package com.arrow.sop.scripts;

import org.testng.annotations.Test;
import com.arrow.workflows.BusinessFunctions_SOP_UnPostLogs;

public class PostLogs extends BusinessFunctions_SOP_UnPostLogs {

	@Test/*(groups= {"newly"})*/
	// Verify Unposted Logs with Attempted as Yes 
	public void attemptUnPostedLog() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookPostLog, "AttemptUnPostLog");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AttemptUnPostLog";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Unposted logs with Attempted as Yes
					//String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					String esopId = submitESOPWithHardCopyRequiredOrNot(SheetName, iLoop);
					String AttemptUnPostedLog = attemptUnPostedLog(SheetName, iLoop, esopId);
					System.out.println(AttemptUnPostedLog);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test/*(groups= {"newly"})*/
	// Verify Unposted Logs when Rejected
	public void rejectUnPostedLog() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookPostLog, "RejectUnpostedLog");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "RejectUnpostedLog";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Unposted logs with Reject as Yes
					//String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					String esopId = submitESOPWithHardCopyRequiredOrNot(SheetName, iLoop);
					String RejectUnPostedLog = rejectUnPostedLog(SheetName, iLoop, esopId);
					System.out.println(RejectUnPostedLog);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test/*(groups= {"newly"})*/
	// Verify Unposted Logs when Post Log clicked
	public void PostLog() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookPostLog, "PostLog");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "PostLog";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Unposted logs with Reject as Yes
					String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					String postLog = postLog(SheetName, iLoop, esopId);
					System.out.println(postLog);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test/*(groups= {"newly"})*/
	// Verify Unposted Logs do not have incomplete worksheet logs
	public void IncompleteWorksheetUnPostedLog() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookPostLog, "IncompleteWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "IncompleteWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Unposted logs with Reject as Yes
					String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					String incompleteWorksheetUnpostedLog = incompleteWorksheetUnpostedLog(SheetName, iLoop, esopId);
					System.out.println(incompleteWorksheetUnpostedLog);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Below scripts added as part of CIOX Arrow Enhancement Project
	//Verify no priority column, priority sorting, priority filter on UnPosted Logs Page: CIA-90
	@Test
	public void verifyPriorityOnUnpostedLogs() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint5, "VerifyPriorityOnUnpostedLogs");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriorityOnUnpostedLogs";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Priority column")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityColumnOnUnpostedLogsPage("VerifyPriorityOnUnpostedLogs", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Sorting")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPrioritySortOnUnpostedLogsPage("VerifyPriorityOnUnpostedLogs", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Filter")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFilterOnUnpostedLogsPage("VerifyPriorityOnUnpostedLogs", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no clone/copied column, field on DocketHistory Page: CIA-90
	@Test
	public void verifyClonedCopiedOnDocketHistory() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint5, "VerifyClonedCopiedDocketHistory");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyClonedCopiedDocketHistory";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Cloned/Copied from field")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedFieldOnDocketHistoryPopUpPage("VerifyClonedCopiedDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied from column")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedColumnOnDocketHistoryPage("VerifyClonedCopiedDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
}
