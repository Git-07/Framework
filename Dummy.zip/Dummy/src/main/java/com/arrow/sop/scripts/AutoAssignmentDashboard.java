package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_AutoAssignmentDashboard;

public class AutoAssignmentDashboard extends BusinessFunctions_SOP_AutoAssignmentDashboard {
	
	// Verify Assignment Dashboard in Auto Assignment Dashboard
	@Test
	public void assignmentDashboard() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard, "AssignmentDashboard");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AssignmentDashboard";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					assignmentDashboard(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	
	// Verify "Logged in Users Dashboard" in Auto Assignment Dashboard
	@Test
	public void loggedInUser() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard, "LoggedInUser");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "LoggedInUser";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					loggedInUser(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	
	// Verify "Assignment By Tier Dashboard" in Auto Assignment Dashboard
	@Test
	public void assignmentByTier() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard, "AssignmentByTier");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AssignmentByTier";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					assignmentByTier(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	
	
	//Verify "User Availability Dashboard" in Auto Assignment Dashboard
	@Test
	public void userAvailabilityDashboard() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard, "UserAvailabilityDashboard");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "UserAvailabilityDashboard";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					userAvailabilityDashboard(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// below test method is added as part of NPD sprint 48 changes in the quality randomiser setup
	@Test
	public void qualityReviewLimitPerDay() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard,"QualityRandomiserSetup");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("QualityRandomiserSetup", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("QualityRandomiserSetup", "Description", iLoop);
			String runStatus = Excelobject.getCellData("QualityRandomiserSetup", "RunStatus", iLoop);
			String member = Excelobject.getCellData("QualityRandomiserSetup", "Member", iLoop);
			String team = Excelobject.getCellData("QualityRandomiserSetup", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Quality Limit count")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);												
					qualityRandomiserSetup("QualityRandomiserSetup", iLoop);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");						
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {}	
		
	}
// below test method is added as part part of Stored procdure changes which was not allowing to delete SOPs
	@Test
	public void deleteTheSOP() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard, "DeleteSOP");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("DeleteSOP", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("DeleteSOP", "Description", iLoop);
			String runStatus = Excelobject.getCellData("DeleteSOP", "RunStatus", iLoop);
			String member = Excelobject.getCellData("DeleteSOP", "Member", iLoop);
			String team = Excelobject.getCellData("DeleteSOP", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Delete")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);											
					deleteTheSOPs("DeleteSOP", iLoop);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");						
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {}	
		
	}	

	// this test method is created to test sp49 changes for rejection rule maintenance app.
		@Test 
		public void rejectionRulesMaintenanceApplication() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAssignmentDashboard, "RejectionRuleMaintenanceApp");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("RejectionRuleMaintenanceApp", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("RejectionRuleMaintenanceApp", "Description", iLoop);
					String runStatus = Excelobject.getCellData("RejectionRuleMaintenanceApp", "RunStatus", iLoop);
					String member = Excelobject.getCellData("RejectionRuleMaintenanceApp", "Member", iLoop);
					String team = Excelobject.getCellData("RejectionRuleMaintenanceApp", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Rejection Rule")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							rejectionRulesMaintenanceApplication("RejectionRuleMaintenanceApp", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
	
}
