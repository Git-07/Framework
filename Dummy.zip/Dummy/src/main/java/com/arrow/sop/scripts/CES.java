package com.arrow.sop.scripts;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_CES;

public class CES extends BusinessFunctions_SOP_CES {

	// Submit esop on ces processing item tab
	@Test
	public void cesProcessingItem() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "CesProcessingItem");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CesProcessingItem";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					cesProcessingItem(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Submit esop from escalated list
	@Test
	public void escalatedList() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "EscalatedList");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EscalatedList";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					escalatedList(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// Submit esop from On Hold list
		@Test
		public void onHoldList() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "OnHoldList");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "OnHoldList";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						onHoldList(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}

//Below Test is added as part of CES enhancement Rejection Workflow project
		@Test
		public void retainDataForTheESOP() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "CESDataRetained");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("CESDataRetained", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("CESDataRetained", "Description", iLoop);
					String runStatus = Excelobject.getCellData("CESDataRetained", "RunStatus", iLoop);
					String member = Excelobject.getCellData("CESDataRetained", "Member", iLoop);
					String team = Excelobject.getCellData("CESDataRetained", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Escalated ESOP")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							String esopId = esopEscalatedOrOnHold("CESDataRetained",iLoop);
							processEscalatedOrOnHoldESOP("CESDataRetained",iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
						else if (testCaseID.contains("On Hold ESOP")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							String esopId = esopEscalatedOrOnHold("CESDataRetained",iLoop);
							processEscalatedOrOnHoldESOP("CESDataRetained",iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}


		}
//Below Test method is added as part of CES Enahcenment Rejection workflow
		
		@Test
		public void plaintiffAndDefendantMandatoryFieldsToSubmitESOP() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "PlaintiffAndDefendantMandatory");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("PlaintiffAndDefendantMandatory", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("PlaintiffAndDefendantMandatory", "Description", iLoop);
					String runStatus = Excelobject.getCellData("PlaintiffAndDefendantMandatory", "RunStatus", iLoop);
					String member = Excelobject.getCellData("PlaintiffAndDefendantMandatory", "Member", iLoop);
					String team = Excelobject.getCellData("PlaintiffAndDefendantMandatory", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Plaintiff and Defendant fields")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							validatePlaintiffAndDefendantFieldsAreMandatory("PlaintiffAndDefendantMandatory",iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}
		}
		
//Below function is added as part of CES enhancement rejection workflow changes
		@Test
		public void retainDataForTheESOPForTheNRAIEntity() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "RetainESOPDataForNRAI");			
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("RetainESOPDataForNRAI", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("RetainESOPDataForNRAI", "Description", iLoop);
					String runStatus = Excelobject.getCellData("RetainESOPDataForNRAI", "RunStatus", iLoop);
					String member = Excelobject.getCellData("RetainESOPDataForNRAI", "Member", iLoop);
					String team = Excelobject.getCellData("RetainESOPDataForNRAI", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Escalated ESOP")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							String esopId = esopEscalatedOrOnHold("RetainESOPDataForNRAI",iLoop);
							processEscalatedOrOnHoldESOP("RetainESOPDataForNRAI",iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
						else if (testCaseID.contains("On Hold ESOP")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							String esopId = esopEscalatedOrOnHold("RetainESOPDataForNRAI",iLoop);
							processEscalatedOrOnHoldESOP("RetainESOPDataForNRAI",iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}


		}
	
//Below method is added as part of CEs enhancement Rejection workflow changes
		@Test
		public void rejectionListUIValidateForDifferentMember() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "RejectionsListUI");			
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("RejectionsListUI", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("RejectionsListUI", "Description", iLoop);
					String runStatus = Excelobject.getCellData("RejectionsListUI", "RunStatus", iLoop);
					String member = Excelobject.getCellData("RejectionsListUI", "Member", iLoop);
					String team = Excelobject.getCellData("RejectionsListUI", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Level")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
	                        rejectionListForPosssibleRejection("RejectionsListUI",iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}
		
//Below test method is added as part of CES enhancement rejection workflow
		//@Test
		public void entitySectionDefaultExpanded() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "EntitySectionExpanded");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("EntitySectionExpanded", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("EntitySectionExpanded", "Description", iLoop);
					String runStatus = Excelobject.getCellData("EntitySectionExpanded", "RunStatus", iLoop);
					String member = Excelobject.getCellData("EntitySectionExpanded", "Member", iLoop);
					String team = Excelobject.getCellData("EntitySectionExpanded", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {	
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							entitySectionDetailsOnProcessingCES("EntitySectionExpanded", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}

//Below test method is added as part of CES enhancement Rejection changes
		@Test/*(groups= {"newly"})*/
		public void levelSpecificFieldsInCESPage() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "LevelSpecificCESFields");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("LevelSpecificCESFields", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("LevelSpecificCESFields", "Description", iLoop);
					String runStatus = Excelobject.getCellData("LevelSpecificCESFields", "RunStatus", iLoop);
					String member = Excelobject.getCellData("LevelSpecificCESFields", "Member", iLoop);
					String team = Excelobject.getCellData("LevelSpecificCESFields", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Log in As Level")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							entitySectionDetailsOnProcessingCES("LevelSpecificCESFields", iLoop);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}	

//Below Test Method is added part of CES enhancement rejection workflow
		@Test
		public void relatedLogSearchfunctionality() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "RelatedLogSearch");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("RelatedLogSearch", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("RelatedLogSearch", "Description", iLoop);
					String runStatus = Excelobject.getCellData("RelatedLogSearch", "RunStatus", iLoop);
					String member = Excelobject.getCellData("RelatedLogSearch", "Member", iLoop);
					String team = Excelobject.getCellData("RelatedLogSearch", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Search By Case#")) {	
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							entitySectionDetailsOnProcessingCES("RelatedLogSearch", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							} catch (Exception e) {
								e.printStackTrace();
							}
							driver.get(URL);
						}
					}
				}
	
		}	

		//Below test method is added as part of CES Enhancement Rejection workflow changes
		@Test
		public void newStatusCodeForPossibleRejection() throws Throwable {			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "StatusCodePossibleRejection");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				
					String testCaseID = Excelobject.getCellData("StatusCodePossibleRejection", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("StatusCodePossibleRejection", "Description", iLoop);
					String runStatus = Excelobject.getCellData("StatusCodePossibleRejection", "RunStatus", iLoop);
					String member = Excelobject.getCellData("StatusCodePossibleRejection", "Member", iLoop);
					String team = Excelobject.getCellData("StatusCodePossibleRejection", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {	
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);												
							String esopId = entitySectionDetailsOnProcessingCES("StatusCodePossibleRejection", iLoop);
							compareTheCurrentStatus("StatusCodePossibleRejection", iLoop,esopId);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");	
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}
	
		}
		
		//Below test method is added as part of CES Enhancement rejection workflow changes
		@Parameters({"environment"})
		@Test
		public void rejectReasonAndReasonForNotRejectingFunctionality(String environment) throws Throwable {			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "NotRejectingFunctionality");			
				uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes",environment);
				uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("NotRejectingFunctionality", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("NotRejectingFunctionality", "Description", iLoop);
					String runStatus = Excelobject.getCellData("NotRejectingFunctionality", "RunStatus", iLoop);
					String member = Excelobject.getCellData("NotRejectingFunctionality", "Member", iLoop);
					String team = Excelobject.getCellData("NotRejectingFunctionality", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {
							try {
							child = extent.startTest(testCaseID, description);						
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							entitySectionDetailsOnProcessingCES("NotRejectingFunctionality", iLoop);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}

		//Below Test method is added as part of CES Enhancement Rejection workflow
		
		@Test
		public void postCompletCESGrandTotalAndTier3CountsCESProductivity() throws Throwable {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "CESProductivity");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {			
					String testCaseID = Excelobject.getCellData("CESProductivity", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("CESProductivity", "Description", iLoop);
					String runStatus = Excelobject.getCellData("CESProductivity", "RunStatus", iLoop);
					String member = Excelobject.getCellData("CESProductivity", "Member", iLoop);
					String team = Excelobject.getCellData("CESProductivity", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);	
							entitySectionDetailsOnProcessingCES("CESProductivity", iLoop);
							cesProductivityGrandTotalAndTier3();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}
 // Below test method is added as part of CES Enhancement Rejection workflow
		@Test
		public void attorneyAndCourtInCES() throws Throwable {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "AttorneyAndCourtInCES");	
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("AttorneyAndCourtInCES", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("AttorneyAndCourtInCES", "Description", iLoop);
					String runStatus = Excelobject.getCellData("AttorneyAndCourtInCES", "RunStatus", iLoop);
					String member = Excelobject.getCellData("AttorneyAndCourtInCES", "Member", iLoop);
					String team = Excelobject.getCellData("AttorneyAndCourtInCES", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);												
							String esopId = entitySectionDetailsOnProcessingCES("AttorneyAndCourtInCES", iLoop);							
							//viewAndCreateTheWorkSheetUsingESOPId("AttorneyAndCourtInCES", iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}
		
		@Test
		public void updateToPossibleRejectionFromEscalatedList() throws Throwable {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "UpdateToPossibleRejection");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("UpdateToPossibleRejection", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("UpdateToPossibleRejection", "Description", iLoop);
					String runStatus = Excelobject.getCellData("UpdateToPossibleRejection", "RunStatus", iLoop);
					String member = Excelobject.getCellData("UpdateToPossibleRejection", "Member", iLoop);
					String team = Excelobject.getCellData("UpdateToPossibleRejection", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {	
							try {						
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);												
							String esopId = entitySectionDetailsOnProcessingCES("UpdateToPossibleRejection", iLoop);
							compareTheCurrentStatus("UpdateToPossibleRejection", iLoop, esopId);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}

		//Below test method is added a part of CES enhancement Rejection changes
		@Test
		public void helpPageFromTheCES() throws Throwable {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "CESHelpPages");	
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("CESHelpPages", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("CESHelpPages", "Description", iLoop);
					String runStatus = Excelobject.getCellData("CESHelpPages", "RunStatus", iLoop);
					String member = Excelobject.getCellData("CESHelpPages", "Member", iLoop);
					String team = Excelobject.getCellData("CESHelpPages", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Process")) {	
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							helpPageInCESQueue("CESHelpPages", iLoop);
							driver.manage().deleteAllCookies();						
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}

		}
		
		//Below test method is added as part of CEs Rejection changes
		@Parameters({"environment"})
		@Test/*(groups= {"newly"})*/
		public void createRejectLogFromTheCESPage(String environment) throws Throwable {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "RejectionLogFromCES");
				//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes",environment);
				//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("RejectionLogFromCES", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("RejectionLogFromCES", "Description", iLoop);
					String runStatus = Excelobject.getCellData("RejectionLogFromCES", "RunStatus", iLoop);
					String member = Excelobject.getCellData("RejectionLogFromCES", "Member", iLoop);
					String team = Excelobject.getCellData("RejectionLogFromCES", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Reject")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							String esopId = entitySectionDetailsOnProcessingCES("RejectionLogFromCES", iLoop);
							rejectedLogFieldValidation(esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						} catch (Exception e) {
							e.printStackTrace();
						}
							driver.get(URL);
						}
					}
				}
		
		}

		//Below Test method is added as part of CES Enhancement Rejection changes
		@Parameters({"environment"})
		@Test(groups= {"newly"})
		public void rejectionLetterPopUpFromTheCESPage(String environment) throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "RejectionLetterFromCES");	
				//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes",environment);
				//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("RejectionLetterFromCES", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("RejectionLetterFromCES", "Description", iLoop);
					String runStatus = Excelobject.getCellData("RejectionLetterFromCES", "RunStatus", iLoop);
					String member = Excelobject.getCellData("RejectionLetterFromCES", "Member", iLoop);
					String team = Excelobject.getCellData("RejectionLetterFromCES", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Reject")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							rejectESOPWithHardCopyRequiredOrNot("RejectionLetterFromCES", iLoop);						
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
							driver.get(URL);
						}
					}
				}

		}

//this test method added as part of NPD sprint 48 changes where the drop down values are added under REason for not rejecting 		
		@Test
		public void additionalValuesForReasonForNotRejection() throws Throwable {
					
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "AdditionalNotRejectionReason");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("AdditionalNotRejectionReason", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("AdditionalNotRejectionReason", "Description", iLoop);
				String runStatus = Excelobject.getCellData("AdditionalNotRejectionReason", "RunStatus", iLoop);
				String member = Excelobject.getCellData("AdditionalNotRejectionReason", "Member", iLoop);
				String team = Excelobject.getCellData("AdditionalNotRejectionReason", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {	
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						// esopId = submitESOPWithHardCopyRequiredOrNot("AdditionalNotRejectionReason", iLoop);
						String esopId = entitySectionDetailsOnProcessingCES("AdditionalNotRejectionReason", iLoop);
						compareTheReasonForNotRejection("AdditionalNotRejectionReason", iLoop,esopId);					
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");	
					}catch(Exception e) {
						e.printStackTrace();		
					}
						driver.get(URL);
					}
				}
			}
			
		}	

		//below test method is added as part of Sp 48 for not rejection reason in on hold queue
		@Test/*(groups= {"newly"})*/
		public void onHoldQueueReasonForNotRejection() throws Throwable {
				
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "OnHoldNotRejectionReason");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("OnHoldNotRejectionReason", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("OnHoldNotRejectionReason", "Description", iLoop);
				String runStatus = Excelobject.getCellData("OnHoldNotRejectionReason", "RunStatus", iLoop);
				String member = Excelobject.getCellData("OnHoldNotRejectionReason", "Member", iLoop);
				String team = Excelobject.getCellData("OnHoldNotRejectionReason", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {	
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("OnHoldNotRejectionReason", iLoop);
						//String esopId = submitESOPWithHardCopyRequiredOrNot("OnHoldNotRejectionReason", iLoop);
						compareTheCurrentStatus("OnHoldNotRejectionReason", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
						driver.get(URL);
					}
				}
			}		
		}
		
// Below test method created as part of Bulk Retirement Process		
//All the expedited Transmission related Test Scenarios are being taken care in 'bulkWorksheetActionItemExecution' test method
		//@Test
		public void bulkWorksheetCreation() throws Throwable {
							
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "BulkWorksheetAfterCESSubmit");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("BulkWorksheetAfterCESSubmit", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("BulkWorksheetAfterCESSubmit", "Description", iLoop);
				String runStatus = Excelobject.getCellData("BulkWorksheetAfterCESSubmit", "RunStatus", iLoop);
				String member = Excelobject.getCellData("BulkWorksheetAfterCESSubmit", "Member", iLoop);
				String team = Excelobject.getCellData("BulkWorksheetAfterCESSubmit", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);	
						//Below submitESOPWithHardCopyRequiredOrNot is modified as part of Sprint 53 changes
						//to handle the alert pop up after selecting an arrow entity
						String esopId = submitESOPWithHardCopyRequiredOrNot("BulkWorksheetAfterCESSubmit", iLoop);
						compareExpeditedWorkflow("BulkWorksheetAfterCESSubmit", iLoop,esopId);									
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {}
						driver.get(URL);
					}
				}
			}
		
		}
		//Below function needs to modify and handle the post ces submit scenarios at last after all submit completed
		
	//Below test method is created as part of Bulk retirement project
	//--modified CES.xlsx test data file for this
		@Test/**/
		public void bulkWorksheetActionItemExecution() throws Throwable {
			
		Map<Integer,String> acceleratedWorksheet = new HashMap<Integer,String>();
		int acceleratedLogKey =1;		
		int currentTest = 0;
				
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "ActionItemExecAcceleratedLog");
			
			//Below parameter is added to fix the execution timing related issue
			int totalTest = inputSheet.getPhysicalNumberOfRows();
			String [] esops = new String[totalTest];
			
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("ActionItemExecAcceleratedLog", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("ActionItemExecAcceleratedLog", "Description", iLoop);
				String runStatus = Excelobject.getCellData("ActionItemExecAcceleratedLog", "RunStatus", iLoop);
				String member = Excelobject.getCellData("ActionItemExecAcceleratedLog", "Member", iLoop);
				String team = Excelobject.getCellData("ActionItemExecAcceleratedLog", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					
					if (testCaseID.contains("Process")) {	
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);											
						String esopId = submitESOPWithHardCopyRequiredOrNot("ActionItemExecAcceleratedLog", iLoop);
						//Below two lines of code is added on 7/1/21					
						esops[currentTest] = esopId;
						++currentTest;	
						
						
						//validate the log in expedited transmission page					
						/*compareExpeditedWorkflow("ActionItemExecAcceleratedLog", iLoop,esopId);
						expeditedTransmissionLog(esopId);	
						acceleratedWorksheet.put(acceleratedLogKey, actionItemExecution(esopId));						
						transmittalDataVerification("ActionItemExecAcceleratedLog", iLoop,esopId);*/
						
						acceleratedLogKey++;
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
					    }catch(Exception e) {
						e.printStackTrace();										
					    }						
				}
					driver.get(URL);
			}			
	 }
			acceleratedWorksheet = validateExpeditedTransmission("Success",currentTest - 1,"ActionItemExecAcceleratedLog",esops);	
            Excelobject.writeDataToExistingExcel(TestDataWorkBookSOPCES,acceleratedLogKey - 1,"Accelerated Log",acceleratedWorksheet);

}
		//Below test method is created as part of bulk retirement project
	
		@Parameters({"sopHubUrl"})
		@Test/*(groups= {"newly"},dependsOnMethods = {"bulkWorksheetActionItemExecution"})*/
		public void validateAcceleratedLogInSOPHub(String sopHubUrl) throws Throwable {		
				
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "ActionItemExecAcceleratedLog");	
			int rows = inputSheet.getPhysicalNumberOfRows();
			for(int iLoop =0 ; iLoop<= rows; iLoop++){			
				String testCaseID = Excelobject.getCellData("ActionItemExecAcceleratedLog", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("ActionItemExecAcceleratedLog", "Description", iLoop);
				String runStatus = Excelobject.getCellData("ActionItemExecAcceleratedLog", "RunStatus", iLoop);			
				String sopHubUser = Excelobject.getCellData("ActionItemExecAcceleratedLog", "User Name", iLoop);
				String sopHubUserPwd = Excelobject.getCellData("ActionItemExecAcceleratedLog", "Password", iLoop);
				String firstName = Excelobject.getCellData("ActionItemExecAcceleratedLog", "First Name", iLoop);
				String lastName = Excelobject.getCellData("ActionItemExecAcceleratedLog", "Last Name", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");																		
						//below SOP Hub side validations
						driver.get(sopHubUrl);
						loginToSOPHub(sopHubUser,sopHubUserPwd,firstName,lastName);
						bulkWorksheetInSOPHub("ActionItemExecAcceleratedLog",iLoop);
						logoutFromSopHub();
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();
						
						}						
					}
				}
			}			
			Excelobject.removeDataFromColumn(TestDataWorkBookSOPCES,rows,"Accelerated Log","");
		
	}
		
		//Below test method is created as part of bulk retirement project
		//Below function needs to modify and handle the post ces submit scenarios at last after all submit completed	
		//--modified CES.xlsx test data file for this
		@Test
		public void bulkWorksheetActionItemExecutionFailure() throws Throwable {			

			int currentTest = 0;
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "ActionItemExecFailureLog");
			//Below parameter is added to fix the execution timing related issue
			int totalTest = inputSheet.getPhysicalNumberOfRows();
			String [] esops = new String[totalTest];
							
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "ActionItemExecFailureLog");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("ActionItemExecFailureLog", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("ActionItemExecFailureLog", "Description", iLoop);
				String runStatus = Excelobject.getCellData("ActionItemExecFailureLog", "RunStatus", iLoop);
				String member = Excelobject.getCellData("ActionItemExecFailureLog", "Member", iLoop);
				String team = Excelobject.getCellData("ActionItemExecFailureLog", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = submitESOPWithHardCopyRequiredOrNot("ActionItemExecFailureLog", iLoop);
						//Below two lines of code is added on 7/1/21					
						esops[currentTest] = esopId;
						++currentTest;
									
/*						compareExpeditedWorkflow("ActionItemExecFailureLog", iLoop,esopId);
						logInActionItemFailure(esopId);	*/
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {}
						driver.get(URL);
					}
				}
			}
			validateExpeditedTransmission("Failed",currentTest - 1,"ActionItemExecFailureLog",esops);		
	}
		
		//Below test method is created as part of Bulk retirement project
		//Below function needs to modify and handle the post ces submit scenarios at last after all submit completed
		@Test
		public void sopWorkflowInWorksheet() throws Throwable {
			
			int currentTest = 0;
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "SOPWorkflowInWorksheet");
			//Below parameter is added to fix the execution timing related issue
			int totalTest = inputSheet.getPhysicalNumberOfRows();
			String [] esops = new String[totalTest];
				
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "SOPWorkflowInWorksheet");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {			
					String testCaseID = Excelobject.getCellData("SOPWorkflowInWorksheet", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("SOPWorkflowInWorksheet", "Description", iLoop);
					String runStatus = Excelobject.getCellData("SOPWorkflowInWorksheet", "RunStatus", iLoop);
					String member = Excelobject.getCellData("SOPWorkflowInWorksheet", "Member", iLoop);
					String team = Excelobject.getCellData("SOPWorkflowInWorksheet", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Reject")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);												
							String esopId = entitySectionDetailsOnProcessingCES("SOPWorkflowInWorksheet", iLoop);
							//Below two lines of code is added on 7/1/21					
							esops[currentTest] = esopId;
							++currentTest;
							
							
							/*compareTheCurrentStatus("SOPWorkflowInWorksheet", iLoop,esopId);
							sopWorkflow("SOPWorkflowInWorksheet", iLoop,esopId);*/
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							} catch (Exception e) {
								e.printStackTrace();
							}
							driver.get(URL);
						}
						else if(testCaseID.contains("Create")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);												
							String esopId = submitESOPWithHardCopyRequiredOrNot("SOPWorkflowInWorksheet", iLoop);
							//Below two lines of code is added on 7/1/21					
							esops[currentTest] = esopId;
							++currentTest;
							
							/*compareTheCurrentStatus("SOPWorkflowInWorksheet", iLoop,esopId);
							viewAndCreateTheWorkSheetUsingESOPId("SOPWorkflowInWorksheet", iLoop,esopId);
							sopWorkflow("SOPWorkflowInWorksheet", iLoop,esopId);*/
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							} catch (Exception e) {
								e.printStackTrace();
							}
							driver.get(URL);
						}
						else if (testCaseID.contains("Process")) {
							try {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);												
							String esopId = submitESOPWithHardCopyRequiredOrNot("SOPWorkflowInWorksheet", iLoop);
							//Below two lines of code is added on 7/1/21
							esops[currentTest] = esopId;
							++currentTest;
							
							/*compareExpeditedWorkflow("SOPWorkflowInWorksheet", iLoop,esopId);
							sopWorkflow("SOPWorkflowInWorksheet", iLoop,esopId);*/
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							} catch (Exception e) {
								e.printStackTrace();
							}
							driver.get(URL);
						}
					}
				}
				validateSOPWorkflowInWorksheet(currentTest - 1,"SOPWorkflowInWorksheet",esops);

		}
		
		//Below test method is created as part of Bulk retirement project
		//Below function needs to modify and handle the post ces submit scenarios at last after all submit completed	
		@Test/*(groups= {"newly"})*/
		public void addAndExecuteDIForActionItemExecutionFailure() throws Throwable {			
			
			int currentTest = 0;
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "ActionItemFailureAddDI");
			//Below parameter is added to fix the execution timing related issue
			int totalTest = inputSheet.getPhysicalNumberOfRows();
			String [] esops = new String[totalTest];
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "ActionItemFailureAddDI");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("ActionItemFailureAddDI", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("ActionItemFailureAddDI", "Description", iLoop);
				String runStatus = Excelobject.getCellData("ActionItemFailureAddDI", "RunStatus", iLoop);
				String member = Excelobject.getCellData("ActionItemFailureAddDI", "Member", iLoop);
				String team = Excelobject.getCellData("ActionItemFailureAddDI", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = submitESOPWithHardCopyRequiredOrNot("ActionItemFailureAddDI", iLoop);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;
						
						/*logInActionItemFailure(esopId);
						createAndExecuteActionItem("ActionItemFailureAddDI", iLoop,esopId);
						compareExpeditedWorkflow("ActionItemFailureAddDI", iLoop,esopId);*/
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
						driver.get(URL);
					}
				}
			}
			createAndExecuteActionItemForAcceleratedLog(currentTest - 1,"ActionItemFailureAddDI",esops);
	
	}
        //Below test method is added as part of the bulk retirement project
		//Below function needs to modify and handle the post ces submit scenarios at last after all submit completed
		@Test/*(groups= {"newly"})*/
		public void modifyAndExecuteDIForPostedLog() throws Throwable {
			
			int currentTest = 0;
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "UnExecuteAndExecuteNewDI");
			//Below parameter is added to fix the execution timing related issue
			int totalTest = inputSheet.getPhysicalNumberOfRows();
			String [] esops = new String[totalTest];
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "UnExecuteAndExecuteNewDI");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "Description", iLoop);
				String runStatus = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "RunStatus", iLoop);
				String member = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "Member", iLoop);
				String team = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {		
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = submitESOPWithHardCopyRequiredOrNot("UnExecuteAndExecuteNewDI", iLoop);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;
						
						/*compareExpeditedWorkflow("UnExecuteAndExecuteNewDI", iLoop,esopId);
						unexecuteActionItems(esopId);
						createAndExecuteActionItem("UnExecuteAndExecuteNewDI", iLoop,esopId);						
						rejectedLogHardCopyRequiredSOPTeamDashboard("UnExecuteAndExecuteNewDI", iLoop,esopId);*/
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
						driver.get(URL);
					}
				}
			}
			unExecuteActionItemForHardCopyDIAcceleratedLog(currentTest - 1,"UnExecuteAndExecuteNewDI",esops);
	}

		//Below function needs to modify and handle the post ces submit scenarios at last after all submit completed
		@Test
		public void createCRMAfterWorksheetCreation() throws Throwable {		
			
			int currentTest = 0;
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "CreateCRMRequestAfterWorksheet");
			//Below parameter is added to fix the execution timing related issue
			int totalTest = inputSheet.getPhysicalNumberOfRows();
			String [] esops = new String[totalTest];
					
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "CreateCRMRequestAfterWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "Team", iLoop);			
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					
					if (testCaseID.contains("Process")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);						
						String esopId = submitESOPWithHardCopyRequiredOrNot("CreateCRMRequestAfterWorksheet", iLoop);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;
						
						//createSOPIncidentReportOnTheCreatedWorksheet(esopId);
						
						
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
						driver.get(URL);
					}
					else if (testCaseID.contains("For Bulk not eligible")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);						
						String esopId = submitESOPWithHardCopyRequiredOrNot("CreateCRMRequestAfterWorksheet", iLoop);
						esops[currentTest] = esopId;
						++currentTest;
						/*viewAndCreateTheWorkSheetUsingESOPId("CreateCRMRequestAfterWorksheet", iLoop,esopId);
						createSOPIncidentReportOnTheCreatedWorksheet(esopId);*/
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
						driver.get(URL);
					}
/*					else if (testCaseID.contains("My Worksheets to review Tab")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						
						worksheetInMyWorksheetsToReview(esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						}catch(Exception e) {
							e.printStackTrace();		
						}
						driver.get(URL);
					}*/
				}
			}
			
			validateCRMForWorksheet(currentTest - 1,"CreateCRMRequestAfterWorksheet",esops);
		}
}
