package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_Quality_Maintainance;

public class QualityMaintainance extends BusinessFunctions_Quality_Maintainance{
	
	//Verify in Worksheet Review Setup page, user can move fields present in Reviewable, Fatal/NonFatal and Typo and Save them
		@Test
		public void worksheetReviewSetup() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookQualityMaintainance_SOP, "WorksheetReviewSetUp");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "WorksheetReviewSetUp";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						worksheetReviewSetup(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		
		//Verify in Quality Randomiser Setup page under Exclude Affiliations tab, user can Add and Delete Affiliation
				@Test
				public void excludeAffiliations() throws Throwable {
					inputSheet = Excelobject.getSheetObject(TestDataWorkBookQualityMaintainance_SOP, "ExcludeAffiliations");
					for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
						try {
							String SheetName = "ExcludeAffiliations";
							String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
							String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
							String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
							String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
							String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
							if (runStatus.trim().equalsIgnoreCase("Y")) {
								child = extent.startTest(strTestCaseID, strDesc);

								// This will mark the beginning of row in data sheet
								iterationReport(iLoop - 1, strTestCaseID + " Started");

								// This method will log into the Application
								SignIn(strTeam, strMember);

								excludeAffiliations(SheetName, iLoop);

								parent.appendChild(child);
								// This will mark end of the one row in data sheet
								iterationReport(iLoop - 1, strTestCaseID + " Completed");

							}

						} catch (Exception e) {
							catchBlock(e);
						}

					}
				}
				
				
				//Verify in Quality Randomiser Setup page under Exclude Affiliations tab, user can Add and Delete Affiliation
				@Test
				public void excludeTeams() throws Throwable {
					inputSheet = Excelobject.getSheetObject(TestDataWorkBookQualityMaintainance_SOP, "ExcludeTeams");
					for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
						try {
							String SheetName = "ExcludeTeams";
							String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
							String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
							String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
							String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
							String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
							if (runStatus.trim().equalsIgnoreCase("Y")) {
								child = extent.startTest(strTestCaseID, strDesc);

								// This will mark the beginning of row in data sheet
								iterationReport(iLoop - 1, strTestCaseID + " Started");

								// This method will log into the Application
								SignIn(strTeam, strMember);

								excludeTeams(SheetName, iLoop);

								parent.appendChild(child);
								// This will mark end of the one row in data sheet
								iterationReport(iLoop - 1, strTestCaseID + " Completed");

							}

						} catch (Exception e) {
							catchBlock(e);
						}

					}
				}




}
