package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_CommonAlerts;

public class CommonAlerts extends BusinessFunctions_SOP_CommonAlerts{

	//Verify Common Alerts when no mandatory fields are entered
	@Test
	public void errorCommonAlerts() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "ErrorMessage");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ErrorMessage";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					alertErrorMessage(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	//Verify Common Alerts when Entity is selected
	@Test
	public void entityCommonAlerts() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "EntityCommonAlerts");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EntityCommonAlerts";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					entityCommonAlerts(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	//Verify Common Alerts when Affiliation is selected
	@Test
	public void affiliationCommonAlerts() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "AffiiationCommonAlerts");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AffiiationCommonAlerts";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					affiliationCommonAlerts(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	//Below scripts added as part of CIOX Arrow Enhancement Project
	//Verify CES Internal Comments & Internal Comments functionality Create WorkSheet Page: CIA-126
	@Test/*(groups= {"newly"})*/
	public void verifyCESInternalCommentsForWorksheetCreation() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "CESICWorksheetCreate");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CESICWorksheetCreate", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CESICWorksheetCreate", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CESICWorksheetCreate", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CESICWorksheetCreate", "Member", iLoop);
				String team = Excelobject.getCellData("CESICWorksheetCreate", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("CES Internal Comments Displayed in static window of Create WorkSheet Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyCESInternalCommentsCreateWorksheet = verifyCESInternalCommentsWorksheetCreate("CESICWorksheetCreate", iLoop);
						System.out.println(VerifyCESInternalCommentsCreateWorksheet);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Add New Internal Comments and Save")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CESICWorksheetCreate", iLoop);
						String NewInternalComments = verifyAddedInternalCommentsForCreateWorksheetPage("CESICWorksheetCreate", iLoop, esopId);
						System.out.println(NewInternalComments);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify CES Internal Comments & Internal Comments functionality Edit WorkSheet Page: CIA-126
	@Test/*(groups= {"newly"})*/
	public void verifyCESInternalCommentsForWorksheetEdit() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "CESICWorksheetEdit");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CESICWorksheetEdit", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CESICWorksheetEdit", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CESICWorksheetEdit", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CESICWorksheetEdit", "Member", iLoop);
				String team = Excelobject.getCellData("CESICWorksheetEdit", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("CES Internal Comments and Internal Comments for Edit WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CESICWorksheetEdit", iLoop);
						String newIntrnalComments = verifyAddedInternalCommentsForCreateWorksheetPage("CESICWorksheetEdit", iLoop, esopId);
						String WorksheetId = verifyCESInternalCommentsForWorksheetEditPage("CESICWorksheetEdit", iLoop, newIntrnalComments);
						System.out.println(WorksheetId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify CES Internal Comments & Internal Comments functionality Review WorkSheet Page: CIA-126
	@Test/*(groups= {"newly"})*/
	public void verifyCESInternalCommentsForWorksheetReview() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "CESICWorksheetReview");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CESICWorksheetReview", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CESICWorksheetReview", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CESICWorksheetReview", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CESICWorksheetReview", "Member", iLoop);
				String team = Excelobject.getCellData("CESICWorksheetReview", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("CES Internal Comments and Internal Comments for Review WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CESICWorksheetReview", iLoop);
						String newIntrnalComments = verifyAddedInternalCommentsForCreateWorksheetPage("CESICWorksheetReview", iLoop, esopId);
						String WorksheetId = verifyCESInternalCommentsForWorksheetReviewPage("CESICWorksheetReview", iLoop, newIntrnalComments);
						System.out.println(WorksheetId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Pdf, IFrame functionality for Create Worksheet Page: CIA-6 & CIA-123
	@Test/*(groups= {"newly"})*/
	public void verifyPdfIFrameFunctionalityForCreateWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "VerifyPdfCreateWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyPdfCreateWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyPdfCreateWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyPdfCreateWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyPdfCreateWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyPdfCreateWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Pdf IFrame Functionalty for Create WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyPdfCreateWorksheet", iLoop);
						String VerifyPdfIFrameCreateWorksheet = verifyPdfIFrameWorksheetCreate("VerifyPdfCreateWorksheet", iLoop, esopId);
						System.out.println(VerifyPdfIFrameCreateWorksheet);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Pdf, IFrame functionality for Edit Worksheet Page: CIA-6 & CIA-123
	@Test
	public void verifyPdfIFrameFunctionalityForEditWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "VerifyPdfEditWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyPdfEditWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyPdfEditWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyPdfEditWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyPdfEditWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyPdfEditWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Pdf IFrame Functionalty for Edit WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String verifyPdfIFrameWorksheetEdit = verifyPdfIFrameWorksheetEdit("VerifyPdfEditWorksheet", iLoop);
						System.out.println(verifyPdfIFrameWorksheetEdit);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Pdf, IFrame functionality for Review Worksheet Page: CIA-6 & CIA-123
	@Test
	public void verifyPdfIFrameFunctionalityForReviewWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "VerifyPdfReviewWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyPdfReviewWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyPdfReviewWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyPdfReviewWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyPdfReviewWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyPdfReviewWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Pdf IFrame Functionalty for Review WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						// This method will log into the Application
						SignInFromSOPSupportTeam();
						String verifyPdfIFrameWorksheetReview = verifyPdfIFrameWorksheetReview("VerifyPdfReviewWorksheet", iLoop);
						System.out.println(verifyPdfIFrameWorksheetReview);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Back To CRM Functionalty for Review WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyBackToCRMButttonForReviewWorksheetPage("VerifyPdfReviewWorksheet", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify if an esop is having common alerts, entity/affiliation/subgroup alerts, Internal Comments, CDSOP Comments then those are displayed on Create, Edit, Review Worksheet Page 
	//in this sequence: CIA-50
	@Test/*(groups= {"newly"})*/
	public void verifyEsopAlertsCommentsOnCreateEditReviewWorksheetPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "EsopAlertsComments");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "EsopAlertsComments";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Esop Alerts Comments verified on Create Edit Review Worksheet Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entityDetailsOnProcessingCES("EsopAlertsComments", iLoop);
						String worksheetId = verifyEsopAlertsCommentsForCreateWorksheetPage("EsopAlertsComments", iLoop, esopId);
						verifyEsopAlertsCommentsForEditWorksheetPage("EsopAlertsComments", iLoop, worksheetId);
						verifyEsopAlertsCommentsForReviewWorksheetPage("EsopAlertsComments", iLoop, worksheetId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no common alerts/entity/affiliation/subgroup alerts/Internal Comments/CDSOP Comments 
	//no change in the Edit/Review worksheet page: CIA-50
	@Test/*(groups= {"newly"})*/
	public void verifyNoAlertsCommentsOnEditReviewWorksheetPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "NoAlertsComments");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NoAlertsComments", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NoAlertsComments", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NoAlertsComments", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NoAlertsComments", "Member", iLoop);
				String team = Excelobject.getCellData("NoAlertsComments", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("No Alerts Comments On Edit Worksheet")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyNoAlertsCommentsForEdit = verifyNoAlertsCommentsOnEditWorksheetPage("NoAlertsComments", iLoop);
						System.out.println(VerifyNoAlertsCommentsForEdit);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Alerts Comments On Review Worksheet")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						String VerifyNoAlertsCommentsForReview = verifyNoAlertsCommentsOnReviewWorksheetPage("NoAlertsComments", iLoop);
						System.out.println(VerifyNoAlertsCommentsForReview);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify comments and alerts are getting displayed on Edit Worksheet Page for Expedited SOP: CIA-50
	@Test/*(groups= {"newly"})*/
	public void verifyAlertsCommentsOnEditForExpeditedSOP() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCommonAlerts, "ExpeditedSOPAlertsComments");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "ExpeditedSOPAlertsComments";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Alerts Comments On Edit Worksheet For Expedited SOP")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyAlertsCommentsForEditWorksheetExpeditedSOP("ExpeditedSOPAlertsComments", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
}
