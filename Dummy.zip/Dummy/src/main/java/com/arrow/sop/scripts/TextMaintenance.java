package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_TextMaintenance;

public class TextMaintenance extends BusinessFunctions_SOP_TextMaintenance{
	
	@Test
	//Verify all Links displayed in Text Maintenance
	public void textMaintenanceLinks() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPTextMaintenance, "TextMaintenanceLinks");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "TextMaintenanceLinks";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					textMaintenanceLinks(SheetName, iLoop);


					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Below scripts added as part of CIOX Arrow Enhancement Project
	// Verify Add Court: CIA-103
	@Test
	public void verifyAddCourtDetails() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPTextMaintenance, "AddCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("AddCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("AddCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("AddCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("AddCourt", "Member", iLoop);
				String team = Excelobject.getCellData("AddCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Added Court displayed in CES Create Edit Review Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyAddedCourtForCESCreateEditReview = verifyAddedCourtForCESCreateEditReview("AddCourt", iLoop);
						System.out.println(VerifyAddedCourtForCESCreateEditReview);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Edit/Update Court: CIA-103
	@Test
	public void verifyUpdateCourtDetails() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPTextMaintenance, "EditCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("EditCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("EditCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("EditCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("EditCourt", "Member", iLoop);
				String team = Excelobject.getCellData("EditCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Updated Court displayed in CES Create Edit Review Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyUpdatedCourtForCESCreateEditReview = verifyUpdatedCourtForCESCreateEditReview("EditCourt", iLoop);
						System.out.println(VerifyUpdatedCourtForCESCreateEditReview);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Delete Court: CIA-103
	@Test
	public void verifyUpdatedDeletedCourtDetails() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPTextMaintenance, "DeleteCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("DeleteCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("DeleteCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("DeleteCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("DeleteCourt", "Member", iLoop);
				String team = Excelobject.getCellData("DeleteCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Deleted Court not displayed in CES Create Edit Review Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyDeletedCourtForCESCreateEditReview = verifyDeletedCourtForCESCreateEditReview("DeleteCourt", iLoop);
						System.out.println(VerifyDeletedCourtForCESCreateEditReview);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify the State of Court field is updated according to the logged in User Team: CIA-103
	//Verify Select One is set by default in State Of Court Dropdown for logged in User Team having  Juris other than US
	@Test
	public void verifyStateOfCourtUpdated() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPTextMaintenance, "DefaultStateOfCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("DefaultStateOfCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("DefaultStateOfCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("DefaultStateOfCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("DefaultStateOfCourt", "Member", iLoop);
				String team = Excelobject.getCellData("DefaultStateOfCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("State of Court field updated according to the logged in User Team")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromAlabamaCTReps();
						String VerifyStateOfCourtForLoggedUserTeam = verifyStateOfCourtForLoggedUserTeam("DefaultStateOfCourt", iLoop);
						System.out.println(VerifyStateOfCourtForLoggedUserTeam);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Select One set by default in State Of Court Dropdown for logged in User Team")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyDefaultStateOfCourtForLoggedUserTeam = verifyDefaultStateOfCourtForLoggedUserTeam("DefaultStateOfCourt", iLoop);
						System.out.println(VerifyDefaultStateOfCourtForLoggedUserTeam);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}
}
