package com.arrow.sop.scripts;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_CES;
import com.arrow.workflows.BusinessFunctions_SOP_TeamDashboard;

public class TeamSOPDashboard extends BusinessFunctions_SOP_TeamDashboard{

	BusinessFunctions_SOP_CES businessFunctionSOPCES = new BusinessFunctions_SOP_CES();
	@Test
	// Verify Team SOP Dashboard 
	public void viewTeamSOPDashboard() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookTeamSOPDashboard, "TeamSOPDashboard");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "TeamSOPDashboard";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Team SOP Dashboard
					String viewTeamSOPDashboard = viewTeamSOPDashboard(SheetName, iLoop);
					System.out.println(viewTeamSOPDashboard);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
      @Test
	// Verify Verify SOP List items without WS navigates user to SOP List
	public void SOPListWithoutWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookTeamSOPDashboard, "SOPListWithoutWS");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SOPListWithoutWS";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Team SOP Dashboard
					String SOPListWithoutWorksheet = SOPListWithoutWorksheet(SheetName, iLoop);
					System.out.println(SOPListWithoutWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
     @Test
	// Verify Action Items and Worksheet Rejection can be Approved when logged in as Amy Mclaren
	public void ApproveActionItemsandRejection() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookTeamSOPDashboard, "ApproveRejection");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ApproveRejection";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				//String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				//String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					//Sign in with Amy Mclaren
					//SignIn(strTeam, strMember);
					SignInFromSOPSupportTeam();

					//This will verify Team SOP Dashboard
					String approveRejectionandActionItem = approveRejectionandActionItem(SheetName, iLoop);
					System.out.println(approveRejectionandActionItem);
					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify Rejected and HardCopy in Team SOP Dashboard and also Verify Content
	public void RejectedAndHardCopy() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookTeamSOPDashboard, "RejectedHardCopy");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "RejectedHardCopy";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Team SOP Dashboard
					String rejectedAndHardCopy = rejectedAndHardCopy(SheetName, iLoop);
					System.out.println(rejectedAndHardCopy);
					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
//Below Test method is added as part of CES Enhancement REjection changes
	
	@Test
	public void rejectionForReviewChangeTeamSOPDashboard() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookTeamSOPDashboard, "RejectionForReviewChange");	
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("RejectionForReviewChange", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("RejectionForReviewChange", "Description", iLoop);
				String runStatus = Excelobject.getCellData("RejectionForReviewChange", "RunStatus", iLoop);
				String member = Excelobject.getCellData("RejectionForReviewChange", "Member", iLoop);
				String team = Excelobject.getCellData("RejectionForReviewChange", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Team SOP Dashboard")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						teamSOPDashboard("RejectionForReviewChange",iLoop);											
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//Below Test method is added as part of CES Enhancement changes
	@Parameters({"environment"})
	@Test
	public void rejectedHardCopyRequiredSOPTeamDashboard(String environment) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookTeamSOPDashboard, "HardCopyRequiredCES");
			businessFunctionSOPCES.uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows(),"Yes",environment);
			businessFunctionSOPCES.uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows(),"No",environment);
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("HardCopyRequiredCES", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("HardCopyRequiredCES", "Description", iLoop);
				String runStatus = Excelobject.getCellData("HardCopyRequiredCES", "RunStatus", iLoop);
				String member = Excelobject.getCellData("HardCopyRequiredCES", "Member", iLoop);
				String team = Excelobject.getCellData("HardCopyRequiredCES", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Reject")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						String esopId = businessFunctionSOPCES.rejectESOPWithHardCopyRequiredOrNot("HardCopyRequiredCES", iLoop);
						rejectedLogHardCopyRequiredSOPTeamDashboard("HardCopyRequiredCES", iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
