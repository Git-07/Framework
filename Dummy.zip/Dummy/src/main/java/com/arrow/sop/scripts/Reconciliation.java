package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_Reconciliation;

public class Reconciliation extends BusinessFunctions_SOP_Reconciliation {

	// Verify Traceable Mail and Process Server links in Reconcilation Calendar 
	@Test
	public void reconciliationLinks() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPReconciliation, "ReconciliationLinks");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ReconciliationLinks";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					reconciliationLinks(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Verify data can be added and viewed in Traceable Mail Reconciliation
	@Test
	public void traceableMailReconciliation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPReconciliation, "TraceableMailReconciliation");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "TraceableMailReconciliation";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					traceableMailReconciliation(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Verify data can be added and viewed in Process Server Reconciliation
	@Test
	public void processServerReconciliation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPReconciliation, "ProcessServerReconciliation");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ProcessServerReconciliation";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					processServerReconciliation(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

}
