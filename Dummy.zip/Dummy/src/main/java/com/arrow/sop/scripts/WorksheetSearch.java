package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_SearchWorksheet;

public class WorksheetSearch extends BusinessFunctions_SOP_SearchWorksheet {

	@Test
	// Verify normal Worksheet Search in SOP
	public void searchWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "SearchWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Search for Worksheet
					String searchWorksheet = searchWorksheet(SheetName, iLoop);
					System.out.println(searchWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify Q2 Legacy Worksheet Search in SOP
	public void q2LegacySearch() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "SearchQ2Legacy");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchQ2Legacy";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Search for Worksheet
					String q2LegacySearch = q2LegacySearch(SheetName, iLoop);
					System.out.println(q2LegacySearch);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify Active Classic Worksheet Search in SOP
	public void activeClassicWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "ClassicWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ClassicWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will search for Active Classic Worksheet
					String activeClassicWorksheetSearch = activeClassicWorksheetSearch(SheetName, iLoop);
					System.out.println(activeClassicWorksheetSearch);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify For Q2 Legacy, Active Classic Worksheet Search in SOP
	public void q2LegacyClassicWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "Q2LegacyClassicSearch");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "Q2LegacyClassicSearch";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will search for Q2 legacy Active Classic Worksheet
					String q2LegacyClassicSearch = q2LegacyClassicSearch(SheetName, iLoop);
					System.out.println(q2LegacyClassicSearch);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

    @Test
	// Verify Archive Classic Worksheet Search in SOP
	public void archiveClassicWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "ArchiveClassicWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ArchiveClassicWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will search for Archive Classic Worksheet
					String archiveClassicWorksheetSearch = archiveClassicWorksheetSearch(SheetName, iLoop);
					System.out.println(archiveClassicWorksheetSearch);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test/*(groups= {"newly"})*/
	// Verify Related Worksheet Search in SOP
	public void relatedWorksheetSearh() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "RelatedWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "RelatedWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will search for Related Worksheet Search
					String esopId = submitESOPWithHardCopyRequiredOrNot(SheetName, iLoop);
					String relatedWorksheetSearh = relatedWorksheetSearh(SheetName, iLoop, esopId);
					System.out.println(relatedWorksheetSearh);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify Related Worksheet Search in SOP
	public void searhByBatchNo() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "SearchByBatchNo");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchByBatchNo";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will search for Related Worksheet Search
					String searhByBatchNo = searhByBatchNo(SheetName, iLoop);
					System.out.println(searhByBatchNo);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	// User performs an Entity search for an Affiliated Entity having alert Type as
	// Entity Affiliation Subgroup and Alerts targeted state as ALL or State of the
	// logged in user
	@Test
	public void entityHavingAlerts() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPSearchWorksheet, "EntityHavingAlerts");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EntityHavingAlerts";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					entityHavingAlerts(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}


	
}
