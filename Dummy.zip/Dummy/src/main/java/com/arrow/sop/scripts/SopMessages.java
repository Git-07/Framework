package com.arrow.sop.scripts;

import com.arrow.workflows.BusinessFunctions_SOP_Messages;
import org.testng.annotations.Test;

public class SopMessages extends BusinessFunctions_SOP_Messages {
	
	//Business has descoped the functionality as part of CIOX project.

	// Click on View and verify functionality of Buttons of My Active Messages Tab
    //  @Test
	public void myActiveMessages() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPMessages_SOP, "ActiveMessages");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ActiveMessages";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					myActiveMessages(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Click on View and verify functionality of Buttons of My Teams Active Messages Tab
	// @Test
	public void myTeamsActiveMessages() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPMessages_SOP, "TeamsActiveMessages");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "TeamsActiveMessages";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					myTeamsActiveMessages(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// Click on View and verify functionality of Buttons of My Message History Tab
	//	 @Test
		public void myMessageHistory() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPMessages_SOP, "MyMessageHistory");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "MyMessageHistory";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						myMessageHistory(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		
		
		// Click on View and verify functionality of Buttons of My Teams Message History Tab
		//		 @Test
				public void myTeamsMessageHistory() throws Throwable {
					inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPMessages_SOP, "MyTeamsMessageHistory");
					for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
						try {
							String SheetName = "MyTeamsMessageHistory";
							String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
							String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
							String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
							String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
							String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
							if (runStatus.trim().equalsIgnoreCase("Y")) {
								child = extent.startTest(strTestCaseID, strDesc);

								// This will mark the beginning of row in data sheet
								iterationReport(iLoop - 1, strTestCaseID + " Started");

								// This method will log into the Application
								SignIn(strTeam, strMember);

								myTeamsMessageHistory(SheetName, iLoop);

								parent.appendChild(child);
								// This will mark end of the one row in data sheet
								iterationReport(iLoop - 1, strTestCaseID + " Completed");

							}

						} catch (Exception e) {
							catchBlock(e);
						}

					}
				}



}
