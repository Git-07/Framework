package com.arrow.sop.scripts;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_CES;
import com.arrow.workflows.BusinessFunctions_SOP_CreateWorksheet;

public class WorksheetCreation extends BusinessFunctions_SOP_CreateWorksheet {

	//Business has descoped the below 2 functionality as part of CIOX project.
	//@Test
	// Verify Create Worksheet in SOP via HomePage
	public void createWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CreateSOP");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreateSOP";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Create Worksheet
					createWorksheet(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//@Test
	// Verify Create Worksheet in SOP via My Worksheet 
	public void myWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "MyWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "MyWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Create Worksheet via My Worksheet
					String MyWorksheet = myWorksheet(SheetName, iLoop);
					System.out.println(MyWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify Create Worksheet in SOP via SOP List 
	public void sopList() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "SOPList");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SOPList";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify Create Worksheet via SOP List
					String SOPList = sopList(SheetName, iLoop);
					System.out.println(SOPList);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test/*(groups= {"newly"})*/
	// Verify Edit Worksheet for Worksheets displayed in My Worksheets 
	public void editMyWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "EditMyWorksheet");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EditMyWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will Edit Worksheet 
					String EditMyWorksheet = editMyWorksheet(SheetName, iLoop);
					System.out.println(EditMyWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify Internal Comments for Worksheets  
	public void internalComments() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "InternalComments");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "InternalComments";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will add in Internal Comments in Worksheet 
					String InternalComments = internalComments(SheetName, iLoop);
					System.out.println(InternalComments);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test
	// Verify Review for Worksheets  
	public void reviewComments() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "ReviewSOP");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ReviewSOP";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will add in Review Comments in Worksheet 
					String ReviewSOP = reviewSOP(SheetName, iLoop);
					System.out.println(ReviewSOP);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	@Test/*(groups= {"newly"})*/
	// Verify Worksheets can be Rejected
	public void rejectWorksheets() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "Reject");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "Reject";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will add in Reject Worksheet 
					String RejectWorksheet = rejectWorksheet(SheetName, iLoop);
					System.out.println(RejectWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}


	@Test/*(groups= {"newly"})*/
	// Verify Worksheets can edit Assigned and Received in Worksheet
	public void editAssignedAndReceived() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "AssignedReceived");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AssignedReceived";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will add in Reject Worksheet 
					String editAssignedReceivedValue = editAssignedReceivedValue(SheetName, iLoop);
					System.out.println(editAssignedReceivedValue);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}


	@Test
	// Verify Images can be uploaded
	public void uploadImage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "SOPUpload");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SOPUpload";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will add in Reject Worksheet 
					uploadImage(SheetName, iLoop);


					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//NPD Sprint 8 - Expedited SOP Permissions on Roles Page
	@Test
	public void ExpeditedSOPPermissionOnRolesPage() throws Throwable{
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "ExpeditedSOPPermission");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {

			String SheetName = "ExpeditedSOPPermission";
			String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
			String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
			String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
			String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
			String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

			if(runStatus.trim().equalsIgnoreCase("Y")) {					  					 
				if(strTestCaseID.contains("Create a Role")) {
					try {
						child = extent.startTest(strTestCaseID, strDesc);					
						iterationReport(iLoop-1,strTestCaseID+" Started");
						SignIn(strTeam, strMember);
						expeditedSOPPermissionOnRolesPage(SheetName, iLoop);
						parent.appendChild(child);
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}
				else if(strTestCaseID.contains("Update the Permission")) {
					try {
						child = extent.startTest(strTestCaseID, strDesc);					
						iterationReport(iLoop-1,strTestCaseID+" Started");
						SignIn(strTeam, strMember);
						addorRemoveTheExpeditedPermissionFromRole(SheetName, iLoop);
						driver.manage().deleteAllCookies();						
						parent.appendChild(child);
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);

				}
				else if(strTestCaseID.contains("Error Message is displayed")){
					try {
						child = extent.startTest(strTestCaseID, strDesc);					
						iterationReport(iLoop-1,strTestCaseID+" Started");
						SignIn(strTeam, strMember);
						errorForExpeditedSOPLog(SheetName, iLoop);
						parent.appendChild(child);
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}
				else if(strTestCaseID.contains("Entity can be edited")){
					try {
						child = extent.startTest(strTestCaseID, strDesc);					
						iterationReport(iLoop-1,strTestCaseID+" Started");
						SignIn(strTeam, strMember);
						errorForExpeditedSOPLog(SheetName, iLoop);
						parent.appendChild(child);
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}					  
			}

		}
	}

	@Test/*(groups= {"newly"})*/
	//User edits SOP quicklog and adds to docket history
	public void addDocketHistory() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "AddDocketHistory");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AddDocketHistory";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					String esopId = submitESOPWithHardCopyRequiredOrNot(SheetName, iLoop);
					addDocketHistory(SheetName, iLoop, esopId);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	//Below test method is added as part of CES Enhancement REjection workflow
	//Commenting below test method as the test scenario is being covered in methodOfServiceAndTraceableMailFieldsRetainedInWorksheetPage
	//@Test
	public void cesPlaintiffAndDefendantFieldsRetainedInWorksheetPage() throws Throwable {	

		int currentTest = 0;
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CESAndPlaintiffData");
		//Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String [] esops = new String[totalTest];

		//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CESAndPlaintiffData");			
		for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			String testCaseID = Excelobject.getCellData("CESAndPlaintiffData", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("CESAndPlaintiffData", "Description", iLoop);
			String runStatus = Excelobject.getCellData("CESAndPlaintiffData", "RunStatus", iLoop);
			String member = Excelobject.getCellData("CESAndPlaintiffData", "Member", iLoop);
			String team = Excelobject.getCellData("CESAndPlaintiffData", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Plaintiff and Defendant fields")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);					
						String esopId = validatePlaintiffAndDefendantFieldsAreMandatory("CESAndPlaintiffData",iLoop);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;

						//workSheetContainsPlaintiffAndDefendantValuesAsESOP("CESAndPlaintiffData",iLoop,esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}
			}
		}


	}

	//Below method is added as part of CES enhancement Rejection workflow changes
	@Test/*(groups= {"newly"})*/
	public void methodOfServiceAndTraceableMailFieldsRetainedInWorksheetPage() throws Throwable {
		//--Modified SOPCreateWorksheet test data file
		int currentTest = 0;
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CESDataInWorksheet");
		//Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String [] esops = new String[totalTest];
		//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CESDataInWorksheet");			
		for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			String testCaseID = Excelobject.getCellData("CESDataInWorksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("CESDataInWorksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("CESDataInWorksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("CESDataInWorksheet", "Member", iLoop);
			String team = Excelobject.getCellData("CESDataInWorksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Escalated ESOP")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = esopEscalatedOrOnHold("CESDataInWorksheet",iLoop);							
						processEscalatedOrOnHoldESOP("CESDataInWorksheet",iLoop,esopId);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;
						//workSheetContainsPlaintiffAndDefendantValuesAsESOP("CESDataInWorksheet",iLoop,esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}
				else if (testCaseID.contains("On Hold ESOP")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = esopEscalatedOrOnHold("CESDataInWorksheet",iLoop);							
						processEscalatedOrOnHoldESOP("CESDataInWorksheet",iLoop,esopId);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;

						//workSheetContainsPlaintiffAndDefendantValuesAsESOP("CESDataInWorksheet",iLoop,esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}
				else if (testCaseID.contains("Plaintiff and Defendant fields")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);					
						String esopId = validatePlaintiffAndDefendantFieldsAreMandatory("CESDataInWorksheet",iLoop);
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;

						//workSheetContainsPlaintiffAndDefendantValuesAsESOP("CESAndPlaintiffData",iLoop,esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);
				}
			}
		}	
		validateCESDataInWorksheet(currentTest - 1,"CESDataInWorksheet",esops);
	}

	//Below test method is added as part CES Enhancement REjection

	@Test

	public void fieldsModificationDuringWorksheetCreation() throws Throwable {

		//--Modified SOPCreateWorksheet test data file
		int currentTest = 0;
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "FieldModificationInWorksheet");
		//Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String [] esops = new String[totalTest];

		/*String esopId = "22073989";
		String worksheetId = "538127202";*/
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "FieldModificationInWorksheet");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("FieldModificationInWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("FieldModificationInWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("FieldModificationInWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("FieldModificationInWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("FieldModificationInWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Complete")) {	
						try {

						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("FieldModificationInWorksheet", iLoop);
						//String esopId = "22050324";
						//Below two lines of code is added on 7/1/21
						esops[currentTest] = esopId;
						++currentTest;

						/*String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("FieldModificationInWorksheet", iLoop,esopId);*/
						//assignmentHistoryAndAudtitTrail(esopId,worksheetId);

						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
						e.printStackTrace();
						openBrowser();
					}
					driver.get(URL);
				}

			}
			//below should be uncommecnted
			validateCESDataModificationInWorksheet(currentTest - 1,"FieldModificationInWorksheet",esops);
	}
	}
	// below test method is added as part of Sp 49 for meta data in rejected log

	@Test(groups= {"newly"})
	public void rejectionLogMetaData() throws Throwable {

		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "RejectedLogMetaData");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("RejectedLogMetaData", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("RejectedLogMetaData", "Description", iLoop);
			String runStatus = Excelobject.getCellData("RejectedLogMetaData", "RunStatus", iLoop);
			String member = Excelobject.getCellData("RejectedLogMetaData", "Member", iLoop);
			String team = Excelobject.getCellData("RejectedLogMetaData", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Reject")) {	
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("RejectedLogMetaData", iLoop);
						metaDataInTheRejectedLog(esopId);					
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {
						e.printStackTrace();
					}
					driver.get(URL);

				}					
			}
		}
	}

	//below test method is added as part of NPD dev ops sprint 1
	@Test
	public void accleratedAndFullWorksheet() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "SOPWorkFlowAddedWorksheetsTab");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("SOPWorkFlowAddedWorksheetsTab", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("SOPWorkFlowAddedWorksheetsTab", "Description", iLoop);
				String runStatus = Excelobject.getCellData("SOPWorkFlowAddedWorksheetsTab", "RunStatus", iLoop);
				String member = Excelobject.getCellData("SOPWorkFlowAddedWorksheetsTab", "Member", iLoop);
				String team = Excelobject.getCellData("SOPWorkFlowAddedWorksheetsTab", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Search for the Log")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						worksheetInMyWorksheetsAndMyTeamWorksheet("SOPWorkFlowAddedWorksheetsTab",iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();

		}	
	}

	@Test
	public void permissionToEditTheTransmittalTypeValue() throws Throwable {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "TransmittalTypeEditPermission");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("TransmittalTypeEditPermission", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("TransmittalTypeEditPermission", "Description", iLoop);
			String runStatus = Excelobject.getCellData("TransmittalTypeEditPermission", "RunStatus", iLoop);
			String member = Excelobject.getCellData("TransmittalTypeEditPermission", "Member", iLoop);
			String team = Excelobject.getCellData("TransmittalTypeEditPermission", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Create a Role")) {	
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						createRoleForTransmittalType("TransmittalTypeEditPermission",iLoop);
						assignTheRoleToTheUser("TransmittalTypeEditPermission",iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {e.printStackTrace();}					
				}

				else if(testCaseID.contains("Edit the Transmittal Type value")) {

					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();				
						editTheTransmittalTypeInAff("TransmittalTypeEditPermission",iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {e.printStackTrace();}
				}

				else if(testCaseID.contains("Revoke the Grant")) {

					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						revokeTheGrantFromTheUser("TransmittalTypeEditPermission",iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {e.printStackTrace();}
				}	

				else if(testCaseID.contains("Delete the Role")) {

					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						deleteTheRole("TransmittalTypeEditPermission",iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {e.printStackTrace();}
				}

			}
			driver.get(URL);
		}	
	}


	@Test/*(groups= {"newly"})*/
	public void optimizedManualWorksheet() throws Throwable {

		Map<Integer,String> optimizedManualWorksheet = new HashMap<Integer,String>();
		int optimizedManualLogKey = 1;
		int currentTest = 0;		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "OptimizedManual Worksheet");

		//Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String [] esops = new String[totalTest];

		//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "OptimizedManual Worksheet");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("OptimizedManual Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("OptimizedManual Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("OptimizedManual Worksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("OptimizedManual Worksheet", "Member", iLoop);
			String team = Excelobject.getCellData("OptimizedManual Worksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Process a CES")) {	
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						String esopId = submitESOPWithHardCopyRequiredOrNot("OptimizedManual Worksheet",iLoop);					
						//Below two lines of code is added on 7/1/21					
						esops[currentTest] = esopId;
						++currentTest;	

						/*					String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("OptimizedManual Worksheet",iLoop,esopId);
					sopWorkflow("OptimizedManual Worksheet",iLoop,esopId);
					executeActionItem("OptimizedManual Worksheet",iLoop,esopId);					
					//executeActionItem("OptimizedManual Worksheet",iLoop,"");
					optimizedManualWorksheet.put(optimizedManualLogKey, worksheetId);*/
						optimizedManualLogKey++;
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {e.printStackTrace();}					
				}
				driver.get(URL);
			}
		}
		optimizedManualWorksheet = executeActionItemAfterWorksheetCreation(currentTest - 1,"OptimizedManual Worksheet",esops);        
		Excelobject.writeDataToExistingExcel(TestDataWorkBookSOPCreateWorksheet,optimizedManualLogKey - 1,"OptimizedManual Log",optimizedManualWorksheet);
	}


	@Test	
	public void optimizedWorksheet() throws Throwable {	

		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "Optimized Worksheet");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("Optimized Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Optimized Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Optimized Worksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Optimized Worksheet", "Member", iLoop);
			String team = Excelobject.getCellData("Optimized Worksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Process a CES")) {	
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						String esopId = submitESOPWithHardCopyRequiredOrNot("Optimized Worksheet",iLoop);
						//Below function needs to uncommented after Release 1.2 development work completed
						//to validate the sop workflow is geting updated successfully
						//sopWorkflow("Optimized Worksheet",iLoop,esopId);					
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {}					
				}
				driver.get(URL);
			}
		}

	}

	@Test/*(groups= {"newly"})*/
	public void fullWorksheet() throws Throwable {	

		Map<Integer,String> fullWorksheet = new HashMap<Integer,String>();
		int fullLogKey =1;

		int currentTest = 0;		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "Full Worksheet");

		//Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String [] esops = new String[totalTest];

		//inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "Full Worksheet");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("Full Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Full Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Full Worksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Full Worksheet", "Member", iLoop);
			String team = Excelobject.getCellData("Full Worksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Process a CES")) {	
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);				
						String esopId = submitESOPWithHardCopyRequiredOrNot("Full Worksheet",iLoop);
						//Below two lines of code is added on 7/1/21					
						esops[currentTest] = esopId;
						++currentTest;	


						/*String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("Full Worksheet",iLoop,esopId);
					sopWorkflow("Full Worksheet",iLoop,esopId);
					executeActionItem("Full Worksheet",iLoop,esopId);
					//executeActionItem("Full Worksheet",iLoop,"");
					fullWorksheet.put(fullLogKey, worksheetId);*/

						fullLogKey++;
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {}					
				}
				driver.get(URL);
			}
		}
		//below should be uncommented
		fullWorksheet = executeActionItemAfterWorksheetCreation(currentTest - 1,"Full Worksheet",esops);
		Excelobject.writeDataToExistingExcel(TestDataWorkBookSOPCreateWorksheet,fullLogKey - 1,"Full Log",fullWorksheet);
	}

	@Parameters({"sopHubUrl"})
	@Test/*(groups= {"newly"} ,dependsOnMethods = {"fullWorksheet"})*/
	public void validatefullWorksheetInSOPHub(String sopHubUrl) throws Throwable {		
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "Full Worksheet");	
			int rows = inputSheet.getPhysicalNumberOfRows();
			for(int iLoop =0 ; iLoop<= rows; iLoop++){			
				String testCaseID = Excelobject.getCellData("Full Worksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("Full Worksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("Full Worksheet", "RunStatus", iLoop);			
				String sopHubUser = Excelobject.getCellData("Full Worksheet", "User Name", iLoop);
				String sopHubUserPwd = Excelobject.getCellData("Full Worksheet", "Password", iLoop);
				String firstName = Excelobject.getCellData("Full Worksheet", "First Name", iLoop);
				String lastName = Excelobject.getCellData("Full Worksheet", "Last Name", iLoop);
				String customer = Excelobject.getCellData("Full Worksheet", "Customer", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");																		
						//below SOP Hub side validations
						driver.get(sopHubUrl);
						loginToSOPHubWithCustomer(sopHubUser,sopHubUserPwd,firstName,lastName,customer);
						worksheetInSOPHub("Full Worksheet",iLoop);
						logoutFromSopHub();	
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");					
					}
					//driver.get(URL);
				}
			}			
			Excelobject.removeDataFromColumn(TestDataWorkBookSOPCreateWorksheet,rows,"Full Log","");
		}catch(Exception e) {
			e.printStackTrace();}

	}

	@Parameters({"sopHubUrl"})
	@Test(/*groups= {"newly"},dependsOnMethods = {"optimizedManualWorksheet"}*/)
	public void validateOptimizedManualWorksheetInSOPHub(String sopHubUrl) throws Throwable {		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "OptimizedManual Worksheet");	
		int rows = inputSheet.getPhysicalNumberOfRows();
		for(int iLoop =0 ; iLoop<= rows; iLoop++){			
			String testCaseID = Excelobject.getCellData("OptimizedManual Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("OptimizedManual Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("OptimizedManual Worksheet", "RunStatus", iLoop);			
			String sopHubUser = Excelobject.getCellData("OptimizedManual Worksheet", "User Name", iLoop);
			String sopHubUserPwd = Excelobject.getCellData("OptimizedManual Worksheet", "Password", iLoop);
			String firstName = Excelobject.getCellData("OptimizedManual Worksheet", "First Name", iLoop);
			String lastName = Excelobject.getCellData("OptimizedManual Worksheet", "Last Name", iLoop);
			String customer = Excelobject.getCellData("OptimizedManual Worksheet", "Customer", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");																		
					//below SOP Hub side validations
					driver.get(sopHubUrl);
					loginToSOPHubWithCustomer(sopHubUser,sopHubUserPwd,firstName,lastName,customer);
					worksheetInSOPHub("OptimizedManual Worksheet",iLoop);
					logoutFromSopHub();					
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					//driver.get(sopHubUrl);
				//driver.get(URL);
				}
			}			
			Excelobject.removeDataFromColumn(TestDataWorkBookSOPCreateWorksheet,rows,"OptimizedManual Log","");
		}	}catch(Exception e) {
			e.printStackTrace();}

	}

	//Below scripts added as part of CIOX Arrow Enhancement Project
	//Verify no Create Worksheet link at Arrow Home Page for Level 1 user: CIA-88
	//Verify Create Worksheet left nav link remain disabled on landing sop module page for Level 1 user
	//Verify Create Worksheet left nav link  remains disabled on clicking any left nav links on sop page for level 1 user
	//Verify there is no Create Worksheet Button on My Worksheets Page for level 1 user
	//Verify there is no Create Worksheet Button on My Team's Worksheets Page for level 1 user
	//Verify Create Worksheet left nav link is only highlighted when user is on Create Worksheet Page for level 1 user
	@Test
	public void verifyCreateWorksheetLinksBtnForLevel1User() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CreateWorksheetLinkBtnLevel1");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateWorksheetLinkBtnLevel1";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet link at Arrow Home Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetLinkAtArrowHomePage("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remain disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetLeftNavLink("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remains disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetLeftNavLinkDisabled("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetBtnOnMyWorksheetsPg("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Teams's Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link only highlighted when user on Create Worksheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWorksheetNavLinkHighlightedLevel1("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no Create Worksheet link at Arrow Home Page for Level 2 user: CIA-88
	//Verify Create Worksheet left nav link remain disabled on landing sop module page for Level 2 user
	//Verify Create Worksheet left nav link  remains disabled on clicking any left nav links on sop page for level 2 user
	//Verify there is no Create Worksheet Button on My Worksheets Page for level 2 user
	//Verify there is no Create Worksheet Button on My Team's Worksheets Page for level 2 user
	//Verify Create Worksheet left nav link is only highlighted when user is on Create Worksheet Page for level 2 user
	@Test/*(groups= {"newly"})*/
	public void verifyCreateWorksheetLinksBtnForLevel2User() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CreateWorksheetLinkBtnLevel2");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateWorksheetLinkBtnLevel2";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet link at Arrow Home Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetLinkAtArrowHomePage("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remain disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetLeftNavLink("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remains disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetLeftNavLinkDisabled("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetBtnOnMyWorksheetsPg("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Teams's Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link only highlighted when user on Create Worksheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						String esopId = entitySectionDetailsOnProcessingCES("CreateWorksheetLinkBtnLevel2", iLoop);
						verifyCreateWorksheetNavLinkHighlighted("CreateWorksheetLinkBtnLevel2", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no Create Worksheet link at Arrow Home Page for Level 3 user: CIA-88
	//Verify Create Worksheet left nav link remain disabled on landing sop module page for Level 3 user
	//Verify Create Worksheet left nav link  remains disabled on clicking any left nav links on sop page for level 3 user
	//Verify there is no Create Worksheet Button on My Worksheets Page for level 3 user
	//Verify there is no Create Worksheet Button on My Team's Worksheets Page for level 3 user
	//Verify Create Worksheet left nav link is only highlighted when user is on Create Worksheet Page for level 3 user
	@Test/*(groups= {"newly"})*/
	public void verifyCreateWorksheetLinksBtnForLevel3User() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CreateWorksheetLinkBtnLevel3");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateWorksheetLinkBtnLevel3";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet link at Arrow Home Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetLinkAtArrowHomePage("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remain disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetLeftNavLink("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remains disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetLeftNavLinkDisabled("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetBtnOnMyWorksheetsPg("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Teams's Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link only highlighted when user on Create Worksheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CreateWorksheetLinkBtnLevel3", iLoop);
						verifyCreateWorksheetNavLinkHighlighted("CreateWorksheetLinkBtnLevel3", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify the updated court list on Create,CES,Edit,Review WorkSheet Page: CIA-1
	//Verify State of Court dropdown added and defaulted to Received Jurisdiction
	//Verify the court list is updated according to the state of court value
	@Test/*(groups= {"newly"})*/
	public void verifyUpdatedCourtListOnCreateCESEditReviewPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "CreateCESEditReviewUpdatedCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateCESEditReviewUpdatedCourt";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet court list field updated")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CreateCESEditReviewUpdatedCourt", iLoop);
						verifyUpdatedCourtListForCreateWorksheetPage("CreateCESEditReviewUpdatedCourt", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("CES court list field updated")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyUpdatedCourtListForCESPage("CreateCESEditReviewUpdatedCourt", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Edit Worksheet court list field updated")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyUpdatedCourtListForEditWorksheetPage("CreateCESEditReviewUpdatedCourt", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Review Worksheet court list field updated")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						verifyUpdatedCourtListForReviewWorksheetPage("CreateCESEditReviewUpdatedCourt", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify Worksheets having old court data reflects new court list on editing the worksheet: CIA-1
	@Test
	public void verifyWorksheetOldCourt() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "WorksheetOldCourtData");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "WorksheetOldCourtData";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Worksheet Court field Edited")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyExistingWorksheetWithOldCourt("WorksheetOldCourtData", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify if None specified radio button is selected in CES process then when user lands on create worksheet page
	//"Use an Existing court" radio button should be selected by default and state of court dropdown should have received juris value selected: CIA-1
	@Test
	public void verifyNoneSpecifiedCourt() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "NoneSpecifiedCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NoneSpecifiedCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NoneSpecifiedCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NoneSpecifiedCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NoneSpecifiedCourt", "Member", iLoop);
				String team = Excelobject.getCellData("NoneSpecifiedCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("None Specified radio button selected in CES")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyNoneSpecifiedCourt = verifyNoneSpecifiedCourtCES("NoneSpecifiedCourt", iLoop);
						System.out.println(VerifyNoneSpecifiedCourt);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify if Use this court radio button is selected in ces process then when user lands on create worksheet page
	//"Use this court" radio button should be selected by default and state of court dropdown should have received juris value selected: CIA-1
	@Test/*(groups= {"newly"})*/
	public void verifyUseThisCourt() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "UseThisCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("UseThisCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("UseThisCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("UseThisCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("UseThisCourt", "Member", iLoop);
				String team = Excelobject.getCellData("UseThisCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Use this Court radio button selected in CES")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyUseThisCourt = verifyUseThisCourtCES("UseThisCourt", iLoop);
						System.out.println(VerifyUseThisCourt);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify state of court  is defaulted to the Received Juris of the SOP when user lands on create worksheet page for level 2 user: CIA-1
	@Test
	public void verifyStateOfCourtForLevel2() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "StateOfCourtLevel2");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "StateOfCourtLevel2";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("State of Court defaulted to the Received Juris of the SOP")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyStateOfCourtForLevel2User("StateOfCourtLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify state of court  is defaulted to the Received Juris of the SOP when user lands on create worksheet page for level 1 user: CIA-1
	@Test
	public void verifyStateOfCourtForLevel1() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "StateOfCourtLevel1");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "StateOfCourtLevel1";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("State of Court defaulted to the Received Juris of the SOP")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyStateOfCourtForLevel1User("StateOfCourtLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify there is no Priority and Multiple Fields on Create Worksheet Page
	@Test/*(groups= {"newly"})*/
	public void verifyPriorityMultipleFieldsOnCreateWokPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyPriMulOnCreateWok");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriMulOnCreateWok";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Multiple Field Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyPriMulOnCreateWok", iLoop);
						verifyMultipleFieldOnCreateWorksheetPage("VerifyPriMulOnCreateWok", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Priority Field Verification")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyPriMulOnCreateWok", iLoop);
						verifyPriorityFieldOnCreateWorksheetPage("VerifyPriMulOnCreateWok", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify there is no Priority and Multiple Fields on Edit Worksheet Page of Newly Created Worksheets
	@Test
	public void verifyPriorityMultipleFieldsOnEditWokandProfPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyPriMulOnEditAndProfWok");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriMulOnEditAndProfWok";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Multiple Field Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyMultipleFieldOnEditandWorksheetProfilePage("VerifyPriMulOnEditAndProfWok", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Priority Field Verification")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFieldOnEditandWorksheetProfilePage("VerifyPriMulOnEditAndProfWok", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify there is confirmation number, customer and individual on Worksheet Popup Page for worksheet type DSSOP: CIA-47
	@Test
	public void verifyWorksheetPopUpPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyWorksheetPopUpPage");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyWorksheetPopUpPage", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyWorksheetPopUpPage", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyWorksheetPopUpPage", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyWorksheetPopUpPage", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyWorksheetPopUpPage", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Worksheet PopUp Page for Worksheet Type")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyWorksheetPopUpPageForWorksheetType("VerifyWorksheetPopUpPage", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no message related text available on all SOP Pages: CIA-48
	@Test/*(groups= {"newly"})*/
	public void verifyNoMsgTextDisplayOnSOPPages() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyNoMsgTextOnSOP");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyNoMsgTextOnSOP";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Top Message Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyMessageTextOnSOPPage("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("New Messages Left Nav Link Verification")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyNewMessagesLeftNavLink("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Worksheet Profile Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnWorksheetProfile("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Worksheet Create Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyNoMsgTextOnSOP", iLoop);
						verifySendMessageOnWorksheetCreate("VerifyNoMsgTextOnSOP", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Worksheet Edit Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnWorksheetEdit("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Top Message Verification on SOP List")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyMessageOnSOPList("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message Verification on Fedex Package Profile")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnFedexPackageProfile("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Choose DI Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnChooseDIPage("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Action Items Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnActionItemsPage("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify No Send Msg Btn on Worksheet Review Page: CIA-48
	@Test
	public void verifySendMsgOnWorksheetReview() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyNoSendMsgOnReview");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyNoSendMsgOnReview", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyNoSendMsgOnReview", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyNoSendMsgOnReview", "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("No Send Message On Worksheet Review Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						verifySendMessageOnWorksheetReview("VerifyNoSendMsgOnReview", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify when a related log is added to a ces item and user navigates to Create Worksheet Page 
	//then the Initial/Subsequent field is having "Subsequent" radio button as selected by default: CIA-49
	@Test/*(groups= {"newly"})*/
	public void verifyRelatedLogSubsequent() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyRelatedLogSubsequent");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyRelatedLogSubsequent", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyRelatedLogSubsequent", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyRelatedLogSubsequent", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyRelatedLogSubsequent", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyRelatedLogSubsequent", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Related Log Subsequent Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entityDetailsOnProcessingCESUploadImage("VerifyRelatedLogSubsequent", iLoop);
						verifyRelatedLogSubsequentByDefault("VerifyRelatedLogSubsequent", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify when user adds a log to docket history of an existing log 
	//then the Initial/Subsequent field of existing log should be changed to Subsequent on Worksheet Profile page & Edit Page: CIA-49
	@Test
	public void verifyExistingLogDocketHistory() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyExistingLogDocketHistory");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyExistingLogDocketHistory";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Log Docket History Verification On Worksheet Profile Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyExistingLogOnWorksheetProfilePage("VerifyExistingLogDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Existing Log Docket History Verification On Worksheet Edit Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyExistingLogOnWorksheetEditPage("VerifyExistingLogDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify no priority column, priority sorting, priority filter on My WorkSheets Page: CIA-46
	@Test
	public void verifyPriorityOnMyWorksheetsPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyPriorityOnMyWorksheets");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriorityOnMyWorksheets";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Priority Column on My Worksheets Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityColumnOnMyWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Sorting on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPrioritySortOnMyWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Filter on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFilterOnMyWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Column on My Teams Worksheets Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityColumnOnMyTeamsWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Sorting on My Teams Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPrioritySortOnMyTeamsWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Filter on My Teams Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFilterOnMyTeamsWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify there is no Priority field on Worksheet Popup Page: CIA-46
	//Verify there is no "Create Quicklog/attempted/rejection/multiple" button on Related Worksheet Search Page 
	//after clicking on Modify Docket History Button on Worksheet Profile Page
	@Test
	public void verifyPriorityFieldWorksheetPopUpPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "NoPriorityOnWorksheetPopUp");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "Member", iLoop);
				String team = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Priority Field  on Worksheet PopUp Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFieldOnWorksheetPopUpPage("NoPriorityOnWorksheetPopUp", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Create Quicklog/attempted/rejection/multiple button on Related Worksheet Search Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateQuicklogBtnOnRelatedWorksheetSearchPage("NoPriorityOnWorksheetPopUp", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no checkboxes and select all & select none btn on Worksheet Profile Page: CIA-46
	@Test
	public void verifyCheckboxesSelectBtnOnWorksheetProfile() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "NoCheckboxSelectBtnOnWSProfile");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "NoCheckboxSelectBtnOnWSProfile";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Checkboxes on Worksheet Profile")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCheckboxesOnWorksheetProfilePage("NoCheckboxSelectBtnOnWSProfile", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Select All and Select None Btn on Worksheet Profile")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySelectAllAndSelectNoneBtnOnWorksheetProfilePage("NoCheckboxSelectBtnOnWSProfile", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify no cloned/copied field on newly created Worksheet Profile Pg, Worksheet PopUp Pg: CIA-46
	//Verify no cloned/copied column on My Worksheets & My Teams Worksheets Page
	@Test/*(groups= {"newly"})*/
	public void verifyClonedCopiedOnWorksheetPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifyClonedCopiedOnWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyClonedCopiedOnWorksheet";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Cloned/Copied field on Worksheet Profile")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyClonedCopiedOnWorksheet", iLoop);
						verifyClonedCopiedFieldOnNewlyCreatedWorksheetProfilePage("VerifyClonedCopiedOnWorksheet", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied field on Worksheet PopUp")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedFieldOnWorksheetPopUpPage("VerifyClonedCopiedOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied column on My Worksheets grid")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedColumnOnMyWorksheets("VerifyClonedCopiedOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied column on My Teams Worksheets grid")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedColumnOnMyTeamsWorksheets("VerifyClonedCopiedOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify default sorting functionality on My worksheet & My teams worksheet pg. is Received Date : CIA-46
	//Verify sorting functionality on My worksheet & My teams worksheet pg. 
	@Test
	public void verifySortingandDefaultSortingOnWorksheetPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "VerifySortingDefaultOnWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifySortingDefaultOnWorksheet";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Default Sorting on My Worksheet Page is Received Date")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyDefaultSortingOnMyWorksheetPageIsReceivedDt("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of  Sorting Functionality on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySortingOnMyWorksheetPage("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Default Sorting on My Teams Worksheet Page is Received Date")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyDefaultSortingOnMyTeamsWorksheetPageIsReceivedDt("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of  Sorting Functionality on My Teams Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySortingOnMyTeamsWorksheetPage("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
	
	//Verify ML Slider is displayed with data on Create WorkSheet Page: Transmittal ML Slider
		@Test
		public void verifyMLSliderForWorksheetCreation() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "MLSliderWorksheetCreate");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "MLSliderWorksheetCreate";
					String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
					String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

					if(runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						//This will mark the beginning of row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Started");

						//This method will log into the Application
						SignIn(strTeam, strMember);

						//Test case 1: Verify ML Slider is displayed with data on Create Worksheet Page
						String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
						verifyMLSliderWithDataForWorksheetCreation(SheetName, iLoop, esopId);

						parent.appendChild(child);
						//This will mark end of the one row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}
				}catch (Exception e) {
					catchBlock(e);
				}
			}
		}

		//Verify ML Slider is displayed with data on Edit WorkSheet Page: Transmittal ML Slider
		@Test
		public void verifyMLSliderForWorksheetEdit() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "MLSliderWorksheetEdit");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "MLSliderWorksheetEdit";
					String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
					String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

					if(runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						//This will mark the beginning of row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Started");

						//This method will log into the Application
						SignIn(strTeam, strMember);

						//Test case 1: Verify ML Slider is displayed with data on Edit Worksheet Page
						verifyMLSliderWithDataForWorksheetEdit(SheetName, iLoop);

						parent.appendChild(child);
						//This will mark end of the one row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}
				}catch (Exception e) {
					catchBlock(e);
				}
			}
		}

		//Verify ML Slider is displayed with data on Review WorkSheet Page: Transmittal ML Slider
		@Test
		public void verifyMLSliderForWorksheetReview() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "MLSliderWorksheetReview");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "MLSliderWorksheetReview";
					String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
					String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

					if(runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						//This will mark the beginning of row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Started");

						//This method will log into the Application
						SignInFromSOPSupportTeam();

						//Test case 1: Verify ML Slider is displayed with data on Review Worksheet Page
						verifyMLSliderWithDataForWorksheetReview(SheetName, iLoop);

						parent.appendChild(child);
						//This will mark end of the one row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}
				}catch (Exception e) {
					catchBlock(e);
				}
			}
		}

		//Verify elements and draggable fields on Manage ML Slider Fields page: Transmittal ML Slider
		@Test
		public void verifyAdminMLSlider() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "AdminMLSlider");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "AdminMLSlider";
					String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
					String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

					if(runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						//This will mark the beginning of row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Started");

						//This method will log into the Application
						SignIn(strTeam, strMember);

						//Test case 1: Verify elements and draggable fields on Manage ML Slider Fields page
						verifyAdminMLSliderPage(SheetName, iLoop);

						parent.appendChild(child);
						//This will mark end of the one row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}
				}catch (Exception e) {
					catchBlock(e);
				}
			}
		}

		//Verify no QuickLog button is present  on Create WorkSheet Page: Retiring QuickLog
		@Test
		public void verifyNoQuicklogBtnOnCreateWorksheet() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "NoQuicklogOnCreateWorksheet");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "NoQuicklogOnCreateWorksheet";
					String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
					String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

					if(runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						//This will mark the beginning of row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Started");

						//This method will log into the Application
						SignIn(strTeam, strMember);

						//Test case 1: Verify no Quicklog button is present  on Create Worksheet Page
						String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
						verifyNoQuicklogOnCreateWorksheet(SheetName, iLoop, esopId);

						parent.appendChild(child);
						//This will mark end of the one row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}
				}catch (Exception e) {
					catchBlock(e);
				}
			}
		}

		//Verify if the status of existing worksheet is  Quicklog  
		//then on editing the worksheet no quicklog button should be present: Retiring QuickLog
		@Test
		public void verifyEditedQuicklogStatusWorksheet() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCreateWorksheet, "EditedQuicklogStatus");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "EditedQuicklogStatus";
					String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
					String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

					if(runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						//This will mark the beginning of row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Started");

						//This method will log into the Application
						SignIn(strTeam, strMember);

						//Test case 1: Verify if the status of existing worksheet is  Quicklog  
						//then on editing the worksheet no quicklog button should be present
						verifyEditedQuicklogWorksheet(SheetName, iLoop);

						parent.appendChild(child);
						//This will mark end of the one row in data sheet
						iterationReport(iLoop-1,strTestCaseID+" Completed");
					}
				}catch (Exception e) {
					catchBlock(e);
				}
			}
		}
		
		//Verify NOA for WorkSheet Create Page: NOA Cleanup
		@Test
		public void verifyNOAForWorksheetCreation() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAWorksheetCreate");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("NOAWorksheetCreate", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("NOAWorksheetCreate", "Description", iLoop);
					String runStatus = Excelobject.getCellData("NOAWorksheetCreate", "RunStatus", iLoop);
					String member = Excelobject.getCellData("NOAWorksheetCreate", "Member", iLoop);
					String team = Excelobject.getCellData("NOAWorksheetCreate", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Create Worksheet NOA field updated")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							String esopId = entitySectionDetailsOnProcessingCES("NOAWorksheetCreate", iLoop);
							String VerifyNOACreateWorksheet = verifyNOAWorksheetCreate("NOAWorksheetCreate", iLoop, esopId);
							System.out.println(VerifyNOACreateWorksheet);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Verify NOA for WorkSheet Edit Page: NOA Cleanup
		@Test
		public void verifyNOAForWorksheetEdit() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAWorksheetEdit");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "NOAWorksheetEdit";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						String VerifyNOAEditMyWorksheet = verifyNOAWorksheetEdit(SheetName, iLoop);
						System.out.println(VerifyNOAEditMyWorksheet);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}

		//Verify NOA for WorkSheet Review Page: NOA Cleanup
		@Test
		public void verifyNOAForWorksheetReview() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAWorksheetReview");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "NOAWorksheetReview";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignInFromSOPSupportTeam();

						String VerifyNOAReviewMyWorksheet = verifyNOAWorksheetReview(SheetName, iLoop);
						System.out.println(VerifyNOAReviewMyWorksheet);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}

		@Test
		public void verifyCreateWorksheetPage() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "VerifyCreateWorksheetPage");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("VerifyCreateWorksheetPage", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("VerifyCreateWorksheetPage", "Description", iLoop);
					String runStatus = Excelobject.getCellData("VerifyCreateWorksheetPage", "RunStatus", iLoop);
					String member = Excelobject.getCellData("VerifyCreateWorksheetPage", "Member", iLoop);
					String team = Excelobject.getCellData("VerifyCreateWorksheetPage", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Create Worksheet Page Verifcation")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							String esopId = entitySectionDetailsOnProcessingCES("VerifyCreateWorksheetPage", iLoop);
							verifyUIofCreateWorksheetPage("VerifyCreateWorksheetPage", iLoop, esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Validate Error Message for Create WorkSheet Page
		@Test/*(groups= {"newly"})*/
		public void createWorksheetErrMsg() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "CreateWorksheetErrMsg");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("CreateWorksheetErrMsg", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("CreateWorksheetErrMsg", "Description", iLoop);
					String runStatus = Excelobject.getCellData("CreateWorksheetErrMsg", "RunStatus", iLoop);
					String member = Excelobject.getCellData("CreateWorksheetErrMsg", "Member", iLoop);
					String team = Excelobject.getCellData("CreateWorksheetErrMsg", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Create Worksheet Error Msg Validation")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							String esopId = entitySectionDetailsOnProcessingCES("CreateWorksheetErrMsg", iLoop);
							validateErrMsgofCreateWorksheetPage("CreateWorksheetErrMsg", iLoop, esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Validate Error Message for Edit WorkSheet Page
		@Test/*(groups= {"newly"})*/
		public void editWorksheetErrMsg() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "EditWorksheetErrMsg");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("EditWorksheetErrMsg", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("EditWorksheetErrMsg", "Description", iLoop);
					String runStatus = Excelobject.getCellData("EditWorksheetErrMsg", "RunStatus", iLoop);
					String member = Excelobject.getCellData("EditWorksheetErrMsg", "Member", iLoop);
					String team = Excelobject.getCellData("EditWorksheetErrMsg", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Edit Worksheet Error Msg Validation")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							validateErrMsgofEditWorksheetPage("EditWorksheetErrMsg", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Validate Error Message for Review WorkSheet Page
		@Test/*(groups= {"newly"})*/
		public void reviewWorksheetErrMsg() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "ReviewWorksheetErrMsg");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("ReviewWorksheetErrMsg", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("ReviewWorksheetErrMsg", "Description", iLoop);
					String runStatus = Excelobject.getCellData("ReviewWorksheetErrMsg", "RunStatus", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Review Worksheet Error Msg Validation")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignInFromSOPSupportTeam();
							validateErrMsgofReviewWorksheetPage("ReviewWorksheetErrMsg", iLoop);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Verify NOA for Existing WorkSheet: NOA Cleanup
		@Test
		public void verifyNOAForExistingWorksheet() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAExistingWorksheet");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("NOAExistingWorksheet", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("NOAExistingWorksheet", "Description", iLoop);
					String runStatus = Excelobject.getCellData("NOAExistingWorksheet", "RunStatus", iLoop);
					String member = Excelobject.getCellData("NOAExistingWorksheet", "Member", iLoop);
					String team = Excelobject.getCellData("NOAExistingWorksheet", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Existing Worksheet NOA field updated")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							String VerifyNOAExistingWorksheet = verifyNOAExistingWorksheet("NOAExistingWorksheet", iLoop);
							System.out.println(VerifyNOAExistingWorksheet);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Verify NOA for Existing WorkSheet when Edited & Saved: NOA Cleanup
		@Test/*(groups= {"newly"})*/
		public void verifyNOAForExistingWorksheetEditedSaved() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAExistingWorksheetEditedSaved");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "Description", iLoop);
					String runStatus = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "RunStatus", iLoop);
					String member = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "Member", iLoop);
					String team = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Existing Worksheet NOA field Edited and Saved")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							String VerifyNOAExistingWorksheetEditedSaved = verifyNOAExistingWorksheetEditedSaved("NOAExistingWorksheetEditedSaved", iLoop);
							System.out.println(VerifyNOAExistingWorksheetEditedSaved);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}

		//Verify NOA for Existing WorkSheet when Reviewed & Saved: NOA Cleanup
		@Test
		public void verifyNOAForExistingWorksheetReviewedSaved() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAExistingWSReviewedSaved");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("NOAExistingWSReviewedSaved", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("NOAExistingWSReviewedSaved", "Description", iLoop);
					String runStatus = Excelobject.getCellData("NOAExistingWSReviewedSaved", "RunStatus", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Existing Worksheet NOA field Reviewed and Saved")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignInFromSOPSupportTeam();
							verifyNOAExistingWorksheetReviewedSaved("NOAExistingWSReviewedSaved", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}
}
