package com.arrow.sop.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_SOP_AutoUpload;

public class AutoUpload extends BusinessFunctions_SOP_AutoUpload{
	
	
	@Test
	// Verify user is able to view Error Message, In Process Queue and Pending Upload tabs in Auto Upload
	public void autoUpload() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPAutoUpload, "AutoUpload");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AutoUpload";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This will verify auto upload tab's in SOP
					autoUpload(SheetName, iLoop);


					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	

}
