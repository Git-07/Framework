package com.arrow.sop.scripts;

import com.arrow.workflows.BusinessFunctions_SOP_ActionItem;

import org.testng.annotations.Test;

public class ActionItem extends BusinessFunctions_SOP_ActionItem {

	// Verify Edit and Delete buttons are available for unexecuted Action Items.
	@Test
	public void editAndDeleteActionItems() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "EditDeleteActionItem");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EditDeleteActionItem";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					editAndDeleteActionItems(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User verifies delete btn is not available when only one unexecute Action Item
	// for dlvrble SOP Pprs wit Transmittal & deli methd is othr thn Fax & ISOP
	@Test/*(groups= {"newly"})*/
	public void noDeleteButton() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "NoDeleteButton");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "NoDeleteButton";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					noDeleteButton(SheetName, iLoop, esopId);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User verifies recipient information is not available for delivery method
	// ISOP.
	@Test
	public void NoRecipientInfoForISOP() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "NoRecipientInfo");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "NoRecipientInfo";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					noRecipientInfoForISOP(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User verifies Transmittal in Action items
	@Test
	public void viewTransmittal() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "ViewTrasmittal");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ViewTrasmittal";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);
					// This method will view Transmittal
					viewTransmittal(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// User verifies ISOP in Action items
	@Test
	public void ISOPActionItems() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "ISOPExecuteButton");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ISOPExecuteButton";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);
					// This method will execute ISOP present in action Items
					executeISOP(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// User verifies my Action items
	@Test
	public void myActionItems() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "myActionItems");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "myActionItems";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);
					// This method will execute ISOP present in action Items
					myActionItems(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// User verifies my Teams Action items
	@Test
	public void myTeamsActionItems() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "MyTeamsActionItem");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "MyTeamsActionItem";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);
					// This method will execute ISOP present in action Items
					myTeamsActionItem(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// User verifies my Teams Action items
		@Test/*(groups= {"newly"})*/
		public void executeEmailSOP() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "ExecuteEmailSOP");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "ExecuteEmailSOP";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);
						
						String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
						// This method will execute ISOP present in action Items
						executeEmailSOP(SheetName, iLoop, esopId);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		
  	    //Below test method is added as part of Bulk retimrent project
		
		@Test
		public void actioItemFailureUI() throws Throwable {
			
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookActionItem_SOP, "ActionItemFailureUI");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				
					String testCaseID = Excelobject.getCellData("ActionItemFailureUI", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("ActionItemFailureUI", "Description", iLoop);
					String runStatus = Excelobject.getCellData("ActionItemFailureUI", "RunStatus", iLoop);
					String member = Excelobject.getCellData("ActionItemFailureUI", "Member", iLoop);
					String team = Excelobject.getCellData("ActionItemFailureUI", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Action Items Failure UI")) {
							try {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);						
							actionItemFailuresUI();			
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							} catch (Exception e) {
								e.printStackTrace();
							}
						}					
					}
				}

		}


	

}
