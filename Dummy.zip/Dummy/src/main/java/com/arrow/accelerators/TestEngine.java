package com.arrow.accelerators;       

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import com.arrow.support.ConfiguratorSupport;
import com.arrow.support.HtmlReportSupport;
import com.arrow.support.MyListener;
import com.arrow.support.ReportStampSupport;
import com.arrow.util.SendMail;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;



public class TestEngine extends SendMail {

	public static Logger logger = Logger.getLogger(TestEngine.class.getName());

	public static ConfiguratorSupport configProps = new ConfiguratorSupport("config.properties");
	public static ExtentReports extent;
	public ExtentTest parent;
	public ExtentTest child;
	public  String environment= configProps.getProperty("Environment");
	public static ConfiguratorSupport counterProp = new ConfiguratorSupport(configProps.getProperty("counterPath"));
	public static String ParallelExec;
	public static int iStepNo = 0; 
	public String currentSuite = "";
	public String method = "";
	public boolean flag = false;
	public WebDriver webDriver = null;
	public EventFiringWebDriver driver=null;
	public DesiredCapabilities capabilities;
	public  int stepNum = 0;
	public  int PassNum =0;
	public  int FailNum =0;
	public  int RowFailNum =0;
	public  String testName = "";
	public String testCaseExecutionTime = "";
	public StringBuffer x=new StringBuffer();
	public String finalTime = "";
	public boolean isSuiteRunning=false;
	public static Map<String, String> testDescription = new LinkedHashMap<String, String>();
	public static Map<String, String> testResults = new LinkedHashMap<String, String>();
	//below commented part is the part of original code
	//public  String URL= configProps.getProperty("Arrow_URL");
	public  String URL = "";
	public  String FilePath=System.getProperty("user.dir")+File.separator+"TestData\\FileUploads\\R42800_CLS0010_633154_PDF.pdf";
	public int countcompare = 0;
	public String browsertype ;
	static int len = 0;
	static int i = 0;
	public  ITestContext itc;
	public String groupNames =null;
	public int failCount=0;
	public int passCount=0;
	public static File zip=new File("");
	public Map<Integer, Object[]> data = new LinkedHashMap<Integer, Object[]>();
	private static int h=1;
	
	/**
	 * Initializing browser requirements, Test Results file path and Database
	 * requirements from the configuration file
	 * 
	 * @Date 19/02/2013
	 * @Revision History
	 * 
	 */
	 //below code is the original code
	@Parameters({"parallel"})
	@BeforeSuite(alwaysRun=true)
	public void suiteFirst(ITestContext ctx,String parallel) throws Throwable{
		itc=ctx;
		
		ParallelExec=parallel;
		
		//TestEngine.cleanUP();
		ReportStampSupport.calculateSuiteStartTime();
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy hh mm ss SSS");
		String formattedDate = sdf.format(date);
		suiteStartTime = formattedDate.replace(":","_").replace(" ","_");
		
		new File("Results/HTML"+suiteStartTime+"/Screenshots").mkdirs();
		
		HtmlReportSupport.copyLogos();

	} 
	
	@Parameters({"browser"})
	@BeforeTest(alwaysRun=true)
	public void first(ITestContext ctx,String browser) throws Throwable{
		itc=ctx;
		extent=new ExtentReports(System.getProperty("user.dir")+"\\Reports\\ExecutionResults.html",false);
		extent.loadConfig(new File(System.getProperty("user.dir")+"\\config.xml"));
//		if (new File(System.getProperty("user.dir")+"\\Reports\\Screenshots").exists())
//			FileUtils.deleteDirectory(new File(System.getProperty("user.dir")+"\\Reports\\Screenshots")); // Delete ScreenShots folder
		extent.addSystemInfo("Environment", environment);
		extent.addSystemInfo("Browser", browser);
	}


	@Parameters({"browser"})
	@BeforeClass(alwaysRun=true)
	public void firstBeforeClass(ITestContext ctx,String browser) throws Throwable{
		browsertype=browser;
		itc=ctx;
		
	}


	
	@AfterTest(alwaysRun=true)
	public void first1(ITestContext ctx) throws Throwable{
		itc=ctx;
		extent.close();		
		HtmlReportSupport.createHtmlSummaryReport(browsertype, URL);
		ReportStampSupport.calculateSuiteExecutionTime();
		closeSummaryReport(browsertype);
	}

	
	@AfterSuite(alwaysRun = true)
	public void tearDownFirefox(ITestContext ctx) throws Throwable {
		
		WriteExcelfile();
		//File destFile= new File("Results/SummaryFiles");
		File source = new File("Results/HTML"+suiteStartTime+"/SummaryResults_IE.xls");
	    File dest = new File("Results/SummaryFiles/"+suiteStartTime+"-"+"_SummaryResults_IE.xls");
	    /*if (!destFile.exists()) {
	    	destFile.mkdir();
		}*/
	    FileUtils.copyFile(source, dest);
	    
	    

		//SendMail.attachReportsToEmail("Results/HTML"+suiteStartTime+"/SummaryResults_IE.xls");
		
		
		//SendMail.attachReportsToEmail("Results/HTML"+suiteStartTime);// if need to send entire folder

	}

	public static void cleanUP() throws IOException {

		FileUtils.deleteDirectory(new File("Results/HTML"));
		new File("Results/HTML/Screenshots").mkdirs();
		HtmlReportSupport.copyLogos();

	}

//For below code added new Parameter URL
	@Parameters({"ip"})
	@BeforeMethod(alwaysRun = true)
	public void reportHeader(Method method, ITestContext ctx,String ip) throws Throwable {
		itc = ctx;
		
		parent=extent.startTest(method.getName());
		//***Below Parameter URL is added and assigned it to ip ***//
		URL = ip;
		DesiredCapabilities dr=null;
		if(ParallelExec.equalsIgnoreCase("YES")){
		if(browsertype.equalsIgnoreCase("firefox"))
			{
				dr=DesiredCapabilities.firefox();
				dr.setBrowserName(browsertype);
				dr.setPlatform(Platform.WINDOWS);
			}
			else if(browsertype.equalsIgnoreCase("ie"))
			{
				dr=DesiredCapabilities.internetExplorer();
				dr.setBrowserName("internet explorer");
				dr.setPlatform(Platform.WINDOWS);
			}
			else if(browsertype.equalsIgnoreCase("chrome"))
			{
				dr=DesiredCapabilities.chrome();
				dr.setBrowserName(browsertype);
				dr.setPlatform(Platform.WINDOWS);
			}
			
			webDriver=new RemoteWebDriver(new  URL("http://localhost:4444/wd/hub"), dr);
			 
		 }else if(ParallelExec.equalsIgnoreCase("NO")){
			 
			 
			if(browsertype.equalsIgnoreCase("firefox"))
			{
				webDriver = new FirefoxDriver();
				i=i+1;
			}
			else if(browsertype.equalsIgnoreCase("ie"))
			{
				File file = new File("Drivers/IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
				cap.setCapability("nativeEvents", false);
				cap.setCapability("unexpectedAlertBehaviour", "accept");
				cap.setCapability("ignoreProtectedModeSettings", true);
				cap.setCapability("disable-popup-blocking", true);
				cap.setCapability("enablePersistentHover", true);
				cap.setCapability("ignoreZoomSetting", true);
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				cap.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "");
				cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
				webDriver= new InternetExplorerDriver(cap);
				i=i+1;
			}
			else if(browsertype.equalsIgnoreCase("chrome"))
			{
				File file = new File("Drivers/chromedriver.exe");
				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());  
				ChromeOptions options=new ChromeOptions();
				//[11/1/2019]no-sandbox included as Chrome was crashing on launch
				options.addArguments("--test-type, --no-sandbox");				
				webDriver=new ChromeDriver(options);
				webDriver.manage().window().maximize();				
				i=i+1;				
			}
			
		}
		
		driver = new EventFiringWebDriver(webDriver);
		System.out.println("url opened"+URL);
		MyListener myListener = new MyListener();
		driver.register(myListener);

		try {

			if(browsertype.equalsIgnoreCase("IE")){
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			}
			else{
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			}

			if(browsertype.equalsIgnoreCase("Firefox") || browsertype.equalsIgnoreCase("IE") || browsertype.equalsIgnoreCase("Chrome"))
			{
				driver.manage().window().maximize();
			}
				
			
			driver.get(URL);
			currentSuit = ctx.getCurrentXmlTest().getSuite().getName();
		} catch (Exception e1) {
			System.out.println(e1);
		}

		calculateTestCaseStartTime();

		flag = false;
		tc_name = method.getName().toString() + "-" + browsertype;
		String[] ts_Name = this.getClass().getName().toString().split("\\.");
		packageName = ts_Name[0] + "." + ts_Name[1] + "."+ ts_Name[2];
	
        testHeader(tc_name);
        
		stepNum = 0;
		PassNum = 0;
		FailNum = 0;
		testName = method.getName();
		String[] tmp=testName.split("_");
		String desc = testName.replaceAll("_", " ")+" Script";
		testDescription.put(testName+ "-" + browsertype, desc);
		
	}

	
	@AfterMethod(alwaysRun = true)
	public void tearDown()
	{		
	
		extent.endTest(parent);	
        extent.flush();
		calculateTestCaseExecutionTime();
		closeDetailedReport(browsertype);
		System.out.println("browser :"+strTestName);
		String[] test=strTestName.split("-");
		int stringlength=test.length;
		String currentBrwoser=test[1];
		       		
		if(FailNum!=0)
		{	
			
			testResults.put(tc_name, "FAIL");
			System.out.println("current Browser:"+currentBrwoser);
			failCount++;
		}

		else if(PassNum!=0)
		{

			testResults.put(tc_name, "PASS");			
			passCount++;
		}

		try{
		
			driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	
	@AfterClass(alwaysRun=true)
	public void close(){

	}


	public void calculateTestCaseStartTime(){			
		iStartTime = System.currentTimeMillis();
	}


	/***
	 * 		This method is supposed to be used in the @AfterMethod to calculate the total test case execution time 
	 * to show in Reports by taking the start time from the calculateTestCaseStartTime method.
	 */
	public void calculateTestCaseExecutionTime(){	
		iEndTime = System.currentTimeMillis();
		iExecutionTime=(iEndTime-iStartTime);
		TimeUnit.MILLISECONDS.toSeconds(iExecutionTime);
		HtmlReportSupport.executionTime.put(tc_name,String.valueOf(TimeUnit.MILLISECONDS.toSeconds(iExecutionTime)));
	}


	public void onSuccess(String strStepName, String strStepDes) {


		strTestName=strTestName.replaceAll("_", " ");	
		String status = "PASS";
		File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName+"_Results"
				+ ".html");// "SummaryReport.html"
		Writer writer = null;
		stepNum = stepNum + 1;

		try {
			//testdescrption.put(TestTitleDetails.x.toString(), TestEngine.testDescription.get(TestTitleDetails.x));
			if (!map.get(packageName + ":" + tc_name).equals("FAIL")) {
				map.put(packageName + ":" + tc_name, "PASS");
				//map.put(TestTitleDetails.x.toString(), TestEngine.testDescription.get(TestTitleDetails.x.toString()));
			}
			writer = new FileWriter(file, true);
			writer.write("<tr class='content2' >");
			writer.write("<td>" + stepNum + "</td> ");
			writer.write("<td class='justified'>" + strStepName + "</td>");
			writer.write("<td class='justified'>" + strStepDes + "</td> ");
			writer.write("<td class='Pass' align='center'><img  src='./Screenshots/passed.ico' width='18' height='18'/></td> ");
			//writer.write("<td>" + status + "</td> ");
			
			//writer.write("<td> <font color='#008000'><b>" + status + "<b></font></td>");
			
			PassNum  =PassNum + 1;
			cmdEndTime=System.currentTimeMillis();
        	cmdTime=cmdEndTime-cmdStartTime;
        	int time=(int) TimeUnit.MILLISECONDS.toSeconds(cmdTime);
        	if(time==0)
        		time=1;
			writer.write("<td><small>" + time +" Sec "+ "</small></td> ");
			writer.write("</tr> ");
			writer.close();

		}catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void onWarning(String strStepName, String strStepDes) {
		Writer writer = null;
		String status = "Warning/Failed";
		try {
			//String fileName= strTestName;
			strTestName=strTestName.replaceAll("_", " ");	

			File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName+"_Results"
					+ ".html");// "SummaryReport.html"

			writer = new FileWriter(file, true);
			stepNum = stepNum + 1;

			writer.write("<tr class='content2' >");
			writer.write("<td>" + stepNum + "</td> ");
			writer.write("<td class='justified'>" + strStepName + "</td>");
			writer.write("<td class='justified'>" + strStepDes + "</td> ");
			FailNum = FailNum + 1;


			/*writer.write("<td class='Fail'  align='center'><a  href='"+"./Screenshots"+"/"
					+ strStepDes.replaceAll("[^\\w]", "_")
					+ ".jpeg'"+" alt= Screenshot  width= 15 height=15 style='text-decoration:none;'><img src='./Screenshots/warning.ico' width='18' height='18'/></a></td>");*/
			writer.write("<td>" + status + "</td> ");
			cmdEndTime=System.currentTimeMillis();
        	cmdTime=cmdEndTime-cmdStartTime;
        	int time=(int) TimeUnit.MILLISECONDS.toSeconds(cmdTime);
        	if(time==0)
        		time=1;
			writer.write("<td><small>" + time +" Sec "+ "</small></td> ");
			writer.write("</tr> ");
			writer.close();

		} catch (Exception e) {

		}

	}


	/*
	 * 
	 * 
	 */
	public void onFailure(String strStepName, String strStepDes, String stepExecTime) {
		Writer writer = null;
		try {
			//String fileName= strTestName;
			String status = "FAIL";
			strTestName=strTestName.replaceAll("_", " ");			
			File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName+"_Results"
					+ ".html");// "SummaryReport.html"

			writer = new FileWriter(file, true);
			stepNum = stepNum + 1;

			writer.write("<tr class='content2' >");
			writer.write("<td>" + stepNum + "</td> ");
			writer.write("<td class='justified'>" + strStepName + "</td>");
			writer.write("<td class='justified'>" + strStepDes + "</td> ");
			FailNum = FailNum + 1;
			RowFailNum=RowFailNum+1;


			writer.write("<td class='Fail' align='center'><a  href='"+"./Screenshots"+"/"+ strStepDes.replaceAll("[^\\w]", "_")
					+ stepExecTime +".jpeg'"+" alt= Screenshot  width= 15 height=15 style='text-decoration:none;'><img  src='./Screenshots/failed.ico' width='18' height='18'/></a></td>");
			//writer.write("<td>" + status + "</td> ");
			//writer.write("<td> <font color='#FF0000'> <b>" + status + "<b> </font></td>");
			cmdEndTime=System.currentTimeMillis();
        	cmdTime=cmdEndTime-cmdStartTime;
        	int time=(int) TimeUnit.MILLISECONDS.toSeconds(cmdTime);
        	if(time==0)
        		time=1;
			writer.write("<td><small>" + time +" Sec "+ "</small></td> ");
			writer.write("</tr> ");
			writer.close();
			if (!map.get(packageName + ":" + tc_name).equals("PASS")) {
				map.put(packageName + ":" + tc_name+":", "FAIL");
				//map.put(TestTitleDetails.x.toString(), TestEngine.testDescription.get(TestTitleDetails.x.toString()));
			}
		} catch (Exception e) {

		}

	}

	public void closeDetailedReport(String browser) {

		//String fileName= strTestName;
		strTestName=strTestName.replaceAll("_", " ");	
		File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName+"_Results"
				+ ".html");// "SummaryReport.html"
		Writer writer = null;

		try {
			writer = new FileWriter(file, true);
			writer.write("</table>");
			writer.write("<table id='footer'>");
			writer.write("<colgroup>");
			writer.write("<col style='width: 25%' />");
			writer.write("<col style='width: 25%' />");
			writer.write("<col style='width: 25%' />");
			writer.write("<col style='width: 25%' />");
			writer.write("</colgroup>");
			writer.write("<tfoot>");
			writer.write("<tr class='heading'> ");
			writer.write("<th colspan='4'>Execution Time In Seconds (Includes Report Creation Time) : "
					+ executionTime.get(tc_name)+ "&nbsp;</th> ");
			writer.write("</tr> ");
			writer.write("<tr class='content'>");
			writer.write("<td class='pass'>&nbsp;Steps Passed&nbsp;:</td>");
			writer.write("<td class='pass'> " + PassNum
					+ "</td>");
			writer.write("<td class='fail'>&nbsp;Steps Failed&nbsp;: </td>");
			writer.write("<td class='fail'>" + FailNum
					+ "</td>");
			writer.write("</tr>");
			writer.close();			

		} catch (Exception e) {

		}
	}

	public void closeSummaryReport(String browser) {	
		File file = new File("Results/HTML"+suiteStartTime+"/SummaryResults_"+browser+".html");// "SummaryReport.html"
		Writer writer = null;
		try {
			writer = new FileWriter(file, true);

			writer.write("<table id='footer'>");
			writer.write("<colgroup>");
			writer.write("<col style='width: 25%' />");
			writer.write("<col style='width: 25%' />");
			writer.write("<col style='width: 25%' />");
			writer.write("<col style='width: 25%' /> ");
			writer.write("</colgroup> ");
			writer.write("<tfoot>");
			writer.write("<tr class='heading'>");
			writer.write("<th colspan='4'>Total Duration  In Minutes (Including Report Creation) : "
					+ (iSuiteExecutionTime) + "</th>");
			writer.write("</tr>");
			writer.write("<tr class='content'>");
			writer.write("<td class='pass'>&nbsp;Tests Passed&nbsp;:</td>");
			writer.write("<td class='pass'> " + passCount
					+ "</td> ");
			writer.write("<td class='fail'>&nbsp;Tests Failed&nbsp;:</td>");
			writer.write("<td class='fail'> " + failCount
					+ "</td> ");
			writer.write("</tr>");
			writer.write("</tfoot>");
			writer.write("</table> ");
			writer.close();
			
		} catch (Exception e) {

		}
	}

public void WriteExcelfile() throws IOException {
		
	  HSSFWorkbook workbook = new HSSFWorkbook();
	
	  File dir=new File("Results/HTML"+suiteStartTime);
	  int sheetno = 0;
	  int c = 0;
	  File[] directoryListing = dir.listFiles();
	  if (directoryListing != null) {
	    for (File child : directoryListing) {
	        if(child.getName().endsWith("html"))
	        {
	        System.out.println(child.getName());
	        
	        System.out.println("Entire File Path:"+child.getAbsolutePath());  
	        	sheetno++;
	        	Document html = Jsoup.parse(FileUtils.readFileToString(new File(child.getAbsolutePath())));
	    		
	    		Elements elements = html.body().getElementById("main").getElementsByTag("tr");
	    		
	    		                                      
	    		setTrElements(elements.get(0), new Object[elements.get(0).getElementsByTag("th").size() + 1]);                                  
	    		
	    		for (Element Elemen : elements) {
	    			   
	    			//setTrElements(Elemen, new Object[Elemen.getElementsByTag("th").size() + 1]);// check this place to remove extra line from excel
	    			setElements(Elemen,	new Object[Elemen.getElementsByTag("td").size() ]);
	    		}
	        	
	        	HSSFSheet sheet = workbook.createSheet(child.getName().replace(".html", ""));

	        	Set<Integer> keyset = data.keySet();
	        	
	      
	    		
	    		int rownum = 0;
	    		for (Integer key : keyset) {
	    			Row row = sheet.createRow(rownum++);
	    			Object[] objArr = data.get(key);
	    			int cellnum = 0;
	    			for (Object obj : objArr) {
	    				Cell cell = row.createCell(cellnum++);
	    				if (obj instanceof Date)
	    					cell.setCellValue((Date) obj);
	    				else if (obj instanceof Boolean)
	    					cell.setCellValue((Boolean) obj);
	    				else if (obj instanceof String)
	    					cell.setCellValue((String) obj);
	    				else if (obj instanceof Double)
	    					cell.setCellValue((Double) obj);
	    			
	    				sheet.autoSizeColumn(cellnum);
	    			}
	    		}
	    		
	    		try {
	    			FileOutputStream out = new FileOutputStream(new File("Results/HTML"+suiteStartTime+"/SummaryResults_IE.xls"));
	    				
	    			workbook.write(out);
	    			out.close();
	    			System.out.println("Excel written successfully..");

	    		} catch (FileNotFoundException e) {
	    			e.printStackTrace();
	    		} catch (IOException e) {
	    			e.printStackTrace();
	    		}
	    		for(int i = 0; i<rownum;i++)
	    		{
	    		Object key = data.keySet().iterator().next();
	    		data.remove(key);
	    		}
	        }
	    	else
	        {
	        }
	    
	    }
	  } 
	  else {
	   	  }
		
	  
	}
	

	private void setTrElements(Element es, Object[] m) {

		int y = 0;
		for (Element k : es.getElementsByTag("th")) {
			m[y++] = Jsoup.parse(k.childNodes().get(0).toString()).text();
		}

		data.put(h, m);
		h++;
	}

	private void setElements(Element es, Object[] m) {
		int y = 0;
		for (Element k : es.getElementsByTag("td")) {
			m[y++] = Jsoup.parse(k.childNodes().get(0).toString()).text();
		}

		data.put(h, m);
		h++;
	}
	/*public static void SendSimpleMessage() {
	    HttpClient client = new Client(); 
	    
	    client.addFilter(new HTTPBasicAuthFilter("api","key-3146ad1438f23839acf67735c2acade0"));
	    WebResource webResource =
	        client.resource("https://api.mailgun.net/v3/sandbox64f3e1f8fdcb4530850fd11f3cce01e8.mailgun.org/messages");
	    MultivaluedMapImpl formData = new MultivaluedMapImpl();
	    formData.add("from", "Mailgun Sandbox <postmaster@sandbox64f3e1f8fdcb4530850fd11f3cce01e8.mailgun.org>");
	    formData.add("to", "rajesh <rajesh.nadella@gmail.com>");
	    formData.add("subject", "Hello rajesh");
	    formData.add("text", "Congratulations rajesh, you just sent an email with Mailgun!  You are truly awesome!  You can see a record of this email in your logs: https://mailgun.com/cp/log .  You can send up to 300 emails/day from this sandbox server.  Next, you should add your own domain so you can send 10,000 emails/month for free.");
	    return webResource.type(MediaType.APPLICATION_FORM_URLENCODED).
	                                                post(ClientResponse.class, formData);
	}*/
	    
	public  void iterationReport(int iLoop,String strStatus) throws Throwable{

		
		File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName + "_Results"
				+ ".html");
		Writer writer = null;

		try {
			iStepNo = 0;
			writer = new FileWriter(file, true);
			writer.write("<tr class='content2'>");
			if(strStatus.contains("Started"))
			{
				writer.write("<td colspan='2' height='25' ><b> Test Case "+iLoop+"</b></td>");
				writer.write("<td colspan='4' height='25' ><b> "+strStatus+"</b></td>");
			}
			else if(strStatus.contains("Completed"))
			{
				writer.write("<td colspan='2' height='25' ><b>  Test Case "+iLoop+" </b></td>");
				writer.write("<td colspan='4' height='25' ><b> "+strStatus+"</b></td>");
			}
			
			writer.write("</tr> ");
			writer.close();
			}catch (Exception e) {
			e.printStackTrace();
		}

	}	
	
	public void openBrowser(){
		
		
		if(browsertype.equalsIgnoreCase("firefox"))
		{
			webDriver = new FirefoxDriver();
			i=i+1;
		}
		else if(browsertype.equalsIgnoreCase("ie"))
		{
			File file = new File("Drivers/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			webDriver= new InternetExplorerDriver();
			i=i+1;
				
		}
		else if(browsertype.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");				
			webDriver=new ChromeDriver();
			i=i+1;

		}

		driver = new EventFiringWebDriver(webDriver);
		System.out.println("url opened"+URL);
		MyListener myListener = new MyListener();
		driver.register(myListener);

		try {

			if(browsertype.equalsIgnoreCase("IE")){
				driver.manage().timeouts().implicitlyWait(5 * 2, TimeUnit.SECONDS);
			}
			else{
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}

			if(browsertype.equalsIgnoreCase("Firefox") || browsertype.equalsIgnoreCase("IE") || browsertype.equalsIgnoreCase("Chrome"))
			{
				driver.manage().window().maximize();
			}
				
			
			driver.get(URL);
			
		} catch (Exception e1) {
			System.out.println(e1);
		}
	}
	
	
	//FirefoxProfile
	
	
	public static FirefoxProfile FirefoxDriverProfile() throws Exception {
		FirefoxProfile profile = new FirefoxProfile();
		 
		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("browser.download.dir", "C://IN01612/WKProject//GBS_Automation//TestData//PDFDownloads");
		profile.setPreference("browser.helperApps.neverAsk.openFile",
		"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
		"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
		profile.setPreference("browser.helperApps.alwaysAsk.force", false);
		profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
		profile.setPreference("browser.download.manager.focusWhenStarting", false);
		profile.setPreference("browser.download.manager.useWindow", false);
		profile.setPreference("browser.download.manager.showAlertOnComplete", false);
		profile.setPreference("browser.download.manager.closeWhenDone", false);
		return profile;
		
		
		
	}
	
}
