package com.arrow.accelerators;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Parameters;

import com.arrow.objectrepo.Admin;
import com.arrow.support.ReportStampSupport;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 *  ActionEngine is a wrapper class of Selenium actions
 */

public class ActionEngine extends TestEngine {

	public XSSFSheet inputSheet = null;
	public 	com.arrow.support.ExcelReader Excelobject=new com.arrow.support.ExcelReader();
	
	public static long lSleep_VLow=Long.valueOf(configProps.getProperty("Sleep_VLow").toString());
	public static long lSleep_Low=Long.valueOf(configProps.getProperty("Sleep_Low").toString());
	public static long lSleep_Medium=Long.valueOf(configProps.getProperty("Sleep_Medium").toString());
	public static long lSleep_High=Long.valueOf(configProps.getProperty("Sleep_High").toString());
	public  int stepNum = 0;
	public  int PassNum =0;
	public  int FailNum =0;
	public  int RowFailNum =0;
	public boolean flag = false;
	public boolean blnEventReport = false;
	public String browsertype;
	public String TestDataWorkBookLogin = "TestData\\"+configProps.getProperty("TestDataWorkBookLogin").toString();
	public String TestDataWorkBookEntity = "TestData\\"+configProps.getProperty("TestDataWorkBookEntity").toString();
	public String TestDataWorkBookAffiliation = "TestData\\"+configProps.getProperty("TestDataWorkBookAffiliation").toString();
	public String TestDataWorkBookNPDSprint1 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint1").toString();
	public String TestDataWorkBookNPDSprint3 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint3").toString();
	public String TestDataWorkBookNPDSprint7 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint7").toString();
	public String TestDataWorkBookNPDSprint8 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint8").toString();
	public String TestDataWorkBookNPDSprint13 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint13").toString();
	public String TestDataWorkBookNPDSprint15 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint15").toString();
	public String TestDataWorkBookNPDSprint16 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint16").toString();
	public String TestDataWorkBookNPDSprint17 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint17").toString();
	public String TestDataWorkBookNPDSprint23 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint23").toString();
	public String TestDataWorkBookNPDSprint24 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint24").toString();
	public String TestDataWorkBookAlerts = "TestData\\"+configProps.getProperty("TestDataWorkBookAlerts").toString();
	public String TestDataWorkBookUSOP = "TestData\\"+configProps.getProperty("TestDataWorkBookUSOP").toString();
	public String TestDataWorkBookEntityLevelDI = "TestData\\"+configProps.getProperty("TestDataWorkBookEntityLevelDI").toString();
	public String TestDataWorkBookEntityName = "TestData\\"+configProps.getProperty("TestDataWorkBookEntityName").toString();
	public String TestDataWorkBookCarrierSOP = "TestData\\"+configProps.getProperty("TestDataWorkBookCarrierSOP").toString();
	public String TestDataWorkBookActionItem_SOP = "TestData\\"+configProps.getProperty("TestDataWorkBookActionItem_SOP").toString();
	public String TestDataWorkBookCustomer = "TestData\\"+configProps.getProperty("TestDataWorkBookCustomer").toString();
	public String TestDataWorkBookRepresentation = "TestData\\"+configProps.getProperty("TestDataWorkBookRepresentation").toString();
	public String TestDataWorkBookReports = "TestData\\"+configProps.getProperty("TestDataWorkBookReports").toString();
	public String TestDataWorkBookSOPCreateWorksheet = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPCreateWorksheet").toString();
	public String TestDataWorkBookPostLog = "TestData\\"+configProps.getProperty("TestDataWorkBookPostLog").toString();
	public String TestDataWorkBookTeamSOPDashboard = "TestData\\"+configProps.getProperty("TestDataWorkBookTeamSOPDashboard").toString();
	public String TestDataWorkBookManageDefaultAssignment_SOP = "TestData\\"+configProps.getProperty("TestDataWorkBookManageDefaultAssignment_SOP").toString();
	public String TestDataWorkBookSOPMessages_SOP = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPMessages_SOP").toString();
	public String TestDataWorkBookQualityMaintainance_SOP = "TestData\\"+configProps.getProperty("TestDataWorkBookQualityMaintainance_SOP").toString();
	public String TestDataWorkBookSOPSearchWorksheet = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPSearchWorksheet").toString();
	public String TestDataWorkBookSOPAutoUpload = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPAutoUpload").toString();
	public String TestDataWorkBookSOPCommonAlerts = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPCommonAlerts").toString();
	public String TestDataWorkBookSOPCES = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPCES").toString();

	public String TestDataWorkBookSOPAutoAssignment = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPAutoAssignment").toString();
	public String TestDataWorkBookAffiliationLevelDI = "TestData\\"+configProps.getProperty("TestDataWorkBookAffiliationLevelDI").toString();
	public String TestDataWorkBookCommunication = "TestData\\"+configProps.getProperty("TestDataWorkBookCommunication").toString();
	public String TestDataWorkBookAdmin = "TestData\\"+configProps.getProperty("TestDataWorkBookAdmin").toString();
	public String TestDataWorkBookCRM = "TestData\\"+configProps.getProperty("TestDataWorkBookCRM").toString();
	public String TestDataWorkBookRenewalInvoice = "TestData\\"+configProps.getProperty("TestDataWorkBookRenewalInvoice").toString();
	public String TestDataWorkBookXSOP = "TestData\\"+configProps.getProperty("TestDataWorkBookXSOP").toString();
	public String TestDataWorkBookSOPAssignmentDashboard = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPAssignmentDashboard").toString();
	public String TestDataWorkBookEM = "TestData\\"+configProps.getProperty("TestDataWorkBookEM").toString();
	public String TestDataWorkBookSOPReconciliation = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPReconciliation").toString();
	public String TestDataWorkBookCampaign = "TestData\\"+configProps.getProperty("TestDataWorkBookCampaign").toString();
	public String TestFileXMLToUploadScanRBCOld = "TestData\\"+configProps.getProperty("TestFileXMLToUploadScanRBCOld").toString();
	public String TestFilePDFToUploadScanRBCOld = "TestData\\"+configProps.getProperty("TestFilePDFToUploadScanRBCOld").toString();
	public String PowerShellToCopy = "TestData\\"+configProps.getProperty("PowerShellToCopy").toString();
	public String PowerShellToRename = "TestData\\"+configProps.getProperty("PowerShellToRename").toString();
	public String PowerShellToUpdate = "TestData\\"+configProps.getProperty("PowerShellToUpdate").toString();
	public String PowerShellToDelete =  "TestData\\"+configProps.getProperty("PowerShellToDelete").toString();
	public String TestDataWorkBookNPDPSOPXML = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDPSOPXML").toString();
	//public String NasScanFirstPath = configProps.getProperty("NasScanFirstPath").toString();
	public String NasScanFirstPathStg = configProps.getProperty("NasScanFirstPathStg").toString();
	public String NasScanFirstPathQA = configProps.getProperty("NasScanFirstPathQA").toString();
	public String TestDataWorkBookSOPTextMaintenance = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPTextMaintenance").toString();
	public String TestDataWorkBookSOPVolume = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPVolume").toString();
	public String TestDataWorkBookSOPExpeditedTransmissions = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPExpeditedTransmissions").toString();
	public String TestDataWorkBookSOPRetainedWorksheets = "TestData\\"+configProps.getProperty("TestDataWorkBookSOPRetainedWorksheets").toString();
    public String TestDataWorkBookNPDSprint25 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint25").toString();
    public String TestDataWorkBookNPDSprint26 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint26").toString();
    public String TestDataWorkBookNPDSprint27 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint27").toString();
    public String TestDataWorkBookNPDSprint28 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint28").toString();
    public String TestDataWorkBookNPDSprint30 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint30").toString();
    public String TestDataWorkBookNPDSprint32 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint32").toString();
    public String TestDataWorkBookNPDSprint33 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint33").toString();
    public String TestDataWorkBookNPDSprint34 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint34").toString();
    public String TestDataWorkBookNPDSprint35 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint35").toString();
    public String TestDataWorkBookNPDSprint36 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint36").toString();
    public String TestDataWorkBookNPDSprint37 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint37").toString();
    public String TestDataWorkBookNPDSprint38 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint38").toString();
    public String TestDataWorkBookNPDSprint39 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint39").toString();
    public String TestDataWorkBookNPDSprint40 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint40").toString();
    public String TestDataWorkBookNPDSprint41 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint41").toString();
    public String TestDataWorkBookNPDSprint42 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint42").toString();
    public String TestDataWorkBookNPDSprint43 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint43").toString();
    public String TestDataWorkBookNPDSprint48 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint48").toString();
    public String TestDataWorkBookNPDSprint49 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint49").toString();
    public String TestDataWorkBookNPDSprint50 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint50").toString();
    public String TestDataWorkBookNPDSprint52 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint52").toString();
    public String TestDataWorkBookCIOXSprint2 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint2").toString();
    public String TestDataWorkBookCIOXSprint3 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint3").toString();
    public String TestDataWorkBookCIOXSprint4 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint4").toString();
    public String TestDataWorkBookCIOXSprint5 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint5").toString();
    public String TestDataWorkBookNPDSprint53 = "TestData\\"+configProps.getProperty("TestDataWorkBookNPDSprint53").toString();
    public String TestDataWorkBookCIOXSprint7 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint7").toString();
    public String TestDataWorkBookCIOXSprint8 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint8").toString();
    public String TestDataWorkBookCIOXSprint9 = "TestData\\"+configProps.getProperty("TestDataWorkBookCIOXSprint9").toString();
    public String TestDataNPDDevOpsSprint1 = "TestData\\"+configProps.getProperty("TestDataNPDDevOpsSprint1").toString();
    public String TestDataNPDDevOpsSprint2 = "TestData\\"+configProps.getProperty("TestDataNPDDevOpsSprint2").toString();
    public String TestDataNPDDevOpsSprint5 = "TestData\\"+configProps.getProperty("TestDataNPDDevOpsSprint5").toString();
    public String TestDataNPDDevOpsSprint7 = "TestData\\"+configProps.getProperty("TestDataNPDDevOpsSprint6&7").toString();
    
    public  String gStrErrMsg=" ";
	public WebDriverWait wait;
	private static final DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

	/*****
	 * moveToElement
	 * @param locator		: Action to be performed on element (Get it from Object repository)
	 * @param locatorName	:Meaningful name to the element (Ex:Login Button, SignIn Link etc..)
	 * @return				:(true or false)
	 */

	public boolean moveToElement(By locator, String locatorName) {
		boolean flag = false;
		try {
			WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].scrollIntoView(true);", element);
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(locator)).build().perform();
			flag = true;
		}catch(Exception e) {
			return false;
		}
		return flag;
	}
	
	/*****
	 * click
	 * @param locator		: Action to be performed on element (Get it from Object repository)
	 * @param locatorName	:Meaningful name to the element (Ex:Login Button, SignIn Link etc..)
	 * @return				:(true or false)
	 */
	
	public boolean click(By locator, String locatorName)
			throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			moveToElement(locator, locatorName);
			driver.findElement(locator).click();
			Thread.sleep(lSleep_Low);
			flag = true;
		} catch (Exception e) {
			try {
				WebElement element = driver.findElement(locator);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", element);
				// driver.executeAsyncScript("arguments[0].click();", element);
				flag = true;
			}
			catch (Exception e1) {
				throw e1;
			}
		} finally {
			if (flag && blnEventReport) {
				SuccessReport("Click on "+locatorName, "Successfully clicked on: \""+locatorName+"\"");
				//return true;
			} else if(!flag) {
				failureReport("Click on "+locatorName, "Unable to click on: \""+ locatorName+"\"");

			}
			/*if(flag) {
				  SuccessReport("verify Service Response", "Able to find text: \""+searchTerm+"\" in Response");
				 } 
				 else {
				  failureReport("verify Service Response", "Unable to find text: \""+searchTerm+"\" in Response");
				 }*/
		}
		return flag;
	}
	
	public boolean clickOnFirstElement(By locator, String locatorName)
			throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			moveToElement(locator, locatorName);
			driver.findElement(locator).click();
			Thread.sleep(lSleep_Low);
			flag = true;
		} catch (Exception e) {
			try {
				List <WebElement> elements = driver.findElements(locator);
				WebElement element = elements.get(0);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", element);
				flag = true;
			}
			catch (Exception e1) {
				throw e1;
			}
		} finally {
			if (flag && blnEventReport) {
				SuccessReport("Click on "+locatorName, "Successfully clicked on: \""+locatorName+"\"");
				//return true;
			} else if(!flag) {
				failureReport("Click on "+locatorName, "Unable to click on: \""+ locatorName+"\"");

			}
			/*if(flag) {
				  SuccessReport("verify Service Response", "Able to find text: \""+searchTerm+"\" in Response");
				 } 
				 else {
				  failureReport("verify Service Response", "Unable to find text: \""+searchTerm+"\" in Response");
				 }*/
		}
		return flag;
	}
	
	/**
	 * Wait for an ElementPresent
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @return Whether or not the element is displayed
	 */
	public boolean waitForElementPresent(By by, String locator) throws Throwable{
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		for(int i = 0; i <100; i++) {
			try {
				if(driver.findElement(by).isDisplayed()) {
					flag = true;
					break;
				}	
			}catch(Exception e) {
				flag = false;
				Thread.sleep(100);
			}
		}
		return flag;
	}
	
	@Parameters({"browser"})
	public void SuccessReport(String strStepName, String strStepDes)
			throws Throwable {
				int intReporterType = Integer.parseInt(configProps
						.getProperty("reportsType"));
				switch (intReporterType) {
				case 1:
		
					break;
				case 2:
					if (configProps.getProperty("OnSuccessScreenshot")
							.equalsIgnoreCase("True")) {
						screenShot("Results/HTML"+suiteStartTime+"/Screenshots/"
								+ strStepDes.replaceAll("[^\\w]", "_") 
								+ ".jpeg");
					}
					onSuccess(strStepName, strStepDes);
		
					break;
		
				default:
					if (configProps.getProperty("OnSuccessScreenshot")
							.equalsIgnoreCase("True")) {
						screenShot("Results/HTML"+suiteStartTime+"/Screenshots/"
								+ strStepDes.replaceAll("[^\\w]", "_")
								+ ".jpeg");
					}
					onSuccess(strStepName, strStepDes);
					break;
				}
				
		if (configProps.getProperty("OnSuccessScreenshot").equalsIgnoreCase("True")){
			child.log(LogStatus.PASS,strStepName + child.addScreenCapture(screenShotForPass(driver)),strStepDes );	
		} else {
			child.log(LogStatus.PASS, strStepName, strStepDes);
		}
		

	}

	public void failureReport(String strStepName, String strStepDes)
			throws Throwable {
				int intReporterType = Integer.parseInt(configProps
						.getProperty("reportsType"));
		
				String stepExecTime =  ReportStampSupport.stepExecTime();
				switch (intReporterType) {
				case 1:
					flag = true;
					break;
				case 2:
					screenShot("Results/HTML"+suiteStartTime+"/Screenshots/"
							+ strStepDes.replaceAll("[^\\w]", "_")+stepExecTime+".jpeg");
					flag = true;
					onFailure(strStepName, strStepDes, stepExecTime);
					break;
		
				default:
					flag = true;
					screenShot("Results/HTML"+suiteStartTime+"/Screenshots/"
							+ strStepDes.replaceAll("[^\\w]", "_")+ReportStampSupport.stepExecTime()+".jpeg");
					onFailure(strStepName, strStepDes, stepExecTime);
					break;
				}

		child.log(LogStatus.FAIL,strStepName + child.addScreenCapture(screenShotForPass(driver)),strStepDes);
		

	}
	
	/**
	 * Capture Screenshot
	 * 
	 * @param fileName
	 *            : FileName screenshot save in local directory
	 * 
	 */
	public void screenShot(String fileName) {
		cmdStartTime=System.currentTimeMillis();
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		try {
			// Now you can do whatever you need to do with it, for example copy
			// somewhere
			FileUtils.copyFile(scrFile, new File(fileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void onSuccess(String strStepName, String strStepDes) {
		strTestName=strTestName.replaceAll("_", " ");	
		String status = "PASS";
		File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName+"_Results"
				+ ".html");// "SummaryReport.html"
		Writer writer = null;
		stepNum = stepNum + 1;

		try {
			//testdescrption.put(TestTitleDetails.x.toString(), TestEngine.testDescription.get(TestTitleDetails.x));
			if (!map.get(packageName + ":" + tc_name).equals("FAIL")) {
				map.put(packageName + ":" + tc_name, "PASS");
				//map.put(TestTitleDetails.x.toString(), TestEngine.testDescription.get(TestTitleDetails.x.toString()));
			}
			writer = new FileWriter(file, true);
			writer.write("<tr class='content2' >");
			writer.write("<td>" + stepNum + "</td> ");
			writer.write("<td class='justified'>" + strStepName + "</td>");
			writer.write("<td class='justified'>" + strStepDes + "</td> ");
			writer.write("<td class='Pass' align='center'><img  src='./Screenshots/passed.ico' width='18' height='18'/></td> ");
			//writer.write("<td>" + status + "</td> ");
			
			//writer.write("<td> <font color='#008000'><b>" + status + "<b></font></td>");
			
			PassNum  =PassNum + 1;
			cmdEndTime=System.currentTimeMillis();
        	cmdTime=cmdEndTime-cmdStartTime;
        	int time=(int) TimeUnit.MILLISECONDS.toSeconds(cmdTime);
        	if(time==0)
        		time=1;
			writer.write("<td><small>" + time +" Sec "+ "</small></td> ");
			writer.write("</tr> ");
			writer.close();

		}catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void onFailure(String strStepName, String strStepDes, String stepExecTime) {
		Writer writer = null;
		try {
			//String fileName= strTestName;
			String status = "FAIL";
			strTestName=strTestName.replaceAll("_", " ");			
			File file = new File("Results/HTML"+suiteStartTime+"/" + strTestName+"_Results"
					+ ".html");// "SummaryReport.html"

			writer = new FileWriter(file, true);
			stepNum = stepNum + 1;

			writer.write("<tr class='content2' >");
			writer.write("<td>" + stepNum + "</td> ");
			writer.write("<td class='justified'>" + strStepName + "</td>");
			writer.write("<td class='justified'>" + strStepDes + "</td> ");
			FailNum = FailNum + 1;
			RowFailNum=RowFailNum+1;


			writer.write("<td class='Fail' align='center'><a  href='"+"./Screenshots"+"/"+ strStepDes.replaceAll("[^\\w]", "_")
					+ stepExecTime +".jpeg'"+" alt= Screenshot  width= 15 height=15 style='text-decoration:none;'><img  src='./Screenshots/failed.ico' width='18' height='18'/></a></td>");
			//writer.write("<td>" + status + "</td> ");
			//writer.write("<td> <font color='#FF0000'> <b>" + status + "<b> </font></td>");
			cmdEndTime=System.currentTimeMillis();
        	cmdTime=cmdEndTime-cmdStartTime;
        	int time=(int) TimeUnit.MILLISECONDS.toSeconds(cmdTime);
        	if(time==0)
        		time=1;
			writer.write("<td><small>" + time +" Sec "+ "</small></td> ");
			writer.write("</tr> ");
			writer.close();
			if (!map.get(packageName + ":" + tc_name).equals("PASS")) {
				map.put(packageName + ":" + tc_name+":", "FAIL");
				//map.put(TestTitleDetails.x.toString(), TestEngine.testDescription.get(TestTitleDetails.x.toString()));
			}
		} catch (Exception e) {

		}

	}
	
	public String screenShotForPass(WebDriver driver) throws IOException
	{	
		String src_path = System.getProperty("user.dir")+"\\Reports\\Screenshots\\";
		UUID uuid = UUID.randomUUID();
		// generate screenshot as a file object
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			// copy file object to designated location
			FileUtils.copyFile(scrFile, new File(src_path + uuid + ".png"));
		} catch (IOException e) {
			System.out.println("Unhadled exception occure while generating screenshot:\n" + e.toString());
		}
		return src_path + uuid + ".png";
	}   

	/**
	 * This method returns check existence of element
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Textbox, checkbox etc)
	 * @return: Boolean value(True or False)
	 * @throws NoSuchElementException
	 */
	
	public boolean isElementPresent(By by, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			driver.findElement(by).isDisplayed();
			flag = true;
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		} finally {
			if (flag) {
				SuccessReport("Check IsElementPresent ", "\""+locatorName+"\"Element is present on the page ");
			} else {
				failureReport("Check IsElementPresent ","\""+locatorName+"\"Element is not present on the page");
			}
		}
	}	
	
	/**
	 * This method does not add in failure path if element is not present. 
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Textbox, checkbox etc)
	 * @return: Boolean value(True or False)
	 * @throws NoSuchElementException
	 */
	
	public boolean verifyIfElementPresent(By by, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			driver.findElement(by).isDisplayed();
			flag = true;
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		finally {
			if (flag) {
				SuccessReport("Check IsElementPresent ", "\""+locatorName+"\"Element is present on the page ");
			} else {
				System.out.println("Element is not displayed");
			}
		}
	}	
	/**
	 * Select a value from Dropdown using send keys
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param value
	 *            : Value wish type in dropdown list
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Year Dropdown, items
	 *            Listbox etc..)
	 * 
	 */
	public boolean selectBySendkeys(By locator, String value,
			String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			driver.findElement(locator).sendKeys(value);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				SuccessReport("Select value from "+locatorName,"\""+value+"\"is Selected from the DropDown\""+locatorName+"\"");		
			} else {
				failureReport("Select value from "+locatorName,"\""+value+"\"is Not Selected from the DropDown\""+locatorName+"\"");
				// throw new ElementNotFoundException("", "", "")
			}
		}
	}

	/**
	 * select value from DropDown by using selectByIndex
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param index
	 *            : Index of value wish to select from dropdown list.
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Year Dropdown, items
	 *            Listbox etc..)
	 * 
	 */
	public boolean selectByIndex(By locator, int index,
			String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			Select s = new Select(driver.findElement(locator));
			s.selectByIndex(index);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				SuccessReport("Select ", "Option at index \""+index+"\"is Selected from the DropDown \""+locatorName+"\"");
			} else {
				failureReport("Select ", "Option at index \""+index+"\"is Not Selected from the DropDown \""+locatorName+"\"");
			}
		}
	}

	/**
	 * select value from DD by using value
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param value
	 *            : Value wish to select from dropdown list.
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Year Dropdown, items
	 *            Listbox etc..)
	 */

	public boolean selectByValue(By locator, String value,
			String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			Select s = new Select(driver.findElement(locator));
			s.selectByValue(value);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				SuccessReport("Select","Option with value attribute \""+value+"\"is Selected from the DropDown \""+locatorName+"\"");
			} else {
				failureReport("Select","Option with value attribute \""+value+"\"is Not Selected from the DropDown \""+locatorName+"\"");
			}
		}
	}

	/**
	 * select value from DropDown by using selectByVisibleText
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param visibletext
	 *            : VisibleText wish to select from dropdown list.
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Year Dropdown, items
	 *            Listbox etc..)
	 */

	public boolean selectByVisibleText(By locator, String visibletext,
			String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			Select s = new Select(driver.findElement(locator));
			s.selectByVisibleText(visibletext);
			Thread.sleep(500);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag && blnEventReport) {
				SuccessReport("Select","\""+visibletext+"\" is Selected from the DropDown \""+locatorName+"\"");		
			} else if(!flag) {
				failureReport("Select","\""+visibletext+"\" is Not Selected from the DropDown \""+locatorName+"\"");
			}
		}
	}
	
	/**
	 * This method used type value in to text box or text area
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param testdata
	 *            : Value wish to type in text box / text area
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Textbox,Text Area etc..)
	 * 
	 * @throws NoSuchElementException
	 */
	public boolean type(By locator, String testdata, String locatorName)
		
			throws Throwable {
		System.out.println(testdata);
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			driver.findElement(locator).clear();
			driver.findElement(locator).sendKeys(testdata);
			Thread.sleep(250);
			flag = true;

		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw e;

		} finally {
			if (flag && blnEventReport) {
				SuccessReport("Type Data in "+locatorName,"Data typing action is performed on \""+locatorName+"\" with data \""+testdata+"\"");
			} else if(!flag){
				failureReport("Type Data in "+locatorName,"Data typing action is not performed on \""+locatorName+"\" with data \""+testdata+"\"");
			}
		}
		return flag;
	}
	
	/**
	 * The innerText of this element.
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:label text, SignIn Link
	 *            etc..)
	 * 
	 * @return: String return text on element
	 * 
	 */

	public String getText(By locator, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		String text = "";
		boolean flag = false;
		try {
			if (isElementPresent(locator, locatorName)) {
				text = driver.findElement(locator).getText();
				System.out.println("Text: "+text);
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				SuccessReport("GetText ", " Able to get Text from \""+locatorName+"\"");			
			} else {
				//warningReport("GetText ", " Unable to get Text from \""+locatorName+"\"");
			}
		}
		return text;
	}
	
	/**
	 * Check the expected value is available or not
	 * 
	 * @param expvalue
	 *            : Expected value of attribute
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param attribute
	 *            : Attribute name of element wish to assert
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:link text, label text
	 *            etc..)
	 * 
	 */
	public boolean compareStrings(String expvalue, String actvalue) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {

			Assert.assertEquals(expvalue, actvalue);
			flag = true;
		} catch (Exception e) {

		} 
		finally {
			if (flag) {
				SuccessReport("AssertValue ", "Expected value \""+expvalue+"\" is matching with Actual value \""+actvalue+"\"");				
				return false;
			} else {
				failureReport("AssertValue ","Expected value \""+expvalue+"\" is NOT matching with Actual value \""+actvalue+"\"");
			}
		}
		return flag;
	}
	
	/**
	 * Assert element present or not
	 * 
	 * @param by
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Login Button, SignIn Link
	 *            etc..)
	 * 
	 */
	public boolean assertElementPresent(By by, String locatorName)
			throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			Assert.assertTrue(isElementPresent(by, locatorName));
			flag = true;
		} catch (Exception e) {

		} finally {
			if (flag) {
				SuccessReport("AssertElementPresent ", "\""+locatorName+"\"is present in the page ");
				return false;
			} else {
				failureReport("AssertElementPresent ", "\""+locatorName+"\" is not present in the page ");
			}
		}
		return flag;

	}
	
	public boolean assertTextMatching(By by, String text, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			String ActualText = getText(by, text).trim();
			if (ActualText.contains(text)) {
				flag = true;
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (flag) {
				SuccessReport("Verify \""+locatorName+"\"" , "\""+text+"\" is  present in the element ");				
			} else {
				failureReport("Verify \""+locatorName+"\"" , "\""+text+"\" is not present in the element");
			}
		}

	}
	
	public boolean waitForFrameToLoadAndSwitchToIt(By by, String LocatorName) throws Throwable{
		WebDriverWait wait = new WebDriverWait(driver, 2);

		cmdStartTime=System.currentTimeMillis();
		try {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(by));
			if(blnEventReport==true){
				SuccessReport("waitForFrameToLoadAndSwitchToIt "+LocatorName, "Switched to frame successfully");	
			}
			
			 
			return true;
		} catch (Exception e) {
			failureReport("waitForFrameToLoadAndSwitchToIt","Not able to switch to Frame : " + LocatorName);
					 
			return false;
		}		
	}
	
	/**
	 * This method wait selenium until visibility of Elements on WebPage.
	 * 
	 * @param by
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @throws Throwable
	 * 
	 */

	public boolean waitForElementToBeClickable(By by, String locator) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		wait = new WebDriverWait(driver, 30);
		try {
			wait.until(ExpectedConditions.elementToBeClickable(by));
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				SuccessReport("WaitForVisibilityOfElement ", " Element\""+locator+"\"  is visible");			
			} else {
				failureReport("WaitForVisibilityOfElement ", " Element \""+locator+"\" is not visible");
			}
		}
	}
	
	
	/**
	 * This method wait selenium until visibility of Elements on WebPage.
	 * 
	 * @param by
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @throws Throwable
	 * 
	 */
	
	public boolean waitForVisibilityOfElementWithoutReport(By by, String locator) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		wait = new WebDriverWait(driver, 5);

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} 
	}

	/**
	 * Element is enable or not
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Login Button, UserName
	 *            Textbox etc..)
	 * 
	 * @return: boolean value (True: if the element is enabled, false: if it not
	 *          enabled).
	 * 
	 */

	public boolean isEnabled(By locator, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		Boolean value = false;
		boolean flag = false;
		try {
			if (driver.findElement(locator).isEnabled()) {
				flag = true;
				value = true;
			}

		} catch (Exception e) {

			flag = false;

		} finally {
			if (flag) {
				SuccessReport("IsEnabled ", "\""+locatorName+"\" is Enabled");
			} else {
				failureReport("IsEnabled ", "\""+locatorName+"\" is not Enabled");
			}
		}
		return value;
	}
	
	/**
	 * Element is enable or not
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Login Button, UserName
	 *            Textbox etc..)
	 * 
	 * @return: boolean value (True: if the element is enabled, false: if it not
	 *          enabled).
	 * 
	 */

	public boolean isDisabled(By locator, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		Boolean value = false;
		boolean flag = false;
		try {
			if (driver.findElement(locator).isEnabled()) {
				flag = true;
				value = true;
			}

		} catch (Exception e) {

			flag = false;

		} finally {
			if (!flag) {
				SuccessReport("IsDisabled ", "\""+locatorName+"\" is Disabled");
			} else {
				failureReport("IsDisabled ", "\""+locatorName+"\" is Enabled");
			}
		}
		return value;
	}

	
	/**
	 * This function gets system date
	 * 
	 * 
	 * @return: String which contains Date
	 * 
	 */
	public String getCurrentDate() throws Throwable {
		Date currentDate = new Date();

        // convert date to calendar
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);
        //below commented code part was present before
   /*   c.getTime();
        return dateFormat.format(c);*/
        //below code part is added as null was being returned and after formatting the c objects .getTime() value works fine 
        return dateFormat.format(c.getTime());
	}
	
	/**
	 * This function gets system date and add one month to it
	 * 
	 * 
	 * @return: String which contains Date
	 * 
	 */
	public String addMonthInCurrentDate() throws Throwable {
		Date currentDate = new Date();

        // convert date to calendar
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);

        // manipulate date
        c.add(Calendar.MONTH, 1);

        // convert calendar to date
        Date currentDatePlusOne = c.getTime();

        return dateFormat.format(currentDatePlusOne);
	}
	
	/**
	 * This function gets system date and adds number of days
	 * 
	 * @param noOfDays
	 * 				Number of days need to add in current date
	 * 
	 * @return: String which contains Date
	 * 
	 */
	public String addDaysInCurrentDate(int noOfDays) throws Throwable {
		Date currentDate = new Date();

        // convert date to calendar
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);

        // manipulate date
        c.add(Calendar.DATE, noOfDays);

        // convert calendar to date
        Date currentDatePlusOne = c.getTime();

        return dateFormat.format(currentDatePlusOne);
	}
	
	
	/**
	 * This method handles popup
	 * 
	 * @throws NoSuchElementException
	 */
	
	public void handlepopup() throws Throwable {
		try {
		driver.switchTo().alert().accept();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method cancels popup
	 * 
	 * @throws NoSuchElementException
	 */
	
	public void cancelpopup() throws Throwable {
		try {
		driver.switchTo().alert().dismiss();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This function gets current Window
	 *
	 * @return: Current Window
	 * 
	 */

	public String getCurrentWindow() throws Throwable{
		String currentWindow = driver.getWindowHandle();
		return currentWindow;
	}
	
	/**
	 * This method switches to the child window from main window
	 * 
	 * @throws NoSuchElementException
	 */

	public void handlePopUpWindwow() throws Throwable {
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		String MainWindow = getCurrentWindow();

		while (i1.hasNext()) {
			String ChildWindow = i1.next();

			if (!MainWindow.equalsIgnoreCase(ChildWindow)) {

				// Switching to Child window
				driver.switchTo().window(ChildWindow);

			}
		}

	}
	
	/**
	 * This method switches to the child window from main window, closes child window and
	 * switch back to main window 
	 * @throws NoSuchElementException
	 */

	public void switchAndCloseWindow() throws Throwable {
		String parentWindow = driver.getWindowHandle();
		Set<String> handles =  driver.getWindowHandles();
		   for(String windowHandle  : handles)
		       {
		       if(!windowHandle.equals(parentWindow))
		          {
		          driver.switchTo().window(windowHandle);
		         driver.close(); //closing child window
		         driver.switchTo().window(parentWindow); //cntrl to parent window
		          }
		       }
	}
	
	/**
	 * This function gets the column data from the table
	 * 
	 * @param table
	 * 				Locator of the table
	 * 
	 * @return: Column Data
	 * 
	 */

	
	public ArrayList<String> getTableData(By table) throws Throwable {
		WebElement tableContents = driver.findElement(table);
		ArrayList<String> ColData=new ArrayList<String> ();

		List<WebElement> rows=tableContents.findElements(By.tagName("tr"));
		for(int rnum=0;rnum<rows.size();rnum++)
		{
		List<WebElement> columns=rows.get(rnum).findElements(By.tagName("td"));
		ColData.add(columns.get(0).getText());
		}

		return ColData;
	}
	
	/**
	 * This function gets Attribute of WebElement
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * 
	 * @param attributeName
	 *            : Attrinute Name whose value to be returned (Ex: Style etc..)
	 * 
	 * @return: String which contains Date
	 * 
	 */
	public String getAttribute(By locator, String attributeName) throws Throwable {
		String value = "";
		boolean flag = false;
		try {
			value = driver.findElement(locator).getAttribute(attributeName);
			flag = true;
			return value;
		} catch (Exception e) {
			flag = false;
		} finally {
			if (flag) {
				SuccessReport("Attribute of element", "Attribute of Element\""+locator+"\"  is returned");			
			} else {
				failureReport("Attribute of element", "Attribute of Element \""+locator+"\" is not returned");
			}
		}
	return value;
	
	}
	
	/**
	 * This function function finds if Actual Text is present in text
	 * 
	 * @param text
	 *            : Original text
	 * 
	 * @param ActualText
	 *            : ActualText to find within text
	 * 
	 * @return: String which contains boolean
	 * 
	 */
	public boolean assertTextContains(String text, String ActualText) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			if (text.contains(ActualText)) {
				flag = true;
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (flag) {
				SuccessReport("Verify \""+text+"\"" , "\""+ActualText+"\" is  present in the element ");				
			} else {
				failureReport("Verify \""+text+"\"" , "\""+ActualText+"\" is not present in the element");
			}
		}

	}
	
	/**
	 * This function function finds if Actual Text is present in text
	 * 
	 * @param locator
	 *            : Where the text to be pasted
	 * 
	 *            
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Login Button, UserName
	 *            Textbox etc..)
	 * 
	 * @return: String which contains boolean
	 * 
	 */
	
	public boolean pasteTextInTextField(By locator, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			driver.findElement(locator).sendKeys(Keys.chord(Keys.CONTROL, "v"));
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (flag) {
				SuccessReport("Paste text" , "Pasted text in field \""+locatorName+"\" ");				
			} else {
				failureReport("Paste text" , "Text is NOT pasted in \""+locatorName+"\" ");
			}

			
		}
		return flag;
		
	}
	
	/**
	 * A convenience method that performs click-and-hold at the location of the
	 * source element, moves by a given offset, then releases the mouse.
	 * 
	 * @param source
	 *            : Element to emulate button down at.
	 * 
	 * @param xOffset
	 *            : Horizontal move offset.
	 * 
	 * @param yOffset
	 *            : Vertical move offset.
	 * 
	 */
	public boolean draggable(By source, int x, int y, String locatorName)
			throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			WebElement dragitem = driver.findElement(source);
			new Actions(driver).dragAndDropBy(dragitem, x, y).build().perform();
			
			flag = true;
			return true;

		} catch (Exception e) {
		
			return false;
			
			
		} finally {
			if (flag) {
				SuccessReport("Draggable ","Draggable Action is performed on \""+locatorName+"\"");			
			} else if(!flag) {
				failureReport("Draggable ","Draggable action is not performed on \""+locatorName+"\"");
			}
		}
	}

	/**
	 * A convenience method that performs click-and-hold at the location of the
	 * source element, moves to the location of the target element, then
	 * releases the mouse.
	 * 
	 * @param source
	 *            : Element to emulate button down at.
	 * 
	 * @param target
	 *            : Element to move to and release the mouse at.
	 * 
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Button,image etc..)
	 * 
	 */
	public boolean draganddrop(By source, By target, String locatorName)
			throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			WebElement from = driver.findElement(source);
			WebElement to = driver.findElement(target);
		    new Actions(driver).dragAndDrop(from, to).perform();
			
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag && blnEventReport) {
				SuccessReport("DragAndDrop ","DragAndDrop Action is performed on \""+locatorName+"\"");
			} else if(!flag) {
				failureReport("DragAndDrop ","DragAndDrop action is not performed on \""+locatorName+"\"");
			}
		}
	}
	
	/*****
	 * focus
	 * @param locator		: Action to be performed on element (Get it from Object repository)
	 * @param locatorName	:Meaningful name to the element (Ex:Login Button, SignIn Link etc..)
	 * @return				:(true or false)
	 */
	
	public boolean focus(By locator, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			moveToElement(locator, locatorName);
			WebElement element = driver.findElement(locator);
			new Actions(driver).moveToElement(element).perform();
			flag = true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				SuccessReport("Focus on "+locatorName, "Successfully focused on: \""+locatorName+"\"");
			} else if(!flag) {
				failureReport("Click on "+locatorName, "Unable to focus on: \""+ locatorName+"\"");

			}
		}
		return flag;
	}

	/*****
	 * scroll
	 * @return				:(true or false)
	 */
	
	public boolean scrollUp() throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("window.scrollBy(0,-1000)");
			flag = true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				SuccessReport("Window Scroll", "Window is scrolled up successfully");
			} else if(!flag) {
				failureReport("Window Scroll", "Window is NOT scrolled up");

			}
		}
		return flag;
	}
	
	/*****
	 * elementIsNotPresent
	 * @param locator		: Action to be performed on element (Get it from Object repository)
	 * @param locatorName	:Meaningful name to the element (Ex:Login Button, SignIn Link etc..)
	 * @return				:(true or false)
	 */
	
	public boolean elementIsNotPresent(By locator, String locatorName) throws Throwable {
		boolean flag = true;
		try {
			List<WebElement> element = driver.findElements(locator);
			if(element.size()!=0) {
				flag = false;
			}
			else {
				flag = true;
			}
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				SuccessReport("Check element is not present ", "\""+locatorName+"\"element is NOT present on the page");
			} else {
				failureReport("Check element is not present ", "\""+locatorName+"\"element is present on the page ");

			}
		}
		return flag;
	}
	
	
	/**
	 * This method returns check an element is not present
	 * 
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Textbox, checkbox etc)
	 * @return: Boolean value(True or False)
	 * @throws NoSuchElementException
	 */
	
	public boolean isElementNotPresent(By by, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			 flag=driver.findElement(by).isDisplayed();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		} finally {
			if (!flag) {
				SuccessReport("Check IsElementNotPresent ", "\""+locatorName+"\"Element is not present on the page ");
				return true;
			} else {
				failureReport("Check IsElementNotPresent ","\""+locatorName+"\"Element is  present on the page");
			}
		}
		return flag;
	}
	
	/**
	 * This function gets all the datas from the tdropdown
	 * 
	 * @param table
	 * 				Locator of the Dropdown
	 * 
	 * @return: Drop Down Data
	 * 
	 */
	
	public List<WebElement> getAllDropDownData(By dropDown) throws Throwable {
		
		WebElement drop_down = driver.findElement(dropDown);
		Select se = new Select(drop_down);
		List<WebElement> options = se.getOptions();
		return options;
	}
	
	public boolean compareTwoArrayList(List<String> repAndAnnualReportServiceList,List<String> originalrepAndAnnualReportServiceList) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag=false;
		try {
			 flag = repAndAnnualReportServiceList.equals(originalrepAndAnnualReportServiceList); 			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		} finally {
			if (flag) {
				SuccessReport("ArrayList is matching ", "\""+"ArrayOne"+"\"is matching with "+ "ArrayTwo");
			} else if(!flag) {
				failureReport("ArrayList is not matching ", "\""+"ArrayOne"+"\"is not matching with "+ "ArrayTwo");

			}
		}
		return flag;
	}
	
	/*****
	 * scroll
	 * @return				:(true or false)
	 */
	
	public boolean uploadFile(String fileName,By locator,String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		try {
			String uploadFilePath="\\UploadFiles\\"+fileName;
			String pathLocator = System.getProperty("user.dir") + uploadFilePath;
			type(locator,pathLocator,"Upload File");
			flag = true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				SuccessReport("File Uploaded", "File Uploaded successfully");
			} else if(!flag) {
				failureReport("File Upload Failed", "File didnt get Uploaded");

			}
		}
		return flag;
	}


	public void refreshPage() throws Throwable {
		driver.navigate().refresh();
	}


	/*****
	 * This method is used to print a specific message in report.
	 * It is mainly used in case of database connection
	 */
	public void printMessageInReport(String expvalue) throws Throwable {
		SuccessReport("AssertValue", expvalue);
	}

	// Below function Returns the Index of a matched Attribute value 
	public int returnIndexOfMatchedAttribute(By locator,String attributeName, String attributeValue) throws Throwable {
		int index = - 1;
		try{
		List <WebElement> tableContents = driver.findElements(locator);
		for(int s =0 ; s< tableContents.size(); s++){
			if(tableContents.get(s).getAttribute(attributeName).equalsIgnoreCase(attributeValue)){
				index = s;
				break;
			}
		}
		
		if(index == -1){
			throw new ArrayIndexOutOfBoundsException();
		}
	}catch(ArrayIndexOutOfBoundsException e){		
		
	}
		return index;
	}
	
	public int returnIndexOfMatchedTextvalue(By locator,String textValue){
		int index = - 1;
		try{
		List <WebElement> tableContents = driver.findElements(locator);
		for(int s =0 ; s< tableContents.size(); s++){
			//System.out.println("the value ++++++++ "+ tableContents.get(s).getText());
			if(tableContents.get(s).getText().contains(textValue)){
				index = s;
				break;
			}
		}
		
		if(index == -1){
			throw new ArrayIndexOutOfBoundsException();
		}
	}catch(ArrayIndexOutOfBoundsException e){		
		
	}
		return index;
	}
	
	public WebElement returnWebElementOfMatchedTextvalue(By locator,String textValue){
		WebElement ele = null;
		try{
		List <WebElement> tableContents = driver.findElements(locator);
		for(int s =0 ; s< tableContents.size(); s++){
			//System.out.println("the value ++++++++ "+ tableContents.get(s).getText());
			if(tableContents.get(s).getText().contains(textValue)){
				ele = tableContents.get(s);
				break;
			}
		}

	}catch(NullPointerException e){		
		
	}
		return ele;
	}

	public boolean clickOnAParticularIndexOfAnElement(By by, String locatorName, int index)
			throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		
		wait = new WebDriverWait(driver, 30);
		try {
			List <WebElement> elements =
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(by));
				//System.out.println("the index value is : " + index);				
				for(int s =0 ; s< elements.size(); s++){
					if(s == index) {						
						Thread.sleep(2000);		
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].scrollIntoView(true);", elements.get(s));	
						elements.get(s).click();
					
						break;
					}
				}
				flag = true;
			}
			catch (Exception e1) {
				throw e1;
			}
		 finally {
			if (flag && blnEventReport) {
				SuccessReport("Click on "+locatorName, "Successfully clicked on: \""+locatorName+"\"");
			} else if(!flag) {
				failureReport("Click on "+locatorName, "Unable to click on: \""+ locatorName+"\"");

			}
		}
		return flag;
	} 
	
	public List<String> getListText(By locator, String locatorName) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		List<String> text = new ArrayList<String>();
		boolean flag = false;
		try {
			if (isElementPresent(locator, locatorName)) {
				List <WebElement> elements = driver.findElements(locator);
				for(int s =0 ; s< elements.size(); s++){
                text.add(elements.get(s).getText());															
					}
				flag = true;	
			}																			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				SuccessReport("GetText ", " Able to get Text from \""+locatorName+"\"");			
			} else {
				failureReport("GetText ", " Unable to get Text from \""+locatorName+"\"");
			}
		}
		return text;
	}
	
	
	public String getPDFContent(String strURL) throws Throwable{

        String pdfData = ""; 
        try{			
            URL url = new URL(strURL);
            BufferedInputStream file = new BufferedInputStream(url.openStream());
            PDDocument document = null;
            try {
                document = PDDocument.load(file);
                pdfData = new PDFTextStripper().getText(document);
               //System.out.println(pdfData);
            } finally {
                if (document != null) {
                    document.close();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return pdfData;
    }
	
	
	public boolean waitForElementToBePresent(By by, String locator) throws Throwable {
		cmdStartTime=System.currentTimeMillis();
		boolean flag = false;
		wait = new WebDriverWait(driver, 30);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				SuccessReport("WaitForElementToBePresent ", " Element\""+locator+"\"  is Present");			
			} else {
				failureReport("WaitForElementToBePresent ", " Element \""+locator+"\" is not Present");
			}
		}
	}
}
