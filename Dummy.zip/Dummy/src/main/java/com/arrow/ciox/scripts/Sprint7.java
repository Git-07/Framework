package com.arrow.ciox.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_CIOXSprint7;

public class Sprint7 extends BusinessFunctions_CIOXSprint7 {

	//Verify no Create Worksheet link at Arrow Home Page for Level 1 user: CIA-88
	//Verify Create Worksheet left nav link remain disabled on landing sop module page for Level 1 user
	//Verify Create Worksheet left nav link  remains disabled on clicking any left nav links on sop page for level 1 user
	//Verify there is no Create Worksheet Button on My Worksheets Page for level 1 user
	//Verify there is no Create Worksheet Button on My Team's Worksheets Page for level 1 user
	//Verify Create Worksheet left nav link is only highlighted when user is on Create Worksheet Page for level 1 user
	@Test
	public void verifyCreateWorksheetLinksBtnForLevel1User() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "CreateWorksheetLinkBtnLevel1");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateWorksheetLinkBtnLevel1";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet link at Arrow Home Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetLinkAtArrowHomePage("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remain disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetLeftNavLink("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remains disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetLeftNavLinkDisabled("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetBtnOnMyWorksheetsPg("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Teams's Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link only highlighted when user on Create Worksheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyCreateWorksheetNavLinkHighlightedLevel1("CreateWorksheetLinkBtnLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no Create Worksheet link at Arrow Home Page for Level 2 user: CIA-88
	//Verify Create Worksheet left nav link remain disabled on landing sop module page for Level 2 user
	//Verify Create Worksheet left nav link  remains disabled on clicking any left nav links on sop page for level 2 user
	//Verify there is no Create Worksheet Button on My Worksheets Page for level 2 user
	//Verify there is no Create Worksheet Button on My Team's Worksheets Page for level 2 user
	//Verify Create Worksheet left nav link is only highlighted when user is on Create Worksheet Page for level 2 user
	@Test/*(groups= {"newly"})*/
	public void verifyCreateWorksheetLinksBtnForLevel2User() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "CreateWorksheetLinkBtnLevel2");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateWorksheetLinkBtnLevel2";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet link at Arrow Home Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetLinkAtArrowHomePage("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remain disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetLeftNavLink("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remains disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetLeftNavLinkDisabled("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetBtnOnMyWorksheetsPg("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Teams's Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg("CreateWorksheetLinkBtnLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link only highlighted when user on Create Worksheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						String esopId = entitySectionDetailsOnProcessingCES("CreateWorksheetLinkBtnLevel2", iLoop);
						verifyCreateWorksheetNavLinkHighlighted("CreateWorksheetLinkBtnLevel2", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no Create Worksheet link at Arrow Home Page for Level 3 user: CIA-88
	//Verify Create Worksheet left nav link remain disabled on landing sop module page for Level 3 user
	//Verify Create Worksheet left nav link  remains disabled on clicking any left nav links on sop page for level 3 user
	//Verify there is no Create Worksheet Button on My Worksheets Page for level 3 user
	//Verify there is no Create Worksheet Button on My Team's Worksheets Page for level 3 user
	//Verify Create Worksheet left nav link is only highlighted when user is on Create Worksheet Page for level 3 user
	@Test/*(groups= {"newly"})*/
	public void verifyCreateWorksheetLinksBtnForLevel3User() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "CreateWorksheetLinkBtnLevel3");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateWorksheetLinkBtnLevel3";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet link at Arrow Home Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetLinkAtArrowHomePage("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remain disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetLeftNavLink("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link remains disabled")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetLeftNavLinkDisabled("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetBtnOnMyWorksheetsPg("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet Button on My Teams's Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg("CreateWorksheetLinkBtnLevel3", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create Worksheet left nav link only highlighted when user on Create Worksheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CreateWorksheetLinkBtnLevel3", iLoop);
						verifyCreateWorksheetNavLinkHighlighted("CreateWorksheetLinkBtnLevel3", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify the updated court list on Create,CES,Edit,Review WorkSheet Page: CIA-1
	//Verify State of Court dropdown added and defaulted to Received Jurisdiction
	//Verify the court list is updated according to the state of court value
	@Test/*(groups= {"newly"})*/
	public void verifyUpdatedCourtListOnCreateCESEditReviewPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "CreateCESEditReviewUpdatedCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "CreateCESEditReviewUpdatedCourt";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet court list field updated")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CreateCESEditReviewUpdatedCourt", iLoop);
						verifyUpdatedCourtListForCreateWorksheetPage("CreateCESEditReviewUpdatedCourt", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("CES court list field updated")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyUpdatedCourtListForCESPage("CreateCESEditReviewUpdatedCourt", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Edit Worksheet court list field updated")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyUpdatedCourtListForEditWorksheetPage("CreateCESEditReviewUpdatedCourt", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Review Worksheet court list field updated")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						verifyUpdatedCourtListForReviewWorksheetPage("CreateCESEditReviewUpdatedCourt", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify Worksheets having old court data reflects new court list on editing the worksheet: CIA-1
	@Test
	public void verifyWorksheetOldCourt() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "WorksheetOldCourtData");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "WorksheetOldCourtData";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Worksheet Court field Edited")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyExistingWorksheetWithOldCourt("WorksheetOldCourtData", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify if None specified radio button is selected in CES process then when user lands on create worksheet page
	//"Use an Existing court" radio button should be selected by default and state of court dropdown should have received juris value selected: CIA-1
	@Test
	public void verifyNoneSpecifiedCourt() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "NoneSpecifiedCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NoneSpecifiedCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NoneSpecifiedCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NoneSpecifiedCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NoneSpecifiedCourt", "Member", iLoop);
				String team = Excelobject.getCellData("NoneSpecifiedCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("None Specified radio button selected in CES")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyNoneSpecifiedCourt = verifyNoneSpecifiedCourtCES("NoneSpecifiedCourt", iLoop);
						System.out.println(VerifyNoneSpecifiedCourt);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify if Use this court radio button is selected in ces process then when user lands on create worksheet page
	//"Use this court" radio button should be selected by default and state of court dropdown should have received juris value selected: CIA-1
	@Test/*(groups= {"newly"})*/
	public void verifyUseThisCourt() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "UseThisCourt");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("UseThisCourt", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("UseThisCourt", "Description", iLoop);
				String runStatus = Excelobject.getCellData("UseThisCourt", "RunStatus", iLoop);
				String member = Excelobject.getCellData("UseThisCourt", "Member", iLoop);
				String team = Excelobject.getCellData("UseThisCourt", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Use this Court radio button selected in CES")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyUseThisCourt = verifyUseThisCourtCES("UseThisCourt", iLoop);
						System.out.println(VerifyUseThisCourt);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify state of court  is defaulted to the Received Juris of the SOP when user lands on create worksheet page for level 2 user: CIA-1
	@Test
	public void verifyStateOfCourtForLevel2() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "StateOfCourtLevel2");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "StateOfCourtLevel2";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("State of Court defaulted to the Received Juris of the SOP")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel2();
						verifyStateOfCourtForLevel2User("StateOfCourtLevel2", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify state of court  is defaulted to the Received Juris of the SOP when user lands on create worksheet page for level 1 user: CIA-1
	@Test
	public void verifyStateOfCourtForLevel1() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "StateOfCourtLevel1");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "StateOfCourtLevel1";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("State of Court defaulted to the Received Juris of the SOP")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromLevel1();
						verifyStateOfCourtForLevel1User("StateOfCourtLevel1", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify if an esop is having common alerts, entity/affiliation/subgroup alerts, Internal Comments, CDSOP Comments then those are displayed on Create, Edit, Review Worksheet Page 
	//in this sequence: CIA-50
	@Test/*(groups= {"newly"})*/
	public void verifyEsopAlertsCommentsOnCreateEditReviewWorksheetPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "EsopAlertsComments");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "EsopAlertsComments";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Esop Alerts Comments verified on Create Edit Review Worksheet Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entityDetailsOnProcessingCES("EsopAlertsComments", iLoop);
						String worksheetId = verifyEsopAlertsCommentsForCreateWorksheetPage("EsopAlertsComments", iLoop, esopId);
						verifyEsopAlertsCommentsForEditWorksheetPage("EsopAlertsComments", iLoop, worksheetId);
						verifyEsopAlertsCommentsForReviewWorksheetPage("EsopAlertsComments", iLoop, worksheetId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
	
	//Verify no common alerts/entity/affiliation/subgroup alerts/Internal Comments/CDSOP Comments 
	//no change in the Edit/Review worksheet page: CIA-50
		@Test/*(groups= {"newly"})*/
		public void verifyNoAlertsCommentsOnEditReviewWorksheetPage() throws Throwable {
			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "NoAlertsComments");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
					String testCaseID = Excelobject.getCellData("NoAlertsComments", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("NoAlertsComments", "Description", iLoop);
					String runStatus = Excelobject.getCellData("NoAlertsComments", "RunStatus", iLoop);
					String member = Excelobject.getCellData("NoAlertsComments", "Member", iLoop);
					String team = Excelobject.getCellData("NoAlertsComments", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("No Alerts Comments On Edit Worksheet")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							String VerifyNoAlertsCommentsForEdit = verifyNoAlertsCommentsOnEditWorksheetPage("NoAlertsComments", iLoop);
							System.out.println(VerifyNoAlertsCommentsForEdit);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
						else if(testCaseID.contains("No Alerts Comments On Review Worksheet")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignInFromSOPSupportTeam();
							String VerifyNoAlertsCommentsForReview = verifyNoAlertsCommentsOnReviewWorksheetPage("NoAlertsComments", iLoop);
							System.out.println(VerifyNoAlertsCommentsForReview);
							driver.manage().deleteAllCookies();
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}

					}
				}
			}catch(Exception e) {}
		}
		
		//Verify comments and alerts are getting displayed on Edit Worksheet Page for Expedited SOP: CIA-50
		@Test/*(groups= {"newly"})*/
		public void verifyAlertsCommentsOnEditForExpeditedSOP() throws Throwable {

			try {		
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint7, "ExpeditedSOPAlertsComments");		
				for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
					String SheetName = "ExpeditedSOPAlertsComments";
					String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String description = Excelobject.getCellData(SheetName, "Description", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String member = Excelobject.getCellData(SheetName, "Member", iLoop);
					String team = Excelobject.getCellData(SheetName, "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Alerts Comments On Edit Worksheet For Expedited SOP")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");						
							SignIn(team, member);
							verifyAlertsCommentsForEditWorksheetExpeditedSOP("ExpeditedSOPAlertsComments", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");						
							driver.get(URL);
						}
					}
				}
			}catch(Exception e) {}
		}
}
