package com.arrow.ciox.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_CIOXSprint5;

public class Sprint5 extends BusinessFunctions_CIOXSprint5{

	//Verify no priority column, priority sorting, priority filter on UnPosted Logs Page: CIA-90
	@Test
	public void verifyPriorityOnUnpostedLogs() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint5, "VerifyPriorityOnUnpostedLogs");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriorityOnUnpostedLogs";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Priority column")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityColumnOnUnpostedLogsPage("VerifyPriorityOnUnpostedLogs", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Sorting")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPrioritySortOnUnpostedLogsPage("VerifyPriorityOnUnpostedLogs", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Filter")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFilterOnUnpostedLogsPage("VerifyPriorityOnUnpostedLogs", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no clone/copied column, field on DocketHistory Page: CIA-90
	@Test
	public void verifyClonedCopiedOnDocketHistory() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint5, "VerifyClonedCopiedDocketHistory");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyClonedCopiedDocketHistory";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Cloned/Copied from field")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedFieldOnDocketHistoryPopUpPage("VerifyClonedCopiedDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied from column")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedColumnOnDocketHistoryPage("VerifyClonedCopiedDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

}
