package com.arrow.ciox.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_CIOXSprint3;

public class Sprint3 extends BusinessFunctions_CIOXSprint3{

	//Verify ML Slider is displayed with data on Create WorkSheet Page: Transmittal ML Slider
	@Test
	public void verifyMLSliderForWorksheetCreation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint3, "MLSliderWorksheetCreate");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "MLSliderWorksheetCreate";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					//This will mark the beginning of row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Started");

					//This method will log into the Application
					SignIn(strTeam, strMember);

					//Test case 1: Verify ML Slider is displayed with data on Create Worksheet Page
					String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					verifyMLSliderWithDataForWorksheetCreation(SheetName, iLoop, esopId);

					parent.appendChild(child);
					//This will mark end of the one row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Verify ML Slider is displayed with data on Edit WorkSheet Page: Transmittal ML Slider
	@Test
	public void verifyMLSliderForWorksheetEdit() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint3, "MLSliderWorksheetEdit");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "MLSliderWorksheetEdit";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					//This will mark the beginning of row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Started");

					//This method will log into the Application
					SignIn(strTeam, strMember);

					//Test case 1: Verify ML Slider is displayed with data on Edit Worksheet Page
					verifyMLSliderWithDataForWorksheetEdit(SheetName, iLoop);

					parent.appendChild(child);
					//This will mark end of the one row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Verify ML Slider is displayed with data on Review WorkSheet Page: Transmittal ML Slider
	@Test
	public void verifyMLSliderForWorksheetReview() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint3, "MLSliderWorksheetReview");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "MLSliderWorksheetReview";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					//This will mark the beginning of row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Started");

					//This method will log into the Application
					SignInFromSOPSupportTeam();

					//Test case 1: Verify ML Slider is displayed with data on Review Worksheet Page
					verifyMLSliderWithDataForWorksheetReview(SheetName, iLoop);

					parent.appendChild(child);
					//This will mark end of the one row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Verify elements and draggable fields on Manage ML Slider Fields page: Transmittal ML Slider
	@Test
	public void verifyAdminMLSlider() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint3, "AdminMLSlider");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AdminMLSlider";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					//This will mark the beginning of row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Started");

					//This method will log into the Application
					SignIn(strTeam, strMember);

					//Test case 1: Verify elements and draggable fields on Manage ML Slider Fields page
					verifyAdminMLSliderPage(SheetName, iLoop);

					parent.appendChild(child);
					//This will mark end of the one row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Verify no QuickLog button is present  on Create WorkSheet Page: Retiring QuickLog
	@Test
	public void verifyNoQuicklogBtnOnCreateWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint3, "NoQuicklogOnCreateWorksheet");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "NoQuicklogOnCreateWorksheet";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					//This will mark the beginning of row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Started");

					//This method will log into the Application
					SignIn(strTeam, strMember);

					//Test case 1: Verify no Quicklog button is present  on Create Worksheet Page
					String esopId = entitySectionDetailsOnProcessingCES(SheetName, iLoop);
					verifyNoQuicklogOnCreateWorksheet(SheetName, iLoop, esopId);

					parent.appendChild(child);
					//This will mark end of the one row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}

	//Verify if the status of existing worksheet is  Quicklog  
	//then on editing the worksheet no quicklog button should be present: Retiring QuickLog
	@Test
	public void verifyEditedQuicklogStatusWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint3, "EditedQuicklogStatus");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EditedQuicklogStatus";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);

				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					//This will mark the beginning of row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Started");

					//This method will log into the Application
					SignIn(strTeam, strMember);

					//Test case 1: Verify if the status of existing worksheet is  Quicklog  
					//then on editing the worksheet no quicklog button should be present
					verifyEditedQuicklogWorksheet(SheetName, iLoop);

					parent.appendChild(child);
					//This will mark end of the one row in data sheet
					iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}
}
