package com.arrow.ciox.scripts;

import com.arrow.workflows.BusinessFunctions_CIOXSprint4;
import org.testng.annotations.Test;

public class Sprint4 extends BusinessFunctions_CIOXSprint4 {


	//Verify there is no Priority and Multiple Fields on Create Worksheet Page
	@Test
	public void verifyPriorityMultipleFieldsOnCreateWokPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyPriMulOnCreateWok");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriMulOnCreateWok";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Multiple Field Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyPriMulOnCreateWok", iLoop);
						verifyMultipleFieldOnCreateWorksheetPage("VerifyPriMulOnCreateWok", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Priority Field Verification")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyPriMulOnCreateWok", iLoop);
						verifyPriorityFieldOnCreateWorksheetPage("VerifyPriMulOnCreateWok", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify there is no Priority and Multiple Fields on Edit Worksheet Page of Newly Created Worksheets
	@Test
	public void verifyPriorityMultipleFieldsOnEditWokandProfPage() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyPriMulOnEditAndProfWok");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriMulOnEditAndProfWok";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Multiple Field Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyMultipleFieldOnEditandWorksheetProfilePage("VerifyPriMulOnEditAndProfWok", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Priority Field Verification")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFieldOnEditandWorksheetProfilePage("VerifyPriMulOnEditAndProfWok", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify there is confirmation number, customer and individual on Worksheet Popup Page for worksheet type DSSOP: CIA-47
	@Test
	public void verifyWorksheetPopUpPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyWorksheetPopUpPage");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyWorksheetPopUpPage", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyWorksheetPopUpPage", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyWorksheetPopUpPage", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyWorksheetPopUpPage", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyWorksheetPopUpPage", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Worksheet PopUp Page for Worksheet Type")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyWorksheetPopUpPageForWorksheetType("VerifyWorksheetPopUpPage", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no message related text available on all SOP Pages: CIA-48
	@Test
	public void verifyNoMsgTextDisplayOnSOPPages() throws Throwable {

		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyNoMsgTextOnSOP");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyNoMsgTextOnSOP";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Top Message Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyMessageTextOnSOPPage("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("New Messages Left Nav Link Verification")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyNewMessagesLeftNavLink("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Worksheet Profile Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnWorksheetProfile("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Worksheet Create Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyNoMsgTextOnSOP", iLoop);
						verifySendMessageOnWorksheetCreate("VerifyNoMsgTextOnSOP", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Worksheet Edit Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnWorksheetEdit("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Top Message Verification on SOP List")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyMessageOnSOPList("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message Verification on Fedex Package Profile")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnFedexPackageProfile("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Choose DI Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnChooseDIPage("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("No Send Message On Action Items Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySendMessageOnActionItemsPage("VerifyNoMsgTextOnSOP", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify No Send Msg Btn on Worksheet Review Page: CIA-48
	@Test
	public void verifySendMsgOnWorksheetReview() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyNoSendMsgOnReview");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyNoSendMsgOnReview", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyNoSendMsgOnReview", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyNoSendMsgOnReview", "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("No Send Message On Worksheet Review Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						verifySendMessageOnWorksheetReview("VerifyNoSendMsgOnReview", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify when a related log is added to a ces item and user navigates to Create Worksheet Page 
	//then the Initial/Subsequent field is having "Subsequent" radio button as selected by default: CIA-49
	@Test
	public void verifyRelatedLogSubsequent() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyRelatedLogSubsequent");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyRelatedLogSubsequent", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyRelatedLogSubsequent", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyRelatedLogSubsequent", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyRelatedLogSubsequent", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyRelatedLogSubsequent", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Related Log Subsequent Verification")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entityDetailsOnProcessingCESUploadImage("VerifyRelatedLogSubsequent", iLoop);
						verifyRelatedLogSubsequentByDefault("VerifyRelatedLogSubsequent", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify when user adds a log to docket history of an existing log 
	//then the Initial/Subsequent field of existing log should be changed to Subsequent on Worksheet Profile page & Edit Page: CIA-49
	@Test
	public void verifyExistingLogDocketHistory() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyExistingLogDocketHistory");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyExistingLogDocketHistory";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Log Docket History Verification On Worksheet Profile Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyExistingLogOnWorksheetProfilePage("VerifyExistingLogDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Existing Log Docket History Verification On Worksheet Edit Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyExistingLogOnWorksheetEditPage("VerifyExistingLogDocketHistory", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify no priority column, priority sorting, priority filter on My WorkSheets Page: CIA-46
	@Test
	public void verifyPriorityOnMyWorksheetsPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyPriorityOnMyWorksheets");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyPriorityOnMyWorksheets";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Priority Column on My Worksheets Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityColumnOnMyWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Sorting on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPrioritySortOnMyWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Filter on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFilterOnMyWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Column on My Teams Worksheets Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityColumnOnMyTeamsWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Sorting on My Teams Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPrioritySortOnMyTeamsWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Priority Filter on My Teams Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFilterOnMyTeamsWorksheetsPage("VerifyPriorityOnMyWorksheets", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify there is no Priority field on Worksheet Popup Page: CIA-46
	//Verify there is no "Create Quicklog/attempted/rejection/multiple" button on Related Worksheet Search Page 
	//after clicking on Modify Docket History Button on Worksheet Profile Page
	@Test
	public void verifyPriorityFieldWorksheetPopUpPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "NoPriorityOnWorksheetPopUp");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "Member", iLoop);
				String team = Excelobject.getCellData("NoPriorityOnWorksheetPopUp", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Priority Field  on Worksheet PopUp Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyPriorityFieldOnWorksheetPopUpPage("NoPriorityOnWorksheetPopUp", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Create Quicklog/attempted/rejection/multiple button on Related Worksheet Search Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCreateQuicklogBtnOnRelatedWorksheetSearchPage("NoPriorityOnWorksheetPopUp", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify no checkboxes and select all & select none btn on Worksheet Profile Page: CIA-46
	@Test
	public void verifyCheckboxesSelectBtnOnWorksheetProfile() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "NoCheckboxSelectBtnOnWSProfile");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "NoCheckboxSelectBtnOnWSProfile";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Checkboxes on Worksheet Profile")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyCheckboxesOnWorksheetProfilePage("NoCheckboxSelectBtnOnWSProfile", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Select All and Select None Btn on Worksheet Profile")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySelectAllAndSelectNoneBtnOnWorksheetProfilePage("NoCheckboxSelectBtnOnWSProfile", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify no cloned/copied field on newly created Worksheet Profile Pg, Worksheet PopUp Pg: CIA-46
	//Verify no cloned/copied column on My Worksheets & My Teams Worksheets Page
	@Test
	public void verifyClonedCopiedOnWorksheetPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifyClonedCopiedOnWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifyClonedCopiedOnWorksheet";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Cloned/Copied field on Worksheet Profile")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyClonedCopiedOnWorksheet", iLoop);
						verifyClonedCopiedFieldOnNewlyCreatedWorksheetProfilePage("VerifyClonedCopiedOnWorksheet", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied field on Worksheet PopUp")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedFieldOnWorksheetPopUpPage("VerifyClonedCopiedOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied column on My Worksheets grid")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedColumnOnMyWorksheets("VerifyClonedCopiedOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Cloned/Copied column on My Teams Worksheets grid")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyClonedCopiedColumnOnMyTeamsWorksheets("VerifyClonedCopiedOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify default sorting functionality on My worksheet & My teams worksheet pg. is Received Date : CIA-46
	//Verify sorting functionality on My worksheet & My teams worksheet pg. 
	@Test
	public void verifySortingandDefaultSortingOnWorksheetPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint4, "VerifySortingDefaultOnWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
				String SheetName = "VerifySortingDefaultOnWorksheet";
				String testCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String description = Excelobject.getCellData(SheetName, "Description", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String member = Excelobject.getCellData(SheetName, "Member", iLoop);
				String team = Excelobject.getCellData(SheetName, "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Verification of Default Sorting on My Worksheet Page is Received Date")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyDefaultSortingOnMyWorksheetPageIsReceivedDt("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of  Sorting Functionality on My Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySortingOnMyWorksheetPage("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of Default Sorting on My Teams Worksheet Page is Received Date")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyDefaultSortingOnMyTeamsWorksheetPageIsReceivedDt("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Verification of  Sorting Functionality on My Teams Worksheets Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifySortingOnMyTeamsWorksheetPage("VerifySortingDefaultOnWorksheet", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
}
