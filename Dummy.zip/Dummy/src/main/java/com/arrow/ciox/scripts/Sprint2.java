package com.arrow.ciox.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_CIOXSprint2;

public class Sprint2 extends BusinessFunctions_CIOXSprint2 {

	//Verify NOA for WorkSheet Create Page: NOA Cleanup
	@Test
	public void verifyNOAForWorksheetCreation() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAWorksheetCreate");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NOAWorksheetCreate", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NOAWorksheetCreate", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NOAWorksheetCreate", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NOAWorksheetCreate", "Member", iLoop);
				String team = Excelobject.getCellData("NOAWorksheetCreate", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet NOA field updated")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("NOAWorksheetCreate", iLoop);
						String VerifyNOACreateWorksheet = verifyNOAWorksheetCreate("NOAWorksheetCreate", iLoop, esopId);
						System.out.println(VerifyNOACreateWorksheet);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify NOA for WorkSheet Edit Page: NOA Cleanup
	@Test
	public void verifyNOAForWorksheetEdit() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAWorksheetEdit");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "NOAWorksheetEdit";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					String VerifyNOAEditMyWorksheet = verifyNOAWorksheetEdit(SheetName, iLoop);
					System.out.println(VerifyNOAEditMyWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	//Verify NOA for WorkSheet Review Page: NOA Cleanup
	@Test
	public void verifyNOAForWorksheetReview() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAWorksheetReview");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "NOAWorksheetReview";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignInFromSOPSupportTeam();

					String VerifyNOAReviewMyWorksheet = verifyNOAWorksheetReview(SheetName, iLoop);
					System.out.println(VerifyNOAReviewMyWorksheet);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	@Test
	public void verifyCreateWorksheetPage() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "VerifyCreateWorksheetPage");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyCreateWorksheetPage", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyCreateWorksheetPage", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyCreateWorksheetPage", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyCreateWorksheetPage", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyCreateWorksheetPage", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet Page Verifcation")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyCreateWorksheetPage", iLoop);
						verifyUIofCreateWorksheetPage("VerifyCreateWorksheetPage", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Validate Error Message for Create WorkSheet Page
	@Test
	public void createWorksheetErrMsg() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "CreateWorksheetErrMsg");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CreateWorksheetErrMsg", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CreateWorksheetErrMsg", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CreateWorksheetErrMsg", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CreateWorksheetErrMsg", "Member", iLoop);
				String team = Excelobject.getCellData("CreateWorksheetErrMsg", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Create Worksheet Error Msg Validation")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CreateWorksheetErrMsg", iLoop);
						validateErrMsgofCreateWorksheetPage("CreateWorksheetErrMsg", iLoop, esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Validate Error Message for Edit WorkSheet Page
	@Test
	public void editWorksheetErrMsg() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "EditWorksheetErrMsg");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("EditWorksheetErrMsg", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("EditWorksheetErrMsg", "Description", iLoop);
				String runStatus = Excelobject.getCellData("EditWorksheetErrMsg", "RunStatus", iLoop);
				String member = Excelobject.getCellData("EditWorksheetErrMsg", "Member", iLoop);
				String team = Excelobject.getCellData("EditWorksheetErrMsg", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Edit Worksheet Error Msg Validation")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						validateErrMsgofEditWorksheetPage("EditWorksheetErrMsg", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Validate Error Message for Review WorkSheet Page
	@Test
	public void reviewWorksheetErrMsg() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "ReviewWorksheetErrMsg");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("ReviewWorksheetErrMsg", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("ReviewWorksheetErrMsg", "Description", iLoop);
				String runStatus = Excelobject.getCellData("ReviewWorksheetErrMsg", "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Review Worksheet Error Msg Validation")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						validateErrMsgofReviewWorksheetPage("ReviewWorksheetErrMsg", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify NOA for Existing WorkSheet: NOA Cleanup
	@Test
	public void verifyNOAForExistingWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAExistingWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NOAExistingWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NOAExistingWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NOAExistingWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NOAExistingWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("NOAExistingWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Worksheet NOA field updated")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyNOAExistingWorksheet = verifyNOAExistingWorksheet("NOAExistingWorksheet", iLoop);
						System.out.println(VerifyNOAExistingWorksheet);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify NOA for Existing WorkSheet when Edited & Saved: NOA Cleanup
	@Test/*(groups= {"newly"})*/
	public void verifyNOAForExistingWorksheetEditedSaved() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAExistingWorksheetEditedSaved");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "RunStatus", iLoop);
				String member = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "Member", iLoop);
				String team = Excelobject.getCellData("NOAExistingWorksheetEditedSaved", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Worksheet NOA field Edited and Saved")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyNOAExistingWorksheetEditedSaved = verifyNOAExistingWorksheetEditedSaved("NOAExistingWorksheetEditedSaved", iLoop);
						System.out.println(VerifyNOAExistingWorksheetEditedSaved);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify NOA for Existing WorkSheet when Reviewed & Saved: NOA Cleanup
	@Test
	public void verifyNOAForExistingWorksheetReviewedSaved() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint2, "NOAExistingWSReviewedSaved");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("NOAExistingWSReviewedSaved", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("NOAExistingWSReviewedSaved", "Description", iLoop);
				String runStatus = Excelobject.getCellData("NOAExistingWSReviewedSaved", "RunStatus", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Existing Worksheet NOA field Reviewed and Saved")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignInFromSOPSupportTeam();
						verifyNOAExistingWorksheetReviewedSaved("NOAExistingWSReviewedSaved", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
}

