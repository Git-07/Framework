package com.arrow.ciox.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_CIOXSprint8;

public class Sprint8 extends BusinessFunctions_CIOXSprint8{

	//Verify CES Internal Comments & Internal Comments functionality Create WorkSheet Page: CIA-126
	@Test/*(groups= {"newly"})*/
	public void verifyCESInternalCommentsForWorksheetCreation() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint8, "CESICWorksheetCreate");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CESICWorksheetCreate", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CESICWorksheetCreate", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CESICWorksheetCreate", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CESICWorksheetCreate", "Member", iLoop);
				String team = Excelobject.getCellData("CESICWorksheetCreate", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("CES Internal Comments Displayed in static window of Create WorkSheet Page")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String VerifyCESInternalCommentsCreateWorksheet = verifyCESInternalCommentsWorksheetCreate("CESICWorksheetCreate", iLoop);
						System.out.println(VerifyCESInternalCommentsCreateWorksheet);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Add New Internal Comments and Save")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CESICWorksheetCreate", iLoop);
						String NewInternalComments = verifyAddedInternalCommentsForCreateWorksheetPage("CESICWorksheetCreate", iLoop, esopId);
						System.out.println(NewInternalComments);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}

				}
			}
		}catch(Exception e) {}
	}

	//Verify CES Internal Comments & Internal Comments functionality Edit WorkSheet Page: CIA-126
	@Test
	public void verifyCESInternalCommentsForWorksheetEdit() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint8, "CESICWorksheetEdit");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CESICWorksheetEdit", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CESICWorksheetEdit", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CESICWorksheetEdit", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CESICWorksheetEdit", "Member", iLoop);
				String team = Excelobject.getCellData("CESICWorksheetEdit", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("CES Internal Comments and Internal Comments for Edit WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CESICWorksheetEdit", iLoop);
						String newIntrnalComments = verifyAddedInternalCommentsForCreateWorksheetPage("CESICWorksheetEdit", iLoop, esopId);
						String WorksheetId = verifyCESInternalCommentsForWorksheetEditPage("CESICWorksheetEdit", iLoop, newIntrnalComments);
						System.out.println(WorksheetId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	//Verify CES Internal Comments & Internal Comments functionality Review WorkSheet Page: CIA-126
	@Test
	public void verifyCESInternalCommentsForWorksheetReview() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint8, "CESICWorksheetReview");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("CESICWorksheetReview", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CESICWorksheetReview", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CESICWorksheetReview", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CESICWorksheetReview", "Member", iLoop);
				String team = Excelobject.getCellData("CESICWorksheetReview", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("CES Internal Comments and Internal Comments for Review WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("CESICWorksheetReview", iLoop);
						String newIntrnalComments = verifyAddedInternalCommentsForCreateWorksheetPage("CESICWorksheetReview", iLoop, esopId);
						String WorksheetId = verifyCESInternalCommentsForWorksheetReviewPage("CESICWorksheetReview", iLoop, newIntrnalComments);
						System.out.println(WorksheetId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Pdf, IFrame functionality for Create Worksheet Page: CIA-6 & CIA-123
	@Test
	public void verifyPdfIFrameFunctionalityForCreateWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint8, "VerifyPdfCreateWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyPdfCreateWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyPdfCreateWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyPdfCreateWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyPdfCreateWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyPdfCreateWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Pdf IFrame Functionalty for Create WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String esopId = entitySectionDetailsOnProcessingCES("VerifyPdfCreateWorksheet", iLoop);
						String VerifyPdfIFrameCreateWorksheet = verifyPdfIFrameWorksheetCreate("VerifyPdfCreateWorksheet", iLoop, esopId);
						System.out.println(VerifyPdfIFrameCreateWorksheet);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Pdf, IFrame functionality for Edit Worksheet Page: CIA-6 & CIA-123
	@Test
	public void verifyPdfIFrameFunctionalityForEditWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint8, "VerifyPdfEditWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyPdfEditWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyPdfEditWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyPdfEditWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyPdfEditWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyPdfEditWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Pdf IFrame Functionalty for Edit WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						String verifyPdfIFrameWorksheetEdit = verifyPdfIFrameWorksheetEdit("VerifyPdfEditWorksheet", iLoop);
						System.out.println(verifyPdfIFrameWorksheetEdit);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}

	// Verify Pdf, IFrame functionality for Review Worksheet Page: CIA-6 & CIA-123
	@Test
	public void verifyPdfIFrameFunctionalityForReviewWorksheet() throws Throwable {
		try {		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCIOXSprint8, "VerifyPdfReviewWorksheet");		
			for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
				String testCaseID = Excelobject.getCellData("VerifyPdfReviewWorksheet", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("VerifyPdfReviewWorksheet", "Description", iLoop);
				String runStatus = Excelobject.getCellData("VerifyPdfReviewWorksheet", "RunStatus", iLoop);
				String member = Excelobject.getCellData("VerifyPdfReviewWorksheet", "Member", iLoop);
				String team = Excelobject.getCellData("VerifyPdfReviewWorksheet", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if(testCaseID.contains("Pdf IFrame Functionalty for Review WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						// This method will log into the Application
						SignInFromSOPSupportTeam();
						String verifyPdfIFrameWorksheetReview = verifyPdfIFrameWorksheetReview("VerifyPdfReviewWorksheet", iLoop);
						System.out.println(verifyPdfIFrameWorksheetReview);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Back To CRM Functionalty for Review WorkSheet Page")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);
						verifyBackToCRMButttonForReviewWorksheetPage("VerifyPdfReviewWorksheet", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		}catch(Exception e) {}
	}
}
