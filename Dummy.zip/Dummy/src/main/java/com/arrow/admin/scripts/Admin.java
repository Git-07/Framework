package com.arrow.admin.scripts;

import org.testng.annotations.Test;
import com.arrow.workflows.BusinessFunctions_Admin;

public class Admin extends BusinessFunctions_Admin {

	// User successfully logs in Creats a role & deletes it
	@Test
	public void createAndDeleteRole() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "CreateAndDeleteRole");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreateAndDeleteRole";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					createAndDeleteRole(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User successfully Edits Role
	@Test
	public void editRole() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "EditRole");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EditRole";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					editRole(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login as user with full admin rights- views Role Profile- verifies page
	// specifications- prints- views edit role page.
	@Test
	public void viewRolePageSpecifications() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "ViewRolePageSpecifications");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ViewRolePageSpecifications";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewRolePageSpecifications(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login usr with full admin rights- views Role Profile page- does filter
	// operation on role usrs vrfis page navigation
	// Login usr wit full admin rights- verify pge specs of Role users pge- verify
	// pge navigation links- verify sort links
	@Test
	public void filterSortPageNavigationOnRolesPage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "FilterSortPageNavigation");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "FilterSortPageNavigation";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					filterSortPageNavigationOnRolesPage(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login user wit full admin rights-goes to Find users pge to serch for usrs to
	// grant roles- verifies pge specs
	// Login as a user with fill admin rights- verify filterrefine operations in
	// Role users page- revokes grant - logout.
	@Test
	public void grantAndRevokeRole() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "GrantAndRevokeRole");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "GrantAndRevokeRole";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					grantAndRevokeRole(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login usr wit full admn rights- does successful serch - verfis pge spec of
	// Emply Search Rslts Scrn verifies filter
	@Test
	public void viewEmployeeSearchResultPageSpecifications() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "ViewEmployeeSearchResultPage");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ViewEmployeeSearchResultPage";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewEmployeeSearchResultPageSpecifications(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login usr wit full admin rights does successful serch verifies pge specs of
	// Emply Grants page verifies filter sort
	@Test
	public void viewGrantsPageSpecifications() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "ViewGrantsPageSpecifications");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ViewGrantsPageSpecifications";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewGrantsPageSpecifications(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login usr wit full admn privileges verifies page specs of emply serch- perfms
	// serch on Team Type, User group and Employee Name
	@Test
	public void empSearchUserGroup() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "EmployeeUserGroup");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EmployeeUserGroup";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					empSearchUserGroup(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Login usr wit full admin rights does successful serch verifies pge specs of
	// Emply Grants page verifies filter sort
	@Test
	public void grantsSortBy() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "EmployeeUserGroup");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EmployeeUserGroup";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					grantsSortBy(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Verify E1 Refresh Message Q with completed Status
	@Test
	public void e1RefreshMessageQ() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "E1RefreshMessageQ");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "E1RefreshMessageQ";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					e1RefreshMessageQ(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Verify Global Intake Time can be added and deleted
	@Test
	public void globalIntakeTime() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "GlobalIntakeTime");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "GlobalIntakeTime";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					globalIntakeTime(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Darn Test Case
	// Verify a new section called 'DE AR Notifications' is added on left side blue
	// pannel for users having permissions
	@Test
	public void verifyDEARNotificationsSection() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "VerifyDEARNotificationsSection");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "VerifyDEARNotificationsSection";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					verifyDEARNotificationsSection(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Darn Test Case
	// Verify user having admin permissions is only able to access de ar
	// notifications section
	@Test
	public void adminPermission() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "AdminPermission");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AdminPermission";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					if (strTestCaseID.contains("A new checkbox called 'Delaware AR Admin' is added")) {
						deARNotificationsPermissionOnRolesPage(SheetName, iLoop);
					} else if (strTestCaseID.contains("Admin having Permission")) {
						adminHavingPermissions(SheetName, iLoop);
					} else {
						adminNotHavingPermissions(SheetName, iLoop);
					}
					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Darn Test Case
	// Upload Files on File and Event Selection Page
	@Test
	public void fileUploadFunctionality() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "FileUploadFunctionality");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "FileUploadFunctionality";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					if (strTestCaseID.contains("1 KB")) {
						fileAndEventSelectionPageUploadFunctionality(SheetName, iLoop);
					} else if (strTestCaseID.contains("0 KB")) {
						fileAndEventSelectionPageUploadFunctionality(SheetName, iLoop);
					} else if (strTestCaseID.contains("invalid File")) {
						fileAndEventSelectionPageUploadFunctionality(SheetName, iLoop);
					} else if (strTestCaseID.contains("less than 150 MB")) {
						fileAndEventSelectionPageUploadFunctionality(SheetName, iLoop);
					} else if (strTestCaseID.contains("greater than 150 MB")) {
						fileAndEventSelectionPageUploadFunctionality(SheetName, iLoop);
					}

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Darn Test Case
	// Verify Grid Functionality Of File and Event Selection Page
	@Test
	public void fileGridFunctionality() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "GridFunctionality");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "GridFunctionality";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					fileAndEventSelectionPageGridFunctionality(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Darn Test Case
	// Add,Edit and delete event on Event Manager Page
	@Test
	public void addEditDeleteEvent() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "AddEditDeleteEvent");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AddEditDeleteEvent";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					addEditDeleteEvent(SheetName, iLoop);
					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Darn Test Case
	// Verify Add Functionality On Event Manager Page
	@Test
	public void filesUploadOnOutputFilesPage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "FileUpload");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "FileUpload";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					if (strTestCaseID.contains("more than 0 kb")) {
						filesUploadOnOutputFilesPage(SheetName, iLoop);
					} else if (strTestCaseID.contains("0 KB File")) {
						filesUploadOnOutputFilesPage(SheetName, iLoop);
					} else if (strTestCaseID.contains("invalid File")) {
						filesUploadOnOutputFilesPage(SheetName, iLoop);
					}
					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// NPD Sprint 3: verify if ML Slider is displayed in CES screen
	@Test
	public void adminCESMLSlider() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "AdminCESMLSlider");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AdminCESMLSlider";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);

				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// Test case 1: Verify CES select button is displayed if CES Enabled is set to
					// Yes
					adminCESMLSliderPage(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}
			} catch (Exception e) {
				catchBlock(e);
			}
		}

	}

	// NPD Sprint 13- Edit existing entity bundle
	@Test
	public void editEntityBundle() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "Plus Disbursement");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "Plus Disbursement";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					if (strTestCaseID.contains("DS Checkbox on Entity Edit and Profile page")) {
						editEntityBundle(SheetName, iLoop);
					} else if (strTestCaseID.contains("DS Checkbox on Sub Group Profile Page")) {
						editSubGroupBundle(SheetName, iLoop);
					}

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// NPD Sprint 13- verification of Bundles Disbursements Maintenance
	@Test
	public void addBundleDisbursement() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "AddBundleDisbursement");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AddBundleDisbursement";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					addBundleDisbursement(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	//Below Test method is added as part of CES enhancement Rejection workflow changes
	//As part of Sprint 49 this was decided to move this application to SOP page. Hence the test method is added 
	//under SOP
	//@Test
	public void rejectionRulesMaintenanceApplication() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "RulesMaintenanceApp");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("RulesMaintenanceApp", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("RulesMaintenanceApp", "Description", iLoop);
				String runStatus = Excelobject.getCellData("RulesMaintenanceApp", "RunStatus", iLoop);
				String member = Excelobject.getCellData("RulesMaintenanceApp", "Member", iLoop);
				String team = Excelobject.getCellData("RulesMaintenanceApp", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rule")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceApplication("RulesMaintenanceApp", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//Below Test Method is added as part of CES enhancement Rejection workflow
	@Test
	public void rejectionRulesUpdateAndValidate() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "RulesUpdate");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("RulesUpdate", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("RulesUpdate", "Description", iLoop);
				String runStatus = Excelobject.getCellData("RulesUpdate", "RunStatus", iLoop);
				String member = Excelobject.getCellData("RulesUpdate", "Member", iLoop);
				String team = Excelobject.getCellData("RulesUpdate", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rule")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						selectTheJurisdictionAndEdit("RulesUpdate", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//Below Test Method is added as part of CES enhancement Rejection workflow
	@Test
	public void sopRejectionRulesMaintenanceApplicationAccess() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookAdmin, "RulesMaintenanceAppAccess");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("RulesMaintenanceAppAccess", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("RulesMaintenanceAppAccess", "Description", iLoop);
				String runStatus = Excelobject.getCellData("RulesMaintenanceAppAccess", "RunStatus", iLoop);
				String member = Excelobject.getCellData("RulesMaintenanceAppAccess", "Member", iLoop);
				String team = Excelobject.getCellData("RulesMaintenanceAppAccess", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rules Maintenance Role")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceRole("RulesMaintenanceAppAccess",iLoop); 
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					} else if (testCaseID.contains("Application access")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceAccess("RulesMaintenanceAppAccess",iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
