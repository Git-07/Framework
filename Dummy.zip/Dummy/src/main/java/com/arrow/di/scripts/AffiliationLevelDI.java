package com.arrow.di.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_AffiliationLevelDI;

public class AffiliationLevelDI extends BusinessFunctions_AffiliationLevelDI{
	
	//User logs in and Views DI History list for an Affiliated entity
		 @Test
		public void formerDIs() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookAffiliationLevelDI, "FormerDIs");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "FormerDIs";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						formerDIs(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		
		 //AffiliationLevelDI
			@Test
			public void forNewSubgroupUpdateTheRenewalDIAutoRenewStatusToActive() throws Throwable {
				try {
					inputSheet = Excelobject.getSheetObject(TestDataWorkBookAffiliationLevelDI, "AutoRenewRenewalDI");	
					for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
						String testCaseID = Excelobject.getCellData("AutoRenewRenewalDI", "TestCase-ID", iLoop);
						String description = Excelobject.getCellData("AutoRenewRenewalDI", "Description", iLoop);
						String runStatus = Excelobject.getCellData("AutoRenewRenewalDI", "RunStatus", iLoop);
						String member = Excelobject.getCellData("AutoRenewRenewalDI", "Member", iLoop);
						String team = Excelobject.getCellData("AutoRenewRenewalDI", "Team", iLoop);					
						if (runStatus.trim().equalsIgnoreCase("Y")) {	
							 if (testCaseID.contains("Create A Renewal Subgroup and Update the Renewal DI")) {
								  child = extent.startTest(testCaseID, description);
								  iterationReport(iLoop , testCaseID + " Started");
								  SignIn(team, member);
								  searchForTheAffiliation(getTheAffiliationHavingMulitpleInvoices());
								  createRenewalSubgroupAndRenewalDIPaperLessDeliveryMethod();													
								  parent.appendChild(child);
								  iterationReport(iLoop, testCaseID + " Completed");
								  driver.get(URL);
								}
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}		


}
