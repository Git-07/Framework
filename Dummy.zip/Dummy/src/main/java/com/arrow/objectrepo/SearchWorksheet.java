package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class SearchWorksheet {

		public static final By SEARCH_WORKSHEET_LEFT_NAV = By.xpath("//a[contains(text(), 'Worksheet Search')]");
		public static final By WORKSHEET_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Worksheet Search Criteria')]");
		public static final By RECEIVED_DATE = By.id("ctlFromDate_txtDate");
		public static final By WORKSHEET_SEARCH_RESULT = By.xpath("//span[contains(text(), 'Worksheet Search Results')]");
		public static final By CLASSIC_WORKSHEET_SEARCH_RESULT = By.xpath("//span[contains(text(), 'Classic Worksheet Search Results')]");
		public static final By CASE_ID_TEXT = By.id("txtCaseID");
		public static final By LOG_ID_TEXT = By.id("txtLogID");
		public static final By CASE_ID = By.xpath("(//tr[@class='dataGridText']/td[2])[1]");
		public static final By ACTIVE_DATA = By.id("rdoActiveData");
		public static final By ARCHIVE_DATA = By.id("rdoArchiveData");
		public static final By Q2_LEGACY_RADIO_BUTTON = By.id("rbQ2LegacyNo");
		public static final By CLASSIC_SEARCH_BUTTON = By.id("btnClassicSearch");
		public static final By CLASSIC_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Classic Worksheet Search Criteria')]");
		public static final By RELATED_WORKSHEET_SEARCH = By.xpath("//span[contains(text(), 'Related Worksheet Search Results')]");
		public static final By SEARCH_BY_BATCH_NO = By.xpath("//a[contains(text(), 'WS Search by Batch No')]");
		public static final By BATCH_NUMBER = By.id("txtBatchNumber");
		public static final By BATCH_RECEIVED_DATE = By.id("ctlFromDateBatch_txtDate");
		public static final By BATCH_END_DATE = By.id("ctlToDateBatch_txtDate");
		public static final By WORKSHEET_SEARCH_RESULT_PAGE = By.xpath("//span[contains(text(), 'Worksheet Search Results')]");
		public static final By WORKSHEET_SEARCH_CRITERIA_PAGE = By.xpath("//span[contains(text(), 'Worksheet Search Criteria')]");
		public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");
		public static final By ENTITY_SELECT_BTN = By.id("imgFind");
		public static final By ALERTS_LINK = By.id("grdData_ctl02_hlAlerts");
		public static final By ALERTS_TAB = By.xpath("//td[contains(text(), 'Alerts')]");
		public static final By ALERTS_TEXT = By.xpath("//td[contains(text(), 'test')]");
		
		//Below are the Worksheet Profile Fields
		public static final By BAD_LOG = By.id("lblBadLog");
		public static final By WORKSHEET_TYPE = By.id("lblWorksheetType");
		public static final By CONFIRMATION_NUMBER = By.id("lblConfirmationNumber");
		public static final By CUSTOMER = By.id("lblCustomer");
		public static final By INDIVIDUAL = By.id("lblIndividual");
		public static final By REJECTION_APPROVED = By.id("lblRejectionApproved");
		public static final By ATTEMPTED = By.id("lblAttempted");
		public static final By INITIAL_SUBSEQUENT = By.id("lblStageOfProceedingInd");
		public static final By CONSOLIDATED = By.id("lblConsolidated");
		public static final By MULTIPLE = By.id("lblMultiple");
		public static final By LETTER = By.id("lblLetter");
		public static final By POST_STATUS = By.id("lblPostStatus");
		public static final By DEFENDANT_NAME = By.id("lblDefendantName");
		public static final By AGENCY_TITLE = By.id("lblAgencyTitle");
		public static final By CASE_NUMBER = By.id("lblCaseID");
		public static final By PLAINTIFF = By.id("lblPlaintiffDebtor");
		public static final By METADATA = By.xpath("//td[contains(text(),'NOTE:')]");
		

		//Action Item in worksheet profile
		public static final By ACTION_ITEMS = By.cssSelector("a[href*='SOP_ACTION_ITEMS']");
		public static final By RETAIN_SOP_STATUS = By.xpath("//span[contains(text(),'Retain SOP')]/parent::td/following-sibling::td/child::table//span[contains(text(),'Retained')]");
		public static final By ISOP_STATUS = By.xpath("//span[contains(text(),'ISOP')]/parent::td/following-sibling::td/child::table//span[contains(text(),'Executed')]");
		public static final By ACTION_ITEM_FAILURES = By.cssSelector("a[href*='SOP_ACTION_ITEM_FAILURES']");
		public static final By ACTION_ITEMS_NO_RECORDS = By.id("lblNoRecords");
		public static final By SOP_WORKFLOW = By.id("lblSopWorkflow");
		public static final By WORKSHEET_PROFILE_LINK = By.xpath("//a[contains(text(),'Worksheet Profile')]");
		
}
