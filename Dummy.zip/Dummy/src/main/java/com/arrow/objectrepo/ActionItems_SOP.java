package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class ActionItems_SOP {
	
	//Fields On Sop Worksheet Profile page
		public static final By WORKSHEET_EDIT_BTN = By.id("ctlPageTitle_btnEdit");
		public static final By CHOOSE_DI_BTN = By.id("btnChooseDI");
		
		//Fields on Choose Delivery Instruction Page
		public static final By ACTIONS_LIST_BTN = By.id("btnActionsList");
		
		//Fields on Execute Action Items Page
		public static final By MANAGE_ACTIONS_ITEM_BTN = By.id("btnManageActionItems");
		public static final By EXECUTE_ACTION_ITEMS_PAGE = By.xpath("//span[contains(text(), 'Execute Action Items')]");
		public static final By EXECUTE_BTN = By.xpath("//input[@alt='Execute']");
		//public static final By ISOP_EXECUTE_BTN = By.xpath("//input[@alt='Execute']");
		public static final By ISOP_EXECUTE_BTN = By.id("grdData_ctl03_ctlSOPActionItem_imgExecute");
		public static final By ISOP_UNEXECUTE_BTN = By.id("grdData_ctl03_ctlSOPActionItem_imgUnExecute");
		public static final By UNEXECUTE_BTN = By.id("//input[@alt='Unexecute']");
		public static final By CONTINUE_BTN = By.id("btnContinue");
		public static final By UNEXECUTE_COMMENTS = By.id("txtUnexecuteComments");
		public static final By UNEXECUTE_ACTION_ITEM_BTN = By.id("btnUnexecuteActionItem");
		public static final By SCAN_PAPERS_AND_TRANSMITTAL = By.xpath("//span[contains(text(), 'Scan Papers and Transmittal')]");
		public static final By SOP_PAPERS_AND_TRANSMITTAL = By.xpath("//span[contains(text(), 'SOP Papers with Transmittal')]");
		public static final By ISOP_PENDING_STATUS = By.xpath("//span[@id='grdData_ctl03_ctlSOPActionItem_lblStatus'][contains(text(), 'Pending')]");
		public static final By ISOP_UNEXECUTED_STATUS = By.xpath("//span[@id='grdData_ctl03_ctlSOPActionItem_lblStatus'][contains(text(), 'Unexecuted')]");
		public static final By AIRBORNE_ACTION_ITEM_STATUS = By.xpath("//span[@id='grdData_ctl02_ctlSOPActionItem_lblStatus'][contains(text(), 'Executed')]");
		public static final By EMAIL_ACTION_ITEM_STATUS_PENDING = By.xpath("//span[@id='grdData_ctl03_ctlSOPActionItem_lblStatus'][contains(text(), 'Pending')]");

		public static final By EMAIL_ACTION_ITEM_STATUS_PROCESSED = By.xpath("//span[@id='grdData_ctl03_ctlSOPActionItem_lblStatus'][contains(text(), 'Processed')]");

		//Fields on Manage Action Items Page
		public static final By SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN = By.xpath("//select[@id='drpDeliverable']//option[contains(text(), 'SOP Papers with Transmittal')]");
		public static final By COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN = By.xpath("//select[@id='drpDeliverable']//option[contains(text(), 'Copy of Transmittal')]");
		public static final By FED_EX_INTERNATIONAL_ECONOMY_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Fed Ex International Economy')]");
		public static final By HAND_DELIVERED_BY_CT_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Hand Delivered by CT')]");
		public static final By ISOP_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'ISOP')]");
		public static final By FED_EX_PRIORITY_OVERNIGHT_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Fed Ex Priority Overnight')]");
		public static final By COURIER_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Courier')]");
		public static final By AIRBORNE_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Airborne')]");

		public static final By RECIPIENT_SELECT_BTN = By.id("ctlRecipient_imgFind");
		public static final By RECIPIENT_EMAIL_ID_CHECK = By.xpath("//td[contains(text(), 'qatestr@wolterskluwer.com')][1]");
		public static final By ADDUPDATE_BTN = By.id("imgAddUpdate");
		public static final By ACTION_ITEM_EDIT_BUTTON = By.xpath("//input[@alt='Edit']");
		public static final By ACTION_ITEM_DELETE_BUTTON = By.xpath("//input[@alt='Delete']");
		public static final By EMAIL_DROPDOWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Email')]");
		
		//Fields On Find DI Recipient Page
		public static final By PARTICIPANTNAMEFIELD = By.id("txtParticipantName");
		public static final By FINDBTN = By.id("btnFind");
		public static final By TABLEID = By.id("grdData");
		public static final By SELECTRECIPIENTBTN = By.id("grdData_ctl02_lnkSelect");
		
		//Fields on Delete Action Item
		public static final By INTERNAL_COMMENTS_TEXTBOX = By.id("txtInternalComments");
		public static final By DELETE_ACTION_ITEM_BTN = By.id("btnDeleteActionItem");
		
		//Transmittal
		public static final By PDF_TOOLBAR = By.xpath("//viewer-pdf-toolbar[@id='toolbar']");
		public static final By ACTION_ITEMS_TAB = By.xpath("//a[contains(text(), 'Action Items')]");
		public static final By TRANSMITTAL_BUTTON = By.xpath("//input[@alt='Transmittal']");
		public static final By TRANSMITTAL_PDF = By.id("aligner");
		public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");

		//My Actions Item
		public static final By ACTION_ITEMS_PAGE = By.xpath("//span[contains(text(), \"Action Items\")]");
		public static final By MY_ACTION_ITEMS = By.xpath("//a[contains(text(), 'My Action Items')]");
		public static final By MY_ACTION_ITEMS_TAB = By.xpath("//td[contains(text(), 'My Action Items')]");
		public static final By MY_TEAMS_ACTION_TAB = By.xpath("//a[contains(text(), \"My Team's Action Items\")]");
		public static final By POST_LOG_BTN = By.id("btnPostLog");

		
}
