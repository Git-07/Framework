package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class ActionItemsFailure {
	
	public static final By ACTION_ITEM_FAILURES = By.cssSelector("a[href*='SOP_ACTION_ITEM_FAILURES']");
	public static final By ACTION_ITEM_FAILURE_PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By SORT_BY = By.xpath("//span[contains(text(),'Sort by')]");
	public static final By RECEIVED_DATE_SORT = By.xpath("//span[contains(text(),'Received Date')]");
	public static final By ERROR_REASON_SORT = By.xpath("//a[contains(text(),'Error Reason')]");
	public static final By ASSIGNED_TO_SORT = By.xpath("//a[contains(text(),'Assigned To')]");
	public static final By BRANCH_PLANT_SORT = By.xpath("//a[contains(text(),'Branch Plant')]");
	public static final By EXPORT_BUTTON = By.id("ctlPageTitle_btnExport");
	public static final By HELP_PAGE_ICON = By.xpath("//img[@src='/public/images/btn_Help.gif']");
	public static final By CURRENT_FILTER = By.xpath("//span[contains(text(),'Current filter')]");

}
