package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Login {
	public static final By LOGINBTN = By.id("btnLogin");
	public static final By TEAMDROPDOWN = By.id("drpServiceTeam");
	public static final By MEMBERDROPDOWN = By.id("drpMember");
	public static final By TEAM_DROPDOWN = By.xpath("(//select[@id='drpServiceTeam']/option[contains(text(), 'SOP Support Team')])[2]");
	public static final By MEMBER_DROPDOWN = By.xpath("//select[@id='drpMember']/option[contains(text(), 'Amy McLaren')]");
	
	//Below is added for the login for the SOP Hub Login 	
	public static final By USER_NAME = By.id("userId");
	public static final By PASSWORD = By.id("password");
	public static final By INDIVIDUAL_FIRST_NAME = By.id("indFirstName");
	public static final By INDIVIDUAL_LAST_NAME = By.id("indLastName");
	public static final By LOGIN = By.xpath("//button[@type='submit']");
	public static final By SEARCH = By.xpath("//button[contains(text(),'Search')]");
	public static final By WK_ICON = By.xpath("//span[@class='wk-icon-contact-outline']");
	public static final By LOG_OUT = By.id("btnLogout");
	public static final By CONFIRM_LOG_OUT = By.id("btnConfirmLogout");
	public static final By CUSTOMER_NAME_TEXT_BOX = By.id("customerName");

	
	//Below is added for the Level 1,2 login members
	public static final By LEVEL1_MEMBER_DROPDOWN = By.xpath("//select[@id='drpMember']/option[contains(text(), 'Dacia Jamison')]");
	public static final By LEVEL2_MEMBER_DROPDOWN = By.xpath("//select[@id='drpMember']/option[contains(text(), 'Allegra Garland')]");
	public static final By ALABAMA_TEAM_DROPDOWN = By.xpath("//select[@id='drpServiceTeam']/option[contains(text(), 'Alabama CT Reps')]");
	public static final By ALABAMA_MEMBER_DROPDOWN = By.xpath("//select[@id='drpMember']/option[contains(text(), 'Jimmy Barnes')]");
	public static final By GLOBAL_TEAM_DROPDOWN = By.xpath("(//select[@id='drpServiceTeam']/option[contains(text(), 'Global Operations Team - India')])[2]");
	public static final By GLOBAL_MEMBER_DROPDOWN = By.xpath("//select[@id='drpMember']/option[contains(text(), 'Mukesh Agarwal')]");

	
}
