package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Alerts {
	
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");

	// Elements on Alerts Page
	public static final By ALERTS_TEXTFIELD = By.id("txtAlert");
	public static final By CALENDAR = By.id("ctrlDateSelectorEndDate_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By ADDUPDATE_BTN = By.id("btnAddUpdate");
	public static final By ALL_STATE = By.xpath("//select[@id='drpState']//option[contains(text(), 'All')]");
	public static final By ALL_AUDIENCE = By.xpath("//select[@id='drpAudience']//option[contains(text(), 'All')]");
	public static final By ALABAMA_STATE = By.xpath("//select[@id='drpState']//option[contains(text(), 'ALABAMA')]");
	public static final By PROMPT_BRFORE_EXPIRATION_RADIO_BTN = By.id("rdoPromptBeforeExpiration");
	public static final By EXPIRATION_ON_END_DATE_RADIO_BTN = By.id("rdoExpireOnEndDate");

	// Elements on My Expiring Alerts page
	public static final By FIRST_EXTEND_BUTTON = By.id("grdData_ctl02_lnkExtend");
	public static final By FIRST_EXPIRE_BUTTON = By.id("grdData_ctl02_lnkExpire");
	public static final By STATE_FIRST_FILTER = By.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'State')]");
	public static final By ALL_SECOND_FILTER = By.xpath("//select[@id='ctlFilterBar_lstRHS']//option[contains(text(), 'All')]");
	public static final By AUDIENCE_FIRST_FILTER = By.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Audience')]");

	// Sort By Links on My Expiring Alerts page
	public static final By ALERT_TYPE_SORTBY_LINK = By.linkText("Alert Type");
	public static final By STATE_SORTBY_LINK = By.linkText("State");
	public static final By AUDIENCE_SORTBY_LINK = By.linkText("Audience");
	public static final By END_DATE_SORTBY_LINK = By.linkText("End Date");
	public static final By ALERT_LINK_BOLD = By.xpath("//span[@class='sortBy']//span[contains(text(), 'Alert Type')]");
	public static final By STATE_LINK_BOLD = By.xpath("//span[@class='sortBy']//span[contains(text(), 'State')]");
	public static final By AUDIENCE_LINK_BOLD = By.xpath("//span[@class='sortBy']//span[contains(text(), 'Audience')]");
	public static final By END_DATE_LINK_BOLD = By.xpath("//span[@class='sortBy']//span[contains(text(), 'End Date')]");

	// Pagination Links on My Expiring Alerts page
	public static final By FIRST_LINK = By.xpath("//span[@class='listNavigation']//a[contains(text(), 'First')]");
	public static final By PREVIOUS_LINK = By.xpath("//span[@class='listNavigation']//a[contains(text(), 'Previous')]");
	public static final By NEXT_LINK = By.xpath("//span[@class='listNavigation']//a[contains(text(), 'Next')]");
	public static final By LAST_LINK = By.xpath("//span[@class='listNavigation']//a[contains(text(), 'Last')]");
	public static final By NUMBER_LINK = By.xpath("//span[@class='listNavigation']//a[contains(text(), '11-1')]");

	// Filter dropdown elements on My Expiring Alerts page
	public static final By ALERT_FILTER_DROPDOWN1 = By.id("ctlFilterBar_lstF");
	public static final By ALERT_FILTER_DROPDOWN2 = By.id("ctlFilterBar_lstRHS");
	public static final By ALERT_FILTER_DROPDOWN3 = By.id("ctlFilterBar_lstOp");
	public static final By ALERT_FILTER_TEXTFIELD = By.id("ctlFilterBar_txtRHS");
	public static final By ALERT_FILTER_GO_BTN = By.id("ctlFilterBar_btnGo");
	public static final By ALERT_FILTER_CLEAR_BTN = By.id("ctlFilterBar_btnClear");

	// Elements on Extend Alerts page
	public static final By NEW_END_DATE_FIELD = By.id("ctrlDateSelectorNewEndDate_txtDate");
	public static final By ALERTS_SAVE_BTN = By.id("btnSave");
	public static final By ALERTS_CANCEL_BTN = By.id("btnCancel");
	public static final By STATE_LABEL_VALUE = By.id("lblState");
	public static final By AUDIENCE_LABEL_VALUE = By.id("lblAudience");

}
