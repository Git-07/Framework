package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class SopHub {
	
	public static final By SELECT = By.xpath("//a[contains(text(),'Select')]");
	public static final By SOP_HUB_LINK = By.xpath("//a[@title='Loading... Please Wait.']/following-sibling::a[contains(text(),'SOP Hub')]");
	public static final By LOG_SEARCH_TEXT_FIELD = By.id("txtBasicSearch");
	public static final By SEARCH_BUTTON = By.id("btnBasicSearch");
	public static final By CT_LOG_NUMBER = By.cssSelector("a[onClick*='ViewSOPDetail']");
	public static final By HOME_BUTTON = By.id("lnkMySOPs");
}
