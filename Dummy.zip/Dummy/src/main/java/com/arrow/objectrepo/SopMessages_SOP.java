package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class SopMessages_SOP {

	// Fields On My Active Messages Tab
	public static final By FIRST_VIEW_BTN_ON_GRID = By.id("grdData_ctl02_btnViewMessage");
	
	//Fields On Messages Page
	public static final By MESSAGES_PAGE_TITLE = By.xpath("//td[@class='pageTitle']//span[contains(text(), 'Messages')]");
	public static final By MY_TEAMS_ACTIVE_MESSAGES_TAB = By.id("lnkMyTeamActiveMessages");
	public static final By MY_MESSAGE_HISTORY_TAB = By.id("lnkMyHistoryMessages");
	public static final By MY_TEAMS_MESSAGE_HISTORY_TAB = By.id("lnkMyTeamHistoryMessages");


	// Fields on View Message Page
	public static final By BACK_TO_MESSAGES_BTN = By.id("btnBackToMessages");
	public static final By REPLY_BTN = By.id("btnReply");
	public static final By CLOSE_CONVERSATION_BTN = By.id("btnClose");
	public static final By SEND_NEW_MESSAGES_BTN = By.id("btnStart");


	//Fields On Reply Message Page
	public static final By REPLY_MESSAGE_PAGE_TITLE = By.xpath("//td[@class='pageTitle']//span[contains(text(), 'Reply Message')]");
	public static final By BACK_BTN = By.id("btnBack");
	
	//Fields On Create Message Page
	public static final By CREATE_MESSAGE_PAGE_TITLE = By.xpath("//td[@class='pageTitle']//span[contains(text(), 'Create Message')]");

	

}
