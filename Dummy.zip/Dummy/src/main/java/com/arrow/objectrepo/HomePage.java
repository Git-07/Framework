package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class HomePage {
	public static final By ENTITYLINKTOPNAV = By.xpath("//a[@href='javascript:__doPostBack('ctlHeader$topNavBar','ENTITY')']");
	public static final By WELCOMETOARROW =By.xpath("//img[@src='/public/images/img_Welcome.jpg']");
	public static final By AFFILIATIONSEARCHLINK = By.linkText("Affiliation Search");
	public static final By SOPLISTLINK = By.linkText("SOP List");
	public static final By ENTITY_SEARCH_LINK = By.linkText("Entity Search");
	public static final By USOP_LINK_TOP_NAV = By.xpath("//img[@alt='USOP']");
	public static final By ADMINLINK = By.xpath("//*[@alt=\"Admin\"]");
	public static final By ADMIN_LINK_ON_TOP_NAV = By.xpath("//img[@alt='Admin']");
	public static final By CUSTOMER_TOP_NAV = By.xpath("//img[@alt='Customer']");
	public static final By CARRIER_PACKAGE_SEARCH_LINK = By.linkText("Carrier Package Search");
	public static final By CREATE_WORKSHEET_LINK = By.id("btnCreateWS");
	public static final By SOPLINK = By.xpath("//img[@alt='SOP']");
	public static final By CRM_LINK = By.xpath("//img[@alt='CRM']");
	public static final By MY_WORKSHEET_LINK = By.xpath("//a[contains(text(), 'My Worksheets')]");
	public static final By SOP_LIST_LINK = By.xpath("//a[contains(text(), 'SOP List')]");
	public static final By WORKSHEET_SEARCH_LINK = By.xpath("//a[contains(text(), 'Worksheet Search')]");
	public static final By MY_ACTIONS_ITEMS = By.xpath("//a[contains(text(), \"My Action Items\")]");
	public static final By COMM_WORKSHEET_SEARCH_LINK = By.xpath("(//a[contains(text(), 'Worksheet Search')])[2]");
	public static final By RENEWAL_INVOICE_SEARCH_LINK = By.linkText("Renewal/XSOP Invoice Search");
	public static final By PARTICIPANT_SEARCH_LINK = By.linkText("Participant Search");
	public static final By INVOICE_TAB = By.xpath("//img[@alt='Invoice']");
	public static final By AFFILIATION_TAB = By.xpath("//img[@alt='Affiliation']");
	public static final By ENTITY_TAB = By.xpath("//img[@alt='Entity']");
	public static final By EM_TOP_NAV = By.linkText("EM");
	public static final By RENEWAL_XSOP_PSOP_INVOICE  = By.xpath("//li[@class='quickLinksSection']/following-sibling::li/a[@href='Renewal/Ren_InvoiceSearch.aspx']");
    public static final By ARROW_IMAGE = By.xpath("//img[@src='/public/images/img_Logo.gif']");
    public static final By MY_WORKSHEET_TO_REVIEW_LINK = By.xpath("//a[contains(text(), 'My Worksheets to Review')]");
    public static final By AFFILIATION_TAB_HOME_PAGE = By.cssSelector("[alt='Affiliation']");
    
}
