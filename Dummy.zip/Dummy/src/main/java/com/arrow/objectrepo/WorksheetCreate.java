package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class WorksheetCreate {

	//Worksheet Creation Search Page 1
	public static final By RADIO_BUTTON_CASE = By.id("rdoCase");
	public static final By CASE_TEXT = By.id("txtCase");
	public static final By RADIO_BUTTON_PLAINTIFF  = By.id("rdoPlaintiff");
	public static final By PLAINTIFF_TEXT = By.id("txtPlaintiff");
	//Entity Select and Cancel Button
	public static final By RADIO_ENTITY_SELECT = By.id("rdoArrowEntity");
	public static final By RADIO_REP_SELECT = By.id("rdoArrowRepresentation");
	public static final By ENTITY_SELECT = By.id("btnSelectEntity");
	public static final By ENTITY_NAME_SEARCH = By.xpath("//span[contains(text(), 'Entity Name Search Criteria')]");
	public static final By ENTITY_CANCEL = By.id("txtPlaintiff");
	public static final By ENTITY_SEARCH = By.id("btnSearch");	

	
	//Rep Select and Cancel Button
	public static final By REP_SELECT = By.id("btnSelectRepresentation");
	public static final By REP_UNIT_PAGE = By.xpath("//span[contains(text(), 'Representation Units')]");
	public static final By REP_CANCEL = By.id("txtPlaintiff");	
	public static final By REMARKS = By.id("drpRemarks");
	public static final By ATTEMPTED_NO = By.id("rdoAttemptedNo");
	public static final By REMARKS_FIRST_OPTION = By.xpath("//select[@id='drpRemarks']/option[2]");
	public static final By INTERNAL_COMMENTS = By.id("drpInternalComments");
	public static final By INTERNAL_COMMENTS_FIRST_OPTION = By.xpath("//select[@id='drpInternalComments']/option[2]");
	public static final By USE_THIS_ATTORNEY = By.id("rdoAttorney");
	public static final By ADDRESS_NONE_SPECIFIED = By.id("rdoAttorneyAddressNone");
	//Worksheet Creation Search Page 2
	public static final By RADIO_BUTTON_COURT = By.id("rdoSelectCourt");
	public static final By COURT = By.id("drpCourt");
	public static final By RADIO_BUTTON_AGENCY = By.id("rdoSelectAgency");
	public static final By AGENCY = By.id("drpAgency");
	public static final By RADIO_BUTTON_SENDER = By.id("rdoAttorneySender");
	public static final By ATTORNEY_OR_SENDER = By.id("drpAttorneySender");
	public static final By DOCUMENT_TYPE = By.id("drpDocumentType");
	public static final By RADIO_BUTTON_ANSWERDATE = By.id("rdoSelectAnswerDate");
	public static final By ANSWER_DATE = By.id("drpAnswerDate");
	public static final By FIRST_ANSWER_DATE = By.xpath("//select[@id='drpAnswerDate']/option[2]");
	public static final By NO_CASE_RADIO_BUTTON = By.id("rdoCaseNoneSpecified");
	public static final By NO_PLAINTIFF_RADIO_BUTTON = By.id("rdoPlaintiffNone");
	//Worksheet Creation Search Page 3
	public static final By LAWSUITE_SUBTYPE = By.id("drpLawsuitSubtype");
	public static final By FIRST_LAWSUITE_SUBTYPE = By.xpath("//select[@id='drpLawsuitSubtype']/option[2]");
	public static final By SPECIAL_CIRCUMSTANCES = By.id("drpSpecialCircum");
	public static final By SPECIAL_CIRCUMSTANCES_NONE = By.xpath("//select[@id='drpSpecialCircum']//option[@value='51001']");
	public static final By NATURE_OF_ACTION = By.id("drpNatureofAction");
	public static final By AMOUNT_DUE = By.id("txtAmountDue");
	public static final By ANSWER_DATE_NONE = By.id("rdoAnswerDateNone");
	public static final By DOCUMENT_TYPE_NOT_SELECTED = By.xpath("//li[contains(text(),'Enter a value for Document Type.')]");
	public static final By ENTER_VALUE_CONSOLIDATED_DEFENDANT = By.xpath("//li[contains(text(),'Enter a value for Consolidated Defendant/Creditor.')]");
//
	
	//Worksheet Profile
	public static final By WORKSHEET_PROFILE = By.xpath("//span[contains(text(), 'SOP Worksheet Profile')]");
	public static final By SOP_DESTINATION = By.xpath("//span[contains(text(), 'Service of Process Destination')]");
	public static final By POST_MARKED_DATE = By.id("ctlDateSelectorPostMarked_txtDate");
	public static final By METHOD_OF_SERVICE = By.xpath("//select[@id='drpMethodofService']//option[@selected='selected']");
	public static final By WORKSHEET_TYPE = By.id("lblWorksheetType");
	public static final By ENTITY_IN_WORKSHEET_PROFILE = By.id("txtEntityName");
	
	//My Worksheet
	public static final By CREATE_WORKSHEET_BUTTON = By.id("btnCreateWorksheet");
	public static final By CREATE_QUICKLOG_BUTTON = By.id("btnCreate");
	public static final By FIRST_SOP_DATA = By.id("grdData_ctl02_lnkLogID");
	public static final By SECOND_SOP_DATA = By.id("grdData_ctl03_lnkLogID");
	public static final By REVIEW_WORKSHEET_BUTTON = By.id("ctlPageTitle_btnReview");
	public static final By FIRST_MY_WORKSHEETS_TO_REVIEW_DATA = By.id("grdMyWorksheetsToReview_ctl02_lnkWorksheetId");

	//SOP List
	public static final By SOP_LIST_PAGE = By.xpath("//span[contains(text(), 'Service Of Process List')]");
	public static final By OLD_SOP_LIST = By.id("lnkOldSopList");
	public static final By VIEW_WORKSHEET = By.xpath("//img[@alt='View']");
	public static final By CREATE_WORKSHEET = By.xpath("//img[@alt='Create Worksheet']");
	public static final By ML_EXTRACTED_DATA = By.xpath("//h4[contains(text(), 'ML Extracted Data')]");
	public static final By CREATE_WORKSHEET_STEP1 = By.xpath("//span[contains(text(), 'Create Worksheet  - Step 1')]");
	public static final By CREATE_WORKSHEET_SINGLE = By.xpath("//span[contains(text(), 'Create Worksheet')]");
	
	//Edit My Worksheet
	public static final By EDIT_WORKSHEET_TITLE = By.xpath("//span[contains(text(), 'Edit Worksheet  - Step 1')]");
	public static final By UNIDENTIFIED_ENTITY = By.id("rdoUnidentifiedEntity");
	public static final By ENTITY_NAME = By.id("txtEntityName");
	public static final By ENTITY_SEARCH_NAME = By.id("txtName");
	public static final By DOMESTIC_JURISDICTION = By.id("ctlEntityJurisSelector_lstJurisdictions");
	public static final By UNIDENTIFIED_REP = By.id("rdoUnidentifiedRep");
	public static final By REP_JURISDICTION = By.id("ctlRepJurisSelector_lstJurisdictions");
	public static final By EDIT_WORKSHEET_SINGLE = By.xpath("//span[contains(text(), 'Edit Worksheet')]");
	public static final By EDITED_ENTITY_NAME = By.xpath("//span[contains(text(), 'Test Entity Name (Alabama)')]");
	public static final By EDITED_REP_JURISDICTION = By.xpath("//span[contains(text(), 'Hawaii')]");
	public static final By EDITED_CASE = By.xpath("//span[contains(text(), 'Test-123-456')]");
	public static final By EDITED_PLAINTIFF = By.xpath("//span[contains(text(), 'Test-Plaintiff / Debtor')]");

	//Internal Comments
	public static final By INTERNAL_COMMENT_IMAGE = By.id("grdCommentData_ctl01_imgComments");
	public static final By INTERNAL_TEXT_COMMENT = By.id("txtInternalComments");
	public static final By ADDED_TEXT_COMMENT = By.xpath("//td[contains(text(), 'MV - Second Review')]");

	//Review
	public static final By REVIEW_BUTTON = By.id("btnReview");
	public static final By REVIEW_COMMENT = By.id("txtComments");
	public static final By ADDED_REVIEW_COMMENT = By.xpath("//span[contains(text(), 'Review for Testing')]");
	
	//Reject
	public static final By REJECT_REASON = By.id("drpRejectReason");
	public static final By REJECT_REASON_FIRST = By.xpath("//select[@id='drpRejectReason']/option[2]");
	public static final By REJECT_DATE = By.id("ctlDateSelectorRejectDate_btnCal");
	public static final By REJECTED_REASON = By.xpath("//span[@id='lblRejectedReason'][contains(text(), 'CT Named in Error')]");
	public static final By REJECTION_PENDING = By.xpath("//span[@id='lblRejectionApproved'][contains(text(), 'Pending')]");
	public static final By REJECT_COMMENTS = By.xpath("//td[contains(text(), 'Rejection approved by manager')]");
	
	//Assinged and Received
	public static final By RECEIVED_BY = By.xpath("//span[@id='lblReceivedBy'][contains(text(), 'TEST New York SOP Team')]");
	public static final By ASSIGNED_TO = By.xpath("//span[@id='lblAssignedTo'][contains(text(), 'TEST New York SOP Team')]");
	public static final By RECEIVED_BY_TEAM = By.xpath("//span[@id='lblReceivedByTeam'][contains(text(), 'CT - New York SOP Team')]");
	public static final By ASSIGNED_TO_TEAM = By.xpath("//span[@id='lblAssignedToTeam'][contains(text(), 'CT - New York SOP Team')]");
	public static final By RECEIVED_BY_GLYPHICON = By.xpath("//span[@class='glyphicon glyphicon-triangle-right']");
	
	public static final By EDIT_RECEIVED_BY_NYFACILITY = By.xpath("//select[@id='drpReceivedByFacility']/option[contains(text(), 'New York Facility 1 (LIS)')]");
	public static final By EDIT_RECEIVED_BY_NYTEAM = By.xpath("//select[@id='drpReceivedByTeam']/option[contains(text(), 'CT - New York SOP Team')]");
	public static final By EDIT_RECEIVED_BYNY = By.xpath("//select[@id='drpReceivedBy']/option[contains(text(), 'TEST New York SOP Team')]");
	public static final By EDIT_RECEIVED_BY = By.id("drpReceivedBy");
	public static final By EDIT_ASSIGNED_TO = By.id("drpAssignedTo");
	public static final By EDIT_ASSIGNED_TO_FACILITY =By.id("drpAssignedToFacility");
	public static final By EDIT_ASSIGNED_TO_TEAM =By.id("drpAssignedToTeam");
	public static final By SELECT_GLOBAL_PROCESSING_CENTRE =By.xpath("//select[@id='drpAssignedToFacility']/option[contains(text(), 'Global Processing Center')]");
	
	public static final By EDITED_RECEIVED_BY = By.xpath("//span[@id='lblReceivedBy'][contains(text(), 'Nora Dindyal')]");
	public static final By EDITED_ASSIGNED_TO = By.xpath("//span[@id='lblAssignedTo'][contains(text(), 'Nora Dindyal')]");
	public static final By INCOMPLETE_STATUS = By.xpath("//span[@id='ctlStatusBar_lblStatusText'][contains(text(), 'Incomplete')]");

	public static final By MY_WORKSHEET = By.xpath("//a[contains(text(), 'My Worksheets')]");

	public static final By WORKSHEET_PROFILE_ASSIGNMENTHISTORY = By.id("ctlPageTitle_btnSopAssignmentHistory");
	public static final By DOCKET_HISTORY_CES_AUDIT_TRAIL = By.xpath("//td[contains(text(),'CES')]//following-sibling::td[12]");
	public static final By ATTORNEY_WORKSHEET_AUDIT_TRAIL = By.xpath("//td[contains(text(),'Worksheet')]//following-sibling::td[9]");
	public static final By COURT_WORKSHEET_AUDIT_TRAIL = By.xpath("//td[contains(text(),'Worksheet')]//following-sibling::td[10]");
	public static final By PLAINTIFF_WORKSHEET_AUDIT_TRAIL = By.xpath("//td[contains(text(),'Worksheet')]//following-sibling::td[5]");
	public static final By DEFENDANT_WORKSHEET_AUDIT_TRAIL = By.xpath("//td[contains(text(),'Worksheet')]//following-sibling::td[6]");
	
	//Review My Worksheet
	public static final By REVIEW_WORKSHEET_TITLE = By.xpath("//span[contains(text(), 'Review Worksheet')]");

	public static final By FIRST_TRANSMITTAL_BUTTON = By.id("grdData_ctl02_ctlSOPActionItem_imgTransmittal");
	public static final By UNIDENTIFIED_JURIS_GLYPHICON = By.xpath("//label[@for='rdoUnidentifiedRep']/following-sibling::div/span[@class='glyphicon glyphicon-triangle-right']");
	
	public static final By RECEIVED_BY_GLYPHICON_WORKSHEET = By.xpath("//tr[@id='trReceivedBy']//following-sibling::td//span[@class='glyphicon glyphicon-triangle-right']");
    public static final By OTHER_DOC_SERVED_WORKSHEET = By.id("txtOther");
    public static final By ENTER_VALUE_FOR_OTHER_MESSAGE = By.xpath("//li[contains(text(),'Enter a value for Other.')]");

    public static final By EDITED_ASSIGNED_TO_TEAM = By.xpath("//select[@id='drpAssignedToTeam']/option[contains(text(), 'SOP Support Team')]");
    public static final By EDITED_ASSIGN_TO = By.xpath("//select[@id='drpAssignedTo']/option[contains(text(), 'Amy McLaren')]");
    public static final By ASSIGNED_TO_GLYPHICON_WORKSHEET = By.xpath("//tr[@id='trAssignedTo']//following-sibling::td//span[@class='glyphicon glyphicon-triangle-right']");
    public static final By DSSOP_EDIT_RECEIVED_BY = By.xpath("//select[@id='drpReceivedBy']/option[2]");
    public static final By REJECT_REASON_DATE_NOT_SELECTED = By.xpath("//li[contains(text(),'Reject Reason and Reject Date are both mandatory,if either is specified.')]");
	public static final By REJECT_REASON_DATE_SELECTED = By.xpath("//img[@id='ctlDateSelectorRejectDate_btnCal']");
	public static final By ATTEMPTED_REJECTED_WORKSHEET_NOT_SELECTED = By.xpath("//li[contains(text(),'Attempted or Rejected worksheet')]");
	public static final By POST_MARKED_DATE_ERROR = By.xpath("//li[contains(text(),'Enter a value for Post Marked date in mm/dd/yyyy format.')]");
	public static final By POST_MARKED_REASON = By.id("drpPostMarked");
	public static final By CHOOSE_INITIAL_SUBSEQUENT_ERROR = By.xpath("//li[contains(text(),'Choose Initial/Subsequent')]");
    //below element is added as part of Sprint 7 changes 
	public static final By BANKRUPTCY_RADIO_BUTTON_YES = By.id("rdoBankruptcyYes");
	public static final By CONSOLIDATED_RADIO_BUTTON_YES = By.id("rdoConsolidatedYes");

}

