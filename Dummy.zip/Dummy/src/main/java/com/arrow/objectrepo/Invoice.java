package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Invoice {
	//PSOP Invoice Search
	public static final By PSOP_INVOICE_SEARCH = By.xpath("//a[contains(text(),'PSOP Invoice Search')]");
	public static final By PSOP_INVOICE_SEARCH_CRITERIA = By.xpath("//span[@id='ctlPageTitle_lblTitle']");
	public static final By PSOP_INVOICE_SEARCH_HEADER = By.id("ctlContextBar_lblContextTitle");
	public static final By SEARCH_BY = By.xpath("//td[contains(text(),'Search by')]");
	public static final By INVOICE_RADIO_BUTTON_LABEL = By.xpath("//label[@for='rdoInvoiceId']");
	public static final By CUSTOMER_RADIO_BUTTON_LABEL = By.xpath("//label[@for='rdoCustomerId']");
	public static final By SEARCH_TEXT_UNDER_SEARCH_BY = By.xpath("//input[@name='txtID']");
	public static final By INVOICE_STATUS_DROP_DOWN = By.xpath("//td[contains(text(),'Invoice Status')]");	
	public static final By INVOICE_STATUS_VALUE = By.id("lstInvoiceStatus");
	public static final By SERVICE_CENTER_DROP_DOWN = By.xpath("//td[contains(text(),'Service Center')]");
	public static final By SERVICE_TEAM_DROP_DOWN = By.xpath("//td[contains(text(),'Service Team')]");
	public static final By INVOICE_DATE_LABEL = By.xpath("//td[contains(text(),' Invoice Date')]");
	public static final By FROM_LABEL = By.xpath("//span[contains(text(),'From')]");
	public static final By To_LABEL = By.xpath("//span[contains(text(),'To')]");
	public static final By DATE_IN_FROM_LABEL = By.id("ctlFromDate_txtDate");
	public static final By DATE_IN_TO_LABEL = By.id("ctlToDate_txtDate");
	public static final By FROM_LABEL_CALENDAR_ICON = By.id("ctlFromDate_btnCal");
	public static final By TO_LABEL_CALENDAR_ICON = By.id("ctlToDate_btnCal");
	public static final By SEARCH_BUTTON = By.id("btnSearch");
	public static final By INVOICE_ID = By.id("ctlContextBar_lblContextId");
	public static final By GENERATE_DETAIL_REPORT_BUTTON = By.id("ctlPageTitle_btnGenerateDetailReport");
	public static final By SERVICE_CENTER_DROP_DOWN_VALUES = By.id("lstServiceCenter");
	public static final By SERVICE_TEAM_DROP_DOWN_VALUES = By.id("lstServiceTeam");
	public static final By INVOICE_RADIO_BUTTON = By.id("rdoInvoiceId");
	public static final By CUSTOMER_RADIO_BUTTON = By.id("rdoCustomerId");
	public static final By GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST = By.xpath("//img[@alt='Generate Detail Report']");
	public static final By INVOICE_PROFILING_LINK_PSOP_LIST =By.id("grdData_ctl02_lnkLogID");
	public static final By DROP_DOWN_FISRT_OP = By.id("ctlFilterBar_lstOp");
	
	//PSOP Invoice Profile
	public static final By PRINT_BUTTON = By.id("ctlPageTitle_btnPrint");
    public static final By INVOICE_DATA_LABEL = By.xpath("//div[@id='pnlEntityName']/following-sibling::table//td[contains(text(),'Invoice # :')]");
    public static final By INVOICE_DATA_LABEL_AFFI = By.xpath("//div[@id='pnlAffiliationName']/following-sibling::table//td[contains(text(),'Invoice # :')]");
    public static final By INVOICE_DATA_TEXT = By.id("lblInvoice");
    public static final By ENTITY_DATA_LABEL = By.xpath("//tr//td[contains(text(),'Entity :')]");
    public static final By ENTITY_LINK_TEXT = By.id("lnkEntity");
    public static final By AFFILIATION_LINK_TEXT = By.id("lnkAffiliation");
    public static final By OW_ORDER_DATA_LABEL = By.xpath("//tr//td[contains(text(),'OW Order # :')]");
    public static final By INVOICE_STATUS_LABEL = By.xpath("//tr//td[contains(text(),'Invoice Status :')]");
    public static final By RECIPIENT_LABEL = By.xpath("//tr//td[contains(text(),'Recipient :')]");
    public static final By TITLE_LABEL = By.xpath("//tr//td[contains(text(),'Title')]");
    public static final By CUSTOMER_LABEL = By.xpath("//tr//td[contains(text(),'Customer')]");
    public static final By ADDRESS_LABEL = By.xpath("//tr//td[contains(text(),'Address')]");
    public static final By PHONE_LABEL = By.xpath("//tr//td[contains(text(),'Phone')]");
    public static final By FAX_LABEL = By.xpath("//tr//td[contains(text(),'Fax')]");
    public static final By PERIOD_COVERED_LABEL = By.xpath("//tr//td[contains(text(),'PSOP Period Covered :')]");
    public static final By PRINT_DATE_LABEL = By.xpath("//tr//td[contains(text(),'Print Date :')]");
    public static final By RENEWAL_MONTH_LABEL = By.xpath("//tr//td[contains(text(),'Renewal Month :')]");
    public static final By INVOICE_SUMMARY_SECTION = By.xpath("//div[contains(text(),'Invoice Summary')]");
    public static final By TOTAL_PAPER_SOP_LABEL = By.xpath("//tr//td[contains(text(),'Total Paper SOP :')]");
    public static final By PSOP_AMOUNT_LABEL = By.xpath("//tr//td[contains(text(),'PSOP Amount :')]");
    public static final By OPEN_AMOUNT_LABEL = By.xpath("//tr//td[contains(text(),'Open Amount :')]");
    public static final By PREVIOUS_INVOICE_LABEL = By.xpath("//tr//td[contains(text(),'Previous Invoice # :')]");
    public static final By PREVIOUS_BILLED_LABEL = By.xpath("//tr//td[contains(text(),'Previous Billed :')]");
    public static final By INVOICE_CONTENT_SECTION = By.xpath("//tr//td[contains(text(),'Invoice Content')]");
    public static final By EXPORT_BUTTON = By.id("btnExport");
    public static final By DROP_DOWN_INVOICE_CONTENT = By.id("ctlFilterBar_lstF");
    public static final By TEXT_BOX_IN_RHS = By.id("ctlFilterBar_txtRHS");
    public static final By GO_BUTTON = By.id("ctlFilterBar_btnGo");
    public static final By SORT_BY_LABEL = By.className("sortBy");
    public static final By SORT_BY_LABEL_ENTITY_NAME = By.xpath("//span[contains(text(),'Entity Name')]");
    public static final By SORT_BY_LABEL_ENTITY_NUMBER = By.xpath("//a[contains(text(),'Entity #')]");
    public static final By SORT_BY_LABEL_JURIS  = By.xpath("//a[contains(text(),'Juris')]");
    public static final By SORT_BY_LABEL_SOP_COUNT = By.xpath("//a[contains(text(),'SOP Count')]");
    public static final By SORT_BY_LABEL_SUIT_TYPE = By.xpath("//a[contains(text(),'Suit Type')]");
    public static final By SORT_BY_LABEL_SUIT_SUB_TYPE = By.xpath("//a[contains(text(),'Suit Sub Type')]");
    public static final By ENTITY_NAME_GRID_HEADER = By.xpath("//tr//td[contains(text(),'Entity Name')]");
    public static final By ENTITY_NUMBER_GRID_HEADER = By.xpath("//tr//td[contains(text(),'Entity #')]");
    public static final By ENTITY_STATUS_GRID_HEADER = By.xpath("//tr//td[contains(text(),'Entity Status')]");
    public static final By JURIS_GRID_HEADER = By.xpath("//tr//td[contains(text(),'Juris')]");
    public static final By SUIT_TYPE_GRID_HEADER = By.xpath("//tr//td[contains(text(),'Suit Type')]");
    public static final By SUIT_SUB_TYPE_GRID_HEADER = By.xpath("//tr//td[contains(text(),'Suit Sub Type')]");
    public static final By PSOP_COUNT_GRID_HEADER = By.xpath("//tr//td[contains(text(),'PSOP Count')]");
    public static final By FIRST_NAVIGATION_BELOW_GRID = By.xpath("//td[@class='statusLabel']/following-sibling::td//a[contains(text(),'First')]");
    public static final By PREVIOUS_NAVIGATION_BELOW_GRID  = By.xpath("//td[@class='statusLabel']/following-sibling::td//a[contains(text(),'Previous')]");
    public static final By NEXT_NAVIGATION_BELOW_GRID = By.xpath("//td[@class='statusLabel']/following-sibling::td//a[contains(text(),'Next')]");
    public static final By LAST_NAVIGATION_BELOW_GRID = By.xpath("//td[@class='statusLabel']/following-sibling::td//a[contains(text(),'Last')]");
    public static final By FIRST_NAVIGATION_ABOVE_GRID = By.xpath("//table[@id='grdData']/preceding-sibling::table//td//a[contains(text(),'First')]");
    public static final By PREVIOUS_NAVIGATION_ABOVE_GRID = By.xpath("//table[@id='grdData']/preceding-sibling::table//td//a[contains(text(),'Previous')]");
    public static final By NEXT_NAVIGATION_ABOVE_GRID = By.xpath("//table[@id='grdData']/preceding-sibling::table//td//a[contains(text(),'Next')]");
    public static final By LAST_NAVIGATION_ABOVE_GRID = By.xpath("//table[@id='grdData']/preceding-sibling::table//td//a[contains(text(),'Last')]");
    public static final By BACK_BUTTON = By.id("btnBackToInvoiceList");
    public static final By REVISE_BUTTON = By.id("btnRevise");    
    public static final By RECIPIENT_NAME = By.id("ctlRecipient_lblTitle");
    public static final By PARTICIPANT_TITLE = By.id("ctlRecipient_lblParticipantTitle");
	public static final By RECIPIENT_CUSTOMER = By.id("ctlRecipient_lblCustomer");
	public static final By RECIPIENT_ADDRESS =By.id("ctlRecipient_lblAddress");
	public static final By RECIPIENT_EMAIL = By.id("ctlRecipient_lblEmail");
	public static final By RECIPIENT_PHONE = By.id("ctlRecipient_lblPhone");
	public static final By RECIPIENT_FAX = By.id("ctlRecipient_lblFax");
	public static final By MONTH_TITLE = By.xpath("//td[@class='title']");
	public static final By GO_BACK_IN_MONTH = By.xpath("//td[contains(text(),'Today')]/preceding-sibling::td[1]");
	public static final By GO_FORWARD_IN_MONTH = By.xpath("//td[contains(text(),'Today')]/following-sibling::td[1]");
	public static final By TOTAL_PAPER_SOP_COUNT = By.id("lblTotalPaperSOP");
	public static final By PSOP_COUNT = By.xpath("//tr[@class='dataGridText']//td[7]");	
	public static final By AGENT_NAME= By.id("ctlContextBar_lblContextBusUnit");
	public static final By NRAI_DOC_TYPE_COLUMN_NAME = By.xpath("//td[contains(text(),'NRAI Doc Type')]");
	
   //PSOP invoice search resuts page
	public static final By PSOP_INVOICE_RESULTS_EXPORT_BUTTON = By.id("ctlPageTitle_btnExport");
	public static final By INVOICE_DATA_HEADER = By.xpath("//td[contains(text(),'Invoice #')]");
	public static final By OW_ORDER_DATA_HEADER = By.xpath("//td[contains(text(),'OW Order #')]");
	public static final By PRINT_DATE_DATA_HEADER = By.xpath("//td[contains(text(),'Print Date')]");
	public static final By INVOICE_DATE_DATA_HEADER = By.xpath("//td[contains(text(),'Invoice Date')]");
	public static final By INV_AMOUNT_DATA_HEADER = By.xpath("//td[contains(text(),'Inv. Amount')]");
	public static final By PSOP_COUNT_DATA_HEADER = By.xpath("//td[contains(text(),'PSOP Count')]");
	public static final By SEARCH_AGAIN = By.id("btnSearchAgain");	
	public static final By INVOICE_BELOW_PSOP_INVOICE_REVISION = By.xpath("//tr//td[contains(text(),'OW Order # :')]/parent::tr/preceding-sibling::tr//td[contains(text(),'Invoice # :')]");
	public static final By REVISE_BUTTON_IN_PSOP_INVOICES = By.xpath("//img[@src='/public/images/btn_Revise.gif']");
	
	
  //PSOP Invoice Revision Page
	public static final By SUBMIT_BUTTON = By.id("btnSubmit");
	public static final By REMOVE_CREDIT_DATA_HEADER = By.xpath("//td[contains(text(),'Remove/Credit')]");
	public static final By CURRENT_FILTER = By.className("statusLabelBold");
	public static final By BACK_BUTTON_REVISION_PAGE = By.id("btnBack");
	public static final By SELECT_ALL_BUTTON = By.id("btnSelectAll"); 
	public static final By SELECT_NONE_BUTTON = By.id("btnSelectNone");
	public static final By INVOICE_DELIVERY_OPTIONS_SECTION = By.className("sectionBreak");
	public static final By DELIVERY_METHOD_LABEL = By.xpath("//td[contains(text(),'Delivery Method :')]");
	public static final By REVISION_REASON_LABEL = By.xpath("//td[contains(text(),'Revision Reason :')]");
	public static final By DELIVERY_METHOD_DROP_DOWN = By.id("drpDeliveryMethod");
	public static final By REVISION_REASON_DROP_DOWN = By.id("drpRevisionReason");
	public static final By ERROR_PSOP_PERMISSION = By.xpath("//b[contains(text(),'Security Error Occurred')]/parent::p/parent::td");
    public static final By REMOVE_CREDIT_CHECK_BOX = By.xpath("//input[contains(@id,'grdData_ctl')]");
	
  //PSOP Invoice Exception
	public static final By INVOICE_EXCEPTION_SEARCH = By.xpath("//a[contains(text(),'Invoice Exception Search')]");
	public static final By RADIO_BUTTON_FOR_ENTITY = By.id("rdoEntity");
	public static final By PSOP_EXCEPTIONS_TAB = By.id("lnkPSOPExp"); 
	public static final By IS_NEXT_TO_DROP_DOWN = By.id("ctlFilterBar_singleOperator");
	public static final By REASON_SORT_LABEL = By.xpath("//a[contains(text(),'Reason')]");
	public static final By EXCEPTION_DATE_SORT_LABEL = By.xpath("//span[contains(text(),'Exception Date')]");
	public static final By INVOICE_DATE_SORT_LABEL = By.xpath("//a[contains(text(),'Invoice Date')]");
	public static final By SERVICE_CENTER = By.id("lstServiceCenter");	
	public static final By FIRST_SUBMIT_ORDER_BUTTON = By.xpath("//a[@id='grdData_ctl02_btnSubmitOrder']/img");
	public static final By ERROR_BOX_VAL_SUMMARY = By.id("ctlErrorBox_valSummary");

	//REvise Invoice Page
	public static final By DO_NOT_PRINT_RADIO_BUTTON = By.id("rdoDoNotPrint");
	public static final By REVISE_BUTTON_REPRINT = By.id("btnReviseReprint");
    public static final By REVISE_REASON_DROP_DOWN = By.id("lstRevisionReasons");
    public static final By COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE = By.id("txtComment");
    public static final By GRID_CHECK_BOX_SELECTOR = By.id("grdRenSubGroupList_ctl02_chkSelector");   
    public static final By ENABLE_BUTTON = By.id("btnEnable");
    public static final By ARROW_INVOICE_STATUS_SORT_BY = By.xpath("//a[contains(text(),'ARROW Invoice Status')]");
    public static final By EFFECTIVE_END_DATE = By.id("ctrlDateSelectorEndDate_txtDate");
    public static final By BUTTON_DISABLE = By.id("btnDisable");
    public static final By NEXT_BUTTON_RELATED_INVOICE = By.id("btnNext");
    public static final By INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE = By.id("grdData_ctl02_lnkInvoiceChanges");
    public static final By DS_ADDED = By.xpath("//td[contains(text(),'DS Added')]");
    public static final By NO_INVOICE_CHANGES_LINK = By.xpath("//a[@id='grdData_ctl02_lnkInvoiceChanges'] [@title='No Changes']");
    public static final By REFUND_CHECK_COMMENTS = By.xpath("//li[contains(text(),'Enter text for Refund Check Comments.')]");
    public static final By REFUND_CHECK_COMMENTS_TEXT_BOX = By.id("txtRefundCheckComments");
    //Invoice Profile Page
    public static final By REPRINT_BUTTON = By.id("btnReprint");
    public static final By ARROW_INVOICE_STATUS = By.id("lblStatus");
    public static final By NEXT_BUTTON = By.xpath("//div[6][@class='componentSpacer']//following-sibling::table[1]//a[contains(text(),'Next')]");
    //Reprint Revise Page
    public static final By REVISE_REPRINT_BUTTON = By.id("btnReviseReprint");    
    //Subgroup Bundle Maintenance
    public static final By REPARMS_BUNDLE = By.id("drpBundle");
    //No revised/new invoice(s) will be generated based on your current revisions:
    public static final By NO_REVISED_NEW_INVOICE_MESSAGE =  By.xpath("//span[contains(text(),'No revised/new invoice(s) will be generated based on your current revisions:')]");
    //Invoice Date
    public static final By INVOICE_DATE_SORT = By.xpath("//a[contains(text(),'Invoice Date')]");
}
