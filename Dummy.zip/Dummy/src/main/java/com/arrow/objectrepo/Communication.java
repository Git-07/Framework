package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Communication {

	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	
	//Fields on left nav links of comm module
	public static final By TRANSMITTAL_HISTORY_LEFT_NAV_LINK = By.linkText("Transmittal History");


	// Fields on Worksheet Search Page
	public static final By LOG_ID_TEXTBOX = By.id("txtLogID");
	public static final By SEARCH_BTN = By.id("btnSearch");
	public static final By RECEIVED_DATE_FROM = By.id("ctrlDateSelectorFiling_txtDate");
	public static final By RECEIVED_DATE_TO = By.id("ctrlDateSelectorCTAppointment_txtDate");
	public static final By ENTITY_SELECT_BTN = By.id("imgFind");
	public static final By CREATE_WORKSHEET_BTN = By.id("btnCreateWorksheet");

	// Fields On Worksheet Edit Page
	public static final By RECEIVED_DATE = By.id("ctlDateSelectorReceived_txtDate");
	public static final By REGISTERED_MAIL_METHOD_OF_SERVICE = By
			.xpath("//select[@id='drpMethodofService']//option[contains(text(), 'Registered Mail')]");

	// Fields on Worksheet Search Results Page
	public static final By FIRST_LOG_ON_GRID = By.id("grdData_ctl02_lnkLogID");

	// Fields on Worksheet Profile Page
	public static final By LOG_ID_ON_CONTEXT_BAR = By.id("ctlContextBar_lblContextId");
	public static final By ENTITY_NAME_ON_CONTEXT_BAR = By.id("ctlContextBar_lblContextTitle");
	public static final By EDIT_BTN = By.id("ctlPageTitle_btnEdit");
	public static final By RECEIVED_DATE_ON_WORKSHEET_PROFILE = By
			.xpath("//span[@id='lblReceived'][contains(text(), '09/11/2008')]");
	public static final By RECEIVED_DATE_WORKSHEET_PROFILE = By.id("lblReceived");
	public static final By METHOD_OF_SERVICE_ON_WORKSHEET_PROFILE = By.id("lblMethodofService");
	public static final By COMM_JURIS_ON_WORKSHEET_PROFILE = By.id("lblCommJuris");
	public static final By DOCUMENT_JURIS_ON_WORKSHEET_PROFILE = By.id("lblDocumentJuris");
	public static final By VIEW_TRANSMITTAL_BTN = By.id("btnViewTransmittal");
	public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");

	// Fields on Entity Name Search Criteria Page
	public static final By ENTITY_NAME_TEXTBOX = By.id("txtName");

	// Field on Entity Name Search Results Page
	public static final By SELECT_FIRST_ENTITY_ON_GRID = By.id("grdData_ctl02_lnkSelect");

	// Fields on Create Worksheet Page
	public static final By CALENDAR = By.id("ctlDateSelectorReceived_btnCal");
	public static final By POST_MARKED_CALENDAR = By.id("ctlDateSelectorPostMarked_btnCal");
	public static final By METHOD_OF_SERVICE_DRPDWN = By.xpath("//select[@id='drpMethodofService']");
	public static final By ALASKA_COMMUNICATION_JURISDICTION = By
			.xpath("//select[@id='ctlCommJurisSelector_lstJurisdictions']//option[contains(text(), 'Alaska')]");
	public static final By ENTITY_SELECT = By.id("imgSelect");
	public static final By BULK_MAIL_METHOD_OF_SERVICE = By
			.xpath("//select[@id='drpMethodofService']//option[contains(text(), 'Bulk Mail')]");
	public static final By ELECTRONIC_DELIVERY_METHOD_OF_SERVICE = By
			.xpath("//select[@id='drpMethodofService']//option[contains(text(), 'Electronic Delivery')]");
	
	public static final By DOCUMENT_TYPE_DRPDWN = By.id("ctlDocTypeSelector_lstDocTypes");
	public static final By DOCUMENT_TYPE_DRPDWN_ANNUAL_REPORT = By.xpath("//select[@id='ctlDocTypeSelector_lstDocTypes']/option[contains(text(), 'Annual Report')]");
	public static final By DOCUMENT_TYPE_DRPDWN_PERIODIC_REPORT = By.xpath("//select[@id='ctlDocTypeSelector_lstDocTypes']/option[contains(text(), 'Periodic Report')]");
	public static final By DOCUMENT_TYPE_DRPDWN_BIENNIAL_REPORT = By.xpath("//select[@id='ctlDocTypeSelector_lstDocTypes']/option[contains(text(), 'Biennial Report')]");
	public static final By ALASKA_DOCUMENT_JURISDICTION = By
			.xpath("//select[@id='ctlDocumentJurisSelector_lstJurisdictions']//option[contains(text(), 'Alaska')]");
	public static final By DOCUMENT_SOURCE_DRPDWN = By.id("drpDocumentSource");
	public static final By DOCUMENT_SOURCE_DRPDWN_DPT_OF_COMMERCE = By.xpath("//select[@id='drpDocumentSource']/option[contains(text(), 'Department of Commerce')]");
	public static final By DOCUMENT_SOURCE_DRPDWN_DPT_OF_LICENSING = By.xpath("//select[@id='drpDocumentSource']/option[contains(text(), 'Department of Licensing')]");
	public static final By DOCUMENT_SOURCE_DRPDWN_ARIZONA_CORP_COMM = By.xpath("//select[@id='drpDocumentSource']/option[contains(text(), 'Arizona Corporation Commission')]");
	
	public static final By REMARKS_TEXTBOX = By.id("txtRemarks");
	public static final By SAVE_BTN = By.id("btnSave");
	public static final By REGULAR_MAIL_METHOD_OF_SERVICE = By
			.xpath("//select[@id='drpMethodofService']//option[contains(text(), 'Regular Mail')]");
	public static final By COMMUNICATION_JURISDICTION_DRPDWN = By.id("ctlCommJurisSelector_lstJurisdictions");
	public static final By DOCUMENT_JURISDICTION = By.id("ctlDocumentJurisSelector_lstJurisdictions");
	
	//Fields on transmittal history button
	public static final By VIEW_ENTITY_DI_BTN = By.id("btnViewEntityDI");
	public static final By MARK_AS_UNDELIVERABLE_BTN = By.id("btnMarkAsUndeliverable");
	public static final By CREATE_TRANSMITTAL_BTN = By.id("btnCreateTransmittal");

	
	//Fields on Transmittal Undeliverable Page
	public static final By RETURNED_CALENDAR_ICON_ON_TRANSMITTAL_DELIVERABLE_PAGE = By.id("ctlDateSelectorReturned_btnCal");
	public static final By OTHER_REASON = By
			.xpath("//select[@id='drpReturnReason']//option[contains(text(), 'Other')]");
	





}
