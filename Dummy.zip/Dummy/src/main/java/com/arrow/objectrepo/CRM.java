package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class CRM {
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By ALERTS_TEXTFIELD = By.id("txtAlert");
	public static final By CLEAR_BTN = By.id("ctlFilterBar_btnClear");
	public static final By RSS_BTN = By.id("lnkRSS");
	public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");
	public static final By REQUEST_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Request Search')]");
	public static final By CREATE_BUTTON = By.id("btnCreate");
	public static final By NEW_REQUEST_PAGE =  By.xpath("//span[contains(text(), 'New Request')]");
	public static final By DROPDOWN_REQUEST_NEW=  By.xpath("//select[@id='drpRequestStatus']/option[contains(text(), 'New')]");
	public static final By DROPDOWN_REQUEST_ASSIGNED=  By.xpath("//select[@id='drpRequestStatus']/option[contains(text(), 'Assigned')]");
	public static final By YEARDRPDWN_2019=  By.xpath("//select[@id='drpYear']/option[contains(text(), '2019')]");
	public static final By SOP_INCIDENT_REPORT =  By.xpath("//select[@id='drpRequestType']/option[contains(text(), 'SOP Incident Report')]");
	public static final By SERVICE_TYPE =  By.xpath("//select[@id='drpRequestType']/option[contains(text(), 'Auto-Renew Setup')]");
	public static final By AFFILIATION_SELECT =  By.id("grdDataSearchByAffiliation_ctl02_lnkSelect");
	public static final By WORKSHEET_SEARCH_LINK =  By.id("lnkWorksheet");
	public static final By CST_SEARCH_LINK =  By.id("lnkCST");
	public static final By ENTITY_SEARCH_LINK =  By.id("lnkEntity");
	public static final By AFFILIATION_SEARCH_LINK =  By.id("lnkAffiliation");
	public static final By NONCT_SEARCH_LINK =  By.id("lnkNonCT");
	public static final By NAME_TEXT_BOX =  By.id("txtSearchByName");
	public static final By PARTICIPANT_LOOKUP =  By.id("btnParticipantLookup");
	public static final By WORKSHEET_SEARCH_POPUP = By.xpath("//span[contains(text(), 'Worksheet Search')]");
	public static final By ENTER_LOGID = By.id("txtWorksheetID");
	public static final By LOGID_SEARCH_BUTTON = By.id("btnSearchWorksheet");
	public static final By ERROR_TYPE= By.xpath("//select[@id='drpErrorType']//option[contains(text(), 'FedEx Issue')]");
	public static final By REQUESTED_VIA = By.xpath("//select[@id='drpRequestedVia']//option[contains(text(), 'Phone')]");
	public static final By SERVICE_LEVEL = By.xpath("//select[@id='drpServiceLevel']//option[contains(text(), 'Severity Level 1')]");
	public static final By SERVICE_LEVEL_OPTION = By.xpath("//select[@id='drpServiceLevel']/option[2]");

	public static final By EDIT_REQUEST_PAGE = By.xpath("//span[contains(text(), 'Edit Request')]");
	public static final By ASSIGNED_STATUS = By.xpath("//span[contains(text(), 'Assigned')]");
	public static final By COMPLETED_STATUS = By.xpath("//span[contains(text(), 'Completed')]");
	public static final By REQUESTID = By.id("txtRequestID");
	public static final By REQUEST_LIST_PAGE = By.xpath("//span[contains(text(), 'Requests List - CT - New York SOP Team')]");

	public static final By SERVICE_TYPE_DROP_DOWN = By.id("drpRequestType");
	
	//View History
	public static final By VIEW_HISTORY = By.xpath("//img[@alt='View Assignment History']");
	public static final By REQUEST_HISTORY = By.xpath("//span[contains(text(), 'Request History')]");
	public static final By EMAIL_WHEN_COMPLETE_CHECKBOX = By.id("chkEmailParticipant");
	
	//My Worksheets To Review
	public static final By MY_WORKSHEETS_TO_REVIEW_TAB = By.id("lnkMyWorksheetsToReview");
	public static final By MY_TEAMS_WORKSHEET_TO_REVIEW_TAB = By.id("tdMyTeamWorksheetsToReview");
	public static final By REVIEW_TYPE_DROPDOWN = By.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Review Type')]");
	public static final By CUSTOMER_INCIDENT_REPORT_DROPDOWN = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Customer Reported Incident Review')]");
	public static final By FIRST_SOP_TO_REVIEW = By.id("grdMyWorksheetsToReview_ctl02_lnkWorksheetId");
	public static final By TEAMS_FIRST_SOP_TO_REVIEW = By.id("grdMyTeamWorksheetsToReview_ctl02_lnkWorksheetId");
	public static final By REVIEW_PAGE = By.xpath("//span[contains(text(), 'Review Worksheet  - Step 1')]");
	public static final By SAVE_TOP_BUTTON = By.id("btnSaveTop");
	public static final By REVIEW_SUB_TYPE = By.id("drpReviewSubType");
	public static final By REVIEW_SUB_TYPE_OPTION = By.xpath("//select[@id='drpReviewSubType']/option[2]");
	
	public static final By LOG_ID = By.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Log #')]");
	
	
	//Fields on administration
	public static final By ADMINISTRATION_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Administration')]");
	public static final By FIRST_DISABLE_BTN_ON_GRID = By.xpath("(//input[@src='/public/images/btn_DISABLE.gif'])[1]");
	public static final By FIRST_ENABLE_BTN_ON_GRID = By.xpath("(//input[@src='/public/images/btn_Enable.gif'])[1]");
	
	//Fields on email text maintenance
	public static final By EMAIL_TEXT_MAINTANANCE_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Email Text Maintenance')]");
	public static final By VALUE_TEXTBOX = By.id("txtValue");
	public static final By ADD_UPDATE_BTN = By.id("imgAddUpdate");
	public static final By FIRST_DELETE_BTN = By.id("lstData_ctl01_imgDelete");

	//Fields on Reports By Service Type
	public static final By REPORTS_BY_SERVICE_TYPE_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Reports - By Service Type')]");
	public static final By GRID_HEADER = By.id("grdOuter_ctl02_serviceTypeUserControl_grdSearchResult_ctl01_lblHeader");
	public static final By GENERATE_REPORT_BTN = By.id("btnGenerateReport");
	public static final By ALL_REGIONS_RADIO_BTN = By.id("rdoAllRegions");
	public static final By EXPORT_BTN = By.id("ctlPageTitle_btnExport");

	//Fields on Reports By Service Level
	public static final By REPORTS_BY_SERVICE_LEVEL_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Reports - By Service Level')]");
	public static final By SERVICE_LEVEL_GRID_HEADER = By.id("grdOuter_ctl02_serviceLevelUserControl_grdSearchResult_ctl01_lblHeader");

	//Fields on Reports By Requested Via
	public static final By REPORTS_BY_REQUESTED_VIA_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Reports - By Requested Via')]");
	public static final By REQUESTED_VIA_GRID_HEADER = By.id("grdOuter_ctl02_requestedViaUserControl_grdSearchResult_ctl01_lblHeader");
	
	//Fields on Reports Core Team Cycle
	public static final By REPORTS_CORE_TEAM_CYCLE_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Reports - CORE Team Cycle')]");
	public static final By CORE_TEAM_GRID_HEADER = By.id("grdOuter_ctl02_core_team_cycle_time_report_control_grdSearchResult_ctl01_lblAssignedToTeam");

	//Fields on Reports Core Assignment
	public static final By REPORTS_CORE_ASSIGNMENT_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Reports - CORE Assignment')]");

    public static final By FIRST_CRM_DATA = By.id("grdData_ctl02_lnkEdit");
    public static final By WORKSHEET_LINK = By.id("lnkWorkSheetId");

    public static final By BOTTOM_BACK_TO_CRM_BTN = By.id("btnBackToCRM");
    public static final By TOP_BACK_TO_CRM_BTN = By.id("btnBackToCRMTop");
	
}
