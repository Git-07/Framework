package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class SOP {
	public static final By UPLOADIMAGEBTN = By.id("btnUploadImage");
	public static final By UPLOADIMAGE_PAGE = By.xpath("//span[contains(text(), 'Upload Image')]");
	public static final By BATCHNUMBER_TEXT = By.id("txtBatchNumber");
	public static final By UPLOAD_IMG = By.id("imgFile");
	public static final By REJECTION_RULE_MAINTENANCE_LINK = By.xpath("//a[contains(text(),'SOP Rejection Rules Maintenance')]");

	// Filter buttons
	public static final By CLEARBTN = By.id("ctlFilterBar_btnClear");
	public static final By FILTERDROPDOWN1 = By.id("ctlFilterBar_lstF");
	public static final By FILTERDROPDOWN2 = By.id("ctlFilterBar_lstOp");
	public static final By FILTERTEXTFIELD = By.id("ctlFilterBar_txtRHS");
	public static final By FILTERGOBTN = By.id("ctlFilterBar_btnGo");
	public static final By FILTER_DROPDOWN1 = By.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'ESOP Id')]");

	// Elements on SOP List page
	public static final By CESSELECTBTN = By.id("grdData_ctl02_lnkProcessCES");
	public static final By VIEW_BTN = By.id("grdData_ctl02_lnkView");
	public static final By CREATE_WORKSHEET_BTN = By.id("grdData_ctl02_lnkCreateWorksheet");
	public static final By CREATE_WORKSHEET = By.xpath("//img[@alt='Create Worksheet']");
	public static final By FIRST_SOP_CHECKBOX = By.id("grdData_ctl02_chkBoxEsopDoc");
	public static final By ASSIGN_BTN = By.id("btnAssign");
	public static final By CES_ENABLED_LABEL = By.id("grdData_ctl02_lblCESEnabled");
	public static final By SOP_15DAYS_TAB = By.id("lnkOldSopList");
	public static final By SOPLIST_PAGE = By.xpath("//span[contains(text(), 'Service Of Process List')]");
	public static final By SOPLIST_TILE_PAGE = By.xpath("(//span[contains(text(), 'Service Of Process List')])[2]");
	public static final By NO_RECORDS_BAR = By.id("ctlNoRecordsBar_lblNoRecords");
	public static final By TEAM_SOP_DASHBOARD = By.xpath("//a[contains(text(),'Team SOP Dashboard')]");    
	public static final By DELETE_SOPS = By.id("btnDelete");    
	public static final By FIRST_ESOP_ID_SELECTED = By.id("grdData_ctl02_lnkAssignmentHistory");
	// Elements on CES page
	public static final By SUBMITBTN = By.id("BtnSubmit2");
	public static final By ESOPIFRAMEID = By.id("frmCesData");
	public static final By INTAKEMETHODLABEL = By.xpath("//*[@id='EsopInfoTbl']/tbody/tr[5]/td[1]");
	public static final By INTAKEMETHODVALUE = By.id("lblIntakeMethod");
	public static final By CASE_ID_TEXTFIELD = By.id("txtCaseNumber");
	public static final By CUSTOMER_COMMENTS_LABEL = By.xpath("//*[@id=\"EsopInfoTbl\"]/tbody/tr[6]/td[1]");
	public static final By CUSTOMER_COMMENTS_VALUE = By.id("txtareaCustComment");
	public static final By SELECT_ARROW_ENTITY_BTN = By.id("IBEntitySearch");
	public static final By CES_PROCESSING_TAB = By.xpath("//td[contains(text(), 'CES Processing Item')]");
	public static final By NEXT_IN_QUEUE_BTN = By.id("NextItemButtons_btnUPItems");
	public static final By UNRELATED_WORKSHEET_BTN = By.id("btnUnrelatedWorksheet");
	public static final By ESCALATION_DETAILS_ARROW = By.id("trEscalation");
	public static final By REASON_DRPDWN = By.id("drpEscalationReason");
	public static final By ESCALATION_COMMENTS_TEXTBOX = By.id("txtEscalationComment");
	public static final By ESCALATE_BTN = By.id("btnEscalate");
	public static final By ESOPID = By.id("lblEsopNumber");
	public static final By ESCALATED_LIST_TAB = By.id("cesTabs_tbEscalate");
	public static final By REASON_FOR_HOLD_TEXTBOX = By.id("txtOnHoldReason");
	public static final By ONHOLD_BTN = By.id("btnOnHold");
	public static final By ON_HOLD_LIST_TAB = By.id("cesTabs_tbonHold");
	public static final By ESCALATION_REASON = By.id("lblEscalationReason");
	public static final By SEARCH_AGAIN_BUTTON = By.id("btnSearchAgain");
	public static final By CANCEL_BUTTON = By.id("btnCancel");

	public static final By ESOP_ID_FIRST_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'ESOP Id')]");
	public static final By FIRST_CES_SELECT_BUTTON = By.id("grdEscalatedItems_ctl02_btnEdit");
	public static final By FIRST_ONHOLD_CES_SELECT_BUTTON = By.id("grdOhHoldItems_ctl02_btnEdit");

	public static final By EQUAL_SECOND_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), '=')]");


	public static final By FIRST_ENTITY_IN_SEARCH_RESULT = By.xpath("//span[@id='grdData_ctl02_lblEntityNames']/a[1]/li[1]");

	public static final By HOME_PDF_ICONS = By.className("bootstrap-iso");
	public static final By HOME_ICON = By.xpath("//div[@class='iframe-icon-Home']");
	public static final By LAWSUITTYPE_DROPDOWN = By.id("drpLawsuitType");
	public static final By LAWSUITTYPE_SELECT_ONE_DROPDOWN = By
			.xpath("//select[@id='drpLawsuitType']/option[contains(text(), '-- Select One --')]");

	public static final By FIRST_REP_CES_REP_UNITS = By.id("lstData_ctl01_lnkSelect");
	public static final By USE_THIS_COURT = By.id("rdoCourtOthers");
	public static final By ADDRESS_LINE_ONE = By.id("ctlFreeTextCourt_txtAddressLine1"); 
	public static final By ATTORNEY_ADDRESS_LINE_ONE = By.id("txtAttorneyAddressLine1");



	// Elements on Entity Name Search Criteria
	public static final By ENTITY_NAME_TEXTFIELD = By.id("txtName");
	public static final By SEARCH_BTN = By.id("btnSearch");
	public static final By ENTITY_SEARCH_MESSAGE = By.id("lblSearchLimitMsg");
	public static final By ENTITY_DOM_JURISDICTION = By.id("grdData_ctl02_lblJuris");
	public static final By ENTITY_REP_JURISDICTION = By.id("grdData_ctl02_lblRepJuris");
	public static final By ENTITY_REP_STATUS = By.id("grdData_ctl02_lblRepStatus");
	public static final By ENTITY_REP_SERVICE_TYPE = By.id("grdData_ctl02_lblRepServiceType");
	public static final By ENTITY_RESULT_MESSAGE = By.id("lblNoRecords");
	public static final By UNIDENTIFIED_ENTITY_BTN = By.id("btnUnidentifiedEntity");
	public static final By INCLUDE_ALL_REP_ASSUMED_BTN = By.id("chkIncludeAllRepresentationJrisdiction");
	public static final By INCLUDE_STAFFING_ENTITIES_BTN = By.id("chkIncludeStaffingEntities");

	// Elements of ML Slider on CES page
	public static final By SLIDER_EYE_OPEN_BTN = By.cssSelector(".glyphicon-eye-open");
	public static final By SLIDER_EYE_CLOSE_BTN = By.cssSelector(".glyphicon-eye-close");
	public static final By SLIDER_ID = By.id("ml_sidebar");
	public static final By SLIDER_OPENED_BTN = By.cssSelector(".glyphicon-chevron-left");
	public static final By SLIDER_TITLE = By.xpath("//div[@id='ml_sidebar']//h6");//h6 instead of h4
	public static final By CES_SECTION_UP_ARROW = By.cssSelector(".glyphicon-menu-up");
	public static final By CES_SECTION_DOWN_ARROW = By.cssSelector(".glyphicon-menu-down");
	public static final By CES_SECTION_TITLE = By.className("panel-title");
	public static final By SLIDER_CLOSED_BTN = By.cssSelector(".glyphicon-chevron-right");
	public static final By COPY_ICON = By.cssSelector(".glyphicon.glyphicon-duplicate");
	public static final By FIRST_ELEMENT_ON_ML_SLIDER = By.xpath("//*[@id=\"tCES\"]/tbody/tr[1]/td[2]/div");

	// Elements on Create Worksheet page
	public static final By PAGE_HEADER = By.id("ctlContextBar_lblContextTitle");
	public static final By PDF_ICONBTN = By.id("lnkPDF");
	public static final By BAD_LOG_FIELD = By.xpath("//td[contains(text(), 'Bad Log')]");
	public static final By BAD_LOG_CHECKBOX = By.id("chkIsBadLog");
	public static final By WORKSHEET_TYPE_FIELD = By.xpath("//td[contains(text(), 'Worksheet Type')]");
	public static final By WORKSHEET_TYPE = By.id("lblWorksheetType");
	public static final By RECEIPT_DATE_FIELD = By.id("ctlDateSelectorReceiptDate_txtDate");
	public static final By RECEIVED_BY_FACILITY = By.id("drpReceivedByFacility");
	public static final By MULTIPLE_FIELD = By.xpath("//td[contains(text(),'Multiple')]");
	public static final By MULTIPLE_FIELD_YES_RADIO_BTN = By.id("rdoMultipleYes");
	public static final By MULTIPLE_FIELD_NO_RADIO_BTN	 = By.id("rdoMultipleNo");
	public static final By PRIORITY_FIELD_DRPDWN	 = By.id("drpPriority");


	public static final By RECEIVED_BY_EXPANDABLE_ARROW = By.xpath("//td[contains(text(),'Received')]/child::div/span[@class='glyphicon glyphicon-triangle-right']");

	/*public static final By RECEIVED_BY_EXPANDABLE_ARROW = By.xpath("//span[@class='glyphicon glyphicon-triangle-right'][1]");
    public static final By RECEIVED_BY_EXPANDABLE_ARROW = By.xpath("//span[@class='glyphicon glyphicon-triangle-right'][1]");*/

	public static final By RECEIVED_BY_COLLAPSABLE_ARROW = By.xpath("//span[@class='glyphicon glyphicon-triangle-bottom']");
	public static final By ASSIGNED_TO_EXPANDABLE_ARROW = By.xpath("//td[contains(text(),'Assigned')]/child::div/span[@class='glyphicon glyphicon-triangle-right']");
	public static final By ASSIGNED_TO_COLLAPSABLE_ARROW = By.xpath("//span[@class='glyphicon glyphicon-triangle-right'][1]");

	public static final By RECEIVED_BY_TEAM = By.id("drpReceivedByTeam");
	public static final By ASSIGNED_TO_FACILITY_DPDOWN = By.id("drpAssignedToFacility");
	public static final By ASSIGNED_TO_TEAM_DPDOWN = By.id("drpAssignedToTeam");
	public static final By ASSIGNED_TO_MEMBER_DPDOWN = By.id("drpAssignedTo");
	public static final By CONSOLIDATED_YES_RADIO_BUTTON = By.id("rdoConsolidatedYes");
	public static final By BANKRUPTCY_YES_RADIO_BUTTON = By.id("rdoBankruptcyYes");
	public static final By LETTER_YES_RADIO_BUTTON = By.id("rdoLetterYes");
	public static final By ARROW_ENTITY_FIELD = By.xpath("//label[contains(text(), 'ARROW Entity')]");
	public static final By ARROW_UNIDENTIFIED_ENTITY_FIELD = By.xpath("//label[contains(text(), ' Unidentified')][1]");
	public static final By TARGET_DETAILS_SECTION = By.xpath("//div[contains(text(),'Target Details')]");
	public static final By REJECT_DETAILS_SECTION = By.xpath("//div[contains(text(),'Reject Details')]");
	public static final By REJECT_DATE = By.id("ctlDateSelectorRejectDate_txtDate");
	public static final By CONFIRMATION_NUMBER_FIELD = By.xpath("//td[contains(text(),'Confirmation Number')]");
	public static final By CUSTOMER_FIELD = By.xpath("//td[contains(text(),'Customer')]");
	public static final By INDIVIDUAL_FIELD = By.xpath("//td[contains(text(),'Individual')]");
	public static final By CLONED_COPIED_FIELD = By.xpath("//td[contains(text(),'Cloned / Copied From')]");
	public static final By TRACKING_FIELD = By.id("txtCertifiedMailNo");
	public static final By DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN = By.id("drpCDMOS");
	public static final By DIRECT_SERVED_PROCESS_RECEIVED_DATE = By.id("ctlDateSelectorCDReceivedDate_txtDate");
	public static final By DIRECT_SERVED_PROCESS_RECEIVED_TIME = By.id("txtCDReceivedTime");
	public static final By CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION = By.xpath("//div[contains(text(),'Customer Comments (CDSOP Only)')]");
	public static final By CUSTOMER_COMMENTS_BOX = By.id("txtareaCustComment");
	public static final By COURT_DETAILS_SECTION = By.xpath("//div[contains(text(),'Court Details')]");
	public static final By STATE_OF_COURT_DRPDWN = By.id("drpJurisdictions");
	public static final By EXISTING_AGENCY_RADIO_BTN = By.id("rdoSelectAgency");
	public static final By EXISTING_AGENCY_DRPDOWN = By.id("drpAgency");
	public static final By AGENCY_DETAILS_SECTION = By.xpath("//div[contains(text(),'Agency Details')]");
	public static final By ATTORNEY_DETAILS_SECTION = By.xpath("//td[contains(text(),'Attorney / Sender Details')]");
	public static final By ARROW_ENTITY_BRANCHPLANT = By.id("lblBusinessUnit");
	public static final By ARROW_ENTITY_RADIO_BUTTON_SELECTED = By.xpath("//input[@id='rdoArrowEntity' and @checked='checked']");
	public static final By UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED = By.xpath("//input[@id='rdoUnidentifiedEntity' and @checked='checked']");
	public static final By LAW_SUIT_SUB_TYPE_DRPDWN = By.id("drpLawsuitSubtype");
	public static final By NOA_DRPDWN = By.id("drpNatureofAction");
	public static final By CTCORP_ENTITY_SELECTED = By.xpath("//select[@id='drpBusinessUnits']/option[@value='92001' and @selected='selected']");
	public static final By NRAI_ENTITY_SELECTED = By.xpath("//select[@id='drpBusinessUnits']/option[@value='92003' and @selected='selected']");
	public static final By AMOUNT_DUE_DRPDWN = By.id("txtAmountDue");

	public static final By METHOD_OF_SERVICE = By.id("drpMethodofService");
	public static final By RECEIVED_BY_MEMBER_DPDOWN = By.id("drpReceivedBy");
	public static final By POST_MARKED_DATE = By.id("ctlDateSelectorPostMarked_txtDate");
	public static final By POST_MARKED_DATE_BTN = By.id("ctlDateSelectorPostMarked_btnCal");
	public static final By CERTIFIED_MAIL_NUMBER = By.id("txtCertifiedMailNo");
	public static final By CUSTOMER_COMMENT_GRID = By.id("txtareaCustComment");
	public static final By INITIAL_RADIOBTN = By.id("rdoInitial");
	public static final By CASE_NUMBER_NONE_RADIOBTN = By.id("rdoCaseNoneSpecified");
	public static final By CASE_NUMBER = By.id("rdoCase");
	public static final By CASE_TEXTFIELD = By.id("txtCase");
	public static final By PLAINTIFF_NONE_RADIOBTN = By.id("rdoPlaintiffNone");
	public static final By PLAINTIFF_RADIOBTN = By.id("rdoPlaintiff");
	public static final By DEFENDANT_TEXTFIELD = By.id("txtDefendantName");
	public static final By NEXT_BTN = By.id("btnNext");
	public static final By PREV_BTN = By.id("btnPreviousTop");

	public static final By COURT_NONE_RADIOBTN = By.id("rdoCourtNoneSpecified");
	public static final By AGENCY_NONE_RADIOBTN = By.id("rdoAgencyNoneSpecified");

	public static final By ATTORNEY_NONE_RADIOBTN = By.id("rdoAttorneyNone");
	public static final By COURT_HELP_ICON = By.id("imgCourtHelp");
	public static final By CUSTOMER_PARTICIPANT_SEARCHBTN = By.id("lnkRecipientSearch");

	public static final By DOCUMENT_TYPE_DROPDWN = By.id("drpDocumentType");
	public static final By NRAI_DOCUMENT_TYPE_DROPDWN = By.id("drpNRAIDocType");

	public static final By DOCUMENT_TYPE_TEXTFIELD = By.id("txtDocumentType");
	public static final By SPECIAL_DROPDWN = By.id("drpSpecialCircum");
	public static final By ANSWER_NONE_RADIOBTN = By.id("rdoAnswerDateNone");
	public static final By ANSWER_RADIOBTN = By.id("rdoSelectAnswerDate");
	public static final By ANSWER_DROPDWN = By.id("drpAnswerDate");
	public static final By ANSWER_SELECT_ONE_DRPDOWN = By
			.xpath("//select[@id='drpAnswerDate']/option[contains(text(), '-- Select One --')]");

	public static final By ANSWER_DATE_TEXTFIELD = By.id("txtAnswerDate");
	public static final By SAVE_BTN = By.id("btnSave");
	public static final By TIME_TEXTFIELD = By.id("txtTime");
	public static final By SELECT_ENTITY_BTN = By.id("btnSelectEntity");
	public static final By TOP_SAVE_BTN = By.id("btnSaveTop");
	public static final By COURT_NAME_TEXT_BOX = By.id("ctlFreeTextCourt_txtName");
	public static final By CITY_NAME = By.id("ctlFreeTextCourt_txtCity");
	public static final By STATE_NAME = By.id("ctlFreeTextCourt_txtState");
	public static final By ZIP_CODE = By.id("ctlFreeTextCourt_txtZip");
	public static final By ATTORNEY_CITY_NAME = By.id("txtAttorneyAddressCity");
	public static final By ATTORNEY_STATE_NAME = By.id("txtAttorneyAddressState");
	public static final By ATTORNEY_ZIP_CODE = By.id("txtAttorneyAddressZip");

	// Elements on Manage Default Assignment page

	public static final By MANAGE_DEFAULT_ASSIGNMENT_LINK = By.linkText("Manage Default Assignment");
	public static final By ADD_NEW_BTN = By.id("btnAddNew");
	public static final By CES_ENABLED_SORTBY_LINK = By.linkText("CES Enabled");
	public static final By CES_ENABLED_CHECKBOX = By.id("chkIsCESEnabled");
	public static final By EDIT_BTN = By.id("grdData_ctl02_lnkEdit");

	// Fields On Sop Worksheet Profile page
	public static final By WORKSHEET_EDIT_BTN = By.id("ctlPageTitle_btnEdit");
	public static final By CHOOSE_DI_BTN = By.id("btnChooseDI");
	public static final By MODIFY_DOCKET_HISTORY = By.id("btnModifyDocketHistory");
	public static final By MULTIPLE_YES_FIELD = By.xpath("//span[@id='lblMultiple'][contains(text(), 'Yes')]");
	public static final By MULTIPLE_FIELD_ON_WORKSHEET_PROFILE = By.xpath("//td[contains(text(), 'Multiple')]");
	public static final By PRIORITY_FIELD_ON_WORKSHEET_PRO_PAGE = By.xpath("//td[contains(text(), 'Priority')]");

	//Fields on Related Worksheet Search Page
	public static final By CASEID_TEXTBOX = By.id("txtCaseID");
	public static final By FIRST_WORKSHEET_RADIO_BTN = By.id("grdData_ctl02_rdoLog");
	public static final By ADD_TO_DOCKET_HISTORY_BUTTON = By.id("btnAdd");


	// Fields on Choose Delivery Instruction Page
	public static final By ACTIONS_LIST_BTN = By.id("btnActionsList");
	public static final By WORKSHEET_ID_ON_CONTEXT_BAR = By.id("ctlContextBar_lblContextId");
	public static final By ATTEMPTED_YES_RADIO_BUTTON = By.id("rdoAttemptedYes");

	// Fields on Execute Action Items Page
	public static final By MANAGE_ACTIONS_ITEM_BTN = By.id("btnManageActionItems");
	public static final By EXECUTE_BTN = By.xpath("//input[@alt='Execute']");
	public static final By STATUS_OF_FIRST_ACTION_ITEM_ON_GRID = By.xpath("//span[contains(text(), 'Executed')]");

	// Fields on Manage Action Items Page
	public static final By SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN = By
			.xpath("//select[@id='drpDeliverable']//option[contains(text(), 'SOP Papers with Transmittal')]");
	// By.xpath("//a[@class='drpDeliverable']//a[contains(text(), 'SOP Tranam')]")
	public static final By FED_EX_INTERNATIONAL_ECONOMY_DELIVERY_METHOD_DRPDWN = By
			.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Fed Ex International Economy')]");
	public static final By FED_EX_PRIORITY_OVERNIGHT_DELIVERY_METHOD_DRPDWN = By
			.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Fed Ex Priority Overnight')]");
	public static final By RECIPIENT_SELECT_BTN = By.id("ctlRecipient_imgFind");
	public static final By ADDUPDATE_BTN = By.id("imgAddUpdate");
	public static final By MANAGE_ACTIONS_ITEM_ERR_MSG = By
			.xpath("//li[contains(text(), 'The selected delivery method is not valid for this recipient.')]");

	// Fields on Carrier Package Search Page
	public static final By CARRIER_TRACKING_ID = By.id("txtFedExTrackingID");

	// Fields on Carrier Package Search Results Page
	public static final By NO_RECORDS_FOUND_ERR_MSG = By.xpath("//span[contains(text(), 'No records found.')]");

	// Field on Entity Name Search Results Page
	public static final By SELECT_FIRST_ENTITY_ON_GRID = By.id("grdData_ctl02_lnkSelect");

	// Fields on Related Worksheet Basic Search Page
	public static final By CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN = By.id("btnCreate");

	// Fields On Find DI Recipient Page
	public static final By PARTICIPANTNAMEFIELD = By.id("txtParticipantName");
	public static final By FINDBTN = By.id("btnFind");
	public static final By TABLEID = By.id("grdData");
	public static final By SELECTRECIPIENTBTN = By.id("grdData_ctl02_lnkSelect");

	// Fields on Left Nav Links of SOP module
	public static final By CES_LEFT_NAV_LINK = By.linkText("CES");
	public static final By WOKSHEET_SEARCH_LEFT_NAV_LINK = By.linkText("Worksheet Search");
	public static final By MY_MESSAGES = By.linkText("My Messages");
	public static final By MANAGE_DEFAULT_ASSIGNMENT_LEFT_NAV_LINK = By.linkText("Manage Default Assignment");
	public static final By QUALITY_MAINTAINANCE_LEFT_NAV_LINK = By.linkText("Quality Maintenance");
	public static final By QUALITY_RANDOMISER_SETUP_LEFT_NAV_LINK = By.linkText("Quality Randomiser Setup");

	// Fields On Worksheet Search Criteria page
	public static final By WORKSHEET_ID_TEXTBOX = By.id("txtLogID");
	public static final By WORKSHEET_SEARCH_BTN = By.id("btnSearch");
	public static final By CLASSIC_SEARCH_BTN = By.id("btnClassicSearch");

	// Fields on Edit Worksheet Step 1
	public static final By ERROR_MSG_ON_ENTITY_EDIT = By.xpath(
			"//li[contains(text(), 'This SOP has been transmitted to the customer via the Expedited SOP Feed and you cannot edit the Entity.  Please contact your manager.')]");
	public static final By MULTIPLE_YES_RADIO_BTN_SELECTED = By.xpath("//input[@id='rdoMultipleYes' and @checked='checked']");
	public static final By DISABLED_CASE_ID_TEXTBOX = By.xpath("//input[@id='rdoMultipleYes' and @checked='checked']");
	public static final By DISABLED_PLAINTIFF_DEBTOR_TEXTBOX = By.xpath("//input[@id='txtPlaintiffGrid' and @disabled]");
	public static final By CASE_SORTING_GRID = By.xpath("//span[contains(text(), 'Case #')]");
	public static final By ADDUPDATELIST_BTN = By.id("imgAddUpdateList");
	public static final By CLEAR_BTN = By.id("imgClear");
	public static final By GRID_EDIT_BTN = By.id("grdData_ctl03_lnkEdit");
	public static final By GRID_DELETE_BTN = By.id("grdData_ctl03_imgDelete");
	public static final By CREATE_SEPARATE_TRANSMITTAL_PER_CASE_CHECKBOX = By.xpath("//input[@id='chkTransmittalPerCase' and @disabled]");
	public static final By CASE_ID_NONE_SPECIFIED = By.id("rdoCaseNoneSpecified");
	public static final By CONSOLIDATED_YES_RADIO_BTN = By.id("rdoConsolidatedYes");
	public static final By CONSOLIDATED_DEFENDANT_TEXTBOX = By.id("txtConsolidatedDefendant");
	public static final By CONSOLIDATED_PLAINTIFF_TEXTBOX = By.id("txtConsolidatedPlantiff");

	// Auto Assignment Maintenance
	public static final By AUTO_ASSIGNMENT_MAINTENANCE = By
			.xpath("//a[contains(text(), 'Auto Assignment Maintenance')]");
	public static final By CUSTOMER_NAME_MAPPING = By.xpath("//span[contains(text(), 'Customer Name Mapping')]");
	public static final By CUSTOMER_NAME = By.id("txtAbbreviation");
	public static final By ENTITY_AFF_BTN_SELECT = By.id("EntAffSelector_btnSelect");
	public static final By FIND_ENT_AFF_PAGE = By.xpath("//span[contains(text(), 'Find Entity/Affiliation')]");
	public static final By PICK_ENTITY_PAGE = By.xpath("//span[contains(text(), 'Pick Entity')]");
	public static final By AFF_MAPPING_EDIT = By.id("grdAbbreviationAffliationMapping_ctl02_btnEdit");
	public static final By AFF_MAPPING_DELETE = By.id("grdAbbreviationAffliationMapping_ctl02_btnDelete");
	public static final By EDITED_ENTITY_AFF_NAME = By
			.xpath("//span[@id='EntAffSelector_lblTitle'][contains(text(), 'apple')]");
	public static final By DELETED_ENTITY_AFF_NAME = By
			.xpath("//span[@id='EntAffSelector_lblTitle'][contains(text(), '-- Not Selected --')]");

	// Method of Serive Ranking Setup
	public static final By METHOD_OF_SERVICE_RANKING_SETUP = By
			.xpath("//a[contains(text(), 'Method Of Service Ranking Setup')]");
	public static final By METHOD_OF_SERVICE_RANKING_SETUP_PAGE = By
			.xpath("//span[contains(text(), 'Method Of Service Ranking Setup')]");
	public static final By LAW_ENFORCEMENT_DROPDOWN = By
			.xpath("//select[@id='drpMethodOfService']/option[contains(text(), 'Law Enforcement')]");
	public static final By CERTIFIED_MAIL_DROPDOWN = By
			.xpath("//select[@id='drpMethodofService']/option[contains(text(), 'Certified Mail')]");

	public static final By TEXT_RANKING = By.id("txtRanking");
	public static final By METHOD_OF_SERVICE_DROPDOWN = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Method Of Service')]");
	public static final By LAW_ENFORCEMENT_RHS_DROPDOWN = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Law Enforcement')]");
	public static final By EDIT_BUTTON = By.id("grdData_ctl02_btnEdit");
	public static final By DELETE_BUTTON = By.id("grdData_ctl02_btnDelete");

	// Customer Ranking Setup
	public static final By CUSTOMER_RANKING_SETUP = By.xpath("//a[contains(text(), 'Customer Ranking Setup')]");
	public static final By CUSTOMER_RANKING_SETUP_PAGE = By.xpath("//span[contains(text(), 'Customer Ranking Setup')]");
	public static final By TIER_NAME = By
			.xpath("//select[@id='drpTierName']/option[contains(text(), 'Customer - 100')]");
	public static final By ENTITY_AFF_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Entity/Affiliation')]");
	public static final By CUSTOMER_RANKING_EDIT_BUTTON = By.id("grdCustomerRanking_ctl02_btnEdit");
	public static final By CUSTOMER_RANKING_DELETE_BUTTON = By.id("grdCustomerRanking_ctl02_btnDelete");
	public static final By CREATE_EDIT_TIER = By.id("imgCreateEditTier");
	public static final By TIER_SETUP_PAGE = By.xpath("//span[contains(text(), 'Tier Setup')]");
	public static final By TIER_NAME_FIELD = By.id("txtTierName");
	public static final By TIER_RANK_FIELD = By.id("txtTierRank");
	public static final By TIER_NAME_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Tier Name')]");
	public static final By TIER_EDIT_BUTTON = By.id("grdTier_ctl02_btnEdit");
	public static final By TIER_DELETE_BUTTON = By.id("grdTier_ctl02_btnDelete");

	// Lawsuit Ranking Setup
	public static final By LAWSUIT_RANKING_SETUP = By.xpath("//a[contains(text(), 'Lawsuit Ranking Setup')]");
	public static final By LAWSUIT_RANKING_SETUP_PAGE = By.xpath("//span[contains(text(), 'Lawsuit Ranking Setup')]");
	public static final By LAWSUIT_TYPE_DROPDOWN = By
			.xpath("//select[@id='drpLawsuitType']/option[contains(text(), 'Levies')]");
	public static final By TIER_DROPDOWN = By.xpath("//select[@id='drpTierName']/option[contains(text(), 'LST-101')]");
	public static final By TIER1_DROPDOWN = By.xpath("//select[@id='drpTierName']/option[contains(text(), 'Tier-1')]");

	public static final By LAWSUIT_TYPE_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Lawsuit Type')]");
	public static final By LEVIS_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Levies')]");
	public static final By LAWSUIT_EDIT_BUTTON = By.id("grdLawsuitTypeRanking_ctl02_btnEdit");
	public static final By LAWSUIT_DELETE_BUTTON = By.id("grdLawsuitTypeRanking_ctl02_btnDelete");

	// Complexity Ranking Setup
	public static final By COMPLEXITY_RANKING_SETUP = By.xpath("//a[contains(text(), 'Complexity Ranking Setup')]");
	public static final By COMPLEXITY_RANKING_SETUP_PAGE = By
			.xpath("//span[contains(text(), 'Complexity Ranking Setup')]");

	// Manage Assignment Group
	public static final By MANAGE_ASSIGNMENT_GROUP = By.xpath("//a[contains(text(), 'Manage Assignment Group')]");
	public static final By MANAGE_ASSIGNMENT_GROUP_PAGE = By
			.xpath("//span[contains(text(), 'Auto Assignment Group List')]");
	public static final By CREATE_AUTO_ASSIGNMENT_GROUP_PAGE = By
			.xpath("//span[contains(text(), 'Create Auto Assignment Group')]");
	public static final By GROUP_NAME_TEXT = By.id("txtGroupName");
	public static final By COMPLEXITY_TIER_1 = By
			.xpath("//select[@id='drpComplexityTier']/option[contains(text(), 'Tier-1')]");
	public static final By JURISDICTION = By
			.xpath("//select[@id='ctlEntityJurisSelector_lstJurisdictions']/option[contains(text(), 'Alabama')]");
	public static final By SELECT_GROUPNAME = By.id("grdData_ctl02_lnkGrdGroupName");
	public static final By AUTO_ASSIGNMENT_GROUP_LIST = By
			.xpath("//span[contains(text(), 'Auto Assignment Group List')]");
	public static final By AUTO_ASSIGNMENT_GROUP_PROFILE_PAGE = By
			.xpath("//span[contains(text(), 'Auto Assignment Group Profile')]");
	public static final By ASSIGNMENT_GROUP_USERS = By.xpath("//span[contains(text(), 'Assignment Group Users')]");
	public static final By FIND_USER_PAGE = By.xpath("//span[contains(text(), 'Find User')]");
	public static final By EMPLOYEE_NAME = By.id("txtEmpName");
	public static final By PICK_USER_PAGE = By.xpath("//span[contains(text(), 'Pick Users')]");
	public static final By SELECT_EMPLOYEE = By.id("grdData_ctl02_chkUser");
	public static final By UNSELECT_EMPLOYEE = By.id("grdGroupUsers_ctl02_chkUser");
	public static final By ASSIGNMENT_GROUP_PAGE = By.xpath("//a[contains(text(), 'Assignment Groups')]	");
	public static final By DELETE_BTN = By.id("grdData_ctl02_btnDelete");

	// Group Profile and Priority
	public static final By USER_GROUP_PROFILE = By.xpath("//a[contains(text(), 'User Group Profile')]");
	public static final By EMPLOYEE_SEARCH_CRITERIA = By.xpath("//span[contains(text(), 'Employee Search Criteria')]");
	public static final By EMPLOYEE_SEARCH_RESULT = By.xpath("//span[contains(text(), 'Employee Search Result')]");
	public static final By SELECT_FIRST_EMPLOYEE = By.id("grdData_ctl02_lnkEmpName");
	public static final By AUTO_ASSIGNMENT_USER_GROUP_LIST = By
			.xpath("//span[contains(text(), 'Auto Assignment User Group List')]");

	public static final By MANAGE_GROUP_PRIORITY = By.xpath("//a[contains(text(), 'Manage Group Priority')]");
	public static final By GROUP_PRIORITY_MAINTENANCE_PAGE = By
			.xpath("//span[contains(text(), 'Auto Assignment Group Priority Maintenance')]");
	// public static final By SERVICE_TEAM = By.id("lstServiceTeam");//Change done for the below (instead of first second selected)
	public static final By SERVICE_TEAM = By.xpath("//select[@id='lstServiceTeam']/option[2]");
	// public static final By SERVICE_TEAM_MEMBER = By.id("lstServiceTeamMember");
	public static final By SERVICE_TEAM_MEMBER = By.xpath("//select[@id='lstServiceTeamMember']/option[1]");
	public static final By PRIORITY_ERROR_MESSAGE = By.xpath(
			"//li[contains(text(), 'Group Priority cannot be blank or equal to 0. Please enter a valid Group Priority.')]");

	// Tier Setup
	public static final By TIER_SETUP = By.xpath("//a[contains(text(), 'Tier Setup')]");

	// Auto Assignment Setup
	public static final By AUTO_ASSIGNMENT_SETUP = By.xpath("//a[contains(text(), 'Auto Assignment Setup')]");

	// Alert Maintenance Setup
	public static final By ALERT_MAINTENANCE_SETUP = By.xpath("//a[contains(text(), 'Alert Maintenance Setup')]");

	// Auto Upload
	public static final By AUTO_UPLOAD_LINK = By.xpath("//a[contains(text(), 'Auto Upload')]");
	public static final By AUTO_UPLOAD_PAGE = By.xpath("//span[contains(text(), 'Auto Upload')]");
	public static final By ERROR_IMAGES_TAB = By.xpath("//td[contains(text(), 'Error Images')]");
	public static final By IMAGE_PATH = By.xpath("//td[contains(text(), 'Image Path')]");

	public static final By INPROCESS_QUEUE = By.id("lnkInProcess");
	public static final By PROCESS_START_TIME = By.xpath("//td[contains(text(), 'Process Start Time')]");
	public static final By PENDING_UPLOAD = By.id("lnkWaitingQueue");

	// Auto Assignment Dashboard
	public static final By AUTO_ASSIGNMENT_DASHBOARD = By.linkText("Auto Assignment Dashboard");
	public static final By AUTO_ASSIGNMENT_DASHBOARD_PAGE = By
			.xpath("//span[contains(text(), 'Assignment Team Dashboard')]");
	public static final By GO_BUTTON = By.id("btnGo");
	public static final By TEAM_NAME_LINK = By.id("grdData_ctl02_lnkTeamName");
	public static final By ASSIGNMENT_PROCESSOR_DASHBOARD_PAGE = By
			.xpath("//span[contains(text(), 'Assignment Processor Dashboard')]");
	public static final By SOP_COUNT_LINK = By.id("grdData_ctl02_lnkICount");

	// Logged in User Dashboard
	public static final By LOGGED_IN_USERS_LINK = By.linkText("Logged In Users Dashboard");
	public static final By LOGGED_IN_USERS_PAGE = By
			.xpath("//span[contains(text(), 'Auto Assignment Logged In Users Dashboard')]");

	// Assignment By Tier Dashboard
	public static final By ASSIGNMENT_TIER_DASHBOARD = By.linkText("Assignment By Tier Dashboard");
	public static final By ASSIGNMENT_TIER_DASHBOARD_PAGE = By
			.xpath("//span[contains(text(), 'Auto Assignment Team and Tier Dashboard')]");
	public static final By ASSIGNMENT_PROCESSOR_TIER_DASHBOARD_PAGE = By
			.xpath("//span[contains(text(), 'Assignment Processor and Tier Dashboard')]");

	// User Availability Dashboard
	public static final By USER_AVAILABILITY_DASHBOARD = By.linkText("User Availability Dashboard");
	public static final By GO_BTN = By.id("btnDisplay");
	public static final By USER_AVAILABILITY_DASHBOARD_PAGE = By
			.xpath("//span[contains(text(), 'Auto Assignment User Availability Dashboard')]");
	public static final By TEST_NY_TEAM_DRPDOWN = By
			.xpath("//select[@id='drpProcessorTeamMember']/option[contains(text(), 'TEST New York SOP Team')]");
	public static final By AVAILABLE_STATUS = By
			.xpath("//span[@id='grdData_ctl02_lblStatus'][contains(text(), 'Available')]");

	public static final By REJECTED_HARD_COPY_REQUIRED = By.id("grdData_ctl02_lblStatus");
	public static final By PHONE_CALL_REQUIRED = By.id("grdData_ctl03_lblStatus");
	public static final By INCOMPLETE_WORKSHEETS = By.id("grdData_ctl04_lblStatus");
	public static final By PENDING_ACTION_ITEMS = By.id("grdData_ctl05_lblStatus");
	public static final By REJECTION_FOR_REVIEW = By.id("grdData_ctl06_lblStatus");
	public static final By TEAM_DROP_DOWN = By.id("drpOffice");


	// Reconciliation
	public static final By RECONCILIATION_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Reconciliation')]");
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By TRACEABLE_MAIL_RECONCILIATION_SELECTED_TAB = By
			.xpath("//td[contains(text(), 'Traceable Mail Reconciliation')]");
	public static final By ALABAMA_CT_REPS_TEAM_DRPDWN = By
			.xpath("//select[@id='ddlTeam']/option[contains(text(), 'Alabama CT Reps')]");
	public static final By CERTIFIED_MAIL_MAIL_TYPE_DRPDWN = By
			.xpath("//select[@id='ddl_mailtype']/option[contains(text(), 'Certified Mail')]");
	public static final By FIVE_DAY_NO_OF_DAYS_DRPDWN = By
			.xpath("//select[@id='ddldaysCount']/option[contains(text(), '5 day')]");
	public static final By CALENDAR = By.id("ctlDate_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By ALL_STATUS_DRPDWN = By.xpath("//select[@id='ddlStatus']/option[contains(text(),'All')]");
	public static final By ALL_SOURCE_DRPDWN = By.xpath("//select[@id='ddlSource']/option[contains(text(),'All')]");
	public static final By PROCESS_SERVER_RECONCILIATION_TAB = By.id("lnkProcessServerReconciliation");
	public static final By PROCESS_SERVER_RECONCILIATION_SELECTED_TAB = By
			.xpath("//td[contains(text(), 'Process Server Reconciliation')]");
	public static final By PROCESS_SERVER_SERVED_TYPE_DRPDWN = By
			.xpath("//select[@id='ddl_served_type']/option[contains(text(), 'Process Server')]");
	public static final By CALENDER_LEFT_NAV_LINK = By.xpath("//a[contains(text(), 'Calendar')]");
	public static final By TRACEABLE_MAIL_LINK = By.id("dlstReconciliationCalendar_ctl01_lnkCMReconciliationStatus");
	public static final By PROCESS_SERVER_LINK = By.id("dlstReconciliationCalendar_ctl01_lnkPSReconciliationStatus");
	public static final By CHOOSE_FILE_BUTTON = By.id("fileReferenceCMUpload");
	public static final By UPLOAD_BUTTON = By.id("btnUpload");
	public static final By DELETE_BTN_RECONCILIATION = By.id("btnDeleteReferenceManifest");
	public static final By MANIFEST_ARTICLE_TEXTBOX = By.id("txtAddManifestArticleNumber");
	public static final By ADD_MANIFEST_BTN = By.id("btnAdd");
	public static final By MANIFEST_ARTICLE_NUMBER = By
			.xpath("//input[@id='grdDetailData_ctl02_txtManifestArticleNumber' and @value='appletesting']");
	public static final By MANIFEST_CHECKBOX = By.id("grdDetailData_ctl02_chkReconcilationEdit");
	public static final By DELETE_BTN_MANIFEST = By.id("grdDetailData_ctl02_btnDelete");
	public static final By TIME_TEXTBOX = By.id("txtTime");
	public static final By PSNAME_DRPDWN = By.id("drpProcessServerName");
	public static final By SERVED_NAME = By.id("txtServedName");
	public static final By NAME_TYPE_DRPDWN = By.id("drpNameType");
	public static final By NAME_TAKEN_UNDER_TEXTBOX = By.id("txtTrueName");
	public static final By CASE_ID_TEXTBOX = By.id("txtCaseNumber");
	public static final By COMMENTS_DRPDWN = By.id("drpComments");
	public static final By REMARKS_DRPDWN = By.id("drpRemarks");
	public static final By REMARKS_SECTION = By.xpath("//div[contains(text(),'Remarks (Displays on Transmittal)')]");
	public static final By COMMENTS_SECTION = By.xpath("//div[contains(text(),'Comments')]");
	public static final By INTERNAL_COMMENTS_DRPDWN = By.id("drpInternalComments");
	public static final By BOTTOM_CANCELBTN = By.id("btnCancel");
	public static final By BOTTOM_SAVEBTN = By.id("btnSave");
	public static final By BOTTOM_SAVEINCOMPLETEBTN = By.id("btnSaveIncomplete");
	public static final By WIREFRAME_NUMBER = By.id("ctlFooter_ctlWFReference_lblWFReference");
	public static final By BOTTOM_MODULE_LINK = By.id("ctlFooter_lnkEntity");
	public static final By SEND_MESSAGE_BTN = By.id("btnCreateMessageTop");

	//To identify SOP Link from the header
	public static final By SOP_LINK_HEADER = By.xpath("//img[contains(@src,'/Public/Images/Nav_Sop')]");
	public static final By INCLUDE_ALL_REPRESENTATION_JURISDICTION = By.id("chkIncludeAllRepresentationJrisdiction");
	public static final By INCLUDE_STAFFING_ENTITIES = By.id("chkIncludeStaffingEntities");
	public static final By GLYPHICON_HOME = By.className("iframe-icon-Home");
	public static final By ARROW_REPRESENTATION = By.id("IBRepresentation");
	public static final By REPRESENTATION_STATUS = By.xpath("//td[@class='dataGrid2Row']//tr[@class='dataGridText']//td[3]");
	public static final By SELECT_BUTTON = By.xpath("//td[@class='dataGrid2Row']//tr[@class='dataGridText']//td[4]");
	public static final By SELECT_BUTTON_SELECT_RECIPIENT = By.xpath("//img[@alt='Select']");
	public static final By SUBMIT_CES = By.id("BtnSubmit");
	public static final By DATE_CALENDAR = By.id("ctlDateSelectorRejectDate_btnCal");
	public static final By SAVE_INCOMPLETE_BUTTON = By.id("btnSaveIncomplete");
	public static final By SORT_BY_RECEIVEDDATE_CST = By.xpath("//a[contains(text(),'Received Date CST')]");
	public static final By SORT_BY_DEFAULT = By.xpath("//span//a[contains(text(),'Default')]");
	public static final By SORT_BY_ASSIGNMENT_DATE = By.xpath("//a[contains(text(),'Assignment Date')]");    
	//To identify Manage Action Items
	public static final By DELIVERABLE = By.id("drpDeliverable");
	public static final By DELIVERY_METHOD = By.id("drpDeliveryMethod");
	public static final By PARTICIPANT_NAME = By.className("dataGridTextBold");
	public static final By EXECUTE_CENTRALIZED = By.id("grdData_ctl02_ctlSOPActionItem_imgExecuteCentralized");
	public static final By EXISTING_RECIPIENT = By.id("rdoExistingRecipient");

	// Text Maintenance
	public static final By TEXT_MAINTENANCE_LINK = By.linkText("Text Maintenance");
	public static final By CTCORP_DOCUMENT_TYPE_LINK = By.linkText("CTCORP Document Type");
	public static final By VALUE_TEXTBOX = By.id("txtValue");
	public static final By FIRST_EDIT_BTN = By.id("lstData_ctl01_ctl00_imgEdit");
	public static final By FIRST_DELETE_BTN = By.id("lstData_ctl01_ctl00_imgDelete");
	public static final By RETURN_TO_TEXT_TYPES = By.id("btnReturntoTextTypes");
	public static final By NATURE_OF_ACTION_LINK = By.linkText("Nature of Action");
	public static final By NATURE_OF_ACTION_LINK_DISABLED = By.id("grdData_ctl03_lnkLogID");
	public static final By REMARKS_LINK = By.linkText("Remarks");
	public static final By ANSWER_DATE_LINK = By.linkText("Answer Date");
	public static final By COURT_LINK = By.linkText("Court");
	public static final By NAME_TEXTBOX = By.id("txtName");
	public static final By LINE1_TEXTBOX = By.id("txtAddressLine1");
	public static final By CITY_TEXTBOX = By.id("txtCity");
	public static final By STATE_TEXTBOX = By.id("txtState");
	public static final By ZIP_TEXTBOX = By.id("txtZip");
	public static final By NAME_FIRST_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Name')]");
	public static final By EQUALS_SECOND_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), 'equals')]");
	public static final By AGENCY_LINK = By.linkText("Agency");
	public static final By ATTORNEY_LINK = By.linkText("Attorney/Sender");
	public static final By INTERNAL_COMMENTS_LINK = By.linkText("Internal Comments");
	public static final By DOCUMENT_SERVED_TYPE_LINK = By.linkText("Document Served Type");

	// SOP Volume
	public static final By SOP_VOLUME = By.linkText("SOP Volume");
	public static final By OFFICE_NAME_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Office Name')]");
	public static final By NO_OF_SOP_OVER_CAPACITY_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), '# of SOP Over Capacity')]");
	public static final By NO_OF_SOP_UNDER_CAPACITY_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), '# of SOP Under Capacity')]");
	public static final By PROJECTED_CARRYOVER_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Projected Carryover')]");
	public static final By PROJECTED_EXCESS_CAPACITY_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Projected Excess Capacity')]");
	public static final By ACTIVE_OFFICE_NAME = By.xpath("//span[contains(text(), 'Office Name')]");
	public static final By ACTIVE_NO_OF_SOP_OVER_CAPACITY = By
			.xpath("//span[contains(text(), '# of SOP Over Capacity')]");
	public static final By ACTIVE_NO_OF_SOP_UNDER_CAPACITY = By
			.xpath("//span[contains(text(), '# of SOP Under Capacity')]");
	public static final By ACTIVE_PROJECTED_EXCESS_CAPACITY = By
			.xpath("//span[contains(text(), 'Projected Excess Capacity')]");
	public static final By ACTIVE_PROJECTED_CARRYOVER = By.xpath("//span[contains(text(), 'Projected Carryover')]");

	public static final By INACTIVE_NO_OF_SOP_OVER_CAPACITY = By
			.xpath("//a[contains(text(), '# of SOP Over Capacity')]");
	public static final By INACTIVE_NO_OF_SOP_UNDER_CAPACITY = By
			.xpath("//a[contains(text(), '# of SOP Under Capacity')]");
	public static final By INACTIVE_PROJECTED_CARRYOVER = By.xpath("//a[contains(text(), 'Projected Carryover')]");
	public static final By INACTIVE_PROJECTED_EXCESS_CAPACITY = By
			.xpath("//a[contains(text(), 'Projected Excess Capacity')]");

	// Expedited Transmissions
	public static final By EXPEDITED_TRANSMISSIONS = By.linkText("Expedited Transmissions");
	public static final By PDF_BTN = By.id("grdData_ctl02_lnkView");
	public static final By FIRST_RESEND_BTN = By.id("grdData_ctl02_lnkResend");
	public static final By FIRST_CHECKBOX = By.id("grdData_ctl02_chkSelector");
	public static final By RESEND_BTN = By.id("btnResend");
	public static final By FIRST_DELETE_BTN_ON_GRID = By.id("grdData_ctl02_lnkDelete");
	public static final By REFRESH_BTN = By.id("btnRefresh");
	public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");
	public static final By FIRST_ESOP_IN_EXPEDITED_TRANSMISSION = By.id("grdData_ctl02_lblEsopId");
	public static final By FIRST_LOG_IN_EXPEDITED_TRANSMISSION = By.xpath("//a[@id='grdData_ctl02_lnkPackageView']/parent::td/preceding-sibling::td[1]");

	// Retained Worksheets
	public static final By RETAINED_WORKSHEETS_LEFT_NAV_LINK = By.linkText("Retained Worksheets");
	public static final By FIRST_WORKSHEET = By.id("grdData_ctl02_lnkLogID");
	public static final By FIRST_CHECKBOX_ON_GRID = By.id("grdData_ctl02_chkSOPDestination");
	public static final By UPDATE_REMARKS_BTN = By.id("btnUpdateRemarks");
	public static final By REMARKS_TEXTBOX = By.id("txtRemarks");
	public static final By PURGE_LOG_BTN = By.id("btnPurgeLog");
	public static final By PURGE_LOG_ERROR = By.xpath("//li[contains(text(), 'At least one worksheet must be selected for purging.')]");

	//CES
	public static final By DROP_DOWN_LIST_LEFT = By.id("ctlFilterBar_lstF");
	public static final By DROP_DOWN_LIST_RIGHT = By.id("ctlFilterBar_lstRHS");
	public static final By NRAI_DOCUMENT_TYPE = By.id("drpNRAIDocType");
	public static final By DOCUMENT_SERVED = By.id("ctlDocTypeSelector_lstAvailableItems");
	public static final By FIRST_DOCUMENT_SERVED = By.xpath("//select[@id='ctlDocTypeSelector_lstAvailableItems']//option[1]");
	public static final By DOCUMENT_SERVED_MOVE_RIGHT = By.xpath("//input[@src='/Public/images/btn_MoveRight.gif']");
	public static final By PLAINTIFF_TEXT_BOX = By.id("txtPlaintiff");
	public static final By DEFENDANT_TEXT_BOX = By.id("txtDefendant");
	public static final By UNIDENTIFIED_ENTITY_RADIO_BUTTON = By.id("rdoUnidentifiedEntity");
	public static final By ARROW_ENTITY_RADIO_BUTTON = By.id("rdoArrowEntity");
	public static final By BRANCH_PLANT_UNIDENTIFIED_ENTITY = By.id("drpBusinessUnits");
	public static final By ENTITY_TEXT_BOX = By.id("txtEntityName");
	public static final By DOMESTIC_JURISDICTION_SELECTION = By.id("ctlEntityJurisSelector_lstJurisdictions");
	public static final By REP_JURISDICTION_SELECTION = By.id("ctlRepJurisSelector_lstJurisdictions");
	public static final By ESCALATION_DETAILS = By.xpath("//tr[@id='trEscalation']//span[@class='glyphicon glyphicon-triangle-right']");
	public static final By FILTERBAR_FIRST_FILTER = By.id("ctlFilterBar_lstF");
	public static final By BUSINESS_UNIT_ARROW_ENTITY = By.id("lblBusinessUnit");
	public static final By REP_STATUS_SORT = By.linkText("Rep Status");
	public static final By SELECTED_LAWSUIT_TYPE = By.xpath("//select[@name='drpLawsuitType']//option[@selected='selected']");
	public static final By SELECTED_DOC_TYPE = By.xpath("//select[@name='drpNRAIDocType']//option[@selected='selected']");
	public static final By CLOSE_THE_ML_SLIDER = By.xpath("//div[@class='toggler']//span[@class='glyphicon glyphicon-chevron-left']");
	public static final By DEFENDANT_EMPTY_ERROR = By.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(),'Enter a value for Defendant.')]");
	public static final By REJECT_REASON_EMPTY_ERROR = By.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(),'Please select Reject Reason.')]");
	public static final By ERROR_REASON_FOR_NOT_REJECTING_SELECTED = By.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(),'Reason for Not Rejecting field should not be selected while Rejecting SOP.')]");
	public static final By PLAINTIFF_EMPTY_ERROR = By.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(),'Enter a value for Plaintiff.')]");
	public static final By ATTORNEY_SENDER_NOT_SELECTED_ERROR = By.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(),'Attorney/Sender is mandatory for Rejection.')]");
	public static final By SUBMIT_ERROR_REJECT_REASON_SELECTED = By.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(),'SOP cannot be submitted if Reject Reason is Selected.')]");
	//Entity Name Search
	public static final By CTCORP_RADIO_BUTTON = By.id("ctlBusinessUnitSelector_rbCTCORP");
	public static final By NRAI_RADIO_BUTTON = By.id("ctlBusinessUnitSelector_rbNRAI");
	// ML Slider fields
	public static final By ML_SLIDER_FIELDS_CES_PAGE = By.xpath("//table[@id='tCES']//tr//td[1]");
	public static final By DISCARD_BUTTON = By.id("BtnDiscard");
	//New Fields Added in CES Page
	public static final By TRACEABLE_MAIL_FIELD = By.id("txtTraceableMailNo");
	public static final By REJECTION_LIST_TAB = By.id("cesTabs_tbRejection");
	public static final By ATTORNEY_SENDER_NONE_SPECIFIED = By.id("rdoAttorneyNone");
	public static final By ENTITY_SEARCH_RESULT_COUNT = By.id("lblResultsCount"); 
	public static final By RADIO_BUTTON_ATTORNEYNONE = By.id("rdoAttorneyNone");
	public static final By RADIO_BUTTON_COURTNONE = By.id("rdoCourtNoneSpecified");
	public static final By RADIO_BUTTON_EXISTING_ATTORNEYSENDER = By.id("rdoAttorneySender");
	public static final By RADIO_BUTTON_EXISTING_COURT = By.id("rdoSelectCourt");
	public static final By DROP_DOWN_ATTORNEY_SENDER_NAME = By.id("drpAttorneySender");
	public static final By DROP_DOWN_COURT_NAME = By.id("drpCourt");
	public static final By TEXT_BOX_ATTORNEYNAME = By.id("txtAttorneyName");
	public static final By TEXTBOX_ATTORNEYNAME = By.id("txtAttorneySenderName");
	public static final By TEXT_BOX_COURTNAME = By.id("txtCourt");
	public static final By TEXT_BOX_AGENCY = By.id("txtAgency");
	public static final By EXISTING_COURTNAME = By.id("lblCourtName");
	public static final By UPDATE_TO_POSSIBLE_REJECTION = By.id("BtnPR");
	public static final By UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT = By.id("BtnPRNGetNext");
	public static final By OTHER_METHOD_OF_SERVICE = By.xpath("//li[contains(text(),'Enter a value for Other Mehod of Serivce.')]");
	public static final By CASE_NUMBER_IN_WORKSHEET_ERROR = By.xpath("//li[contains(text(),'Enter a valid value for Case#.')]");
	public static final By CASE_NUMBER_BLANK = By.xpath("//li[contains(text(),'Enter a value for Case#.')]");
	public static final By OTHER_METHOD_OF_SERVICE_TEXT_BOX =  By.id("txtMethodofServiceOther");
	public static final By HARD_COPY_DELIVERY = By.id("lblHardCopyDelivery");
	public static final By CASE_TEXT_PS_CASENUM = By.id("txtPSCasenum");

	//Rejection List UI in  
	public static final By CREATED_ON_SORTING_LINK = By.xpath("//span[contains(text(),'Created On')]");
	public static final By FILE_NAME_SORTING_LINK = By.xpath("//a[contains(text(),'File Name')]");
	public static final By ESOP_ID_SORTING_LINK =By.xpath("//a[contains(text(),'ESOP Id')]");
	public static final By ESCALATED_ON_SORTING_LINK = By.xpath("//a[contains(text(),'Escalated On')]");
	public static final By ESCALATED_BY_SORTING_LINK = By.xpath("//a[contains(text(),'Escalated By')]");
	public static final By REJECT_REASON_DROP_DOWN = By.id("drpRejectReason");
	public static final By REASON_FOR_NOT_REJECTING = By.id("drpReasonsForNotRejecting");
	public static final By REJECT_BUTTON_IN_CES = By.id("btnReject");

	//Default Entity Section expanded
	public static final By TRAINGLE_ICON_ARROW_ENTITY = By.xpath("//td[@id='trEntity']//span[@class='glyphicon glyphicon-triangle-bottom']");
	public static final By ATTORNEY_SENDER_LABEL = By.xpath("//td[contains(text(),'Attorney / Sender')]"); 
	public static final By COURT_LABEL = By.xpath("//td[contains(text(),'Court')]");
	public static final By REJECTION_RULES_LABEL = By.xpath("//td[contains(text(),'Rejection Rules')]");
	public static final By UNPROCESSED_COUNT = By.id("UnprocessedCnt");
	public static final By SELECT_BUTTON_IN_RELATED_LOG = By.id("IBRelatedWS");
	public static final By CES_PRODUCTIVITY_TAB = By.id("cesTabs_tbCESDashBoard");
	public static final By REJECTIONS_LIST_FIRST_CES_SELECT = By.id("grdRejectionItems_ctl02_btnEdit");
	public static final By CONTINUE_BUTTON = By.id("btnContinue");
	public static final By TOTAL_RECORDS_RELATED_WORKSHEET = By.id("lblTotalRecords");
	public static final By CASE_NUMBER_RELATED_WORKSHEET = By.xpath("//tr[@class='dataGridText']//td[3]");
	public static final By RADIO_PRESENTATION_BUTTON = By.id("rdoArrowRepresentation");
	public static final By HELP_PAGE_ICON = By.id("ctlPageTitle_lnkHelp");
	public static final By TITLE_CES_HELP_PAGE = By.xpath("//u[contains(text(),'Centralized Entity Selection - CES Processing Item tab')]");    

	//CES Productivity
	public static final By CES_PRODUCTIVITY_TITLE = By.id("ctlContextBar_lblContextTitle");
	public static final By TIER3_HEADER = By.xpath("//th[contains(text(),'Tier 3')]");
	public static final By GRAND_TOTALS_LABEL = By.xpath("//td[contains(text(),'Grand Totals')]");
	public static final By TOTAL_COUNT_GRAND_TOTALS = By.xpath("//td[contains(text(),'Grand Totals')]//following-sibling::td[5]");    
	public static final By PDF_ICON = By.xpath("//img[@alt='View']");
	public static final By PDF_CONTENT = By.tagName("//body");
	public static final By DELETE_REFERENCE_MANIFEST = By.id("btnDeleteReferenceManifest");
	public static final By PDF_IMG_TITLE = By.xpath("//span[contains(text(),'SOP_ViewImage.aspx']");

	public static final By QUALITY_MAINTENANCE = By.xpath("//a[contains(text(),'Quality Maintenance')]");
	public static final By QUALITY_RANDOMISER_SETUP = By.xpath("//a[contains(text(),'Quality Randomiser Setup')]");
	public static final By QUALITY_LIMIT_PER_DAY = By.id("grdData_ctl02_txtLimit");
	public static final By INVALID_LIMIT_ERROR = By.xpath("//li[contains(text(),'Please provide valid Limit.')]");

	// Rejection Rules Maintenance Application

	public static final By US_RADIO_BTN = By.id("ctlJurisSelector_rbJurisType1");
	public static final By US_LABEL = By.xpath("//label[@for='ctlJurisSelector_rbJurisType1']");
	public static final By CANADA_LABEL = By.xpath("//label[@for='ctlJurisSelector_rbJurisType2']");
	public static final By INTERNATIONAL_LABEL = By.xpath("//label[@for='ctlJurisSelector_rbJurisType3']");
	public static final By ADD_BUTTON = By.id("imgAdd");
	public static final By SORT_BY_JURISDICTION_LABEL = By.xpath("//span[contains(text(),'Jurisdiction')]");
	public static final By TABLE_HEADER_JURISDICTION = By.xpath("//th[contains(text(),'Jurisdiction')]");
	public static final By SORT_BY_MODIFIED_BY_LABEL  = By.xpath("//a[contains(text(),'Modified By')]");
	public static final By TABLE_HEADER_MODIFIED_BY = By.xpath("//th[contains(text(),'Modified By')]");
	public static final By SORT_BY_MODIFIED_DATE_LABEL  = By.xpath("//a[contains(text(),'Modified Date')]");
	public static final By TABLE_HEADER_MODIFIED_DATE = By.xpath("//th[contains(text(),'Modified Date')]");
	public static final By FIRST_EDIT_BUTTON = By.id("grdData_ctl02_btnEdit");
	public static final By REJECTION_RULE_DROP_DOWN = By.id("drpRejectionRule");
	public static final By STATUS_TEXT_FIELD = By.id("txtStatus");
	public static final By ACTION_TEXT_FIELD = By.id("txtAction");
	public static final By REJECTION_RULE1_FIRST_EDIT = By.id("grdDataGroup1_ctl02_lnkEdit");
	public static final By REJECTION_RULE2_FIRST_EDIT = By.id("grdDataGroup2_ctl02_lnkEdit");
	public static final By REJECTION_RULE1_FIRST_DELETE = By.id("grdDataGroup1_ctl02_lnkDelete");
	public static final By REJECTION_RULE2_FIRST_DELETE = By.id("grdDataGroup2_ctl02_lnkDelete");
	public static final By REJECTION_RULE_MAINTENANCE_CHECK_BOX = By.id("chkRejectionRulesMaintenance");
	public static final By PERMISSIONS_UNDER_ADMIN_PERMISSION = By.id("lblRoleAdminPermissions");    
	public static final By LAW_SUIT_TYPE = By.xpath("//li[contains(text(),'Case#')]");
	public static final By LAW_SUIT_SUB_TYPE = By.xpath("//li[contains(text(),'Lawsuit SubType')]");
	public static final By CANADA_RADIO_BTN = By.id("ctlJurisSelector_rbJurisType2");
	public static final By INTERNATIONAL_RADIO_BTN = By.id("ctlJurisSelector_rbJurisType3");
	public static final By JURIS_DRP_DWN = By.id("ctlJurisSelector_lstJurisdictions");
	public static final By ADD_BTN = By.id("imgAdd");
	public static final By SAVE_BUTTON = By.id("imgSave");
	public static final By QUICKLOG_BUTTON = By.id("btnQuickLogTop");
	public static final By QUICKLOG_STATUS = By.xpath("//span[contains(text(),'Quicklog')]");

	//Field on ML Slider block on Create, Edit, Review Worksheet Page
	public static final By CASEIDFIELD = By.xpath("//td[contains(text(),'Case#')]");
	public static final By JURISDICTIONFIELD = By.xpath("//td[contains(text(),'Jurisdiction')]");
	public static final By PLAINTIFF = By.xpath("//td[contains(text(),'Plaintiff')]");
	public static final By DEFENDANT = By.xpath("//td[contains(text(),'Defendant')]");
	public static final By LAWSUITTYPEFIELD = By.xpath("//td[contains(text(),'Lawsuit Type')]");
	public static final By LAWSUITSUBTYPEFIELD = By.xpath("//td[contains(text(),'Lawsuit SubType')]");
	public static final By ANSWERDATE = By.xpath("//td[contains(text(),'Answer Date')]");
	public static final By POSTMARKDATE = By.xpath("//td[contains(text(),'Postmark Date')]");
	public static final By FIRSTELEMENT_ON_ML_SLIDER = By.xpath("//table[@id='t1']/tbody/child::tr/td[contains(text(),'Jurisdiction')]");
	public static final By SECONDELEMENT_ON_ML_SLIDER = By.xpath("//table[@id='t1']/tbody/child::tr/td[contains(text(),'Case#')]");
	public static final By PRIORITYMAILIDFIELD = By.xpath("//td[contains(text(),'Priority Mail#')]");
	public static final By INITIAL_SUBSEQUENT_FIELD = By.xpath("//td[contains(text(),'Initial/ Subsequent')]");
	public static final By COURTNAME = By.xpath("//td[contains(text(),'Court Name')]");
	public static final By COURTADDRESS = By.xpath("//td[contains(text(),'Court Address')]");
	public static final By AGENCYNAME = By.xpath("//td[contains(text(),'Agency Name')]");
	public static final By ATTORNEYNAME = By.xpath("//td[contains(text(),'Attorney Name')]");
	public static final By NATUREOFACTION = By.xpath("//td[contains(text(),'Nature of Action')]");
	public static final By AMOUNTDUE = By.xpath("//td[contains(text(),'Amount Due')]");
	public static final By DOCUMENTTYPE = By.xpath("//td[contains(text(),'Document Type')]");
	public static final By ATTORNEYADDRESS = By.xpath("//td[contains(text(),'Attorney Address')]");
	public static final By AGENCYADDRESS = By.xpath("//td[contains(text(),'Agency Address')]");

	//Validations on Create, Edit, Review Worksheet Page
	public static final By RECEIPT_DATE_ERRMSG = By
			.xpath("//li[contains(text(), 'Enter a value for Receipt Date.')]");
	public static final By RECEIVED_BY_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for Received By Facility.')]");
	public static final By ASSIGNED_TO_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for Assigned To Facility.')]");
	public static final By METHOD_OF_SERVICE_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for Method of Service.')]");
	public static final By INITIAL_ERRMSG = By
			.xpath("//li[contains(text(), 'Choose Initial/Subsequent')]");
	public static final By CASEID_PLAINTIFF_ERRMSG = By
			.xpath("//li[contains(text(), 'Enter values for Case # and Plaintiff / Debtor.')]");
	public static final By DEFENDANT_ERRMSG = By
			.xpath("//li[contains(text(), 'Enter a value for Defendant/Creditor Name.')]");
	public static final By CT_ENTITY_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for CT Entity.')]");
	public static final By REPRESENTATION_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for Representation.')]");
	public static final By COURT_ERRMSG = By
			.xpath("//li[contains(text(), 'Court must be entered')]");
	public static final By AGENCY_ERRMSG = By
			.xpath("//li[contains(text(), 'Agency must be entered')]");
	public static final By ATTORNEY_ERRMSG = By
			.xpath("//li[contains(text(), 'Attorney must be entered')]");
	public static final By CT_DOCUMENT_TYPE_ERRMSG = By
			.xpath("//li[contains(text(), 'Enter a value for Document Type.')]");
	public static final By LAWSUIT_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for LawsuitType.')]");
	public static final By ANSWER_DATE_ERRMSG = By
			.xpath("//li[contains(text(), 'Answer Date must be entered')]");
	public static final By REMARKS_ERRMSG = By
			.xpath("//li[contains(text(), 'Enter a value for valid Remarks.')]");
	public static final By REVIEW_SUBTYPE_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for Review sub type.')]");
	public static final By PLAINTIFF_ERRMSG = By
			.xpath("//li[contains(text(), 'Enter a value for Plaintiff / Debtor.')]");

	//Fields on Review Worksheet Page
	public static final By SAVE_INCOMPLETE_REVIEWPAGEBUTTON = By.id("btnSaveIncompleteReviewTop");
	public static final By BOTTOM_SAVEINCOMPLETEBTN_REVIEWPAGE = By.id("btnSaveIncompleteReview");
	public static final By COMMENTS_BTN = By.id("ctlPageTitle_btnViewAllComments");
	public static final By REVIEW_TYPE_DRPDWN = By.id("drpReviewType");
	public static final By REVIEW_STATUS = By.id("lblReviewStatus");
	public static final By ERROR_TYPE = By.id("lblErrorType");
	public static final By ADDITIONAL_REVIEW_FIELDS = By.xpath("//div[contains(text(),'Additional Review Fields')]");
	public static final By PREVIEW_PROFILE_BTN = By.id("btnProfilePreview");
	public static final By PREVIEW_DI_BTN = By.id("btnDIPreview");

	public static final By INITIAL_TYPE = By.xpath("//input[@id='rdoInitial'][@unchecked='unchecked']");
	public static final By SUBSEQUENT_TYPE = By.xpath("//input[@id='rdoSubsequent'][@checked='checked']");
	public static final By PRELIMINARY_TYPE = By.xpath("//input[@id='rdoPreliminaryProceeding'][@unchecked='unchecked']");
	public static final By NONE_TYPE = By.xpath("//input[@id='rdoNone'][@unchecked='unchecked']");
	public static final By CREATE_PAGE_TITLE = By.xpath("//span[contains(text(),'Create Worksheet')]");
	public static final By EDIT_PAGE_TITLE = By.xpath("//span[contains(text(),'Edit Worksheet')]");
	public static final By REVIEW_PAGE_TITLE = By.xpath("//span[contains(text(),'Review Worksheet')]");
	public static final By SAVE_INCOMPLETE_REVIEW_BUTTON = By.id("btnSaveIncompleteReview");

	//Fields on Related Worksheet Basic Search Page
	public static final By IGNORE_ENTITY = By.id("chkIgnoreEntity");
	public static final By IGNORE_REP_JURISDICTION = By.id("chkIgnoreRepJuris");

	//Fields on Top Header SOP Page
	public static final By NEW_MESSAGE_HEADER = By.xpath("//span[contains(text(), 'You have new messages')]");
	public static final By TEAMS_MESSAGE_HEADER = By.xpath("//span[contains(text(), 'Your team has new messages')]");
	public static final By SEND_MSG_BTN = By.id("btnCreateMessage");
	public static final By SEND_MESSAGE_ON_SOP_LIST = By.xpath("//img[@alt='Create Message']");
	public static final By CARRIER_PACKAGE_SEARCH = By.linkText("Carrier Package Search");
	public static final By ACTION_ITEMS_LEFT_NAV_LINK = By.linkText("Action Items");
	public static final By SEND_MESSAGE_BTN_ON_ACTIONLIST = By.xpath("//img[@alt='Send Message']");
	public static final By SUBSEQUENT = By.xpath("//span[contains(text(), 'Subsequent')]");
	public static final By UNPOSTED_LOGS_NAV_LINK = By.linkText("Un-Posted Logs");
	public static final By PRIORITY_COLUMN = By.xpath("//td[contains(text(),'Priority')]");
	public static final By PRIORITY_SORT_LINK = By.xpath("//a[contains(text(),'Priority')]");
	public static final By PRIORITY_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Priority')]");
	public static final By CLONED_COPIED_COLUMN = By.xpath("//td[contains(text(),'Cloned/Copied From')]");
	public static final By DOCKET_HISTORY_NAV_LINK = By.linkText("Docket History");
	public static final By NOA_DATE_CALENDAR = By.xpath("//span[contains(text(), 'Date Calendar (Personal Injury)')]");
	public static final By REVIEW_SUB_TYPE = By.id("drpReviewSubType");
	public static final By NOA_TERMINATIONOFGARNISHMENT = By.xpath("//span[contains(text(), 'Termination of Garnishment')]");
	public static final By WORKSHEET_REVIEW_BTN = By.id("ctlPageTitle_btnReview");
	public static final By NOA_DEFAULTJUDGMENT = By.xpath("//span[contains(text(), 'Default Judgment')]");
	public static final By PRIORITY_SORT_LINK_MYWORKSHEETS_PAGE = By.xpath("//span[contains(text(),'Priority')]");
	public static final By MY_TEAMS_WORKSHEETS_LINK = By.id("lnkTeamWorksheet");
	public static final By SELECT_ALL_BTN = By.id("btnSelectPage");
	public static final By SELECT_NONE_BTN = By.id("btnUnSelectPage");

	//Sorting Links on MyWorksheets Page & MyTeamsWorksheets Page
	public static final By ACTIVE_RECEIVED_DATE_SORT_LINK = By.xpath("//span[contains(text(), 'Received Date')]");
	public static final By ACTIVE_LOG_ID_SORT_LINK = By.xpath("//span[contains(text(), 'Log #')]");
	public static final By ACTIVE_ENTITY_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'Entity Name')]");
	public static final By ACTIVE_STATUS_SORT_LINK = By.xpath("//span[contains(text(), 'Status')]");
	public static final By ACTIVE_CASE_ID_SORT_LINK = By.xpath("//span[contains(text(), 'Case #')]");
	public static final By ACTIVE_PLAINTIFF_DEBTOR_SORT_LINK = By.xpath("//span[contains(text(), 'Plaintiff / Debtor')]");
	public static final By ACTIVE_DEFENDANT_CREDITOR_SORT_LINK = By.xpath("//span[contains(text(), 'Defendant / Creditor')]");
	public static final By ACTIVE_RECEIVED_BY_OFFICE_SORT_LINK = By.xpath("//span[contains(text(), 'Received by Office')]");
	public static final By ACTIVE_BRANCH_PLANT_SORT_LINK = By.xpath("//span[contains(text(), 'Branch Plant')]");
	public static final By ACTIVE_PLTFF_DEBTOR_SORT_LINK = By.xpath("//span[contains(text(), 'Pltf. / Debtor')]");
	public static final By ACTIVE_ASSIGNED_TO_SORT_LINK = By.xpath("//span[contains(text(), 'Assigned To')]");
	public static final By ACTIVE_DEFT_CREDITOR_SORT_LINK = By.xpath("//span[contains(text(), 'Deft. / Creditor')]");
	public static final By LOG_ID_SORT = By.xpath("//a[contains(text(), 'Log #')]");
	public static final By ENTITY_NAME_SORT = By.xpath("//a[contains(text(), 'Entity Name')]");
	public static final By STATUS_SORT = By.xpath("//a[contains(text(), 'Status')]");
	public static final By CASE_ID_SORT = By.xpath("//a[contains(text(), 'Case #')]");
	public static final By PLAINTIFF_DEBTOR_SORT = By.xpath("//a[contains(text(), 'Plaintiff / Debtor')]");
	public static final By DEFENDANT_CREDITOR_SORT = By.xpath("//a[contains(text(), 'Defendant / Creditor')]");
	public static final By RECEIVED_BY_OFFICE_SORT = By.xpath("//a[contains(text(), 'Received by Office')]");
	public static final By BRANCH_PLANT_SORT = By.xpath("//a[contains(text(), 'Branch Plant')]");
	public static final By PLTFF_DEBTOR_SORT = By.xpath("//a[contains(text(), 'Pltf. / Debtor')]");
	public static final By ASSIGNED_TO_SORT = By.xpath("//a[contains(text(), 'Assigned To')]");
	public static final By DEFT_CREDITOR_SORT = By.xpath("//a[contains(text(), 'Deft. / Creditor')]");
	//Checkboxes on Worksheet Profile
	public static final By PRIORITY_CHECKBOX = By.id("chkPriority");
	public static final By REJECTED_CHECKBOX = By.id("chkRejected");
	public static final By ATTEMPTED_CHECKBOX = By.id("chkAttempted");
	public static final By CONSOLIDATED_CHECKBOX = By.id("chkConsolidated");
	public static final By MULTIPLE_CHECKBOX = By.id("chkMultiple");
	public static final By BANKRUPTCY_CHECKBOX = By.id("chkBankruptcy");
	public static final By LETTER_CHECKBOX = By.id("chkLetterInd");
	public static final By DEFENDANT_CHECKBOX = By.id("chkDefendantName");
	public static final By ENTITY_CHECKBOX = By.id("chkEntity");
	public static final By COURT_CHECKBOX = By.id("chkCourt");
	public static final By AGENCY_CHECKBOX = By.id("chkAgency");
	public static final By ATTORNEY_CHECKBOX = By.id("chkAttorney");
	public static final By CASEID_CHECKBOX = By.id("chkCaseID");
	public static final By PLAINTIFF_CHECKBOX = By.id("chkPlaintiff");
	public static final By DOCUMENT_TYPE_CHECKBOX = By.id("chkDocumentType");
	public static final By SPECIAL_CIRCUMSTANCES_CHECKBOX = By.id("chkDocumentType");
	public static final By LAWSUIT_TYPE_CHECKBOX = By.id("chkLawsuitType");
	public static final By NATURE_OF_ACTION_CHECKBOX = By.id("chkNatureofAction");
	public static final By ANSWER_DATE_CHECKBOX = By.id("chkAnswerDate");
	//NPD Sprint 53 change
	public static final By SOP_WORKFLOW_SORT = By.xpath("//a[contains(text(), 'SOP Workflow')]");   
	public static final By BOA_USE_SUBPOENA_LAWSUIT_TYPE = By.xpath("//div[@id='ctlSOPDIView_3']/child::div/table/tbody//tr//td//input");
	public static final By BOA_USE_SUBPOENA_LAWSUIT_TYPE_HARD_COPY_REQUIRED = By.xpath("//div[@id='ctlSOPDIView_1']/child::div/table/tbody//tr//td//input");
	public static final By JP_USE_SUBPOENA_LAWSUIT_TYPE = By.xpath("//div[@id='ctlSOPDIView_0']/child::div/table/tbody//tr//td//input");
	public static final By JP_USE_SUBPOENA_LAWSUIT_TYPE_HARD_COPY_REQUIRED = By.xpath("//div[@id='ctlSOPDIView_3']/child::div/table/tbody//tr//td//input");
	public static final By SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL = By.xpath("//span[contains(text(),'SOP Papers with Transmittal')]/parent::td/following-sibling::td/input[@src='/public/images/btn_Retain.gif']");
	public static final By EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL = By.xpath("//span[contains(text(),'ISOP')]/parent::td/parent::tr/parent::tbody/parent::table/parent::td/parent::tr/preceding-sibling::tr//td/input[@src='/public/images/btn_Execute.gif']");
	public static final By EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL = By.xpath("//span[contains(text(),'SOP Papers with Transmittal')]/parent::td/following-sibling::td/input[@src='/public/images/btn_ExecuteManual.gif']");
	public static final By UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL = By.xpath("//span[contains(text(),'Retain SOP')]/ancestor::tr/preceding-sibling::tr//td/input[@src='/public/images/btn_UnExecute.gif']");
	public static final By UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL = By.xpath("//span[contains(text(),'ISOP')]/parent::td/parent::tr/parent::tbody/parent::table/parent::td/parent::tr/preceding-sibling::tr//td/input[@src='/public/images/btn_UnExecute.gif']");
	public static final By JP_USE_GARNISMENTS_NON_WAGE_HARD_COPY = By.xpath("//div[@id='ctlSOPDIView_7']/child::div/table/tbody//tr//td//input");
	public static final By UNEXECUTE_COMMENTS_TEXT_BOX = By.id("txtUnexecuteComments");
	public static final By UNEXECUTE_ACTION_ITEM_BUTTON = By.id("btnUnexecuteActionItem");
	public static final By VALUE_OF_LAW_SUIT_TYPE_IN_DI = By.xpath("//div[starts-with(@id,'ctlSOPDIView')]/img/following-sibling::span[not(contains(text(),'Special Circumstances'))]/parent::div");
	public static final By USE_BUTTON_IN_LAWSUIT = By.xpath("//div[starts-with(@id,'ctlSOPDIView')]/img/following-sibling::span[not(contains(text(),'Special Circumstances'))]/following-sibling::div/table/tbody//tr//td//input");
	public static final By VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI = By.xpath("//span[contains(text(),'Special Circumstances')]/parent::div");
	public static final By USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES = By.xpath("//div[starts-with(@id,'ctlSOPDIView')]/img/following-sibling::span[contains(text(),'Special')]/following-sibling::div/span[contains(text(),'Law')]/following-sibling::div/table/tbody//tr//td//input");
	public static final By BUTTON_CREATE_PACKAGE = By.id("btnCreatePackage");

	//CIOX Sprint 7 change
	public static final By CREATE_WORKSHEET_NAV_LINK = By.linkText("Create Worksheet");
	public static final By MY_WORKSHEETS_NAV_LINK = By.linkText("My Worksheets");
	public static final By WS_SEARCH_BY_BATCHNO_NAV_LINK = By.linkText("WS Search by Batch No");
	public static final By CARRIER_PENDING_QUEUE = By.linkText("Carrier Pending Queue");
	public static final By MY_ACTION_ITEMS_NAV_LINK = By.linkText("My Action Items");
	public static final By CREATE_WORKSHEET_BUTTON = By.id("btnCreateWorksheet");
	public static final By RECEIVED_JURISDICTION = By.id("lblReceivedJuris");
	public static final By OLD_COURT_JURISDICTION = By.xpath("//span[contains(text(), '11th Judicial District Court Harris County')]");
	public static final By RADIO_EXISTING_COURT = By.xpath("//input[@id='rdoSelectCourt'][1]");
	public static final By RADIO_USE_THIS_COURT = By.xpath("//input[@id='rdoCourtOthers'][1]");
	public static final By CREATE_EDIT_REVIEW_IFRAMEID = By.id("frmSOPData");
	public static final By SELECT_ENTITY = By.xpath("//img[@alt='Select']");
	public static final By CREATE_HELP_ICON = By.xpath("//img[@alt='Help']");
	public static final By REVIEW_TYPE_LABEL = By.xpath("//td[contains(text(),'Review Type')]");

	public static final By CES_INTERNAL_COMMENTS_DRPDWN = By
			.xpath("//select[@id='drpCESComment']//option[contains(text(), 'HCD approved')]");
	public static final By INTERNAL_COMMENTS_LABEL = By.xpath("//td[contains(text(),'Internal Comment(s)')]");
	public static final By COMMON_ALERTS_LABEL = By.xpath("//td[contains(text(),'Common Alert(s)')]");
	public static final By CES_INTERNAL_COMMENTS_LABEL = By.xpath("//td[contains(text(),'CES Internal Comment')]");
	public static final By INTERNAL_COMMENTS_FIELD = By.xpath("//td[contains(text(),'Internal Comments')]");
	public static final By INTERNAL_COMMENTS_METADATA = By.id("lblInternalComments");
	public static final By INTERNAL_COMMENTS_TEXTBOX = By.xpath("//textarea[@id='txtInternalComments']");
	public static final By SOP_INTERNAL_COMMENTS_DRPDWN = By
			.xpath("//select[@id='drpInternalComments']//option[contains(text(), 'HCD approved')]");
	public static final By CES_INTERNAL_COMMENTS_TEXT = By.id("lblCESComment");
	public static final By COMMENTS_LABEL_METADATA = By.xpath("//td[contains(text(),'NOTE')]");
	public static final By SPECIFIC_COMMENTS_METADATA = By.xpath("//td[contains(text(),'Post Issues')]");
	public static final By USER_COMMENTS = By.id("grdCommentData_ctl01_imgComments");
	public static final By FIRST_INTERNAL_COMMENTS = By.xpath("//select[@id='drpInternalComments']//option[2]");

	public static final By CES_INTERNAL_COMMENTS = By.xpath("//textarea[@id='txtCESComment']");
	public static final By FIRST_REJECT_REASON = By.xpath("//select[@id='drpRejectReason']//option[1]");

	public static final By PDF_CREATE_EDIT_REVIEW_IFRAMEID = By.id("frmImage2");
	public static final By EXPAND_PDF_CREATE_EDIT_REVIEW = By.xpath("//span[@class='glyphicon glyphicon-fullscreen']");
	public static final By COLLAPSE_PDF_CREATE_EDIT_REVIEW = By.xpath("//span[@class='glyphicon glyphicon-resize-small']");
	public static final By CLOSE_PDF_CREATE_EDIT_REVIEW = By.xpath("//span[@class='glyphicon glyphicon-remove']");
	public static final By OPEN_PDF_CREATE_EDIT_REVIEW = By.xpath("//span[@class='glyphicon glyphicon-file']");
	public static final By PDF_POPUP_CREATE_EDIT_REVIEW = By.xpath("//span[@class='glyphicon glyphicon-new-window']");
	public static final By TOP_SAVE_INCOMPLETE_BTN = By.id("btnSaveIncompleteTop");
	public static final By OFFICE_COURT_FIELD = By.id("ddlOfficeName");
	public static final By STATE_OF_COURT_LABEL = By.xpath("//td[contains(text(),'State Of Court')]");
	public static final By STATE_OF_COURT_DROPDOWN = By.id("drpStateOfCourt");
	public static final By NY_STATE_OF_COURT_DRPDWN = By.xpath("//select[@id='drpStateOfCourt']//option[contains(text(), 'New York')]");
	public static final By ALABAMA_STATE_OF_COURT_DRPDWN = By.xpath("//select[@id='drpStateOfCourt']//option[contains(text(), 'Alabama')]");
	public static final By GLOBAL_STATE_OF_COURT_DRPDWN = By.xpath("//select[@id='drpStateOfCourt']//option[contains(text(), '-- Select One --')]");
	public static final By LINE2_TEXTBOX = By.id("txtAddressLine2");
	public static final By LINE3_TEXTBOX = By.id("txtAddressLine3");
	public static final By LINE4_TEXTBOX = By.id("txtAddressLine4");
	public static final By COUNTY_TEXTBOX = By.id("txtCounty");
	public static final By COUNTRY_TEXTBOX = By.id("txtCountry");
	public static final By PHONE_TEXTBOX = By.id("txtPhone");
	public static final By FAX_TEXTBOX = By.id("txtFax");
	public static final By EMAIL_TEXTBOX = By.id("txtEmail");
	public static final By SPECIFIC_STATE_OF_COURT_DRPDWN = By.xpath("//select[@id='drpJurisdictions']//option[contains(text(), 'New York')]");
	public static final By SPECIFIC_DROP_DOWN_COURT_NAME = By.xpath("//select[@id='drpCourt']//option[contains(text(), 'CIOXAutomationTestingEdit')]");
	public static final By ENTITY_AFF_SG_ALERTS_LABEL = By.xpath("//td[contains(text(),'Entity/Affiliation/SubGroup Alert(s)')]");
	public static final By CDSOP_ALERTS_LABEL = By.xpath("//td[contains(text(),'Customer Comments (CDSOP Only)')]");


	//NPD DevOPs Sprint 2 changes
	//("//span[contains(text(),'ISOP')]/parent::td/parent::tr/parent::tbody/parent::table/parent::td/parent::tr/preceding-sibling::tr//td/input[@src='/public/images/btn_Execute.gif']")
	public static final By EXECUTE_SOP_PAPER_WITH_TRANSMITTAL = By.xpath("//span[contains(text(),'SOP Papers with Transmittal')]/parent::td/following-sibling::td/input[@src='/public/images/btn_Transmittal.gif']/following-sibling::input[@src='/public/images/btn_Execute.gif']");
	//("//td/div/span[contains(text(),'Special Circumstances')]/parent::div/child::div")
	public static final By VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES = By.xpath("//td/div/span[contains(text(),'Special Circumstances')]/parent::div/child::div");
	//("//td/div/span[not(contains(text(),'Special Circumstances'))]/parent::div");
	public static final By VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_NO_SPECIAL_CIRCUMSTANCES = By.xpath("//td/div//span[not(contains(text(),'Special Circumstances'))]/parent::div[starts-with(@class,'DITreeNodeFirst')]");

	//USE_BUTTON_IN_LAWSUIT
	//("//td/div//span[not(contains(text(),'Special Circumstances'))]/following-sibling::div/table/tbody//tr//td//input");
	public static final By USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES = By.xpath("//td/div/span[not(contains(text(),'Special Circumstances'))]/parent::div[starts-with(@class,'DITreeNodeFirst')]/div//td/input");

	public static final By USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES = By.xpath("//div[starts-with(@id,'ctlSOPDIView')]/img/following-sibling::span[contains(text(),'Special')]/following-sibling::div/span[contains(text(),'Law')]/following-sibling::div/table/tbody//tr//td//input");

	public static final By POST_MARKED_REASON_ERROR = By.xpath("//li[contains(text(),'Select a Post Marked reason.')]");
	public static final By POST_MARKED_RADIO_BUTTON = By.id("rdoPostMarkedDate");


	public static final By SPECIAL_CIRCUMSTANCES_ERRMSG = By
			.xpath("//li[contains(text(), 'Select a value for Special Circumstance.')]");
	public static final By CASE_RADIO_BTN = By.xpath("//input[@id='rdoCase' and @checked='checked']");

    //NPD DevOPs sprint5 changes
    public static final By TITLE_OF_ACTION_RULES_MAINTENANCE = By.xpath("//a[contains(text(),'Title Of Action Rules Maintenance')]");
    public static final By LAW_SUIT_TYPE_DROP_DOWN = By.id("drpLawSuit");
    public static final By TITLE_TOA_APP = By.id("ctlPageTitle_lblTitle");
    public static final By NRAI_TOA = By.id("lnkNRAITOA");
    public static final By TOA_LOOK_UP = By.id("lnkManageTOALookup");
    public static final By TEXT1 = By.xpath("//tr[@id='trText1']/td[@class='dataLabel']");
    public static final By TEXT2 = By.xpath("//tr[@id='trText2']/td[@class='dataLabel']");
    public static final By TEXT3 = By.xpath("//tr[@id='trText3']/td[@class='dataLabel']");
    public static final By TEXT4 = By.xpath("//tr[@id='trText4']/td[@class='dataLabel']");
    public static final By TEXT5 = By.xpath("//tr[@id='trText5']/td[@class='dataLabel']");
    public static final By TEXT6 = By.xpath("//tr[@id='trText6']/td[@class='dataLabel']");
    public static final By TEXT1_DROP_DOWN = By.id("drpText1");
    public static final By DUPLICATE_RECORDS_MESSAGE = By.xpath("//span[contains(text(),'Duplicate record not allowed.')]");
    public static final By EDIT_TEST_TEXT_VALUE = By.xpath("//span[contains(text(),'Test Value1')]/parent::td/following-sibling::td/a/img[@src='/public/images/btn_Edit.gif']");
    public static final By TEXT_FIELD_TOA_LOOKUP = By.id("txtText");
    public static final By DELETE_TEST_TEXT_VALUE = By.xpath("//span[contains(text(),'Test Value2')]/parent::td/following-sibling::td/a/img[@src='/public/images/btn_Delete.gif']");
    public static final By ERROR_ON_DELETE_TEXT_IN_USE = By.xpath("//span[contains(text(),'You must First Remove/Replace this value in all existing Title of Action Formats')]"); 

	//BOFA Sprint3 Changes
	public static final By ACTIVE_DEFAULT_SORT_LINK = By.xpath("//span[contains(text(), 'Default')]");
	public static final By ACTIVE_CES_PRIORITY_SORT_LINK = By.xpath("//span[contains(text(), 'CES Priority')]");
	public static final By ACTIVE_RECEIVED_JURIS_SORT_LINK = By.xpath("//span[contains(text(), 'Received Juris')]");
	public static final By ACTIVE_RECEIVED_BY_FACILITY_SORT_LINK = By.xpath("//span[contains(text(), 'Received By Facility')]");
	public static final By ACTIVE_BIG_SORT_LINK = By.xpath("//span[contains(text(), 'Big 6')]");
	public static final By ACTIVE_SHORT_ANSWER_DATE_SORT_LINK = By.xpath("//span[contains(text(), 'Short Answer Date')]");
	public static final By ACTIVE_PROCESSOR_SORT_LINK = By.xpath("//span[contains(text(), 'Processor ')]");
	public static final By ACTIVE_FILE_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'File Name')]");
	public static final By ACTIVE_CUSTOMER_SORT_LINK = By.xpath("//span[contains(text(), 'Customer')]");
	public static final By ACTIVE_WORKSHEET_TYPE_SORT_LINK = By.xpath("//span[contains(text(), 'Worksheet Type')]");
	public static final By ACTIVE_CONFIRMATION_NUMBER_SORT_LINK = By.xpath("//span[contains(text(), 'Confirmation Number')]");
	public static final By ACTIVE_DELIVERY_METHOD_SORT_LINK = By.xpath("//span[contains(text(), 'Delivery Method')]");
	public static final By ACTIVE_SECOND_REVIEW_SORT_LINK = By.xpath("//span[contains(text(), 'Second Review')]");
	public static final By ACTIVE_TIME_SENSITIVE_SORT_LINK = By.xpath("//span[contains(text(), 'Time Sensitive')]");
	public static final By ACTIVE_DAMAGE_AMOUNT_SORT_LINK = By.xpath("//span[contains(text(), 'Damage Amount')]");
	public static final By ACTIVE_LAWSUIT_TYPE_SORT_LINK = By.xpath("//span[contains(text(), 'Lawsuit Type')]");
	public static final By ACTIVE_AGING_IN_HOURS_SORT_LINK = By.xpath("//span[contains(text(), 'Aging In Hours')]");
	public static final By ACTIVE_AGING_IN_DAYS_SORT_LINK = By.xpath("//span[contains(text(), 'Aging In Days')]");
	public static final By ACTIVE_ENTITY_AFFILIATION_SORT_LINK = By.xpath("//span[contains(text(), 'Entity/Affiliation')]");
	public static final By ACTIVE_ASSIGNMENT_TYPE_SORT_LINK = By.xpath("//span[contains(text(), 'Assignment Type')]");
	public static final By ACTIVE_ASSIGNMENT_DATE_SORT_LINK = By.xpath("//span[contains(text(), 'Assignment Date')]");
	public static final By ACTIVE_ON_HOLD_SORT_LINK = By.xpath("//span[contains(text(), 'On Hold')]");
	public static final By ACTIVE_RECEIVED_METHOD_RANK_SORT_LINK = By.xpath("//span[contains(text(), 'Received Method Rank')]");
	public static final By ACTIVE_PRIORITY_RANK_SORT_LINK = By.xpath("//span[contains(text(), 'Priority Rank')]");
	public static final By ACTIVE_CUSTOMER_RANK_SORT_LINK = By.xpath("//span[contains(text(), 'Customer Rank')]");
	public static final By ACTIVE_LAWSUIT_RANK_SORT_LINK = By.xpath("//span[contains(text(), 'Lawsuit Rank')]");
	public static final By ACTIVE_COMPLEXITY_RANK_SORT_LINK = By.xpath("//span[contains(text(), 'Complexity Rank')]");
	public static final By ACTIVE_COMPLEXITY_TIER_SORT_LINK = By.xpath("//span[contains(text(), 'Complexity Tier')]");
	public static final By ACTIVE_ESOP_ID_SORT_LINK = By.xpath("//span[contains(text(), 'ESOP Id')]");
	public static final By ACTIVE_RECEIVED_DATE_CST_SORT_LINK = By.xpath("//span[contains(text(), 'Received Date CST')]");
	public static final By ACTIVE_SOP_WORKFLOW_SORT_LINK = By.xpath("//span[contains(text(), 'SOP Workflow')]");
	public static final By BIG_SORT_LINK = By.xpath("//a[contains(text(), 'Big 6')]");
	public static final By SHORT_ANSWER_DATE_SORT_LINK = By.xpath("//a[contains(text(), 'Short Answer Date')]");
	public static final By PROCESSOR_SORT_LINK = By.xpath("//a[contains(text(), 'Processor ')]");
	public static final By FILE_NAME_SORT_LINK = By.xpath("//a[contains(text(), 'File Name')]");
	public static final By CUSTOMER_SORT_LINK = By.xpath("//a[contains(text(), 'Customer')]");
	public static final By WORKSHEET_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Worksheet Type')]");
	public static final By CONFIRMATION_NUMBER_SORT_LINK = By.xpath("//a[contains(text(), 'Confirmation Number')]");
	public static final By DELIVERY_METHOD_SORT_LINK = By.xpath("//a[contains(text(), 'Delivery Method')]");
	public static final By SECOND_REVIEW_SORT_LINK = By.xpath("//a[contains(text(), 'Second Review')]");
	public static final By ASSIGNED_TO_SORT_LINK = By.xpath("//a[contains(text(), 'Assigned To')]");
	public static final By CES_PRIORITY_SORT_LINK = By.xpath("//a[contains(text(), 'CES Priority')]");
	public static final By RECEIVED_DATE_SORT_LINK = By.xpath("//a[contains(text(), 'Received Date')]");
	public static final By RECEIVED_JURIS_SORT_LINK = By.xpath("//a[contains(text(), 'Received Juris')]");
	public static final By RECEIVED_BY_FACILITY_SORT_LINK = By.xpath("//a[contains(text(), 'Received By Facility')]");
	public static final By TIME_SENSITIVE_SORT_LINK = By.xpath("//a[contains(text(), 'Time Sensitive')]");
	public static final By DAMAGE_AMOUNT_SORT_LINK = By.xpath("//a[contains(text(), 'Damage Amount')]");
	public static final By LAWSUIT_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Lawsuit Type')]");
	public static final By AGING_IN_HOURS_SORT_LINK = By.xpath("//a[contains(text(), 'Aging In Hours')]");
	public static final By AGING_IN_DAYS_SORT_LINK = By.xpath("//a[contains(text(), 'Aging In Days')]");
	public static final By ENTITY_AFFILIATION_SORT_LINK = By.xpath("//a[contains(text(), 'Entity/Affiliation')]");
	public static final By ASSIGNMENT_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Assignment Type')]");
	public static final By ASSIGNMENT_DATE_SORT_LINK = By.xpath("//a[contains(text(), 'Assignment Date')]");
	public static final By ON_HOLD_SORT_LINK = By.xpath("//a[contains(text(), 'On Hold')]");
	public static final By RECEIVED_METHOD_RANK_SORT_LINK = By.xpath("//a[contains(text(), 'Received Method Rank')]");
	public static final By PRIORITY_RANK_SORT_LINK = By.xpath("//a[contains(text(), 'Priority Rank')]");
	public static final By CUSTOMER_RANK_SORT_LINK = By.xpath("//a[contains(text(), 'Customer Rank')]");
	public static final By LAWSUIT_RANK_SORT_LINK = By.xpath("//a[contains(text(), 'Lawsuit Rank')]");
	public static final By COMPLEXITY_RANK_SORT_LINK = By.xpath("//a[contains(text(), 'Complexity Rank')]");
	public static final By COMPLEXITY_TIER_SORT_LINK = By.xpath("//a[contains(text(), 'Complexity Tier')]");
	public static final By ESOP_ID_SORT_LINK = By.xpath("//a[contains(text(), 'ESOP Id')]");
	public static final By RECEIVED_DATE_CST_SORT_LINK = By.xpath("//a[contains(text(), 'Received Date CST')]");
	public static final By SOP_WORKFLOW_SORT_LINK = By.xpath("//a[contains(text(), 'SOP Workflow')]");
	
	public static final By INACTIVE_CREATED_ON_SORTING_LINK = By.xpath("//a[contains(text(),'Created On')]");
	public static final By INACTIVE_REASON_SORTING_LINK = By.xpath("//a[contains(text(),'Reason')]");
	public static final By ACTIVE_REASON_SORTING_LINK = By.xpath("//span[contains(text(),'Reason')]");
	public static final By ACTIVE_FILE_NAME_SORTING_LINK = By.xpath("//span[contains(text(),'File Name')]");
	public static final By ACTIVE_ESOP_ID_SORTING_LINK =By.xpath("//span[contains(text(),'ESOP Id')]");
	public static final By ACTIVE_ESCALATED_ON_SORTING_LINK = By.xpath("//span[contains(text(),'Escalated On')]");
	public static final By ACTIVE_ESCALATED_BY_SORTING_LINK = By.xpath("//span[contains(text(),'Escalated By')]");
	public static final By INACTIVE_ONHOLD_ON_SORTING_LINK = By.xpath("//a[contains(text(),'OnHold On')]");
	public static final By ACTIVE_ONHOLD_ON_SORTING_LINK = By.xpath("//span[contains(text(),'OnHold On')]");
	public static final By INACTIVE_ONHOLD_BY_SORTING_LINK = By.xpath("//a[contains(text(),'OnHold By')]");
	public static final By ACTIVE_ONHOLD_BY_SORTING_LINK = By.xpath("//span[contains(text(),'OnHold By')]");
	
	public static final By RECEIVED_DATE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Received Date')]");
	public static final By RECEIVED_JURIS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Received Juris')]");
	public static final By RECEIVED_BY_FACILITY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Received By Facility')]");
	public static final By RECEIVED_BY_TEAM_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Received By Team')]");
	public static final By FILE_NAME_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'File Name')]");
	public static final By METHOD_OF_SERVICE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Method of Service')]");
	public static final By BATCH_ID_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Batch #')]");
	public static final By SHORT_ANSWER_DATE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Short Answer Date')]");
	public static final By ASSIGNED_TO_TEAM_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Assigned To Team')]");
	public static final By ASSIGNED_TO_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Assigned To')]");
	public static final By BIG_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Big 6')]");
	public static final By HARD_COPY_DELIVERY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Hard Copy Delivery')]");
	public static final By PROCESSOR_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Processor')]");
	public static final By CUSTOMER_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Customer')]");
	public static final By WORKSHEET_TYPE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Worksheet Type')]");
	public static final By CONFIRMATION_NUMBER_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Confirmation Number')]");
	public static final By DELIVERY_METHOD_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Delivery Method')]");
	public static final By SECOND_REVIEW_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Second Review')]");
	public static final By TIME_SENSITIVE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Time Sensitive')]");
	public static final By DAMAGE_AMOUNT_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Damage Amount')]");
	public static final By LAWSUIT_TYPE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Lawsuit Type')]");
	public static final By AGING_IN_HOURS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Aging In Hours')]");
	public static final By AGING_IN_DAYS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Aging In Days')]");
	public static final By ENTITY_AFFILIATION_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Entity/Affiliation')]");
	public static final By ASSIGNMENT_TYPE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Assignment Type')]");
	public static final By ASSIGNMENT_DATE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Assignment Date')]");
	public static final By ON_HOLD_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'On Hold')]");
	public static final By RECEIVED_METHOD_RANK_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Received Method Rank')]");
	public static final By PRIORITY_RANK_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Priority Rank')]");
	public static final By CUSTOMER_RANK_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Customer Rank')]");
	public static final By LAWSUIT_RANK_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Lawsuit Rank')]");
	public static final By COMPLEXITY_RANK_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Complexity Rank')]");
	public static final By COMPLEXITY_TIER_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Complexity Tier')]");
	public static final By ESOP_ID_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'ESOP Id')]");
	public static final By RECEIVED_DATE_CST_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Received Date CST')]");
	public static final By SOP_WORKFLOW_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'SOP Workflow')]");
	public static final By ADVANCED_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Advanced')]");
	public static final By INTAKE_METHOD_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Intake Method')]");
	public static final By CES_STATUS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'CES Status')]");
	public static final By REJECTED_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Rejected')]");
	public static final By EXPEDITED_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Expedited')]");
	public static final By CES_PRIORITY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'CES Priority')]");
	public static final By CES_PRIORITY_YES_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstRHS')]//option[contains(text(), 'Yes')]");
	public static final By CES_PRIORITY_NO_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstRHS')]//option[contains(text(), 'No')]");
	public static final By CREATED_ON_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Created On')]");
	public static final By ESCALATED_ON_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Escalated On')]");
	public static final By ESCALATED_BY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Escalated By')]");
	public static final By CES_REASON_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Reason')]");
	public static final By CES_PRIORITY_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'CES Priority')]");
	public static final By ON_HOLD_ON_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'OnHold On')]");
	public static final By ON_HOLD_BY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'OnHold By')]");
	public static final By CES_PRIORITY_LABEL = By.xpath("//td[contains(text(), 'CES Priority')]");
	public static final By CES_STATUS_COMPLETED = By.xpath("//td[contains(text(), 'Completed')]");
	public static final By CES_STATUS_ESCALATED = By.xpath("//td[contains(text(), 'Escalated')]");
	public static final By CES_PRIORITY_YES = By.xpath("//td[contains(text(), 'Yes')]");
	public static final By CES_PRIORITY_NO = By.xpath("//td[contains(text(), 'No')]");
	public static final By WORKSHEET_REMARKS_TEXTBOX = By.xpath("//textarea[@id='txtRemarks']");
	
	//Below added as part of NPD DevOps sprint 7
	public static final By TITLE_OF_ACTION_CTCORP = By.id("ctl00_lblCase");
	public static final By TITLE_OF_ACTION_NRAI = By.id("ctl00_lblTitleOfAction");
}
