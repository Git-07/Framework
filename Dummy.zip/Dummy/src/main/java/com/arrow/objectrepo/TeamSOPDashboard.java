package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class TeamSOPDashboard {

		public static final By TEAM_SOP_DASHBOARD =By.xpath("//a[contains(text(), 'Team SOP Dashboard')]");
		public static final By TEAM_SOP_DASHBOARD_PAGE =By.xpath("//span[contains(text(), 'Team SOP Dashboard')]");
		//Team Related
		public static final By TEAM =By.xpath("//td[contains(text(), 'Team')]");
		public static final By TOTAL_SOP_COUNT_15DAYS =By.xpath("//td[contains(text(), 'Total SOPs(past 15 days)')]");
		public static final By COMPLETED_SOPS =By.xpath("//td[contains(text(), 'Completed SOPs(past 15 days)')]");
		public static final By SOP_LIST_WITHOUT_WORKSHEET =By.xpath("//td[contains(text(), 'SOP List items without worksheets')]");
		public static final By PENDING_WORKSHEET_AND_ACTION_ITEM =By.xpath("//td[contains(text(), 'Pending Worksheet & Action items')]");
		//Status
		public static final By REJECTED_AND_HARD_COPY =By.xpath("//span[contains(text(), 'Rejected & Hard Copy Delivery Required')]");
		public static final By PHONE_CALL_REQUIRED =By.xpath("//span[contains(text(), 'Phone call required')]");
		public static final By INCOMPLETE_WORKSHEETS =By.xpath("//span[contains(text(), 'Incomplete Worksheets')]");
		public static final By PENDING_ACTION_ITEMS =By.xpath("//span[contains(text(), 'Pending Action Items')]");
		public static final By REJECTION_FOR_REVIEW =By.xpath("//span[contains(text(), 'Rejections for Review')]");
		//Refresh Button
		public static final By REFRESH_BUTTON =By.id("btnRefresh");
		//Team
		public static final By TEAM_SELECTION =By.id("drpOffice");
		public static final By NY_TEAM_SELECTION =By.xpath("//select[@name='drpOffice']/option[contains(text(), 'CT - New York SOP Team')]");
		public static final By LINK_WITHOUT_WS =By.id("lnkListWithoutWS");
		//Count of SOP
		//grdData_ctl02_lnkBtnAssignedToCTCORPTeam
		public static final By REJECT_AND_HARDCOPY_LINK =By.id("grdData_ctl02_lnkBtnReceivedByCTCORPTeam");
		public static final By REJECT_AND_HARDCOPY_LINK_NRAI =By.id("grdData_ctl02_lnkBtnReceivedByNRAITeam");
		public static final By PENDING_ACTION_ITEM_LINK =By.id("grdData_ctl05_lnkBtnReceivedByCTCORPTeam");
		public static final By INCOMPLETE_WORKSHEET_LINK =By.id("grdData_ctl04_lnkBtnReceivedByCTCORPTeam");
		public static final By REJECTIONS_FOR_REVIEW_LINK =By.id("grdData_ctl06_lnkBtnReceivedByCTCORPTeam");
		//Filters
		public static final By STATUS_DRPDWN = By
				.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Status')]");
		public static final By HARD_COPY_DELIVERY_CONTAINS_FILTER = By
				.xpath("//*[contains(@id,'ctlFilterBar_lstOp')]//option[contains(text(), 'contains')]");
		public static final By HARD_COPY_DELIVERY_RHS_FILTER = By.id("ctlFilterBar_txtRHS");
		public static final By GO_BTN = By.id("ctlFilterBar_btnGo");
        //Rejection Approved
		public static final By SOP_DASHBOARD_ITEMS =By.xpath("//span[contains(text(), 'SOP Dashboard Items')]");
		public static final By FIRST_SOP_ID =By.id("grdData_ctl02_lnkLogId");
		public static final By SECOND_SOP_ID =By.id("grdData_ctl03_lnkLogId");
		public static final By CREATE_UPS_PACKAGE =By.id("btnRejectionLetter");
		public static final By CREATE_PACKAGE_BUTTON =By.id("btnCreatePackage");
		public static final By PENDING_ACTION_ITEMS_LINK =By.id("grdData_ctl05_lnkBtnAssignedToCTCORPTeam");
		public static final By CTCORP_REJECTED_COPY =By.id("grdData_ctl02_lnkBtnReceivedByCTCORPTeam");
		public static final By REJECTION_APPROVED_BUTTON =By.id("rdoRejectionApproved_0");
		public static final By REJECTION_APPROVED_YES =By.xpath("//span[@id='lblRejectionApproved'][contains(text(), 'Yes')]");

		public static final By CARRIER_PACKAGE_PAGE =By.xpath("//span[contains(text(), 'Create Carrier Package')]");
		public static final By CARRIER_PACKAGE_PROFILE =By.xpath("//span[contains(text(), 'Carrier Package Profile')]");
		public static final By NO_RECORDS_FOUND =By.xpath("//span[contains(text(), 'No records found.')]");
		//Verify Content
		public static final By SELECT_LOG_ID =By.id("grdData_ctl02_chkSelector");
		public static final By VERIFY_CONTENT_BUTTON =By.id("btnVerifyContents");
		public static final By DROP_OPTION =By.id("drpOptions");
		public static final By CT_PACKING_SLIP =By.xpath("//span[contains(text(), 'CT Packing Slip')]");
		
		public static final By GO_TO_TEAM_DASHBOARD =By.id("btnGotoTeamDashboard");
        		
		public static final By REJECT_AND_HARDCOPY_ASSIGNED_TO =By.id("grdData_ctl02_lnkBtnAssignedToCTCORPTeam");

}
