package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Admin {

	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");

	// Fields on left hav bar of Admin Module
	public static final By MANAGECESMLSLIDERFIELDSLINK = By.linkText("Manage CES ML Slider Fields");
	public static final By MANAGEMLSLIDERFIELDSLINK = By.linkText("Manage ML Slider Fields");
	public static final By ROLES_LEFT_NAV_LINK = By.linkText("Roles");
	public static final By GRANTS_LEFT_NAV_LINK = By.linkText("Grants");
	public static final By BUNDLE_DISBURSEMENTS_MAINTAINANCE_LEFT__NAV_LINK = By
			.linkText("Bundles Disbursements Maintenance");
	public static final By DE_AR_NOTIFICATIONS_LEFT_NAV_LINK = By.linkText("DE AR Notifications");
	public static final By EVENT_MANAGER_LEFT_NAV_LINK = By.linkText("Event Manager");
	public static final By FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK = By.linkText("File & Event Selection");
	public static final By E1_REFRESH_MESSAGE_Q__TAB = By.linkText("E1 Refresh Message Q");
	public static final By GLOBAL_INTAKE_TIME__TAB = By.linkText("Global Intake Time");
	public static final By REF_DATA_MAINTENANCE_LEFT_NAV_LINK = By.linkText("Ref Data Maintenance");

	// Fields on Manage CES ML Slider Fields Page
	public static final By MANAGECESMLSLIDERFIELDSPAGE = By.id("ctlPageTitle_lblTitle");
	public static final By CESMLSLIDERFIELDSBLOCK = By.id("sortable3");
	public static final By MAINTAINCESMLSLIDERFIELDSBLOCK = By.id("t3");
	public static final By SAVEBTN = By.id("btnSave");
	public static final By CANCELBTN = By.id("btnCancel");
	public static final By CASEIDFIELD = By.xpath("//*[contains(@value,'20')]");
	public static final By LAWSUITTYPEFIELD = By.xpath("//*[contains(@value,'21')]");
	public static final By LAWSUITSUBTYPEFIELD = By.xpath("//*[contains(@value,'22')]");
	public static final By INDEXFIELD = By.xpath("//*[@id=\"t3\"]/tbody/tr[1]/td[1]");
	public static final By NAMEFIELD = By.xpath("//*[@id=\"t3\"]/tbody/tr[1]/td[2]");

	// Fields on Roles Page
	public static final By CREATE_ROLE_BTN = By.id("btnCreateRole");
	public static final By FIRST_FILTER_DRPDWN = By.id("ctlFilterBar_lstF");
	public static final By SECOND_FILTER_DRPDWN = By.id("ctlFilterBar_lstOp");
	public static final By FILTER_TEXT_FILED = By.id("ctlFilterBar_txtRHS");
	public static final By GO_BTN = By.id("ctlFilterBar_btnGo");
	public static final By ROLE_DELETE_BTN = By.id("grdData_ctl02_lnkDelete");
	public static final By FIRST_ROLE_ON_THE_GRID = By.id("grdData_ctl02_lnkRoleName");

	// Fields on Create Role Page
	public static final By ROLE_NAME_TEXT_BOX = By.id("txtRoleName");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_CHECKBOX = By.id("chkEntExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_AFFILAITION_CHECKBOX = By.id("chkAffExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_DI_CHECKBOX = By.id("chkDIExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ALERT_CHECKBOX = By.id("chkAlertExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_RENEWAL_CHECKBOX = By.id("chkRenExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_SOP_CHECKBOX = By.id("chkSopExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_COMM_CHECKBOX = By.id("chkComExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_USOP_CHECKBOX = By.id("chkUSOPExecuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ROLE_ADMINISTRATION_CHECKBOX = By.id("chkRoleExexuteAll");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_MONITORING_CHECKBOX = By.id("chkEMRoleExecuteAll");
	public static final By PERFORM_CRM_REQUEST_MANAGEMENT_CHECKBOX = By.id("chkCrmRequestMgmt");
	public static final By ALLOW_TARGET_SELECTION_CHECKBOX = By.id("chkTargetSelection");
	public static final By MAINTAIN_ENTITY_BASED_VIEWING_RIGHTS_CHECKBOX = By.id("chkEntityBasedVR");
	public static final By ALLOW_XSOP_INVOICE_REVISIONS_CHECKBOX = By.id("chkXSOPRevision");
	public static final By ALLOW_SIDES_ACCESS_CHECKBOX = By.id("chkSIDESAcces");
	public static final By MAINTAIN_GENERIC_CD_ENTITY_CHECKBOX = By.id("chkMaintainGenericEntity");
	public static final By MAINTAIN_DSSOP_VIEWING_RIGHTS_CHECKBOX = By.id("chkCDSOPVR");
	public static final By EXTERNAL_USER_SOP_VERIFICATION_CHECKBOX = By.id("chkExternalUserSopVerification");
	public static final By ALLOW_CAMPAIGN_ACCESS_CHECKBOX = By.id("chkCampaign");
	public static final By ALLOW_SOP_WORKTOOL_ACCESS_CHECKBOX = By.id("chkAllowSOPWorktoolAccess");
	public static final By CUSTOMER_NAME_MAPPING_SETUP_CHECKBOX = By.id("chkAACustomerNameMapping");
	public static final By REMOVE_FROM_BULK_WORKFLOW_CHECKBOX = By.id("chkBulkWfPer");
	public static final By LEVEL1_CHECKBOX = By.id("rdoCESL1");
	public static final By LEVEL2_CHECKBOX = By.id("rdoCESL2");
	public static final By NONE_CHECKBOX = By.id("rdoCESNone");
	public static final By MANAGE_BUNDLE_DISBURSEMENTS_MAINTENANCE_CHECKBOX = By
			.id("chkConfigureBundlesDisburseMaintain");
	public static final By MANAGE_BUNDLE_DISBURSEMENTS_MAINTENANCE_LABEL = By
			.xpath("//label[@for='chkConfigureBundlesDisburseMaintain']");

	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_TEXT = By.id("lblEntityPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_AFFILAITION_TEXT = By.id("lblAffilPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_DI_TEXT = By.id("lblDIPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ALERT_TEXT = By.id("lblAlertPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_RENEWAL_TEXT = By.id("lblRenewalPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_SOP_TEXT = By.id("lblSOPPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_COMM_TEXT = By.id("lblCommPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_USOP_TEXT = By.id("lblUSOPPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ROLE_ADMINISTRATION_TEXT = By
			.id("lblRoleAdminPermissions");
	public static final By EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_MONITORING_TEXT = By.id("lblRoleEMPermissions");
	public static final By PERFORM_CRM_REQUEST_MANAGEMENT_TEXT = By.id("lblCRMPermissions");
	public static final By ALLOW_TARGET_SELECTION_TEXT = By.id("lblPaperlessPermissions");
	public static final By MAINTAIN_ENTITY_BASED_VIEWING_RIGHTS_TEXT = By.id("lblEntityBasedVRPermissions");
	public static final By ALLOW_XSOP_INVOICE_REVISIONS_TEXT = By.id("lblXSOPPermission");
	public static final By MAINTAIN_GENERIC_CD_ENTITY_TEXT = By.id("lblGenericCDEntityPermission");
	public static final By MAINTAIN_DSSOP_VIEWING_RIGHTS_TEXT = By.id("lblCDSOPVRPermissions");
	public static final By ALLOW_SIDES_ACCESS_TEXT = By.id("lblSIDESPermission");
	public static final By ALLOW_SIDES_ACCESS_TEXT2 = By.xpath("//span[contains(text(), 'Allow SIDES access')]");
	public static final By EXTERNAL_USER_SOP_VERIFICATION_TEXT = By.id("lblSopVerificationPermission");
	public static final By ALLOW_CAMPAIGN_ACCESS_TEXT = By.id("lblCampaignPermissions");
	public static final By ALLOW_SOP_WORKTOOL_ACCESS_TEXT = By.id("lblSOPWorktoolPermission");
	public static final By CUSTOMER_NAME_MAPPING_SETUP_TEXT = By.id("lblAutoAssignmentPermissions");

	public static final By UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_LABEL = By
			.xpath("//label[contains(text(), 'Update Entity on posted Expedited SOP Log')]");

	public static final By DELAWARE_AR_ADMIN_CHECKBOX = By.id("chkDEARAdmin");
	public static final By DELAWARE_AR_ADMIN_LABEL = By.xpath("//label[contains(text(), 'Delaware AR Admin')]");

	public static final By CREDIT_DS_LINES_CHECKBOX = By.id("chkCreditDSLines");
	public static final By CREDIT_DS_LINES_LABEL = By
			.xpath("//label[contains(text(), 'Credit DS Lines on Renewal Invoices')]");

	// Fields on Role Profile Page
	public static final By EXPEDITED_SOP_PERMISSION_FIELD = By.id("lblExpedSOP");
	public static final By EDIT_BTN = By.id("ctlPageTitle_btnEdit");
	public static final By PRINT_BTN = By.id("ctlPageTitle_btnPrint");
	public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");
	public static final By ROLE_NAME_ON_PRINT_PDF_PAGE = By.id("lblRoleName");
	public static final By NAME_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Name')]");
	public static final By TEAM_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Team')]");
	public static final By TEAM_TYPE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'TeamType')]");
	public static final By STATUS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Status')]");
	public static final By FIRST_PAGE_LINK = By.linkText("First");
	public static final By PREVIOUS_PAGE_LINK = By.linkText("Previous");
	public static final By PAGE_11__20_LINK = By.linkText("11-20");
	public static final By NEXT_PAGE_LINK = By.linkText("Next");
	public static final By LAST_PAGE_LINK = By.linkText("Last");
	public static final By PAGE_1__10_LINK = By.linkText("1-10");
	public static final By ACTIVE_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'Name')]");
	public static final By ACTIVE_TEAM_SORT = By.xpath("(//span[contains(text(), 'Team')])[3]");
	public static final By ACTIVE_TEAM_TYPE_SORT = By.xpath("//span[contains(text(), 'Team Type')]");
	public static final By ACTIVE_STATUS_SORT = By.xpath("//span[contains(text(), 'Status')]");

	public static final By INACTIVE_NAME_SORT_LINK = By.xpath("//a[contains(text(), 'Name')]");
	public static final By INACTIVE_TEAM_SORT_LINK = By.xpath("(//a[contains(text(), 'Team')])[2]");
	public static final By INACTIVE_TEAM_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Team Type')]");
	public static final By INACTIVE_STATUS_SORT_LINK = By.xpath("(//a[contains(text(), 'Status')])[2]");

	public static final By MAINTAIN_BTN = By.id("btnMaintain");
	public static final By CONTAINS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstOp')]//option[contains(text(), 'contains')]");
	public static final By FILTER_TEXT_BOX = By.id("ctlFilterBar_txtRHS");
	public static final By EMPLOYEE_NAME_ON_GRID = By.xpath("(//span[contains(text(), 'Vicki Bones')])[1]");
	public static final By NO_RECORDS_FOUND_ON_GRID = By.id("ctlNoRecordsBar_lblNoRecords");
	public static final By DELAWARE_AR_ADMIN_ON_ROLE_PROFILE_PAGE = By
			.xpath("//span[@id='lblRoleAdminPermissions'][contains(text(), 'Delaware AR Admin')]");
	public static final By ADMINISTRATIVE_PERMISSIONS_FIELD = By.id("lblRoleAdminPermissions");

	public static final By CREDIT_DS_LINES_ON_ROLE_PROFILE_PAGE = By
			.xpath("//span[@id='lblRenewalPermissions'][contains(text(), 'Credit DS Lines on Renewal Invoices')]");
	public static final By RENEWAL_PERMISSIONS_FIELD = By.id("lblRenewalPermissions");

	// Fields on Edit Role Page
	public static final By UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX = By
			.id("chkUpdateEntityOnPostedExpedSOP");

	// Fields on Role Users Page
	public static final By GRANT_ROLE_BTN = By.id("btnGrantRole");
	public static final By GRANTS_TAB = By.xpath("//a[contains(text(), 'Grants')]");
	public static final By EMP_SEARCH_CRITERIA_PAGE = By.xpath("//span[contains(text(), 'Employee Search Criteria')]");
	public static final By TEAM_TYPE_SOP = By.xpath("//select[@id='lstTeamType']/option[contains(text(), 'SOP TEAM')]");
	public static final By USER_GROUP_SOP = By
			.xpath("//select[@id='lstUserGroup']/option[contains(text(), 'SOP     ')]");
	public static final By FIRST_CHECKBOX_ON_GRANT_GRID = By.id("grdData_ctl02_chkGrantId");
	public static final By REVOKE_GRANT_BTN = By.id("btnRevokeGrant");
	public static final By EMP_SEARCH_RESULTS_PAGE = By.xpath("//span[contains(text(), 'Employee Search Results')]");
	public static final By SELECT_FIRST_EMPLOYEE = By.id("grdData_ctl02_lnkEmpName");
	public static final By EMPLOYEE_GRANTS_PAGE = By.xpath("//span[contains(text(), 'Employee Grants')]");

	// Sort by
	public static final By NAME_ACTIVE = By.xpath("//span[contains(text(), 'Name')]");
	public static final By TEAM_INACTIVE = By.xpath("//span[@class='sortBy']/a[contains(text(), 'Team')]");
	public static final By TEAMTYPE_INACTIVE = By.xpath("//span[@class='sortBy']/a[contains(text(), 'Team Type')]");
	public static final By STATUS_INACTIVE = By.xpath("//span[@class='sortBy']/a[contains(text(), 'Status')]");
	public static final By NAME_INACTIVE = By.xpath("//span[@class='sortBy']/a[contains(text(), 'Name')]");
	public static final By TEAM_ACTIVE = By.xpath("//a/span[contains(text(), 'Team')]");

	// Fields on Find Users Page
	public static final By EMPLOYEE_NAME_TEXTBOX = By.id("txtEmpName");
	public static final By FIND_BTN = By.id("btnFind");

	// Fields on Pick Users Page
	public static final By FIRST_CHECKBOX_ON_EMPLOYEE_GRID = By.id("grdData_ctl02_chkEmpId");
	public static final By SEARCH_AGAIN_BTN = By.id("btnSearchAgain");
	public static final By CANCEL_BTN = By.id("btnCancel");

	// Fields on Employee Search Criteria Page
	public static final By SEARCH_BTN = By.id("btnSearch");

	// Fields on Bundles Disbursements Maintenance Page
	public static final By SECURITY_ERROR = By.xpath("//b[contains(text(), 'Security Error Occurred')]");
	public static final By REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN = By
			.xpath("//select[@id='drpBundle']//option[contains(text(), 'REP and Annual Report')]");
	public static final By ADD_BTN = By.id("imgAdd");
	public static final By BUNDLE_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a Bundle.')]");
	public static final By SERVICE_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a Service.')]");
	public static final By JURISDICTION_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a Jurisdiction.')]");
	public static final By SERVICE_DROPDOWN = By.id("drpSelectService");
	public static final By REPARMS_BUNDLE_DRPDWN = By
			.xpath("//select[@id='drpBundle']//option[contains(text(), 'REPARMS Bundle')]");
	public static final By US_RADIO_BTN = By.id("ctlJurisSelector_rbJurisType1");
	public static final By CANADA_RADIO_BTN = By.id("ctlJurisSelector_rbJurisType2");
	public static final By INTERNATIONAL_RADIO_BTN = By.id("ctlJurisSelector_rbJurisType3");
	public static final By JURIS_DRP_DWN = By.id("ctlJurisSelector_lstJurisdictions");
	public static final By SAVE_BUTTON = By.id("imgSave");
	public static final By DS_ITEM_NUMBER_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Enter a value for E1 DS Item Number.')]");
	public static final By DS_DESCRIPTION_ERR_MSG = By.xpath(
			"//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Enter a value for DS Service Description.')]");
	public static final By DS_ITEM_NUMBER_TEXTBOX = By.id("txtE1DSItemNumber");
	public static final By DS_DESCRIPTION_TEXTBOX = By.id("txtDSServiceDescription");
	public static final By E1_DS_ITEM_NUMBER_ON_GRID = By.id("grdData_ctl02_lblItemNumber");
	public static final By DS_DESCRIPTION_ON_GRID = By.id("grdData_ctl02_lblDSServiceDesc");
	public static final By FIRST_EDIT_BUTTON_ON_GRID = By.id("grdData_ctl02_lnkEdit");
	public static final By DS_INVALID_ITEM_NUMBER_ERR_MSG = By.xpath(
			"//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Enter a positive number for E1 DS Item Number.')]");
	public static final By FIRST_DELETE_BUTTON_ON_GRID = By.id("grdData_ctl02_lnkDelete");

	// Fields on File and Event Selection Page
	public static final By DELAWARE_EVENT_LABEL = By.xpath("*//td[contains(text(), 'Delaware Event :')]");
	public static final By DELAWARE_EVENT_DROPDOWN = By.id("drpDelawareEvent");
	public static final By FILE__UPLOAD_LABEL = By.xpath("*//td[contains(text(), 'File Upload :') ]");
	public static final By CHOOSE_FILE_BUTTON = By.id("DEARFile");
	public static final By UPLOAD_BUTTON = By.id("btnUpload");
	public static final By CANCEL_BUTTON = By.id("btnCancel");
	public static final By ERROR = By.xpath("//div[@id='ctlErrorBox_valSummary']//li");
	public static final By PRODUCTION_RADIO_BTN = By.id("rdoTestOrProd_0");
	public static final By TEST_RADIO_BTN = By.id("rdoTestOrProd_1");
	public static final By CHECKED_PRODUCTION_RADIO_BTN = By
			.xpath("//input[@id='rdoTestOrProd_0' and @checked='checked']");
	public static final By DELAWARE_EVENT_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a value for Delaware Event.')]");
	public static final By FILE_UPLOAD_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a DAT file.')]");

	public static final By EVENT_ID_FILTER_DRPDWN = By
			.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Event Id')]");
	public static final By EVENT_NAME_FILTER_DRPDWN = By
			.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Event Name')]");
	public static final By IS_PROD_FILTER_DRPDWN = By
			.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Is Prod')]");
	public static final By STATUS_FILTER_DRPDWN = By
			.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Status')]");

	public static final By ACTIVE_EVENT_ID_SORT_LINK = By.xpath("//span[contains(text(), 'Event Id')]");
	public static final By ACTIVE_EVENT_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'Event Name')]");
	public static final By ACTIVE_STATUS_SORT_LINK = By.xpath("//span[contains(text(), 'Status')]");
	public static final By ACTIVE_UPDATED_ON_SORT_LINK = By.xpath("//span[contains(text(), 'Updated On')]");

	public static final By INACTIVE_EVENT_NAME_SORT_LINK = By.xpath("//a[contains(text(), 'Event Name')]");
	public static final By INACTIVE_UPDATED_ON_SORT_LINK = By.xpath("//a[contains(text(), 'Updated On')]");
	public static final By INACTIVE_EVENT_ID_SORT_LINK = By.xpath("//a[contains(text(), 'Event Id')]");

	public static final By EVENT_ID_COLUMN = By.xpath("//td[contains(text(), 'Event Id')]");
	public static final By EVENT_NAME_COLUMN = By.xpath("//td[contains(text(), 'Event Name')]");
	public static final By FILE_NAME_COLUMN = By.xpath("//td[contains(text(), 'File Name')]");
	public static final By COUNT_COLUMN = By.xpath("//td[contains(text(), 'Count')]");
	public static final By IS_PROD_COLUMN = By.xpath("//td[contains(text(), 'Is Prod')]");
	public static final By STATUS_COLUMN = By.xpath("//td[contains(text(), 'Status')]");
	public static final By UPLOADED_BY_COLUMN = By.xpath("//td[contains(text(), 'Uploaded By')]");
	public static final By UPDATED_ON_COLUMN = By.xpath("//td[contains(text(), 'Updated On')]");

	public static final By CURRENT_FILTER_LABEL = By.xpath("//span[contains(text(), 'Current filter:')]");
	public static final By FIRST_DELETE_BTN_ON_GRID = By.id("grdData_ctl02_lnkDelete");
	public static final By STATUS = By.id("grdData_ctl02_lblStatus");
	public static final By UPLOADED_STATUS = By
			.xpath("//span[@id='grdData_ctl02_lblStatus'][contains(text(), 'Uploaded')]");
	public static final By FIRST_EVENT_ID_ON_GRID = By.id("grdData_ctl02_lblEventId");
	public static final By FIRST_EVENT_NAME_ON_GRID = By.id("grdData_ctl02_lblEventName");
	public static final By FIRST_FILE_NAME_ON_GRID = By.id("grdData_ctl02_lnkFileName");
	public static final By FIRST_IS_PROD_ON_GRID = By.id("grdData_ctl02_lblIsProd");
	public static final By FIRST_STATUS_ON_GRID = By.id("grdData_ctl02_lblStatus");
	public static final By FIRST_UPLOADED_BY_ON_GRID = By.id("grdData_ctl02_lblUpdatedBy");
	public static final By FIRST_VIEW_RESULTS_LINK_ON_GRID = By.id("grdData_ctl02_lnkViewResults");
	public static final By FIRST_COUNT_ON_GRID = By.id("grdData_ctl02_lblTotalCount");
	public static final By BACK_BTN = By.id("btnBack");

	// Fields On Event Manager Page
	public static final By HELP_ICON = By.id("ctlPageTitle_lnkHelp");
	public static final By EVENT_NAME_TEXTBOX = By.id("txtEventName");
	public static final By EVENT_TYPE_DRPDWN = By.id("ddlEventType");
	public static final By ENTITY_TYPE_DRPDWN = By.id("ddlEntityType");
	public static final By NO_OPT_OUT_SUPPRESSION__RADIO_BTN = By
			.xpath("//input[@id='rdoOptOut_1' and @checked='checked' ]");
	public static final By NO_OPTOUT_SUPPRESSION__RADIO_BTN = By.xpath("//input[@id='rdoOptOut_1']");
	public static final By NO_ARMS_SUPPRESSION__RADIO_BTN = By
			.xpath("//input[@id='rdoArms_1' and @checked='checked' ]");
	public static final By NO_BFI_CTPRO_SUPPRESSION__RADIO_BTN = By
			.xpath("//input[@id='rdoBFISuppress_1' and @checked='checked' ]");
	public static final By YES_OPT_OUT_SUPPRESSION__RADIO_BTN = By.id("rdoOptOut_0");
	public static final By YES_ARMS_SUPPRESSION__RADIO_BTN = By.id("rdoArms_0");
	public static final By YES_BFI_CTPRO_SUPPRESSION__RADIO_BTN = By.id("rdoBFISuppress_0");
	public static final By EVENT_CANCEL_BTN = By.id("btnClear");
	public static final By EVENT_ADD_BTN = By.id("btnAddUpdate");

	public static final By ACTIVE_EVENT_TYPE_SORT_LINK = By.xpath("//span[contains(text(), 'Event Type')]");
	public static final By INACTIVE_EVENT_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Event Type')]");
	public static final By INACTIVE_ENTITY_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Entity Type')]");

	public static final By EVENT_NAME_COLUMN_ON_EVENT_MANAGER = By.xpath("//th[contains(text(), 'Event Name')]");
	public static final By EVENT_TYPE_COLUMN_ON_EVENT_MANAGER = By.xpath("//th[contains(text(), 'Event Type')]");
	public static final By ENTITY_TYPE_COLUMN_ON_EVENT_MANAGER = By.xpath("//th[contains(text(), 'Entity Type')]");
	public static final By UPDATED_BY_COLUMN_ON_EVENT_MANAGER = By.xpath("//th[contains(text(), 'Updated By')]");
	public static final By UPDATED_ON_COLUMN_ON_EVENT_MANAGER = By.xpath("//th[contains(text(), 'Updated On')]");

	public static final By FIRST_EVENT_NAME_ON_EVENT_DETAILS_GRID = By.id("grdDEAREventManager_ctl02_lblEventName");
	public static final By FIRST_EVENT_TYPE_ON_EVENT_DETAILS_GRID = By.id("grdDEAREventManager_ctl02_lblEventTypeCd");
	public static final By FIRST_ENTITY_TYPE_ON_EVENT_DETAILS_GRID = By.id("grdDEAREventManager_ctl02_lblEntityTypeCd");
	public static final By OPT_OUT_SUPPRESSION_VALUE = By.id("grdDEAREventManager_ctl02_lblIsOutPut");
	public static final By ARMS_SUPPRESSION_VALUE = By.id("grdDEAREventManager_ctl02_lblIsArms");
	public static final By BFI_CTPRO_SUPPRESSION_VALUE = By.id("grdDEAREventManager_ctl02_lblBFISuppress");
	public static final By FIRST_UPDATED_BY_ON_EVENT_DETAILS_GRID = By
			.id("grdDEAREventManager_ctl02_lblLastModifiedBy");
	public static final By FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID = By.id("grdDEAREventManager_ctl02_btnEdit");
	public static final By FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID = By.id("grdDEAREventManager_ctl02_btnDelete");

	public static final By EVENT_NAME_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Enter a value for Event Name.')]");
	public static final By EVENT_TYPE_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a value for Event Type.')]");
	public static final By ENTITY_TYPE_ERR_MSG = By
			.xpath("//div[@id='ctlErrorBox_valSummary']//li[contains(text(), 'Select a value for Entity Type.')]");

//Fields on Output Files Page
	public static final By EVENT_NAME_ON_CONTEXTBAR = By.id("ctlContextBar_lblContextTitle");
	public static final By EVENT_ID_ON_CONTEXTBAR = By.id("ctlContextBar_lblContextId");
	public static final By TEST_ON_CONTEXTBAR = By.xpath("//span[@style='color:black'][contains(text(), 'TEST')]");
	public static final By PRODUCTION_ON_CONTEXTBAR = By
			.xpath("//span[@style='color:white'][contains(text(), 'PRODUCTION')]");
	public static final By STATUS_ON_OUTPUT_FILES_PAGE = By.id("ctlStatusBar_lblStatusText");
	public static final By PRINTER_OUTPUT_FILES_LABEL = By.xpath("//div[contains(text(), 'Printer Output File(s)')]");
	public static final By ADDITIONAL_OUTPUT_FILES_LABEL = By
			.xpath("//div[contains(text(), 'Additonal Output File(s)')]");
	public static final By PRINTER_ACKNOWLEDGE_FILES_LABEL = By
			.xpath("//div[contains(text(), 'Printer Acknowledge File(s)')]");
	public static final By PRINT_FILE = By.id("grdViewPrintFile_ctl02_lnkPrintFileName");
	public static final By DISCREPANCY_FILE = By.id("grdViewAddFiles_ctl02_lnkAddFileName");
	public static final By SUPPRESSION_FILE = By.id("grdViewAddFiles_ctl03_lnkAddFileName");
	public static final By UNMATCH_FILE = By.id("grdViewAddFiles_ctl04_lnkAddFileName");
	public static final By CHOOSE_FILE_BTN = By.id("PrinterAckFile");
	public static final By BACKBTN = By.id("btnBack");
	public static final By PRINTER_ACKNOWLEDGE_FILE = By.id("grdViewPrintAckFiles_ctl02_lnkFileName");
	public static final By DELETE_IMG = By.id("grdViewPrintAckFiles_ctl02_lnkDelete");
	public static final By CREATE_COMM_BTN = By.id("grdViewPrintAckFiles_ctl02_lnkbtnCreateCOMM");
	public static final By ERROR_MSG = By.xpath("//div[@id='ctlErrorBox_valSummary']/ul/li");
	public static final By FILE_LINK = By.id("grdViewPrintAckFiles_ctl02_lnkFileName");
	public static final By UPDATED_BY = By.id("grdViewPrintAckFiles_ctl02_lblUpdatedBy");

	// Fields on E1 Refresh Message Q Page
	public static final By COMPLETED_MESSAGE_STATUS = By
			.xpath("//select[@id='drpMessageStatus']//option[contains(text(), 'Completed')]");
	public static final By FIRST_NAME = By.id("grdData_ctl02_lnkEdit");

	// Fields on Global Intake Time Page
	public static final By CERTIFIED_MAIL = By
			.xpath("//select[@id='MOS_Selector_lstAvailableItems']//option[contains(text(), 'Certified Mail')][1]");
	public static final By RIGHT_SELECTOR = By.xpath("//input[@src='/Public/images/btn_MoveRight.gif']");
	public static final By TIME_TEXT_BOX = By.id("txtAddTime");
	public static final By INTAKE_ADD_BTN = By.id("btnAdd");
	public static final By FIRST_CHECKBOX = By.id("grdData_ctl02_chkGrdEdit");
	public static final By FIRST_DEL_BTN = By.id("grdData_ctl02_btnDelete");

	// Admin Tab
	public static final By ADMIN_TAB = By.xpath("//img[@alt='Admin']");

	// PSOP Permission Fields in Role Page
	public static final By PSOP_PERMISSION_SECTION = By.xpath("//div[contains(text(),'PSOP Permissions')]");
	public static final By PSOP_BILLING_CHECK_BOX = By.id("chkPSOPBilling");
	public static final By PSOP_REVISION_CHECK_BOX = By.id("chkPSOPRevision");

//Fields on Entity Default Activation Status
	public static final By ENTITY_DEFAULT_ACTIVATION_LINK = By.id("lnkEntDefActivationStatus");
	public static final By EDIT_IMAGE_BTN = By.id("imgEdit");
	public static final By DEFAULT_STATUS_DRPDWN = By.xpath("//select[@id='drpDefaultStatus']/option[contains(text(), 'Active - External')]");

//Manage CES ML Slider Fields
	public static final By PLAINTIFF_CES_ML_SLIDER_FIELD = By.xpath("//ul[@id='sortable3']//li[contains(text(),'Plaintiff')]");
	public static final By DEFENDANT_CES_ML_SLIDER_FIELD = By.xpath("//ul[@id='sortable3']//li[contains(text(),'Defendant')]");
    public static final By PLAINTIFF_INDEX = By.xpath("//table[@id='t3']//tr//td[contains(text(),'Plaintiff')]/preceding-sibling::td");
    public static final By DEFENDANT_INDEX = By.xpath("//table[@id='t3']//tr//td[contains(text(),'Defendant')]/preceding-sibling::td");
    public static final By LAWSUIT_SUBTYPE_INDEX = By.xpath("//table[@id='t3']//tr//td[contains(text(),'Lawsuit SubType')]/preceding-sibling::td");
    public static final By LAWSUIT_TYPE_INDEX = By.xpath("//table[@id='t3']//tr//td[contains(text(),'Lawsuit Type')]/preceding-sibling::td");
//expedited SOP
    public static final By MAINTAIN_EXPEDITED_CHECK_BOX = By.id("chkExpedSOP");
    public static final By UPDATE_ENTITY_ON_POSTED = By.id("chkUpdateEntityOnPostedExpedSOP");
        	
//SOP Rejection Rule Maintenance
    public static final By REJECTION_RULE_MAINTENANCE_LINK = By.xpath("//a[contains(text(),'SOP Rejection Rules Maintenance')]");
    public static final By US_LABEL = By.xpath("//label[@for='ctlJurisSelector_rbJurisType1']");
    public static final By CANADA_LABEL = By.xpath("//label[@for='ctlJurisSelector_rbJurisType2']");
    public static final By INTERNATIONAL_LABEL = By.xpath("//label[@for='ctlJurisSelector_rbJurisType3']");
    public static final By ADD_BUTTON = By.id("imgAdd");
    public static final By SORT_BY_JURISDICTION_LABEL = By.xpath("//span[contains(text(),'Jurisdiction')]");
    public static final By TABLE_HEADER_JURISDICTION = By.xpath("//th[contains(text(),'Jurisdiction')]");
    public static final By SORT_BY_MODIFIED_BY_LABEL  = By.xpath("//a[contains(text(),'Modified By')]");
    public static final By TABLE_HEADER_MODIFIED_BY = By.xpath("//th[contains(text(),'Modified By')]");
    public static final By SORT_BY_MODIFIED_DATE_LABEL  = By.xpath("//a[contains(text(),'Modified Date')]");
    public static final By TABLE_HEADER_MODIFIED_DATE = By.xpath("//th[contains(text(),'Modified Date')]");
    public static final By FIRST_EDIT_BUTTON = By.id("grdData_ctl02_btnEdit");
    public static final By REJECTION_RULE_DROP_DOWN = By.id("drpRejectionRule");
    public static final By STATUS_TEXT_FIELD = By.id("txtStatus");
    public static final By ACTION_TEXT_FIELD = By.id("txtAction");
    public static final By REJECTION_RULE1_FIRST_EDIT = By.id("grdDataGroup1_ctl02_lnkEdit");
    public static final By REJECTION_RULE2_FIRST_EDIT = By.id("grdDataGroup2_ctl02_lnkEdit");
    public static final By REJECTION_RULE1_FIRST_DELETE = By.id("grdDataGroup1_ctl02_lnkDelete");
    public static final By REJECTION_RULE2_FIRST_DELETE = By.id("grdDataGroup2_ctl02_lnkDelete");
    public static final By REJECTION_RULE_MAINTENANCE_CHECK_BOX = By.id("chkRejectionRulesMaintenance");
    public static final By PERMISSIONS_UNDER_ADMIN_PERMISSION = By.id("lblRoleAdminPermissions");    
    public static final By LAW_SUIT_TYPE = By.xpath("//li[contains(text(),'Case#')]");
    public static final By LAW_SUIT_SUB_TYPE = By.xpath("//li[contains(text(),'Lawsuit SubType')]");
    
    //Fields on Manage ML Slider Fields Page
    public static final By MLSLIDERFIELDSBLOCK = By.id("sortable1");
    public static final By MAINTAINMLSLIDERFIELDSBLOCK = By.id("t1");
    public static final By CASEID_FIELD = By.xpath("//li[contains(@value,'4')]");
    public static final By JURISDICTION_FIELD = By.xpath("//li[contains(@value,'7')]");
    public static final By PLAINTIFF_FIELD = By.xpath("//li[contains(@value,'5')]");
    public static final By DEFENDANT_FIELD = By.xpath("//li[contains(@value,'6')]");
    public static final By LAWSUITTYPE_FIELD = By.xpath("//li[contains(@value,'15')]");
    public static final By LAWSUITSUBTYPE_FIELD = By.xpath("//li[contains(@value,'16')]");
    public static final By ANSWER_DATE = By.xpath("//li[contains(@value,'19')]");
    public static final By POSTMARK_DATE = By.xpath("//li[contains(@value,'1')]");
    public static final By PRIORITYMAILID_FIELD = By.xpath("//li[contains(@value,'2')]");
    public static final By INITIALSUBSEQUENT_FIELD = By.xpath("//li[contains(@value,'3')]");
    public static final By COURT_NAME = By.xpath("//li[contains(@value,'8')]");
    public static final By COURT_ADDRESS = By.xpath("//li[contains(@value,'9')]");
    public static final By AGENCY_NAME = By.xpath("//li[contains(@value,'10')]");
    public static final By ATTORNEY_NAME = By.xpath("//li[contains(@value,'12')]");
    public static final By NATURE_OFACTION = By.xpath("//li[contains(@value,'17')]");
    public static final By AMOUNT_DUE = By.xpath("//li[contains(@value,'18')]");
    public static final By DOCUMENT_TYPE = By.xpath("//li[contains(@value,'14')]");
    public static final By ATTORNEY_ADDRESS = By.xpath("//li[contains(@value,'13')]");
    public static final By AGENCY_ADDRESS = By.xpath("//li[contains(@value,'11')]");
    public static final By INDEX_FIELD = By.xpath("//td[contains(text(),'Index')]");
    public static final By NAME_FIELD = By.xpath("//td[contains(text(),'Name')]");
    
    //NPD DEvops Sprint 2 changes
    public static final By MAINTAIN_TRANSMITTAL_TYPE = By.xpath("//label[@for='chkTransmittalType']");
    
}
