package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class USOP {

	//View fields on USOP - Partners page
	public static final By USOP_LINK = By.xpath("//img[@alt='USOP']");
	public static final By PARTNER_HEADER = By.id("ctlPageTitle_lblTitle");
	public static final By PARTNERS = By.xpath("//div[contains(text(), 'Partners')]");
	public static final By PARTNER_PROFILE = By.xpath("//div[contains(text(), 'Partner Profile')]");
	public static final By CHANNELS = By.xpath("//div[contains(text(), 'Channels')]");
	public static final By CHANNELS_PROFILE = By.xpath("//div[contains(text(), 'Channel Profile')]");
	public static final By SUBSCRIPTION = By.xpath("//div[contains(text(), 'Subscription')]");
	public static final By SUBSCRIPTION_PROFILE = By.xpath("//div[contains(text(), 'Subscription Profile')]");
	public static final By FILTERS = By.xpath("//div[contains(text(), 'Filters')]");
	public static final By USOP_INTERFACE_TEXT = By.xpath("//a[contains(text(), 'USOP Interface Test')]");
	
	//Partners Page
	//sort by
	public static final By PARTNER_NAME = By.xpath("//span[contains(text(), 'Partner Name')]");
	public static final By PARTNER_HASH = By.xpath("//a[contains(text(), 'Partner #')]");
	public static final By CREATED = By.xpath("//a[contains(text(), 'Created')]");
	
	//Select Drop Down
	public static final By SELECT_DROPDOWN = By.id("ctlFilterBar_lstF");
	public static final By SELECT_SECOND_DROPDOWN = By.id("ctlFilterBar_lstOp");
	
	//First Drop Down
	public static final By DROPDOWN_PARTNER_NAME = By.xpath("//option[contains(text(), 'Partner Name')]");
	public static final By DROPDOWN_PARTNER_ID = By.xpath("//option[contains(text(), 'Partner #')]");
	public static final By DROPDOWN_CREATED = By.xpath("//option[contains(text(), 'Created')]");
	
	//Drop Down text with Partner selected
	public static final By BEGINS_WITH = By.xpath("//option[contains(text(), 'begins with')]");
	public static final By CONTAINS = By.xpath("//option[contains(text(), 'contains')]");
	public static final By ENDS_WITH = By.xpath("//option[contains(text(), 'ends with')]");
	public static final By NOT_HAVING = By.xpath("//option[contains(text(), 'not having')]");
	public static final By EQUALS = By.xpath("//option[contains(text(), 'equals')]");
	
	//Drop Down text with Partner # selected
	public static final By GREATER_THAN = By.xpath("//option[contains(text(), '>')]");
	public static final By EQUAL = By.xpath("//option[contains(text(), '=')]");
	public static final By LESS_THAN = By.xpath("//option[contains(text(), '<')]");
	public static final By GREATER_THAN_EQUALS = By.xpath("//option[contains(text(), '>=')]");
	public static final By LESS_THAN_EQUALS = By.xpath("//option[contains(text(), '<=')]");
	public static final By NOT_EQUALS = By.xpath("//option[contains(text(), '!=')]");
	
	//Drop Down text with Created selected
	public static final By IS_ON = By.xpath("//option[contains(text(), 'Is on')]");
	public static final By IS_AFTER = By.xpath("//option[contains(text(), 'Is after')]");
	public static final By IS_BEFORE = By.xpath("//option[contains(text(), 'Is before')]");

	//Dropdown related Partner Name, ID and created on
	public static final By PARTNER_NAME_CONTAINS = By.xpath("//a[contains(text(), 'LTOnline/Iberia Bank')]");
	public static final By PARTNER_ID_EQUALS = By.xpath("//span[contains(text(), '1010000481')]");
	public static final By PARTNER_CREATED_ON = By.xpath("//td[contains(text(), '11/11/2010')]");
	
	//Drop down Text Field and Go Button
	public static final By DROP_DOWN_TEXT = By.id("ctlFilterBar_txtRHS");
	public static final By GO_BUTTON = By.id("ctlFilterBar_btnGo");	
	public static final By CLEAR_BUTTON = By.id("ctlFilterBar_btnClear");	
	
	//Pagination
	public static final By FIRST = By.xpath("//a[contains(text(), 'First')]");	
	public static final By PREVIOUS = By.xpath("//a[contains(text(), 'Previous')]");		
	public static final By NEXT = By.xpath("//a[contains(text(), 'Next')]");	
	public static final By LAST = By.xpath("//a[contains(text(), 'Last')]");	
	
	//Create Partner Button
	public static final By CREATE_PARTNER_BUTTON = By.id("btnCreatePartner");	
	
	//Create Partner Error Message
	public static final By ERROR_PARTNER_NAME = By.xpath("//li[contains(text(), 'Enter a value for Partner Name.')]");
	public static final By ERROR_PARTNER_ADDRESS_LINE1 = By.xpath("//li[contains(text(), 'Enter a value for Partner Address Line 1.')]");
	public static final By ERROR_PARTNER_CITY = By.xpath("//li[contains(text(), 'Enter a value for Partner City.')]");
	public static final By ERROR_PARTNER_STATE = By.xpath("//li[contains(text(), 'Enter a value for Partner State.')]");
	public static final By ERROR_ZIP_CODE = By.xpath("//li[contains(text(), 'Enter a value for Partner ZipCode.')]");
	public static final By ERROR_PHONE = By.xpath("//li[contains(text(), 'Enter a value for Partner Phone.')]");
	public static final By ERROR_TECHNICAL_CONTACT_NAME = By.xpath("//li[contains(text(), 'Enter a value for Technical Contact Name.')]");
	public static final By ERROR_TECHNICAL_CONTACT_EMAIL = By.xpath("//li[contains(text(), 'Enter a value for Technical Contact Email.')]");
	public static final By ERROR_BUSINESS_CONTACT_NAME = By.xpath("//li[contains(text(), 'Enter a value for Business Contact Name.')]");
	public static final By ERROR_BUSINESS_CONTACT_EMAIL = By.xpath("//li[contains(text(), 'Enter a value for Business Contact Email.')]");
	public static final By ERROR_KEY_DURATION = By.xpath("//li[contains(text(), 'Enter a positive number for Key Duration.')]");
	public static final By ERROR_KEY_VALUE = By.xpath("//li[contains(text(), 'Generate the value for Key / IV.')]");

	
	public static final By NAME_FIELD = By.id("txtName");	
	public static final By ADDRESS_LINE1 = By.id("txtAddressLine1");	
	public static final By ADDRESS_LINE2 = By.id("txtAddressLine2");	
	public static final By CITY = By.id("txtCity");	
	public static final By STATE = By.id("txtState");	
	public static final By ZIP_CODE = By.id("txtZipCode");
	public static final By COUNTRY = By.id("drpCountry");
	public static final By SELECT_COUNTRY = By.xpath("//option[contains(text(), 'Canada')]");
	public static final By PHONE = By.id("txtPhone");	
	
	//Technical Contact Details
	public static final By TECHNICAL_CONTACT_NAME = By.id("txtTechnicalContactName");	
	public static final By TECHNICAL_CONTACT_PHONE = By.id("txtTechnicalContactPhone");	
	public static final By TECHNICAL_CONTACT_FAX = By.id("txtTechnicalContactFax");	
	public static final By TECHNICAL_CONTACT_EMAIL = By.id("txtTechnicalContactEmail");	
	
	//Business Contact Details
	public static final By BUSINESS_CONTACT_NAME = By.id("txtBusinessContactName");	
	public static final By BUSINESS_CONTACT_PHONE = By.id("txtBusinessContactPhone");	
	public static final By BUSINESS_CONTACT_FAX = By.id("txtBusinessContacFax");	
	public static final By BUSINESS_CONTACT_EMAIL = By.id("txtBusinessContactEmail");		
	
	//Data Security
	public static final By ENCRYPTION_STATUS_YES = By.id("rdoEncryptionYes");	
	public static final By KEY_DURATION = By.id("txtKeyDuration");	
	public static final By ENCRYPT_TRANSIENT_YES = By.id("rdoTransientKeyYes");	
	public static final By GENERATE_KEY = By.id("btnGenerateKeyIv");
	
	//Comments
	public static final By COMMENTS = By.id("txtComments");
	
	//Save and Cancel
	public static final By SAVE = By.id("btnSave");
	public static final By CANCEL = By.id("btnCancel");
	
	// Partner Profile
	public static final By PARTNER_PROFILE_PAGE = By.xpath("//span[contains(text(), 'Partner Profile')]");
	public static final By PARTNER_ID = By.id("ctlContextBar_lblContextId");
	public static final By EDIT_BUTTON = By.id("ctlPageTitle_btnEdit");
	public static final By EDIT_PARTNER = By.xpath("//span[contains(text(), 'Edit Partner')]");
	public static final By MAINTAIN_CREDENTIALS_BUTTON = By.id("btnMaintainCredentials");
	public static final By MAINTAIN_CREDENTIALS_PAGE = By.xpath("//span[contains(text(), 'Maintain Credentials')]");
	public static final By VIEW_METRICS_BUTTON = By.id("btnViewMetrics");
	public static final By GENERATE_BUTTON = By.xpath("//button[contains(text(), 'Generate Report')]");
	public static final By SOP_METRICS_FOR = By.xpath("//div[contains(text(), 'SOP Metrics for ')]");
	public static final By METRICS_SUMMARY = By.xpath("//h4[contains(text(), 'Summary')]");
	
	//Channels Profile
	public static final By FIRST_PARTNER_ON_PAGE = By.id("grdData_ctl02_lnkLogID");
	public static final By CHANNELS_LINK = By.xpath("//a[contains(text(), 'Channels')]");
	public static final By MAINTAIN_CHANNELS = By.xpath("//span[contains(text(), 'Maintain Channels')]");
	public static final By CHANNEL_NAME = By.id("txtName");
	public static final By ADD_UPDATE = By.id("imgAddUpdate");
	public static final By CHANNEL_NAME_CHECK = By.xpath("//a[contains(text(), 'AB - Channel Name')]");
	public static final By CHANNEL_PROFILE = By.xpath("//span[contains(text(), 'Channel Profile')]");
	
	
	//Subscription
	public static final By SUBSCRIPTION_LINK = By.xpath("//a[contains(text(), 'Subscriptions')]");
	public static final By MAINTAIN_SUBSCRIPTION = By.xpath("//span[contains(text(), 'Maintain Subscriptions')]");
	public static final By FIND_BUTTON = By.id("btnFind");
	public static final By DELETE_BUTTON = By.id("grdData_ctl02_imgDelete");
	public static final By SELECT_SUBSCRIPTION_BUTTON = By.id("ctlSubscription_imgFind");
	
	//Radio Button
	public static final By AFFILIATION_RADIO_BUTTON = By.id("rdoAffiliation");
	public static final By ENTITY_RADIO_BUTTON = By.id("rdoEntity");
	public static final By SUBGROUP_RADIO_BUTTON = By.id("rdoSubGroup");
	
	//Subscription related
	public static final By SUBSCRIPTION_UNIT_SEARCH_CRITERIA = By.xpath("//span[contains(text(), 'Subscription Unit Search criteria')]");
	public static final By ENTITY_AFFILIATION_TEXT_BOX = By.id("txtObjectName");
	public static final By ENTITY_AFFILIATION_ID_BOX = By.id("txtObjectId");
	public static final By SUBSCRIPTION_UNIT_SEARCH_RESULTS = By.xpath("//span[contains(text(), 'Subscription Unit Search Results')]");
	public static final By SELECT_ENTITY_AFFILIATION = By.id("grdData_ctl02_imgSelect");
	public static final By AFFILIATION_SUBSCRIPTION = By.xpath("//a[contains(text(), 'APPLE ACQUISITION CORP.')]");
	public static final By ENTITY_SUBSCRIPTION = By.xpath("//a[contains(text(), 'Apple Air Holding, LLC')]");
	public static final By SUBSCRIPTION_ERROR = By.xpath("//li[contains(text(), 'Subscription already exist for the selected subscription unit.')]");
	
	
	//Filters
	public static final By FILTER_LINK = By.xpath("//a[contains(text(), 'Filters')]");
	public static final By FILTER_PAGE = By.xpath("//span[contains(text(), 'Filters')]");
	public static final By FILTER_ATTRIBUTE_DELETE = By.id("imgFiltersAttribsDelete");
	public static final By FILTER_ATTRIBUTE_ADD = By.id("imgFiltersAttribsAdd");
	public static final By FILTER_ATTRIBUTE_EDIT = By.id("imgFiltersAttribsEdit");
	public static final By FILTER_SOP_ATTRIBUTE_PAGE = By.xpath("//span[contains(text(), 'Filters – SOP Attributes')]");	
	
	//Radio Buttons and Selections for Special Circumstances	
	public static final By FILTER_TYPE_EXCLUDE = By.id("rdoExcludeChar");
	public static final By FILTER_TYPE_SPECIFIC = By.id("rdoSpecificSpecialCircumstances");
	public static final By SELECT_NONE_CIRCUMSTANCES = By.xpath("//option[contains(text(), 'None')]");
	public static final By ADD_SPECIAL_CIRCUMSTANCE_VALUE = By.id("ctlSpecialCircumstancesCtrl_lnkAdd");
	public static final By SELECTED_SPECIAL_CIRCUMSTANCE_VALUE = By.xpath("//option[contains(text(), 'None')]");
	
	//Radio Buttons and Selections for Lawsuite Type
	public static final By LAWSUITE_TYPE_RADIO_BUTTON = By.id("rdoSpecificLawsuitTypes");
	public static final By LAWSUITE_TYPE = By.xpath("//option[contains(text(), 'All Types Not Specified')]");
	public static final By ADD_LAWSUITE_TYPE_VALUE = By.id("ctlLawsuitTypeControl_lnkAdd");
	public static final By SELECTED_LAWSUITE_TYPE = By.xpath("//option[contains(text(), 'All Types Not Specified')]");

	//Lawsuite Sub-Type
	public static final By LAWSUITE_SUB_TYPE_DROPDOWN = By.id("ctlLawsuitTypeControl_ddLawsuitType");
	public static final By LAWSUITE_SUB_TYPE_VALUE = By.xpath("//select[@id='ctlLawsuitTypeControl_ddLawsuitType']/option[contains(text(), 'Bankruptcy Litigation')]");
	public static final By LAWSUITE_SUB_VALUE = By.xpath("//option[contains(text(), 'Chapter 13')]");
	public static final By SELECTED_LAWSUITE_SUB_VALUE = By.xpath("//option[contains(text(), 'Bankruptcy Litigation - Chapter 13')]");
	
	//Select State
	public static final By SELECT_SPECIFIC_JURISDICTION = By.id("rdoSpecificJurisdictions");
	public static final By SELECT_STATE = By.id("ctlJurisdictionTypeCtrl_rblState_0");
	public static final By US_STATE = By.xpath("//option[contains(text(), 'Alabama')]");
	public static final By ADD_US_STATE = By.id("ctlJurisdictionTypeCtrl_lnkAdd");
	public static final By SELECTED_US_STATE = By.xpath("//option[contains(text(), 'Alabama')]");
	
	
	//View Filter SOP Attributes
	public static final By VIEW_SPECIAL_CIRCUMSTANCE = By.xpath("//span[contains(text(), 'None')]");
	public static final By VIEW_LAWSUITE_TYPE_SUBTYPE = By.xpath("//span[contains(text(), 'All Types Not Specified, Bankruptcy Litigation - Chapter 13')]");
	public static final By VIEW_JURISDICTION = By.xpath("//span[contains(text(), 'Alabama')]");
	
	//Recipients
	public static final By RECIPIENTS_DELETE = By.id("imgFiltersRecipientsDelete");
	public static final By RECIPIENTS_ADD = By.id("imgFiltersRecipientsAdd");
	public static final By RECIPIENTS_EDIT = By.id("imgFiltersAttribsEdit");
	public static final By FILTER_SOP_RECIPIENTS = By.xpath("//span[contains(text(), 'Filters – SOP Recipients')]");	
	
	
	//Add new Recipient
	public static final By ADD_NEW_RECIPIENT = By.id("btnAddNewRecipient");
	public static final By DELETE_OLD_RECIPIENT = By.id("grdData_ctl02_lnkDelete");
	public static final By CANCEL_RESULT = By.id("btnCancelResult");
	
	public static final By RECIPIENT_FILTER_TYPE_INCLUDE = By.id("rdoIncludeChar");
	public static final By RECIPIENT_FILTER_TYPE_EXCLUDE = By.id("rdoExcludeChar");
	public static final By SELECT_RECIPIENT = By.id("rdoRecipientChar");
	public static final By SELECT_CUSTOMER = By.id("rdoCustomerChar");
	public static final By ONE_WORLD_ID = By.id("txtOneWorld");
	public static final By SEARCH_BUTTON = By.id("btnSearch");
	public static final By VIEW_ADDED_PARTICIPANT = By.xpath("//td[contains(text(), 'PADDY SHARMA')]");
	public static final By PARTICIPANT_SELECTOR = By.id("grdData_ctl02_chkSelector");
	public static final By ADD_BUTTON = By.id("btnAdd");
	
	public static final By VIEW_SOP_RECEIPIENT = By.xpath("//span[contains(text(), 'PADDY SHARMA')]");
	
	//Republish
	public static final By REPUBLISH_DELETE = By.id("imgFiltersRepublishDelete");
	public static final By REPUBLISH_ADD = By.id("imgFiltersRepublishAdd");
	public static final By REPUBLISH_EDIT = By.id("imgFiltersRepublishEdit");
	
	public static final By FILTER_SOP_REPUBLISH = By.xpath("//span[contains(text(), 'Filters – SOP Republish')]");
	public static final By SELECT_HARDCOPY_DELIVERY = By.id("chkHardcopyDeliveryMethods");
	public static final By VIEW_SOP_REPUBLISH = By.xpath("//span[contains(text(), 'Hardcopy Delivery Actions')]");
	
	//USOP Interface Test
	public static final By PARTNER_DROP_DOWN = By.id("drpPartner");
	public static final By USOP_INTERFACE_TEST_PAGE = By.xpath("//span[contains(text(), 'USOP Interface Test Criteria')]");
	public static final By PARTNER_DROP_DOWN_NAME = By.xpath("//option[contains(text(), 'Bank of America /Mitratech')]");
	public static final By CHANNEL_DROP_DOWN = By.id("drpChannel");
	
	//Initialize button related
	public static final By INITIALIZE_ENCRYPTED_RESULTS = By.id("btnInitialize");
	public static final By INITIALIZE_ENCRYPTED_RESULTS_SESSION_PAGE = By.xpath("//span[contains(text(), 'USOP Interface Test Result - Initialize “Encrypted Results Session”')]");
	public static final By PARTNER_FIELD_DISPLAY = By.xpath("//td[contains(text(), 'Partner')]");
	public static final By OPERATIONAL_FIELD_DISPLAY = By.xpath("//td[contains(text(), 'Operation Result ')]");
	
	//Versions
	public static final By VERSION = By.id("drpVersion");
	public static final By VERSION_1 = By.xpath("//option[contains(text(), 'Version 1.0')]");
	public static final By VERSION_1_1 = By.xpath("//option[contains(text(), 'Version 1.1')]");
	public static final By VERSION_1_2 = By.xpath("//option[contains(text(), 'Version 1.2')]");
	public static final By VERSION_1_3 = By.xpath("//option[contains(text(), 'Version 1.3')]");
	
	//Get SOP Sumamry List
	public static final By GET_SOP_SUMMARY_LIST = By.id("btnGetSOPSummaryList");
	public static final By WORKSHEET_LOG = By.xpath("//tr[@class='dataGrid2Row']//a");
	public static final By SOP_SUMMARY_LIST_PAGE = By.xpath("//span[contains(text(), 'USOP Interface Test Result - SOP Summary List')]");
	public static final By NEW_OR_MODIFIED_WORKSHEET = By.xpath("//td[contains(text(), 'New/Modified Worksheet(s)')]");
	public static final By CREATED_WORKSHEET = By.xpath("//td[contains(text(), 'Created Worksheet(s)')]");
	public static final By SEARCH_AGAIN = By.id("btnSearchAgain");
	
	public static final By INIT_SOP_SUMMARY_LIST_ER = By.id("btnInitSOPSummaryListER");
	public static final By INIT_SOP_SUMMARY_LIST_ER_PAGE = By.xpath("//span[contains(text(), 'InitSOPSummaryListER')]");
	public static final By RESULT_SET_ID_ON_LISTER_PAGE = By.xpath("//span[contains(text(), 'Result Set Id (Base 64) : ')]");

	
	public static final By RESULT_SET_ID = By.id("txtResultSetId");
	public static final By PAGE_NUMBER = By.id("txtPageNum");
	public static final By GET_SOP_SUMMARY_LIST_ER = By.id("btnGetSOPSummaryListER");
	public static final By ENCRYPTED_RESULT_PAGE = By.xpath("//span[contains(text(), 'USOP Interface Test Result - Encrypted Results')]");
	public static final By CIPHER_TEXT = By.xpath("//span[contains(text(), 'Cipher Text :')]");
	
	//Get SOP Detail
	public static final By CT_LOG = By.id("txtID");	
	public static final By GET_SOP_DETAIL = By.id("btnGetSOPDetail");
	public static final By INVALID_ID = By.id("lblSOAPError");	
	public static final By NO_RECORDS_FOUND = By.xpath("//td[contains(text(), ' No records found.')]");
	public static final By SOP_DETAIL_PAGE = By.xpath("//span[contains(text(), 'USOP Interface Test Result - SOP Detail')]");
	
	public static final By TARGET_DETAILS = By.xpath("//div[contains(text(), 'Target Details')]");	
	public static final By LAWSUIT_DETAILS = By.xpath("//div[contains(text(), 'Lawsuit Details')]");	
	public static final By CASE_DETAILS = By.xpath("//div[contains(text(), 'Case Details')]");	
	public static final By SOURCE_DETAILS = By.xpath("//div[contains(text(), 'Source Details')]");	
	public static final By REMARKS = By.xpath("//div[contains(text(), 'Remarks')]");	
	
	public static final By GET_SOP_DETAIL_ER = By.id("btnGetSOPDetailER");
	public static final By ACKNOWLEDGE_SOP = By.id("btnAcknowledgeSOP");
	public static final By GET_DOC_URL = By.id("btnGetDocUrl");
	public static final By GET_DOC_URL_PDF = By.xpath("//span[contains(text(), 'USOP_DownloadDoc.aspx')]");

	
	

}