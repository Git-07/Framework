package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Generic {

	//Homepage Search
	public static final By ENTITY_SEARCH = By.xpath("//a[contains(text(), 'Entity Search')]");
	public static final By ENTITY_ID = By.id("txtEntityNumber");
	public static final By SEARCH_LINK = By.id("lnkSearch");
	
	//Buttons
	public static final By FILTERS = By.xpath("//div[contains(text(), 'Filters')]");
	public static final By FIND_BUTTON = By.id("btnFind");
	public static final By DELETE_BUTTON = By.id("grdData_ctl02_imgDelete");
	public static final By ADD_BUTTON = By.id("btnAdd");
	public static final By REMOVE_BUTTON = By.id("btnRemove");
	public static final By SELECT_BUTTON = By.id("grdData_ctl02_lnkSelect");
	public static final By EDIT_BUTTON = By.id("grdData_ctl02_lnkEdit");
	public static final By EDIT_NAME = By.id("btnEditName");
	public static final By NEXT_BUTTON = By.id("btnNext");
	public static final By EXPORT_BUTTON = By.id("ctlPageTitle_btnExport");
	public static final By EXPORT_BUTTON2 = By.id("btnExport");
	public static final By EDIT_NAME_LIST = By.id("btnEdit");
	public static final By IMG_ADD_UPDATE = By.id("imgAddUpdate");
	public static final By TEXT_DATE = By.id("ctlDate_txtDate");
	public static final By IMG_CLEAR = By.id("imgClear");
	public static final By CREATE_GROUP = By.id("btnCreateGroup");
	public static final By MAINTAIN_BTN = By.id("btnMaintain");
	public static final By FIRST_RESULT = By.id("grdData_ctl02_lnkLogID");
	public static final By SUBMIT_BTN = By.id("btnSubmit");
	public static final By REFRESH_BTN = By.id("btnRefresh");
	public static final By BACK_BTN = By.id("btnBack");
	public static final By CANCEL_BUTTON = By.id("btnCancelTop");
	
	//Search
	public static final By SEARCH = By.id("btnSearch");
	public static final By SEARCH_AGAIN = By.id("btnSearchAgain");
	
	//Save and Cancel
	public static final By SAVE = By.id("btnSave");
	public static final By CANCEL = By.id("btnCancel");
	public static final By COMMENTS = By.id("txtComment");
	public static final By TEXT_IMAGE = By.id("txtImage");
	public static final By GO_BACK = By.id("btnGoBack");
	public static final By DI_HISTORY_COMMENT = By.id("ctlDIHistoryComment_txtComment");
	public static final By NO_RECORDS_FOUND = By.xpath("//td[contains(text(), ' No records found.')]");
	public static final By NO_RECORDS_FOUND2 = By.xpath("//span[contains(text(), 'No records found.')]");
	
	//Select Drop Down
	public static final By SELECT_DROPDOWN = By.id("ctlFilterBar_lstF");
	public static final By SELECT_SECOND_DROPDOWN = By.id("ctlFilterBar_lstOp");
	public static final By SELECT_2ND_DROPDOWN = By.id("ctlFilterBar_lstRHS");
	//public static final By TYPE_2ND_TEXTBOX = By.xpath("//input[@id='ctlFilterBar_txtRHS']");
	
	
	//Drop Down text(Old Part)
	public static final By BEGINS_WITH = By.xpath("//option[contains(text(), 'begins with')]");
	public static final By CONTAINS = By.xpath("//option[contains(text(), 'contains')]");
	public static final By ENDS_WITH = By.xpath("//option[contains(text(), 'ends with')]");
	public static final By NOT_HAVING = By.xpath("//option[contains(text(), 'not having')]");
	public static final By EQUALS = By.xpath("//option[contains(text(), 'equals')]");
	
	//Drop Down text(New Part)
	public static final By SECOND_DROP_BEGINS_WITH = By.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), 'begins with')]");
	public static final By SECOND_DROP_CONTAINS = By.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), 'contains')]");
	public static final By SECOND_DROP_ENDS_WITH = By.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), 'ends with')]");
	public static final By SECOND_DROP_NOT_HAVING = By.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), 'not having')]");
	public static final By SECOND_DROP_EQUALS = By.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), 'equals')]");
	public static final By SECOND_DROP_EQUALS2 = By.xpath("//select[@id='ctlFilterBar_lstOp']/option[contains(text(), '=')]");
	
	//Drop Down text with # selected
	public static final By GREATER_THAN = By.xpath("//option[contains(text(), '>')]");
	public static final By EQUAL = By.xpath("//option[contains(text(), '=')]");
	public static final By LESS_THAN = By.xpath("//option[contains(text(), '<')]");
	public static final By GREATER_THAN_EQUALS = By.xpath("//option[contains(text(), '>=')]");
	public static final By LESS_THAN_EQUALS = By.xpath("//option[contains(text(), '<=')]");
	public static final By NOT_EQUALS = By.xpath("//option[contains(text(), '!=')]");
	
	//Drop Down text with Created selected
	public static final By IS_ON = By.xpath("//option[contains(text(), 'Is on')]");
	public static final By IS_AFTER = By.xpath("//option[contains(text(), 'Is after')]");
	public static final By IS_BEFORE = By.xpath("//option[contains(text(), 'Is before')]");
	
	//Drop down Text Field and Go Button
	public static final By DROP_DOWN_TEXT = By.id("ctlFilterBar_txtRHS");
	public static final By GO_BUTTON = By.id("ctlFilterBar_btnGo");	
	public static final By CLEAR_BUTTON = By.id("ctlFilterBar_btnClear");
	public static final By CLEAR_BTN = By.id("btnClear");
	public static final By IMG_GO_BUTTON = By.id("imgGo");
	
	//Pagination
	public static final By FIRST = By.xpath("//a[contains(text(), 'First')]");	
	public static final By PREVIOUS = By.xpath("//a[contains(text(), 'Previous')]");		
	public static final By NEXT = By.xpath("//a[contains(text(), 'Next')]");	
	public static final By LAST = By.xpath("//a[contains(text(), 'Last')]");	
	
	
	public static final By NAME_FIELD = By.id("txtName");	
	public static final By ADDRESS_LINE1 = By.id("txtAddressLine1");	
	public static final By ADDRESS_LINE2 = By.id("txtAddressLine2");	
	public static final By CITY = By.id("txtCity");	
	public static final By STATE = By.id("txtState");	
	public static final By ZIP_CODE = By.id("txtZipCode");
	public static final By COUNTRY = By.id("drpCountry");
	public static final By PHONE = By.id("txtPhone");	



	//Recipients
	public static final By RECIPIENTS_DELETE = By.id("imgFiltersRecipientsDelete");
	public static final By RECIPIENTS_ADD = By.id("imgFiltersRecipientsAdd");
	public static final By RECIPIENTS_EDIT = By.id("imgFiltersAttribsEdit");	
	
	
	//Add new Recipient
	public static final By ADD_NEW_RECIPIENT = By.id("btnAddNewRecipient");
	public static final By DELETE_OLD_RECIPIENT = By.id("grdData_ctl02_lnkDelete");
	public static final By CANCEL_RESULT = By.id("btnCancelResult");
	
	public static final By RECIPIENT_FILTER_TYPE_INCLUDE = By.id("rdoIncludeChar");
	public static final By RECIPIENT_FILTER_TYPE_EXCLUDE = By.id("rdoExcludeChar");
	public static final By SELECT_RECIPIENT = By.id("rdoRecipientChar");
	public static final By SELECT_CUSTOMER = By.id("rdoCustomerChar");
	public static final By ONE_WORLD_ID = By.id("txtOneWorld");
	public static final By SEARCH_BUTTON = By.id("btnSearch");
	public static final By VIEW_ADDED_PARTICIPANT = By.xpath("//td[contains(text(), 'PADDY SHARMA')]");
	public static final By PARTICIPANT_SELECTOR = By.id("grdData_ctl02_chkSelector");

	//Get SOP Detail
	public static final By CT_LOG = By.id("txtID");	
	public static final By GET_SOP_DETAIL = By.id("btnGetSOPDetail");
	public static final By INVALID_ID = By.id("lblSOAPError");	

	public static final By TARGET_DETAILS = By.xpath("//div[contains(text(), 'Target Details')]");	
	public static final By LAWSUIT_DETAILS = By.xpath("//div[contains(text(), 'Lawsuit Details')]");	
	public static final By CASE_DETAILS = By.xpath("//div[contains(text(), 'Case Details')]");	
	public static final By SOURCE_DETAILS = By.xpath("//div[contains(text(), 'Source Details')]");	
	public static final By REMARKS = By.xpath("//div[contains(text(), 'Remarks')]");	
	
	public static final By GET_SOP_DETAIL_ER = By.id("btnGetSOPDetailER");
	public static final By ACKNOWLEDGE_SOP = By.id("btnAcknowledgeSOP");
	public static final By GET_DOC_URL = By.id("btnGetDocUrl");
	
	//Delivery Type
	
	public static final By DROPDOWN_BULLETIN = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Bulletin')]");
	public static final By DROPDOWN_COMMUNICATION = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Communication')]");
	public static final By DROPDOWN_RENEWAL = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Renewal')]");
	public static final By DROPDOWN_SOP = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'SOP')]");
	public static final By DROPDOWN_XSOP = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'XSOP')]");

	public static final By ENTITY_PROFILE = By.xpath("//span[contains(text(), 'Entity Profile')]");
	public static final By CUSTOMER_PROFILE = By.xpath("//span[contains(text(), 'Customer Profile')]");
	
	//First Data Present on Page
	public static final By FIRST_DATA = By.id("grdData_ctl02_lnkName");

	//Select Buttons
	public static final By SELECT = By.id("btnSelect");
	public static final By SELECT_ALL = By.id("btnSelectAll");
	public static final By SELECT_NONE = By.id("btnSelectNone");
	
	//Print Button
	public static final By PRINT = By.id("ctlPageTitle_btnPrint");
	
	//Generate Detailed Report
	public static final By GENERATE_DETAILED_REPORT = By.id("ctlPageTitle_btnGenerateDetailReport");

	//Today's Date
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By SELECT_DATE = By.id("ctlFromDate_txtDate");
	
	//Find Image Button
	public static final By FIND_BTN = By.id("imgFind");
	public static final By ADD_UPDATE_BTN = By.id("btnAddUpdate");
	

	//Radio Buttons
	public static final By ENTITY_RADIO_BTN = By.id("rdoCaseEntity");
	public static final By AFF_RADIO_BTN = By.id("rdoCaseAffiliation");

	
}