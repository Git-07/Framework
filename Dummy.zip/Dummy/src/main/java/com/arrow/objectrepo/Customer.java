package com.arrow.objectrepo;
import org.openqa.selenium.By;

public class Customer {

	//Common locators
	public static final By SEARCH = By.id("btnSearch");
	public static final By SEARCH_AGAIN = By.id("btnSearchAgain");
	public static final By NO_RECORDS_FOUND = By.xpath("//span[contains(text(), 'No records found.')]");
	public static final By NO_CUSTOMERID_ERROR = By.xpath("//li[contains(text(), 'Customer not found.')]");
	public static final By NO_CUSTOMERS_ERROR = By.xpath("//li[contains(text(), 'Enter either a Customer # or a Customer Name.')]");
	public static final By FIRST_CUSTOMER = By.id("grdData_ctl02_lnkName");
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");

	//Customer Search Page
	public static final By CUSTOMER_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Customer Search Criteria')]");
	public static final By CUSTOMER_ID_SEARCH = By.id("txtCustomerNumber");
	public static final By CUSTOMER_NAME_SEARCH = By.id("txtCustomerName");
	public static final By LEADING_CHARACTER = By.id("rdoLeadingChar");
	public static final By KEYWORD = By.id("rdoKeyword");
	public static final By CITY = By.id("txtCity");
	public static final By RETRIVE_STATUS_BUTTON = By.id("btnGetTnCStatus");
	public static final By TNC_STATUS = By.id("lblTnCStatus");

	//public static final By STATE = By.id("lstState");
	public static final By STATE_ALABAMA = By.xpath("//select[@id='lstState']//option[@value='       AL ']");
	//public static final By COUNTRY = By.id("lstCountry");
	public static final By COUNTRY_ITALY = By.xpath("//select[@id='lstCountry']//option[@value='       IT ']");
	
	//Customer Profile
	public static final By CUSTOMER_PROFILE = By.xpath("//span[contains(text(), 'Customer Profile')]");
	public static final By CUSTOMER_ID_MATCH = By.xpath("//span[contains(text(), '1824503')]");
	public static final By REQUEST_COMPANY_BOOK_BTN = By.id("btnRequestCompanyBook");

	//Left Nav Tabs
	public static final By CUSTOMER_SEARCH_LEFT_TAB = By.xpath("//a[contains(text(), 'Customer Search')]");
	public static final By CUSTOMER_PRINT = By.id("ctlPageTitle_btnPrint");
	public static final By CUSTOMER_PRINT_VIEW = By.xpath("//td[contains(text(), 'CUSTOMER PROFILE')]");
	
	//Customer Name Search
	public static final By STATE_MICHIGAN = By.xpath("//select[@id='lstState']//option[@value='       MI ']");
	public static final By COUNTRY_USA = By.xpath("//select[@id='lstCountry']//option[contains(text(), 'USA')]");
	public static final By ACTIVE_CUSTOMER_NAME = By.xpath("//a[contains(text(), 'Ford')]");
	public static final By INCLUDE_INACTIVE_CUSTOMER = By.id("chkIncludeInactiveCustomer");
	public static final By INACTIVE_CUSTOMER_NAME = By.xpath("//a[contains(text(), 'Ford Audio-Video Systems, Inc.')]");
	
	//Email Verification Status Page
	public static final By EMAIL_VERIFICATION_LEFT_TAB = By.xpath("//a[contains(text(), 'Email Verification Status')]");
	public static final By NAME_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Name')]");
	public static final By CUSTOMER_NAME_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Customer Name')]");
	public static final By EMAIL_ADDRESS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Email Address')]");
	public static final By OWNING_SERVICE_TEAM_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Owning Service Team')]");
	public static final By SOURCE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Source')]");
	public static final By FIRST_PAGE_LINK = By.linkText("First");
	public static final By PREVIOUS_PAGE_LINK = By.linkText("Previous");
	public static final By PAGE_11__20_LINK = By.linkText("11-20");
	public static final By NEXT_PAGE_LINK = By.linkText("Next");
	public static final By LAST_PAGE_LINK = By.linkText("Last");
	public static final By ACTIVE_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'Name')]");
	public static final By ACTIVE_CUSTOMER_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'Customer Name')]");
	public static final By ACTIVE_EMAIL_ADDRESS_SORT_LINK = By.xpath("//span[contains(text(), 'Email Address')]");
	public static final By ACTIVE_OWNING_SERVICE_TEAM_SORT_LINK = By.xpath("//span[contains(text(), 'Owning Service team')]");
	public static final By ACTIVE_SOURCE_SORT_LINK = By.xpath("//span[contains(text(), 'Source')]");
	public static final By CUSTOMER_NAME_SORT = By.xpath("//a[contains(text(), 'Customer Name')]");
	public static final By EMAIL_ADDRESS_SORT = By.xpath("//a[contains(text(), 'Email Address')]");
	public static final By OWNING_SERVICE_TEAM_SORT = By.xpath("//a[contains(text(), 'Owning Service team')]");
	public static final By SOURCE_SORT = By.xpath("//a[contains(text(), 'Source')]");
	public static final By VIEW_RESULTS_BTN = By.id("grdEmailVerification_ctl02_lnkViewHistory");
	
	//Participant Search Page
	public static final By PARTICIPANT_SEARCH = By.xpath("//a[contains(text(), 'Participant Search')]");
	public static final By PARTICIPANT_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Participant Search Criteria')]");
	public static final By PARTICIPANT_ID_SEARCH = By.id("txtParticipantNumber");
	public static final By NAME_SEARCH = By.id("txtName");
	public static final By TEXT_PARTICIPANT_NAME = By.id("txtParticipantName");
	public static final By INCLUDE_INACTIVE_PARTICIPANT = By.id("chkIncInactiveParticipants");
	public static final By PARTICIPANT_PROFILE_TAB = By.xpath("//a[contains(text(), 'Participant Profile')]");
	public static final By PARTICIPANT_PROFILE = By.xpath("//span[contains(text(), 'Participant Profile')]");
	public static final By PARTICIPANT_NAME_MATCH = By.xpath("//span[contains(text(), 'Adrene Ashford')]");
	
	public static final By ACTIVE_PARTICIPANT_NAME = By.xpath("//a[contains(text(), 'Chuck Meyer')]");
	public static final By INACTIVE_PARTICIPANT_NAME = By.xpath("//a[contains(text(), 'ALEX BELLENSON')]");
	
	public static final By NO_PARTICIPANTS_ERROR = By.xpath("//li[contains(text(), 'Enter either a Participant # or a Participant Name.')]");
	
	//Paperless Participant Search
	public static final By PAPERLESS_PARTICIPANT_SEARCH = By.xpath("//a[contains(text(), 'Paperless Participant Search')]");
	public static final By PAPERLESS_PARTICIPANT_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Paperless Participant Search')]");
	public static final By PAPERLESS_ID_SEARCH = By.id("txtID");
	public static final By PAPERLESS_ID_CHECKBOX = By.id("chkpaperless");

	public static final By PAPERLESS_SEARCH_RESULT_PAGE = By.xpath("//span[contains(text(), 'Paperless Participant Search Results')]");
	public static final By PAPERLESS_PARTICIPANT_NAME_MATCH = By.xpath("//td[contains(text(), 'Roger A. Stong')]");

	//Account Search
	public static final By ACCOUNT_SEARCH = By.xpath("//a[contains(text(), 'Account Search')]");
	public static final By ACCOUNT_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Account Search Criteria')]");

	public static final By ACCOUNT_SEARCH_RESULT_PAGE = By.xpath("//span[contains(text(), 'Account Search Results')]");
	public static final By ACCOUNT_NAME_MATCH = By.xpath("//span[contains(text(), 'APPLE ADVISE, L.L.C.')]");
	public static final By ACCOUNT_ENTITY_LINK = By.id("ctl00_ctl02_lnkTargetUrl");
	public static final By ACCOUNT_CUSTOMER_LINK = By.id("ctl00_ctl03_lnkTargetUrl");
	
	//Name History
	public static final By NAME_HISTORY = By.xpath("//a[contains(text(), 'Name History')]");
	public static final By NAME_HISTORY_PAGE = By.xpath("//span[contains(text(), 'Name History')]");

	public static final By CUSTOMER_NAME_HISTORY = By.xpath("//td[contains(text(), 'General Agency Company')]");
	public static final By TYPE_IN_NAME_HISTORY = By.xpath("//td[contains(text(), 'CURRENT')]");
	
	//Participant Deliverables
	public static final By PARTICIPANT_DELIVERABLES = By.xpath("//a[contains(text(), 'Participant Deliverables')]");
	public static final By PARTICIPANT_DELIVERABLES_PAGE = By.xpath("//span[contains(text(), \"Participant's Deliverables\")]");
	public static final By NO_RECORDS_DELIVERABLES = By.id("ctlNoRecordsBar_lblNoRecords");
	public static final By PARTICIPANT_DELIVERABLE_LIST = By.xpath("//div[contains(text(), \"Participant's Deliverables List\")]");
	public static final By SAVE_ICOMM = By.id("btnSaveICOMM");
	public static final By COMMENT_ERROR = By.xpath("//li[contains(text(), 'Enter a value for comment.')]");
	public static final By COMMENT_SUCCESS = By.xpath("//span[contains(text(), 'Your ICOMM Preferences are saved successfully.')]");
	public static final By CHECKBOX_CHECKED = By.xpath("//tr[@class='dataGrid2Row']//input[@checked='checked']");
	public static final By FIRST_CHECKBOX = By.id("grdData_ctl02_chkDISource");
	public static final By SELECT_PAGE = By.id("btnSelectPage");
	public static final By UNSELECT_PAGE = By.id("btnUnSelectPage");
	public static final By SELECT_ALL = By.id("btnSelectAll");
	public static final By SELECT_NONE = By.id("btnSelectNone");
	public static final By BACK_TO_PARTICIPANT_DELIVERABLES = By.id("btnBackToParticipantDeliverables");
	public static final By FIRST_LINK = By.id("grdData_ctl02_lnkName");
	public static final By ICOMM_CHECKBOX = By.id("grdData_ctl03_chkICOMM");
	public static final By AUTO_RENEW_DISABLED = By.xpath("//input[@disabled='disabled']");
	public static final By AUTO_RENEW = By.id("btnSaveAutoRenew");
	public static final By DELIVERABLETYPE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Deliverable Type')]");
	public static final By RENEWAL_RHS_FILTER = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstRHS')]//option[contains(text(), 'Renewal')]");
	public static final By GO_BTN = By.id("ctlFilterBar_btnGo");
	public static final By AUTORENEW_CHECKBOX = By.id("grdData_ctl02_chkAutoRenew");
	public static final By FORMER_RECIPIENT_COMMENT = By.id("ctlDIHistoryComment_imgFormerRecipientComment");
	public static final By PARTICIPANT_NAME_TEXTFIELD = By.id("txtParticipantName");
	public static final By FIND_BTN = By.id("btnFind");
	public static final By SELECT_IMG_NONE = By.id("imgBtnSelectNone");
	
	//Sort By
	public static final By SORT_DELIVERABLE_TYPE = By.xpath("//span[contains(text(), 'Deliverable Type')]");
	public static final By SORT_DI_SOURCE = By.xpath("//a[contains(text(), 'DI Source')]");
	public static final By SORT_AFFILIATION = By.xpath("//a[contains(text(), 'Affiliation')]");
	public static final By SORT_ENTITY_STATUS = By.xpath("//a[contains(text(), 'Entity Status')]");
	public static final By SORT_GENERIC_CD_ENTITY = By.xpath("//a[contains(text(), 'Generic CD Entity')]");
	public static final By SORT_BRANCH_PLANT = By.xpath("//a[contains(text(), 'Branch Plant')]");
	public static final By SORT_BRANCH_PLANT_CLICKED = By.xpath("//span[contains(text(), 'Branch Plant')]");

	
	//Customer Deliverables
	public static final By CUSTOMER_DELIVERABLES = By.xpath("//a[contains(text(), 'Customer Deliverables')]");
	public static final By CUSTOMER_DELIVERABLES_PAGE = By.xpath("//span[contains(text(), \"Customer's Deliverables\")]");

	public static final By DELIVERY_PARTICIPANT_NAME = By.id("grdData_ctl02_lblParticpantName");
	public static final By DELIVERABLE_TYPE = By.xpath("//option[contains(text(), 'Deliverable Type')]");
	
	public static final By BULLETIN_TEXT = By.xpath("//td[contains(text(), 'Bulletin')]");
	public static final By COMMUNICATION_TEXT = By.xpath("//td[contains(text(), 'Communication')]");
	public static final By RENEWAL_TEXT = By.xpath("//td[contains(text(), 'Renewal')]");
	public static final By XSOP_TEXT = By.xpath("//td[contains(text(), 'XSOP')]");
	public static final By SOP_TEXT = By.xpath("//td[contains(text(), 'SOP')]");
	
	//Participants
	public static final By PARTICIPANTS = By.xpath("//a[contains(text(), 'Participants')]");
	public static final By PARTICIPANTS_PAGE = By.xpath("//span[contains(text(), 'Participants')]");
	public static final By ACTIVE_PARTICIPANT = By.xpath("//a[contains(text(), 'Virginia Nelson')]");	
	
	public static final By REPLACE_RECIPIENT = By.id("btnReplaceRecipient");
	public static final By REPLACE_RECIPIENT_PAGE = By.xpath("//span[contains(text(), 'Replace Recipient')]");
	
	public static final By FIND_ALTERNATE_RECIPIENT = By.id("btnFindAlternateRecipient");
	public static final By CONFIRM_RECIPIENT_PAGE = By.xpath("//span[contains(text(), 'Confirm Recipient Replace')]");
	public static final By CHANGE_MESSAGE = By.xpath("//li[contains(text(), 'The Following Changes were made')]");
	public static final By RETURN_TO_PARTICIPANT_SEARCH = By.id("btnReturnToParticipantSearch");
	public static final By CUSTOMER_NAME = By.xpath("//td[contains(text(), 'Customer Name :')]");
	public static final By CUSTOMER_LINK = By.id("lnkCustomer");
	
	//Viewing Rights
	public static final By VIEWING_RIGHTS = By.xpath("//a[contains(text(), 'Viewing Rights')]");
	public static final By CDSOP_LEFT_NAV = By.xpath("//a[contains(text(), 'CDSOP')]");
	public static final By SOP_VIEWING_RIGHTS_PAGE = By.xpath("//span[contains(text(), 'SOP History Viewing Rights')]");
	public static final By ADD_PARTICIPANTS = By.id("btnAddParticipants");
	public static final By PICK_PARTICIPANTS_PAGE = By.xpath("//span[contains(text(), 'Pick Participants')]");
	public static final By SELECT_FIRST_PARTICIPANT = By.id("grdData_ctl02_chkParticipant");
	public static final By ADD_SELECTED_PARTICIPANT = By.id("btnAddSelectedParticipants");
	public static final By CRM_REQUESTID_SELECT = By.id("ctlSelectCRMidControl_imgFind");
	public static final By CRM_REQUEST_SEARCH_PAGE = By.xpath("//span[contains(text(), 'CRM Request Search')]");
	public static final By FIRSTID_SELECT = By.id("grdData_ctl02_imgBtnSelect");
	public static final By VIEW_HISTORY = By.id("btnViewHistory");
	public static final By VIEWING_RIGHTS_HISTORY_PAGE = By.xpath("//span[contains(text(), 'Viewing Rights History')]");
	public static final By REMOVE_PARTICIPANT = By.id("btnRemoveParticipants");
	public static final By CDSOP_VIEWING_RIGHTS_PAGE = By.xpath("//span[contains(text(), 'CDSOP Viewing Rights')]");
	public static final By CREATED_DATE = By.id("ctlCreateDateFrom_txtDate");
	public static final By ADD_ENTITY_BASED_VIEWING_RIGHTS_BTN = By.id("btnAddEntityBasedVR");
	public static final By FIRST_NAME_CHECKBOX = By.id("grdData_ctl02_chkSelector");
	public static final By NEXT_BTN = By.id("btnNext");
	public static final By SPECIFIC_SPECIAL_CIRCUMSTANCES_RADIO_BTN = By.id("rdoSpecificSpecialCircumstances");
	public static final By SPECIAL_CIRCUMSTANCES_DROPDOWN = By.id("ctlSpecialCircumstancesCtrl_lbSpecialCircum");
	public static final By RIGHT_ARROW = By.id("ctlSpecialCircumstancesCtrl_lnkAdd");
	public static final By SPECIFIC_LAWSUIT_TYPES_RADIO_BTN = By.id("rdoSpecificLawsuitTypes");
	public static final By LAWSUIT_TYPE_DROPDOWN = By.id("ctlLawsuitTypeControl_lbLawsuitType");
	public static final By LAWSUIT_RIGHT_ARROW = By.id("ctlLawsuitTypeControl_lnkAdd");
	public static final By CRM_REQUEST_ID_BTN = By.id("ctlSelectCRMidControl_imgFind");
	public static final By FIRST_SELECT_BTN = By.id("grdData_ctl02_imgBtnSelect");
	public static final By SAVE_BTN = By.id("btnSave");
	public static final By FIRST_CRM_REQUEST_ID = By.id("grdDataVR_ctl02_lnkCRMReqID");
	public static final By CTCORP_ENTITY_RADIO_BTN = By.id("rdoEntity");
	public static final By NRAI_ENTITY_RADIO_BTN = By.id("rdoNraiEntity");
	public static final By NRAI_AFFILIATION_RADIO_BTN = By.id("rdoNraiAffiliation");

	public static final By CTCORP_SUBGROUP_RADIO_BTN = By.id("rdoEntity");
	
	//Fields on Request Company Book Page
	public static final By SELECT_AFFILIATION_BTN = By.id("imgSelect");
	public static final By FIRST_SELECT_BTN_ON_GRID = By.id("grdData_ctl02_lnkSelect");
 
	//Fields on Participant Profile Page
	public static final By REGROUP_ENTITIES_BTN = By.id("btnReGroupentities");
	public static final By AUTO_RENEW_LINK = By.id("lnkAutoRenewProfileDetail");
	public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");
	public static final By COMMENT_TEXTBOX = By.id("txtComment");
	
	//Fields on Regroup Entities Page
	public static final By FIRST_CHECKBOX_ENTITY = By.id("grdData_ctl02_chkEntity");
	public static final By STANDALONE_ENTITY_RADIO_BTN = By.id("rdoStandAlone");
	public static final By COMMENTS_TEXTBOX = By.id("txtComments");
	public static final By REGROUP_BTN = By.id("btnRegroup");
	public static final By JOIN_EXISTING_RADIO_BTN = By.id("rdoJoinExisting");
	public static final By JOIN_NEW_RADIO_BTN = By.id("rdoJoinNew");
	public static final By AFFILIATION_NAME_TEXTBOX = By.id("ctlJoinAffi_txtAffiliationName");
	public static final By SUBGROUP_NAME_TEXTBOX = By.id("ctlJoinAffi_txtXSOP");
	public static final By SELECT_RECIPIENT_BTN = By.id("ctlJoinAffi_ctlRecipient_imgFind");
	public static final By AFFILIATION_COMMENTS_TEXTBOX = By.id("ctlJoinAffi_txtComments");
	public static final By COMMON_RENEWAL_DRPDWN = By.id("ctlJoinAffi_lstRenewalMonth");



	

}
