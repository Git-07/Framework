package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Rep {
	
	//Page Title
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	
	// Create Representation
	public static final By ENTITY_SEARCH = By.xpath("//a[contains(text(), 'Entity Search')]");
	public static final By REPRESENTATION_TAB = By.xpath("//a[contains(text(), 'Representation')]");
	public static final By CREATE_REPRESENTATION = By.id("btnCreateRepUnit");
	public static final By NEW_REPRESENTATION_PAGE = By.xpath("//span[contains(text(), 'New Representation Unit')]");

	// DropDowns - Select Jurisdiction
	public static final By ALABAMA_JURISDICTION = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']//option[contains(text(), 'Alabama')]");
	public static final By ALASKA_JURISDICTION = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']//option[contains(text(), 'Alaska')]");
	public static final By ARIZONA_JURISDICTION = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']//option[contains(text(), 'Arizona')]");
	public static final By NEWYORK_JURISDICTION = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']//option[contains(text(), 'New York')]");
	public static final By NH_JURISDICTION = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']//option[contains(text(), 'New Hampshire')]");

	// DropDown - Select Service Type
	public static final By CONTRACT_AGENCY = By
			.xpath("//select[@id='drpServiceType']//option[contains(text(), 'Contract Agency')]");
	public static final By FOREIGN_REP = By
			.xpath("//select[@id='drpServiceType']/option[contains(text(), 'Foreign Representation')]");
	public static final By DOMESTIC_REP = By
			.xpath("//select[@id='drpServiceType']/option[contains(text(), 'Domestic Representation')]");
	public static final By FMCA = By
			.xpath("//select[@id='drpServiceType']//option[contains(text(), 'FMCA (Federal Motor Carrier Act)')]");

	public static final By SERVICE_TYPE = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Service Type')]");

	// DropDown - Select Status
	public static final By STATUS = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Status')]");
	public static final By ACTIVE_STATUS = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Active')]");
	
	// DropDown - Discontinuance Date
	public static final By DISCONTINUANCE_DATE= By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Discontinuance Date')]");
	
	// New Representation Unit Page
	public static final By NEW_REPRESENTATION_UNIT_PAGE = By
			.xpath("//span[contains(text(), 'New Representation Unit')]");
	public static final By ENTITY_BUSINESS_UNIT_CTCORP = By
			.xpath("//span[@id='ctlContextBar_lblContextBusUnit'][contains(text(), '(CTCORP)')]");
	public static final By NUMBER_OF_YEARS = By.id("txtYears");
	public static final By FILING_DATE_BUTTON = By.id("ctrlDateSelectorFiling_btnCal");
	public static final By EXPIRATION_DATE_BUTTON = By.id("ctrlDateSelectorExpiration_btnCal");
	public static final By DISCONTINUE_DATE = By.id("ctrlDateSelectorDiscontinuanceFiling_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");

	// Representation Unit Page
	public static final By REPRESENTATION_UNIT_PAGE = By.xpath("//span[contains(text(), 'Representation Units')]");
	public static final By CONTRACT_AGENCY_REP = By.xpath("//a[contains(text(), 'Contract Agency')]");
	public static final By DOMESTIC_AGENCY_REP = By.xpath("//a[contains(text(), 'Domestic Registered')]");
	public static final By DISCONTINUE_BUTTON = By.id("btnDiscont");
	public static final By REP_DISCONTINUE_BUTTON = By.id("btnDiscontinue");
	public static final By DISCONTINUE_REASON = By
			.xpath("//select[@id='drpListDiscontTypes']//option[contains(text(), 'Bankruptcy Ch. 11')]");
	public static final By DISCONTINUE_REASON_NRAI = By
			.xpath("//select[@id='drpListDiscontTypes']//option[contains(text(), 'Change of Independent Director')]");
	public static final By REVISIONS_PAGE = By.xpath("//span[contains(text(), 'Revisions')]");

	public static final By REPRESENTATION_UNIT_PROFILE = By
			.xpath("//span[contains(text(), 'Representation Unit - Profile')]");
	public static final By DISCONTINUE_STATUS = By.xpath("//span[contains(text(), 'Discontinued')]");
	public static final By REINSTATE = By.id("btnReinstate");
	public static final By REINSTATE_FILING_DATE = By.id("ctrlDtReinstatFiling_btnCal");
	public static final By REINSTATEMENT_REASON = By
			.xpath("//select[@id='ddlReinstatReason']//option[contains(text(), 'Re-qualification')]");
	public static final By RETURN_TO_REP_UNITS = By.id("btnReturnRepUnit");
	public static final By DISCONTINUE_DUE_TO_PROPERTY_SOLD = By.id("btnDiscontinueWithReasonPropertySold");

	public static final By SORT_BY_JURISDICTION_ACTIVE = By.xpath("//span[contains(text(), 'Jurisdiction')]");
	public static final By SORT_BY_JURISDICTION_INACTIVE = By.xpath("//a[contains(text(), 'Jurisdiction')]");
	public static final By SORT_BY_STATUS = By.xpath("//a[contains(text(), 'Status')]");
	public static final By SORT_BY_SERVICE_TYPE = By.xpath("//a[contains(text(), 'ServiceType')]");
	public static final By SORT_BY_REGISTERED_AGENT = By.xpath("//a[contains(text(), 'Registered Agent')]");
	public static final By SORT_BY_IS_STATE_VALIDATED = By.xpath("//a[contains(text(), 'Is State ID Validated')]");

	public static final By DOMESTIC_REP_UNIT_AGENT = By.id("grdData_ctl02_lnkName");
	public static final By DOMESTIC_REP_UNIT = By.xpath("//a[contains(text(), 'Domestic Representation (Limited Liability Company)')]");
	// Re-instating and Discontinuing multiple rep's
	public static final By MULTIPLE_REP_TEXT = By.xpath("//td[contains(text(), 'Choose a multi-rep operation')]");
	public static final By REINSTATE_MULTIPLE = By
			.xpath("//select[@id='lstDiscReinst']/option[contains(text(), 'Reinstate Multiple')]");
	public static final By DISCONTINUE_MULTIPLE = By
			.xpath("//select[@id='lstDiscReinst']/option[contains(text(), 'Discontinue Multiple')]");
	public static final By GO_BUTTON = By.id("lnkGo");
	public static final By ENTITY_COMMENT = By.id("txtEntityComment");
	public static final By MULTIPLE_REP_PAGE = By
			.xpath("//span[contains(text(), 'Discontinue Multiple Representation Units')]");
	public static final By REINSTATE_MULTIPLE_REP_PAGE = By
			.xpath("//span[contains(text(), 'Reinstate Multiple Representation Units')]");
	public static final By MULTIPLE_DISCONTINUE_REASON = By
			.xpath("//select[@id='drpListDiscontinuanceReason']/option[contains(text(), 'Bankruptcy Ch. 11')]");
	public static final By MULTIPLE_REINSTATE_REASON = By
			.xpath("//select[@id='lstReinstatementReason']/option[contains(text(), 'Re-qualification')]");
	public static final By MULTIPLE_REINSTATE_DATE = By.id("ctrlDateSelectorReinstatementFiling_btnCal");

	// Print Rep Profile
	public static final By PRINT_REP_PROFILE = By.xpath("//span[contains(text(), 'REPRESENTATION UNIT PROFILE')]");
	public static final By INDEPENDENT_DIRECTOR_DROPDOWN = By.xpath(
			"//select[@id='drpServiceType']/option[contains(text(), 'Independent Director / Manager Services')]");
	public static final By MAINTAIN_OFFICER_DIRECTOR_PAGE = By
			.xpath("//span[contains(text(), 'Maintain Officers / Directors')]");
	public static final By FIND_OFFICER_DIRECTOR_PAGE = By.xpath("//span[contains(text(), 'Find Officer / Director')]");
	public static final By EMPLOYEE_NAME_FIELD = By.id("txtEmployeeName");
	public static final By POSITION = By.xpath("//select[@id='drpPosition']/option[2]");
	public static final By APPOINTED_DATE = By.id("ctrlDateSelectorAppointed_btnCal");
	public static final By SELECT_EMPLOYEE = By.id("grdData_ctl02_btnSelect");
	public static final By EDIT_BUTTON = By.id("grdData_ctl02_btnEdit");
	public static final By REP_EDIT_BUTTON = By.id("ctlPageTitle_btnEdit");
	public static final By DELETE_BUTTON = By.id("grdData_ctl02_btnDelete");
	public static final By RETURN_TO_PROFILE_VIEW = By.id("btnReturnToProfileView");
	public static final By STATE_BIZ_ERROR_ERRMSG = By
			.xpath("//li[contains(text(), 'State biz data service not available. Please try again later.')]");
	public static final By STATE_BIZ_ERROR_MSG = By
			.xpath("//li[contains(text(), 'State biz data service not availaible. Please try again later.')]");
	
	public static final By CT_FILING_DATE = By.id("ctlStateResult_lblCTFilingDateText");
	public static final By MAINTAIN_BUTTON = By.id("btnMaintain");
	public static final By MAINTAIN_INDEPENDENT_AFFILIATE_COMMISION_BUTTON = By.id("btnMaintainIndependentAffiliate");
	public static final By MAINTAIN_INDEPENDENT_AFFILIATE_COMMISION_PAGE = By
			.xpath("//span[contains(text(), 'Maintain Independent Affiliate Commission')]");
	public static final By AFFILIATE_LIST_PAGE = By.xpath("//span[contains(text(), 'Affiliate List')]");
	public static final By AFFILIATE_COMMISION_DROPDOWN = By
			.xpath("//select[@id='drpCommissionRate']/option[@value='10']");
	public static final By AFFILIATE_COMMISION_PERCENTAGE = By.xpath("//span[contains(text(), '10.00 %')]");

	//
	public static final By NORTH_CAROLINA_JURISDICTION = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']/option[contains(text(), 'North Carolina')]");
	public static final By PUBLIC_BENEFIT_LLC = By
			.xpath("//select[@id='drpServiceType']/option[contains(text(), 'Foreign Rep (Public Benefit LLC)')]");
	public static final By STATE_ID = By.id("txtStateId");
	public static final By FOREIGN_REP_TEXT = By.xpath("//a[contains(text(), 'Foreign Rep (Public Benefit LLC)')]");
	public static final By GET_STATE_IDCT_DATABASE_BUTTON = By.id("btnGetStateId");
	public static final By STATE_ID_VERIFICATION_PAGE = By
			.xpath("//span[contains(text(), 'Rep State ID Verification')]");
	public static final By CUSTOM_SEARCH_RADIO = By.id("rdoCustomSearch");
	public static final By CUSTOM_SEARCH_TEXT = By.id("txtCusSearch");
	public static final By REP_SEARCH_BUTTON = By.id("btnSearchPro");
	public static final By REP_SEARCH_FIRST_RESULT = By.id("grdUDSResults_ctl02_lnkEntityName");
	public static final By ACCEPT_SELECTED_ITEM_BUTTON = By.id("btnAcceptable2");
	public static final By ALASKA_NAME_JURISDICTION = By
			.xpath("//select[@id='ctlJurisSelector_lstJurisdictions']/option[contains(text(), 'Alaska')]");
    public static final By NAMES_LINK=By.xpath("//a[contains(text(),'Names')]");
	public static final By END_DATE_ASSUMEDNAME_TEXT = By.xpath("//div[contains(text(), 'End Dated Assumed Names')]");
	public static final By RETURN_TO_REP_PROFILE = By.id("btnRepProfileView");
	public static final By RETURN_TO_PROFILE_VIEW_BTN = By.id("btnReturnToProfileView");

	public static final By COMPARE_TO_STATE_RECORD_BTN = By.id("btnViewRepDetails");
	public static final By STATE_RECORD_DETAILS_PAGE = By
			.xpath("//span[contains(text(), 'Details From State Data Repository')]");
	// Go Back Btn
	public static final By GO_BACK_BTN = By.id("btnGoBack");
	public static final By ACCEPT_RESIGNATION_BUTTON=By.id("btnAcceptResign");
    public static final By REJECT_RESIGNATION_BUTTON=By.id("btnRejectResign");
    
    // Edit Rep Unit page
	public static final By STATE_ID_TEXTBOX = By.id("txtStateID");
	public static final By AGENT_DROP_DOWN = By.id("drpAgents"); 
	public static final By REINSTATE_REASON_DROP_DOWN = By.id("ddlReinstatReason");
	public static final By AGENT_APPOINTMENT_DATE = By.id("ctlRepProfile_lblCTAppointmentDt");
	public static final By REINSTATEMENT_DATES = By.id("ctrlDtReinstatFiling_txtDate");
	public static final By DISCONTINUE_DATES = By.id("ctrlDateSelectorDiscontinuanceFiling_txtDate");
	
	//Resignate Representation Page
	public static final By RESIGN_REPRESENTATION_UNIT_PAGE=By.xpath("//span[contains(text(),'Resign Representation Unit')]");
	public static final By RESIGNATE_BTN= By.id("btnStartResign");
	public static final By PENDING_DATE_TEXT= By.id("ctrlDtResignPending_txtDate");

	//Cancel Btn
	public static final By CANCEL_REP_STATEID = By.id("btnNoMatch2");
	public static final By ASSUMED_NAME_FILING_DATES = By.id("ctlFilingDate_txtDate");
	public static final By CREATE_REP_FILING_DATES = By.id("ctrlDateSelectorFiling_txtDate");
	public static final By CREATE_REP_EXPIRATION_DATES = By.id("ctrlDateSelectorExpiration_txtDate");
}
