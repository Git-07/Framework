package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Carrier_SOP {
	
public static final By UPLOADIMAGEBTN = By.id("btnUploadImage");
	
	//Filter buttons
	public static final By CLEARBTN = By.id("ctlFilterBar_btnClear");
	public static final By FILTERDROPDOWN1 = By.id("ctlFilterBar_lstF");
	public static final By FILTERDROPDOWN2 = By.id("ctlFilterBar_lstOp");
	public static final By FILTERTEXTFIELD = By.id("ctlFilterBar_txtRHS");
	public static final By FILTERGOBTN = By.id("ctlFilterBar_btnGo");
	
	//Elements on SOP List page
	public static final By CESSELECTBTN = By.id("grdData_ctl02_lnkProcessCES");
	public static final By VIEW_BTN = By.id("grdData_ctl02_lnkView");
	public static final By CREATE_WORKSHEET_BTN = By.id("grdData_ctl02_lnkCreateWorksheet");
	public static final By FIRST_SOP_CHECKBOX = By.id("grdData_ctl02_chkBoxEsopDoc");
	public static final By ASSIGN_BTN = By.id("btnAssign");
	public static final By CES_ENABLED_LABEL = By.id("grdData_ctl02_lblCESEnabled");
	public static final By SOP_15DAYS_TAB = By.id("lnkOldSopList");
	
	//Elements on CES page
	public static final By SUBMITBTN = By.id("BtnSubmit2");
	public static final By ESOPIFRAMEID = By.id("frmCesData");
	public static final By INTAKEMETHODLABEL = By.xpath("//*[@id='EsopInfoTbl']/tbody/tr[5]/td[1]");
	public static final By INTAKEMETHODVALUE = By.id("lblIntakeMethod");
	public static final By CASE_ID_TEXTFIELD = By.id("txtCaseNumber");
	public static final By CUSTOMER_COMMENTS_LABEL = By.xpath("//*[@id=\"EsopInfoTbl\"]/tbody/tr[6]/td[1]");
	public static final By CUSTOMER_COMMENTS_VALUE = By.id("txtareaCustComment");
	public static final By SELECT_ARROW_ENTITY_BTN = By.id("IBEntitySearch");

	public static final By FIRST_ENTITY_IN_SEARCH_RESULT = By.xpath("//span[@id='grdData_ctl02_lblEntityNames']/a[1]");
	public static final By HOME_PDF_ICONS = By.className("bootstrap-iso");
	public static final By HOME_ICON = By.className("iframe-icon-PDF");
	public static final By LAWSUITTYPE_DROPDOWN = By.id("drpLawsuitType");
	
	//Elements on Entity Name Search Criteria
	public static final By ENTITY_NAME_TEXTFIELD = By.id("txtName");
	public static final By SEARCH_BTN = By.id("btnSearch");
	public static final By ENTITY_SEARCH_MESSAGE = By.id("titleLimitCDSOP");
	public static final By ENTITY_DOM_JURISDICTION = By.id("grdData_ctl02_lblJuris");
	public static final By ENTITY_REP_JURISDICTION = By.id("grdData_ctl02_lblRepJuris");
	public static final By ENTITY_REP_STATUS = By.id("grdData_ctl02_lblRepStatus");
	public static final By ENTITY_REP_SERVICE_TYPE = By.id("grdData_ctl02_lblRepServiceType");
	public static final By ENTITY_RESULT_MESSAGE = By.id("lblNoRecords");
	public static final By UNIDENTIFIED_ENTITY_BTN = By.id("btnUnidentifiedEntity");
	
	//Elements of ML Slider on CES page
	public static final By SLIDER_EYE_OPEN_BTN = By.cssSelector(".glyphicon-eye-open");
	public static final By SLIDER_EYE_CLOSE_BTN = By.cssSelector(".glyphicon-eye-close");
	public static final By SLIDER_ID = By.id("ml_sidebar");
	public static final By SLIDER_OPENED_BTN = By.cssSelector(".glyphicon-chevron-left");
	public static final By SLIDER_TITLE = By.xpath("//div[@id='ml_sidebar']//h4");
	public static final By CES_SECTION_UP_ARROW = By.cssSelector(".glyphicon-menu-up");
	public static final By CES_SECTION_DOWN_ARROW = By.cssSelector(".glyphicon-menu-down");
	public static final By CES_SECTION_TITLE = By.className("panel-title");
	public static final By SLIDER_CLOSED_BTN = By.cssSelector(".glyphicon-chevron-right");
	public static final By COPY_ICON = By.cssSelector(".glyphicon.glyphicon-duplicate");
	public static final By FIRST_ELEMENT_ON_ML_SLIDER = By.xpath("//*[@id=\"tCES\"]/tbody/tr[1]/td[2]/div");
	
	//Elements on Create Worksheet page
	public static final By METHOD_OF_SERVICE = By.id("drpMethodofService");
	public static final By RECEIVED_BY_MEMBER_DPDOWN = By.id("drpReceivedBy");
	public static final By POST_MARKED_DATE = By.id("ctlDateSelectorPostMarked_txtDate");
	public static final By CERTIFIED_MAIL_NUMBER = By.id("txtCertifiedMailNo");
	public static final By CUSTOMER_COMMENT_GRID = By.id("txtareaCustComment");
	public static final By INITIAL_RADIOBTN = By.id("rdoInitial");
	public static final By CASE_NUMBER_NONE_RADIOBTN = By.id("rdoCaseNoneSpecified");
	public static final By PLAINTIFF_NONE_RADIOBTN = By.id("rdoPlaintiffNone");
	public static final By DEFENDANT_TEXTFIELD = By.id("txtDefendantName");
	public static final By NEXT_BTN = By.id("btnNext");
	public static final By COURT_NONE_RADIOBTN = By.id("rdoCourtNoneSpecified");
	public static final By DOCUMENT_TYPE_DROPDWN = By.id("drpDocumentType");
	public static final By DOCUMENT_TYPE_TEXTFIELD = By.id("txtDocumentType");
	public static final By SPECIAL_DROPDWN = By.id("drpSpecialCircum");
	public static final By ANSWER_NONE_RADIOBTN = By.id("rdoAnswerDateNone");
	public static final By SAVE_BTN = By.id("btnSave");
	public static final By TIME_TEXTFIELD = By.id("txtTime");
	public static final By REJECT_REASON_DRPDWN = By.id("drpRejectReason");
	public static final By REJECT_CALENDAR = By.id("ctlDateSelectorRejectDate_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By TOP_SAVE_BTN = By.id("btnSaveTop");
	public static final By CREATE_UPS_PACKAGE_BTN = By.id("btnRejectionLetter");
	
	
	//Elements on Manage Default Assignment page
	public static final By MANAGE_DEFAULT_ASSIGNMENT_LINK = By.linkText("Manage Default Assignment");
	public static final By ADD_NEW_BTN = By.id("btnAddNew");
	public static final By CES_ENABLED_SORTBY_LINK = By.linkText("CES Enabled");
	public static final By CES_ENABLED_CHECKBOX = By.id("chkIsCESEnabled");
	public static final By EDIT_BTN = By.id("grdData_ctl02_lnkEdit");
	
	//Fields On Sop Worksheet Profile page
	public static final By WORKSHEET_EDIT_BTN = By.id("ctlPageTitle_btnEdit");
	public static final By CHOOSE_DI_BTN = By.id("btnChooseDI");
	
	//Fields on Choose Delivery Instruction Page
	public static final By ACTIONS_LIST_BTN = By.id("btnActionsList");
	
	//Fields on Execute Action Items Page
	public static final By MANAGE_ACTIONS_ITEM_BTN = By.id("btnManageActionItems");
	public static final By EXECUTE_BTN = By.xpath("//input[@alt='Execute']");	
	public static final By STATUS_OF_FIRST_ACTION_ITEM_ON_GRID = By.xpath("//span[contains(text(), 'Executed')]");
	
	//Fields on Manage Action Items Page
	public static final By SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN = By.xpath("//select[@id='drpDeliverable']//option[contains(text(), 'SOP Papers with Transmittal')]");
	public static final By COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN = By.xpath("//select[@id='drpDeliverable']//option[contains(text(), 'Copy of Transmittal')]");
	public static final By FED_EX_INTERNATIONAL_ECONOMY_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Fed Ex International Economy')]");
	public static final By HAND_DELIVERED_BY_CT_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Hand Delivered by CT')]");
	public static final By FED_EX_PRIORITY_OVERNIGHT_DELIVERY_METHOD_DRPDWN = By.xpath("//select[@id='drpDeliveryMethod']//option[contains(text(), 'Fed Ex Priority Overnight')]");
	public static final By RECIPIENT_SELECT_BTN = By.id("ctlRecipient_imgFind");
	public static final By ADDUPDATE_BTN = By.id("imgAddUpdate");
	public static final By MANAGE_ACTIONS_ITEM_ERR_MSG = By.xpath("//li[contains(text(), 'The selected delivery method is not valid for this recipient.')]");

	
	//Fields on Carrier Package Search Page
	public static final By CARRIER_TRACKING_ID = By.id("txtFedExTrackingID");
	
	
	//Fields on Carrier Package Search Results Page
	public static final By NO_RECORDS_FOUND_ERR_MSG = By.xpath("//span[contains(text(), 'No records found.')]");
	
	//Field on Entity Name Search Results Page
	public static final By SELECT_FIRST_ENTITY_ON_GRID = By.id("grdData_ctl02_lnkSelect");
	
	//Fields on Related Worksheet Basic Search Page
	public static final By CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN = By.id("btnCreate");
	
	//Fields On Find DI Recipient Page
	public static final By PARTICIPANTNAMEFIELD = By.id("txtParticipantName");
	public static final By FINDBTN = By.id("btnFind");
	public static final By TABLEID = By.id("grdData");
	public static final By SELECTRECIPIENTBTN = By.id("grdData_ctl02_lnkSelect");
	
	
	//Fields on Select Carrier Package Page
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By CARRIER_PACKAGE_SEARCH = By.xpath("//span[contains(text(),'Carrier Package Search')]");	
	public static final By STATUS_OPEN = By.xpath("//tr[@id='trPackageStatus']//span[contains(text(), 'Open')]");	
	public static final By PIGGYBACK_YES = By.xpath("//span[@id='lblPiggyback'][contains(text(), 'Yes')]");	
	public static final By SHIPMENT_TYPE = By.xpath("//span[contains(text(), 'UPS Next Day Air')]");	
	public static final By PACKAGE_TYPE = By.xpath("//span[contains(text(), 'Envelope')]");
	public static final By EDITED_SHIPMENT_TYPE = By.xpath("//span[contains(text(), 'UPS 2nd Day Air')]");	
	public static final By EDITED_PACKAGE_TYPE = By.xpath("//span[contains(text(), 'Box, 1 lbs')]");
	public static final By PIGGYBACK_NO = By.xpath("//span[@id='lblPiggyback'][contains(text(), 'No')]");	
	public static final By EDIT_CARRIER_PACKAGE = By.id("ctlPageTitle_btnEdit");
	public static final By EDIT_CARRIER_PACKAGE_PAGE = By.xpath("//span[contains(text(), 'Edit Carrier Package')]");	
	//Drop Down Shipment
	public static final By SHIPMENT_TYPE_DROPDOWN = By.id("drpShipmentType");
	public static final By BOX_RADIO_BUTTON = By.id("rdoPackageBox");
	public static final By ENVELOPE_RADIO_BUTTON = By.id("rdoPackageEnvelop");
	public static final By PIGGYBACK_NO_BUTTON = By.id("rdoPiggybackNo");
	public static final By PIGGYBACK_YES_BUTTON = By.id("rdoPiggybackYes");
	public static final By CLOSED_STATUS = By.xpath("//tr[@id='trPackageStatus']//span[contains(text(), 'Closed')]");
	public static final By DELIVERY_STATUS = By.xpath("//tr[@id='trDeliveryStaus']//a[contains(text(), 'Delivered')]");
	public static final By UNDELIVERED_STATUS = By.xpath("//tr[@id='trPackageStatus']//span[contains(text(), 'Undelivered')]");
	public static final By DELIVERY_STATUS_UNAVAILABLE = By.xpath("//tr[@id='trDeliveryStaus']//a[contains(text(), 'Unavailable')]");

	public static final By PARTICIPANT_CUSTOMER_SEARCH = By.id("lnkRecipientSearch");
}
