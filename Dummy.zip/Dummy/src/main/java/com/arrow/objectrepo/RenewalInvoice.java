package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class RenewalInvoice {

	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By CONTEXT_TITLE = By.id("ctlContextBar_lblContextTitle");

	// Fields on Renewal Invoice Search Page
	public static final By INVOICE_ID_TEXT_BOX = By.id("txtID");
	public static final By SEARCH_BTN = By.id("btnSearch");
	public static final By RECEIVED_DATE_FROM = By.id("ctlDateFrom_txtDate");
	public static final By RECEIVED_DATE_TO = By.id("ctlDateTo_txtDate");

	//Fields on XSOP search Page
	public static final By XSOP_INVOICEID_TEXTBOX = By.id("txtID");
	
	//Fields on Order Preview Page
	public static final By XSOP_INVOICE_ADJUSTMENT_BUTTON = By.id("btnInvoiceAdjustment");



	// Fields on Renewal Invoices Page
	public static final By FIRST_INVOICE_ON_THE_GRID = By.id("grdData_ctl02_lnkInvoice");
	public static final By SECOND_INVOICE_ON_THE_GRID = By.id("grdData_ctl03_lnkInvoice");
	public static final By INVOICE_ID_ON_INVOICE_PROFILE = By.id("ctlContextBar_lblContextId");
	public static final By REPRINT_BTN = By.id("btnReprint");
	public static final By SECOND_INVOICE_CHECKBOX = By.id("grdData_ctl03_chkSelector");
	public static final By SELECT_PAGE_BTN = By.id("btnSelectPage");
	public static final By UNSELECT_PAGE_BTN = By.id("btnUnSelectPage");
	public static final By FIRST_CREDIT_DS_BTN_ON_GRID = By.id("grdData_ctl02_btnCreditDS");
	public static final By CREDIT_DS_SORTING_LINK = By.linkText("Credit DS");
	public static final By ACTIVE_CREDIT_DS_SORTING_LINK = By.xpath("//span[contains(text(), 'Credit DS')]");
	public static final By CREDIT_DS_FIRST_FILTER = By.xpath("//option[contains(text(), 'Credit DS')]");
	public static final By YES_SECOND_FILTER = By.xpath("//option[contains(text(), 'Yes')]");
	public static final By GO_BTN = By.id("ctlFilterBar_btnGo");
	public static final By CURRENT_RENEWAL_INVOICES_ACTIVE_TAB = By.xpath("//td[contains(text(), 'Current Renewal Invoices')]");
	public static final By LAST_TWO_YEARS_REMEWAL_INVOICES_TAB = By.linkText("Last 2 Year's Renewal Invoices");
	public static final By ALL_REMEWAL_INVOICES_TAB = By.linkText("All Renewal Invoices");
	public static final By INVOICE_HISTORY_TAB = By.linkText("Invoice History");
	public static final By REVISIONS_LEFT_NAV_LINK = By.linkText("Revisions");
	public static final By REVISION_PREVIEW_BTN = By.id("btnRevisionPreview");
	public static final By NEW_INVOICES_ERROR_MSG = By.xpath("//span[contains(text(), 'No revised/new invoice(s) will be generated based on your current revisions:')]");


	// Fields on Referrals Page
	public static final By INVOICE_CHECKBOX = By.id("grdData_ctl02_chkSelector");
	public static final By REMOVE_REFERRAL_BTN = By.id("btnRemoveReferral");
	public static final By NOT_ON_REFERRAL_TAB = By.id("lnkInvoicesNotOnReferral");
	public static final By ON_REFERRAL_TAB = By.id("lnkOnReferral");
	public static final By PLACE_ON_REFERRAL_BTN = By.id("btnPlaceOnReferral");
	public static final By PLACE_ON_REFERRAL_ERR_MSG = By
			.xpath("//li[contains(text(), 'At least one invoice must be selected to place on referral.')]");

	// Fields on Invoice Profile Page
	public static final By ARROW_INVOICE_STATUS_IS_REVISED = By.xpath("//span[@id='lblStatus'][contains(text(), 'Revised')]");
	public static final By CREDIT_DS_BTN = By.id("btnCreditDS");
	
	public static final By BLANK_SUBGROUP = By.xpath("//span[@id='lblSubGroup'][contains(text(), '--')]");
	public static final By CONSOLIDATED_STATUS = By.id("lblConsolidated");
	public static final By ALL_RENEWAL_INVOICES_TAB = By.id("lnkAll1");

	// Fields on Reprint Invoice Page
	public static final By DELIVER_TO_CUSTOMER_RADIO_BTN = By.id("rdoRepirntToCustomer");
	public static final By PRINT_LOCALLY_RADIO_BTN = By.id("rdoRepirntLocally");
	public static final By REPRINT_BTN_ON_REPRINT_INVOICE_PAGE = By.id("btnReviseReprint");

	// Fields on Revisions Page
	public static final By ALL_REVISABLE_INVOICES_TAB = By.id("lnkAll");
	public static final By REVISE_BTN = By.id("btnRevise");
	public static final By REVISE_ERR_MSG = By
			.xpath("//li[contains(text(), 'At least one invoice must be selected to revise.')]");
	public static final By CURRENT_REVISABLE_INVOICES_ACTIVE_TAB = By
			.xpath("//td[contains(text(), 'Current Revisable Invoices')]");

	// Fields on Revise Invoice Page
	public static final By REVISION_REASON_DRPDWN = By.id("lstRevisionReasons");
	public static final By REVISE_BTN_ON_REVISE_INVOICE_PAGE = By.id("btnReviseReprint");
	public static final By CANCEL_BTN = By.id("btnCancel");
	
	// Fields on Representation Units with Disbursements Page
	public static final By INVOICE_ID_ON_CONTEXT_BAR = By.id("ctlContextBar_lblContextId");

	// Field on Credit Disbursements page
	public static final By DISBURSEMENTS_MESSAGE = By.id("headLines");
	public static final By INVOICE_NUMBER = By.id("lblInvoiceNumber");
	public static final By INVOICE_DATE = By.id("lblInvoiceDate");
	public static final By RENEWAL_DATE = By.id("lblRenewalDate");
	public static final By REVISION_BTN_TOP = By.id("btnReviseTop");
	public static final By REVISION_BTN_BOTTOM = By.id("btnReviseBottom");
	public static final By REVISION_PREVIEW_BTN_TOP = By.id("btnRevisionPreviewTop");
	public static final By REVISION_PREVIEW_BTN_BOTTOM = By.id("btnRevisionPreviewBottom");
	public static final By ENTITY_NAME_COLUMN = By.xpath("//tr[@class='dataGridHeaderRow']//td[1]");
	public static final By DS_SERVICE_DESCR_COLUMN = By.xpath("//tr[@class='dataGridHeaderRow']//td[2]");
	public static final By JURISDICTION_COLUMN = By.xpath("//tr[@class='dataGridHeaderRow']//td[3]");
	public static final By DS_AMOUNT_COLUMN = By.xpath("//tr[@class='dataGridHeaderRow']//td[4]");
	public static final By CREDIT_DS_COLUMN = By.xpath("//tr[@class='dataGridHeaderRow']//td[6]");
	public static final By SELECT_ALL_BTN = By.id("btnSelectAll");
	public static final By SELECT_NONE_BTN = By.id("btnSelectNone");
	public static final By ENTITY_NAME_SORTING_LINK = By.linkText("Entity Name");
	public static final By DS_SERVICE_DESCR_SORTING_LINK = By.linkText("Disbursements Service Description");
	public static final By JURISDICTION_SORTING_LINK = By.linkText("Jurisdiction");
	public static final By DS_AMOUNT_SORTING_LINK = By.linkText("DS Amount");
	public static final By ERROR_MESSAGE = By.id("ctlErrorBox_valSummary");
	public static final By BACK_TO_INVOICE_BTN_TOP = By.id("btnBackToInvoiceListTop");
	public static final By BACK_TO_INVOICE_BTN_BOTTOM = By.id("btnBackToInvoiceListBottom");
	
	
	//Invoice Exception
	public static final By INVOICE_EXCEPTION_SEARCH = By.xpath("//a[contains(text(), 'Invoice Exception Search')]");
	public static final By INVOICE_EXCEPTION_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Invoice Exceptions Search')]");

	public static final By RENEWAL_INVOICE_SEARCH_PAGE = By.xpath("//span[contains(text(), 'Renewal Invoice Search')]");
	public static final By SERVICE_CENTRE = By.xpath("//select[@id='lstServiceCenter']/option[contains(text(), 'CT Corporation Team 1')]");
	public static final By SERVICE_TEAM = By.xpath("//select[@id='lstServiceTeam']/option[contains(text(), 'Corporation Team')]");
	public static final By INVOICE_EXCEPTION_PAGE = By.xpath("//span[contains(text(), 'Invoice Exceptions')]");
	public static final By RENEWAL_INVOICE_EXCEPTION_TAB = By.xpath("//td[contains(text(), 'Renewal Invoice Exceptions')]");
	public static final By EXCEPTION_REASON = By.xpath("//td[contains(text(), 'Exception Reason')]");
	public static final By REINVOICE_BUTTON = By.id("grdData_ctl02_btnReinvoice");
	public static final By ERROR_MSG_FOR_EXCEPTION = By.xpath("//li[contains(text(), 'Select a value for Service Center.')]");

	//Field on Affected Invoices Page
	public static final By PARTICIPANT_NAME_ON_GRID = By.id("grdNewInvoiceData_ctl02_pnlRecipientName");

	
}
