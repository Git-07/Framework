package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Reports {

	//Reports Page
	public static final By REPORTS_PAGE_TITLE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][text()='Reports']");
	public static final By REPORTS_LINK = By.xpath("//a[contains(text(), 'Reports')]");
	public static final By REQUEST_REPORT_LINK = By.xpath("//a[contains(text(), 'Request Report')]");
	public static final By CREATE_NEW_BUTTON = By.id("btnCreateNew");
	
	//GRID DATA
	public static final By REPORTS_FIRST_ROW_REQUESTED_DATE_DATA = By.xpath("//span[@id='grdData_ctl02_lblRequestedDate']");
	public static final By REPORTS_FIRST_ROW_NAME_DATA = By.xpath("//span[@id='grdData_ctl02_lblName']");
	public static final By REPORTS_FIRST_ROW_DESCRIPTION_DATA = By.xpath("//span[@id='grdData_ctl02_lblDescription']");
	public static final By REPORTS_FIRST_ROW_REQUESTED_BY_DATA = By.xpath("//span[@id='grdData_ctl02_lblRequestedBy']");
	public static final By REPORTS_FIRST_ROW_STATUS_DATA = By.xpath("//span[@id='grdData_ctl02_lblStatus']");
	public static final By REPORTS_FIRST_ROW_DELETE_BUTTON = By.id("grdData_ctl02_btnDelete");
	public static final By NO_RECORDS_FOUND_GRID_MSG = By.xpath("//span[@id='ctlNoRecordsBar_lblNoRecords'][text()='No reports found.']");
	
	//Create New Report - Step 1 Page
	public static final By CREATE_NEW_REPORTS_STEP1_PAGE_TITLE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][text()='Create New Report - Step 1']");
	public static final By NAME_TEXTBOX = By.id("txtName");
	
	//Create New Report - Step 2 Page
	public static final By CREATE_NEW_REPORTS_STEP2_PAGE_TITLE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][text()='Create New Report - Step 2']");
	public static final By SELECT_BUTTON = By.id("61009_btnSelect");
	public static final By REGULAR_RADIO_BUTTON = By.id("61001_rdoRegular");
	public static final By RECURRING_RADIO_BUTTON = By.id("61001_rdoRecurring");
	
	//Find Entity/Affiliation Page
	public static final By FIND_ENTITY_AFFILIATION_PAGE_TITLE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][text()='Find Entity/Affiliation']");
	public static final By PICK_AFFILIATION_PAGE_TITLE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][text()='Pick Affiliation']");
	public static final By PICK_ENTITY_PAGE_TITLE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][text()='Pick Entity']");
	public static final By ENTITY_RADIO_BUTTON = By.id("rdoCaseEntity");
	public static final By FIND_BUTTON = By.id("btnFind");
	
	//Description Drop down
	public static final By SOP_VOLUMES_REPORT_DESCRIPTION = By.xpath("//select[@id='drpDescription']//option[contains(text(), 'SOP Volumes Report')]");
	public static final By PAPERLESS_SOP_CONVERSION_REPORT_DESCRIPTION = By.xpath("//select[@id='drpDescription']//option[contains(text(), 'Paperless SOP Conversions Report')]");
	
	//Owning Service Drop Down
	public static final By CT_CORPORATE_DEMO_TEAM_OWNING_SERVICE = By.xpath("//select[@id='61017_drpSelectControl']//option[contains(text(), 'CT Corporate Demo Team')]");
	
	public static final By GENERATE_REPORT_BUTTON = By.id("btnGenerateReport");	
	
}
