package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class SopCommonAlerts {

	public static final By COMMON_ALERTS_LINK = By.xpath("//a[contains(text(), 'Common Alerts')]");
	public static final By COMMON_ALERTS_PAGE = By.xpath("//span[@id='ctlPageTitle_lblTitle'][contains(text(), 'Common Alerts')]");
	public static final By MAINTAIN_COMMON_ALERTS_BUTTON = By.id("btnMaintainCommonAlerts");
	
	//Error Message
	public static final By ENTITY_AFFILIATION_ERROR = By.xpath("//li[contains(text(), 'Select a value for Entity or Affiliation.')]");
	public static final By SPECIAL_CIRCUMSTANCE_OR_LAWSUIT_ERROR  = By.xpath("//li[contains(text(), 'Either Special Circumstances or Lawsuit Type is required.')]");
	public static final By ALERT_TEXT_ERROR = By.xpath("//li[contains(text(), 'Enter a value for Alert Text.')]");
	
	public static final By ENTITY_RADIO_BUTTON = By.id("rdoCaseEntity");
	public static final By AFFILIATION_RADIO_BUTTON = By.id("rdoCaseAffiliation");
	public static final By SPECIAL_CIRCUMSTANCES = By.xpath("//select[@name='drpSpecialCircum']/option[2]");
	public static final By LAWSUITE_TYPE = By.xpath("//select[@name='drpLawsuitType']/option[2]");
	public static final By JURISDICTION_SPECIFIC_RADIO_BUTTON = By.id("rdoSpecificJurisdictions");
    public static final By US_STATE_RADIO_BUTTON = By.id("ctlJurisdictionTypeCtrl_rblState_0");
	public static final By UNSELECTED_JURISDICTION = By.xpath("//select[@id='ctlJurisdictionTypeCtrl_lbState']/option[contains(text(), 'Alabama')]");
	public static final By SELECTED_JURISDICTION = By.xpath("//select[@id='ctlJurisdictionTypeCtrl_lbSelectedItems']/option[contains(text(), 'Alabama')]");

	public static final By ADD_LINK = By.id("ctlJurisdictionTypeCtrl_lnkAdd");
	public static final By REMOVE_LINK = By.id("ctlJurisdictionTypeCtrl_lnkRemove");

	public static final By ALERT_TEXT_BOX = By.id("txtAlert");
	public static final By START_DATE = By.id("ctrlDateSelectorStartDate_txtDate");
	public static final By COMMON_MISTAKE_ALERTS_PAGE = By.xpath("//span[contains(text(), 'Common SOP Mistakes Alerts')]");

}
