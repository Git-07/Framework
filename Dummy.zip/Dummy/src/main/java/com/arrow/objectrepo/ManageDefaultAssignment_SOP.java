package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class ManageDefaultAssignment_SOP {
	
	//Fields On Manage SOP Default Assignment Page
	public static final By FIRST_EDIT_BTN_ON_GRID = By.id("grdData_ctl02_lnkEdit");
	public static final By JURIS_DRPDWN = By.id("ctlJurisSelector_lstJurisdictions");
	public static final By ADD_NEW_BTN = By.id("btnAddNew");
	public static final By SOP_SOURCE_TEXTBOX = By.id("txtSopSource");
	public static final By RECEIVED_BY_FACILITY_DRPDWN = By.id("drpReceivedByFacility");
	public static final By DEFAULT_RECEIVED_BY_TEAM_DRPDWN = By.id("drpReceivedByTeam");
	public static final By DEFAULT_ASSIGNED_TEAM_DRPDWN = By.id("drpDefaultAssignedTeam");
	public static final By SORT_BY_SOP_SOURCE_LINK = By.linkText("SOP Source");
	public static final By FIRST_DELETE_BTN_ON_GRID = By.id("grdData_ctl02_lnkDelete");

}
