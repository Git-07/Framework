package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Campaign {
	// Campaign Module Link
	public static final By CAMPAIGN_LINK = By.linkText("Campaign");

	// Fields on left nav bar in Target Search - Representation page
	public static final By TARGET_SEARCH_ON_DEMAND_LINK = By.linkText("On Demand");
	public static final By MANAGE_CAMPAIGN_LINK = By.linkText("Manage Campaign");

	// Create New Campaign button on Manage Campaign page
	public static final By VIEW_TRACKING_LINK = By.id("grdData_ctl02_lnkCampaignTracking");
	public static final By EDIT_CAMPAIGN_LINK = By.id("grdData_ctl02_lnkEditCampaign");
	public static final By CREATE_NEW_CAMPAIGN_BTN = By.id("btnCreateNewCampaign");

	// Fields on View Tracking Page
	public static final By DELIVERABLES_LINK = By.id("grdCampignTracking_ctl02_lnkViewDeliverables");
	public static final By CUSTOMER_NAME_TEXTFIELD = By.id("txtCustomerName");
	public static final By SEARCH_BTN = By.id("btnSearch");

	// Fields on Create Campaign page
	public static final By CAMPAIGN_NAME_TEXTFIELD = By.id("txtCampaignName");
	public static final By FIRST_REMINDER_TEXTFIELD = By.id("txtFirstReminder");
	public static final By SECOND_REMINDER_TEXTFIELD = By.id("txtSecondReminder");

	// Common fields
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By CANCEL_BTN = By.id("btnCancel");
	public static final By SAVE_BTN = By.id("btnSave");

	// Fields on Target Search Page
	//public static final By APPLE_SELECT_EXISTING_CAMPAIGN_DROPDOWN = By
	//		.xpath("//select[@id='ddlExistingTarget']//option[contains(text(), 'apple')][1]");
	public static final By CHANGE_SELECT_EXISTING_CAMPAIGN_DROPDOWN = By
					.xpath("//select[@id='ddlExistingTarget']//option[contains(text(), '614 First 500 Recipietns Entities')]");
	public static final By CLONE_BTN = By.id("btnClone");
	public static final By SERVER_ERROR = By.xpath("//h1[contains(text(), 'Server Error')]");
	public static final By SAVE_AND_SEARCH_BTN = By.id("btnBottomSaveSearch");
	public static final By SELECT_CAMPAIGN_DRPDWN = By.id("ddlCampaignType");
	public static final By VIEW_COUNT_DETAILS_LINK = By.id("btnviewcount");
	public static final By SCHEDULE_CAMPAIGN_TO = By.id("txtScheduleToFirst");
	public static final By CAMPAIGN_SCHEDULE_DATE_CALENDAR = By.id("ctlCampaignScheduleDate_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By SCHEDULE_CAMPAIGN_TARGET_BTN = By.id("btnScheduleCampaign");
	public static final By FIRST_CAMPAIGN_TARGET_NAME = By.id("grdData_ctl02_lnkCampaignTargetName");
	public static final By SECOND_CAMPAIGN_TARGET_NAME = By.id("grdData_ctl03_lnkCampaignTargetName");
	public static final By EMAIL_OPT_OUT_BTN = By.id("btnEmailOptOut");
	public static final By EMAIL_OPT_OUT_ERR_MSG = By
			.xpath("//li[contains(text(), 'Please select at least one record for Email Opt-Out.')]");
	public static final By ON_DEMAND_LINK = By.linkText("On Demand");
	public static final By SELECT_EXISTING_CAMPAIGN_DROPDOWN = By.id("ddlExistingTarget");
	public static final By TOP_SAVE_AND_SEARCH_BTN = By.id("btnTopSaveSearch");
		
	public static final By CHANGE_SELECT_EXISTING_CAMPAIGN = By.id("ddlExistingTarget");
	public static final By RESULTED_RECIPIENTS = By.id("lblResultedRecipients");
    public static final By SELECTED_CAMPAIGN = By.xpath("//select[@id='ddlCampaignType']//option[@selected='selected']");	
    public static final By SCHEDULED_CAPMAIGN_ERROR  = By.xpath("//li[contains(text(),'This Campaign Search Target has scheduled Campaign, the search criteria can not be edited and saved')]");	

}
