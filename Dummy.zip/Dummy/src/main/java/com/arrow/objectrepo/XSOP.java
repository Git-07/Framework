package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class XSOP {

	//Invoice Search Page
	public static final By XSOP_INVOICE_SEARCH = By.xpath("//a[contains(text(), 'XSOP Invoice Search')]");
	public static final By XSOP_INVOICE_SEARCH_PAGE = By.xpath("//span[contains(text(), 'XSOP Invoice Search Criteria')]");

	public static final By INVOICE_STATUS = By.xpath("//select[@name='lstInvoiceStatus']/option[contains(text(), 'Open')]");
	public static final By XSOP_INVOICE_RESULT_PAGE = By.xpath("//span[contains(text(), 'XSOP Invoice Search Results')]");
	
	//XSOP Profile and Review
	public static final By XSOP_PROFILE = By.xpath("//span[contains(text(), 'XSOP Invoice Profile')]");
	public static final By ORDER_PREVIEW_PAGE = By.xpath("//span[contains(text(), 'Order Preview')]");
	
	public static final By MAIL_TO_RECIPIENT_DROPDOWN = By.xpath("//select[@id='drpDeliveryMethod']/option[contains(text(), 'Mail to Recipient')]");
	public static final By AFF_MAINTENANCE_DROPDOWN = By.xpath("//select[@id='drpRevisionReason']/option[contains(text(), 'Affiliation Maintenance')]");

	//Dropdown
	public static final By INVOICE_ID_DROPDOWN = By.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'Invoice #')]");
	
	//Revised
	public static final By REVISED_REASON = By.xpath("//span[contains(text(), 'Revision Reason: Affiliation Maintenance')]");
	
}
