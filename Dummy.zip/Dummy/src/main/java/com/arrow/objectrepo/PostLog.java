package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class PostLog {

		//Un-Posted Logs - Attempted
		public static final By UNPOSTED_LOG = By.xpath("//a[contains(text(), 'Un-Posted Logs')]");
		public static final By UNPOSTED_LOG_TITLE = By.xpath("//span[contains(text(), 'Un-Posted Logs')]");
		public static final By LOG_ID = By.id("grdUnpostedLog_ctl02_lnkLogID");
		public static final By ATTEMPTED_RADIO_BUTTON = By.id("rdoAttemptedYes");
		public static final By ATTEMPTED_DISPLAYED = By.xpath("//span[@id='lblAttempted'][contains(text(), 'Yes')]");
		public static final By CHOOSE_DI = By.id("btnChooseDI");
		public static final By POST_STATUS = By.id("lblPostStatus");
		public static final By POSTED_DATE = By.xpath("//span[@id='lblPostDate'][contains(text(), '2021')]");
		public static final By WORKSHEET_PROFILE = By.xpath("//a[contains(text(), 'Worksheet Profile')]");		
}
