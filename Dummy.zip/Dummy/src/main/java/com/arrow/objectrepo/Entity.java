package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Entity {

	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By ENTITY_PROFILE_PAGE = By.xpath("//span[contains(text(), 'Entity Profile')]");
	public static final By INACTIVE_PROFILE_STATUS = By.xpath("//span[contains(text(), 'Inactive')]");
	public static final By SELECT_PARTICIPANT_PAGE = By.xpath("//span[contains(text(), 'Select Recipient')]");
	public static final By SELECT_PARTICIPANT_BUTTON = By.xpath("//img[@src='/public/images/btn_Select.gif']");
	public static final By ENTITY_SEARCH_RESULTS_PAGE = By.xpath("//span[contains(text(), 'Entity Search Results')]");
	public static final By CONFIRM_QUIT_AFFLN_PAGE = By
			.xpath("//span[contains(text(), 'Confirm Quitting the Affiliation')]");
	public static final By FIND_DI_RECIPIENT_PAGE = By.xpath("//span[contains(text(), 'Find DI Recipient')]");
	public static final By CUSTOMER_NAME_TEXT = By.id("txtCustomerName");
	public static final By SERVICE_CENTER = By.id("lblServiceCenter");
	public static final By ACCOUNT_SEARCH_LINK = By.linkText("Account Search");


	// Elements on Entity Search Criteria page

	public static final By ENTITY_LINK_TOPNAV = By.xpath("//img[@alt='Entity']");
	public static final By ENTITY_ID = By.id("txtEntityNumber");
	public static final By ENTITY_NAME = By.id("txtEntityName");
	public static final By SEARCH_BTN = By.id("btnSearch");
	public static final By CREATE_ENTITY_BTN = By.id("btnCreateEntity");
	public static final By INCLUDE_INACTIVE_ENTITIES_BTN = By.id("chkIncInactiveCompanies");
	public static final By INCLUDE_STAFFING_ENTITIES_BTN = By.id("chkIncStaffingEntities");
	public static final By INCLUDE_ALL_REP_BTN = By.id("chkIncludeAllRepresentationJrisdiction");

	public static final By ENTITY_ID_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Entity #')]");
	public static final By NAME_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Name')]");
	public static final By TYPE_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Type')]");
	public static final By AFFILIATON_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Affiliation')]");
	public static final By DOMESTICJURIS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Domestic Juris')]");
	public static final By TEAM_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Team')]");
	public static final By STATUS_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Status')]");
	public static final By STAFFING_ENTITY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Staffing Entity')]");
	public static final By GENERIC_CD_ENTITY_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Generic CD Entity')]");
	public static final By BRANCH_PLANT_DRPDWN = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstF')]//option[contains(text(), 'Branch Plant')]");
	public static final By FIRST_PAGE_LINK = By.linkText("First");
	public static final By PREVIOUS_PAGE_LINK = By.linkText("Previous");
	public static final By PAGE_11__20_LINK = By.linkText("11-20");
	public static final By NEXT_PAGE_LINK = By.linkText("Next");
	public static final By LAST_PAGE_LINK = By.linkText("Last");
	public static final By NAME_SORT = By.xpath("//span[contains(text(), 'Name')]");
	public static final By TYPE_SORT = By.linkText("Type");
	public static final By AFFILIATION_SORT = By.linkText("Affiliation");
	public static final By DOMESTIC_JURIS_SORT = By.linkText("Domestic Juris");
	public static final By TEAM_SORT = By.linkText("Team"); 	
	public static final By BRANCH_PLANT_SORT = By.linkText("Branch Plant");
	public static final By STATUS_SORT = By.linkText("Status");
	public static final By STAFFING_ENTITY_SORT = By.linkText("Staffing Entity");
	public static final By GENERIC_CD_ENTITY_SORT = By.linkText("Generic CD Entity");
	public static final By RHS_FILTER = By.id("ctlFilterBar_lstRHS");
	public static final By GO_BTN = By.id("ctlFilterBar_btnGo");
	public static final By DEAD_END_ISTRUCTIONS_RHS_FILTER = By
			.xpath("//*[contains(@id,'ctlFilterBar_lstRHS')]//option[contains(text(), 'Dead End Instructions')]");

	// Left Links
	public static final By ENTITY_PRICING = By.linkText("Pricing Details");

	// Records in grid
	public static final By FIRST_ENTITY_IN_GRID = By.id("grdData_ctl02_lnkName");

	// Fields on Entity Profile page and Edit Entity Profile Page
	public static final By JOIN_AFFILIATION_BTN = By.id("btnJoinAffiliation");
	public static final By QUIT_AFFILIATION_BTN = By.id("btnQuitAffiliation");
	public static final By DISABLED_QUIT_AFFILIATION_BTN = By.id("btnQuitAffiliation");
	public static final By ENTITY_ID_ON_ENTITY_PROFILE = By.id("ctlContextBar_lblContextId");
	public static final By ENTITY_NAME_ON_ENTITY_PROFILE = By.id("ctlContextBar_lblContextTitle");
	public static final By ALERTS_FOR_ENTITY_LINK = By.id("lnkAlert");
	public static final By ENTITY_EDIT = By.id("ctlPageTitle_btnEdit");
	public static final By ENTITY_TYPE = By.id("lblEntityType");
	public static final By FISCAL_YEAR_END = By.id("lblYearEnd");
	public static final By FEDERAL_ID_EDIT = By.id("txtFederalID");
	public static final By FEDERAL_ID_ERR_MSG = By.xpath("//div[@id='ctlErrorBox_valSummary']/ul/li");
	public static final By FEDERAL_ID = By.id("lblFederalID");
	public static final By AFFILIATION_NAME = By.id("lnkAffiliation");
	public static final By DEAD_END_BTN = By.id("btnDeadEnd");
	public static final By STATUS_ON_ENTITY_PROFILE = By.id("ctlStatusBar_lblStatusText");
	public static final By UPDATE_INVOICE_BTN = By.id("btnUpdateInvoice");
	public static final By GENERATE_RENEWAL_ESTIMATE_BTN = By.id("btnGenerateRnwlEstimate");
	public static final By ANNUAL_INVOICE_FOR_STATUTORY_REPRESENTATION_ESTIMATE_TEXT = By
			.xpath("//div[contains(text(), 'Annual Invoice for')]");

	public static final By REVERSE_DEAD_END_BTN = By.id("btnReverseDeadEnd");
	public static final By BUNDLE_NAME = By.id("lblName");
	public static final By PLUS_DISBURSEMENTS = By.id("lblPlusDisbursements");
	public static final By ASSUMED_NAMES_VALUE = By.id("lblAssumActiveNo");
	public static final By SALES_ASSIGNMENT_CHECKBOX = By.id("chkSalesAssignment");
	public static final By SALES_ASSIGNMENT_DROPDOWN = By.id("drpListSalesAssignment");
	public static final By SALES_ASSIGNMENT_VALUE = By.id("lblSalesAssignment");
	public static final By APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_IMAGE_BTN = By.id("btnApplyRecipients");
	public static final By EM_PREFERENCE_FOR_NEW_REP_VALUE = By.id("lblEmStatus");

	// Fields on Entity Left nav links
	public static final By ALERTS = By.linkText("Alerts");
	public static final By MYEXPIRINGALERTS = By.linkText("My Expiring Alerts");
	public static final By COMMENT = By.linkText("Comments");
	public static final By DELIVERY_INSTRUCTIONS = By.linkText("Delivery Instructions");
	public static final By DI_HISTORY = By.linkText("DI History");
	public static final By ENTITY_PROFILE = By.linkText("Entity Profile");
	public static final By ENTITY_SEARCH = By.linkText("Entity Search");
	public static final By ENTITY_PROFILE_TAB = By.linkText("Entity Profile");
	public static final By RENEWAL_INVOICE_LEFT_NAV_LINK = By.linkText("Renewal Invoices");
	public static final By REFERRALS_LEFT_NAV_LINK = By.linkText("Referrals");
	public static final By REVISIONS_LEFT_NAV_LINK = By.linkText("Revisions");
	public static final By XSOP_INVOICES_LEFT_NAV_LINK = By.linkText("XSOP Invoices");
	public static final By OFFICER_DIRECTOR_SEARCH = By.linkText("Officer / Director Search");

	// Fields on Edit Entity Information Page
	public static final By ENTITY_TYPE_DRPDWN = By.id("drpListEntityTypes");
	public static final By JANUARY_FISCAL_YEAR_END_DRPDWN = By
			.xpath("//select[@id='drpListFiscalYearEnd']//option[contains(text(), 'January')]");
	public static final By COMMENTS = By.id("txtComments");
	public static final By SAVE_BTN = By.id("btnSave");
	public static final By LLC_ENTITY_TYPE = By
			.xpath("//select[@id='drpListEntityTypes']/option[contains(text(), 'Limited Liability Company')][1]");
	public static final By LLP_ENTITY_TYPE = By
			.xpath("//select[@id='drpListEntityTypes']/option[contains(text(), 'Limited Liability Partnership')]");
	public static final By LP_ENTITY_TYPE = By
			.xpath("//select[@id='drpListEntityTypes']/option[contains(text(), 'Limited Partnership')]");
	public static final By REPARMS_BUNDLE_BUNDLE_DRPDWN = By
			.xpath("//select[@id='drpBundle']//option[contains(text(), 'REPARMS Bundle(Bundle)')]");
	public static final By PLUS_DISBURSEMENTS_CHECKBOX = By.id("chkPlusDisbursements");
	public static final By REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN = By
			.xpath("//select[@id='drpBundle']//option[contains(text(), 'REP and Annual Report(Bundle)')]");
	public static final By EFFECTIVE_START_DATE_CALENDAR = By.id("ctrlStartDateSelector_btnCal");
	public static final By DS_EFFECTIVE_START_DATE_CALENDAR = By.id("ctrlDisEffectiveStartDate_btnCal");

	// Fields on Comments Screen Page
	public static final By COMMENT_SCREEEN_EXPORT_BUTTON = By.id("imgExport");
	public static final By AUTHOR_SORTBY_LINK = By.linkText("Author");
	public static final By AUTHOR_SORTBY_LINK_BOLD = By
			.xpath("//span[@class='sortBy']//span[contains(text(), 'Author')]");

	// Fields On Create Entity Page 1
	public static final By BRANCH_PLANT_CREATE_ENTITY = By.id("drpBusinssUnits");
	public static final By TRUE_NAME = By.id("txtTrueName");
	public static final By DOMESTIC_JURIS_DRPDWN = By.id("ctlJurisSelector_lstJurisdictions");
	public static final By ENTITY_TYPE_CREATE_ENTITY = By.id("drpEntityType");
	public static final By PARTCIPANT_SELECT_BTN = By.id("ctlBulletin_imgFind");
	public static final By PARTICIPANTNAMEFIELD = By.id("txtParticipantName");
	public static final By FINDBTN = By.id("btnFind");
	public static final By TABLEID = By.id("grdData");
	public static final By SELECTRECIPIENTBTN = By.id("grdData_ctl02_lnkSelect");
	public static final By APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN = By.id("imgApplyRecipients");
	public static final By NEXT_BTN = By.id("btnNext");
	public static final By FEDERAL_ID_TEXTBOX = By.id("txtFederalID");
	public static final By ENTITY_REF1_TEXTBOX = By.id("txtEntityRef1");
	public static final By ENTITY_REF2_TEXTBOX = By.id("txtEntityRef2");
	public static final By CLIENT_CONTACT_MINUS_ICON = By.id("ctlClientContactIDSel_imgSelect");
	public static final By PARTICIPANT_NAME_SEARCH_TEXTBOX = By.id("txtName");
	public static final By CLIENT_CONTACT_PARTICIPANT_SEARCH_FRAME = By.id(
			"RadWindowContentFramectlClientContactIDSel_dlgParticipantSelector_rwm_ctlClientContactIDSel_dlgParticipantSelector");
	public static final By PARTCIPANT_SELECT_BTN_ON_FRAME = By.id("grdData_ctl02_lnkSelect");
	public static final By CLIENT_CONTACT_VALUE = By.xpath("//input[@value ='Mital Patel (9951234)']");
	public static final By CENTRALIZED_TEAM_ENABLED_CHECKBOX = By.id("chkoffsite");
	public static final By ATTORNEY_OF_RECORD_MINUS_ICON = By.id("ctlAttorneyIDSel_imgSelect");
	public static final By ATTORNEY_OF_RECORD_PARTICIPANT_SEARCH_FRAME = By.id(
			"RadWindowContentFramectlAttorneyIDSel_dlgParticipantSelector_rwm_ctlAttorneyIDSel_dlgParticipantSelector");
	public static final By BULLETIN_PARTICIPANT_TITLE = By.id("ctlBulletin_lblTitle");
	public static final By COMM_PARTCIPANT_SELECT_BTN = By.id("ctlCommunication_imgFind");
	public static final By COMM_PARTICIPANT_TITLE = By.id("ctlCommunication_lblTitle");
	public static final By RENEWAL_INVOICE_PARTCIPANT_SELECT_BTN = By.id("ctlRenewalInvoice_imgFind");
	public static final By RENEWAL_INVOICE_COMM_PARTICIPANT_TITLE = By.id("ctlRenewalInvoice_lblTitle");
	public static final By SOP_PARTCIPANT_SELECT_BTN = By.id("ctlSOP_imgFind");
	public static final By SOP_COMM_PARTICIPANT_TITLE = By.id("ctlSOP_lblTitle");
	public static final By XSOP_PARTCIPANT_SELECT_BTN = By.id("ctlXSOPInvoice_imgFind");
	public static final By XSOP_COMM_PARTICIPANT_TITLE = By.id("ctlXSOPInvoice_lblTitle");
	public static final By COMMENT_ON_ENTITY_CREATE = By.id("txtComment");
	public static final By INCLUDE_INACTIVE_PARTICIPANTS_BTN = By.id("chkIncludeInactiveParticipants");
	public static final By SEARCH_AGAIN_BTN = By.id("btnSearchAgain");

	// Fields On Create Entity Page 2
	public static final By JURISDICTION_DRPDWN = By.xpath(
			"//select[@id='ctlJurisSelectorRepresentationUnit_lstJurisdictions']//option[contains(text(), 'Alaska')]");
	public static final By SERVICE_TYPE_DRPDWN = By
			.xpath("//select[@id='drpServiceType']//option[contains(text(), 'Foreign Representation')]");
	public static final By SERVICE_TYPE_INDEPENDENT_DIRECTOR_DRPDWN = By
			.xpath("//select[@id='drpServiceType']//option[contains(text(), 'Independent Director / Manager Services')]");

	// Fields on Create Entity Page 3
	public static final By STATE_ID = By.id("txtStateId");
	public static final By CALENDAR = By.id("ctrlDateSelectorFiling_btnCal");
	public static final By CALENDAR_APPOINTED = By.id("ctrlDateSelectorAppointed_btnCal");
	public static final By FILING_DATE = By.id("ctlFilingDate_btnCal");
	public static final By REQUEST_DATE = By.id("ctlRequestDate_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By DESCRIPTION_TEXT = By.id("txtDescription");
	public static final By OFFICER_DIRECTOR_SELECT_BTN = By.id("btnSelect");
	public static final By EMPLOYEE_NAME = By.id("txtEmployeeName");
	public static final By POSITION_DRPDWN = By.xpath(
			"//select[@id='drpPosition']//option[contains(text(), 'Asst. Secretary')]");
	public static final By ADD_UPDATE_BTN = By.id("btnAddUpdate");
	public static final By EDIT_BTN = By.id("grdData_ctl02_btnEdit");
	public static final By EDITED_POSITION_DRPDWN = By.xpath(
			"//select[@id='drpPosition']//option[contains(text(), 'Independent Manager')]");
	public static final By DELETE_BTN = By.id("grdData_ctl02_btnDelete");
	public static final By SELECT_ALL_BTN = By.id("btnSelectAll");
	public static final By REPLACE_DIRECTOR = By.id("btnReplaceDirector");
	public static final By REPLACE_BTN = By.id("btnReplace");
	public static final By POSITION_REPLACE_DRPDWN = By.xpath(
			"//select[@id='lstPosition']//option[contains(text(), 'Asst. Secretary')]");
	public static final By NEW_EMPLOYEE =By.xpath("//td[contains(text(), 'Madeleine Muth')]");
	
	// Fields on Find an Affiliation to Join Page
	public static final By AFFILIATION_NAME_SEARCH_TEXTBOX = By.id("txtName");

	// Fields on Pick the Affiliation to Join Page
	public static final By FIRST_RESULT_ON_PICK_AFFILAITION_PAGE = By.id("grdAffiliation_ctl02_imgViewnJoin");
	public static final By FIRST_VIEW_AND_JOIN_BUTTON_ON_GRID = By.id("grdAffiliation_ctl02_imgViewnJoin");

	// Fields on Confirm Joining the Affiliation Page
	public static final By BULLETINRETAINCURRENTDI = By.id("rdoRetainBulletinSG");
	public static final By COMMRETAINCURRENTDI = By.id("rdoRetainCommSG");
	public static final By RENEWALINVOICERETAINCURRENTDI = By.id("rdoRetainRenewalSG");
	public static final By SOPRETAINCURRENTDI = By.id("rdoRetainSOPSG");
	public static final By XSOPSUBGROUPDROPDWN = By.id("lstXSOP");
	public static final By COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION = By.id("ctlDIHistoryComment_txtComment");
	public static final By JOINBTN = By.id("btnJoin");
	public static final By NEW_AFFILIATION_NAME = By.id("ctlEntityContextBox_lblNewAffiliation");
	public static final By BULLETINSUBGROUPDROPDWN = By.id("lstBulletin");
	public static final By COMMSUBGROUPDROPDWN = By.id("lstComm");
	public static final By RENEWALINVOICESUBGROUPDROPDWN = By.id("lstRenewal");
	public static final By SOPSUBGROUPDROPDWN = By.id("lstSOP");

	// Fields on Confirming Quiting the Affiliation Page
	public static final By APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN_QUIT_AFFPAGE = By.id("btnApplyRecipients");
	public static final By QUIT_THE_AFFILIATION_BTN = By.id("btnQuitAffiliation");
	public static final By CANCEL_BTN = By.id("btnCancel");

	// Names
	public static final By ENTITY_NAME_LINK = By.xpath("//a[contains(text(), 'Names')]");
	public static final By ENTITY_NAME_PAGE = By.xpath("//span[contains(text(), 'Names')]");
	public static final By CREATE_ASSUMED_NAME_BTN = By.id("btnCreateAssumedName");
	public static final By CREATE_CROSSREFERENCE_NAME_BTN = By.id("btnMaintainCrossReference");
	public static final By CREATE_FORMER_NAME_BTN = By.id("btnCreateFormerName");
	public static final By CREATE_CROSSREFERENCE_PAGE = By
			.xpath("//span[contains(text(), 'Create Cross-Reference Name')]");
	public static final By CREATE_ASSUMEDNAME_PAGE = By.xpath("//span[contains(text(), 'Create Assumed Name')]");
	public static final By CREATE_FORMERNAME_PAGE = By.xpath("//span[contains(text(), 'Create Former Name')]");
	public static final By CROSSREFERENCE_TEXT = By.id("txtCrossRefName");
	public static final By ASSUMEDNAME_TEXT = By.id("txtAssumedName");
	public static final By FORMERNAME_TEXT = By.id("txtFormerName");
	public static final By TRUENAME_TEXT = By.id("txtTrueName");
	public static final By VIEW_TRUENAME_PAGE = By.xpath("//span[contains(text(), 'View True Name')]");
	public static final By VIEW_CROSSREFERENCE_PAGE = By.xpath("//span[contains(text(), 'View Cross-Reference Name')]");
	public static final By VIEW_ASSUMEDNAME_PAGE = By.xpath("//span[contains(text(), 'Assumed Names')]");
	public static final By VIEW_FORMERNAME_PAGE = By.xpath("//span[contains(text(), 'View Former Name')]");
	public static final By CHANGE_TRUENAME_PAGE = By.xpath("//span[contains(text(), 'Change True Name')]");
	public static final By RETURN_TO_NAME_LIST = By.id("btnReturnToNamesList");
	public static final By RETURN_TO_NAME = By.id("btnReturnToNames");
	public static final By EDIT_CROSSREFERENCE_PAGE = By.xpath("//span[contains(text(), 'Edit Cross-Reference Name')]");
	public static final By ASSUMED_NAME_TEXT = By.id("txtAssumedName");
	public static final By EDITED_ASSUMED_NAME_TEXT = By
			.xpath("//span[contains(text(), 'Edited-Assumed Name Text for Testing')]");
	public static final By EDIT_ASSUMED_NAME = By
			.xpath("//span[contains(text(),ctlEffectiveDate_btnCal 'Edit Jurisdiction Details')]");
	public static final By EDITED_FORMER_NAME = By
			.xpath("//span[contains(text(), 'Edited - Former Name Text for Testing')]");
	public static final By ENTITY_TRUE_NAME = By
			.xpath("//a[contains(text(), 'Entity - Former Name')]");
	public static final By EDITED_TRUE_NAME = By
			.xpath("//a[contains(text(), 'True Name Text for Testing')]");
	public static final By RADIO_QUALIFIED = By.id("rdoQualified");
	public static final By RADIO_VOLUNTARY = By.id("rdoVoluntary");
	public static final By CALCULATE_END_DATE = By.id("btnCalculateEndDate");
	public static final By END_DATE_TEXT = By.id("ctlEndDate_txtDate");
	public static final By DISCONTINUE_DATE = By.id("ctlDiscontinuanceDate_btnCal");
	public static final By EFFECTIVE_DATE = By.id("ctlEffectiveDate_btnCal");
	public static final By ADD_JURISDICTION = By.id("btnAddJurisdiction");
	public static final By JURISDICTION_PAGE = By.xpath("//span[contains(text(), 'Add Jurisdiction Details')]");
	public static final By NEW_HAMPSHIRE_JURISDICTION = By
			.xpath("//select[@id='ctlJurisSelector_lstJurisdictions']/option[contains(text(), 'New Hampshire')]");
	public static final By JURISDICTION_ERROR = By
			.xpath("//li[contains(text(), 'Already qualified in this Jurisdiction.')]");

	public static final By SORTBY_NAME_INACTIVE = By.id("//a[contains(text(), 'Effective Date')]");
	public static final By SORTBY_NAME_ACTIVE = By.id("//a[contains(text(), 'Effective Date')]");
	public static final By SORTBY_EFFECTIVE_DATE_INACTIVE = By.xpath("//a[contains(text(), 'Effective Date')]");
	public static final By SORTBY_EFFECTIVE_DATE_ACTIVE = By
			.xpath("//span[@class='sortBy']/a/span[contains(text(), 'Effective Date')]");
	public static final By SORTBY_NAMETYPE_INACTIVE = By.xpath("//a[contains(text(), 'Name Type')]");
	public static final By SORTBY_NAMETYPE_ACTIVE = By.xpath("//span[contains(text(), 'Name Type')]");

	// Fields on Confirm Reverse Dead-end Pgae
	public static final By COMMENTS_ON_CONFIRM_REVERSE_DEAD_END = By.id("ctlDIHistoryComment_txtComment");

	// Fields on Reinstate Multiple Representation Units Page
	public static final By EFFECTIVE_DATE_CALENDER_ICON_ON_REINSTATE_MULTIPLE_REP_UNITS_PAGE = By
			.id("ctrlDateSelectorReinstatementEffective_btnCal");
	public static final By REINSTATEMENT_REASON = By.id("lstReinstatementReason");
	public static final By SERVICE_TYPE_CHECKBOX = By.id("grdData_ctl02_chkSelector");
	public static final By REINSTATE_BTN = By.id("btnReinstate");
	public static final By REINSTATE_TITLE = By.xpath("//span[contains(text(), 'Reinstate Multiple Representation Units')]");

	// Fields on Confirm Dead-Ending the Entity.
	public static final By ACTIVE_REP_EXISTS_ERRMSG = By
			.xpath("//li[contains(text(), 'Active Rep exists. Discontinue all Rep in order to Dead-End.')]");
	public static final By ENTITY_IS_AFFILIATED_ERRMSG = By
			.xpath("//li[contains(text(), 'Entity is Affiliated. Quit all Affiliations in order to Dead-End.')]");
	public static final By CUSTOMER_SELECT_ERROR = By
			.xpath("//li[contains(text(), 'Enter at least 2 characters for Participant Name.')]");
	public static final By ENTITY_WITH_AFFILIATION_NAME = By.id("grdData_ctl02_lnkAffiliation");

	// Fields on Paper Surcharge Billing Details
	public static final By MAINTAIN_PAPER_SURCHAGE_BILLING = By.id("btnMaintainPaperSurchargeBilling");
	public static final By PAPER_SURCHARGE_BILLING = By.id("lblPaperSurchargeBilling");
	public static final By PAPER_SURCHARGE_BILLING_ENABLE = By.id("rdoEnable");
	public static final By PAPER_SURCHARGE_BILLING_DISABLE = By.id("rdoDisable");
	public static final By BACK_BUTTON = By.id("btnBack");
	public static final By ENTITY_HEADER = By.xpath("//img[@alt='Entity']");

	// Fields on Update Invoice Page
	public static final By BTDCALENDAR = By.id("ctrlDateSelectorBilledthroughDate_btnCal");
	public static final By UPDATE_BTN = By.id("btnUpdate");

	// Manage Entity Monitoring Notification Recipients
	public static final By MANAGE_ENTITY_MONITORING_NOTIFICATION_RECIPIENTS = By.id("imgManageEMNotifications");
	public static final By ADD_RECIPIENTS_BTN = By.id("btnAddRecipients");
	public static final By PARTICIPANT_NAME_CHECKBOX = By.id("grdData_ctl02_chkParticipant");
	public static final By SELECT_PARTICIPANTS_BTN = By.id("btnSelectParticipants");
	public static final By TURN_OFF_NOTIFICATION_BTN = By.id("btnTurnoffCOMMDIRecipient");
	public static final By REMOVE_BTN = By.id("grdData_ctl02_lnkRemove");
	public static final By NOTIFICATION_ERROR = By.xpath("//li[contains(text(), 'Turn-on notification to COMM DI recipient before removing all the recipients.')]");
	public static final By TURN_ON_NOTIFICATION_BTN = By.id("btnTurnoffCOMMDIRecipient");
	//public static final By NO_RECORDS_FOUND_TEXT = By.xpath("//span[@id='ctlNoRecordsBar_lblNoRecords']");
	public static final By NO_RECORDS_FOUND_TEXT = By.xpath("//span[contains(text(), 'No records found.')]");

	// PSOP Invoices on left navigation bar
	public static final By PSOP_INVOICES_LEFT_NAV_BAR = By.xpath("//a[contains(text(),'PSOP Invoices')]");
	public static final By PSOP_INVOICES_PROFILE_LEFT_NAV_BAR = By.className("leftNavRowLvl2Dis");
	public static final By PSOP_INVOICES_CONTEXTTILE = By.id("ctlContextBar_lblContextTitle");
	public static final By PSOP_INVOICES_DROP_DOWN = By.id("ctlFilterBar_lstF");
	public static final By PSOP_INVOICES_IS = By.id("ctlFilterBar_singleOperator");
	public static final By PSOP_INVOICES_TEXT_SEARCH = By.id("ctlFilterBar_txtRHS");
	public static final By PSOP_INVOICES_HELP_ICON = By.id("ctlPageTitle_lnkHelp");
	public static final By PSOP_INVOICES_SORT_BY = By.className("sortBy");
	public static final By PSOP_INVOICES_SORT_BY_INDEX = By.xpath("//span/a[contains(text(),'Invoice #')]");
	public static final By PSOP_INVOICES_SORT_BY_OW_ORDER = By.xpath("//span/a[contains(text(),'OW Order #')]");
	public static final By PSOP_INVOICES_SORT_BY_PRINT_DATE = By.xpath("//a/span[contains(text(),'Print Date')]");
	public static final By PSOP_INVOICES_SORT_BY_INVOICE_DATE = By.xpath("//span/a[contains(text(),'Invoice Date')]");
	public static final By PSOP_INVOICES_SORT_BY_INVOICE_AMOUNT = By.xpath("//span/a[contains(text(),'Inv. Amount')]");
	public static final By PSOP_INVOICES_SORT_BY_OPEN_AMOUNT = By.xpath("//span/a[contains(text(),'Open Amount')]");
	public static final By PSOP_INVOICES_GRID_HEADER_INVOICE = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'Invoice #')]");
	public static final By PSOP_INVOICES_GRID_HEADER_OW_ORDER = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'OW Order #')]");
	public static final By PSOP_INVOICES_GRID_HEADER_PRINT_DATE = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'Print Date')]");
	public static final By PSOP_INVOICES_GRID_HEADER_INVOICE_DATE = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'Invoice Date')]");
	public static final By PSOP_INVOICES_GRID_HEADER_INV_AMOUNT = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'Inv. Amount')]");
	public static final By PSOP_INVOICES_GRID_HEADER_PSOP_COUNT = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'PSOP Count')]");
	public static final By PSOP_INVOICES_GRID_HEADER_ACTION = By
			.xpath("//tr[@class='dataGrid2HeaderRow']//td[contains(text(),'Action')]");
	public static final By PSOP_INVOICES_CURRENT_FILTER = By.className("statusLabelBold");

	// Edit Entity Profile Page
	public static final By CHECK_BOX_SERVICE_CENTER = By.id("chkServiceCenter");
	public static final By DROP_DOWN_LIST_SERVICE_CENTER = By.id("drpListServiceCenter");
	public static final By DROP_DOWN_LIST_SERVICE_TEAM = By.id("drpListServiceTeam");

	// Renewal Invoices Page
	public static final By GET_FIRST_INVOICE_RENEWAL_DATE = By
			.xpath("//tbody//tr[2]//td[2]//table[1]/tbody/tr[1]//td[2]");
	public static final By GET_FIRST_INVOICE_LINK = By.id("grdData_ctl02_lnkInvoice");
	public static final By ALL_RENEWAL_INVOICES_TAB = By.linkText("All Renewal Invoices");
	public static final By EFFECTIVE_START_DATE = By.id("ctrlStartDateSelector_txtDate");
	public static final By EFFECTIVE_START_DATE_SUBGROUP_LEVEL = By.id("ctrlDateSelectorStartDate_txtDate");
	public static final By DISBURSEMENT_EFFECTIVE_START_DATE = By.id("ctrlDisEffectiveStartDate_txtDate");
	public static final By SECOND_FILTER_DROP_DOWN = By.id("ctlFilterBar_lstOp");
	public static final By SUB_GROUPS_LEFT_NAV_BAR = By.linkText("Sub Groups");
	public static final By SUB_GROUP_BUNDLE_MAINTENANCE = By.linkText("Sub Group Bundle Maintenance");
	public static final By INACTIVE_BUNDLE_SUB_GROUPS = By.id("lnkMaintainSubGroupBundle");
	public static final By LIST_OF_SUBGROUP_NAME = By
			.xpath("//tr[@class='dataGrid2HeaderRow']/following-sibling::tr/td[2]/table/tbody/tr[1]");
	public static final By GRID_CHECK_BOX_SELECTOR = By
			.xpath("//tr[@class='dataGrid2HeaderRow']/following-sibling::tr/td[1]/input");
	public static final By REVISION_PREVIEW_BUTTON = By.id("btnRevisionPreview");
	public static final By ENTITY_NAME_LINK_INVOICE_PROFILE = By.id("lnkEntity");
	public static final By SUBGROUP_NAME_LINK_INVOICE_PROFILE = By.id("lnkSubgroup");
	public static final By FIRST_INVOICE_IN_NEW_INVOICES_GRID = By.id("grdNewInvoiceData_ctl02_lnkID");
	public static final By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By
			.xpath("//td[contains(text(),'Annual Report Renewal Disbursements')]");

	// Representation
	public static final By REPRESENATION_LEFT_NAV_LINK = By.linkText("Representation");
	public static final By FIRST_DROP_DOWN = By.id("ctlFilterBar_lstF");
	public static final By DISCONTINUE_BUTTON = By.id("btnDiscont");
	public static final By FILING_DATE_FOR_DISCONTINUE = By.id("ctrlDateSelectorDiscontinuanceFiling_txtDate");
	public static final By DISCONTINUE_REASON_DROP_DOWN = By.id("drpListDiscontTypes");
	public static final By DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT = By.id("btnDiscontinue");
	public static final By REP_FILING_DATE = By.id("lblFilingDt");

	// Fields on xsop invoices page
	public static final By ESTIMATE_EXCESSS_SOP_TEXT = By.xpath("//div[contains(text(), 'Excess Service of Process')]");
	public static final By GENERATE_CURRENT_ESTIMATE_BTN = By.id("btnGenerateCurrentEstimate");

    //Edit Entity Profile
    public static final By RENEWAL_MONTH_EDIT_ENTITY = By.id("drpListRenewalMonth");
    public static final By SELECTED_RENEWAL_MONTH = By.xpath("//select[@id='drpListRenewalMonth']//option[@selected='selected']");
    
    //Revenue Summary
    public static final By VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON = By.id("rdoViewRevenueYear");
    public static final By VIEW_REVENUE_FOR_YEAR_TEXT_BOX = By.id("txtViewRevenueYear");
    public static final By CALCULATE_REVENUE_BUTTON = By.id("btnCalculate");
    public static final By GROSS_REP_AMOUNT = By.id("lblGrossRepAmount");
    public static final By VIEW_REVENUE_DETAILS_BUTTON = By.id("btnViewRevenueDetails");
    public static final By GROSS_REP_AMOUNT_REVENUE_DETAILS = By.xpath("//td[contains(text(),'Gross Rep Amount :')]/following-sibling::td[@class='dataText']");

    //Delivery Instruction in Entity
    public static final By RENEWAL_EDIT_BUTTON  = By.id("imgRenewalEdit");
    public static final By DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT = By.id("ctlRecipient_imgFind");
    public static final By AUTO_RENEW_RADIO_BUTTON = By.id("rdoBtnAutoRenew_0");
    public static final By RENEWAL_DI_DELIVERY_METHOD = By.id("ctlRenewalDI_lblDeliveryMethod");
    public static final By AUTO_RENEW_STATUS = By.id("ctlRenewalDI_trAutoRenew");
    
    //Account Search
	public static final By ACCOUNT_NAME = By.id("txtName");
	public static final By EXPORT_BUTTON = By.id("ctlPageTitle_btnExport");
	public static final By FIRST_RESULT_FROM_GRID = By.id("ctl00_lblHQName");
    public static final By KEYWORD_RADIO_BTN = By.id("rdoKeyword");
    public static final By FIRSTFILTER_DROP_DOWN = By.id("drpFilter");
    public static final By SECONDFILTER_DROP_DOWN = By.id("drpBusinssUnits");
    public static final By GOBTN = By.id("btnGo");


}
