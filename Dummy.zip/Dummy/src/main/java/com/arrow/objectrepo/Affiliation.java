package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class Affiliation {
	public static final By AFFILIATIONID = By.id("txtID");
	public static final By AFFILIATIONNAME = By.id("txtName");
	public static final By SEARCHBTN = By.id("btnSearch");
	public static final By CREATEAFFILIATIONBTN = By.id("btnCreate");
	public static final By AFFLN_SEARCH_CRITERIA = By.xpath("//span[contains(text(), 'Affiliation Search Criteria')]");
	public static final By SEARCH_AFFLN_PAGE = By.xpath("//span[contains(text(), 'Affiliation Search Results')]");
	public static final By AFFLN_PROFILE = By.xpath("//span[contains(text(), 'Affiliation Profile')]");
	public static final By FIRST_AFFILIATION_ON_GRID = By.id("grdData_ctl02_lnkProfile");
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");

	
	// Fields on Create Affiliation page
	public static final By BRANCHPLANTDRPDWN = By.id("drpBusinessUnits");
	public static final By NAMEFIELD = By.id("txtAffiliationName");
	public static final By SALESASSGNMNTDRPDWN = By.id("drpListDSA");
	public static final By LAWFIRMDRPDWN = By.id("drpLawFirm");
	public static final By COMMONRENEWALDRPDWN = By.id("lstRenewalMonth");
	public static final By SUBGROUPNAMEFIELD = By.id("txtXSOP");
	public static final By SELECTBTN = By.id("ctlRecipient_imgFind");
	public static final By COMMENTFIELD = By.id("txtComments");
	public static final By CUSTOMER_REQUESTED_NO_COMMON_RENEWAL_MONTH_RADIO_BUTTON = By.id("rdoNoRenewalMonth");
	public static final By SAVEBTN = By.id("btnSave");
	public static final By CANCELBTN = By.id("btnCancel");
	public static final By ERROR_BRANCH_PLANT = By.xpath("//li[contains(text(), 'Select a value for Branch Plant.')]");
	public static final By ERROR_AFFILIATION_NAME = By.xpath("//li[contains(text(), 'Enter a value for Name.')]");
	public static final By ERROR_RENEWAL_MONTH = By
			.xpath("//li[contains(text(), 'Select a value for Renewal Month.')]");
	public static final By ERROR_XSOP_SUBGROUP_NAME = By
			.xpath("//li[contains(text(), 'Enter a value for XSOP Sub Group Name.')]");
	public static final By ERROR_RECEPIENT = By
			.xpath("//li[contains(text(), 'Please select a recipient before generating an XSOP Sub Group name.')]");
	public static final By ERROR_COMMENT = By.xpath("//li[contains(text(), 'Enter a value for Comment.')]");

	// Fields on Find DI Recipient page
	public static final By PARTICIPANTNAMEFIELD = By.id("txtParticipantName");
	public static final By CUSTOMERNAMEFIELD = By.id("txtCustomerName");
	public static final By FINDBTN = By.id("btnFind");

	// Fields on Select Recipient page
	public static final By SELECTRECIPIENTBTN = By.id("grdData_ctl02_lnkSelect");
	public static final By TABLEID = By.id("grdData");

	// Fields on Affiliation Profile page
	public static final By AFFILIATIONIDONPROFILE = By.id("ctlContextBar_lblContextId");
	public static final By PRICELISTBTN = By.id("btnPriceList");
	public static final By AFFILIATIONPROFILEPRINTBTN = By.id("ctlPageTitle_btnPrint");
	public static final By COMMON_RENEWAL = By.id("lblRenewalMonth");
	public static final By DELAWARE_NOTIFICATION_OPT_OUT_LABEL = By.xpath("//td[contains(text(), 'Delaware AR Notification Opt-Out :')]");
	public static final By DELAWARE_NOTIFICATION_OPT_OUT_VALUE = By.id("lblDEARNotificationOptOut");
	public static final By EDITBTN = By.id("ctlPageTitle_btnEdit");
	public static final By PAPER_SURCHARGE_BILLING = By.id("lblPaperSurchargeBilling");
	public static final By MAINTAIN_PAPER_SURCHARGE_BILLING_BTN = By.id("btnMaintainPaperSurchargeBilling");
	public static final By ENABLE_RADIO_BTN = By.id("rdoEnable");
	public static final By DISABLE_RADIO_BTN = By.id("rdoDisable");
	public static final By VIEW_DEFINITION_BTN = By.id("grdEnabledBundle_ctl02_btnDefinition");
	public static final By BUNDLE_NAME_LINK = By.id("grdEnabledBundle_ctl02_lnkObjectName");

	// Fields on Affiliation Left Nav links
	public static final By AFFILIATIONALERTSBTN = By.linkText("Affiliation Alerts");
	public static final By AFFILIATIONPROFILEBTN = By.linkText("Affiliation Profile");
	public static final By MEMBERSBTN = By.linkText("Members");
	public static final By SUBGROUPSBTN = By.linkText("Sub Groups");
	public static final By AFFILIATIONSEARCHLEFTNAVLINK = By.linkText("Affiliation Search");
	public static final By MOVEMEMBERSBTN = By.id("btnMoveMembers");
	public static final By SUB_GROUP_BUNDLE_MAINTAINANCE = By.linkText("Sub Group Bundle Maintenance");
	public static final By RENEWAL_INVOICES_LEFT_NAV_LINK = By.linkText("Renewal Invoices");
	public static final By SUB_GROUP_MEMBERS = By.linkText("Sub Group Members");
	public static final By REVISIONS = By.linkText("Revisions");
	public static final By XSOP_INVOICES_LEFT_NAV_LINK = By.linkText("XSOP Invoices");


	// Fields on Affiliation Alerts Page
	public static final By AFFILIATIONALERTTEXT = By.id("txtAlert");
	public static final By AFFILIATIONALERTSADDUPDATEBTN = By.id("btnAddUpdate");
	public static final By AFFILIATIONALERTENDDATECALENDERICON = By.id("ctrlDateSelectorEndDate_btnCal");
	public static final By AFFILIATIONALERTTODAYSDATE = By.xpath("//*[contains(@class,'day selected today')]");

	// Fields on Affiliation Members Page
	public static final By AFFLN_MEMBERS_PAGE = By.xpath("//span[contains(text(), 'Affiliation Members')]");
	public static final By QUITAFFILIATIONBTN = By.id("btnConfirmQuit");
	public static final By ENTITYNAMESCHECKBOX1 = By.id("grdData_ctl02_chkSelector");
	public static final By ENTITYNAMESCHECKBOX2 = By.id("grdData_ctl03_chkSelector");
	public static final By ADDMEMBERSBTN = By.id("btnAddMembers");
	public static final By FIRSTFILTER = By.id("ctlFilterBar_lstF");
	public static final By SECONDFILTER = By.id("ctlFilterBar_lstOp");
	public static final By RHSFILTER = By.id("ctlFilterBar_lstRHS");
	public static final By FILTERTEXTBOX = By.id("ctlFilterBar_txtRHS");
	public static final By GOBTN = By.id("ctlFilterBar_btnGo");
	public static final By CORPORATEENTITYNAMESCHECKBOX1 = By.id("grdData_ctl02_chkSelector");
	public static final By CORPORATEENTITYNAME = By.id("grdData_ctl02_lnkName");
	public static final By QUIT_AFFILIATION_ERRMSG = By
			.xpath("//li[contains(text(), 'At least one member must be selected to quit the affiliation.')]");
	public static final By DI_USAGE_LAYOUT_TAB = By.xpath("//a[contains(text(), 'DI Usage Layout')]");
	public static final By DEFAULT_LAYOUT_TAB = By.xpath("//a[contains(text(), 'Default layout')]");
	public static final By SELECT_PAGE_BTN = By.id("btnSelectPage");
	public static final By UNSELECT_PAGE_BTN = By.id("btnUnSelectPage");
	public static final By UPDATE_ENTITY_REFERENCES_BTN = By.id("btnUpdateEntRef");
	public static final By UPDATE_ENTITY_REFERENCES_ERRMSG = By.xpath("//li[contains(text(), 'At least one member must be selected to update the Entity Reference Numbers.')]");
	public static final By TYPE_FIRSTFILTER = By.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Type')]");
	public static final By CORPORATION_SECONDFILTER = By.xpath("//select[@id='ctlFilterBar_lstRHS']//option[contains(text(), 'Corporation')]");
	public static final By UPDATE_INVOICE_BTN = By.id("btnUpdateInvoice");
	
	//Fields on Update Invoice Page
	public static final By ASSUMED_NAMES_DETAILS_TAB = By.id("lnkAssumedNames");
	public static final By BILLED_THROUGH_DATE_CALENDAR = By.id("ctrlDateSelectorBilledthroughDate_btnCal");
	public static final By ASSUMED_NAME_CHECKBOX1 = By.id("grdData_ctl02_chkSelector");
	public static final By UPDATE_BTN = By.id("btnUpdate");


	// Fields on Confirm Quitting Affiliation Page
	public static final By QUITAFFILIATIONCANCELBTN = By.id("btnCancel");
	public static final By QUITAFFILIATIONCOMMENTSECTTION = By.id("ctlDIHistoryComment_txtComment");
	public static final By QUITAFFILIATIONERRORMESSAGE = By.id("ctlErrorBox_valSummary");
	public static final By QUITAFFILIATIONBTN2 = By.id("btnQuitAffiliation");

	// Fields on Affiliation Search Result Page
	public static final By FIRSTRESULTONSEARCHPAGE = By.id("grdData_ctl02_lnkProfile");
	public static final By NORECORDFOUNDTEXT = By.id("ctlNoRecordsBar_lblNoRecords");
	public static final By SEARCHAGAINBTN = By.id("btnSearch");
	public static final By ADDSELECTEDENTITIESBTN = By.id("btnAddMembersPickDI");

	// Fields on Affiliation Sub Groups Page
	public static final By CREATESUBGROUPBTN = By.id("btnCreateSubGroup");
	public static final By SECOND_SUB_GROUP_ON_GRID = By.id("grdData_ctl03_lnkProfile");
	public static final By FIRST_DELETE_BTN_ON_GRID = By.id("grdData_ctl02_btnDelete");
	public static final By EDITDI_BTN = By.id("imgOthersEdit");

	public static final By SUBGROUPSTABLE = By.id("grdData");
	public static final By EXPORT_BTN = By.id("ctlPageTitle_btnExport");
	public static final By SUB_GROUP_TYPE = By
			.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Sub Group Type')]");
	public static final By RENEWAL = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']//option[contains(text(), 'Renewal')]");
	public static final By ACTIVE_SUB_GROUP_NAME_SORT_LINK = By.xpath("//span[contains(text(), 'Sub Group Name')]");
	public static final By ACTIVE_SUB_GROUP_TYPE_SORT_LINK = By.xpath("//span[contains(text(), 'Sub Group Type')]");
	public static final By ACTIVE_MEMBER_COUNT_SORT_LINK = By.xpath("//span[contains(text(), 'Member Count')]");
	public static final By INACTIVE_SUB_GROUP_TYPE_SORT_LINK = By.xpath("//a[contains(text(), 'Sub Group Type')]");
	public static final By INACTIVE_MEMBER_COUNT_SORT_LINK = By.xpath("//a[contains(text(), 'Member Count')]");
	public static final By AUTORENEW_VALUE = By.id("ctlSimpleDI_lblAutoRenew");

	// Fields on Affiliation Create Sub Group Page
	public static final By CREATEBULLETINSUBGROUPBTN = By.id("chkBulletin");
	public static final By CROWENABLEDBTN = By.id("chkCrowEnabledBulletin");
	public static final By OVERRIDABLEBTN = By.id("chkOverride");
	public static final By FISCALYEAREND = By.id("lstFiscalYear");
	public static final By RECIPIENTSELECTBTN = By.id("ctlExpressDI_imgFind");
	public static final By BULLETINSUBGROUPNAME = By.id("txtBulletin");
	public static final By CREATESUBGROUPSAVEBTN = By.id("btnSave");
	public static final By CREATECOMMUNICATIONSUBGROUPBTN = By.id("chkComm");
	public static final By CREATECOMMUNICATIONCROWENABLEDBTN = By.id("chkCrowEnabledComm");
	public static final By CREATECOMMUNICATIONSUBGROUPNAME = By.id("txtComm");
	public static final By CREATERENEWALSUBGROUPBTN = By.id("chkRenewal");
	public static final By CREATERENEWALCROWENABLEDBTN = By.id("chkCrowEnabledRenewal");
	public static final By CREATERENEWALSUBGROUPNAME = By.id("txtRenewal");
	public static final By CREATESOPSUBGROUPBTN = By.id("chkSOP");
	public static final By CREATESOPCROWENABLEDBTN = By.id("chkCrowEnabledSOP");
	public static final By CREATESOPSUBGROUPNAME = By.id("txtSOP");
	public static final By CREATEXSOPSUBGROUPBTN = By.id("chkXSOP");
	public static final By CREATEXSOPCROWENABLEDBTN = By.id("chkCrowEnabledXSOP");
	public static final By CREATEXSOPSUBGROUPNAME = By.id("txtXSOP");

	// Fields on Find DI Recipient Page
	public static final By PARTICIPANTNAME = By.id("txtParticipantName");
	public static final By FINDDIRECIPENTBTN = By.id("btnFind");

	// Fields on Select Recipient Page
	public static final By PARTICIPANTSELECTBTN = By.id("grdData_ctl02_lnkSelect");

	// Fields after clicking on Print button on affiliation Profile page
	public static final By VERIFYAFFILIATIONALERTS = By.id("lblAlert");

	// Fields on Manage Sub Group Membership - Search Criteria Page
	public static final By MANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE = By.id("ctlPageTitle_lblTitle");
	public static final By ENTITYIDONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE = By.id("txtEntityNo");
	public static final By ENTITYNAMEONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE = By.id("txtEntityName");

	// Fields on Entity Search Page
	public static final By NORECORDSFOUND = By.id("ctlNoRecordsBar_lblNoRecords");

	// Fields on Add Affiliation Members - Pick Delivery Instructions
	public static final By BULLETINSUBGROUPDROPDWN = By.id("lstBulletin");
	public static final By COMMSUBGROUPDROPDWN = By.id("lstComm");
	public static final By RENEWALINVOICESUBGROUPDROPDWN = By.id("lstRenewal");
	public static final By SOPSUBGROUPDROPDWN = By.id("lstSOP");
	public static final By XSOPSUBGROUPDROPDWN = By.id("lstXSOP");
	public static final By COMMENTS = By.id("ctlDIHistoryComment_txtComment");
	public static final By JOINBTN = By.id("btnJoin");
	public static final By GOBACKBTN = By.id("btnBack");
	public static final By BULLETINRETAINCURRENTDI = By.id("rdoRetainBulletinSG");
	public static final By COMMRETAINCURRENTDI = By.id("rdoRetainCommSG");
	public static final By RENEWALINVOICERETAINCURRENTDI = By.id("rdoRetainRenewalSG");
	public static final By SOPRETAINCURRENTDI = By.id("rdoRetainSOPSG");

	// Fields On Sub Group Profile View Page
	public static final By SUBGROUPNAME = By.id("ctlProfileView_lblSubgroupName");
	public static final By BUNDLE_NAME = By.id("lblName");
	public static final By PLUS_DISBURSEMENTS = By.id("lblPlusDisbursements");

	// Fields on Sub Group Bundle Maintenance Page
	public static final By INACTIVE_BUNDLE_SUBGROUPS_TAB = By.id("lnkMaintainSubGroupBundle");
	public static final By REPARMS_BUNDLE_BUNDLE_DRPDWN = By
			.xpath("//select[@id='drpBundle']//option[contains(text(), 'REPARMS Bundle(Bundle)')]");
	public static final By PLUS_DISBURSEMENTS_CHECKBOX = By.id("chkPlusDisbursements");
	public static final By REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN = By
			.xpath("//select[@id='drpBundle']//option[contains(text(), 'REP and Annual Report(Bundle)')]");
	public static final By EFFECTIVE_START_DATE_CALENDAR = By.id("ctrlDateSelectorStartDate_btnCal");
	public static final By TODAYSDATE = By.cssSelector("td.day.selected.today");
	public static final By END_DATE_CALENDAR = By.id("ctrlDateSelectorEndDate_btnCal");
	public static final By COMMENT = By.id("txtComment");
	public static final By FIRST_SUBGROUP_ON_GRID = By.id("grdRenSubGroupList_ctl02_chkSelector");
	public static final By ENABLE_BTN = By.id("btnEnable");
	public static final By DISABLE_BTN = By.id("btnDisable");

	// Fields on Add Affiliation Members Search Criteria Page
	public static final By ENTITYRADIOBTN = By.id("rdoEntityNo");
	public static final By ENTITYIDONADDAFFILIATIONMEMBERS = By.id("txtEntityNo");
	public static final By VERIFYENTITYID = By.xpath("//*[@id=\"grdData\"]/tbody/tr[2]/td[2]/table/tbody/tr[2]/td[1]");
	public static final By SUBGROUPPROFILETITLE = By.id("ctlPageTitle_lblTitle");
	
	// Fields on Add Affiliation Edit Page
	public static final By DELAWARE_NOTIFICATION_OPT_OUT_LABEL_ON_AFFI_EDIT = By.xpath("//label[contains(text(), 'Delaware AR Notification Opt-Out')]");
	public static final By CHECKED_DELAWARE_NOTIFICATION_OPT_OUT = By.xpath("//input[@id='chkDEARNotificationOptOut' and @checked='checked']");
	public static final By DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX = By.id("chkDEARNotificationOptOut");

	
	// Fields on Sub Group Members Page
	public static final By ENTITY_ID_FIRST_FILTER = By.xpath("//select[@id='ctlFilterBar_lstF']//option[contains(text(), 'Entity#')]");
	public static final By EQUAL_SECOND_FILTER = By.xpath("//select[@id='ctlFilterBar_lstOp']//option[contains(text(), '=')]");
	public static final By FIRST_ENTITY_ON_GRID = By.id("grdData_ctl02_lnkName");


	//Pricing Details
	public static final By PRICING_DETAILS = By.xpath("//a[contains(text(), 'Pricing Details')]");
	public static final By PRICING_DETAILS_PAGE = By.xpath("//span[contains(text(), 'Revenue Summary')]");
	public static final By REVENUE_YEAR_RADIO_BUTTON = By.id("rdoViewRevenueYear");
	public static final By REVENUE_YEAR_TEXT = By.id("txtViewRevenueYear");
	public static final By CALCULATE_BTN = By.id("btnCalculate");
	public static final By GROSS_AMOUNT = By.id("lblGrossRepAmount");
	public static final By ERROR_MESSAGE_FOR_REVENUE = By.xpath("//li[contains(text(), 'No revenue exists for specified year.')]");
	
	//Fields on Company tree page
	public static final By COMPANY_TREE_PAGE = By.xpath("//span[contains(text(), 'Company Tree')]");
	public static final By COMPANY_TREE_LINK = By.xpath("//a[contains(text(), 'Company Tree')]");
	public static final By CHANGE_TOPMOST_PARENT_BTN = By.id("btnChangeTopmostParent");
	public static final By PLUS_BTN = By.xpath("//div[@class ='rtBot']//span[@class='rtPlus']");
	public static final By MINUS_BTN = By.xpath("(//span[@class='rtMinus'])[2]");

    //Affiliation profile page
	public static final By AFFILIATION_NAME = By.id("lblAffName");
	public static final By SELECTED_RENEWAL_MONTH = By.xpath("//select[@id='lstRenewalMonth']//option[@selected='selected']");
    public static final By RETAIN_CURRENT_DI_RADIO_BUTTON = By.id("rdoRetainDI");
    public static final By CHECK_BOXES_INVOICES = By.xpath("//input[starts-with(@id,'grdData_ctl')]");
    
    //Revisions Page
    public static final By REVISION_PREVIEW_BUTTON_REVISIONS = By.id("btnRevisionPreview");

	//XSOP Invoices page
	public static final By GENERATE_DETAIL_REPORT_BTN = By.id("grdData_ctl02_btnGenDtlRemort");
	public static final By FIRST_XSOP_INVOICE_ON_GRID = By.id("grdData_ctl02_lnkLogID");
	public static final By GENERATE_CURRENT_ESTIMATE_BTN = By.id("btnGenerateCurrentEstimate");
	
	//Edit DI Page
	public static final By ACTIVE_RADIO_BTN = By.id("rdoBtnAutoRenew_0");
	public static final By INACTIVE_RADIO_BTN = By.id("rdoBtnAutoRenew_1");
	public static final By EDITDI_COMMENTS_TEXTBOX = By.id("ctlDIHistoryComment_txtComment");


    //Sub group Profile Page
    public static final By DELIVERY_INSTRUCTION_EDIT_BUTTON = By.id("imgOthersEdit");
    public static final By DELIVERY_INSTRUCTION_DELIVERY_METHOD = By.id("ctlSimpleDI_lblDeliveryMethod");

    //NPD Dev Ops Sprint2 changes
    public static final By TRANSMITTAL_TYPE_DROP_DOWN = By.id("drpTransmittalType");
    public static final By TRANSMITTAL_TYPE_DROP_DOWN_DISABLED = By.xpath("//select[@id='drpTransmittalType'][@disabled='disabled']");

}
