package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class QualityMaintainance_SOP {
	
	//Fields on Worksheet Review Setup Page
	public static final By WORKSHEET_REVIEW_SETUP_PAGE_TITLE = By.xpath("(//span[contains(text(), 'Worksheet Review Setup')])[2]");
	
	public static final By LEFT_REVIEWABLE_SELECTOR_NOTICE_OF = By.xpath("//select[@id='reviewableSelector_lstAvailableItems']//option[contains(text(), 'Notice Of')]");
	public static final By REVIEWABLE_MOVE_RIGHT_BTN = By.xpath("(//input[@src='/Public/images/btn_MoveRight.gif'])[1]");
	public static final By RIGHT_REVIEWABLE_SELECTOR_NOTICE_OF = By.xpath("//select[@id='reviewableSelector_lstSelectedItems']//option[contains(text(), 'Notice Of')]");
	public static final By REVIEWABLE_SAVE_BTN = By.id("btnSaveReviewable");
	public static final By REVIEWABLE_MOVE_LEFT_BTN = By.xpath("(//input[@src='/Public/images/btn_MoveLeft.gif'])[1]");
	
	public static final By LEFT_FATAL_NONFATAL_SELECTOR_REMARKS = By.xpath("//select[@id='fatalSelector_lstAvailableItems']//option[contains(text(), 'Remarks')]");
	public static final By FATAL_NONFATAL_MOVE_RIGHT_BTN = By.xpath("(//input[@src='/Public/images/btn_MoveRight.gif'])[2]");
	public static final By RIGHT_FATAL_NONFATAL_SELECTOR_REMARKS = By.xpath("//select[@id='fatalSelector_lstSelectedItems']//option[contains(text(), 'Remarks')]");
	public static final By FATAL_NONFATAL_SAVE_BTN = By.id("btnSaveFatal");
	public static final By FATAL_NONFATAL_MOVE_LEFT_BTN = By.xpath("(//input[@src='/Public/images/btn_MoveLeft.gif'])[2]");
	
	public static final By LEFT_TYPO_SELECTOR_REMARKS = By.xpath("//select[@id='TypoSelector_lstAvailableItems']//option[contains(text(), 'Remarks')]");
	public static final By TYPO_MOVE_RIGHT_BTN = By.xpath("(//input[@src='/Public/images/btn_MoveRight.gif'])[3]");
	public static final By RIGHT_TYPO_SELECTOR_REMARKS = By.xpath("//select[@id='TypoSelector_lstSelectedItems']//option[contains(text(), 'Remarks')]");
	public static final By TYPO_SAVE_BTN = By.id("btnSaveTypo");
	public static final By TYPO_MOVE_LEFT_BTN = By.xpath("(//input[@src='/Public/images/btn_MoveLeft.gif'])[3]");
	
	//Fields On Pick Affiliation Page
	public static final By FIRST_AFFILIATION_SELECT_BTN = By.id("grdData_ctl02_lnkSelect");

	
	//Fields On Quality Randomiser Setup Page
	public static final By QUALITY_RANDOMISER_SETUP_PAGE_TITLE = By.xpath("(//span[contains(text(), 'Quality Randomiser Setup')])[2]");
	public static final By EXCLUDE_AFFILIATIONS_TAB = By.id("lnkExclAffl");
	public static final By EXCLUDE_TEAMS_TAB = By.id("lnkExclTeams");
	public static final By AFFILIATION_SELECT_BTN = By.id("EntAffSelector_btnSelect");
	public static final By SAVE_BTN = By.id("imgSave");
	public static final By FIRST_DELETE_BTN_ON_GRID = By.id("grdData_ctl02_btnDelete");
	public static final By SELECT_A_TEAM_DRPDWN = By.id("drpTeam");



	




	


	




}
