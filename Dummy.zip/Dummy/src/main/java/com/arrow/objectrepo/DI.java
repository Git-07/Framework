package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class DI {

	// Fields on Delivery Instructions Page
	public static final By REPLACE_MULTIPLE_DI_BTN = By.id("btnReplaceMultipleDITop");

	public static final By BULLETIN_EDIT_BTN = By.id("imgBulletinEdit");
	public static final By BULLETIN_DI_SOURCE_LABEL = By.id("ctlBulletinDI_trDISource");
	public static final By BULLETIN_OPTIONS_LABEL = By.id("ctlBulletinDI_trOption");
	public static final By BULLETIN_DELIVERY_METHOD_LABEL = By
			.xpath("//tr[@id='ctlBulletinDI_trSimpleDI']//td[contains(text(), 'Delivery Method :')]");
	public static final By BULLETIN_RECIPIENT_LABEL = By
			.xpath("//tr[@id='ctlBulletinDI_trSimpleDI']//td[contains(text(), 'Recipient :')]");
	public static final By BULLETIN_RECIPIENT_NAME = By.id("ctlBulletinDI_ctlRecipient_lblTitle");

	public static final By COMM_EDIT_BTN = By.id("imgCommunicationEdit");
	public static final By COMM_DI_SOURCE_LABEL = By.id("ctlCommunicationDI_trDISource");
	public static final By COMM_DELIVERY_METHOD_LABEL = By
			.xpath("//tr[@id='ctlCommunicationDI_trSimpleDI']//td[contains(text(), 'Delivery Method :')]");
	public static final By COMM_ICOMM_LABEL = By.id("ctlCommunicationDI_trICOMM");
	public static final By COMM_RECIPIENT_LABEL = By
			.xpath("//tr[@id='ctlCommunicationDI_trSimpleDI']//td[contains(text(), 'Recipient :')]");
	public static final By COMM_RECIPIENT_NAME = By.id("ctlCommunicationDI_ctlRecipient_lblTitle");

	public static final By RENEWALINVOICE_EDIT_BTN = By.id("imgRenewalEdit");
	public static final By RENEWALINVOICE_DI_SOURCE_LABEL = By.id("ctlRenewalDI_trDISource");
	public static final By RENEWALINVOICE_ENTITY_NAME_ON_INVOICE_ADDRESS_LABEL = By
			.id("ctlRenewalDI_trEntityonInvoiceAddr");
	public static final By RENEWALINVOICE_DELIVERY_METHOD_LABEL = By
			.xpath("//tr[@id='ctlRenewalDI_trSimpleDI']//td[contains(text(), 'Delivery Method :')]");
	public static final By RENEWALINVOICE_AUTO_RENEW_LABEL = By.id("ctlRenewalDI_trAutoRenew");
	public static final By RENEWALINVOICE_RECIPIENT_LABEL = By
			.xpath("//tr[@id='ctlRenewalDI_trSimpleDI']//td[contains(text(), 'Recipient :')]");
	public static final By RENEWALINVOICE_RECIPIENT_NAME = By.id("ctlRenewalDI_ctlRecipient_lblTitle");

	public static final By SOP_EDIT_BTN = By.id("imgServiceProcessEdit");
	public static final By SOP_DI_SOURCE_LABEL = By
			.xpath("//tr[@id='trSOPDISource']//td[contains(text(), 'DI Source :')]");
	public static final By SOP_LAWSUIT_TYPE = By.id("ctlSOPDI_0");
	public static final By SOP_EXPAND_ALL_LINK = By.linkText("Expand All");
	public static final By SOP_COLLAPSE_ALL_LINK = By.linkText("Collapse All");
	public static final By SOP_RECIPIENT_LABEL = By.xpath("//div[@id='ctlSOPDI_1']//td[contains(text(), 'Recipient')]");
	public static final By SOP_RECIPIENT_NAME = By.xpath("//div[@id='ctlSOPDI_1']//tr[@class='diActionRowAlt']/td[1]");
	public static final By SOP_DELIVERABLES = By.xpath(
			"//div[@id='ctlSOPDI_1']//tr[@class='diActionRowAlt']//td[contains(text(), 'SOP Papers with Transmittal')]");
	public static final By SOP_DELIVERY_METHODS_LABEL = By
			.xpath("//div[@id='ctlSOPDI_1']//td[contains(text(), 'Delivery Methods')]");
	public static final By UPS_2ND_DAY_AIR_SOP_DELIVERY_METHODS = By.xpath("//td[contains(text(), 'UPS 2nd Day Air')]");

	public static final By XSOP_EDIT_BTN = By.id("imgXSOPEdit");
	public static final By XSOP_DI_SOURCE_LABEL = By.id("ctlXSOPDI_trDISource");
	public static final By XSOP_DELIVERY_METHOD_LABEL = By
			.xpath("//tr[@id='ctlXSOPDI_trSimpleDI']//td[contains(text(), 'Delivery Method :')]");
	public static final By XSOP_RECIPIENT_LABEL = By
			.xpath("//tr[@id='ctlXSOPDI_trSimpleDI']//td[contains(text(), 'Recipient :')]");
	public static final By XSOP_RECIPIENT_NAME = By.id("ctlXSOPDI_ctlRecipient_lblTitle");
	public static final By ENTITY_TYPE = By.id("ctlEntityContextBox_lblEntityType");
	public static final By SOP_DI_RECIPIENT_NAME = By.xpath("//tr[@class='diActionRowAlt']/td[1]");


	// Fields on Edit DI Page
	public static final By SELECTBTN = By.id("ctlRecipient_imgFind");
	public static final By DI_COMMENTS_TEXTBOX = By.id("ctlDIHistoryComment_txtComment");
	public static final By SAVEBTN = By.id("btnSave");
	public static final By CANCELBTN = By.id("btnCancel");

	// Fields on Find DI Recipient page
	public static final By PARTICIPANTNAMEFIELD = By.id("txtParticipantName");
	public static final By FINDBTN = By.id("btnFind");
	public static final By DI_RECIPIENT_PAGE = By.xpath("//span[contains(text(), 'Find DI Recipient')]");
	
	// Fields on Select Recipient page
	public static final By SELECTRECIPIENTBTN = By.id("grdData_ctl02_lnkSelect");
	public static final By TABLEID = By.id("grdData");
	public static final By SELECT_RECIPIENT_PAGE = By.xpath("//span[contains(text(), 'Select Recipient')]");
	
	// Fields On Replace Delivery Instructions Page
	public static final By SELECT_ALL_BTN = By.id("btnSelectChk");
	public static final By REPLACEBTN = By.id("btnReplace");
	public static final By DI_PAGE = By.xpath("//span[contains(text(), 'Delivery Instructions')]");

	
	// Fields On Edit SOP DI Page
	public static final By SOP_RECIPIENT_EDIT_BTN = By.xpath("//div[@id='ctlDITreeView_1']//a");
	public static final By CREATE_CONDITION_BTN = By.id("imgCreateCondition");
	public static final By DELETEBTN = By.xpath("//img[@src='/Public/Images/btn_Delete.gif']");
	public static final By SOP_DELETE_IMG = By.id("grdData_ctl02_ctlDIActionItem_imgDelete");
	public static final By SELECT_SOP_TRANSMITTAL = By.xpath("//select[@id='ctlDIActionControl_drpDeliverable']/option[contains(text(), 'SOP Papers with Transmittal')]");
	public static final By EDIT_SOP_DI_PAGE = By.xpath("//span[contains(text(), 'Edit SOP DI')]");
	public static final By EDIT_IMG_BTN = By.xpath("//img[@src='/Public/Images/btn_Edit.gif']");

	

	// Fields On Manage Delivery Actions Page
	public static final By DELIVERY_ACTIONS_EDIT_BTN = By.id("grdData_ctl02_ctlDIActionItem_imgEdit");
	public static final By UPS_2ND_DAY_AIR = By.xpath("//option[contains(text(), 'UPS 2nd Day Air')]");
	public static final By ADD_TO_LIST_BTN = By.id("ctlDIActionControl_imgAddUpdateList");
	public static final By PREVIEW_CHANGES_BTN = By.id("btnPreviewChanges");
	public static final By SOP_PAPERS_WITH_TRANSMITTAL = By
			.xpath("//option[contains(text(), 'SOP Papers with Transmittal')]");
	public static final By RECIPIENT_SELECT_BTN = By.id("ctlDIActionControl_ctlRecipient_imgFind");

	// Fields on Create Delivery Condition Page
	public static final By SPECIAL_CIRUCMSTANCES_DRPDWN = By.id("drpSpecialCircum");
	public static final By LAWSUIT_TYPE_LEFT_SELECTOR_LEVIES = By
			.xpath("//select[@id='ctlLawsuitTypeControl_lbLawsuitType']/option[contains(text(), 'Levies')]");
	public static final By LAWSUIT_TYPE_MOVE_RIGHT_BTN = By.id("ctlLawsuitTypeControl_lnkAdd");
	public static final By LAWSUIT_SUBTYPE_DRPDWN = By.id("ctlLawsuitTypeControl_ddLawsuitType");
	public static final By JURISDICTION_RIGHT_ARROW = By.id("imgJurisdiction");
	public static final By STATE_ALABAMA = By
			.xpath("//select[@id='ctlJurisdictionTypeCtrl_lbState']/option[contains(text(), 'Alabama')]");
	public static final By COUNTRY_ALABAMA = By
			.xpath("//select[@id='ctlJurisdictionTypeCtrl_ddCounty']/option[contains(text(), 'Alabama')]");
	public static final By SUB_COUNTRY = By.id("ctlJurisdictionTypeCtrl_lbCounty");
	public static final By JURISDICTION_MOVE_RIGHT_BTN = By.id("ctlJurisdictionTypeCtrl_lnkAdd");
	public static final By CITY_DRPDWN = By.id("ctlJurisdictionTypeCtrl_ddCity");
	public static final By OTHER_RIGHT_ARROW = By.id("imgOther");
	public static final By DAMAGE_AMOUNT_TEXT_FIELD = By.id("txtDamageAmount");
	public static final By ANSWER_DATE_TEXTBOX = By.id("txtAnswerDate");
	public static final By SPECIFIC_CONDITION_TEXTBOX = By.id("txtSpecificCondition");
	public static final By MANAGE_DELIVERY_ACTIONS_BTN = By.id("btnManageDeliveryActions");
	public static final By MANAGE_DELIVERY_ACTIONS_PAGE = By.xpath("//span[contains(text(), 'Manage Delivery Actions')]");	

	// Fields on DI History Page
	public static final By PAGE_TITLE = By.id("ctlPageTitle_lblTitle");
	public static final By DI_TYPE_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstF']/option[contains(text(), 'DI Type')]");
	public static final By BULLETIN_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Bulletin')]");
	public static final By GO_BTN = By.id("ctlFilterBar_btnGo");
	public static final By FIRST_VIEW_BTN_ON_GRID = By.id("grdData_ctl02_lnkView");
	public static final By COMMUNICATION_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Communication')]");
	public static final By RENEWAL_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'Renewal')]");
	public static final By SOP_FILTER = By.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'SOP')]");
	public static final By XSOP_FILTER = By
			.xpath("//select[@id='ctlFilterBar_lstRHS']/option[contains(text(), 'XSOP')]");
	public static final By DI_HISTORY_COMMENT = By.id("grdData_ctl02_lblComment");
	public static final By DI_HISTORY_PAGE = By.xpath("//span[contains(text(), 'DI History')]");
	public static final By REVIEW_FORMER_DI_PAGE = By.xpath("//span[contains(text(), 'Review Former DI')]");


	// Fields on Review Former DI Page
	public static final By DI_TYPE = By.id("lblDIType");
	public static final By RETURN_TO_HISTORY_BUTTON = By.id("btnReturnToHistory");
	public static final By DI_HISTORY_TAB = By.xpath("//a[contains(text(), 'DI History')]");

	//Affiliation Join:
	public static final By FIND_AFFILIATION_TO_JOIN_PAGE = By.xpath("//span[contains(text(), 'Find an Affiliation to Join')]");
	public static final By PICK_AFFILIATION_TO_JOIN_PAGE = By.xpath("//span[contains(text(), 'Pick the Affiliation to Join')]");
	public static final By CONFIRM_JOINING_AFFILIATION = By.xpath("//span[contains(text(), 'Confirm Joining the Affiliation')]");
	public static final By ENTITY_PROFILE = By.xpath("//span[contains(text(), 'Entity Profile')]");

	//XSOP Invoice in DI Page
	public static final By DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE = By.xpath("//a[contains(text(),'Delivery Instructions')]");
	public static final By PARTICIPANT_TITLE = By.id("ctlXSOPDI_ctlRecipient_lblParticipantTitle");
	public static final By RECIPIENT_CUSTOMER = By.id("ctlXSOPDI_ctlRecipient_lblCustomer");
	public static final By RECIPIENT_ADDRESS =By.id("ctlXSOPDI_ctlRecipient_lblAddress");
	public static final By RECIPIENT_EMAIL = By.id("ctlXSOPDI_ctlRecipient_lblEmail");
	public static final By RECIPIENT_PHONE = By.id("ctlXSOPDI_ctlRecipient_lblPhone");
	public static final By RECIPIENT_FAX = By.id("ctlXSOPDI_ctlRecipient_lblFax");
	
	
	
	
}
