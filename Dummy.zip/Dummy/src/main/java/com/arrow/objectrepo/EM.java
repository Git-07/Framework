package com.arrow.objectrepo;

import org.openqa.selenium.By;

public class EM {
	//EM Entity Page
	public static final By EM_ENTITY_SEARCH_LINK = By.linkText("EM Entity Search");
	public static final By EM_ENTITY_PAGE = By.xpath("//span[contains(text(), 'EM Entity Search')]");
	public static final By ENTITY_PROFILE_PAGE = By.xpath("//span[contains(text(), 'Entity Profile')]");
	public static final By FIRST_EM_DATA = By.id("grdEntsearchResult_ctl02_lnkProfile");
	public static final By EM_ENTITY_SEARCH_RESULT = By.xpath("//span[contains(text(), 'EM Entity Search Results')]");
	public static final By EM_MAINTENANCE = By.xpath("//span[contains(text(), 'EM Maintenance')]");
    //public static final By SAVE_BTN = By.xpath("//span[contains(text(),'btnSave')]");
	public static final By SAVE_BTN = By.xpath("//input[@id='btnSave']");
	
	//EM Affiliation Page
	public static final By EM_AFFLN_SEARCH_LINK = By.linkText("EM Affiliation Search");
	public static final By EM_AFFILIATION_PAGE = By.xpath("//span[contains(text(), 'EM Affiliation Search')]");
	public static final By EM_AFFLN_SEARCH_RESULT = By.xpath("//span[contains(text(), 'Affiliation Search Results')]");
	public static final By FIRST_AFFLN_EM_DATA = By.id("grdData_ctl02_lnkProfile");
	public static final By EM_MAINTENANCE_BY_AFFLN = By.xpath("//span[contains(text(), 'EM Maintenance – By Affiliation')]");

	//Activate and Deactivate
	public static final By ACTIVE_STATUS = By.xpath("//span[@id='grdReps_ctl02_lblEntityStatus'][contains(text(), 'Active')]");
    public static final By BEM_STATUS_EXTERNAL = By.xpath("//td[contains(text(), 'Active-External')]");
	public static final By RADIO_ACTIVE_INTERNAL = By.id("rdoActiveInternal");
	public static final By RADIO_ACTIVE_EXTERNAL = By.id("rdoActiveExternal");
	public static final By ACTIVATE_BTN = By.id("btnActivate");
	public static final By ACTIVATE_BTN2= By.id("btnActivateDeactivate");
	public static final By DEACTIVATE_BTN = By.id("btnDeActivate");
	public static final By AFFLN_DEACTIVATE_BTN = By.id("btnDeactivate");
	public static final By DEACTIVATE_EM_PAGE = By.id("ctlPageTitle_lblTitle");
	//public static final By DEACTIVATE_EM_PAGE = By.xpath("//span[contains(text(), 'Deactivate EM Service')]");
	public static final By ACTIVATE_EM_PAGE = By.xpath("//span[contains(text(), 'Activate EM Service')]");
	public static final By DEACTIVATE_REASON = By.xpath("//select[@id='drpDeactvReason']/option[contains(text(), 'Correction/Entered in Error')]");
	public static final By DEACTIVATE_COMMENT = By.id("txtDeActcomment");
	public static final By SERVICE_TYPE_SELECT = By.id("grdServiceTypes_ctl02_chkSelect");
	public static final By ACTIVATE_DEACTIVATE_BTN = By.id("btnActivateDeactivate");
	public static final By DEACTIVATE_MESSAGE = By.xpath("//li[contains(text(), 'The following units have been deactivated')]");
	public static final By ACTIVATE_MESSAGE = By.xpath("//li[contains(text(), 'The following units have been activated')]");
	public static final By AFFI_DEACTIVATE_MESSAGE = By.xpath("//span[contains(text(), 'The following units have been deactivated.')]");
	public static final By AFFI_ACTIVATE_MESSAGE = By.xpath("//span[contains(text(), 'The following units have been activated.')]");

	//View History
	public static final By VIEW_HISTORY_LINK = By.id("grdReps_ctl02_hlViewHistory");
	public static final By EM_HISTORY_PAGE = By.xpath("//span[contains(text(), 'EM History')]");
	public static final By RETURN_TO_EM_MAINTENANCE = By.id("btnRtnEMList");
	public static final By SAVEBTN= By.id("btnSave");



	
}
