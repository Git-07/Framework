package com.arrow.entity.scripts;


import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_Entity;

public class CreateEntity extends BusinessFunctions_Entity {
	
	
	//User Creates an Entity
	@Test
	public void createEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookEntity, "CreateEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreateEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					createEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	

	//User creates an entity and cancels without saving.  Cancel button returns user to Entity Search Screen
	@Test
	public void cancelCreatingEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookEntity, "CancelCreatingEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CancelCreatingEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					cancelCreatingEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// Verify "View Revenue for Year" in Pricing Details in Entity when No Common Renewal month is Present
    @Test
	public void revenueForNoCommonRenewalMonthEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookEntity, "EntityPricingDetails");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EntityPricingDetails";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					revenueForNoCommonRenewalMonthEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

}
