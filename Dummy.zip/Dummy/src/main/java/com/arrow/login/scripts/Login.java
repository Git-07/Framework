package com.arrow.login.scripts;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_Affiliation;

public class Login extends BusinessFunctions_Affiliation {
	
	@BeforeClass
	public void excelLoad() throws Throwable{
		// Provide sheet path  and sheet name , will return the respective sheet object
		inputSheet=Excelobject.getSheetObject(TestDataWorkBookLogin,"Login");
	}
	
	@Test(enabled = false)
	public void defaultLogin() throws Throwable{
		try {
			child=extent.startTest("TestName");
		//	SignIn(strTeam, strMember);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void valid_login() throws Throwable {
		for(int iLoop=2;iLoop<=inputSheet.getPhysicalNumberOfRows();iLoop++)
		{
		  try{
			  RowFailNum=0;
			  String SheetName="Login";
			  String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
			  String runStatus=Excelobject.getCellData(SheetName, "RunStatus", iLoop);
			  String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
			  String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
			  String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
			  
			  if(runStatus.trim().equalsIgnoreCase("Y")){
				  
				  child=extent.startTest(strTestCaseID,strDesc);
				  iterationReport(iLoop-1,strTestCaseID+" Started");
				  
				  //This method will log into the Application
				  SignIn(strTeam, strMember);
				  
				  parent.appendChild(child);
				  //This will mark end of the one row in data sheet
				  iterationReport(iLoop-1,strTestCaseID+" Completed");
				  
			  }
	  }catch(Exception e){
			  catchBlock(e);
		  }
			  
	
		}
	}

}
