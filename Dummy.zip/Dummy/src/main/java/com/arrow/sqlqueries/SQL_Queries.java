package com.arrow.sqlqueries;

import java.util.ArrayList;

import com.arrow.util.DBConnection;

public class SQL_Queries {
	
	public static ArrayList<String> getAffiliationDetail (String affl_id) throws Throwable{
		String sqlQuery = "select * from arv_affiliation where affl_id = " + affl_id;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getPSOPBillingFlagForEntity (String entity_id) throws Throwable{
		String sqlQuery = "select ENTITY_ID from ARV_PSOP_BILLING_TARGET where ENTITY_ID = " + entity_id;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getPSOPBillingFlagForAffiliation (String aff_id) throws Throwable{
		String sqlQuery = "select AFFILIATION_ID from ARV_PSOP_BILLING_TARGET where AFFILIATION_ID = " + aff_id;
		return DBConnection.getResult(sqlQuery);
	}

	public static ArrayList<String> getEntityIDForLessThanTwoYearsOlderInvoice() throws Throwable{
		String sqlQuerry = "SELECT ENTITY_ID FROM ARV_PSOP_ORDER WHERE ORDER_ID IN("+
			    "SELECT FIRST_ORDER_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN (" +
			    "SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date >= add_months(SYSDATE,- 24)"
			    + " AND ENTITY_ID IS NOT NULL  AND REVISED_BY IS NULL) and FIRST_ORDER_TYPE ='PS' and rownum =1)"; 
				
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getOrderNumberForLessThanTwoYearsOlderInvoice() throws Throwable{		
		String sqlQuerry = " SELECT FIRST_ORDER_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN(" + 
				"SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date >= add_months(SYSDATE,- 24) AND ENTITY_ID IS NOT NULL  AND REVISED_BY IS NULL" + 
				") and FIRST_ORDER_TYPE ='PS' and rownum =1";
		return DBConnection.getResult(sqlQuerry);
	}	

	public static ArrayList<String> getInvoiceIDForLessThanTwoYearsOlderInvoice() throws Throwable{
		String sqlQuerry = "SELECT INVOICE_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN (" + 
				"SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date >= add_months(SYSDATE,- 24) AND ENTITY_ID IS NOT NULL  AND REVISED_BY IS NULL" + 
				" ) and FIRST_ORDER_TYPE ='PS' and rownum =1";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getEntityIDForMoreThanTwoYearsOlderInvoice() throws Throwable{
		String sqlQuerry = "SELECT ENTITY_ID FROM ARV_PSOP_ORDER WHERE ORDER_ID IN(" + 
				"SELECT FIRST_ORDER_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN (" + 
				"SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date < add_months(SYSDATE,- 24) AND ENTITY_ID IS NOT NULL  AND REVISED_BY IS NULL" + 
				" ) and FIRST_ORDER_TYPE ='PS' and rownum =1)";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getOrderNumberForMoreThanTwoYearsOlderInvoice() throws Throwable{
		String sqlQuerry = "SELECT FIRST_ORDER_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN (" + 
				" SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date < add_months(SYSDATE,- 24) AND ENTITY_ID IS NOT NULL  AND REVISED_BY IS NULL" + 
				" ) and FIRST_ORDER_TYPE ='PS' and rownum =1";		
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getInvoiceIDForMoreThanTwoYearsOlderInvoice() throws Throwable{
		String sqlQuerry = "SELECT INVOICE_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN (" +
				" SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date < add_months(SYSDATE,- 24) AND ENTITY_ID IS NOT NULL  AND REVISED_BY IS NULL" + 
				" ) and FIRST_ORDER_TYPE ='PS' and rownum =1";		
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getAffiliationMissingXSOPGroup() throws Throwable{
		String sqlQuerry = "SELECT AFFILIATION_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where PEO.AFFILIATION_ID not in "  
			+ "(select AFFILIATION_ID from ARV_PSOP_ORDER where ENTITY_ID is null and AFFILIATION_ID is not null) and PEO.EXCEPTION_TYPE_CD= '69001' AND ROWNUM=1 order by created_date desc";
				
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getAffiliationContainMoreXSOPGroup() throws Throwable{
		String sqlQuerry = "SELECT AFFILIATION_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where PEO.AFFILIATION_ID not in "  
			+ "(select AFFILIATION_ID from ARV_PSOP_ORDER where ENTITY_ID is null and AFFILIATION_ID is not null) and PEO.EXCEPTION_TYPE_CD= '69002' AND ROWNUM=1 order by created_date desc";
				
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getEntityMissingXSOPDI() throws Throwable{
		String sqlQuerry = "SELECT PEO.ENTITY_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where PEO.ENTITY_ID not in " 
				+ "(select ENTITY_ID from ARV_PSOP_ORDER where ENTITY_ID is NOT null and AFFILIATION_ID is null) and PEO.EXCEPTION_TYPE_CD= '69004' AND ROWNUM=1 order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getAffiliationForXSOPContainInvalidRecipient() throws Throwable{
		String sqlQuerry = "SELECT AFFILIATION_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where PEO.AFFILIATION_ID not in "  
				+"(select AFFILIATION_ID from ARV_PSOP_ORDER where ENTITY_ID is null and AFFILIATION_ID is not null) and PEO.EXCEPTION_TYPE_CD= '69005' AND ROWNUM=1 order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getEntityForDIContainInvalidRecipient() throws Throwable{
		String sqlQuerry = "SELECT PEO.ENTITY_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where PEO.ENTITY_ID not in "  
				+"(select ENTITY_ID from ARV_PSOP_ORDER where ENTITY_ID is NOT null and AFFILIATION_ID is null) and PEO.EXCEPTION_TYPE_CD= '69006' AND ROWNUM=1 order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getEntityForInvalidBusinessUnit() throws Throwable{
		String sqlQuerry = "SELECT ENTITY_ID FROM ARV_PSOP_EXCEPTION_ORDER where EXCEPTION_TYPE_CD= '69008' and ROWNUM=1";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getBusNameAffiliationForXSOPContainInvalidRecipient() throws Throwable{
		String sqlQuerry = "select  bus_name from TSOP_Worksheet where affl_id in (SELECT AFFILIATION_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where AFFILIATION_ID not in "  
			+ "(select AFFILIATION_ID from ARV_PSOP_ORDER where ENTITY_ID is null and AFFILIATION_ID is not null) and EXCEPTION_TYPE_CD= '69005') order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getBusNameAffiliationMissingXSOPGroup() throws Throwable{
		String sqlQuerry = "select  bus_name from TSOP_Worksheet where affl_id in (SELECT AFFILIATION_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where AFFILIATION_ID not in "  
			+ "(select AFFILIATION_ID from ARV_PSOP_ORDER where ENTITY_ID is null and AFFILIATION_ID is not null) and EXCEPTION_TYPE_CD= '69001') order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getBusNameAffiliationContainMoreXSOPGroup() throws Throwable{
		String sqlQuerry = "select  bus_name from TSOP_Worksheet where affl_id in (SELECT AFFILIATION_ID FROM ARV_PSOP_EXCEPTION_ORDER PEO where AFFILIATION_ID not in "  
			+ "(select AFFILIATION_ID from ARV_PSOP_ORDER where ENTITY_ID is null and AFFILIATION_ID is not null) and EXCEPTION_TYPE_CD= '69002') order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getOriginalOrderId(String count) throws Throwable{
		String sqlQuerry = "select order_id from ARV_PSOP_ORDER where PSOP_Count >" + count 
				+" and REVISED_ON is null and previous_order_id is null and Total_amount is not null order by created_date desc";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getCountOfNonCreditedOriginalPSOPOrderContent(String originalOrderId) throws Throwable{
		String sqlQuerry = "select count(*) from ARV_PSOP_ORDER_CONTENT WHERE IS_CREDIT ='N' AND ORDER_CONTENT_KEY = "  
				+"(select ORDER_CONTENT_KEY from ARV_PSOP_ORDER where Order_id = " + originalOrderId+")";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getOriginalInvoiceId(String originalOrderId) throws Throwable{
		String sqlQuerry = "SELECT invoice_number from CTAV_INVOICE where FIRST_ORDER_TYPE ='PS' and FIRST_ORDER_NUMBER = " + originalOrderId;
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getNewOrderId(String orginalOrderId) throws Throwable{
		String sqlQuerry = "select order_id from ARV_PSOP_ORDER where previous_order_id = " + orginalOrderId;
		return DBConnection.getResult(sqlQuerry);
	}
	//getCountOfPSOPOrderContentForNewOrderId
	public static ArrayList<String> getCountOfPSOPOrderContentForNewOrderId(String newOrderId) throws Throwable{
		String sqlQuerry = "select count(*) from ARV_PSOP_ORDER_CONTENT WHERE  ORDER_CONTENT_KEY = " + 
				"(select ORDER_CONTENT_KEY from ARV_PSOP_ORDER where order_id = " + newOrderId +")";
		return DBConnection.getResult(sqlQuerry);
	}
	//getCountOfCreditedPSOPOrderContent
	public static ArrayList<String> getCountOfPSOPOrderContentAfterCreditForOriginalOrderId(String orginalOrderId) throws Throwable{
		String sqlQuerry = "select count(*) from ARV_PSOP_ORDER_CONTENT WHERE IS_CREDIT ='Y' AND ORDER_CONTENT_KEY = "  
				+"(select ORDER_CONTENT_KEY from ARV_PSOP_ORDER where Order_Id = " + orginalOrderId+")";
		return DBConnection.getResult(sqlQuerry);
	}
	//5/13
	public static ArrayList<String> getEntityHaveDERepLLCORDELP() throws Throwable{
		String sqlQuerry = "Select Entity_id from ARV_Entity where Entity_id in ( " + 
				"Select Entity_id from arv_representation where Entity_id not in (select Entity_id from ARV_AFFL_MEMBERSHIP) and Entity_id in ( " + 
				"select entity_id from arv_representation where reason_cd is null and current_status_cd =6001 " + 
				"and is_arms_enabled = 'N' and  juris_id =8 and service_type_id in(228,223) and reason_cd is null and annual_rate is null)) " + 
				"and renewal_month !=1 and bus_unit_cd ='92001' and to_date(last_modified_date,'dd-mon-yy') != to_date(sysdate,'dd-mon-yy') order by last_modified_date ";
		
	    return DBConnection.getResult(sqlQuerry);		
		
	}
	
	public static ArrayList<String> getEntityNotHavingDERepLLCORDELP() throws Throwable{
		String sqlQuerry = "Select ENTITY_ID from arv_representation where Entity_id not in (select Entity_id from ARV_AFFL_MEMBERSHIP) " + 
				" and  juris_id =8 and service_type_id not in (228,223) and is_arms_enabled = 'Y' and annual_rate is null and reason_cd is null and current_status_cd =6001";
	    return DBConnection.getResult(sqlQuerry);		
		
	}
	
	public static ArrayList<String> getRenewalSubgroupHaveDERepLLCORDELP(String renewalMonth) throws Throwable{
		String sqlQuerry = "Select subgroup_id, MAX(to_date(Last_Modified_date,'dd-mon-yy')) as MAX_LAST_MODIFIED  from ARV_RNWL_ORDER where Affiliation_ID in ( " + 
				"select  AFFL_ID from ARV_Subgroup where subgroup_type_cd =10003 and affl_id in( " + 
				"select affl_id from ARV_AFFL_MEMBERSHIP where entity_id in( " + 
				"select Entity_id from arv_representation where rep_id in ( " + 
				"Select rep_id from ARV_RNWL_DS_ORDER_ITEM where is_ds_credit = 'N' and order_id in (select order_id from ARV_RNWL_ORDER where  renewal_year in ('2019','2020')) " + 
				"and juris_id =8 and service_type_id in (228,223) and is_arms_enabled = 'N' and reason_cd is null and annual_rate is null and current_status_cd not in (6002,6003,7037,7035,7030)) " + 
				")and  Entity_id  in (select Entity_id from ARV_AFFL_MEMBERSHIP)) and consolidate_invoice ='Y' and Affl_Id not in ('621','65426','38169','44782','915','389','64129','20','38169','4377')) " + 
				"and subgroup_id is not null and entity_id is null and renewal_month = " + renewalMonth + " and is_consolidated ='Y'  and  renewal_year in ('2019','2020') " +
				" group by subgroup_id order by MAX_LAST_MODIFIED ";
				
		return DBConnection.getResult(sqlQuerry);		
	}
	
	public static ArrayList<String> getRenewalSubgroupNameHavingDERepLLCORDELP(String subgroupID) throws Throwable{
		String sqlQuerry = "select  Affl_id,Subgroup_name from ARV_Subgroup  where subgroup_type_cd =10003 and subgroup_id = " + subgroupID;
		return DBConnection.getResult(sqlQuerry);
		
	}
	public static ArrayList<String> getEntityHavingMoreThanOneRepIncludingREPLLC() throws Throwable{
		String sqlQuerry = "Select Entity_id from ARV_Entity where Entity_id in ( " + 
				"Select Entity_id from arv_representation where Entity_id not in (select Entity_id from ARV_AFFL_MEMBERSHIP) and Entity_id in ( " + 
				"select entity_id from arv_representation where reason_cd is null and to_date(last_modified_date,'dd-mon-yy') != to_date(sysdate,'dd-mon-yy')  and current_status_cd =6001 group by Entity_id having count(Juris_id) > 2) " + 
				" and is_arms_enabled = 'N' and  juris_id =8 and service_type_id in(228,223) and reason_cd is null and annual_rate is null and current_status_cd =6001 " + 
				") and renewal_month !=1 and to_date(last_modified_date,'dd-mon-yy') != to_date(sysdate,'dd-mon-yy') order by last_modified_date ";
		
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(String subgroupID) throws Throwable{
		
		String sqlQuerry = "select Entity_id from ARV_REPRESENTATION where entity_id in( " + 
				"select Entity_id from ARV_AFFL_MEMBERSHIP where affl_id in ( " + 
				"Select Affiliation_id from ARV_RNWL_ORDER where subgroup_id = "+ subgroupID +" and is_consolidated = 'Y') " + 
				")and current_status_cd =6001 and is_arms_enabled = 'N' and annual_rate is null and  juris_id =8 and service_type_id in(228,223)";
		
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(String entity) throws Throwable {
		
		String sqlQuerry = "select SUBGROUP_ID from ARV_Subgroup where subgroup_type_cd =10003 and affl_id in(" + 
				"select affl_id from ARV_AFFL_MEMBERSHIP where entity_id = '" + entity + "')";
	
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheSubgroupWhichAlreadyHavingDSPresent(String renewalMonth) throws Throwable{
		
		String sqlQuerry = "select  AFFL_ID,SUBGROUP_ID,SUBGROUP_NAME from ARV_Subgroup where subgroup_type_cd =10003 and affl_id in( " + 
				"select affl_id from ARV_AFFL_MEMBERSHIP where entity_id in( " + 
				"select Entity_id from arv_representation where rep_id in ( " + 
				"Select rep_id from ARV_RNWL_DS_ORDER_ITEM where is_ds_credit = 'N' and order_id in (select order_id from ARV_RNWL_ORDER where  renewal_month = " + renewalMonth+" and juris_id =8 and service_type_id in (228,223) and current_status_cd = 6001 " + 
				"and is_arms_enabled = 'Y' and annual_rate is null and to_date(last_modified_date,'dd-mon-yy') != to_date(sysdate,'dd-mon-yy')) and affl_id not in ('20','25024','12120','14245','64129','17262','12676') " + 
				") and  Entity_id  in (select Entity_id from ARV_AFFL_MEMBERSHIP))) and consolidate_invoice ='Y'";
	
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheOrderIdPostRevisionOfEntityLevelInvoice(String entityId) throws Throwable{
		
		String sqlQuerry = "select order_id from ARV_RNWL_ORDER where entity_id = '"+entityId+
		"' and  to_date(created_date,'dd-mon-yy') = to_date(sysdate,'dd-mon-yy') order by revised_on desc";
				
		return DBConnection.getResult(sqlQuerry);
			
	}
	
	public static ArrayList<String> getTheOrderIdPostRevisionOfSubgroupLevelInvoice(String subgroupId) throws Throwable{
		
		String sqlQuerry = "select order_id from ARV_RNWL_ORDER where subgroup_id = '"+subgroupId+
		"' and  to_date(created_date,'dd-mon-yy') = to_date(sysdate,'dd-mon-yy') order by revised_on desc";
				
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheOriginalEntityLevelPSOPInvoice() throws Throwable{
		String sqlQuerry = "select Invoice_Number,first_order_number from CTAV_INVOICE where first_order_number in ( " + 
			"select order_id from ARV_PSOP_ORDER where order_content_key  in ( " + 
			"select order_content_key  from ARV_PSOP_ORDER_CONTENT  group by Order_content_Key having count(Order_Content_key)>1) " + 
			"and REVISED_ON is null and previous_order_id is null and Total_amount is not null and affiliation_id is null) and Invoice_Type='RI' " + 
			"and invoice_url is not null order by cust_inv_date";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheOriginalAffiliationLevelPSOPInvoice() throws Throwable{
		String sqlQuerry = "select Invoice_Number,first_order_number from CTAV_INVOICE where first_order_number in ( " + 
			"select order_id from ARV_PSOP_ORDER where order_content_key  in ( " + 
			"select order_content_key  from ARV_PSOP_ORDER_CONTENT  group by Order_content_Key having count(Order_Content_key)>0) " + 
			"and REVISED_ON is null and Total_amount is not null and entity_id is null) and Invoice_Type='RI' " + 
			"and invoice_url is not null order by cust_inv_date";
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheOriginalOrderContent(String originalOrderId) throws Throwable{
		String sqlQuerry = "select to_char(to_date(psop_billing_start_date,'dd-mon-yy'),'MM/dd/yyyy') as billing_start_date," + 
			"to_char(to_date(psop_billing_end_date,'dd-mon-yy'),'MM/dd/yyyy') as biling_end_date," + 
			"to_char(to_date(invoice_date,'dd-mon-yy'),'month') as invoice_date " + 
			"from ARV_PSOP_ORDER where order_id = " + originalOrderId;
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getActiveEntity() throws Throwable{
		
		//String sqlQuery = "select entity_id from arv_representation where current_status_cd=6001 group by entity_id having count(*)=1 fetch first rows only";
			String sqlQuery	="select entity_id from arv_representation where entity_id in "
					+ "(select entity_id from arv_entity where bus_unit_cd=92001) and "
					+ "current_status_cd=6001 group by entity_id having count(*)=1 fetch first rows only";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheNewOrderContent(String newOrderId) throws Throwable{
		String sqlQuerry = "select to_char(to_date(psop_billing_start_date,'dd-mon-yy'),'MM/dd/yyyy') as billing_start_date," + 
			"to_char(to_date(psop_billing_end_date,'dd-mon-yy'),'MM/dd/yyyy') as biling_end_date," + 
			"to_char(to_date(invoice_date,'dd-mon-yy'),'month') as invoice_date " + 
			"from ARV_PSOP_ORDER where order_id = " + newOrderId;
		return DBConnection.getResult(sqlQuerry);	
	}
	
	public static ArrayList<String> getTheEntityIdForThePSOPOrderId(String orderId) throws Throwable{
		
		String sqlQuerry = "select Entity_id from ARV_PSOP_ORDER where order_id = " + orderId;
		
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheAffiliationIdForThePSOPOrderId(String orderId) throws Throwable{
		
		String sqlQuerry = "select affiliation_id from ARV_PSOP_ORDER where order_id = " + orderId;
		
		return DBConnection.getResult(sqlQuerry);
		
	}
	
	public static ArrayList<String> getTheEntityIdToQuitFromAffiliationForThePSOPOrderId(String orderId) throws Throwable{
		
		String sqlQuerry = "select entity_id from ARV_PSOP_ORDER_CONTENT where order_content_key = " + 
			"(select order_content_key from ARV_PSOP_ORDER where order_id = '" +orderId +"') ";
			
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheCountOfEntityQuitFromAffiliationForThePSOPOrderId(String orderId) throws Throwable{
		
		String sqlQuerry = "select count(entity_id) from ARV_PSOP_ORDER_CONTENT where order_content_key = " + 
			"(select order_content_key from ARV_PSOP_ORDER where order_id = '" +orderId +"') ";
			
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(String entityId,String newOrderId) throws Throwable{
		
		String sqlQuerry = "select count(Entity_id) as count from ARV_PSOP_ORDER_CONTENT where " + 
			"Entity_id = '"+ entityId +"' and  order_content_key = (select order_content_key from ARV_PSOP_ORDER where order_id = "+ newOrderId +") group by entity_id";
		
		return DBConnection.getResult(sqlQuerry);
	}
	
	public static ArrayList<String> getTheAffiliationHavingMulitpleInvoices() throws Throwable{
		
		String sqlQuerry = "select affiliation_id from ARV_RNWL_ORDER where to_date(last_modified_date,'dd-mon-yy') != to_date(sysdate,'dd-mon-yy') and renewal_year = " + 
			"to_char(to_date(sysdate,'dd-mon-yy'),'yyyy') and is_consolidated = 'N' and affiliation_id is not null and bus_unit_cd =92001 and rownum< 10  order by last_modified_date";
		
		return DBConnection.getResult(sqlQuerry);
		
	}
	
	public static ArrayList<String> getTheEntityHavingInvoicesForTheCurrentYear() throws Throwable{
	
		String sqlQuerry = "select  Entity_id from ARV_RNWL_ORDER where to_date(last_modified_date,'dd-mon-yy') != to_date(sysdate,'dd-mon-yy') and renewal_year = " + 
			" to_char(to_date(sysdate,'dd-mon-yy'),'yyyy') and total_charge_amount is not null and affiliation_id is  null and bus_unit_cd =92001 and rownum< 10 order by last_modified_date";
			
		return DBConnection.getResult(sqlQuerry);
		
	}

	
	public static ArrayList<String> getTheActiveStandaloneEntity() throws Throwable{
	
		String sqlQuerry = "select entity_id from ARV_Entity where Entity_id not in (Select entity_id from ARV_AFFL_MEMBERSHIP) " + 
			"and Entity_Status_Cd=2002 and rownum <10  order by last_modified_date";
			
		return DBConnection.getResult(sqlQuerry);
		
	}
	
	public static ArrayList<String> getTheStatusAndActionForRejectionRule(String jurisId , String ruleType) throws Throwable{
		
		String sqlQuerry = "SELECT status,action FROM ARROW.ARV_REJECTION_JURIS_RULES " + 
				"where REJ_JURIS_ID = " + jurisId + "and rule_type_cd = " + ruleType +" order by last_modified_date desc";
				
			return DBConnection.getResult(sqlQuerry);
			
		}
	
	public static ArrayList<String> countBeforeDeletingTheRule(String jurisId , String ruleType) throws Throwable{
		
		String sqlQuerry = "SELECT count(*) FROM ARROW.ARV_REJECTION_JURIS_RULES " + 
				"where REJ_JURIS_ID = " + jurisId + "and rule_type_cd = " + ruleType;
				
			return DBConnection.getResult(sqlQuerry);
			
		}
	
	public static ArrayList<String> countAfterDeletingTheRule(String jurisId , String ruleType) throws Throwable{
		
		String sqlQuerry = "SELECT count(*) FROM ARROW.ARV_REJECTION_JURIS_RULES " + 
				"where REJ_JURIS_ID = " + jurisId + "and rule_type_cd = " + ruleType;
				
			return DBConnection.getResult(sqlQuerry);
			
		}
	
	public static ArrayList<String> getTheCurrentStatusCode(String esopId) throws Throwable{		
		String sqlQuery	= "Select curr_status_cd from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	
	public static ArrayList<String> getTheTotalCountOfCompletedESOPs() throws Throwable{		
		String sqlQuery	= "SELECT count(*) FROM ARV_SOP_CES_INBOX WHERE curr_status_cd = 157003 " + 
				"and to_date(last_modified_date,'dd-mon-yy') =  to_date(sysdate ,'dd-mon-yy') ";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheCourtAndAttorneyForCompletedESOPs(String esopId) throws Throwable{		
		String sqlQuery	= "Select attorney_name,court_name from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheSuitTypeForCompletedESOPs(String esopId) throws Throwable{		
		String sqlQuery	= "Select suit_type_cd from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}			
	
	public static ArrayList<String> fieldsModifiedInWorksheet(String worksheetId) throws Throwable{		
		String sqlQuery	= "select attorney_name,court_name,defendant_name, plaintiff from Arrow.TSOP_CES_WORKSHEET_AUDIT_TRAIL where worksheet_id = " +worksheetId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheRelatedLogForCompletedESOPs(String esopId) throws Throwable{		
		String sqlQuery	= "Select related_log_id from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheRejectedLogForRejectedESOPs(String esopId) throws Throwable{		
		String sqlQuery	= "Select worksheet_id from ARV_ESOP_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheFieldsForTheESOPs(String esopId) throws Throwable{		
		String sqlQuery	= "Select case_number,plaintiff,defendant_name from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheTheESOPForHardCopyRequiredOrNo(String hardCopyDeliveryFlag,int cesQueuCode) throws Throwable{		
		String sqlQuery	= "Select esop_id from ARV_SOP_CES_INBOX where " + 
				"esop_id in (select esop_id  from arv_esop_inbox where confirmation_number is null and worksheet_type_cd = "+75001+" and hardcopy_delivery_flag = '"+ hardCopyDeliveryFlag +"'"+ " and worksheet_id is null) " + 
				"and curr_status_cd = " + cesQueuCode + " order by last_modified_date desc fetch first rows only";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheTheESOPForHardCopyRequiredOrNoForMultiThreading(String hardCopyDeliveryFlag,String cesQueuCode) throws Throwable{		
		String sqlQuery	= "Select esop_id from ARV_SOP_CES_INBOX where " + 
				"esop_id in (select esop_id  from arv_esop_inbox where hardcopy_delivery_flag = '"+ hardCopyDeliveryFlag +"'"+ "and received_by_team = 83 and worksheet_id is null) " + 
				"and curr_status_cd = " + cesQueuCode + " order by last_modified_date desc fetch first 5 rows only";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheBranchPlantForTheESOPs(String esopId) throws Throwable{		
		String sqlQuery	= "Select bus_unit_cd from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> criteriaLimitCount() throws Throwable{
		
		String sqlQuery = "select criteria_limit from ARV_SOP_QUAL_LIMIT_CRITERIA";
		return DBConnection.getResult(sqlQuery);
				
	}
	
	public static ArrayList<String> getTheCountInSOPCesInbox(String esopId) throws Throwable{		
		String sqlQuery	= "Select count(*) from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheCountInESOPInbox(String esopId) throws Throwable{		
		String sqlQuery	= "Select count(*) from ARV_ESOP_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}

	public static ArrayList<String> getTheReasonForNotRejection(String esopId) throws Throwable{		
		String sqlQuery	= "Select not_rejection_reason_cd from ARV_SOP_CES_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> metaDataInRejectionLog(String esopId) throws Throwable{		
		String sqlQuery	= "Select damage_amount,time_sensitive, second_review, short_answer_date_flag from arv_esop_inbox where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> expeditedLogWorkflow(String esopId) throws Throwable{		
		String sqlQuery	= "select (select curr_status_cd from ARV_SOP_CES_Inbox where esop_id = " + esopId+") as currentstatus, " + 
				"(select IS_Expedited from ARV_SOP_Worksheet where worksheet_id = " + 
				"(select worksheet_id from arv_esop_inbox where esop_id  = " + esopId + ")) as expedited, " + 
				"(select Workflow_Type_CD from ARV_SOP_WORKSHEET where worksheet_id = " + 
				"(select worksheet_id from arv_esop_inbox where esop_id  = " + esopId + ")) as WorkflowInWS " + 
				"from arv_esop_inbox where esop_id  = "  + esopId ;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheLogNumberInESOPInbox(String esopId) throws Throwable{		
		String sqlQuery	= "Select worksheet_id from ARV_ESOP_INBOX where esop_id = " +esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheLawSuitTypeInCESInbox(String esopId) throws Throwable{		
		String sqlQuery	= "Select lookup_text from TLOOKUP where lookup_cd = (" + 
				"select suit_type_cd from ARV_SOP_CES_INBOX where esop_id = " +esopId + ")";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheRecipientName(String recipientId) throws Throwable{		
		String sqlQuery	= " SELECT recipient_name FROM ARV_sop_recipient_info where recipient_id = "+ recipientId +" FETCH FIRST ROW ONLY";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> executedByInActionItem(String worksheetId) throws Throwable{		
		String sqlQuery	= "Select executed_by from arv_sop_action_item where worksheet_id = "+ worksheetId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheCampaignSchedulerId() throws Throwable{		
		String sqlQuery	= "select campaign_scheduler_id from ARROW.tcampaign_scheduler order by campaign_scheduler_id desc fetch first row only";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheAffIdForTheTransmittalType(String transmittal) throws Throwable{		
		String sqlQuery	= "Select affl_id from arv_affiliation where transmittal_type_cd is " + transmittal + " fetch first row only";
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> executedByInActionItemTable(String worksheetId, String deliveryMethod) throws Throwable{		
		String sqlQuery	= "Select executed_by from arv_sop_action_item where worksheet_id = "+ worksheetId +" and delivery_method_cd = " + deliveryMethod;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> logPostedInWorksheet(String worksheetId) throws Throwable{		
		String sqlQuery	= "select is_logposted from ARV_SOP_WORKSHEET where worksheet_id = "+ worksheetId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> handlerProcessedESOP(String esopId) throws Throwable{		
		String sqlQuery	= "select is_handler_processed from ARV_SOP_CES_Inbox where esop_id = "+ esopId;
		return DBConnection.getResult(sqlQuery);
	}
	
	public static ArrayList<String> getTheNewStatusESOP(int recivedMethod) throws Throwable{		
		String sqlQuery	= "select esop_id from ARV_SOP_CES_INBOX where esop_id in (" + 
				"select esop_id from arv_esop_inbox where  worksheet_id is null and received_method_cd = "+ recivedMethod+")" + 
				"and curr_status_cd = 157001";
		return DBConnection.getResult(sqlQuery);
	}

	public static ArrayList<String> toaInWorksheet(String esopId) throws Throwable{		
		String sqlQuery	= "select title_of_act from ARV_SOP_WORKSHEET where worksheet_id =(" + 
				"select worksheet_id from ARV_ESOP_INBOX where esop_id = " +esopId+")";
		return DBConnection.getResult(sqlQuery);
	} 
}
