package com.arrow.alerts.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_Alerts;

public class Alerts extends BusinessFunctions_Alerts {

	// User add Alerts in Entity
	 @Test
	public void AlertsInEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "SearchEntityAlerts");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchEntityAlerts";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					AlertsInEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Extends Alerts in Entity
	 @Test
	public void ExtendAlertInEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "ExtendAlertInEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ExtendAlertInEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					ExtendAlertInEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}


	// User Enters as Service team member Selects Alerts on the Entity Left
	// Navigation Bar Creates Alerts for All Audience and All States.
	 @Test
	public void addAlertForAllAudienceAndStates() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "AddAlertForAllAudienceAndStates");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AddAlertForAllAudienceAndStates";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					addAlertForAllAudienceAndStates(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Usr Entrs as Srvce team mmbr Slcts Thre r Alrts fr this Enty lnk frm Enty
	// Prfle pge and Crtes Alrts for All Audience and for Specific State.
	 @Test
	public void addAlertForAllAudienceAndSpecificStates() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "AddAlertAllAudienceSpecfcState");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AddAlertAllAudienceSpecfcState";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					addAlertForAllAudienceAndSpecificStates(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Usr Entrs as Service team mmbr Slcts Affil Alrts on Left Nav Bar Crts Alrt
	// for Srvce Team as Audi & All States
	@Test
	public void addAlertForAffiliation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "AddAlertForAffiliation");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AddAlertForAffiliation";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					addAlertForAffiliation(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Enters as a Service Team Member creates an Alert for an Unaffiliated
	// Entity and then flags it for expiration.
	 @Test
	public void expireAlertForUnaffEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "ExpireAlertForUnaffEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ExpireAlertForUnaffEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					expireAlertForUnaffEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Enters as a Service Team Member creates an alert for an Affiliated
	// Entity and then flags it for expiration.
	 @Test
	public void expireAlertForAffiliatedEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "ExpireAlertForAffiliatedEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ExpireAlertForAffiliatedEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					expireAlertForAffiliatedEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Enters as a Service Team Member creates an alert for an Affiliation and
	// then flags it for expiration.
	 @Test
	public void expireAlertForAffiliation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "ExpireAlertForAffiliation");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ExpireAlertForAffiliation";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					expireAlertForAffiliation(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Enters as a Service Team Member and view expired Alerts (Audience and
	// State are set to All) of an Unaffiliated/Affiliated Entity.
	 @Test
	public void expiringAlerts() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "ExpiringAlerts");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ExpiringAlerts";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					expiringAlerts(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// Expire An Alert on My Expiring Alerts Page
	@Test
		public void expireAnAlert() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookAlerts, "ExpireAnAlert");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "ExpireAnAlert";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						expireAnAlert(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}


}