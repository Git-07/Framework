package com.arrow.affiliation.scripts;

import java.util.ArrayList;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.arrow.sqlqueries.SQL_Queries;
import com.arrow.util.DBConnection;
import com.arrow.workflows.BusinessFunctions_Affiliation;

public class CreateAffiliation extends BusinessFunctions_Affiliation {
	@BeforeClass
	public void excelLoad() throws Throwable{
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookAffiliation,"CreateAffiliation");
	}
	
	@Test
	public void createAffiliation() throws Throwable {
		
		for(int iLoop=2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreateAffiliation";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);
					
					//This will mark the beginning of row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Started");
					 
					//This method will log into the Application
					  SignIn(strTeam, strMember);
					  
					  String affl_id = CreateAffiliation(SheetName, iLoop);
					 // String affl_id = "310468533";
					 System.out.println(affl_id);
					
					 ArrayList<String> result = SQL_Queries.getAffiliationDetail(affl_id);
					 System.out.println("here");
					 for(int i =0; i<result.size(); i++) {
						 System.out.println(result.get(i));
					 }
					 
					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Completed");
					  
				}
				
				  
				
				
			}catch(Exception e) {
				catchBlock(e);
			}
			
		}
		
	}
}
