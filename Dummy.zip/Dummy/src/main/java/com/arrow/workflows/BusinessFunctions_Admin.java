package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Communication;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_Admin extends BusinessFunctions {

	public void createAndDeleteRole(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is create role
			assertTextMatching(Admin.PAGE_TITLE, "Create Role", "Title of the page");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is Roles
			assertTextMatching(Admin.PAGE_TITLE, "Roles", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void editRole(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");
			// Check if Name Role Name if already Present
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "Role Name Dropdown");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "Contains", "Second filter drop down");
			type(Admin.FILTER_TEXT_FILED, roleName, "Role Name");
			click(Admin.GO_BTN, "Go Button");
			if (verifyIfElementPresent(Admin.ROLE_DELETE_BTN, "Delete button present")) {
				click(Admin.ROLE_DELETE_BTN, "Delete Button");
				handlepopup();
			}
			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is create role
			assertTextMatching(Admin.PAGE_TITLE, "Create Role", "Title of the page");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Check Execute all standard operations on entity check box,Execute all
			// standard operations on affiliation check box,Execute all standard operations
			// on DI check box,Execute All standard operations on Alert checkbox,Execute All
			// standard operations on Renewal checkbox,Execute All standard operations on
			// SOP checkbox,Execute All standard operations on Communication
			// checkbox,Execute All standard operations on Usop checkbox,Execute All
			// standard operations on role administration checkbox,Execute All standard
			// operations on Entity Monitoring checkbox,Perform CRM Request management
			// checkbox,Allow target selection checkbox,Maintain entity based viewing rights
			// checkbox,Allow XSOP Invoice Revisions older than 2 years checkbox,Allow Sides
			// Access checkbox,Maintain Generic CD Entity checkbox,Maintain DSSOP Viewing
			// Rights checkbox,External User SOP verification checkbox,Allow Campaign Access
			// checkbox,Allow Worktool Access checkbox,Customer Name Mapping Setup
			// checkbox,Update Entity on posted Expedited SOP Log Checkbox,Remove from bulk
			// workflow checkbox,Level 1 checkbox,Level 2 checkbox,None checkbox
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_CHECKBOX,
					"Execute All standard operations on entity checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_AFFILAITION_CHECKBOX,
					"Execute All standard operations on affiliation checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_DI_CHECKBOX,
					"Execute All standard operations on DI checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ALERT_CHECKBOX,
					"Execute All standard operations on Alert checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_RENEWAL_CHECKBOX,
					"Execute All standard operations on Renewal checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_SOP_CHECKBOX,
					"Execute All standard operations on Service of Process checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_COMM_CHECKBOX,
					"Execute All standard operations on Communication checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_USOP_CHECKBOX,
					"Execute All standard operations on Usop checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ROLE_ADMINISTRATION_CHECKBOX,
					"Execute All standard operations on role administration checkbox");
			click(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_MONITORING_CHECKBOX,
					"Execute All standard operations on Entity Monitoring checkbox");
			click(Admin.PERFORM_CRM_REQUEST_MANAGEMENT_CHECKBOX, "Perform CRM Request management checkbox");
			click(Admin.ALLOW_TARGET_SELECTION_CHECKBOX, "Allow target selection checkbox");
			click(Admin.MAINTAIN_ENTITY_BASED_VIEWING_RIGHTS_CHECKBOX, "Maintain entity based viewing rights checkbox");
			click(Admin.ALLOW_XSOP_INVOICE_REVISIONS_CHECKBOX,
					"Allow XSOP Invoice Revisions older than 2 years checkbox");
			click(Admin.ALLOW_SIDES_ACCESS_CHECKBOX, "Allow Sides Access checkbox");
			click(Admin.MAINTAIN_GENERIC_CD_ENTITY_CHECKBOX, "Maintain Generic CD Entity checkbox");
			click(Admin.MAINTAIN_DSSOP_VIEWING_RIGHTS_CHECKBOX, "Maintain DSSOP Viewing Rights checkbox");
			click(Admin.EXTERNAL_USER_SOP_VERIFICATION_CHECKBOX, "External User SOP verification checkbox");
			click(Admin.ALLOW_SOP_WORKTOOL_ACCESS_CHECKBOX, "Allow Worktool Access checkbox");
			click(Admin.CUSTOMER_NAME_MAPPING_SETUP_CHECKBOX, "Customer Name Mapping Setup checkbox");
			click(Admin.ALLOW_CAMPAIGN_ACCESS_CHECKBOX, "Allow Campaign Access checkbox");
			click(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			click(Admin.REMOVE_FROM_BULK_WORKFLOW_CHECKBOX, "Remove from bulk workflow checkbox");
			click(Admin.LEVEL1_CHECKBOX, "Level 1 checkbox");
			click(Admin.NONE_CHECKBOX, "None checkbox");
			click(Admin.LEVEL2_CHECKBOX, "Level 2 checkbox");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Verify all the fields are updated
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_TEXT,
					"Execute all standard operations on Entity", "Execute all standard operations on Entity Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_AFFILAITION_TEXT,
					"Execute all standard operations on Affiliation",
					"Execute all standard operations on Affiliation Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_DI_TEXT,
					"Execute all standard operations on Delivery Instructions",
					"Execute all standard operations on Delivery Instructions Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ALERT_TEXT,
					"Execute all standard operations on Alert", "Execute all standard operations on Alert Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_RENEWAL_TEXT,
					"Execute all standard operations on Renewal", "Execute all standard operations on Renewal Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_SOP_TEXT,
					"Execute all standard operations on Service of Process",
					"Execute all standard operations on SOP Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_COMM_TEXT,
					"Execute all standard operations on Communication",
					"Execute all standard operations on Communication Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_USOP_TEXT,
					"Execute all standard operations on Universal Service of Process",
					"Execute all standard operations on Universal Service of Process Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ROLE_ADMINISTRATION_TEXT,
					"Execute all standard operations on Role Administration",
					"Execute all standard operations on Role Administration Text");
			assertTextMatching(Admin.EXECUTE_ALL_STANDARD_OPERATIONS_ON_ENTITY_MONITORING_TEXT,
					"Execute all standard operations on Entity Monitoring",
					"Execute all standard operations on Entity Monitoring Text");
			assertTextMatching(Admin.PERFORM_CRM_REQUEST_MANAGEMENT_TEXT, "Perform CRM Request Management",
					"Perform CRM Request Management Text");
			assertTextMatching(Admin.ALLOW_TARGET_SELECTION_TEXT, "Allow Target Selection",
					"Allow Target Selection Text");
			assertTextMatching(Admin.MAINTAIN_ENTITY_BASED_VIEWING_RIGHTS_TEXT, "Maintain Entity Based Viewing Rights",
					"Maintain Entity Based Viewing Rights Text");
			assertTextMatching(Admin.ALLOW_XSOP_INVOICE_REVISIONS_TEXT,
					"Allow XSOP Invoice Revisions older than 2 years",
					"Allow XSOP Invoice Revisions older than 2 years Text");
			assertTextMatching(Admin.MAINTAIN_GENERIC_CD_ENTITY_TEXT, "Maintain Generic CD Entity",
					"Maintain Generic CD Entity Text");
			assertTextMatching(Admin.MAINTAIN_DSSOP_VIEWING_RIGHTS_TEXT, "Maintain DSSOP Viewing Rights",
					"Maintain DSSOP Viewing Rights Text");
			assertElementPresent(Admin.ALLOW_SIDES_ACCESS_TEXT2, " Allow SIDES access Text");
			assertTextMatching(Admin.EXTERNAL_USER_SOP_VERIFICATION_TEXT, "External User SOP Verification",
					"External User SOP Verification Text");
			assertTextMatching(Admin.ALLOW_CAMPAIGN_ACCESS_TEXT, "Allow Campaign Access", "Allow Campaign Access Text");
			assertTextMatching(Admin.ALLOW_SOP_WORKTOOL_ACCESS_TEXT, "Allow SOP Worktool Access",
					"Allow SOP Worktool Access Text");
			assertTextMatching(Admin.CUSTOMER_NAME_MAPPING_SETUP_TEXT, "Customer Name Mapping Setup",
					"Customer Name Mapping Setup Text");
			// assertTextMatching(Admin.mai_TEXT, "Customer Name Mapping Setup", "Customer
			// Name Mapping Setup Text");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is Roles
			assertTextMatching(Admin.PAGE_TITLE, "Roles", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void viewRolePageSpecifications(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Select first role present on the grid
			click(Admin.FIRST_ROLE_ON_THE_GRID, "First Role On the grid");

			// Verify the page name is Role Profile
			assertTextMatching(Admin.PAGE_TITLE, "Role Profile", "Title of the page");

			// click on print button
			click(Admin.PRINT_BTN, "Print Button");

			// View Print Pdf
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");

			// Verify Role Name is present on the pdf page
			isElementPresent(Admin.ROLE_NAME_ON_PRINT_PDF_PAGE, "Role Name On Print PDF Page");

			driver.close();
			driver.switchTo().window(parentWindow);

			// Click on Edit Button and verify the landing page
			click(Admin.EDIT_BTN, "Edit Button");

			// Verify the page name is Role Profile
			assertTextMatching(Admin.PAGE_TITLE, "Edit Role", "Title of the page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void filterSortPageNavigationOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Select first role present on the grid
			click(Admin.FIRST_ROLE_ON_THE_GRID, "First Role On the grid");

			// Verify the page name is Role Profile
			assertTextMatching(Admin.PAGE_TITLE, "Role Profile", "Title of the page");

			// Verify all the filters
			click(Admin.NAME_DRPDWN, "Select Name from drp dwn");
			click(Admin.TEAM_DRPDWN, "Select Team from drp dwn");
			click(Admin.TEAM_TYPE_DRPDWN, "Select TeamType from drp dwn");
			click(Admin.STATUS_DRPDWN, "Select status from drp dwn");

			// For Pagination Check
			// Click on First,Previous,1-10,11-20.,...,Next,Last Links
			click(Admin.PAGE_11__20_LINK, "Click on 11-20 link");
			click(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			click(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			click(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");
			click(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");

			// Check whether All sorting links are present
			click(Admin.ACTIVE_NAME_SORT_LINK, "Active Sort By Name Link");
			isElementPresent(Admin.INACTIVE_TEAM_SORT_LINK, "Inactive Sort By Team Link");
			isElementPresent(Admin.INACTIVE_TEAM_TYPE_SORT_LINK, "Inactive Sort By Team Type Link");
			isElementPresent(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Sort By Status Link");

			click(Admin.INACTIVE_TEAM_SORT_LINK, "Inactive Sort By Team Link");
			isElementPresent(Admin.ACTIVE_TEAM_SORT, "Active Sort By Team Link");
			click(Admin.INACTIVE_TEAM_TYPE_SORT_LINK, "Inactive Sort By Team Type Link");
			isElementPresent(Admin.ACTIVE_TEAM_TYPE_SORT, "Active Sort By Team Type Link");
			click(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Sort By Status Link");
			isElementPresent(Admin.ACTIVE_STATUS_SORT, "Active Sort By Status Link");

		} catch (Exception e) {
			throw e;
		}

	}

	public void grantAndRevokeRole(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is create role
			assertTextMatching(Admin.PAGE_TITLE, "Create Role", "Title of the page");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Maintain Button
			click(Admin.MAINTAIN_BTN, "Maintain Button");

			// Click on Grant Role Button
			click(Admin.GRANT_ROLE_BTN, "Grant Role Button");

			// Enter Employee Name and click on find button
			type(Admin.EMPLOYEE_NAME_TEXTBOX, empName, "Employee Name TextBox");
			click(Admin.FIND_BTN, "Find Button");

			// Select Employee
			click(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "Select Employee");
			// Click on Grant Role Button
			click(Admin.GRANT_ROLE_BTN, "Grant Role Button");

			// Click On Cancel Button
			click(Admin.CANCELBTN, "Cancel Button");

			// Select name from first filter and select contains from second filter and
			// enter the employee name and click on go btn
			click(Admin.NAME_DRPDWN, "Select Name from drp dwn");
			click(Admin.CONTAINS_DRPDWN, "Select Contains from second filter drp dwn");
			type(Admin.FILTER_TEXT_BOX, empName, "Filter TextBox");
			click(Admin.GO_BTN, "Go Btn");

			// Verify employee name is present on the grid
			assertElementPresent(Admin.EMPLOYEE_NAME_ON_GRID, "Employee Name On Grid");

			// Click On Maintain Button
			click(Admin.MAINTAIN_BTN, "Maintain Button");

			// Select Employee
			click(Admin.FIRST_CHECKBOX_ON_GRANT_GRID, "Select Employee");

			// Click On Revoke Grant Button
			click(Admin.REVOKE_GRANT_BTN, "Revoke Grant Button");

			// Click On Cancel Button
			click(Admin.CANCELBTN, "Cancel Button");

			// Verify the page name is Role Profile
			assertTextMatching(Admin.PAGE_TITLE, "Role Profile", "Title of the page");

			// Verify No records found is displayed on Employee Grid
			isElementPresent(Admin.NO_RECORDS_FOUND_ON_GRID, "No Records Found Message On Grid");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is Roles
			assertTextMatching(Admin.PAGE_TITLE, "Roles", "Title of the page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void viewEmployeeSearchResultPageSpecifications(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Click on Grants Link from left nav bar
			click(Admin.GRANTS_LEFT_NAV_LINK, "Grants left nav link");

			// Verify the page name is Employee Search Criteria
			assertTextMatching(Admin.PAGE_TITLE, "Employee Search Criteria", "Title of the page");

			// Enter Employee Name and click on search button
			type(Admin.EMPLOYEE_NAME_TEXTBOX, empName, "Employee Name TextBox");
			click(Admin.SEARCH_BTN, "Search Button");

			// Verify the page name is Pick Users
			assertTextMatching(Admin.PAGE_TITLE, "Employee Search Results", "Title of the page");

			// Verify all the filters
			click(Admin.NAME_DRPDWN, "Select Name from drp dwn");
			click(Admin.TEAM_DRPDWN, "Select Team from drp dwn");
			click(Admin.TEAM_TYPE_DRPDWN, "Select TeamType from drp dwn");
			click(Admin.STATUS_DRPDWN, "Select status from drp dwn");

			// For Pagination Check
			// Click on First,Previous,1-10,11-20.,...,Next,Last Links
			click(Admin.PAGE_11__20_LINK, "Click on 11-20 link");
			click(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			click(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			click(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");
			click(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");

			// Check whether All sorting links are present
			click(Admin.ACTIVE_NAME_SORT_LINK, "Active Sort By Name Link");
			isElementPresent(Admin.INACTIVE_TEAM_SORT_LINK, "Inactive Sort By Team Link");
			isElementPresent(Admin.INACTIVE_TEAM_TYPE_SORT_LINK, "Inactive Sort By Team Type Link");
			isElementPresent(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Sort By Status Link");
			click(Admin.INACTIVE_TEAM_SORT_LINK, "Inactive Sort By Team Link");
			isElementPresent(Admin.ACTIVE_TEAM_SORT, "Active Sort By Team Link");
			click(Admin.INACTIVE_TEAM_TYPE_SORT_LINK, "Inactive Sort By Team Type Link");
			isElementPresent(Admin.ACTIVE_TEAM_TYPE_SORT, "Active Sort By Team Type Link");
			click(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Sort By Status Link");
			isElementPresent(Admin.ACTIVE_STATUS_SORT, "Active Sort By Status Link");

			// Search Again Btn,Cancel Button and Grant Role button is present
			isElementPresent(Admin.SEARCH_AGAIN_BTN, "Search Again Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void viewGrantsPageSpecifications(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Verify the page name is create role
			assertTextMatching(Admin.PAGE_TITLE, "Create Role", "Title of the page");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Maintain Button
			click(Admin.MAINTAIN_BTN, "Maintain Button");

			// Click on Grant Role Button
			click(Admin.GRANT_ROLE_BTN, "Grant Role Button");

			// Enter Employee Name and click on find button
			type(Admin.EMPLOYEE_NAME_TEXTBOX, empName, "Employee Name TextBox");
			click(Admin.FIND_BTN, "Find Button");

			// Verify the page name is Pick Users
			assertTextMatching(Admin.PAGE_TITLE, "Pick Users", "Title of the page");

			// Verify all the filters
			click(Admin.NAME_DRPDWN, "Select Name from drp dwn");
			click(Admin.TEAM_DRPDWN, "Select Team from drp dwn");
			click(Admin.TEAM_TYPE_DRPDWN, "Select TeamType from drp dwn");
			click(Admin.STATUS_DRPDWN, "Select status from drp dwn");

			// For Pagination Check
			// Click on First,Previous,1-10,11-20.,...,Next,Last Links
			click(Admin.PAGE_11__20_LINK, "Click on 11-20 link");
			click(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			click(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			click(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");
			click(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");

			// Check whether All sorting links are present
			click(Admin.ACTIVE_NAME_SORT_LINK, "Active Sort By Name Link");
			isElementPresent(Admin.INACTIVE_TEAM_SORT_LINK, "Inactive Sort By Team Link");
			isElementPresent(Admin.INACTIVE_TEAM_TYPE_SORT_LINK, "Inactive Sort By Team Type Link");
			isElementPresent(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Sort By Status Link");
			click(Admin.INACTIVE_TEAM_SORT_LINK, "Inactive Sort By Team Link");
			isElementPresent(Admin.ACTIVE_TEAM_SORT, "Active Sort By Team Link");
			click(Admin.INACTIVE_TEAM_TYPE_SORT_LINK, "Inactive Sort By Team Type Link");
			isElementPresent(Admin.ACTIVE_TEAM_TYPE_SORT, "Active Sort By Team Type Link");
			click(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Sort By Status Link");
			isElementPresent(Admin.ACTIVE_STATUS_SORT, "Active Sort By Status Link");

			// Search Again Btn,Cancel Button and Grant Role button is present
			isElementPresent(Admin.SEARCH_AGAIN_BTN, "Search Again Button");

		} catch (Exception e) {
			throw e;
		}

	}

	// Verifies page specs for search on Team Type, User group and Employee Name
	public void empSearchUserGroup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			click(Admin.GRANTS_TAB, "Grants Tab");
			assertElementPresent(Admin.EMP_SEARCH_CRITERIA_PAGE, "Employee Search Criteria Page");
			// Enter Employee Name and click on find button
			type(Admin.EMPLOYEE_NAME_TEXTBOX, empName, "Employee Name TextBox");
			click(Admin.TEAM_TYPE_SOP, "Team Type SOP");
			click(Admin.USER_GROUP_SOP, "User Group SOP");
			click(Admin.SEARCH_BTN, "Search Button");

			assertElementPresent(Admin.EMP_SEARCH_RESULTS_PAGE, "Employee Search Results");
			click(Admin.SELECT_FIRST_EMPLOYEE, "Select First Employee");
			assertElementPresent(Admin.EMPLOYEE_GRANTS_PAGE, "Employee Grants Page");

		} catch (Exception e) {
			throw e;
		}

	}

	// Verifies pge specs of Emply Grants page verifies filter sort
	public void grantsSortBy(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			click(Admin.GRANTS_TAB, "Grants Tab");
			assertElementPresent(Admin.EMP_SEARCH_CRITERIA_PAGE, "Employee Search Criteria Page");
			// Enter Employee Name and click on find button
			type(Admin.EMPLOYEE_NAME_TEXTBOX, empName, "Employee Name TextBox");
			click(Admin.TEAM_TYPE_SOP, "Team Type SOP");
			click(Admin.USER_GROUP_SOP, "User Group SOP");
			click(Admin.SEARCH_BTN, "Search Button");

			assertElementPresent(Admin.EMP_SEARCH_RESULTS_PAGE, "Employee Search Results");
			assertElementPresent(Admin.NAME_ACTIVE, "Name Active");
			assertElementPresent(Admin.TEAM_INACTIVE, "Team In-Active");
			assertElementPresent(Admin.TEAMTYPE_INACTIVE, "Team Type In-Active");
			assertElementPresent(Admin.STATUS_INACTIVE, "Status In-Active");
			click(Admin.TEAM_INACTIVE, "Team");
			assertElementPresent(Admin.NAME_INACTIVE, "Status In-Active");
			assertElementPresent(Admin.TEAM_ACTIVE, "Team Active");

		} catch (Exception e) {
			throw e;
		}

	}

	public void e1RefreshMessageQ(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Navigate to E1 Refresh Message Q tab
			click(Admin.E1_REFRESH_MESSAGE_Q__TAB, "E1 Refresh Message Q");
			assertTextMatching(Admin.PAGE_TITLE, "E1 Refresh Message Q", "Page Title");

			// Select Message Status as completed
			click(Admin.COMPLETED_MESSAGE_STATUS, "Message Status as completed");
			click(Admin.SEARCH_BTN, "Search Button");

			// Click On First Name
			click(Admin.FIRST_NAME, "First Name");

			// View Data Refresh Details
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");
			assertTextMatching(Admin.PAGE_TITLE, "Data Refresh Details", "Page Title");

			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}

	}

	public void globalIntakeTime(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String empName = Excelobject.getCellData(ReportSheet, "Employee Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Navigate to Global Intake Time tab
			click(Admin.GLOBAL_INTAKE_TIME__TAB, "Global Intake Time Tab");
			assertTextMatching(Admin.PAGE_TITLE, "Global Intake Time", "Page Title");

			// Select Certified Mail as method of service and click on add btn
			click(Admin.CERTIFIED_MAIL, "Method of service as certified mail");
			click(Admin.RIGHT_SELECTOR, "Right Selector");
			type(Admin.TIME_TEXT_BOX, "12:00", "Time");
			click(Admin.INTAKE_ADD_BTN, "Add Button");

			// Delete Certified Mail from grid
			click(Admin.FIRST_CHECKBOX, "First Checkbox");
			click(Admin.FIRST_DEL_BTN, "First Delete Btn");

		} catch (Exception e) {
			throw e;
		}

	}

	public void verifyDEARNotificationsSection(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Click On Event Manager from left nav link
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");

			// Verify the page title is Event Manager
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");

			// Click On File & Event Selection link from left nav bar
			click(Admin.FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK, "File & Event Selection Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void deARNotificationsPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Delaware AR Admin is Present
			isElementPresent(Admin.DELAWARE_AR_ADMIN_CHECKBOX, "Delaware AR Admin Checkbox");
			assertTextMatching(Admin.DELAWARE_AR_ADMIN_LABEL, "Delaware AR Admin", "Label For Delaware AR Admin Field");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(Admin.EDIT_BTN, "Edit Button");

			// Click on Delaware AR Admin Checkbox and click on save
			// button
			click(Admin.DELAWARE_AR_ADMIN_CHECKBOX, "Delaware AR Admin Checkbox");
			click(Admin.SAVEBTN, "Save Button");

			// Verify Delware AR Admin is added under Administrative Permissions on Role
			// Profile Page
			assertElementPresent(Admin.DELAWARE_AR_ADMIN_ON_ROLE_PROFILE_PAGE,
					"Delware AR Admin is added under Administrative Permissions on Role Profile Page");

			// Click on Edit Button again and uncheck Delware AR Admin
			click(Admin.EDIT_BTN, "Edit Button");
			click(Admin.DELAWARE_AR_ADMIN_CHECKBOX, "Delaware AR Admin Checkbox");

			// Click on save btn
			click(Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Administrative Permissions Field
			assertTextMatching(Admin.ADMINISTRATIVE_PERMISSIONS_FIELD, "No permissions",
					"No permissions Msg on Administrative Permissions Field");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminHavingPermissions(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminNotHavingPermissions(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			isDisabled(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
		} catch (Exception e) {
			throw e;
		}

	}

	public void fileAndEventSelectionPageUploadFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Verify Delaware Event Label and its dropdown
			assertElementPresent(Admin.DELAWARE_EVENT_LABEL, "Delaware Event Label");
			assertElementPresent(Admin.DELAWARE_EVENT_DROPDOWN, "Delaware Event Dropdown");

			// Verify File Upload Label and its dropdown
			assertElementPresent(Admin.FILE__UPLOAD_LABEL, "File Uplaod Label");

			// Verify Production and Test radio button
			assertElementPresent(Admin.PRODUCTION_RADIO_BTN, "Production radio button");
			assertElementPresent(Admin.TEST_RADIO_BTN, "Test radio button");

			// Verify Production radio button is checked by default
			assertElementPresent(Admin.CHECKED_PRODUCTION_RADIO_BTN, "Checked Production radio button");

			// Click on Upload Button
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			// Verify the error messages
			assertElementPresent(Admin.DELAWARE_EVENT_ERR_MSG, "Delaware Event Error Message");
			assertElementPresent(Admin.FILE_UPLOAD_ERR_MSG, "File Upload Error Message");

			// Verify Choose File Button,Upload Button and Cancel Button is present
			assertElementPresent(Admin.CHOOSE_FILE_BUTTON, "Choose File Button");
			assertElementPresent(Admin.UPLOAD_BUTTON, "Upload Button");
			assertElementPresent(Admin.CANCEL_BUTTON, "Cancel Button");

			// Select an Event from Dropdown and click on choose file button
			selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, delawareEventName,
					"Select a Delaware Event from delaware event drop down box");

			if (fileName.contains("1 KB")) {
				// Upload 1 kb File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");

			} else if (fileName.contains("0 KB")) {
				// Upload 0 kb File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				assertTextMatching(Admin.ERROR, "Select a valid DAT file.", "Error");
			} else if (fileName.contains("Invalid File")) {
				// Upload an invalid File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				handlepopup();

			} else if (fileName.contains("Less than 150 MB")) {
				// Upload a 120 MB File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");

			} else if (fileName.contains("Greater than 150 MB")) {
				// Upload a 120 MB File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				handlepopup();

			}
			Thread.sleep(7000);

		} catch (Exception e) {
			throw e;
		}

	}

	public void fileAndEventSelectionPageGridFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware Event Name", count);
			String fileNameOf50Records = Excelobject.getCellData(ReportSheet, "File Name Of 50 Records", count);

			// Navigate to File and Event Selection Page
			verifyDEARNotificationsSection(ReportSheet, count);

			// Check Filters
			click(Admin.EVENT_ID_FILTER_DRPDWN, "Select event id from filter dropdown");
			click(Admin.EVENT_NAME_FILTER_DRPDWN, "Select event name from filter dropdown");
			click(Admin.IS_PROD_FILTER_DRPDWN, "Select Is Prod from filter dropdown");
			click(Admin.STATUS_FILTER_DRPDWN, "Select status from filter dropdown");

			// Check Sorting Links
			assertElementPresent(Admin.ACTIVE_EVENT_ID_SORT_LINK, "Active Event ID Sort link");
			assertElementPresent(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Status Sort Link");
			assertElementPresent(Admin.INACTIVE_UPDATED_ON_SORT_LINK, "Inactive Updated On Sort Link");
			click(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.ACTIVE_EVENT_NAME_SORT_LINK, "Active Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_EVENT_ID_SORT_LINK, "Inactive Event Name Sort Link");
			click(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Status Sort Link");
			assertElementPresent(Admin.ACTIVE_STATUS_SORT_LINK, "Active Status Sort Link");
			click(Admin.INACTIVE_UPDATED_ON_SORT_LINK, "Inactive Updated On Sort Link");
			assertElementPresent(Admin.ACTIVE_UPDATED_ON_SORT_LINK, "Active Updated On Sort Link");

			// Check Pagination
			assertElementPresent(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");
			assertElementPresent(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			assertElementPresent(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			assertElementPresent(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");

			// Verify Grid Columns
			assertElementPresent(Admin.EVENT_ID_COLUMN, "Event Id Column");
			assertElementPresent(Admin.EVENT_NAME_COLUMN, "Event Name Column");
			assertElementPresent(Admin.FILE_NAME_COLUMN, "File Name Column");
			assertElementPresent(Admin.COUNT_COLUMN, "Count Column");
			assertElementPresent(Admin.IS_PROD_COLUMN, "Is Prod Column");
			assertElementPresent(Admin.STATUS_COLUMN, "Status Column");
			assertElementPresent(Admin.UPLOADED_BY_COLUMN, "Uploaded By Column");
			assertElementPresent(Admin.UPDATED_ON_COLUMN, "Updated On Column");

			// Verify Current Filter label
			assertElementPresent(Admin.CURRENT_FILTER_LABEL, "Current Filter Label");

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");
			click(Admin.TEST_RADIO_BTN, "Test Radio Button");
			uploadFile(fileNameOf50Records, Admin.CHOOSE_FILE_BUTTON, "Upload File");

			// Upload the file
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			// Verify the data on the grid
			assertElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
			assertTextMatching(Admin.STATUS, "Uploaded", "Status of the File");
			String eventId = getText(Admin.FIRST_EVENT_ID_ON_GRID, "First Event Id On Grid");
			// assertTextMatching(Admin.FIRST_EVENT_NAME_ON_GRID, delawareEventName, "Event
			// Name On Grid");
			assertTextMatching(Admin.FIRST_FILE_NAME_ON_GRID, fileNameOf50Records, "File Name On Grid");
			assertTextMatching(Admin.FIRST_COUNT_ON_GRID, "--", "Count On Grid");
			assertTextMatching(Admin.FIRST_IS_PROD_ON_GRID, "N", "Is Prod On Grid");
			assertTextMatching(Admin.FIRST_UPLOADED_BY_ON_GRID, "TEST New York SOP Team", "Updated By On Grid");
			// TODO verify updated by
			Thread.sleep(30000);
			refreshPage();
			// isElementNotPresent(Admin.UPLOADED_STATUS, "Staus of the file as uploaded");
			// isElementNotPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On
			// Grid");
			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			click(Admin.BACK_BTN, "Back Button");

			// Verify Delete Functionality
			click(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
			handlepopup();

			// Select Event Id from filter drpdwn
			click(Admin.EVENT_ID_FILTER_DRPDWN, "Select Event Id Filter dropdown");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "=", "Select = from second filter");
			type(Admin.FILTER_TEXT_BOX, eventId, "Filter text Box");
			click(Admin.GO_BTN, "Go Button");

			// Verify No Records Found text
			assertElementPresent(Admin.NO_RECORDS_FOUND_ON_GRID, "No Records Found Text");

		} catch (Exception e) {
			throw e;
		}

	}

	public void addEditDeleteEvent(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String eventName = Excelobject.getCellData(ReportSheet, "Event Name", count);
			String eventType = Excelobject.getCellData(ReportSheet, "Event Type", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String member = Excelobject.getCellData(ReportSheet, "Member", count);
			String editEventName = Excelobject.getCellData(ReportSheet, "Edit Event Name", count);
			String editEventType = Excelobject.getCellData(ReportSheet, "Edit Event Type", count);
			String editEntityType = Excelobject.getCellData(ReportSheet, "Edit Entity Type", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			// Click On Event Manager from left nav link
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");

			// Verify the page title is Event Manager
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");

			// Verify help icon
			assertElementPresent(Admin.HELP_ICON, "Help Icon");

			// Click on add/save btn
			click(Admin.EVENT_ADD_BTN, "Add/Save Button");
			// Verify error messages
			assertElementPresent(Admin.EVENT_NAME_ERR_MSG, "Event Name Error Message");
			assertElementPresent(Admin.EVENT_TYPE_ERR_MSG, "Event Type Error Message");
			assertElementPresent(Admin.ENTITY_TYPE_ERR_MSG, "Entity Type Error Message");

			// Enter Event Name,Event Type,Entity Type
			type(Admin.EVENT_NAME_TEXTBOX, eventName, "Event Name Textbox");
			selectBySendkeys(Admin.EVENT_TYPE_DRPDWN, eventType, "Event Type Dropdown");
			selectBySendkeys(Admin.ENTITY_TYPE_DRPDWN, entityType, "Entity Type Dropdown");
			assertElementPresent(Admin.NO_OPT_OUT_SUPPRESSION__RADIO_BTN, "No is selected for opt out suppression");
			assertElementPresent(Admin.NO_ARMS_SUPPRESSION__RADIO_BTN, "No is selected for arms suppression");
			assertElementPresent(Admin.NO_BFI_CTPRO_SUPPRESSION__RADIO_BTN, "No is selected for bfi/ctpro suppression");
			click(Admin.YES_OPT_OUT_SUPPRESSION__RADIO_BTN, "Yes for opt out suppression");
			click(Admin.YES_ARMS_SUPPRESSION__RADIO_BTN, "Yes for arms suppression");
			click(Admin.YES_BFI_CTPRO_SUPPRESSION__RADIO_BTN, "Yes for bfi/ctpro suppression");
			assertElementPresent(Admin.EVENT_CANCEL_BTN, "Cancel Button");
			click(Admin.EVENT_ADD_BTN, "Add Button");

			// Check Sorting Links
			assertElementPresent(Admin.ACTIVE_UPDATED_ON_SORT_LINK, "Active Updated On Sort Link");
			assertElementPresent(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_EVENT_TYPE_SORT_LINK, "Inactive Event Type Link");
			assertElementPresent(Admin.INACTIVE_ENTITY_TYPE_SORT_LINK, "Inactive Entity Type Sort Link");
			click(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.ACTIVE_EVENT_NAME_SORT_LINK, "Active Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_UPDATED_ON_SORT_LINK, "Inactive Updated On Sort Link");
			click(Admin.INACTIVE_EVENT_TYPE_SORT_LINK, "Inactive Event Type Sort Link");
			assertElementPresent(Admin.ACTIVE_EVENT_TYPE_SORT_LINK, "Active Event Type Link");
			click(Admin.INACTIVE_ENTITY_TYPE_SORT_LINK, "Inactive Entity Type Sort Link");

			// Check Pagination
			assertElementPresent(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");
			assertElementPresent(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			assertElementPresent(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			assertElementPresent(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");

			// Verify Grid Columns
			assertElementPresent(Admin.EVENT_NAME_COLUMN_ON_EVENT_MANAGER, "Event Name Column");
			assertElementPresent(Admin.EVENT_TYPE_COLUMN_ON_EVENT_MANAGER, "Event Type Column");
			assertElementPresent(Admin.ENTITY_TYPE_COLUMN_ON_EVENT_MANAGER, "Entity Type Column");
			assertElementPresent(Admin.UPDATED_BY_COLUMN_ON_EVENT_MANAGER, "Updated By Column");
			assertElementPresent(Admin.UPDATED_ON_COLUMN_ON_EVENT_MANAGER, "Updated On Column");

			// Verify the event added on the grid
			assertTextMatching(Admin.FIRST_EVENT_NAME_ON_EVENT_DETAILS_GRID, eventName, "First Event Name On Grid");
			assertTextMatching(Admin.OPT_OUT_SUPPRESSION_VALUE, "Y", "First Opt Out Suppression Value On Grid");
			assertTextMatching(Admin.FIRST_EVENT_TYPE_ON_EVENT_DETAILS_GRID, eventType, "First Event Type On Grid");
			assertTextMatching(Admin.ARMS_SUPPRESSION_VALUE, "Y", "First ARMS Suppression Value On Grid");
			assertTextMatching(Admin.FIRST_ENTITY_TYPE_ON_EVENT_DETAILS_GRID, entityType, "First Entity Type On Grid");
			assertTextMatching(Admin.BFI_CTPRO_SUPPRESSION_VALUE, "Y", "First Bfi/Ctpro Suppression Value On Grid");
			assertTextMatching(Admin.FIRST_UPDATED_BY_ON_EVENT_DETAILS_GRID, member, "First Updated By On Grid");
			assertElementPresent(Admin.FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID, "First Edit Button On Grid");
			assertElementPresent(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First Delete Button On Grid");
			Thread.sleep(5000);

			// Edit Event
			click(Admin.FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID, "First Edit Button On Grid");
			type(Admin.EVENT_NAME_TEXTBOX, editEventName, "Event Name Textbox");
			selectBySendkeys(Admin.EVENT_TYPE_DRPDWN, editEventType, "Event Type Dropdown");
			selectBySendkeys(Admin.ENTITY_TYPE_DRPDWN, editEntityType, "Entity Type Dropdown");
			click(Admin.EVENT_ADD_BTN, "Add Button");
			Thread.sleep(5000);
			refreshPage();
			assertTextMatching(Admin.FIRST_EVENT_NAME_ON_EVENT_DETAILS_GRID, editEventName, "First Event Name On Grid");
			assertTextMatching(Admin.FIRST_EVENT_TYPE_ON_EVENT_DETAILS_GRID, editEventType, "First Event Type On Grid");
			assertTextMatching(Admin.FIRST_ENTITY_TYPE_ON_EVENT_DETAILS_GRID, editEntityType,
					"First Entity Type On Grid");

			// Upload a file for this event on file and event selection page
			// Click On File & Event Selection link from left nav bar
			click(Admin.FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK, "File & Event Selection Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");
			selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, editEventName,
					"Select a Delaware Event from delaware event drop down box");

			// Upload 1 kb File
			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(2000);
			// Check There is no delete button on event manager page for this event
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");
			// isElementNotPresent(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First
			// Delete Button On Grid");
			verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First Delete Button On Grid");
			click(Admin.FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID, "First Edit Button On Grid");
			// Edit this event
			getAttribute(Admin.EVENT_NAME_TEXTBOX, "disabled");
			getAttribute(Admin.EVENT_TYPE_DRPDWN, "disabled");
			getAttribute(Admin.ENTITY_TYPE_DRPDWN, "disabled");
			click(Admin.NO_OPTOUT_SUPPRESSION__RADIO_BTN, "No is selected for opt out suppression");
			click(Admin.EVENT_ADD_BTN, "Add/save Button");
			assertTextMatching(Admin.OPT_OUT_SUPPRESSION_VALUE, "N", "First Opt Out Suppression Value On Grid");

			Thread.sleep(2000);
			// Delete the file uploaded on file and event selection page
			// Click On File & Event Selection link from left nav bar
			click(Admin.FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK, "File & Event Selection Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;
				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Delete the file
			click(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
			handlepopup();

			// Delete the event
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");
			click(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First Delete Button On Grid");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

	public void filesUploadOnOutputFilesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware
			// Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String fileNames = Excelobject.getCellData(ReportSheet, "File Names", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 2,
					"Select a Delaware Event from delaware event drop down box");
			// selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, editEventName,
			// "Select a Delaware Event from delaware event drop down box");

			// Upload 1 kb File
			uploadFile(fileNames, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(5000);

			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;
				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Click on First View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");

			if (fileName.contains("More than 0 KB")) {
				// Upload More than 0 kb csv File
				uploadFile(fileName, Admin.CHOOSE_FILE_BTN, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				// click(Admin.PRINTER_ACKNOWLEDGE_FILE, "Printer Acknowledge File");
				assertElementPresent(Admin.CREATE_COMM_BTN, "Create COMM Button");
				click(Admin.DELETE_IMG, "Delete Image");
				handlepopup();
				assertElementPresent(Admin.CHOOSE_FILE_BTN, "Choose File Button");

			} else if (fileName.contains("0 KB")) {
				// Upload 0 kb File
				uploadFile(fileName, Admin.CHOOSE_FILE_BTN, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				assertTextMatching(Admin.ERROR, "Select a valid CSV file.", "Error");
			} else if (fileName.contains("Invalid CSV File")) {
				// Upload an invalid File
				uploadFile(fileName, Admin.CHOOSE_FILE_BTN, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				assertTextMatching(Admin.ERROR, "Select a CSV file.", "Error");

			}
		} catch (Exception e) {
			throw e;
		}

	}

	/********************************************************************************************************
	 * Method Name : adminCESMLSliderPage() Author : Vrushali Kakade Description :
	 * This method will verify if ML Slider is displayed in CES screen Date of
	 * creation : 6/19/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void adminCESMLSliderPage(String ReportSheet, int count) throws Throwable {
		try {

			// Click on Admin Module
			click(HomePage.ADMINLINK, "Admin Link");

			// Verify Whether New section 'Manage CES ML Slider Fields' on the
			// left nav
			// And click on 'Manage CES ML Slider Fields' link
			assertElementPresent(Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			click(Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");

			// Verify Title of the page is Manage CES ML Slider Fields
			assertTextMatching(Admin.MANAGECESMLSLIDERFIELDSPAGE, "Manage CES ML Slider Fields", "Title of the page");

			// Verify the page has 2 blocks - CES ML Slider Fields and Maintain
			// CES ML
			// Slider Fields
			// and save & cancel buttons at the bottom
			isElementPresent(Admin.CESMLSLIDERFIELDSBLOCK, "CES ML Slider Fields Block");
			isElementPresent(Admin.MAINTAINCESMLSLIDERFIELDSBLOCK, "Maintain CES ML Slider Fields Block");
			isElementPresent(Admin.SAVEBTN, "Save Button");
			isElementPresent(Admin.CANCELBTN, "Cancel Button");

			// CES ML Slider Fields block has 3 fields- Case#,lawsuit type and
			// lawsuitsubtype
			assertElementPresent(Admin.CASEIDFIELD, "Case #");
			assertElementPresent(Admin.LAWSUITTYPEFIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(Admin.LAWSUITSUBTYPEFIELD, "LAWSUIT SUB TYPE FIELD");

			// Maintain CES ML Slider Fields block has 2 fields- Index and Name
			assertTextMatching(Admin.INDEXFIELD, "Index", "Verify 1st col is Index");
			assertTextMatching(Admin.NAMEFIELD, "Name", "Verify 2nd col is Name");

			// Verify Fields can be moved within CES ML Slider Fields block
			draggable(Admin.LAWSUITTYPEFIELD, 0, 150, "LAWSUIT TYPE FIELD DRAG AND DROP");
			click(Admin.SAVEBTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void editEntityBundle(String ReportSheet, int count) throws Throwable {
		try {
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnEntity("Reparms Bundle", "Yes");

			// Verify Bundle Name on entity profile page
			assertTextMatching(Entity.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnEntity("Reparms Bundle", "No");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "No", "Verify  the value of Plus Disbursements label is No");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Rep and Annual Report Bundle
			updatePlusDisbursementOnEntity("Rep and Annual Report", "Yes");

			// Verify Bundle Name on entity profile page
			assertTextMatching(Entity.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Rep and Annual Report Bundle
			updatePlusDisbursementOnEntity("Rep and Annual Report", "No");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "No", "Verify  the value of Plus Disbursements label is No");

		} catch (Exception e) {
			throw e;
		}
	}

	public void editSubGroupBundle(String ReportSheet, int count) throws Throwable {
		try {
			String strId = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Navigate to Affiliation Sub Groups Page
			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Reparms Bundle", "Yes");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on Sub Group profile View page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Reparms Bundle", "No");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on Sub Group profile View page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "No",
					"Verify  the value of Plus Disbursements label is No");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Rep and Annual Report", "Yes");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on entity profile page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Rep and Annual Report", "No");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on entity profile page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "No",
					"Verify  the value of Plus Disbursements label is yes");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addBundleDisbursement(String ReportSheet, int count) throws Throwable {
		try {

			String dsItemNumber = Excelobject.getCellData(ReportSheet, "E1 DS Item Number", count);
			String dsDescription = Excelobject.getCellData(ReportSheet, "DS Description", count);
			String invalidDSItemNumber = Excelobject.getCellData(ReportSheet, "Invalid DS Item Number", count);
			String validDSItemNumber = Excelobject.getCellData(ReportSheet, "Valid DS Item Number", count);
			String editDSDescription = Excelobject.getCellData(ReportSheet, "Edit DS Description", count);
			List<String> originalrepAndAnnualReportServiceList = new ArrayList<String>();
			List<String> originalRepArmsBundleServiceList = new ArrayList<String>();
			List<String> repAndAnnualReportServiceList = Arrays.asList("-- Select One --",
					"Domestic Registered Agent Plus (Registered Series LLC)",
					"Domestic Registered Agent Plus Public Benefit LLC)",
					"Domestic Registered Agent Plus Service (Business Corp)",
					"Domestic Registered Agent Plus Service (Gen. Ptnshp)",
					"Domestic Registered Agent Plus Service (LLC)", "Domestic Registered Agent Plus Service (LLP)",
					"Domestic Registered Agent Plus Service (LP)",
					"Domestic Registered Agent Plus Service (Non-Profit)", "Domestic Rep/ARMS (Registered Series LLC)",
					"Domestic Rep/ARS (RSLP)", "Domestic Rep/ARS (SBLP)", "Domestic Rep/ARS (SLP)",
					"Domestic Rep/ARS (ST)", "Foreign Registered Agent Plus Service (Business Corp)",
					"Foreign Registered Agent Plus Service (Gen. Ptnshp)",
					"Foreign Registered Agent Plus Service (LLC)", "Foreign Registered Agent Plus Service (LLP)",
					"Foreign Registered Agent Plus Service (LP)", "Foreign Registered Agent Plus Service (Non-Profit)");
			List<String> repArmsBundleServiceList = Arrays.asList("-- Select One --",
					"Domestic Rep/ARMS (Business Corp)", "Domestic Rep/ARMS (Gen. Ptnshp)", "Domestic Rep/ARMS (LLC)",
					"Domestic Rep/ARMS (LLP)", "Domestic Rep/ARMS (LP)", "Domestic Rep/ARMS (Non-Profit)","Domestic Rep/ARMS (Public Benefit LLC)",
					"Domestic Rep/ARMS (RSLP)", "Domestic Rep/ARMS (SBLP)", "Domestic Rep/ARMS (SLP)",
					"Domestic Rep/ARMS (ST)", "Foreign Rep/ARMS (Business Corporation)",
					"Foreign Rep/ARMS (Gen. Ptnshp)", "Foreign Rep/ARMS (LLC)", "Foreign Rep/ARMS (LLP)",
					"Foreign Rep/ARMS (LP)", "Foreign Rep/ARMS (Non-Profit)");

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Click on Bundle Disbursements Maintainance left nav Link
			click(Admin.BUNDLE_DISBURSEMENTS_MAINTAINANCE_LEFT__NAV_LINK,
					"Bundle Disbursements Maintainance left nav Link");

			// Verify the page title is Bundles Disbursements Maintenance
			assertTextMatching(Admin.PAGE_TITLE, "Bundles Disbursements Maintenance", "Verify the page title");
			// Click on Add Button
			click(Admin.ADD_BTN, "Click On add button");

			// Verify Error Msgs
			assertTextMatching(Admin.BUNDLE_ERR_MSG, "Select a Bundle.", "Error Message when bundle is not selected");
			assertTextMatching(Admin.SERVICE_ERR_MSG, "Select a Service.",
					"Error Message when Service is not selected");
			assertTextMatching(Admin.JURISDICTION_ERR_MSG, "Select a Jurisdiction.",
					"Error Message when Jurisdiction is not selected");

			// Select Rep and Annual Report from dropdown
			click(Admin.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from bundle dropdown");

			List<WebElement> arr = getAllDropDownData(Admin.SERVICE_DROPDOWN);

			Iterator<WebElement> iter = arr.iterator();

			while (iter.hasNext()) {
				WebElement we = iter.next();

				originalrepAndAnnualReportServiceList.add(we.getText());
			}

			compareTwoArrayList(repAndAnnualReportServiceList, originalrepAndAnnualReportServiceList);

			// Select RepArms Bundle from bundle dropdown
			click(Admin.REPARMS_BUNDLE_DRPDWN, "Select REPARMS Bundle from bundle dropdown");

			List<WebElement> array = getAllDropDownData(Admin.SERVICE_DROPDOWN);

			Iterator<WebElement> itr = array.iterator();

			while (itr.hasNext()) {
				WebElement we = itr.next();

				originalRepArmsBundleServiceList.add(we.getText());
			}

			compareTwoArrayList(repArmsBundleServiceList, originalRepArmsBundleServiceList);

			// Select first value from sevice dropdown
			selectByIndex(Admin.SERVICE_DROPDOWN, 1, "Select first Value from Service DropDown");

			// Check Whether All radio buttons for jurisdiction are present
			isElementPresent(Admin.US_RADIO_BTN, "US Radio Button");
			isElementPresent(Admin.CANADA_RADIO_BTN, "Canada Radio Button");
			isElementPresent(Admin.INTERNATIONAL_RADIO_BTN, "International Radio Button");

			// Select first value from jurisdiction dropdown
			selectByIndex(Admin.JURIS_DRP_DWN, 1, "Select first Value from Jurisdiction DropDown");

			// Click on Add Button
			click(Admin.ADD_BTN, "Click On add button");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			// Verify Error Msgs
			assertTextMatching(Admin.DS_ITEM_NUMBER_ERR_MSG, "Enter a value for E1 DS Item Number.",
					"Error Message when E1 DS Item Number is not entered");
			assertTextMatching(Admin.DS_DESCRIPTION_ERR_MSG, "Enter a value for DS Service Description.",
					"Error Message when Service Description. is not entered");

			// Enter a DS Item Number and DS Service Description
			type(Admin.DS_ITEM_NUMBER_TEXTBOX, dsItemNumber, "DS Item Number TextBox");
			type(Admin.DS_DESCRIPTION_TEXTBOX, dsDescription, "DS Description TextBox");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			String substringDSItemNumber = dsItemNumber.substring(0, 9);
			String substringDSDescription = dsDescription.substring(0, 59);

			// Verify E1 DS Item Number and DS Description on grid
			assertTextMatching(Admin.E1_DS_ITEM_NUMBER_ON_GRID, substringDSItemNumber, "DS Item Number On Grid");
			assertTextMatching(Admin.DS_DESCRIPTION_ON_GRID, substringDSDescription, "DS Description On Grid");

			// Click On edit Button
			click(Admin.FIRST_EDIT_BUTTON_ON_GRID, "Edit Button");

			// Enter an invalid DS Item Number
			type(Admin.DS_ITEM_NUMBER_TEXTBOX, invalidDSItemNumber, "DS Item Number TextBox");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			// Verify Error Msg for entering invalid DS Item Number
			assertTextMatching(Admin.DS_INVALID_ITEM_NUMBER_ERR_MSG, "Enter a positive number for E1 DS Item Number.",
					"Error Message when invalid E1 DS Item Number is entered");

			// Enter an invalid DS Item Number
			type(Admin.DS_ITEM_NUMBER_TEXTBOX, validDSItemNumber, "DS Item Number TextBox");
			type(Admin.DS_DESCRIPTION_TEXTBOX, editDSDescription, "DS Description TextBox");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			// Verify E1 DS Item Number and DS Description on grid
			assertTextMatching(Admin.E1_DS_ITEM_NUMBER_ON_GRID, validDSItemNumber, "DS Item Number On Grid");
			assertTextMatching(Admin.DS_DESCRIPTION_ON_GRID, editDSDescription, "DS Description On Grid");

			// Click On Delete Button
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");

			// Handle Popup
			handlepopup();

		} catch (Exception e) {
			throw e;
		}
	}

	public void updatePlusDisbursementOnEntity(String BundleName, String plusDisbursement) throws Throwable {
		try {
			if (BundleName.equalsIgnoreCase("Reparms Bundle")) {
				// select Reparms bundle from bundle dropdown
				click(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Entity.EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// uncheck Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");
				}

			} else if (BundleName.equalsIgnoreCase("Rep and Annual Report")) {
				// select Rep and Annual Report from bundle dropdown
				click(Entity.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Entity.EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// uncheck Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");

				}

			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void navigateToInactiveBundleSubGroupsPage() throws Throwable {
		try {
			// Navigate to Sub Group Bundle Maintainance Page
			click(Affiliation.SUB_GROUP_BUNDLE_MAINTAINANCE, "Sub Group Bundle Maintainance Left Nav link");

			// Click On Inactive Bundle Subgroups Tab
			click(Affiliation.INACTIVE_BUNDLE_SUBGROUPS_TAB, "Inactive Bundle Subgroups Tab");

		} catch (Exception e) {
			throw e;
		}
	}

	public void updatePlusDisbursementOnSubGroup(String BundleName, String plusDisbursement) throws Throwable {
		try {
			if (BundleName.equalsIgnoreCase("Reparms Bundle")) {
				// select Reparms bundle from bundle dropdown
				click(Affiliation.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Affiliation.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				}

			} else if (BundleName.equalsIgnoreCase("Rep and Annual Report")) {
				// select Rep and Annual Report from bundle dropdown
				click(Affiliation.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN,
						"Select Rep and Annual Report from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Affiliation.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				}

			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void navigateToRenewalTypeSubGroup() throws Throwable {
		try {
			// Navigate to Affiliation Sub Groups Page
			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");

			// Select Sub group type from first filter and Renewal from second
			// filter and
			// click on go button
			click(Affiliation.SUB_GROUP_TYPE, "Select Sub group type from first filter");
			click(Affiliation.RENEWAL, "Select Renewal from second filter");
			click(Affiliation.GOBTN, "Go Button");

			// Select First Subgroup from grid
			click(Affiliation.FIRSTRESULTONSEARCHPAGE, "Select first Subgroup on grid");

		} catch (Exception e) {
			throw e;
		}
	}

	// Below Function is added as part of CEs enhancement Rejection workflow changes
	/*public void rejectionRulesMaintenanceApplication(String reportSheet, int count) throws Throwable {
		try {

			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);
			// ADMIN_TAB
			waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			click(Admin.ADMIN_TAB, "Admin Tab in the header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			click(Admin.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			// PAGE_TITLE
			waitForElementPresent(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			assertElementPresent(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			String pageTitle = getText(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			// US_RADIO_BTN
			waitForElementPresent(Admin.US_RADIO_BTN, "US Radio button");
			assertElementPresent(Admin.US_RADIO_BTN, "US Radio button");
			waitForElementPresent(Admin.US_LABEL, "US label");
			assertElementPresent(Admin.US_LABEL, "US label");
			// CANADA_RADIO_BTN
			waitForElementPresent(Admin.CANADA_RADIO_BTN, "Canada Radio button");
			assertElementPresent(Admin.CANADA_RADIO_BTN, "canada Radio button");
			waitForElementPresent(Admin.CANADA_LABEL, "Canada label");
			assertElementPresent(Admin.CANADA_LABEL, "canada label");
			waitForElementPresent(Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
			assertElementPresent(Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
			waitForElementPresent(Admin.INTERNATIONAL_LABEL, "International label");
			assertElementPresent(Admin.INTERNATIONAL_LABEL, "International label");
			// JURIS_DRP_DWN
			waitForElementPresent(Admin.JURIS_DRP_DWN, "Jurisdiction drop down");
			assertElementPresent(Admin.JURIS_DRP_DWN, "Jurisdiction drop down");
			// ADD_BUTTON
			waitForElementPresent(Admin.ADD_BUTTON, "Add button in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.ADD_BUTTON, "Add button in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.SORT_BY_JURISDICTION_LABEL,
					"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.SORT_BY_JURISDICTION_LABEL,
					"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.SORT_BY_MODIFIED_BY_LABEL,
					"Sort by Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.SORT_BY_MODIFIED_BY_LABEL,
					"Sort by Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.SORT_BY_MODIFIED_DATE_LABEL,
					"Sort by Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.SORT_BY_MODIFIED_DATE_LABEL,
					"Sort by Modified Date in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.TABLE_HEADER_JURISDICTION,
					"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.TABLE_HEADER_JURISDICTION,
					"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.TABLE_HEADER_MODIFIED_BY,
					"Table header Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.TABLE_HEADER_MODIFIED_BY,
					"Table header Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.TABLE_HEADER_MODIFIED_DATE,
					"Table header Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.TABLE_HEADER_MODIFIED_DATE,
					"Table header Modified Date in SOP Rejection Rules Maintenance");
			// FIRST_EDIT_BUTTON
			waitForElementPresent(Admin.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			click(Admin.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			// REJECTION_RULE_DROP_DOWN
			waitForElementPresent(Admin.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(Admin.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");

			if (addEditOrDel.equals("Add")) {
				selectByVisibleText(Admin.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			} else if (addEditOrDel.equals("Edit")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(Admin.REJECTION_RULE1_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(Admin.REJECTION_RULE2_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}
			} else if (addEditOrDel.equals("Delete")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(Admin.REJECTION_RULE1_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
					Thread.sleep(1000);
					handlepopup();
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(Admin.REJECTION_RULE2_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
					Thread.sleep(1000);
					handlepopup();
				}

			}
			// STATUS_TEXT_FIELD
			waitForElementPresent(Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			type(Admin.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
			waitForElementPresent(Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			type(Admin.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
			if (addEditOrDel.equals("Add")) {
				click(Admin.ADD_BTN, "Add button in SOP Rejection Rules by Jurisdiction");
			} else if (addEditOrDel.equals("Edit")) {
				click(Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
			}

		} catch (Exception e) {
		}
	}
*/
	
	public void rejectionRulesMaintenanceApplication(String reportSheet, int count) throws Throwable {
		try {
			
			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);        
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);		

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
			click(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
			//PAGE_TITLE
			waitForElementPresent(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
			assertElementPresent(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
			String pageTitle = getText(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance",pageTitle);
			//US_RADIO_BTN
			waitForElementPresent(SOP.US_RADIO_BTN,"US Radio button");
			assertElementPresent(SOP.US_RADIO_BTN,"US Radio button");
			waitForElementPresent(SOP.US_LABEL,"US label");
			assertElementPresent(SOP.US_LABEL,"US label");
			//CANADA_RADIO_BTN
			waitForElementPresent(SOP.CANADA_RADIO_BTN,"Canada Radio button");
			assertElementPresent(SOP.CANADA_RADIO_BTN,"canada Radio button");	
			waitForElementPresent(SOP.CANADA_LABEL,"Canada label");
			assertElementPresent(SOP.CANADA_LABEL,"canada label");		
			waitForElementPresent(SOP.INTERNATIONAL_RADIO_BTN,"International Radio button");
			assertElementPresent(SOP.INTERNATIONAL_RADIO_BTN,"International Radio button");
			waitForElementPresent(SOP.INTERNATIONAL_LABEL,"International label");
			assertElementPresent(SOP.INTERNATIONAL_LABEL,"International label");
			//JURIS_DRP_DWN
			waitForElementPresent(SOP.JURIS_DRP_DWN,"Jurisdiction drop down");
			assertElementPresent(SOP.JURIS_DRP_DWN,"Jurisdiction drop down");
			//ADD_BUTTON
			waitForElementPresent(SOP.ADD_BUTTON,"Add button in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.ADD_BUTTON,"Add button in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.SORT_BY_JURISDICTION_LABEL,"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.SORT_BY_JURISDICTION_LABEL,"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.SORT_BY_MODIFIED_BY_LABEL,"Sort by Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.SORT_BY_MODIFIED_BY_LABEL,"Sort by Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.SORT_BY_MODIFIED_DATE_LABEL,"Sort by Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.SORT_BY_MODIFIED_DATE_LABEL,"Sort by Modified Date in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.TABLE_HEADER_JURISDICTION,"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.TABLE_HEADER_JURISDICTION,"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.TABLE_HEADER_MODIFIED_BY,"Table header Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.TABLE_HEADER_MODIFIED_BY,"Table header Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.TABLE_HEADER_MODIFIED_DATE,"Table header Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.TABLE_HEADER_MODIFIED_DATE,"Table header Modified Date in SOP Rejection Rules Maintenance");
			//FIRST_EDIT_BUTTON
			waitForElementPresent(SOP.FIRST_EDIT_BUTTON,"First Edit button in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.FIRST_EDIT_BUTTON,"First Edit button in SOP Rejection Rules Maintenance");
			click(SOP.FIRST_EDIT_BUTTON,"First Edit button in SOP Rejection Rules Maintenance");
			//REJECTION_RULE_DROP_DOWN
			waitForElementPresent(SOP.REJECTION_RULE_DROP_DOWN,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(SOP.REJECTION_RULE_DROP_DOWN,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			
			if(addEditOrDel.equals("Add")) {
				selectByVisibleText(SOP.REJECTION_RULE_DROP_DOWN,ruleText,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			}
			else if (addEditOrDel.equals("Edit")) {
			
				if(ruleText.equals("SOS/Arrow Entity Statuses")) {

				click(SOP.REJECTION_RULE1_FIRST_EDIT,"First Edit button in SOP Rejection Rules Maintenance");	
				}

				else if(ruleText.equals("Post Descriptive - Take or Reject")){

				click(SOP.REJECTION_RULE2_FIRST_EDIT,"First Edit button in SOP Rejection Rules Maintenance");	
				}
			}
			else if (addEditOrDel.equals("Delete")) {
			
				if(ruleText.equals("SOS/Arrow Entity Statuses")) {

				click(SOP.REJECTION_RULE1_FIRST_DELETE,"First Delete button in SOP Rejection Rules Maintenance");
				Thread.sleep(1000);
				handlepopup();
				}

				else if(ruleText.equals("Post Descriptive - Take or Reject")){

				click(SOP.REJECTION_RULE2_FIRST_DELETE,"First Delete button in SOP Rejection Rules Maintenance");
				Thread.sleep(1000);
				handlepopup();
				}
				
				
			}
			//STATUS_TEXT_FIELD
			waitForElementPresent(SOP.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
			type(SOP.STATUS_TEXT_FIELD,status,"Status text field in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
			type(SOP.ACTION_TEXT_FIELD,action,"Status text field in SOP Rejection Rules Maintenance");
			if(addEditOrDel.equals("Add")) {
				click(SOP.ADD_BTN,"Add button in SOP Rejection Rules by Jurisdiction");
			}
			else if(addEditOrDel.equals("Edit")) {
				click(SOP.SAVE_BUTTON,"Save button in SOP Rejection Rules by Jurisdiction");	
			}
			
		}
		catch (Exception e) {
		}
	 }

	
//Below function is added as part of CES enhancement Rejection workflow
	public void selectTheJurisdictionAndEdit(String reportSheet, int count) throws Throwable {
		try {
			
			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);        
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);
			String state = Excelobject.getCellData(reportSheet, "State", count);
			String jurisId = Excelobject.getCellData(reportSheet, "Juris Id", count);
			String ruleType = Excelobject.getCellData(reportSheet, "Rule Type", count);
			String selectJurisdiction = Excelobject.getCellData(reportSheet, "Select Jurisdiction", count);
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
			click(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
			//PAGE_TITLE
			waitForElementPresent(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
			assertElementPresent(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
			String pageTitle = getText(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance",pageTitle);
			if(selectJurisdiction.equals("US")) {
			//US_RADIO_BTN
			waitForElementPresent(Admin.US_RADIO_BTN,"US Radio button");
			assertElementPresent(Admin.US_RADIO_BTN,"US Radio button");
			click(Admin.US_RADIO_BTN,"US Radio button");
			}
			//CANADA_RADIO_BTN
			else if(selectJurisdiction.equals("Canada")) {
			waitForElementPresent(Admin.CANADA_RADIO_BTN,"Canada Radio button");
			assertElementPresent(Admin.CANADA_RADIO_BTN,"canada Radio button");
			click(Admin.CANADA_RADIO_BTN,"canada Radio button");
			}
			else if(selectJurisdiction.equals("International")) {		
			waitForElementPresent(Admin.INTERNATIONAL_RADIO_BTN,"International Radio button");
			assertElementPresent(Admin.INTERNATIONAL_RADIO_BTN,"International Radio button");
			click(Admin.INTERNATIONAL_RADIO_BTN,"International Radio button");
			}
			//("//span[contains(text(),'Quebec')]/parent::td/following-sibling::td/a/img")
			By editButton =  By.xpath("//span[contains(text(),'"+state+"')]/parent::td/following-sibling::td/a/img");		
			waitForElementPresent(editButton,"Edit button for the selected State in SOP Rejection Rules Maintenance");
			assertElementPresent(editButton,"Edit button for the selected state in SOP Rejection Rules Maintenance");
			click(editButton,"Edit button for the selected state in SOP Rejection Rules Maintenance");
			//REJECTION_RULE_DROP_DOWN
			waitForElementPresent(Admin.REJECTION_RULE_DROP_DOWN,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(Admin.REJECTION_RULE_DROP_DOWN,"Rejection Rule in SOP Rejection Rules by Jurisdiction");		
			if(addEditOrDel.equals("Add")) {
				selectByVisibleText(Admin.REJECTION_RULE_DROP_DOWN,ruleText,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
				waitForElementPresent(Admin.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				type(Admin.STATUS_TEXT_FIELD,status,"Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(Admin.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				type(Admin.ACTION_TEXT_FIELD,action,"Status text field in SOP Rejection Rules Maintenance");
				//ADD_BTN
				waitForElementPresent(Admin.ADD_BTN,"Add button in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.ADD_BTN,"Add button in SOP Rejection Rules Maintenance");
				click(Admin.ADD_BTN,"Add button in SOP Rejection Rules Maintenance");
				Thread.sleep(1000);
				ArrayList<String> actionStatus = SQL_Queries.getTheStatusAndActionForRejectionRule(jurisId,ruleType);
				compareStrings(status,actionStatus.get(0));
				compareStrings(action,actionStatus.get(1));				
				}	
			else if (addEditOrDel.equals("Edit")) {
			
				if(ruleText.equals("SOS/Arrow Entity Statuses")) {

				click(Admin.REJECTION_RULE1_FIRST_EDIT,"First Edit button in SOP Rejection Rules Maintenance");	
				}

				else if(ruleText.equals("Post Descriptive - Take or Reject")){

				click(Admin.REJECTION_RULE2_FIRST_EDIT,"First Edit button in SOP Rejection Rules Maintenance");	
				}
				selectByVisibleText(Admin.REJECTION_RULE_DROP_DOWN,ruleText,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
				waitForElementPresent(Admin.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				type(Admin.STATUS_TEXT_FIELD,status,"Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(Admin.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
				type(Admin.ACTION_TEXT_FIELD,action,"Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(Admin.SAVE_BUTTON,"Save button in SOP Rejection Rules by Jurisdiction");
				assertElementPresent(Admin.SAVE_BUTTON,"Save button in SOP Rejection Rules by Jurisdiction");
				click(Admin.SAVE_BUTTON,"Save button in SOP Rejection Rules by Jurisdiction");
				ArrayList<String> actionStatus = SQL_Queries.getTheStatusAndActionForRejectionRule(jurisId,ruleType);
				compareStrings(status,actionStatus.get(0));
				compareStrings(action,actionStatus.get(1));	
			}
			else if (addEditOrDel.equals("Delete")) {
			
				ArrayList<String> countBeforeDeletingTheRule = SQL_Queries.countBeforeDeletingTheRule(jurisId, ruleType);
				if(ruleText.equals("SOS/Arrow Entity Statuses")) {
				click(Admin.REJECTION_RULE1_FIRST_DELETE,"First Delete button in SOP Rejection Rules Maintenance");
				}
				else if(ruleText.equals("Post Descriptive - Take or Reject")){
				click(Admin.REJECTION_RULE2_FIRST_DELETE,"First Delete button in SOP Rejection Rules Maintenance");
				}
				Thread.sleep(1000);
				handlepopup();
				Thread.sleep(1000);			
				printMessageInReport("The count of Rule before deleting : " + countBeforeDeletingTheRule);			
				printMessageInReport("The count of Rule after deleting : " + SQL_Queries.countAfterDeletingTheRule(jurisId, ruleType));			
							
			}		
		}
		catch (Exception e) {
		}
	 }

	public void rejectionRulesMaintenanceRole(String reportSheet, int count) throws Throwable {
		try {
			String role = Excelobject.getCellData(reportSheet, "Role", count);
			// ADMIN_TAB
			waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			click(Admin.ADMIN_TAB, "Admin Tab in the header");
			// FIRST_FILTER_DRPDWN
			waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
			assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
			selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
			// SECOND_FILTER_DRPDWN
			waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
			assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
			selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
			// FILTER_TEXT_FILED
			waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
			assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
			type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
			// GO_BTN
			waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
			assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
			click(Admin.GO_BTN, "Go Button in Roles Page");
			// FIRST_ROLE_ON_THE_GRID
			waitForElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			click(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			// EDIT_BTN
			waitForElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
			assertElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
			click(Admin.EDIT_BTN, "Edit button link in Roles Page");
			Thread.sleep(1000);
			// need to pass arg for check and un check
			String checkedRjectionRuleMaintenance = null;
			try {

				checkedRjectionRuleMaintenance = getAttribute(Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX, "checked");

			} catch (NoSuchElementException e) {
			}
			// REJECTION_RULE_MAINTENANCE_CHECK_BOX
			assertElementPresent(Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX,
					"Rejection Rules Maintenance check box in Roles Page");
			click(Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX, "Rejection Rules Maintenance check box in Roles Page");
			// SAVEBTN
			waitForElementPresent(Admin.SAVEBTN, "save button link in Roles Page");
			assertElementPresent(Admin.SAVEBTN, "save button link in Roles Page");
			click(Admin.SAVEBTN, "save button link in Roles Page");
			Thread.sleep(1000);
			if (checkedRjectionRuleMaintenance != null) {
				waitForElementPresent(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin");
				assertElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
				compareStrings("No permissions",
						getText(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin"));
			} else if (checkedRjectionRuleMaintenance == null) {
				waitForElementPresent(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin");
				assertElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
				compareStrings("Rejection Rules Maintenance",
						getText(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin"));
			}
			Thread.sleep(5000);

		} catch (Exception e) {
		}
	}

	public void rejectionRulesMaintenanceAccess(String reportSheet, int count) throws Throwable {
		try {
			String permission = Excelobject.getCellData(reportSheet, "Permission", count);
			// ADMIN_TAB
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			click(Admin.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			Thread.sleep(1000);
			driver.navigate().back();
			Thread.sleep(3000);
			driver.navigate().forward();
			if (permission.equals("Y")) {
				// PAGE_TITLE
				waitForElementPresent(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				assertElementPresent(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				String pageTitle = getText(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			} else if (permission.equals("N")) {
				// SECURITY_ERROR
				waitForElementPresent(Admin.SECURITY_ERROR, "Rejection Rule Maintenance Page Title");
				// assertElementPresent(Admin.SECURITY_ERROR,"Rejection Rule Maintenance Page
				// Title");
				compareStrings("Security Error Occurred",
						getText(Admin.SECURITY_ERROR, "Rejection Rule Maintenance Page Title"));
			}
		} catch (Exception e) {
		}
	}
}
