package com.arrow.workflows;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Communication;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_COMM extends BusinessFunctions {

	public void searchByLogId(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String logId = Excelobject.getCellData(ReportSheet, "Log Id", count);
			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Enter Log ID and click on search button
			type(Communication.LOG_ID_TEXTBOX, logId, "Log Id Text box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void searchByLogIdAndDate(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String logId = Excelobject.getCellData(ReportSheet, "Log Id", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Enter Log ID and click on search button
			type(Communication.LOG_ID_TEXTBOX, logId, "Log Id Text box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Verify log id entered is present on the page
			assertTextMatching(Communication.LOG_ID_ON_CONTEXT_BAR, logId, "LogId On Context bar");
			// Verify received date
			isElementPresent(Communication.RECEIVED_DATE_ON_WORKSHEET_PROFILE,
					"Received Date On Worksheet Profile Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void searchByEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String receivedDateFrom = Excelobject.getCellData(ReportSheet, "Received Date From", count);
			String receivedDateTo = Excelobject.getCellData(ReportSheet, "Received Date To", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Click on Entity select button
			click(Communication.ENTITY_SELECT_BTN, "Entity Select Button");
			// Enter Entity Name and click on search button
			type(Communication.ENTITY_NAME_TEXTBOX, entityName, "Entity Name Textbox");
			click(Communication.SEARCH_BTN, "Search Button");
			// Select first entity on grid
			click(Communication.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity on Grid");
			// Enter received date from and received date to and click on search button
			type(Communication.RECEIVED_DATE_FROM, receivedDateFrom, "Received Date From Text box");
			type(Communication.RECEIVED_DATE_TO, receivedDateTo, "Received Date To Text box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Click on first log id on grid
			click(Communication.FIRST_LOG_ON_GRID, "First Log on Grid");
			// Verify entity name selected is displayed on the context bar
			assertTextMatching(Communication.ENTITY_NAME_ON_CONTEXT_BAR, entityName, "Entity Name On Context Bar");

		} catch (Exception e) {
			throw e;
		}

	}

	public void createWorksheet(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Click on create worksheet button
			click(Communication.CREATE_WORKSHEET_BTN, "Create Worksheet Button");
			// Enter Received date
			// Click on Calendar icon and select todays date
			click(Communication.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Select Communication Jurisdiction
			selectByIndex(Communication.COMMUNICATION_JURISDICTION_DRPDWN, 1, "Comm Jurisdiction Dropdown");
			// Select regular mail from method of service drp dwn
			selectByIndex(Communication.METHOD_OF_SERVICE_DRPDWN, 1, "Method Of Service Dropdown");
			waitForElementPresent(Communication.POST_MARKED_CALENDAR, "Calendar Icon");
			// Click on Calendar icon and select todays date
			click(Communication.POST_MARKED_CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Click On Entity Select Btn
			click(Communication.ENTITY_SELECT, "Entity Select Button");
			type(Communication.ENTITY_NAME_TEXTBOX, entityName, "Entity Name Text Box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Select first entity on grid
			click(Communication.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity on Grid");
			// Click on Unidentified Rep Radio Button
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			// Select First value from document type drpdwn
			selectByIndex(Communication.DOCUMENT_TYPE_DRPDWN, 1, "Select first value from Document Type Dropdown");
			// Select Alabama as Document Jurisdiction
			selectByIndex(Communication.DOCUMENT_JURISDICTION, 1, "Document Jurisdiction Drpdwn");
			// Select First value from document source drpdwn
			selectByIndex(Communication.DOCUMENT_SOURCE_DRPDWN, 1, "Select first value from Document Source Dropdown");
			// Enter Remarks and click on save button
			type(Communication.REMARKS_TEXTBOX, "Test", "Remarks Textbox");
			click(Communication.SAVE_BTN, "Save Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void editWorksheet(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String receivedDate = Excelobject.getCellData(ReportSheet, "Received Date", count);

			createWorksheet(ReportSheet, count);

			// Click On Worksheet Edit Btn
			click(Communication.EDIT_BTN, "Worksheet Edit Button");
			// Edit Received Date
			type(Communication.RECEIVED_DATE, receivedDate, "Change Received date");
			// Select Regular Mail from method of service drpdwn
			click(Communication.REGISTERED_MAIL_METHOD_OF_SERVICE,
					"Select Regular Mail from method of service dropdown");
			// Click on Calendar icon and select todays date
			click(Communication.POST_MARKED_CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Select Alaska from communication juris drpdwn
			click(Communication.ALASKA_COMMUNICATION_JURISDICTION, "Select Alaska from comm juris drpdwn");
			// Click on Unidentified Rep Radio Button
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			// Select Alaska from document juris drpdwn
			click(Communication.ALASKA_DOCUMENT_JURISDICTION, "Select Alaska from document juris drpdwn");
			// Click on save btn
			click(Communication.SAVE_BTN, "Save Button");
			// Verify received date,method of service,comm juris and document juris are
			// changed on Worksheet Profile Page
			assertTextMatching(Communication.RECEIVED_DATE_WORKSHEET_PROFILE, receivedDate,
					"Received date on Worksheet Profile Page");
			assertTextMatching(Communication.METHOD_OF_SERVICE_ON_WORKSHEET_PROFILE, "Registered Mail",
					"Method of service is registered mail");
			assertTextMatching(Communication.COMM_JURIS_ON_WORKSHEET_PROFILE, "Alaska", "Comm Juris is Alaska");
			assertTextMatching(Communication.DOCUMENT_JURIS_ON_WORKSHEET_PROFILE, "Alaska", "Document Juris is Alaska");

		} catch (Exception e) {
			throw e;
		}

	}

	public void viewTransmittal(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String logId = Excelobject.getCellData(ReportSheet, "Log Id", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Enter Log ID and click on search button
			type(Communication.LOG_ID_TEXTBOX, logId, "Log Id Text box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");
			// Click On View Transmittal button
			click(Communication.VIEW_TRANSMITTAL_BTN, "View Transmittal Button");
			// View Tranmittal PDF
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Communication.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			throw e;
		}

	}

	public void transmittalHistory(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String logId = Excelobject.getCellData(ReportSheet, "Log Id", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Enter Log ID and click on search button
			type(Communication.LOG_ID_TEXTBOX, logId, "Log Id Text box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");
			// Click On transmittal history left nav link
			click(Communication.TRANSMITTAL_HISTORY_LEFT_NAV_LINK, "Transmittal History left nav link");
			// Verify title of the page is transmittal history
			assertTextMatching(Communication.PAGE_TITLE, "Transmittal History", "Title of the Page");
			// click on view entity di button
			click(Communication.VIEW_ENTITY_DI_BTN, "View Entity DI Btn");
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Communication.SERVER_ERROR, "Server Error Text");
			// Verify title of the page is Communication Delivery Instructions
			assertTextMatching(Communication.PAGE_TITLE, "Communication Delivery Instructions", "Title of the Page");
			driver.close();
			driver.switchTo().window(parentWindow);
			// Click on Mark As Undeliverable button
			click(Communication.MARK_AS_UNDELIVERABLE_BTN, "Mark As Undeliverable button");
			// Select Other as Reason
			click(Communication.OTHER_REASON, "Select other as reason from reason dropdown");
			// Click on Calendar icon and select todays date
			click(Communication.RETURNED_CALENDAR_ICON_ON_TRANSMITTAL_DELIVERABLE_PAGE, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save buttob
			click(Communication.SAVE_BTN, "Save Button");
			// Click On Create Transmittal Button
			click(Communication.CREATE_TRANSMITTAL_BTN, "Create Transmittal Button");
			// Verify title of the page is Transmittal History
			assertTextMatching(Communication.PAGE_TITLE, "Transmittal History", "Title of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	//'User Views an Annual Report with Department of Commerce by method of Service as "Bulk Mail"
	public void annualReportBulkMail(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Click on create worksheet button
			click(Communication.CREATE_WORKSHEET_BTN, "Create Worksheet Button");
			// Enter Received date
			// Click on Calendar icon and select todays date
			click(Communication.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Select Communication Jurisdiction
			selectByIndex(Communication.COMMUNICATION_JURISDICTION_DRPDWN, 1, "Comm Jurisdiction Dropdown");
			// Select Bulk mail from method of service drp dwn
			click(Communication.BULK_MAIL_METHOD_OF_SERVICE, "Method of Service: Bulk Mail");
			// Click On Entity Select Btn
			click(Communication.ENTITY_SELECT, "Entity Select Button");
			type(Communication.ENTITY_NAME_TEXTBOX, entityName, "Entity Name Text Box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Select first entity on grid
			click(Communication.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity on Grid");
			// Click on Unidentified Rep Radio Button
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			// Select value from document type drpdwn
			click(Communication.DOCUMENT_TYPE_DRPDWN_ANNUAL_REPORT, "Document Type: Annual Report");
			// Select Alabama as Document Jurisdiction
			selectByIndex(Communication.DOCUMENT_JURISDICTION, 1, "Document Jurisdiction Drpdwn");
			// Select value from document source drpdwn
			click(Communication.DOCUMENT_SOURCE_DRPDWN_DPT_OF_COMMERCE, "Document Source: Department of Commerce");
			click(Communication.SAVE_BTN, "Save Button");
			waitForElementPresent(Communication.VIEW_TRANSMITTAL_BTN, "View Transmittal Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");
			// Click On View Transmittal button
			click(Communication.VIEW_TRANSMITTAL_BTN, "View Transmittal Button");
			// View Tranmittal PDF
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Communication.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			throw e;
		}

	}
	
	//'User Views Document Type as "Periodic Report" with Document Source as "Department of Licensing" by method of Service as "Regular Mail"
	public void periodicReportRegularMail(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Click on create worksheet button
			click(Communication.CREATE_WORKSHEET_BTN, "Create Worksheet Button");
			// Enter Received date
			// Click on Calendar icon and select todays date
			click(Communication.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Select Communication Jurisdiction
			selectByIndex(Communication.COMMUNICATION_JURISDICTION_DRPDWN, 1, "Comm Jurisdiction Dropdown");
			// Select Regular mail from method of service drp dwn
			click(Communication.REGULAR_MAIL_METHOD_OF_SERVICE, "Method of Service: Regular Mail");
			// Click on Calendar icon and select todays date
			click(Communication.POST_MARKED_CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Click On Entity Select Btn
			click(Communication.ENTITY_SELECT, "Entity Select Button");
			type(Communication.ENTITY_NAME_TEXTBOX, entityName, "Entity Name Text Box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Select first entity on grid
			click(Communication.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity on Grid");
			// Click on Unidentified Rep Radio Button
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			// Select value from document type drpdwn
			click(Communication.DOCUMENT_TYPE_DRPDWN_PERIODIC_REPORT, "Document Type: Periodic Report");
			// Select Alabama as Document Jurisdiction
			selectByIndex(Communication.DOCUMENT_JURISDICTION, 1, "Document Jurisdiction Drpdwn");
			// Select value from document source drpdwn
			click(Communication.DOCUMENT_SOURCE_DRPDWN_DPT_OF_LICENSING, "Document Source: Department of Licensing");
			click(Communication.SAVE_BTN, "Save Button");
			waitForElementPresent(Communication.VIEW_TRANSMITTAL_BTN, "View Transmittal Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");
			// Click On View Transmittal button
			click(Communication.VIEW_TRANSMITTAL_BTN, "View Transmittal Button");
			// View Tranmittal PDF
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Communication.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			throw e;
		}

	}
	
	
	//'User Views Document Type as "Biennial Report" with Document Source as "Arizona Corporation Commission"  by method of Service as "Electronic Delivery"
	public void biennialReportElectronicDelivery(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);

			// click on Entity Search link
			click(HomePage.COMM_WORKSHEET_SEARCH_LINK, "Comm Worksheet Search Link");
			// Click on create worksheet button
			click(Communication.CREATE_WORKSHEET_BTN, "Create Worksheet Button");
			// Enter Received date
			// Click on Calendar icon and select todays date
			click(Communication.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Select Communication Jurisdiction
			selectByIndex(Communication.COMMUNICATION_JURISDICTION_DRPDWN, 1, "Comm Jurisdiction Dropdown");
			// Select Electronic Delivery from method of service drp dwn
			click(Communication.ELECTRONIC_DELIVERY_METHOD_OF_SERVICE, "Method of Service: Electronic Delivery");
			// Click On Entity Select Btn
			click(Communication.ENTITY_SELECT, "Entity Select Button");
			type(Communication.ENTITY_NAME_TEXTBOX, entityName, "Entity Name Text Box");
			click(Communication.SEARCH_BTN, "Search Button");
			// Select first entity on grid
			click(Communication.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity on Grid");
			// Click on Unidentified Rep Radio Button
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			// Select First value from document type drpdwn
			click(Communication.DOCUMENT_TYPE_DRPDWN_BIENNIAL_REPORT, "Document Type: Biennial Report");
			// Select Alabama as Document Jurisdiction
			selectByIndex(Communication.DOCUMENT_JURISDICTION, 1, "Document Jurisdiction Drpdwn");
			// Select First value from document source drpdwn
			click(Communication.DOCUMENT_SOURCE_DRPDWN_ARIZONA_CORP_COMM, "Document Source: Arizona Corporation Commission");
			click(Communication.SAVE_BTN, "Save Button");
			// Verify title of the page is worksheet profile
			assertTextMatching(Communication.PAGE_TITLE, "Worksheet Profile", "Title of the Page");
			// Click On View Transmittal button
			click(Communication.VIEW_TRANSMITTAL_BTN, "View Transmittal Button");
			// View Tranmittal PDF
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Communication.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			throw e;
		}

	}
	
}
