package com.arrow.workflows;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_CommonCESAndWorksheet extends BusinessFunctions {
		
//Below function will create worksheet after CES submit, using the submitted ESOP Id this includes CIOX changes as well
	
	public String viewAndCreateTheWorkSheetUsingESOPId(String reportSheet, int count,String esopId) throws Throwable{
		String worksheetId = null;
		try{				
		String defendentName = Excelobject.getCellData(reportSheet, "WS Defendent Name", count);
		String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
		String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);
		String attorney = Excelobject.getCellData(reportSheet, "WS Attorney", count);
		String court = Excelobject.getCellData(reportSheet, "WS Court", count);
		String documentServed = Excelobject.getCellData(reportSheet, "Document Served", count);
		String caseNum = Excelobject.getCellData(reportSheet, "WS Case Number", count);
		String plaintiff = Excelobject.getCellData(reportSheet, "WS Plaintiff", count);
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
	    searchForESOP(esopId);		
		try {		 
			WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
			waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
		    searchForESOP(esopId);			
			
		}catch(NoSuchElementException e) {}
				
		for(int i=0 ;i<10; i++) {			
		String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
		if(isHandlerProcessed.equals("N")) {
		Thread.sleep(15000);
		}
		else {
			break;
		}		
		}
		selectAndAssignTheFileToTeam();
	/*	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");*/
		Thread.sleep(300);
		searchForESOP(esopId);		
		
		String parentWindow= driver.getWindowHandle();		
		waitForElementPresent(SOP.VIEW_BTN, "View button");
		assertElementPresent(SOP.VIEW_BTN, "View button");		
		click(SOP.VIEW_BTN, "View button");		
		handlePopUpWindwow();
		driver.close();
		driver.switchTo().window(parentWindow);
		Thread.sleep(300);
		WebElement createWs = null;
		try {
		createWs = driver.findElement(SOP.CREATE_WORKSHEET);
		waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		}catch(NoSuchElementException e) {			
		}
		if(createWs == null) {
			Thread.sleep(10000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(10000);
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
			Thread.sleep(2000);
			String parentWin= driver.getWindowHandle();		
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");		
			click(SOP.VIEW_BTN, "View button");		
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWin);
			waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		}

		//this needs to be commented as the below is creating ambiguity
/*		WebElement initalRadioButton = null;
		try {			
			
			initalRadioButton = driver.findElement(SOP.INITIAL_RADIOBTN);	
			
		}catch(NoSuchElementException e) {}
		if(initalRadioButton == null) {
			 click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			   Thread.sleep(2000);
		      driver.switchTo().frame("frame1");
		}*/
		
	    Thread.sleep(500);
		driver.switchTo().frame("frame1");
		
		waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		
		if(isAttempted.equalsIgnoreCase("Yes")){
			//ATTEMPTED_YES_RADIO_BUTTON
			waitForElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
			assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");	
			click(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
		}
		if(workflowInWorksheet.equals("Full")){
		//INITIAL_RADIOBTN
		waitForElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");
		assertElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");	
		click(SOP.INITIAL_RADIOBTN,"Initial Radio button");
		}
		if(!caseNum.equals("")) {
		//CASEID_TEXTBOX
		waitForElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");
		assertElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");	
		type(SOP.CASEID_TEXTBOX,caseNum,"Case Id text box");
		}
		if (!plaintiff.equals("")) {
		//PLAINTIFF_TEXT_BOX
		waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plaintiff text box");
		assertElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plantiff text box");	
		type(SOP.PLAINTIFF_TEXT_BOX,plaintiff,"Plantiff text box");
		}
		if(!defendentName.equals("")) {
		//DEFENDANT_TEXTFIELD
		waitForElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");	
		assertElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
		type(SOP.DEFENDANT_TEXTFIELD,defendentName,"Defendent text box");
		}

		//Here one function will webelement needs to be added as part of CIOX change that will expand the glyphicon icon
		//$x("//tr[@id='trReceivedBy']//following-sibling::td//span[@class='glyphicon glyphicon-triangle-right']")
		//RECEIVED_BY_GLYPHICON_WORKSHEET
		waitForElementPresent(WorksheetCreate.RECEIVED_BY_GLYPHICON_WORKSHEET,"glyphicon icon during worksheet creation");
		assertElementPresent(WorksheetCreate.RECEIVED_BY_GLYPHICON_WORKSHEET,"glyphicon icon during worksheet creation");
		click(WorksheetCreate.RECEIVED_BY_GLYPHICON_WORKSHEET,"glyphicon icon during worksheet creation");
		//EDIT_RECEIVED_BY
		waitForElementPresent(WorksheetCreate.EDIT_RECEIVED_BY,"Received By drop downs in create wroksheet page");
		assertElementPresent(WorksheetCreate.EDIT_RECEIVED_BY,"Received By drop downs in create wroksheet page");
		selectByIndex(WorksheetCreate.EDIT_RECEIVED_BY,1,"Received By drop downs in create wroksheet page");
		//WORKSHEET_TYPE
		waitForElementPresent(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in create wroksheet page");
		String worksheetType = getText(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in create wroksheet page");
		//ENTITY_IN_WORKSHEET_PROFILE
		waitForElementPresent(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"Entity in wroksheet profile step 1 page");
		String entityInWorksheet = getAttribute(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"value");
		
		//Removing below Next btn functionality	
		Thread.sleep(700);
					
		
		//COURT_NAME_TEXT_BOX
		String attorneyNoneAttribute = "";
		String courtNameInWorksheet = "";

		try {
			attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");  
		}catch (NoSuchElementException e) {}
		try {	
			driver.findElement(SOP.EXISTING_COURTNAME);
			courtNameInWorksheet = getText(SOP.TEXT_BOX_COURTNAME,"value");
		}catch (NoSuchElementException e) {} 
		try {
			driver.findElement(SOP.COURT_NAME_TEXT_BOX);
			courtNameInWorksheet = getAttribute(SOP.COURT_NAME_TEXT_BOX,"value");
		}catch (NoSuchElementException e) {}
			if (courtNameInWorksheet.equals("")) {
				courtNameInWorksheet = null;				
			}			
			String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);		
			compareStrings(courtNameInWorksheet,courtNameInCES);
		//TEXT_BOX_ATTORNEYNAME
		if(attorneyNoneAttribute == null) {
		waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in create wroksheet page");
		assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in create wroksheet page");	
		String attorneyNameInWorksheet = getAttribute(SOP.TEXT_BOX_ATTORNEYNAME,"value");
		if(attorneyNameInWorksheet.equals("")) {
			attorneyNameInWorksheet = null;
		}		
		String attorneyNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(0);
		compareStrings(attorneyNameInWorksheet,attorneyNameInCES);
		}
		if(courtNameInWorksheet == null) {
		waitForElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in create wroksheet page");
		assertElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in create wroksheet page");
		click(SOP.COURT_NONE_RADIOBTN,"court none radio button in create wroksheet page");
		}
		if(!court.equals("")) {
							
		//USE_THIS_COURT
		waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
		assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
		click(SOP.USE_THIS_COURT,"Use this court radio button");
		//COURT_NAME_TEXT_BOX
		waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
		assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
		type(SOP.COURT_NAME_TEXT_BOX,court,"Court NAme");
		//ADDRESS_LINE_ONE
		waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
		assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
		type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
		//CITY_NAME
		waitForElementPresent(SOP.CITY_NAME,"City Name text box");
		assertElementPresent(SOP.CITY_NAME,"City Name text box");
		type(SOP.CITY_NAME,"Houston","City Name text box");
		//STATE_NAME
		waitForElementPresent(SOP.STATE_NAME,"State Name text box");
		assertElementPresent(SOP.STATE_NAME,"State Name text box");
		type(SOP.STATE_NAME,"TX","State Name text box");
		//ZIP_CODE
		waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
		assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
		type(SOP.ZIP_CODE,"77550","Zip code text box");

		Thread.sleep(500);
		}
		if(!attorney.equals("")) {
			//USE_THIS_ATTORNEY
			waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
			assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
			click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
									
			//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							type(SOP.TEXT_BOX_ATTORNEYNAME,"Alan H. Weinreb","Text box to enter attorney name");
							
							//ATTORNEY_ADDRESS_LINE_ONE
						    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
							
							//CITY_NAME
							waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
							
							//ATTORNEY_STATE_NAME
							waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
							
							//ATTORNEY_ZIP_CODE
							waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");
		}

		WebElement specialCircumStances = null;
		try {
			specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);					
				if (specialCircumStances != null) {
						selectByIndex(WorksheetCreate.SPECIAL_CIRCUMSTANCES,1," Special Cicumstances drop down  in create wroksheet page");
					    Thread.sleep(2000);
					}
				} catch (NoSuchElementException e) {
			}						
		/*else if(branchPlant.equals("NRAI")) {
			selectByVisibleText(SOP.DOCUMENT_SERVED,documentServed,"document Type drop down  in create wroksheet page");
			//DOCUMENT_SERVED_MOVE_RIGHT
			assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in create wroksheet page");
			click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in create wroksheet page");
		}*/
		//ANSWER_DATE_NONE
		waitForElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in create wroksheet page");
		assertElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in create wroksheet page");	
		click(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in create wroksheet page");
		if(saveIncomplete.equalsIgnoreCase("Yes")){
			//SAVE_INCOMPLETE_BUTTON
			waitForElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in create wroksheet page");
			assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in create wroksheet page");	
			click(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in create wroksheet page");
		}
		//SAVE_BTN
		else if(saveIncomplete.equalsIgnoreCase("No")){		
		waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		assertElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		click(Entity.SAVE_BTN, "Save button in create wroksheet page");
		Thread.sleep(500);
		//DOCUMENT_TYPE_DROPDWN
		//here one check for if doc type is not selected	
		//Enter a value for Document Type.
	try {
	 WebElement docNotSelected = null;	
	 docNotSelected = driver.findElement(WorksheetCreate.DOCUMENT_TYPE_NOT_SELECTED);
	 if(docNotSelected != null) {	
		//commented below code on 6/3/21 to enter the document type values
		 //selectByIndex(SOP.DOCUMENT_TYPE_DROPDWN,3,"document Type drop down  in create wroksheet page");
		// DOCUMENT_TYPE_TEXTFIELD
	    //added below code on 6/3/21 to enter the document type values
		 type(SOP.DOCUMENT_TYPE_TEXTFIELD,"Document Type value entered in Selenium Automation","Document Type text box");
		 waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		 assertElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		 click(Entity.SAVE_BTN, "Save button in create wroksheet page");
	 }
	}
	 catch (NoSuchElementException e) {}
		}
		
		//below all errors are validated after click on Save
		
		
		//below check for if error- > 'Enter a value for Other Mehod of Serivce.		
		try {
		 
			driver.findElement(SOP.OTHER_METHOD_OF_SERVICE);
			type(SOP.OTHER_METHOD_OF_SERVICE_TEXT_BOX,"Other", "Type the Text for other Method of Service");
			waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			click(Entity.SAVE_BTN, "Save button in create wroksheet page");
			//click(SOP.NEXT_BTN,"next button in create wroksheet page");	
			Thread.sleep(700);
		}catch (NoSuchElementException e) {}	

		//below check for if error- > 'Select a Post Marked reason.'
		
		try {
		driver .findElement(SOP.POST_MARKED_REASON_ERROR);
		waitForElementPresent(WorksheetCreate.POST_MARKED_REASON,"Post Marked Reason");
		selectByVisibleText(WorksheetCreate.POST_MARKED_REASON,"Not Post Marked","Post Marked Reason");
		waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		click(Entity.SAVE_BTN, "Save button in create wroksheet page");
		Thread.sleep(700);
		}catch(NoSuchElementException e) {}
		
		//below check for if error -> Enter a value for Post Marked date in mm/dd/yyyy format.

		try {
		driver.findElement(WorksheetCreate.POST_MARKED_DATE_ERROR);
		waitForElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post Marked Date Text box");		
			int currentYear = Integer.valueOf(getCurrentDate().split("\\/")[2]); 
			String date = "01"+"/" + "01"+"/" + String.valueOf(currentYear); 			
			type(WorksheetCreate.POST_MARKED_DATE,date,"Post marked Date text box");
			waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			click(Entity.SAVE_BTN, "Save button in create wroksheet page");
			Thread.sleep(700);
		}catch(NoSuchElementException e) {}
		
		//below check for if Error -> Enter a valid value initial or subsequent
		//CHOOSE_INITIAL_SUBSEQUENT_ERROR	
		try {
		driver .findElement(WorksheetCreate.CHOOSE_INITIAL_SUBSEQUENT_ERROR);
		waitForElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");
		click(SOP.INITIAL_RADIOBTN,"Initial Radio button");
		waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		click(Entity.SAVE_BTN, "Save button in create wroksheet page");
		Thread.sleep(700);
		}catch(NoSuchElementException e) {}
		
		//below check for if Error -> Enter a valid value for Case#.
		try {
			//Below code is modified on 12/23 
			driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
			Thread.sleep(700);
			boolean caseTextPsNum = false;
			//Below try block is added as some method of srvice has different way of SElecting the CASe# in worksheet page 1
			  try {				
					driver.findElement(SOP.CASE_TEXT_PS_CASENUM);
					Thread.sleep(500);
					type(SOP.CASE_TEXT_PS_CASENUM,"CNInWorksheet", "Type the Text for the Case#");
					//Below save button functionality needs to be added after removing click next functionality
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			        click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					caseTextPsNum = true;
				}catch(NoSuchElementException e) {}
				
					if(caseTextPsNum == false) {
					Thread.sleep(500);
					type(SOP.CASE_TEXT_PS_CASENUM,"CNInWorksheet", "Type the Text for the Case#");
					//Below save button functionality needs to be added after removing click next functionality
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			        click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					Thread.sleep(700);
					}
				}catch (NoSuchElementException e) {}
				
			  //This try block is added on 12/23 to validate and enter the blank case number during worksheet creation if not filled during CES
				try {
					driver.findElement(SOP.CASE_NUMBER_BLANK);
					Thread.sleep(700);
					type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for the Case#");
					//Below save button functionality needs to be added after removing click next functionality
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			        click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					Thread.sleep(700);
				}catch (NoSuchElementException e) {}	

			     if(workflowInWorksheet.equals("Full")){ 
			    	    WebElement docServed = null;
						try {
								docServed = driver.findElement(SOP.DOCUMENT_SERVED);					
								if (docServed != null) {
									waitForElementPresent(SOP.FIRST_DOCUMENT_SERVED,"document Type drop down  in wroksheet step 3 page");
									click(SOP.FIRST_DOCUMENT_SERVED,"document Type drop down  in wroksheet step 3 page");
									Thread.sleep(500);
									//DOCUMENT_SERVED_MOVE_RIGHT
									assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in create wroksheet page");
									click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
									waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
						            click(Entity.SAVE_BTN, "Save button in create wroksheet page");
								    Thread.sleep(700);
								}
							} catch (NoSuchElementException e) {}	
			     }
		
		
		
			//OTHER_DOC_SERVED_WORKSHEET
			WebElement otherDocServed = null;
			try {
				otherDocServed = driver.findElement(WorksheetCreate.ENTER_VALUE_FOR_OTHER_MESSAGE);
				if (otherDocServed != null) {
					waitForElementPresent(WorksheetCreate.OTHER_DOC_SERVED_WORKSHEET,"Other doc served text box in create worksheet page");
					assertElementPresent(WorksheetCreate.OTHER_DOC_SERVED_WORKSHEET,"Assert Other doc served text box in create worksheet page");
					type(WorksheetCreate.OTHER_DOC_SERVED_WORKSHEET,"Other Doc served entered with Selenium automation","Enter Other doc served text box in create worksheet page");
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		            click(Entity.SAVE_BTN, "Save button in create wroksheet page");
				}
				
			} catch (NoSuchElementException e) {}
			
			
		//WORKSHEET_ID_ON_CONTEXT_BAR
		waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
		assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");	
		//click(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
		worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
		if(worksheetId.equals(null)){
			throw new NullPointerException();
		}
		}catch(NullPointerException e){
			e.printStackTrace();
		}
		System.out.println("Worksheet id : " + worksheetId);
		//Thread.sleep(1000);
		
		return worksheetId.split("\\: ")[1];
	}
	
	
	public void searchForESOP(String esopId) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1,"ESOP Id","Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");		
		click(SOP.FILTERGOBTN, "Go Button");
	 }

	public void selectAndAssignTheFileToTeam() throws Throwable{
		waitForElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		assertElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");		
		click(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign button");
		click(SOP.ASSIGN_BTN, "Assign button");
		Thread.sleep(1000);
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		click(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		Thread.sleep(1000);
	}

	
	//Below code will process CES
	public String entitySectionDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
			try {			
				String caseNumber = "";
				int relatedWorksheet = 0;
				String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
				String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
				String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
				String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);				
				String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
				String caseNum2 = Excelobject.getCellData(reportSheet, "New Case Number", count);
				String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
				String rejectionReason = Excelobject.getCellData(reportSheet, "Rejection Reason", count);
				String notRejecting = Excelobject.getCellData(reportSheet, "Reason for Not Rejecting", count);
				String error = Excelobject.getCellData(reportSheet, "Error Message", count);
				String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
				String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
				String reject = Excelobject.getCellData(reportSheet, "Reject", count);
				String onHold = Excelobject.getCellData(reportSheet, "On Hold", count);
				String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
				String courtName = Excelobject.getCellData(reportSheet, "Court", count);
				//String worksheetType = Excelobject.getCellData(reportSheet, "WorkSheet Type", count);
				
				if(!cesQueue.equals("New")) {			
					moveESOPFromNewQueueToDiffCESQueue(reportSheet,count);
			    }
				
				waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				click(SOP.SOP_LINK_HEADER, "SOP link in header");
				if(levelOfUser.equals("Level1")) {
					//CES_LEFT_NAV_LINK
					waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
					assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
					click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
		 		    //CES_PRODUCTIVITY_TAB
					waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
					click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
					//UNPROCESSED_COUNT
					waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
					assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
					click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
					Thread.sleep(1000);
					waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					Thread.sleep(2000);
					driver.switchTo().frame("frame1");
					Thread.sleep(3000);
				}
				
				else if(!levelOfUser.equals("Level1")) {
				if(cesQueue.equals("New")) {
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");			
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");			
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");

				try {		 
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");			
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
					click(SOP.FILTERGOBTN, "Go Button");
					Thread.sleep(1000);	
				}catch(NoSuchElementException e) {}
				Thread.sleep(1000);
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				Thread.sleep(1000);
			
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				}
				else if(!cesQueue.equals("New")) {
				//CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");			
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
	 		    //CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
				
				 if(cesQueue.equals("Escalated List")) {			
				  //ESCALATED_LIST_TAB
				  waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				  assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
				  click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");				    
				  //FIRST_CES_SELECT_BUTTON
				  waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				  assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				  click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				 }

				else if(cesQueue.equals("OnHold List")) {			
			    //ON_HOLD_LIST_TAB
			    waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
				//FIRST_ONHOLD_CES_SELECT_BUTTON
				 waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				 assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				 click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
				 //create on filter search for New York SOP Team
			    }
			    
			    else  if(cesQueue.equals("Rejections List")) {			
				 //REJECTION_LIST_TAB
				 waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				 assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
				 click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
				 //REJECTIONS_LIST_FIRST_CES_SELECT
				 waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				 assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
				 click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		
				 }
				}
				Thread.sleep(2000);
				//System.out.println("Reached Here ewjdjkjlkwdlkjw");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				driver.switchTo().frame("frame1");
				System.out.println("Switched to Frame 1");
				Thread.sleep(3000);
				//TRAINGLE_ICON_ARROW_ENTITY			
				//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				//INTAKEMETHODVALUE
				waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
				String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
				if(!arrowEntity.equals("")) {				
					waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
				    String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
					if (arrowEntityCheckedAttribute == null) {			
					        click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				    }
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 
	                
					if(!cdsop.equals("CDSOP")) {											
					 if (branchPlant.equals("CTCORP")) {
						//CTCORP_RADIO_BUTTON
						 	waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	
										
						}
						else if (branchPlant.equals("NRAI")) {
							//NRAI_RADIO_BUTTON
							waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
							}
					}
					//ENTITY_NAME_TEXTFIELD
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
					if(cdsop.equals("CDSOP")) {
						selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
					}
					else if(!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
					}				
					//INCLUDE_ALL_REP_ASSUMED_BTN
					waitForElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
					assertElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
					click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
					//SEARCH_BTN
					waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					assertElementPresent(SOP.SEARCH_BTN, "Search button");
					click(SOP.SEARCH_BTN, "Search button");
					int entitySearchCount = 0;
					//ENTITY_SEARCH_RESULT_COUNT
					waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
					entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				    if(entitySearchCount == 0) {
					//Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					}catch(NullPointerException e) {}
					if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
					Thread.sleep(1500);
					System.out.println("REached here in line 6420");
					try {
					if(disabledUnEntity.equals("true")) {					
					  //SEARCH_AGAIN_BUTTON
					  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
					  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
					  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
					  //CANCEL_BUTTON
					  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
					  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
					  click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
	                 System.out.println("REached here in line 6431");
	                 Thread.sleep(2000);
	                 //below will be a go ahead when the value for unidentified Entity above is selected
	                 String unEntityRadioSelected = "";
	                 try {                	 
	                	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
	                 }catch(NoSuchElementException e) {}
	                 catch(NullPointerException e) {}
	                 Thread.sleep(1000);
	                 try {
	                 if(unEntityRadioSelected == null) {
	                	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
	                 }}catch(NullPointerException e) {}
					//ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
					//DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
					//REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
					try {
					//waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
					//assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
					driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
					Thread.sleep(1500);
					selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
					}catch(NoSuchElementException e) {}
					//DOCUMENT_TYPE_DROPDWN
					try {
					//waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
					//assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				    driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
					selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}
					//PLAINTIFF_TEXT_BOX			
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX,"Test Plaintiff", "plaintiff text box");
					//DEFENDANT_TEXT_BOX				
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX,"Test Defendant", "defendant text box");
					
					waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
					type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
					}
					else if(entitySearchCount != 0) {
					//REP_STATUS_SORT
					waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 //FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					//CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if(action.size()>0) {
						
							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					}
					 catch(NoSuchElementException e) {
							
				     }
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					click(SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
						}catch(NoSuchElementException e) {}
						//DOCUMENT_TYPE_DROPDWN
						try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}
						
						//PLAINTIFF_TEXT_BOX			
						waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
						//DEFENDANT_TEXT_BOX				
						waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
						
						waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
						assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
						type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
						
								
				}
				
					/*if(!caseNum1.equals("")){					
					 //CASEID_TEXTBOX
					 waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 if(cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,"19342919","Case number Search text box");
					 }
					 else if(!cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,caseNum1,"Case number Search text box");
					 }
					 //SEARCH_BTN
					 waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					 assertElementPresent(SOP.SEARCH_BTN, "Search button");
					 click(SOP.SEARCH_BTN, "Search button");
					 //TOTAL_RECORDS_RELATED_WORKSHEET				 				 
					 waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results");				 
					 relatedWorksheet = Integer.parseInt(getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results"));
					 Thread.sleep(1000);
					 if(relatedWorksheet == 0) {
					 
						 click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
						 Thread.sleep(2000);
						 //RADIO_PRESENTATION_BUTTON
						 String repChecked = "";
						 try {
							 repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked"); 
						 }catch(NoSuchElementException e) {}
						 if(repChecked == null) {
						 //REP_JURISDICTION_SELECTION
						 waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						 assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						 selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");
						 }
						 Thread.sleep(2000);
						 try {
						 driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);					 
						 selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law suit type in CES Page");
						 }catch(NoSuchElementException e) {}
						 Thread.sleep(2000);					 
						 try {						 
						  driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
						  selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}				
						 Thread.sleep(3000);
						 waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
						 assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
						 type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box in CES Page");
							
						 waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
						 assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
						 type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box CES Page");	
						 
						 waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
						 assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
						 type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
						 					 
					  }
					 else if (relatedWorksheet != 0) {
					*/ 
					//FIRST_WORKSHEET_RADIO_BTN
					 /*waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 //ADD_TO_DOCKET_HISTORY_BUTTON
					 waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
					 Thread.sleep(2000);
					 waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");*/
					 //caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 
					/* if(cdsop.equals("CDSOP")) {
						 compareStrings(caseNumber,"19342919");
					 }
					 
					 else if(!cdsop.equals("CDSOP")) {
					 
						 compareStrings(caseNumber,caseNum1);
					 }*/				 
					}
				}
/*					 if(!caseNum2.equals("")){
					 //SELECT_BUTTON_IN_RELATED_LOG
					 waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
					 assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
					 click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
					 //CASEID_TEXTBOX
					 waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 if(cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,"19342919", "Case number Search text box");					 
					 }
					 else if(!cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,caseNum2, "Case number Search text box");					 
					 }

					 //SEARCH_BTN
					 waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					 assertElementPresent(SOP.SEARCH_BTN, "Search button");
					 click(SOP.SEARCH_BTN, "Search button");
					 //FIRST_WORKSHEET_RADIO_BTN
					 waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 //ADD_TO_DOCKET_HISTORY_BUTTON
					 waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
					 Thread.sleep(2000);
					 waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
					 caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 	
					 if(cdsop.equals("CDSOP")) {
						 compareStrings(caseNumber,"19342919");
					 }
					 else if(!cdsop.equals("CDSOP")) {
					 
						 compareStrings(caseNumber,caseNum2);
					 }
					}*/
		
					 
				//if(caseNum1.equals("")){
					
		//	}
	//	}
		//	}
				Thread.sleep(3000);
				assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				//Below one check can be applied if attorney and court modification needs to be done - 1476
				if(!attorneyName.equals("")) {			 			
						//RADIO_BUTTON_ATTORNEYNONE					
						String attorneyNoneAttribute = "";
						
						try {														
							//USE_THIS_ATTORNEY
							waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
							assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
							click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
							
							//TEXT_BOX_ATTORNEYNAME
							waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");
							
							//ATTORNEY_ADDRESS_LINE_ONE
						    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
							
							//CITY_NAME
							waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
							
							//ATTORNEY_STATE_NAME
							waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
							
							//ATTORNEY_ZIP_CODE
							waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");
							
					   } catch (NoSuchElementException e) {}}
				   
				if(!courtName.equals("")) {					
						try {
							/*String courtNoneAttribute = "";
							courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
				            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
							click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
							//DROP_DOWN_COURT_NAME
							waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
							assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
							selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");*/
							
							//USE_THIS_COURT
							waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
							assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
							click(SOP.USE_THIS_COURT,"Use this court radio button");
							//COURT_NAME_TEXT_BOX
							waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
							assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
							type(SOP.COURT_NAME_TEXT_BOX,courtName,"Court NAme");
							//ADDRESS_LINE_ONE
							waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
							assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
							type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
							//CITY_NAME
							waitForElementPresent(SOP.CITY_NAME,"City Name text box");
							assertElementPresent(SOP.CITY_NAME,"City Name text box");
							type(SOP.CITY_NAME,"Houston","City Name text box");
							//STATE_NAME
							waitForElementPresent(SOP.STATE_NAME,"State Name text box");
							assertElementPresent(SOP.STATE_NAME,"State Name text box");
							type(SOP.STATE_NAME,"TX","State Name text box");
							//ZIP_CODE
							waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
							assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
							type(SOP.ZIP_CODE,"77550","Zip code text box");
							
					   } catch (NoSuchElementException e) {}
						/*if(attorneyNoneAttribute == null) {						
							//TEXT_BOX_ATTORNEYNAME
							waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
							assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
							type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"text field for Attorney Sender Name");	
						}
						if(courtNoneAttribute == null) {						
							//TEXT_BOX_COURTNAME
							waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
							assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
							type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");	

						}	*/															
				}			 
				
				//Below one code is to escalate as Possible REjection
				if(!escalationReason.equals("")) {
					//Below one condition needs to be set if the L2 user processing CES from Escalated List
					//then update to possible rejection click can be done from here.		
					if((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List")) && escalationReason.equals("Update to Possible Rejection")) {
					//UPDATE_TO_POSSIBLE_REJECTION
					 waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					 assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					 click(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					 
					}
					 if(cesQueue.equals("Escalated List") && escalationReason.equals("Update to Possible Rejection & GetNext")) {
					//UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");	
					Thread.sleep(5000);
					 }				
					 if(!escalationReason.equals("Update to Possible Rejection") && !escalationReason.equals("Update to Possible Rejection & GetNext")){								
					//ESCALATION_DETAILS
					waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
					//REASON_DRPDWN
					waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");
					//ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Could be a Possible Rejection", "Escalation text box");
					//ESCALATE_BTN
					waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					click(SOP.ESCALATE_BTN, "Escalate button");
					}	
				}
				else if(rejectionReason.equals("") && reject.equals("Y")) {
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");	
					//REJECT_REASON_EMPTY_ERROR
					waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
					assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
					String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
					compareStrings(error,errorMessage);
					
				}
				else if(!rejectionReason.equals("") && !reject.equals("")) {
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					if(!notRejecting.equals("")) {
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reason for not Rejecting drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");								
					//ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
					else if(notRejecting.equals("")) {
					if(attorneyName.equals("")) {
					//ATTORNEY_SENDER_NONE_SPECIFIED
					waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					//commenting below as List of WebElemets not required
					//List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {				
					traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
					if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
					}
					}catch(NoSuchElementException e) {}
				    //HARD_COPY_DELIVERY
					waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
					String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);												
					if(hardCopy.equals("No") && error.equals("")) {		
						String parentWin= driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow();
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1]).get(0);		
						assertTextContains(letterPopup,rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}				
					//ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if(attorneyName.equals("")) {
					waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
					assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
					String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
					compareStrings(error,errorMessage);
					}
				}
			}			
	            else if(escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
	            	if  (!rejectionReason.equals("")){
	    			waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
	    			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
	    			selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
	    			//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {				
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
					}
					}catch(NoSuchElementException e) {}
					//SUBMIT_CES				
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
					//SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
	            	}
	            	else if  (rejectionReason.equals("")){
	    			List<WebElement> traceableMail = null;
	    			//TRACEABLE_MAIL_FIELD
	    			try {
	    			traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
	    			if(traceableMail != null) { 
	    			
	    				type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
	    			 }
	    			}catch(NoSuchElementException e) {}	
	    			
	    			/* Below Code is addded on 1/21 as part of GCNBO-1740
	    			  To handle the onhold submit scenario when the
	    			  Escalation Reason for the esop is Possible Rejection    			  
	    			*/
	    			if(cesQueue.equals("OnHold List")) {
	    			//ESCALATION_DETAILS
	    			waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
	    			assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
	    			click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");	
	    			//ESCALATION_REASON
	    			waitForElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
	    			assertElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
	    			String escalationReasonInOnHold = getText(SOP.ESCALATION_REASON, "Escalation Reason");	
	    			
	    			if(escalationReasonInOnHold.equals("Possible Rejection")) {
	    				waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
	    				assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
	    				selectByIndex(SOP.REASON_FOR_NOT_REJECTING,1,"Reject Reason drop down");
	    				Thread.sleep(2000);	
	    				
	    			}
	    			}    			    			
	    			/* Till here the code change made as on 1/21 */			    
	    			//REASON_FOR_NOT_REJECTING
	    			if(cesQueue.equals("Rejections List")) {
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
	    			}	    			
	    			//Below one change is done to add the CES internal Comments
	    			//CES_INTERNAL_COMMENTS
	    			/*waitForElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
	    			assertElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
	    			type(SOP.CES_INTERNAL_COMMENTS,"CES internal Comments added through Selenium Automation", "Ces internal comments ins CES page");*/
					waitForElementPresent(SOP.CES_INTERNAL_COMMENTS, "CES Internal Comments");
					assertElementPresent(SOP.CES_INTERNAL_COMMENTS, "CES Internal Comments");
					type(SOP.CES_INTERNAL_COMMENTS, "Process Validated", "CES Internal Comments Text");
					
	    			//SUBMIT_CES
	    			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
	    			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
	    			click(SOP.SUBMIT_CES, "Submit button in CES Page");	
	            	}
	            }
	            else if(!onHold.equals("")) {
	            	//REASON_FOR_HOLD_TEXTBOX
	            	waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
	    			assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
	    			type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
	    			//ONHOLD_BTN
	    			waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
	    			assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
	    			click(SOP.ONHOLD_BTN, "On Hold button");
	            }
		
		}catch(Exception e) {}
		return esopId.split("\\: ")[1];	
	  }

	//Below function is created to Reject the CES as per the Hard copy required Y or N
	public String rejectESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {
		
		String esopId = "";			
		try {
				
			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			 
			if(!cesQueue.equals("New")) {			
					moveESOPFromNewQueueToDiffCESQueue(reportSheet,count);
			 }
			
			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode)).get(0);
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");			    
			if(cesQueue.equals("New")) {
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");		
			searchForESOP(esopId);		
			try {		 
			WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
			waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);			
			}catch(NoSuchElementException e) {}

			Thread.sleep(1000);			
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			}
			else if(!cesQueue.equals("New")) {			
				
				//CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");			
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
	 		    //CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
				
				 if(cesQueue.equals("Escalated List")) {			
				  //ESCALATED_LIST_TAB
				  waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				  assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
				  click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
				  searchForESOP(esopId);
				  //FIRST_CES_SELECT_BUTTON
				  waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				  assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				  click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				 }

				else if(cesQueue.equals("OnHold List")) {			
			    //ON_HOLD_LIST_TAB
			    waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				searchForESOP(esopId);
				//FIRST_ONHOLD_CES_SELECT_BUTTON
				 waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				 assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				 click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
				 //create on filter search for New York SOP Team
			    }
			    
			    else  if(cesQueue.equals("Rejections List")) {			
				 //REJECTION_LIST_TAB
				 waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				 assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
				 click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				 searchForESOP(esopId);
				 //REJECTIONS_LIST_FIRST_CES_SELECT
				 waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				 assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
				 click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		
				 }
				}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			//TRAINGLE_ICON_ARROW_ENTITY			
			//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			//INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
			
			if(!arrowEntity.equals("")) {				
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
			    String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {			
				        click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
			    }
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 
	            
				if(!cdsop.equals("CDSOP")) {											
				 if (branchPlant.equals("CTCORP")) {
					//CTCORP_RADIO_BUTTON
					 	waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	
									
					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
						}
				}
				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
				if(cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
				}
				else if(!cdsop.equals("CDSOP")) {
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
				}
				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				//ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			    if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
				disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
				System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
				click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				try {
				if(disabledUnEntity.equals("true")) {					
				  //SEARCH_AGAIN_BUTTON
				  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
				  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
				  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
				  //CANCEL_BUTTON
				  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
				  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
				  click(SOP.CANCEL_BUTTON, "Cancel Button");
				}}catch(NullPointerException e) {}				
	             System.out.println("REached here in line 6431");
	             Thread.sleep(2000);
	             //below will be a go ahead when the value for unidentified Entity above is selected
	             String unEntityRadioSelected = "";
	             try {                	 
	            	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
	             }catch(NoSuchElementException e) {}
	             catch(NullPointerException e) {}
	             Thread.sleep(1000);
	             try {
	             if(unEntityRadioSelected == null) {
	            	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
	             }}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
							
				try {
				driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
				Thread.sleep(1500);
				selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
				}catch(NoSuchElementException e) {}
				//DOCUMENT_TYPE_DROPDWN
				try {
			    driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
				selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
				}catch(NoSuchElementException e) {}
			    
				//PLAINTIFF_TEXT_BOX			
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
				//DEFENDANT_TEXT_BOX				
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
				
				waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
				type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
				}
				else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				 //FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				//CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if(action.size()>0) {
					
						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				}
				 catch(NoSuchElementException e) {}
				Thread.sleep(1000);
				driver.switchTo().defaultContent();
				assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
				click(SOP.GLYPHICON_HOME, "glyphicon button");
				Thread.sleep(3000);
				driver.switchTo().frame("frame1");		
				waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
				type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
				try {
					driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
					selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
					}catch(NoSuchElementException e) {}
					//DOCUMENT_TYPE_DROPDWN
					try {
					driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
					selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}
					
					//PLAINTIFF_TEXT_BOX			
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
					//DEFENDANT_TEXT_BOX				
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
						
				}		
					try {
						// ATTORNEY_SENDER_LABEL
						driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

					} catch (NoSuchElementException e) {

						printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
					}
					try {
						// COURT_LABEL
						driver.findElement(SOP.COURT_LABEL);

					} catch (NoSuchElementException e) {
						printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
					}
					try {
						// REJECTION_RULES_LABEL
						driver.findElement(SOP.REJECTION_RULES_LABEL);
					} catch (NoSuchElementException e) {
						printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

					}
					//Below one check can be applied if attorney and court modification needs to be done - 1476
					if(!attorneyName.equals("")) {			 			
							//RADIO_BUTTON_ATTORNEYNONE					
							String attorneyNoneAttribute = "";
					/*		try {
								attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");   			
					            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
								click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
								//DROP_DOWN_ATTORNEY_SENDER_NAME
								waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"Drop down for Attorney Sender Name");
								assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"DROP down for Attorney Sender Name");
								selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"DROP down for Attorney Sender Name");
						   } catch (NoSuchElementException e) {}}*/
							try {

								waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
								assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
								click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
								
								//TEXT_BOX_ATTORNEYNAME
								waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
								assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");
								
								//ATTORNEY_ADDRESS_LINE_ONE
							    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
							    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
							    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
								
								//CITY_NAME
								waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
								assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
								type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
								
								//ATTORNEY_STATE_NAME
								waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
								assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
								type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
								
								//ATTORNEY_ZIP_CODE
								waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
								assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
								type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");

							} catch (NoSuchElementException e) {
							}
						}
	
					   
					 if(!courtName.equals("")) {					
						try {
								String courtNoneAttribute = "";
								courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
					            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
								click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
								//DROP_DOWN_COURT_NAME
								waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
								assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
								selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");
						  } catch (NoSuchElementException e) {}}
					 Thread.sleep(1000);
					 List<WebElement> traceableMail = null;
						try {				
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
						type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
						}catch(NoSuchElementException e) {}
				 //Below one check to validate Hard copy Required label and data
				//HARD_COPY_DELIVERY
				waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
				compareStrings(hardCopyDeliveryFlag,getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value"));
				//REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
				//CES_INTERNAL_COMMENTS
    			waitForElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
    			assertElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
    			type(SOP.CES_INTERNAL_COMMENTS,"Internal Comments added through Selenium Automation", "Ces internal comments ins CES page");
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				Thread.sleep(5000);
					
			}
		if(hardCopyDeliveryFlag.equals("No")) {		
			String parentWin= driver.getWindowHandle();
			Thread.sleep(2000);
			handlePopUpWindwow();
			String letterPopup = driver.getCurrentUrl();
			String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);		
			assertTextContains(letterPopup,rejectLog);
			driver.close();
			driver.switchTo().window(parentWin);
		}	
		}catch(Exception e){}	
		return esopId;
	 }

	public void moveESOPFromNewQueueToDiffCESQueue(String reportSheet, int count) throws Throwable{
		
		String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);	
		String moveNewCES = Excelobject.getCellData(reportSheet, "Move New CES To", count);		
		String esopId = "";
		try {
		esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], 157001).get(0);
		}catch(Exception e) {
		System.out.println("ESOP is : " + esopId);	
		}		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");			    		
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");		
		searchForESOP(esopId);		
		try {		 
		WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
		waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOP(esopId);			
		}catch(NoSuchElementException e) {}
		Thread.sleep(1000);			
		waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		if(!moveNewCES.equals("OnHold")){								
		//ESCALATION_DETAILS
		waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
		assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
		click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
		//REASON_DRPDWN
		waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
		assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
		selectByVisibleText(SOP.REASON_DRPDWN,moveNewCES, "Escalation reason text box");
		//ESCALATION_COMMENTS_TEXTBOX
		waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
		assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
		type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Moving it to " + moveNewCES, "Escalation text box");
		//ESCALATE_BTN
		waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
		assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
		click(SOP.ESCALATE_BTN, "Escalate button");
		}
	 
	   else if(moveNewCES.equals("OnHold")){
		//REASON_FOR_HOLD_TEXTBOX
	    waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
		assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
		type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
		//ONHOLD_BTN
		waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
		assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
		click(SOP.ONHOLD_BTN, "On Hold button"); 
	   }   		 
	}
	
	//Below function to Submit the CES as per the Hard copy Required Y or N
	public String submitESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
			
			try {												
			    esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode))
					.get(0);
			
			}catch(IndexOutOfBoundsException e) {
			}
			if (!cesQueue.equals("New") && esopId.equals("")) {
				moveESOPFromNewQueueToDiffCESQueue(reportSheet, count);
				esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode))
						.get(0);
			}

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//Below change is Part of Sprint 53 changes
		      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
		     //Till here Sprint 53 changes
			if (cesQueue.equals("New")) {
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					//Below change is Part of Sprint 53 changes
				      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
				     //Till here Sprint 53 changes
					waitForElementPresent(SOP.CLEARBTN, "Clear Button");
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");
					searchForESOP(esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(1000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				
				//INCLUDE_ALL_REP_ASSUMED_BTN
				waitForElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				assertElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
								
				// SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							click(SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(1000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1000);
						selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					/*
					 * waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					 * assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					 * click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 */
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");

					/* Code changed during Accelerated Log Project */
					//Below try and catch block added as part of Sprint 53 scripting
					//from line 8891 to 9024
					String parentWindow = driver.getWindowHandle();
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow();
						driver.close();
						driver.switchTo().window(parentWindow);
						}
					}catch(NoSuchSessionException e ) {
						
					}
					Thread.sleep(1000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					click(SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow();
						driver.close();
						driver.switchTo().window(parentWindow);
						Thread.sleep(1000);
						driver.switchTo().frame("frame1");
						}
					}catch(NoSuchSessionException e ) {
						
					}

					
					try {

						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						if (!lawSuit.equals("")) {
							System.out.println("Reached here with lawsuit value : " + lawSuit);
							selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");

						}

						else {

							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						}
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {

						waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
						assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
						click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
						
						//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
					    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");
						
						//ATTORNEY_ADDRESS_LINE_ONE
					    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
						
						//CITY_NAME
						waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
						
						//ATTORNEY_STATE_NAME
						waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
						
						//ATTORNEY_ZIP_CODE
						waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");

					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						//USE_THIS_COURT
						waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
						assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
						click(SOP.USE_THIS_COURT,"Use this court radio button");
						//COURT_NAME_TEXT_BOX
						waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
						assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
						type(SOP.COURT_NAME_TEXT_BOX,courtName,"Court NAme");
						//ADDRESS_LINE_ONE
						waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
						assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
						type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
						//CITY_NAME
						waitForElementPresent(SOP.CITY_NAME,"City Name text box");
						assertElementPresent(SOP.CITY_NAME,"City Name text box");
						type(SOP.CITY_NAME,"Houston","City Name text box");
						//STATE_NAME
						waitForElementPresent(SOP.STATE_NAME,"State Name text box");
						assertElementPresent(SOP.STATE_NAME,"State Name text box");
						type(SOP.STATE_NAME,"TX","State Name text box");
						//ZIP_CODE
						waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
						type(SOP.ZIP_CODE,"77550","Zip code text box");

					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				/*
				 * //HARD_COPY_DELIVERY waitForElementPresent(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * assertElementPresent(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * compareStrings(hardCopyDeliveryFlag,getText(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value"));
				 */
				List<WebElement> reasonForNotRejection = null;
				// REASON_FOR_NOT_REJECTING
				try {
					reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
					if (reasonForNotRejection != null) {
						selectByIndex(SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
					}
				} catch (NoSuchElementException e) {
				}
				//CES_INTERNAL_COMMENTS
    			waitForElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
    			assertElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
    			type(SOP.CES_INTERNAL_COMMENTS,"Internal Comments added through Selenium Automation at processing level", "Ces internal comments ins CES page");
				// SUBMIT_CES
				waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
				assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
				click(SOP.SUBMIT_CES, "Submit button in CES");
				Thread.sleep(1000);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return esopId;
	}

	//Below function moves ESOP to Escalated or On Hold Queue
	public String esopEscalatedOrOnHold(String reportSheet, int count) throws Throwable {

		  String esopId = "";
			try {
				String escalated = Excelobject.getCellData(reportSheet, "Escalate", count);
				String onHold = Excelobject.getCellData(reportSheet, "Hold", count);
				String unidentifiedEntity = Excelobject.getCellData(reportSheet, "Unidentified Entity", count);
				String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
				String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
				String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
				String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
				String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
				String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
				String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
				
				waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				click(SOP.SOP_LINK_HEADER, "SOP link in header");				
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);
				//To run Sprint 33 and 34 us we need this to be uncommented
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				//CESSELECTBTN
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				Thread.sleep(2000);
				driver.switchTo().frame("frame1");
				Thread.sleep(2000);
				if(!arrowEntity.equals("")) {
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					if (branchPlant.equals("CTCORP")) {
						//CTCORP_RADIO_BUTTON
							assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	
										
						}
						else if (branchPlant.equals("NRAI")) {
							//NRAI_RADIO_BUTTON
							assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	
											
							}	
					//ENTITY_NAME_TEXTFIELD
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					//(SOP.FILTERTEXTFIELD, filename, "Filter text field");		
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
					//SEARCH_BTN
					waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					assertElementPresent(SOP.SEARCH_BTN, "Search button");
					click(SOP.SEARCH_BTN, "Search button");
					//FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					driver.switchTo().frame("frame1");
					Thread.sleep(2000);
					
				}
				else if(!unidentifiedEntity.equals("")) {
					//UNIDENTIFIED_ENTITY_RADIO_BUTTON
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
					click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Click on Unidentified entity radio button");	
					if (branchPlant.equals("CTCORP")) {
					//BRANCH_PLANT_UNIDENTIFIED_ENTITY
					waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY,"CTCORP", "Branch Plant drop down");	
		
				} else if (branchPlant.equals("NRAI")) {
					//Select the drop down for NRAI
					waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY,"NRAI", "Branch Plant drop down");	
					}
					//ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");	
					type(SOP.ENTITY_TEXT_BOX,unidentifiedEntity,"Entity search text box on ESOP");
					//DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");	
					selectByVisibleText(SOP.DOMESTIC_JURISDICTION_SELECTION,"Arizona","Domestic Jurisdiction in CES Page");
					//REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");	
					selectByVisibleText(SOP.REP_JURISDICTION_SELECTION,"Arizona","Rep Jurisdiction in CES Page");				
					}
				//CASE_ID_TEXTBOX
				waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
				type(SOP.CASE_ID_TEXTBOX,caseNumber, "Case Number text box");
				if (branchPlant.equals("CTCORP")) {
					waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
					assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
					selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
				} else if (branchPlant.equals("NRAI")) {
					waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

				}
				//PLAINTIFF_TEXT_BOX
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box");
				//DEFENDANT_TEXT_BOX
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box");
				
				waitForElementPresent(SOP.ESOPID,"ESOP ID");
				assertElementPresent(SOP.ESOPID,"ESOP ID");
				esopId = getText(SOP.ESOPID,"ESOP ID");
				
				if(!escalated.equals("")) {
				//ESCALATION_DETAILS
				waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
				//REASON_DRPDWN
				waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");//
				//ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Entity escalated", "Escalation text box");
				//ESCALATE_BTN
				waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				click(SOP.ESCALATE_BTN, "Escalate button");			
				}
				else if(!onHold.equals("")) {
				//REASON_FOR_HOLD_TEXTBOX
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On hold text box in CES Page");
				type(SOP.REASON_FOR_HOLD_TEXTBOX,"On hold for verification", "Reason for On hold text box in CES Page");
				//ONHOLD_BTN
				waitForElementToBeClickable(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
				assertElementPresent(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
				click(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
				}		

			} catch (Exception e) {
			}
			return esopId;
	  }

	//Below function process the CES from Escalated or On Hold Queue
	public void processEscalatedOrOnHoldESOP(String reportSheet, int count,String esopId) throws Throwable {

		try {
			String checkedArrowEntity = "";
			String caseNumber = "";
			String lawSuitType = "";
			String docType = "";
			String plaintiff = "";
			String defendant = "";
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "New Entity Searched", count);
			String relatedLog = Excelobject.getCellData(reportSheet, "Related Log", count);
			String hold = Excelobject.getCellData(reportSheet, "Hold", count);			
			//CES_LEFT_NAV_LINK
			waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			click(SOP.CES_LEFT_NAV_LINK,"Click on CES Link in SOP List Page");
			if(!hold.equals("")){
			//ON_HOLD_LIST_TAB
			waitForElementToBeClickable(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");
			assertElementPresent(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");
			click(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");	
			}
			//FILTERDROPDOWN1
			waitForElementPresent(SOP.FILTERDROPDOWN1,"First Filter in CES Page");
			assertElementPresent(SOP.FILTERDROPDOWN1,"First Filter in CES Page");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"ESOP Id","First Filter in CES Page");
			//FILTERDROPDOWN2
			waitForElementPresent(SOP.FILTERDROPDOWN2,"Second Filter in CES Page");
			assertElementPresent(SOP.FILTERDROPDOWN2,"Second Filter in CES Page");
			selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Second Filter in CES Page");
			//FILTERTEXTFIELD
			assertElementPresent(SOP.FILTERTEXTFIELD,"Text box in CES Page");
			type(SOP.FILTERTEXTFIELD,esopId,"Text box in CES Page");
			//FILTERGOBTN
			assertElementPresent(SOP.FILTERGOBTN,"Go Button in CES Page");
			click(SOP.FILTERGOBTN,"Go Button in CES Page");
			if(hold.equals("")){
			//FIRST_CES_SELECT_BUTTON
			waitForElementToBeClickable(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			click(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			}
			else if(!hold.equals("")){
			waitForElementToBeClickable(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");
			assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");
			click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");			
			}
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if(branchPlant.contains("NRAI")) {

				docType = getText(SOP.SELECTED_DOC_TYPE, "Document Type drop down in CES Page");
			}
			else if (branchPlant.contains("CTCORP")) {
				lawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
			}
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			//TRACEABLE_MAIL_FIELD
			try {
			traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
			if(traceableMail != null) { 
			type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
			}
			}catch(NoSuchElementException e) {}
			plaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
	        defendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
	        caseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			try {
			checkedArrowEntity = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON,"checked");
			}catch(NullPointerException e) {}
			if(checkedArrowEntity == null) {
				assertElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Arrow Entity Radio button");
				click(SOP.ARROW_ENTITY_RADIO_BUTTON,"Click on Arrow Entity Radio button");
			}
			
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			
				if (branchPlant.equals("CTCORP")) {
					//CTCORP_RADIO_BUTTON
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	
									
					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	
										
						}
				
				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				//(SOP.FILTERTEXTFIELD, filename, "Filter text field");		
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
			
				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
				assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
				click(SOP.SEARCH_BTN, "Search button in CES Page");
				Thread.sleep(2000);
				//UNIDENTIFIED_ENTITY_BTN
				List<WebElement> entityNotFound = null;
				try {
					entityNotFound = driver.findElements(SOP.FIRST_ENTITY_IN_SEARCH_RESULT);
				}catch(NoSuchElementException e) {}
				if(entityNotFound == null) {
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "unidentified Entity button in CES Page");
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "click on unidentified Entity button in CES Page");
					Thread.sleep(2000);
									
					if(branchPlant.contains("NRAI")) {
						waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
						Thread.sleep(1000);
						String newDocType = getText(SOP.SELECTED_DOC_TYPE,"selected Doc type value");			
						printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
					}
					else if (branchPlant.contains("CTCORP")) {
						waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
						Thread.sleep(1000);
						String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
						printMessageInReport("Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);								
					}
				}
				else if(entityNotFound != null) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT,"First entity link in CES Page");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "click on First entity link in CES Page");
				if(relatedLog.equals("")) {
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(1000);
					driver.switchTo().frame("frame1");
					Thread.sleep(1000);
					
				}
				else if(!relatedLog.equals("")) {
					//WORKSHEET_ID_TEXTBOX
					waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					type(SOP.WORKSHEET_ID_TEXTBOX,relatedLog,"Worksheet id text box in CES Page");
					//SEARCH_BTN
					assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
					click(SOP.SEARCH_BTN, "Click on Search button in CES Page");
					//FIRST_WORKSHEET_RADIO_BTN
					waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					//ADD_MANIFEST_BTN
					assertElementPresent(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
					click(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
					Thread.sleep(1000);
				}	
			}
				if(branchPlant.contains("NRAI")) {
					waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					Thread.sleep(1000);
					String newDocType = getText(SOP.SELECTED_DOC_TYPE,"selected Doc type value");			
					printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
				}
				else if (branchPlant.contains("CTCORP")) {
					waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
					Thread.sleep(1000);
					String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
					printMessageInReport("Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);								
				}
				String newPlaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
				Thread.sleep(1000);
				String newDefendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
				Thread.sleep(1000);
				String newCaseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
				//SUBMIT_CES
				waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
				assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
				click(SOP.SUBMIT_CES, "Submit button in CES Page");	
				printMessageInReport("Previous plaintiff : " + plaintiff + " and new plaintiff : " + newPlaintiff);
				printMessageInReport("Previous defendant : " + defendant + " and new defendant : " + newDefendant);
				printMessageInReport("Previous case number : " + caseNumber + " and new case Number : " + newCaseNumber);
			
				
		}catch (Exception e) {
				e.printStackTrace();
			}
			
	 }
	
	
	
	public void searchWorksheet(String worksheetId) throws Throwable {
		try {
			blnEventReport = true;
			//Click On Worksheet Search Link from left nav bar
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK,"Worksheet Search On Left Nav Link");
			click(SOP.CLASSIC_SEARCH_BTN,"Classic Search Button");
			waitForElementPresent(SOP.SEARCH_BTN, "Search Button");
			
			//Enter an entity Id to be searched and click on search btn
			type(SOP.WORKSHEET_ID_TEXTBOX,worksheetId,"Workhseet Id text Box");
			click(SOP.WORKSHEET_SEARCH_BTN,"Worksheet Search Btn");
						
		} catch (Exception e) {
			throw e;
		}
	}
	
	public String createWorksheetViaSOPList(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
		    searchForESOP(esopId);		
			try {		 
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
			    searchForESOP(esopId);			
				
			}catch(NoSuchElementException e) {}
			//Below is modified to wait for CReate ws button
			for(int i=0 ;i<3; i++) {
			Thread.sleep(15000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(15000);
			}
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			Thread.sleep(20000);
			searchForESOP(esopId);		
			String parentWindow= driver.getWindowHandle();		
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");		
			click(SOP.VIEW_BTN, "View button");		
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(2000);
			WebElement createWs = null;
			try {
			createWs = driver.findElement(SOP.CREATE_WORKSHEET);
			waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			}catch(NoSuchElementException e) {			
			}
			if(createWs == null) {
				Thread.sleep(10000);
				selectAndAssignTheFileToTeam();
				Thread.sleep(10000);
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				Thread.sleep(2000);
				String parentWin= driver.getWindowHandle();		
				waitForElementPresent(SOP.VIEW_BTN, "View button");
				assertElementPresent(SOP.VIEW_BTN, "View button");		
				click(SOP.VIEW_BTN, "View button");		
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
				click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
public void worksheetInMyWorksheetsAndMyTeamWorksheet(String reportSheet , int count) throws Throwable{
		
		String sopWorkFlow = Excelobject.getCellData(reportSheet, "SOP Workflow", count);
		String worksheetIn = Excelobject.getCellData(reportSheet, "Worksheet In", count);
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//MY_WORKSHEETS_NAV_LINK
		waitForElementPresent(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");
		assertElementPresent(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");
		click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");		
		
		if(!worksheetIn.equals("My Worksheet")) {
		 //MY_TEAMS_WORKSHEETS_LINK
		 waitForElementPresent(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");
		 assertElementPresent(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");
		 click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");	
			
		}
		
		searchForSOPWorkflow(sopWorkFlow);
		String records = "";
		Thread.sleep(600);
		try {
			WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
			records =  getText(SOP.NO_RECORDS_BAR,"Test for no records found");
		}catch(NoSuchElementException e) {}
		if(!records.contains("No records found.")) {
		// FIRST_WORKSHEET
		waitForElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		assertElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		click(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
        //SOP_WORKFLOW
		waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
        compareStrings(sopWorkFlow,workflowInWorksheet);
		}
	}

public void searchForSOPWorkflow(String workflow) throws Throwable {

	waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
	assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
	selectByVisibleText(SOP.FILTERDROPDOWN1, "SOP WorkFlow", "Filter drop down");
	waitForElementToBeClickable(SOP.DROP_DOWN_LIST_RIGHT, "Filter drop right");
	assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter drop right");
	selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, workflow, "Filter drop right");
	waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
	assertElementPresent(SOP.FILTERGOBTN, "Go Button");
	click(SOP.FILTERGOBTN, "Go Button");
}

public void  createRoleForTransmittalType(String reportSheet, int count) throws Throwable {
	try {
		String role = Excelobject.getCellData(reportSheet, "Role Name", count);

		// ADMIN_TAB
		waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
		assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
		click(Admin.ADMIN_TAB, "Admin Tab in the header");
		
		//CREATE_ROLE_BTN
		waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role button in Roles Page");
		assertElementPresent(Admin.CREATE_ROLE_BTN, "Create Role button in Roles Page");
		click(Admin.CREATE_ROLE_BTN, "Create Role button in Roles Page");
		
		//ROLE_NAME_TEXT_BOX
		waitForElementPresent(Admin.ROLE_NAME_TEXT_BOX, "Role name textbox in Create Role Page");
		assertElementPresent(Admin.ROLE_NAME_TEXT_BOX, "Role name textbox in Create Role Page");
		type(Admin.ROLE_NAME_TEXT_BOX,role, "Role name textbox in Create Role Page");
		
		//MAINTAIN_TRANSMITTAL_TYPE
		waitForElementPresent(Admin.MAINTAIN_TRANSMITTAL_TYPE, "Permission for Maintain Transmittal Type in Create Role Page");
		assertElementPresent(Admin.MAINTAIN_TRANSMITTAL_TYPE, "Permission for Maintain Transmittal Type in Create Role Page");
		click(Admin.MAINTAIN_TRANSMITTAL_TYPE, "Click on Permission for Maintain Transmittal Type in Create Role Page");
		
		// SAVEBTN
		waitForElementPresent(Admin.SAVEBTN, "wait for save button link in Roles Page");
		assertElementPresent(Admin.SAVEBTN, "assert save button link in Roles Page");
		click(Admin.SAVEBTN, "click on save button link in Roles Page");								

	} catch (Exception e) {
	}
}

public void assignTheRoleToTheUser(String reportSheet, int count) throws Throwable {
	
	try{	
	String role = Excelobject.getCellData(reportSheet, "Role Name", count);
    String user = Excelobject.getCellData(reportSheet, "User", count);
	// ADMIN_TAB
	waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	click(Admin.ADMIN_TAB, "Admin Tab in the header");
	// FIRST_FILTER_DRPDWN
	waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
	// SECOND_FILTER_DRPDWN
	waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
	// FILTER_TEXT_FILED
	waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
	// GO_BTN
	waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	click(Admin.GO_BTN, "Go Button in Roles Page");
	// FIRST_ROLE_ON_THE_GRID
	waitForElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
	assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
	click(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
	//MAINTAIN_BTN
	waitForElementPresent(Admin.MAINTAIN_BTN, "wait for Maintain button in Roles Page");
	assertElementPresent(Admin.MAINTAIN_BTN, "Assert Maintain button in Roles Page");
	click(Admin.MAINTAIN_BTN, "Click on Maintain button in Roles Page");
	//GRANT_ROLE_BTN
	waitForElementPresent(Admin.GRANT_ROLE_BTN, "wait for Grant role button in Role Users Page");
	assertElementPresent(Admin.GRANT_ROLE_BTN, "Assert Grant role button in Role Users Page");
	click(Admin.GRANT_ROLE_BTN, "Click Grant role button in Role Users Page");
	//EMPLOYEE_NAME_TEXTBOX
	waitForElementPresent(Admin.EMPLOYEE_NAME_TEXTBOX, "wait for Employee name text field in Find Users Page");
	assertElementPresent(Admin.EMPLOYEE_NAME_TEXTBOX, "ASsert Employee name text field in Find Users Page");
	type(Admin.EMPLOYEE_NAME_TEXTBOX,user, "wait for Employee name text field in Find Users Page");
	//FIND_BTN
	waitForElementPresent(Admin.FIND_BTN, "Find button in Find Users Page");
	assertElementPresent(Admin.FIND_BTN, "Asserty Find button in Find Users Page");
	click(Admin.FIND_BTN, "Click on Find button in Find Users Page");
	//FIRST_CHECKBOX_ON_EMPLOYEE_GRID
	waitForElementPresent(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "First check box in Pick Users Page");
	assertElementPresent(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "Assert First check box in Pick Users Page");
	click(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "Click on First check box in Pick Users Page");
	//GRANT_ROLE_BTN
	waitForElementPresent(Admin.GRANT_ROLE_BTN, "wait for Grant role button in Role Users Page");
	assertElementPresent(Admin.GRANT_ROLE_BTN, "Assert Grant role button in Role Users Page");
	click(Admin.GRANT_ROLE_BTN, "Click Grant role button in Role Users Page");			
	
} catch (Exception e) {
}
}

public void editTheTransmittalTypeInAff(String reportSheet, int count) throws Throwable{
	
	try{
	  
	  String transmittalType = Excelobject.getCellData(reportSheet, "Transmittal Type Cd", count);
	  String transmittalValue = Excelobject.getCellData(reportSheet, "Transmittal Value", count);
	  String affiliationId = SQL_Queries.getTheAffIdForTheTransmittalType(transmittalType).get(0);
	  
	  	    waitForElementPresent(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			assertElementPresent(HomePage.AFFILIATION_TAB, "Assert Affiliation Search Link");
			click(HomePage.AFFILIATION_TAB, "Click on AAffiliation Tab in Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
			assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(Affiliation.SEARCHBTN, "Search Button");
			// EDITBTN
			waitForElementPresent(Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			assertElementPresent(Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			click(Affiliation.EDITBTN, "Click on Edit Button");
			
			//TRANSMITTAL_TYPE_DROP_DOWN
			waitForElementPresent(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, "Transmittal Type Drop down in Edit Affiliation Page");
			assertElementPresent(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, "assert Transmittal Type Drop down in Edit Affiliation Page");
			
			if(transmittalValue.equals("Full")){
			
			selectByVisibleText(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, transmittalValue , "select Full Transmittal Type Drop down in Edit Affiliation Page");
			}
			
			else if(transmittalValue.equals("--")){
			
			selectByVisibleText(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, "-- Select One --" , "select Full Transmittal Type Drop down in Edit Affiliation Page");
			}
			
			else if(transmittalValue.equals("")){
			
			//TRANSMITTAL_TYPE_DROP_DOWN_DISABLED
			assertElementPresent(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN_DISABLED, "assert disabled Transmittal Type Drop down in Edit Affiliation Page");
			
			}
			
			//COMMENTFIELD			
			assertElementPresent(Affiliation.COMMENTFIELD, "Comment text box in Edit Affiliation Information Page");
			type(Affiliation.COMMENTFIELD, "Comments entered with Selenium Automation", "Comment text box in Edit Entity Information Page");
			
			// SAVE_BTN
			assertElementPresent(Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");
			click(Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");
	
	}catch(NoSuchElementException e){
		e.printStackTrace();
	}
}

public void revokeTheGrantFromTheUser(String reportSheet, int count) throws Throwable {
	
	try{	
	String role = Excelobject.getCellData(reportSheet, "Role Name", count);
    String user = Excelobject.getCellData(reportSheet, "User", count);
	// ADMIN_TAB
	waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	click(Admin.ADMIN_TAB, "Admin Tab in the header");
	// FIRST_FILTER_DRPDWN
	waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
	// SECOND_FILTER_DRPDWN
	waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
	// FILTER_TEXT_FILED
	waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
	// GO_BTN
	waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	click(Admin.GO_BTN, "Go Button in Roles Page");
	// FIRST_ROLE_ON_THE_GRID
	waitForElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
	assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
	click(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
	//MAINTAIN_BTN
	waitForElementPresent(Admin.MAINTAIN_BTN, "wait for Maintain button in Roles Page");
	assertElementPresent(Admin.MAINTAIN_BTN, "Assert Maintain button in Roles Page");
	click(Admin.MAINTAIN_BTN, "Click on Maintain button in Roles Page");
	//here search for the user
	//FIRST_FILTER_DRPDWN
	waitForElementToBePresent(Admin.FIRST_FILTER_DRPDWN,"First filter drop down in Role Page");
	assertElementPresent(Admin.FIRST_FILTER_DRPDWN,"First filter drop down in Role Page");
	selectByVisibleText(Admin.FIRST_FILTER_DRPDWN,"Name","First filter drop down in Role Page");
	//SECOND_FILTER_DRPDWN
	waitForElementToBePresent(Admin.SECOND_FILTER_DRPDWN,"Second filter drop down in Role Page");
	assertElementPresent(Admin.SECOND_FILTER_DRPDWN,"Second filter drop down in Role Page");
	selectByVisibleText(Admin.SECOND_FILTER_DRPDWN,"contains","Second filter drop down in Role Page");
	//FILTER_TEXT_BOX
	waitForElementToBePresent(Admin.FILTER_TEXT_BOX,"Text box top right in Role Page");
	assertElementPresent(Admin.FILTER_TEXT_BOX,"Text box top right in Role Page");
	type(Admin.FILTER_TEXT_BOX,user,"Text box top right in Role Page");
	//
	waitForElementToBePresent(Admin.GO_BTN, "GO Button in the Role Page");
	assertElementPresent(Admin.GO_BTN, "GO Button in the Role Page");
	click(Admin.GO_BTN, "GO Button in the Role Page");
	//FIRST_CHECKBOX_ON_GRANT_GRID
	waitForElementToBePresent(Admin.FIRST_CHECKBOX_ON_GRANT_GRID,"First check box in data grid");
	assertElementPresent(Admin.FIRST_CHECKBOX_ON_GRANT_GRID,"First check box in data grid");
	click(Admin.FIRST_CHECKBOX_ON_GRANT_GRID,"First check box in data grid");
	
	//REVOKE_GRANT_BTN
	waitForElementPresent(Admin.REVOKE_GRANT_BTN, "wait for revoke Grant role button in Role Users Page");
	assertElementPresent(Admin.REVOKE_GRANT_BTN, "Assert Revoke Grant role button in Role Users Page");
	click(Admin.REVOKE_GRANT_BTN, "Click Revoke Grant role button in Role Users Page");
	
	} catch (Exception e) {
}
}

public void deleteTheRole(String reportSheet, int count) throws Throwable {
	
	try{	
	String role = Excelobject.getCellData(reportSheet, "Role Name", count);
	// ADMIN_TAB
	waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	click(Admin.ADMIN_TAB, "Admin Tab in the header");
	//FIRST_FILTER_DRPDWN
	waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
	//SECOND_FILTER_DRPDWN
	waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
	//FILTER_TEXT_FILED
	waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
	//GO_BTN
	waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	click(Admin.GO_BTN, "Go Button in Roles Page");
	//FIRST_DELETE_BUTTON_ON_GRID
	waitForElementToBePresent(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button in Roles Page");
	assertElementPresent(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button in Roles Page");
	click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button in Roles Page");
    
	handlepopup();

	}catch(Exception e) {}
}
public void sopWorkflow(String reportSheet, int count, String esopId) throws Throwable {
	String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
	String logNumber = "";
	
	//Below check is added as part of dev ops Sprint 3 changes and this should be merged post GM merge
	for(int i=0 ;i<10; i++) {			
	String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
	if(isHandlerProcessed.equals("N")) {
	Thread.sleep(10000);
	}
	else {
		break;
	}		
	}
	try {
		Thread.sleep(2000);
		logNumber = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
	} catch (IndexOutOfBoundsException e) {
		e.printStackTrace();
	}
	searchWorksheet(logNumber);

	// SOP_WORKFLOW
	waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
	assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
	String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");

	if (workflow.equals("151001")) {

		compareStrings("Full",workflowInWorksheet);

	}

	else if (workflow.equals("151002")) {

		compareStrings( "Accelerated",workflowInWorksheet);
	}
	
	//this function needs to be modify to accommodate the new SOP Workflow checks
	//below function is modified and added below checks as part of NPD devops Sprint 2 
	if (workflow.equals("151004")) {

		compareStrings("Optimized Manual",workflowInWorksheet);

	}

	else if (workflow.equals("151005")) {

		compareStrings("Optimized",workflowInWorksheet);
	}
	
}

public void executeActionItem(String reportSheet,int count,String esopId) throws Throwable {
	//uncomment below before completed implmentation of fxn
		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
	    String  lawsuitType = Excelobject.getCellData(reportSheet, "Law Suit Type", count);
		String  hardCopyRequired = Excelobject.getCellData(reportSheet, "Hard Copy DI", count);
		String  specialCircumstance = Excelobject.getCellData(reportSheet, "Special Circumstances", count);
		
		//String expeditedLog = "538121340";
		waitForElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		
		if(hardCopyRequired.equals("No") && specialCircumstance.equals("Yes")) {		
			   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
			//VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES
				int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES,lawsuitType);		   
				System.out.println("the index sent is : " + matchedIndexLawSuit);
			   //USE_BUTTON_IN_LAWSUIT
				//USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES
			    clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
				
			}	
		else if(hardCopyRequired.equals("No") && specialCircumstance.equals("No")) {		
	   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
		int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_NO_SPECIAL_CIRCUMSTANCES,lawsuitType);
	   
		System.out.println("the index sent is : " + matchedIndexLawSuit);
	   //USE_BUTTON_IN_LAWSUIT
		//USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES
	    clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
		
		}
		else if(hardCopyRequired.equals("Yes")) {
		
			int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES,lawsuitType);
			clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
		}	
		//EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL
		Thread.sleep(500);
		try{
		WebElement executeManual = driver.findElement(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL);
		 //waitForElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 click(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 //COMMENTS_DRPDWN
		 waitForElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 selectByVisibleText(SOP.COMMENTS_DRPDWN,"Hard Copy Required","Execute Manual in SOP Papers with Transmittal");
		 //CONTINUE_BUTTON
		 waitForElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 assertElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 click(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 try {
			 WebElement createPackage = driver.findElement(By.id("btnCreatePackage"));
			 createPackage.click();
		 }catch(NoSuchElementException e) {}
		 //SAVE_BTN
		 assertElementPresent(Entity.SAVE_BTN, "Save button");
		 click(Entity.SAVE_BTN, "Save button");
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");	
/*		   for(int i = 0 ; i<3; i++) {	 
			   try {
			   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13023").get(0)	;	   
			   if(!executedBy.equals("")) {
				  Thread.sleep(5000);	
				   break;
			       }
			   }catch(IndexOutOfBoundsException e) {
				   Thread.sleep(5000);
				   }
		   }*/
		}catch(NoSuchElementException e){}
		
		
		//EXECUTE_SOP_PAPER_WITH_TRANSMITTAL
		Thread.sleep(500);
		try{
		WebElement execute = driver.findElement(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL);
		 //waitForElementPresent(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute in SOP Papers with Transmittal");
		 assertElementPresent(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute  in SOP Papers with Transmittal");
		 click(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute  in SOP Papers with Transmittal");
		
	/*	   for(int i = 0 ; i<3; i++) {	 
			   try {
			   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13010").get(0)	;	   
			   if(!executedBy.equals("")) {
				  Thread.sleep(5000);	
				   break;
			       }
			   }catch(IndexOutOfBoundsException e) {
				   Thread.sleep(5000);
				  }
		   }*/
		}catch(NoSuchElementException e){}
	   //SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
	   Thread.sleep(500);
	   try{
	   WebElement retainButton = driver.findElement(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL);
	   //waitForElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
	   assertElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with ransmittal");
	   click(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");   

/*		   for(int i = 0 ; i<10; i++) {	 
			   try {
			   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13021").get(0)	;	   
			   if(executedBy.equals("1166")) {
				  Thread.sleep(2000);	
				   break;
			       }
			   }catch(NullPointerException e) {
				   Thread.sleep(5000);
				  }
		   }*/
	   }catch(NoSuchElementException e){/*e.printStackTrace();*/}
	   	
	    //EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL
	   Thread.sleep(500);
	   try{
	   WebElement isopButton = driver.findElement(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL);
	   //waitForElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   assertElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   click(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   }catch(NoSuchElementException e){} 
	   // below code is committed as this functionality is handled in different function to reduce the execution run time	  
	 /* for(int i = 0 ; i<10; i++) {	 
		   try {
		   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13014").get(0)	;	   
		   if(executedBy.equals("1166")) {
				  Thread.sleep(2000);	
			   break;
		       }
		   }catch(NullPointerException e) {
			   Thread.sleep(5000);
			   e.printStackTrace();}
	  }
	   }catch(NoSuchElementException e){e.printStackTrace();}   
	   //logPostedInWorksheet
	     
	   for(int i = 0 ; i<10; i++) {	
		   String isLogPosted = SQL_Queries.logPostedInWorksheet(expeditedLog).get(0)	;	   
		   if(isLogPosted.equals("N")) {			
			   Thread.sleep(10000);	
		   }
		   else {
			   break;
		       }
	   }
	   Thread.sleep(2000);
	   //WORKSHEET_PROFILE_LINK
	   waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   click(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   
	   //POST_STATUS
	   assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
	   String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
	   compareStrings(postStatus, "Posted");
	  */    
	} 

	public void validateThePostStatusOfworksheet(String worksheetId) throws Throwable {

		for (int i = 0; i < 10; i++) {
			String isLogPosted = SQL_Queries.logPostedInWorksheet(worksheetId).get(0);
			if (isLogPosted.equals("N")) {
				Thread.sleep(2000);
			} else {
				break;
			}
		}
//WORKSHEET_PROFILE_LINK
/*		waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet profile link");
		assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet profile link");
		click(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet profile link");*/

//POST_STATUS
		assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus, "Posted");
}     

}
