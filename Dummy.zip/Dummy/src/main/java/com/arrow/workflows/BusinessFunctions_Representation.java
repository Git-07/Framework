package com.arrow.workflows;

import java.util.ArrayList;

import org.apache.poi.ss.formula.functions.Today;
import org.openqa.selenium.By;

import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BusinessFunctions_Representation extends BusinessFunctions_Entity {
		
	public void catchBlock(Exception e) throws Throwable {
		if (e.getMessage() != null)
			parent.appendChild(child);
		gStrErrMsg = e.getMessage();
		closeSummaryReport(browsertype);
		driver.quit();
		openBrowser();
		Thread.sleep(lSleep_VLow);

	}
	
	//Re-instate Rep
	public String Reinstate(String ReportSheet, int count) throws Throwable {
		
		String filingDate = "";
		try {
			blnEventReport = true;
			filingDate = getText(Entity.REP_FILING_DATE, "Entity Rep Filing Date");
			click(Rep.REINSTATE, "Reinstate Button");
			click(Rep.REINSTATEMENT_REASON, "Reinstatement Reason");
			//click(Rep.REINSTATE_FILING_DATE, "Calender Icon");
			//click(Rep.TODAYSDATE, "Select Today's Date");
			//int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			//String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
			//		+ String.valueOf(lastYear); 		
			type(Rep.REINSTATEMENT_DATES, filingDate, "Reinstatement Filing Date text box");
			click(Rep.REINSTATE, "Reinstate Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	//Discontinue Button
	public String Discontinue(String ReportSheet, int count) throws Throwable {
		
		String filingDate = "";
		try {
			blnEventReport = true;
			filingDate = getText(Entity.REP_FILING_DATE, "Entity Rep Filing Date");
			click(Rep.DISCONTINUE_BUTTON, "Click on Discontinue Button");
			click(Rep.DISCONTINUE_REASON, "Discontinue Reason");
			//click(Rep.DISCONTINUE_DATE, "Click on Discontinue Date");
			//click(Rep.TODAYSDATE, "Select Today's Date");
			//int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			//String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
			//		+ String.valueOf(lastYear); 			
			type(Rep.DISCONTINUE_DATES, filingDate, "Discontinuance Filing Date text box");
			click(Rep.REP_DISCONTINUE_BUTTON, "Discontinue Rep");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	//Create Representation
	public String CreateRep(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strNumberOfYears = Excelobject.getCellData(ReportSheet, "NumberOfYears", count);
			click(Rep.CREATE_REPRESENTATION, "Create Representation Button");
			assertElementPresent(Rep.NEW_REPRESENTATION_PAGE, "New Representation Page");
			click(Rep.ARIZONA_JURISDICTION, "Select Jurisdiction");
			click(Rep.CONTRACT_AGENCY, "Contract Agency");
			click(Generic.NEXT_BUTTON, "Next Button");
			assertElementPresent(Rep.NEW_REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			type(Rep.NUMBER_OF_YEARS, strNumberOfYears, "Number of Years");
			click(Rep.FILING_DATE_BUTTON, "Filing Date Button");
			click(Rep.TODAYSDATE, "Select Today's Date");
			click(Rep.EXPIRATION_DATE_BUTTON, "Expiration Date Button");
			click(Rep.TODAYSDATE, "Select Today's Date");
			/*int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(Rep.CREATE_REP_FILING_DATES, lastYearDate, "Filing Date text box");
			type(Rep.CREATE_REP_EXPIRATION_DATES, lastYearDate, "Expiration Date text box");*/
			click(Generic.SAVE, "Save Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	//Re-instate Multiple Rep Method
	public String ReinstateMultiple(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(Rep.REINSTATE_MULTIPLE, "Re-instate Multiple");
			click(Rep.GO_BUTTON, "Go Button");
			assertElementPresent(Rep.REINSTATE_MULTIPLE_REP_PAGE, "Re-instate Multiple Rep Page");
			click(Rep.MULTIPLE_REINSTATE_REASON, "Re-instate Reason");
			click(Rep.MULTIPLE_REINSTATE_DATE, "Reinstate Date");
			click(Rep.TODAYSDATE, "Today's Date");
			/*int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(Rep.REINSTATEMENT_DATES, lastYearDate, "Reinstatement Filing Date text box");*/
			click(Generic.SELECT_ALL, "Select All");
			click(Rep.REINSTATE, "Reinstate Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	//Discontinue Multiple Rep Method
	public String DiscontinueMultiple(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityComment = Excelobject.getCellData(ReportSheet, "EntityComment", count);
			click(Rep.DISCONTINUE_MULTIPLE, "Discontinue Multiple");
			click(Rep.GO_BUTTON, "Go Button");
			assertElementPresent(Rep.MULTIPLE_REP_PAGE, "Discontinue Multiple Rep Page");
			click(Rep.MULTIPLE_DISCONTINUE_REASON, "Discontinue Reason");
			click(Rep.DISCONTINUE_DATE, "Discontinue Date");
			click(Rep.TODAYSDATE, "Today's Date");
			/*int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(Rep.DISCONTINUE_DATES, lastYearDate, "Discontinuance Filing Date text box");*/
			type(Rep.ENTITY_COMMENT, strEntityComment, "Entity Comment");
			click(Generic.SELECT_ALL, "Select All");
			click(Rep.REP_DISCONTINUE_BUTTON, "Discontinue Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : AffiliatedRepCreateAndDiscontinue() 
	 * Author : Pradyumna 
	 * Description : This method will Create and Discontinue Rep for Affiliated Entity
	 * Date of creation : 7/15/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String AffiliatedRepCreateAndDiscontinue(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			//String strNumberOfYears = Excelobject.getCellData(ReportSheet, "NumberOfYears", count);
			String strServiceType = Excelobject.getCellData(ReportSheet, "ServiceType", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			//Check if Contract Agency is present and Re-instate is present instead of Discontinue
			try {
				click(Rep.SERVICE_TYPE, "Service Type Drop Down");
				click(Generic.SECOND_DROP_CONTAINS, "Contains Drop Down");
				type(Generic.DROP_DOWN_TEXT, strServiceType, "Contract Agency");
				click(Generic.GO_BUTTON, "Go Button");
				if(verifyIfElementPresent(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency")) {
					click(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency");
					if(verifyIfElementPresent(Rep.REINSTATE, "Reinstate Button")) {
						//If re-instate button is present click on it and re-instate the rep
						Reinstate(ReportSheet, count);
						click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
					}
					else {
						click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
						System.out.println("Discontinue Button Present");
					}
				} else {
					System.out.println("Continue with remaining scenarios");
				}
			} catch (Exception e) {
				// handle else
				//click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
			}
			//Create New Rep
			CreateRep(ReportSheet, count);
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			//Search for Contract Agency
			click(Rep.SERVICE_TYPE, "Service Type Drop Down");
			click(Generic.SECOND_DROP_CONTAINS, "Contains Drop Down");
			type(Generic.DROP_DOWN_TEXT, strServiceType, "Entity ID");
			click(Generic.GO_BUTTON, "Go Button");
			//Click on Discontinue 
			click(Rep.CONTRACT_AGENCY_REP, "Click on Contract Agency rep");
			Discontinue(ReportSheet, count);
			if(verifyIfElementPresent(Rep.REVISIONS_PAGE, "Revisions Page")) {
				click(Rep.REPRESENTATION_TAB, "Representation Tab");
				click(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency");
			}
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "REPRESENTATION UNIT PROFILE");
			assertElementPresent(Rep.DISCONTINUE_STATUS, "Discontinue Status");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : StandaloneRepAndDiscontinue() 
	 * Author : Pradyumna 
	 * Description : This method will Create and Discontinue Rep
	 * Date of creation : 7/15/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String StandaloneRepAndDiscontinue(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			String strServiceType = Excelobject.getCellData(ReportSheet, "ServiceType", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			//Check if Contract Agency is present and Re-instate is present instead of Discontinue
			try {
				click(Rep.SERVICE_TYPE, "Service Type Drop Down");
				click(Generic.SECOND_DROP_CONTAINS, "Contains Drop Down");
				type(Generic.DROP_DOWN_TEXT, strServiceType, "Entity ID");
				click(Generic.GO_BUTTON, "Go Button");		
					if(verifyIfElementPresent(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency")) {
					click(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency");
					if(verifyIfElementPresent(Rep.REINSTATE, "Reinstate Button")) {
						//If re-instate button is present click on it and re-instate the rep
						Reinstate(ReportSheet, count);
						click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
					}
					else {
						click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
						System.out.println("Discontinue Button Present");
					}
				} else {
					System.out.println("Continue with remaining scenarios");
				}
			} catch (Exception e) {
				// handle else
			}
			//Create New Rep
			CreateRep(ReportSheet, count);
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			//Search for Contract Agency
			click(Rep.SERVICE_TYPE, "Service Type Drop Down");
			click(Generic.SECOND_DROP_CONTAINS, "Contains Drop Down");
			type(Generic.DROP_DOWN_TEXT, strServiceType, "Entity ID");
			click(Generic.GO_BUTTON, "Go Button");		
			//Click on Discontinue 
			click(Rep.CONTRACT_AGENCY_REP, "Click on Contract Agency rep");
			Discontinue(ReportSheet, count);
			if(verifyIfElementPresent(Rep.REVISIONS_PAGE, "Revisions Page")) {
				click(Rep.REPRESENTATION_TAB, "Representation Tab");
				click(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency");
			}
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "REPRESENTATION UNIT PROFILE");
			assertElementPresent(Rep.DISCONTINUE_STATUS, "Discontinue Status");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}	
	
	/********************************************************************************************************
	 * Method Name : DiscntinueDuetoPropertySold() 
	 * Author : Pradyumna 
	 * Description : This method will Discontinue Rep due to Property sold
	 * Date of creation : 7/16/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String DiscntinueDuetoPropertySold(String ReportSheet, int count) throws Throwable {
		
		String filingDate = "";
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			String strNumberOfYears = Excelobject.getCellData(ReportSheet, "NumberOfYears", count);
			String strServiceType = Excelobject.getCellData(ReportSheet, "ServiceType", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			//Check if Contract Agency is present and Re-instate is present instead of Discontinue
			try {
				//if (driver.findElement(By.xpath("//a[contains(text(), 'Contract Agency')]")).isDisplayed()) {
				if(verifyIfElementPresent(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency")) {
					click(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency");
					if(verifyIfElementPresent(Rep.REINSTATE, "Reinstate Button")) {
						//If re-instate button is present click on it and re-instate the rep
						Reinstate(ReportSheet, count);
					}
					else {
						System.out.println("Discontinue Button Present");
					}
				} else {
					System.out.println("Continue with remaining scenarios");
				}
			} catch (Exception e) {
				// handle else
			}
			click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
			//Discontinue due to property Sold
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			assertElementPresent(Rep.CONTRACT_AGENCY_REP, "Contract Agency Entity Created");
			//Discontinue due to Property Sold
			click(Rep.CONTRACT_AGENCY_REP, "Click on Contract Agency rep");
			filingDate = getText(Entity.REP_FILING_DATE, "Entity Rep Filing Date");
			click(Rep.DISCONTINUE_BUTTON, "Click on Discontinue Button");
			click(Rep.DISCONTINUE_REASON, "Discontinue Reason");
			//click(Rep.DISCONTINUE_DATE, "Click on Discontinue Date");
			//click(Rep.TODAYSDATE, "Select Today's Date");
			//int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			//String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
			//		+ String.valueOf(lastYear); 			
			type(Rep.DISCONTINUE_DATES, filingDate, "Discontinuance Filing Date text box");
			click(Rep.DISCONTINUE_DUE_TO_PROPERTY_SOLD, "Discontinue Due to Property Sold Button");
			if(verifyIfElementPresent(Rep.REVISIONS_PAGE, "Revisions Page")) {
				click(Rep.REPRESENTATION_TAB, "Representation Tab");
				click(Rep.CONTRACT_AGENCY_REP, "Contract Rep Agency");
			}
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "REPRESENTATION UNIT PROFILE");
			assertElementPresent(Rep.DISCONTINUE_STATUS, "Discontinue Status");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : ExportRepresentation() 
	 * Author : Pradyumna 
	 * Description : This method will Export Rep Present on page
	 * Date of creation : 7/17/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ExportRepresentation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			click(Generic.EXPORT_BUTTON, "Click on Export Button");
			//TODO Verify if Export has been done successfully
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : SortBy() 
	 * Author : Pradyumna 
	 * Description : This method will click Sort by in Rep Page
	 * Date of creation : 7/24/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SortBy(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			//Verify Sort By on Representation 
			assertElementPresent(Rep.SORT_BY_JURISDICTION_ACTIVE, "Jurisdiction is active as its default");
			click(Rep.SORT_BY_STATUS, "Sort By");
			click(Rep.SORT_BY_SERVICE_TYPE, "Service Type");
			click(Rep.SORT_BY_IS_STATE_VALIDATED, "state validated");
			click(Rep.SORT_BY_REGISTERED_AGENT, "Registered Agent");
			assertElementPresent(Rep.SORT_BY_JURISDICTION_INACTIVE, "Jurisdiction is In-active");
			click(Rep.SORT_BY_JURISDICTION_INACTIVE, "Sort By");
			assertElementPresent(Rep.SORT_BY_JURISDICTION_ACTIVE, "Jurisdiction is active as its default");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : ReinstateAndDiscontinueMultiple() 
	 * Author : Pradyumna 
	 * Description : This method will Discontinue and Re-instate multiple Entities
	 * Date of creation : 7/30/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ReinstateAndDiscontinueMultiple(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			//Verify Discontinue of Multiple-Rep's
			if(verifyIfElementPresent(Rep.DISCONTINUE_MULTIPLE, "Discontinue Multiple")) {
				//Discontinue multiple Rep's with below method
				DiscontinueMultiple(ReportSheet, count);
				if(verifyIfElementPresent(Rep.REVISIONS_PAGE, "Revisions Page")) {
					click(Rep.REPRESENTATION_TAB, "Representation Tab");
				}
				assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			}
			/*else {
				click(Generic.FIRST_DATA, "First Rep Data");
				if(verifyIfElementPresent(Rep.DISCONTINUE_BUTTON, "Discontinue Button")) {
					//If re-instate button is present click on it and re-instate the rep
					Discontinue(ReportSheet, count);
					if(verifyIfElementPresent(Rep.REVISIONS_PAGE, "Revisions Page")) {
						click(Rep.REPRESENTATION_TAB, "Representation Tab");
					}
					assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
				}
				else {
					Reinstate(ReportSheet, count);
				}
				click(Rep.RETURN_TO_REP_UNITS, "Return to representation unit Button");
			}
*/			//Re-instate multiple Rep's with below method
			ReinstateMultiple(ReportSheet, count);
			if(verifyIfElementPresent(Rep.REVISIONS_PAGE, "Revisions Page")) {
				click(Rep.REPRESENTATION_TAB, "Representation Tab");
			}
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : PrintRep() 
	 * Author : Pradyumna 
	 * Description : This method will verify Print Page of Rep
	 * Date of creation : 7/30/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String PrintRep(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			click(Generic.FIRST_DATA, "First Rep Data");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
			//Click on Print
			click(Generic.PRINT, "Print");
			//On clicking Print Button, New window is opened. Below steps manages Jumps from Parent to child & back to Parent Window
			String parentWindow= driver.getWindowHandle();
			handlePopUpWindwow();
			assertElementPresent(Rep.PRINT_REP_PROFILE, "Rep Print Page");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
		
	/********************************************************************************************************
	 * Method Name : IndependentDirector() 
	 * Author : Pradyumna 
	 * Description : This method will create entity with Independent Director
	 * Date of creation : 9/16/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String IndependentDirector(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strBranchPlant = Excelobject.getCellData(ReportSheet, "BranchPlant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "DomesticJuris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "EntityType", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "ParticipantName", count);
			String strEmployeeName = Excelobject.getCellData(ReportSheet, "EmployeeName", count);
			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Entity.ENTITY_NAME, "Apple", "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, strBranchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, "Entity having Independent Director Rep", "True Name Text box");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Rep.INDEPENDENT_DIRECTOR_DROPDOWN, "Select Service Type");
			// click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			waitForElementPresent(Rep.MAINTAIN_OFFICER_DIRECTOR_PAGE, "Officer Director Page");
			assertElementPresent(Rep.MAINTAIN_OFFICER_DIRECTOR_PAGE, "Officer Director Page");
			//Add New Employee
			click(Generic.SELECT, "Select");
			assertElementPresent(Rep.FIND_OFFICER_DIRECTOR_PAGE, "Find Officer Director Page");
			type(Rep.EMPLOYEE_NAME_FIELD, strEmployeeName, "Employee Name Entered");
			click(Generic.FIND_BUTTON, "Find Button");
			click(Rep.SELECT_EMPLOYEE, "Select Employee");
			assertElementPresent(Rep.MAINTAIN_OFFICER_DIRECTOR_PAGE, "Officer Director Page");
			click(Rep.POSITION, "Position");
			click(Rep.APPOINTED_DATE, "Appointed Date");
			click(Rep.TODAYSDATE, "Today's Date");
			click(Generic.ADD_UPDATE_BTN, "Add Update Button");
			//Check Edit and Delete Button
			click(Rep.EDIT_BUTTON, "Edit Button");
			click(Rep.DELETE_BUTTON, "Delete Button");
			cancelpopup();
			click(Rep.RETURN_TO_PROFILE_VIEW, "Return to Profile view button");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
			//Click on Maintain Button on rep profile Page
			click(Rep.MAINTAIN_BUTTON, "Maintain button");
			assertElementPresent(Rep.MAINTAIN_OFFICER_DIRECTOR_PAGE, "Officer Director Page");
			click(Rep.RETURN_TO_PROFILE_VIEW, "Return to Profile View button");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
			click(Rep.MAINTAIN_INDEPENDENT_AFFILIATE_COMMISION_BUTTON, "Maintain Independent Affiliate Commision button");
			assertElementPresent(Rep.MAINTAIN_INDEPENDENT_AFFILIATE_COMMISION_PAGE, "Maintain Independent Affiliate Commision Page");
			click(Generic.SEARCH_LINK, "Search Link");
			assertElementPresent(Rep.AFFILIATE_LIST_PAGE, "Affiliate List Page");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(Rep.MAINTAIN_INDEPENDENT_AFFILIATE_COMMISION_PAGE, "Maintain Independent Affiliate Commision Page");
			click(Rep.AFFILIATE_COMMISION_DROPDOWN, "Affiliate Commision Dropdown");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
			assertElementPresent(Rep.AFFILIATE_COMMISION_PERCENTAGE, "Affiliate Commision Percentage");			

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : StateID() 
	 * Author : Pradyumna 
	 * Description : This method will verify State ID related part of Rep
	 * Date of creation : 10/3/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String StateID(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// create Entity
			createEntity(ReportSheet,count);
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			click(Rep.CREATE_REPRESENTATION, "Create Representation Button");
			assertElementPresent(Rep.NEW_REPRESENTATION_PAGE, "New Representation Page");
			click(Rep.NORTH_CAROLINA_JURISDICTION, "Select Jurisdiction");
			click(Rep.PUBLIC_BENEFIT_LLC, "Public Benefit LLC");
			click(Generic.NEXT_BUTTON, "Next Button");
			assertElementPresent(Rep.NEW_REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			type(Rep.STATE_ID, "0336239", "State ID entered");
			click(Rep.FILING_DATE_BUTTON, "Filing Date Button");
			click(Rep.TODAYSDATE, "Select Today's Date");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			click(Rep.FOREIGN_REP_TEXT, "Foreign Rep Service Type");
			click(Rep.REP_EDIT_BUTTON, "Rep Edit Button");
			click(Rep.GET_STATE_IDCT_DATABASE_BUTTON, "Get State ID CT Database Button");;
			assertElementPresent(Rep.STATE_ID_VERIFICATION_PAGE, "State id verification Page");
			if(verifyIfElementPresent(Rep.STATE_BIZ_ERROR_ERRMSG, "Error Msg For State Biz Service unavailable")){
				assertTextMatching(Rep.STATE_BIZ_ERROR_ERRMSG,
						"State biz data service not available. Please try again later.",
						"Error Msg For State Biz Service unavailable");
				click(Rep.CANCEL_REP_STATEID, "Cancel Rep StateId Button");
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
			}
			else {
			click(Rep.CUSTOM_SEARCH_RADIO, "Custom Search Radio Button");
			type(Rep.CUSTOM_SEARCH_TEXT, "Walmart", "Custom Search text entered");
			click(Rep.REP_SEARCH_BUTTON, "Rep Search Button");
			click(Rep.REP_SEARCH_FIRST_RESULT, "Rep Search First Result");
			click(Rep.ACCEPT_SELECTED_ITEM_BUTTON, "Accept Selected Item Button");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "Rep Unit Profile Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}	
	
	
	/********************************************************************************************************
	 * Method Name : AssumedNameRep() 
	 * Author : Pradyumna 
	 * Description : This method will verify Assumed Name Rep can be re-instated
	 * Date of creation : 10/3/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String AssumedNameRep(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// create Entity
			createEntity(ReportSheet,count);
			//Click on Names Link Tab
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Entity.CREATE_ASSUMED_NAME_BTN, "Create Assumed Name Button");
			assertElementPresent(Entity.CREATE_ASSUMEDNAME_PAGE, "Create Assumed Name Page");
			type(Entity.ASSUMED_NAME_TEXT, "Assumed Name Rep for Testing", "Assumed Name Text");
			click(Entity.RADIO_QUALIFIED, "Radio button Qualified");
			click(Rep.ALASKA_NAME_JURISDICTION,"Alaska Dropdown");
			click(Entity.FILING_DATE, "Filing Date");
			click(Entity.TODAYSDATE, "Today's Date");
			/*int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(Rep.ASSUMED_NAME_FILING_DATES, lastYearDate, "Assumed Name Filing Date text box");*/
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			click(Generic.FIRST_DATA, "First Data");
			Discontinue(ReportSheet, count);
			waitForElementPresent(Rep.END_DATE_ASSUMEDNAME_TEXT, "End Date Assumed Name Text");
			assertElementPresent(Rep.END_DATE_ASSUMEDNAME_TEXT, "End Date Assumed Name Text");
			click(Rep.RETURN_TO_REP_PROFILE, "Return to Rep Profile");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "REPRESENTATION UNIT PROFILE");
			assertElementPresent(Rep.DISCONTINUE_STATUS, "Discontinue Status");
			Reinstate(ReportSheet, count);
			waitForElementPresent(Rep.END_DATE_ASSUMEDNAME_TEXT, "End Date Assumed Name Text");
			assertElementPresent(Rep.END_DATE_ASSUMEDNAME_TEXT, "End Date Assumed Name Text");
			click(Rep.RETURN_TO_PROFILE_VIEW_BTN, "Return to Rep Profile view button");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "REPRESENTATION UNIT PROFILE");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : CorporateStaffing() 
	 * Author : Pradyumna 
	 * Description : This method will verify Domestic Rep with Corporate Staffing  
	 * Date of creation : 10/4/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CorporateStaffing(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			String strServiceType = Excelobject.getCellData(ReportSheet, "ServiceType", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			//Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			//Check if Contract Agency is present and Re-instate is present instead of Discontinue
			try {
				click(Rep.SERVICE_TYPE, "Service Type Drop Down");
				click(Generic.SECOND_DROP_CONTAINS, "Contains Drop Down");
				type(Generic.DROP_DOWN_TEXT, strServiceType, "Entity ID");
				click(Generic.GO_BUTTON, "Go Button");		
					if(verifyIfElementPresent(Rep.DOMESTIC_AGENCY_REP, "Domestic Rep Agency")) {
					click(Rep.DOMESTIC_AGENCY_REP, "Domestic Rep Agency");
					assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE, "REPRESENTATION UNIT PROFILE");
					click(Rep.COMPARE_TO_STATE_RECORD_BTN, "Compare to State Record button");
					assertElementPresent(Rep.STATE_RECORD_DETAILS_PAGE, "State Record Details Page");
					click(Generic.GO_BACK, "Go Back Button");
					click(Rep.RETURN_TO_REP_UNITS, "Return to Rep Units Page");
					assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Rep Unit Page");					
				} else {
					System.out.println("Domestic Rep is not available");
				}
			} catch (Exception e) {
				// handle else
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : ResignationOfDiscontinuedRep() 
	 * Author : Arpana 
	 * Description : This method will discontinue and then resign the representation for the given entity
	 * Date of creation : 06/12/2020
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ResignationOfDiscontinuedRep(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			ArrayList<String> entityID = new ArrayList<String>();
			String todaysDate=formatter.format(date).toString();
			try {
				 entityID = SQL_Queries.getActiveEntity();
			} catch (Throwable e) {
				e.printStackTrace();
			}
			
			//Search for the entity id
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search link");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityID.get(0), "Entity ID Text box");
			click(Entity.SEARCH_BTN,"Entity search Button");
			assertElementPresent(Entity.ENTITY_PROFILE_PAGE,"Entity Profile Page");
			
			//Filter the representation by Active status and click on 1st rep link
			click(Rep.REPRESENTATION_TAB,"Representation Left Nav Bar Link");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Representation Units Page");
			click(Rep.STATUS,"Rep Status Filter");
			click(Rep.ACTIVE_STATUS,"Active Status");
			click(Generic.GO_BUTTON, "Go Button");
			click(Generic.FIRST_DATA, "First Data");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE,"Representation Profile Page");
			
			//Discontinue the representation
			click(Rep.DISCONTINUE_BUTTON, "Click on Discontinue Button");
			click(Rep.DISCONTINUE_DATE, "Click on Discontinue Date");
			click(Rep.TODAYSDATE, "Select Today's Date");
			/*int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(Rep.DISCONTINUE_DATES, lastYearDate, "Discontinuance Filing Date text box");*/
			click(Rep.DISCONTINUE_DUE_TO_PROPERTY_SOLD,"Discontinued due to property sold button");
			
			//Go to the discontinued rep profile
			click(Rep.NAMES_LINK,"Names Left Nav Bar Link");	
			click(Rep.REPRESENTATION_TAB,"Representation Left Nav Bar Link");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PAGE, "Representation Units Page");
			click(Rep.DISCONTINUANCE_DATE,"Rep Discontinuance Date Filter");
			click(Generic.IS_ON,"Is On Filter");
			type(Generic.DROP_DOWN_TEXT, todaysDate, "Discontinuance Date Text Box");
			click(Generic.GO_BUTTON, "Go Button");
			click(Generic.FIRST_DATA, "First Data");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE,"Representation Profile Page");
			
			//Resignate the discontinued representation
			waitForElementToBeClickable(Rep.RESIGNATE_BTN,"Start Resignation Button");
			click(Rep.RESIGNATE_BTN,"Start Resignation Button");
			assertElementPresent(Rep.RESIGN_REPRESENTATION_UNIT_PAGE, "Resign Representation Unit Page");
			type(Rep.PENDING_DATE_TEXT, todaysDate, "Pending Date Text Box");
			click(Generic.SAVE,"Save Button");
				
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE,"Representation Profile Page");
			assertElementPresent(Rep.ACCEPT_RESIGNATION_BUTTON,"Accept Resignation Button");
			assertElementPresent(Rep.REJECT_RESIGNATION_BUTTON,"Reject Resignation Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
}