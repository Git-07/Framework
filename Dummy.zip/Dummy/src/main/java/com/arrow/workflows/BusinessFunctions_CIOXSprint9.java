package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CIOXSprint9 extends BusinessFunctions_CommonCESAndWorksheet {

	public String verifyStateOfCourtForCES(String stateOfCourtDrp, String courtName, String operation) throws Throwable {

		String esopId = "";
		try {
			blnEventReport = true;
			//Verify added court details in CES Page:-
			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID").split("\\: ")[1];

			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
			
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

			// enter entity name in Entity Search page and click on Search
			// button
			type(SOP.ENTITY_NAME_TEXTFIELD, "Apple", "Entity Name textfield on Entity Search page");
			//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
			click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "Apple", "Entity Name textfield on Entity Search page");
			}
			
			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			
			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
		    if(entitySearchCount == 0) {
			//Click on unidentified entity
			waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
			String disabledUnEntity = "";
			try {				
			disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
			System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
			}catch(NullPointerException e) {}
			if(disabledUnEntity == null) {
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
			Thread.sleep(1500);
			System.out.println("REached here in line 6420");
			try {
			if(disabledUnEntity.equals("true")) {					
			  //SEARCH_AGAIN_BUTTON
			  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
			  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
			  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
			  //CANCEL_BUTTON
			  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
			  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
			  click(SOP.CANCEL_BUTTON, "Cancel Button");
			}}catch(NullPointerException e) {}				
             System.out.println("REached here in line 6431");
             Thread.sleep(2000);
             //below will be a go ahead when the value for unidentified Entity above is selected
             String unEntityRadioSelected = "";
             try {                	 
            	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
             }catch(NoSuchElementException e) {}
             catch(NullPointerException e) {}
             Thread.sleep(1000);
             try {
             if(unEntityRadioSelected == null) {
            	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
             }}catch(NullPointerException e) {}
			//ENTITY_TEXT_BOX
			waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
			//DOMESTIC_JURISDICTION_SELECTION
			waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
			//REP_JURISDICTION_SELECTION
			waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 
			
		    }
		    else if(entitySearchCount != 0) {
			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			//FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

			// Enter log id in log text field
			type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(4000);
			// Click on Unrelated worksheet
			click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
		    }
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			//Use an existing court
			if((operation.equalsIgnoreCase("add"))||(operation.equalsIgnoreCase("update"))){
				if (verifyIfElementPresent(SOP.COURT_LABEL, "Court Label")) {
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
					click(SOP.SPECIFIC_STATE_OF_COURT_DRPDWN,"State of Court");
					selectByVisibleText(SOP.DROP_DOWN_COURT_NAME, courtName, "Court Data Added");
					//click(SOP.SPECIFIC_DROP_DOWN_COURT_NAME, "Court Data Added");
				}
			}
			else {
				if (verifyIfElementPresent(SOP.COURT_LABEL, "Court Label")) {
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
					isElementNotPresent(SOP.SPECIFIC_DROP_DOWN_COURT_NAME, "Court Data Deleted");
					selectByIndex(SOP.DROP_DOWN_COURT_NAME, 1, "Court Data Added");
				}
			}
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			/*click(SOP.CES_INTERNAL_COMMENTS_DRPDWN, "CES Internal Comments Drpdwn");
			cesInternalComments = getText(SOP.CES_INTERNAL_COMMENTS_DRPDWN, "CES Internal Comments");*/
			type(SOP.CES_INTERNAL_COMMENTS, "Process Validated", "Internal Comments Text");

			click(SOP.SUBMITBTN, "Submit Button");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

		} catch (Exception e) {
			throw e;
		}
		return esopId;
	}

	public void verifyStateOfCourtForCreateWorksheet(String stateOfCourtDrp, String courtName, String operation) throws Throwable {


		try {
			blnEventReport = true;
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");

			if((operation.equalsIgnoreCase("add"))||(operation.equalsIgnoreCase("update"))){
				if (verifyIfElementPresent(SOP.COURT_LABEL, "Court Label")) {

					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
					selectByVisibleText(SOP.DROP_DOWN_COURT_NAME, courtName, "Court Data Added");

				}
			}
			else {
				waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
				isElementNotPresent(SOP.SPECIFIC_DROP_DOWN_COURT_NAME, "Court Data Deleted");
			}
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
					"Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyStateOfCourtForEditWorksheet(String stateOfCourtDrp, String courtName, String operation) throws Throwable {


		try {
			blnEventReport = true;
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			if((operation.equalsIgnoreCase("add"))||(operation.equalsIgnoreCase("update"))){
				if (verifyIfElementPresent(SOP.COURT_LABEL, "Court Label")) {

					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
					selectByVisibleText(SOP.DROP_DOWN_COURT_NAME, courtName, "Court Data Added");

				}
			}
			else {
				waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
				isElementNotPresent(SOP.SPECIFIC_DROP_DOWN_COURT_NAME, "Court Data Deleted");
			}

			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyStateOfCourtForReviewWorksheet(String reportSheet, int count, String stateOfCourtDrp, String courtName, String operation) throws Throwable {


		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "Worksheet Search Left Nav Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			waitForElementPresent(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			Thread.sleep(2000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");

			if((operation.equalsIgnoreCase("add"))||(operation.equalsIgnoreCase("update"))){
				if (verifyIfElementPresent(SOP.COURT_LABEL, "Court Label")) {

					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
					selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
					selectByVisibleText(SOP.DROP_DOWN_COURT_NAME, courtName, "Court Data Added");

				}
			}
			else {
				waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, stateOfCourtDrp, "State of Court");
				isElementNotPresent(SOP.SPECIFIC_DROP_DOWN_COURT_NAME, "Court Data Deleted");
			}
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyStateOfCourtForUSJurisdiction(String reportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalCourtList = new ArrayList<String>();
			List<String> updatedCourtList = Arrays.asList("-- Select One --", "Alabama", "Alaska",
					"Arizona", "Arkansas", "California", "Cherokee Nation", "Colorado", "Connecticut", "Delaware",
					"District of Columbia", "Florida", "Georgia", "Guam", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa","Kansas",
					"Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri",
					"Montana", "Navajo Nation", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota",
					"Northern Mariana", "Ohio", "Oklahoma", "Oregon", "Paskenta Band of Nomlaki Indians", "Pennsylvania", "Puerto Rico", "Rhode Island", "South Carolina",
					"South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virgin Islands (US)", "Virginia",
					"Washington", "West Virginia", "Wisconsin",
					"Wyoming");
			if (verifyIfElementPresent(SOP.STATE_OF_COURT_LABEL, "State of Court Label")) {

				// Select Nature of Action from dropdown
				click(SOP.STATE_OF_COURT_DROPDOWN, "State of Court Dropdown");

				List<WebElement> arr = getAllDropDownData(SOP.STATE_OF_COURT_DROPDOWN);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalCourtList.add(we.getText());
				}
				compareTwoArrayList(updatedCourtList, originalCourtList);
			}

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;

	}

	public String verifyAddedCourtForCESCreateEditReview(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String operation = "add";
			String stateOfCourtDrp = Excelobject.getCellData(reportSheet, "State Of Court", count);
			String courtName = Excelobject.getCellData(reportSheet, "Name", count);
			String line1 = Excelobject.getCellData(reportSheet, "Line1", count);
			String line2 = Excelobject.getCellData(reportSheet, "Line2", count);				
			String line3 = Excelobject.getCellData(reportSheet, "Line3", count);
			String line4 = Excelobject.getCellData(reportSheet, "Line4", count);
			String city = Excelobject.getCellData(reportSheet, "City", count);
			String county = Excelobject.getCellData(reportSheet, "County", count);
			String zip = Excelobject.getCellData(reportSheet, "Zip", count);
			String country = Excelobject.getCellData(reportSheet, "Country", count);				
			String phone = Excelobject.getCellData(reportSheet, "Phone", count);
			String fax = Excelobject.getCellData(reportSheet, "Fax", count);
			String email = Excelobject.getCellData(reportSheet, "Email", count);
			//String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Text Maintenance Link
			click(SOP.TEXT_MAINTENANCE_LINK, "Text Maintenance Page");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");
			// Click on Court Link
			click(SOP.COURT_LINK, "Court Link");
			assertTextMatching(SOP.PAGE_TITLE, "Manage Text Type - Court", "Page Title");
			isElementNotPresent(SOP.OFFICE_COURT_FIELD, "Office drpdown not available");
			assertElementPresent(SOP.STATE_OF_COURT_LABEL, "State of Court Label");
			assertElementPresent(SOP.STATE_OF_COURT_DROPDOWN, "State of Court Dropdown");
			assertElementPresent(SOP.NY_STATE_OF_COURT_DRPDWN, "State of Court Dropdown");
			verifyStateOfCourtForUSJurisdiction(reportSheet, count);
			String stateCourt = getText(SOP.NY_STATE_OF_COURT_DRPDWN, "State of Court Dropdown");
			System.out.println("***********"+stateCourt+"************");
			String stateOfCourt = getAttribute(SOP.STATE_OF_COURT_DROPDOWN, "value");
			System.out.println("State Of Court Value:"+""+stateOfCourt);
			isDisabled(SOP.STATE_TEXTBOX, "State TextBox");
			String stateText = getAttribute(SOP.STATE_TEXTBOX, "value");
			System.out.println("Disabled State Text:"+""+stateText);

			// Add Court Value
			selectBySendkeys(SOP.STATE_OF_COURT_DROPDOWN, stateOfCourtDrp, "State of Court");
			type(SOP.NAME_TEXTBOX, courtName, "Value Textbox");
			type(SOP.LINE1_TEXTBOX, line1, "Line1 Textbox");
			type(SOP.LINE2_TEXTBOX, line2, "Line2 Textbox");
			type(SOP.LINE3_TEXTBOX, line3, "Line3 Textbox");
			type(SOP.LINE4_TEXTBOX, line4, "Line4 Textbox");
			type(SOP.CITY_TEXTBOX, city, "City Textbox");
			type(SOP.COUNTY_TEXTBOX, county, "County Textbox");
			type(SOP.ZIP_TEXTBOX, zip, "Zip Textbox");
			type(SOP.COUNTRY_TEXTBOX, country, "Country Textbox");
			type(SOP.PHONE_TEXTBOX, phone, "County Textbox");
			type(SOP.FAX_TEXTBOX, fax, "Zip Textbox");
			type(SOP.EMAIL_TEXTBOX, email, "Country Textbox");
			click(SOP.ADDUPDATE_BTN, "Add Update Btn");

			click(SOP.RETURN_TO_TEXT_TYPES, "Return To Text Types");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");

			//Verify added court details in CES Page
			String esopId = verifyStateOfCourtForCES(stateOfCourtDrp,courtName, operation);

			createWorksheetViaSOPList(reportSheet, count, esopId);

			//Verify added court details in Create Worksheet Page
			verifyStateOfCourtForCreateWorksheet(stateOfCourtDrp, courtName, operation);

			//Verify added court details in Edit Worksheet Page
			verifyStateOfCourtForEditWorksheet(stateOfCourtDrp, courtName, operation);

			//Verify added court details in Review Worksheet Page
			verifyStateOfCourtForReviewWorksheet(reportSheet, count, stateOfCourtDrp, courtName, operation);


		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyUpdatedCourtForCESCreateEditReview(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String operation = "update";
			String stateOfCourtDrp = Excelobject.getCellData(reportSheet, "State Of Court", count);
			String addedCourtName = Excelobject.getCellData(reportSheet, "AddedName", count);
			String editedCourtName = Excelobject.getCellData(reportSheet, "EditedName", count);

			//String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Text Maintenance Link
			click(SOP.TEXT_MAINTENANCE_LINK, "Text Maintenance Page");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");
			// Click on Court Link
			click(SOP.COURT_LINK, "Court Link");
			assertTextMatching(SOP.PAGE_TITLE, "Manage Text Type - Court", "Page Title");
			click(SOP.NAME_FIRST_FILTER, "Select Name fromm first filter");
			click(SOP.EQUALS_SECOND_FILTER, "Select Equals from second filter");
			type(SOP.FILTERTEXTFIELD, addedCourtName, "Filter Textbox");
			click(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FIRST_EDIT_BTN, "First Edit Btn");
			//Edit Court Name
			type(SOP.NAME_TEXTBOX, editedCourtName, "Value Textbox");
			click(SOP.ADDUPDATE_BTN, "Add Update Btn");

			click(SOP.RETURN_TO_TEXT_TYPES, "Return To Text Types");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");

			//Verify added court details in CES Page
			String esopId = verifyStateOfCourtForCES(stateOfCourtDrp,editedCourtName, operation);

			createWorksheetViaSOPList(reportSheet, count, esopId);

			//Verify added court details in Create Worksheet Page
			verifyStateOfCourtForCreateWorksheet(stateOfCourtDrp, editedCourtName, operation);

			//Verify added court details in Edit Worksheet Page
			verifyStateOfCourtForEditWorksheet(stateOfCourtDrp, editedCourtName, operation);

			//Verify added court details in Review Worksheet Page
			verifyStateOfCourtForReviewWorksheet(reportSheet, count, stateOfCourtDrp, editedCourtName, operation);


		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyDeletedCourtForCESCreateEditReview(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String operation = "delete";
			String stateOfCourtDrp = Excelobject.getCellData(reportSheet, "State Of Court", count);
			String editedCourtName = Excelobject.getCellData(reportSheet, "EditedName", count);

			//String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Text Maintenance Link
			click(SOP.TEXT_MAINTENANCE_LINK, "Text Maintenance Page");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");
			// Click on Court Link
			click(SOP.COURT_LINK, "Court Link");
			assertTextMatching(SOP.PAGE_TITLE, "Manage Text Type - Court", "Page Title");
			click(SOP.NAME_FIRST_FILTER, "Select Name fromm first filter");
			click(SOP.EQUALS_SECOND_FILTER, "Select Equals from second filter");
			type(SOP.FILTERTEXTFIELD, editedCourtName, "Filter Textbox");
			click(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FIRST_DELETE_BTN, "First Delete Btn");
			handlepopup();

			click(SOP.RETURN_TO_TEXT_TYPES, "Return To Text Types");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");

			//Verify added court details in CES Page
			String esopId = verifyStateOfCourtForCES(stateOfCourtDrp,editedCourtName, operation);

			createWorksheetViaSOPList(reportSheet, count, esopId);

			//Verify added court details in Create Worksheet Page
			verifyStateOfCourtForCreateWorksheet(stateOfCourtDrp, editedCourtName, operation);

			//Verify added court details in Edit Worksheet Page
			verifyStateOfCourtForEditWorksheet(stateOfCourtDrp, editedCourtName, operation);

			//Verify added court details in Review Worksheet Page
			verifyStateOfCourtForReviewWorksheet(reportSheet, count, stateOfCourtDrp, editedCourtName, operation);


		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyStateOfCourtForLoggedUserTeam(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Text Maintenance Link
			click(SOP.TEXT_MAINTENANCE_LINK, "Text Maintenance Page");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");
			// Click on Court Link
			click(SOP.COURT_LINK, "Court Link");
			assertTextMatching(SOP.PAGE_TITLE, "Manage Text Type - Court", "Page Title");
			assertElementPresent(SOP.STATE_OF_COURT_LABEL, "State of Court Label");
			assertElementPresent(SOP.STATE_OF_COURT_DROPDOWN, "State of Court Dropdown");
			assertElementPresent(SOP.ALABAMA_STATE_OF_COURT_DRPDWN, "Alabama State of Court Dropdown");

			String stateCourt = getText(SOP.ALABAMA_STATE_OF_COURT_DRPDWN, "Alabama State of Court Dropdown");
			System.out.println("***********"+stateCourt+"************");
			String stateOfCourt = getAttribute(SOP.STATE_OF_COURT_DROPDOWN, "value");
			System.out.println("State Of Court Value:"+""+stateOfCourt);
			isDisabled(SOP.STATE_TEXTBOX, "State TextBox");
			String stateText = getAttribute(SOP.STATE_TEXTBOX, "value");
			System.out.println("Disabled State Text:"+""+stateText);



		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyDefaultStateOfCourtForLoggedUserTeam(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Text Maintenance Link
			click(SOP.TEXT_MAINTENANCE_LINK, "Text Maintenance Page");
			assertTextMatching(SOP.PAGE_TITLE, "Text Types", "Page Title");
			// Click on Court Link
			click(SOP.COURT_LINK, "Court Link");
			assertTextMatching(SOP.PAGE_TITLE, "Manage Text Type - Court", "Page Title");
			assertElementPresent(SOP.STATE_OF_COURT_LABEL, "State of Court Label");
			assertElementPresent(SOP.STATE_OF_COURT_DROPDOWN, "State of Court Dropdown");
			assertElementPresent(SOP.GLOBAL_STATE_OF_COURT_DRPDWN, "Global State of Court Dropdown");

			String stateCourt = getText(SOP.GLOBAL_STATE_OF_COURT_DRPDWN, "Global State of Court Dropdown");
			System.out.println("***********"+stateCourt+"************");
			String stateOfCourt = getAttribute(SOP.STATE_OF_COURT_DROPDOWN, "value");
			System.out.println("State Of Court Value:"+""+stateOfCourt);
			isDisabled(SOP.STATE_TEXTBOX, "State TextBox");
			String stateText = getAttribute(SOP.STATE_TEXTBOX, "value");
			System.out.println("Disabled State Text:"+""+stateText);


		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}
}
