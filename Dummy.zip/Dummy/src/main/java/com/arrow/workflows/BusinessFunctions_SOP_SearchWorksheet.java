package com.arrow.workflows;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_SOP_SearchWorksheet extends BusinessFunctions_CommonCESAndWorksheet/*BusinessFunctions*/ {

	/********************************************************************************************************
	 * Method Name : searchWorksheet() Author : Pradyumna Description : This method
	 * will Search Worksheet Date of creation : 8/26/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String searchWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);
			String receivedDate = Excelobject.getCellData(ReportSheet, "Date", count);
			String caseID = Excelobject.getCellData(ReportSheet, "CaseID", count);
			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			type(Generic.NAME_FIELD, entityName, "Entity Name Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");

			// Store the value of Log and caseID and search it again
			// String logID=getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			// String caseID=getText(SearchWorksheet.CASE_ID, "Case ID");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Case ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			type(SearchWorksheet.CASE_ID_TEXT, caseID, "Case ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Worksheet ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : searchWorksheet() Author : Pradyumna Description : This method
	 * will Search Worksheet Date of creation : 8/26/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String q2LegacySearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);
			String receivedDate = Excelobject.getCellData(ReportSheet, "Date", count);
			String caseID = Excelobject.getCellData(ReportSheet, "CaseID", count);
			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.Q2_LEGACY_RADIO_BUTTON, "Q2 Legacy Radio Button");
			type(Generic.NAME_FIELD, entityName, "Entity Name Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");
			// Store the value of Log and caseID and search it again
			// String logID=getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			// String caseID=getText(SearchWorksheet.CASE_ID, "Case ID");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Case ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.Q2_LEGACY_RADIO_BUTTON, "Q2 Legacy Radio Button");
			type(SearchWorksheet.CASE_ID_TEXT, caseID, "Case ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Worksheet ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.Q2_LEGACY_RADIO_BUTTON, "Q2 Legacy Radio Button");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : classicWorksheetSearch() Author : Pradyumna Description : This
	 * method will Search active Classic Worksheet Date of creation : 8/27/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String activeClassicWorksheetSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String receivedDate = Excelobject.getCellData(ReportSheet, "Date", count);
			String caseID = Excelobject.getCellData(ReportSheet, "CaseID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");
			// Store the value of LogID and search it again
			String logID = getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Worksheet ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Case ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			type(SearchWorksheet.CASE_ID_TEXT, caseID, "Case ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_WORKSHEET_SEARCH_RESULT, "Classic Worksheet Search Page");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : q2LegacyClassicSearch() Author : Pradyumna Description : This
	 * method will Search active Classic Worksheet Date of creation : 8/27/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String q2LegacyClassicSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String receivedDate = Excelobject.getCellData(ReportSheet, "Date", count);
			String caseID = Excelobject.getCellData(ReportSheet, "CaseID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			click(SearchWorksheet.Q2_LEGACY_RADIO_BUTTON, "Q2 Legacy Radio Button");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");
			// Store the value of LogID and search it again
			String logID = getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Worksheet ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			click(SearchWorksheet.Q2_LEGACY_RADIO_BUTTON, "Q2 Legacy Radio Button");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Case ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			click(SearchWorksheet.Q2_LEGACY_RADIO_BUTTON, "Q2 Legacy Radio Button");
			type(SearchWorksheet.CASE_ID_TEXT, caseID, "Case ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_WORKSHEET_SEARCH_RESULT, "Classic Worksheet Search Page");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : archiveClassicWorksheetSearch() Author : Pradyumna Description
	 * : This method will Search archive Classic Worksheet Date of creation :
	 * 8/27/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String archiveClassicWorksheetSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String receivedDate = Excelobject.getCellData(ReportSheet, "Date", count);
			String caseID = Excelobject.getCellData(ReportSheet, "CaseID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ARCHIVE_DATA, "Archive Data Radio Button");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_WORKSHEET_SEARCH_RESULT, "Worksheet Search Page");
			// Store the value of LogID and search it again
			String logID = getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Worksheet ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ARCHIVE_DATA, "Archive Data Radio Button");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Search by Case ID
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Search Worksheet Tab");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ARCHIVE_DATA, "Archive Data Radio Button");
			// TODO Case ID needs updated once page loads fine correctly
			type(SearchWorksheet.CASE_ID_TEXT, caseID, "Case ID Entered");
			type(SearchWorksheet.RECEIVED_DATE, receivedDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_WORKSHEET_SEARCH_RESULT, "Classic Worksheet Search Page");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : relatedWorksheetSearh() Author : Pradyumna Description : This
	 * method will Search archive Classic Worksheet Date of creation : 8/27/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String relatedWorksheetSearh(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);

			// Click On Edit Worksheet
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			// Create Worksheet Step 2
			waitForElementPresent(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			waitForElementPresent(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			waitForElementPresent(SOP.RADIO_BUTTON_ATTORNEYNONE, "None Specified Attorney Radio Button");
			click(SOP.RADIO_BUTTON_ATTORNEYNONE, "None Specified Attorney Radio Button");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.RELATED_WORKSHEET_SEARCH, "Related Worksheet Search Page");
			String parentWindow = driver.getWindowHandle();
			click(WorksheetCreate.FIRST_SOP_DATA, "Worksheet ID");
			handlePopUpWindwow();
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertElementPresent(SearchWorksheet.RELATED_WORKSHEET_SEARCH, "Related Worksheet Search Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : SearhByBatchNo() Author : Pradyumna Description : This method
	 * will Search archive Classic Worksheet Date of creation : 8/27/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String searhByBatchNo(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String batchNumber = Excelobject.getCellData(ReportSheet, "BatchNumber", count);
			String receivedDate = Excelobject.getCellData(ReportSheet, "ReceivedDate", count);
			String endDate = Excelobject.getCellData(ReportSheet, "EndDate", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			// click on Search by Batch No link on Home page
			click(SearchWorksheet.SEARCH_BY_BATCH_NO, "WS Search by Batch NO.");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_CRITERIA_PAGE, "Worksheet Search Criteria Page");
			type(SearchWorksheet.BATCH_NUMBER, batchNumber, "Received Date Entered");
			type(SearchWorksheet.BATCH_RECEIVED_DATE, receivedDate, "Received Date Entered");
			type(SearchWorksheet.BATCH_END_DATE, endDate, "Received Date Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_RESULT_PAGE, "Worksheet Search Result Page");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String entityHavingAlerts(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);


			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertTextMatching(SOP.PAGE_TITLE, "Worksheet Search Criteria", "Title Of the page");

			// Click on Entity Select Button
			click(SearchWorksheet.ENTITY_SELECT_BTN, "Entity Select Button");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Criteria", "Title Of the page");

			// Enter the name of the entity having alerts
			type(Generic.NAME_FIELD, entityName, "Entity Name Entered");
			click(Entity.INCLUDE_ALL_REP_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Results", "Title Of the page");

			selectBySendkeys(Generic.SELECT_DROPDOWN,"Entity #", "Select Entity Id from drp dwn");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN,"=", "Select Equals");
			type(Generic.DROP_DOWN_TEXT, entityId, "Entity Id Entered");
			click(Generic.GO_BUTTON, "Go Button");


			// Click on Alerts link on the grid
			click(SearchWorksheet.ALERTS_LINK, "Alerts Link on the grid");

			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");
			isElementPresent(SearchWorksheet.ALERTS_TAB, "ALERTS tab");
			//Thread.sleep(1000);
			assertElementPresent(SearchWorksheet.ALERTS_TEXT, "Alerts Text");

			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
