package com.arrow.workflows;

import java.util.ArrayList;

import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.DI;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_AffiliationLevelDI extends BusinessFunctions {

	public void formerDIs(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on DI History left nav link
			click(Entity.DI_HISTORY, "DI History Left Nav Link");

			// Verify title of the page is DI History
			assertTextMatching(DI.PAGE_TITLE, "DI History", "Title of the page");

			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");

			// Select Bulletin from second filter and click on Go Btn
			click(DI.BULLETIN_FILTER, "Select Bulletin from second filter");
			click(DI.GO_BTN, "Go Button");

			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");

			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");

			// Verify DI Type is Bulletin and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "Bulletin", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");

			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");

			// Select Communication from second filter and click on Go Btn
			click(DI.COMMUNICATION_FILTER, "Select Communication from second filter");
			click(DI.GO_BTN, "Go Button");

			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");

			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");

			// Verify DI Type is Communication and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "Communication", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");

			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");

			// Select Renewal from second filter and click on Go Btn
			click(DI.RENEWAL_FILTER, "Select Renewal from second filter");
			click(DI.GO_BTN, "Go Button");

			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");

			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");

			// Verify DI Type is Renewal and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "Renewal", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");

			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");

			// Select SOP from second filter and click on Go Btn
			click(DI.SOP_FILTER, "Select SOP from second filter");
			click(DI.GO_BTN, "Go Button");

			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");

			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");

			// Verify DI Type is SOP and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "SOP", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");

			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");

			// Select XSOP from second filter and click on Go Btn
			click(DI.XSOP_FILTER, "Select XSOP from second filter");
			click(DI.GO_BTN, "Go Button");

			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");

			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");

			// Verify DI Type is XSOP and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "XSOP", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");

		} catch (Exception e) {
			throw e;
		}

	}
	public void searchForTheAffiliation(String affiliationId) throws Throwable {
		
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
	
	}
	public String getTheAffiliationHavingMulitpleInvoices() {
		ArrayList<String> affiliationId  =  new ArrayList<String>();
		try {
			
			affiliationId = SQL_Queries.getTheAffiliationHavingMulitpleInvoices();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return affiliationId.get(0);
	}
	
public void createRenewalSubgroupAndRenewalDIPaperLessDeliveryMethod() throws Throwable{
    	
    	//SUBGROUPSBTN
    	waitForElementPresent(Affiliation.SUBGROUPSBTN, "Sub Groups Link in Affiliation Page");
 		assertElementPresent(Affiliation.SUBGROUPSBTN, "Sub Groups Link in Affiliation Page");
 		click(Affiliation.SUBGROUPSBTN, "Click on Sub Groups Link in Affiliation Page");
 		//CREATESUBGROUPBTN
 		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Subgroup button in Affiliation Sub groups Page");
 		assertElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Subgroup button in Affiliation Sub groups Page");
 		click(Affiliation.CREATESUBGROUPBTN, "Click on Create Subgroup button in Affiliation Sub groups Page");
    	//CREATERENEWALSUBGROUPBTN
 		waitForElementPresent(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Subgroup Checkbox in Create groups Page");
 		assertElementPresent(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Subgroup checkbox in Create Sub groups Page");
 		click(Affiliation.CREATERENEWALSUBGROUPBTN, "Click on Create Renewal Subgroup checkbox in Create Sub groups Page"); 		
 		String renewalSubgroupName  = "Test " + getCurrentDate().split("\\/")[1];
 		//CREATERENEWALSUBGROUPNAME
 		assertElementPresent(Affiliation.CREATERENEWALSUBGROUPNAME, "Create Renewal Subgroup name textbox in Create Sub groups Page");
 		type(Affiliation.CREATERENEWALSUBGROUPNAME,renewalSubgroupName,"Create Renewal Subgroup name textbox in Create Sub groups Page");
 		//RECIPIENTSELECTBTN
 		assertElementPresent(Affiliation.RECIPIENTSELECTBTN, "Select Button under Express DI Recipient details in Create Sub groups Page");
 		click(Affiliation.RECIPIENTSELECTBTN, "Click on Select Button under Express DI Recipient details in Create Sub groups Page");
 		//PARTICIPANTNAMEFIELD
 		waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
 		assertElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
    	type(Entity.PARTICIPANTNAMEFIELD,"CHERYL TURLEY", "Participant text field in Find DI Recipient Page");
    	//FINDBTN
    	assertElementPresent(Entity.FINDBTN, "Find Button in Find DI Recipient Page");
    	click(Entity.FINDBTN, "Click on Find Button in Find DI Recipient Page");
    	//SELECTRECIPIENTBTN
    	assertElementPresent(Entity.SELECTRECIPIENTBTN, "Select button for recipient under Delivery Instruction in Edit DI Page");
 		click(Entity.SELECTRECIPIENTBTN, "Click on Select button for recipient under Delivery Instruction in Edit DI Page");
 		//SAVE_BTN
 		waitForElementPresent(Affiliation.SAVEBTN, "Save Button in Delivery Instruction Page");
 		assertElementPresent(Affiliation.SAVEBTN, "Save Button in Delivery Instruction Page");
 		click(Affiliation.SAVEBTN, "Save Button in Delivery Instruction Page"); 		
 		searchTheRenewalSubGroup(renewalSubgroupName);
 		//FIRSTRESULTONSEARCHPAGE
 		waitForElementPresent(Affiliation.FIRSTRESULTONSEARCHPAGE, "first result in Affiliation Subgroup Page");
 		assertElementPresent(Affiliation.FIRSTRESULTONSEARCHPAGE, "first result in Affiliation Subgroup Page");
 		click(Affiliation.FIRSTRESULTONSEARCHPAGE, "first result in Affiliation Subgroup Page");
 		//DELIVERY_INSTRUCTION_EDIT_BUTTON
 		waitForElementPresent(Affiliation.DELIVERY_INSTRUCTION_EDIT_BUTTON, "Edit button in Affiliation Subgroup Profile viewPage");
 		assertElementPresent(Affiliation.DELIVERY_INSTRUCTION_EDIT_BUTTON, "Edit button in Affiliation Subgroup Profile view Page");
 		click(Affiliation.DELIVERY_INSTRUCTION_EDIT_BUTTON, "Edit button in Affiliation Subgroup Profile view Page");
 		//AUTO_RENEW_RADIO_BUTTON
 		
 		//waitForElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		//assertElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		//click(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		
 		click(Affiliation.ACTIVE_RADIO_BTN, "Auto Renew Active button for Renewal Invoice in Delivery Instruction Page");
 		//COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION
 		assertElementPresent(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, "Comments text box for Renewal Invoice in Delivery Instruction Page");
 		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION,"Test", "Comments text box for Renewal Invoice in Delivery Instruction Page");
 		//SAVE_BTN
 		assertElementPresent(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
 		click(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
 		//DELIVERY_INSTRUCTION_DELIVERY_METHOD
 		assertElementPresent(Affiliation.DELIVERY_INSTRUCTION_DELIVERY_METHOD, "Delivery Method text in Delivery Instruction Page");
 		assertTextMatching(Affiliation.DELIVERY_INSTRUCTION_DELIVERY_METHOD,"Paperless", "Delivery Method text in Delivery Instruction Page");
 		
    }

    public void searchTheRenewalSubGroup(String subgroupName) throws Throwable{
	   
	   //FIRSTFILTER
	   waitForElementPresent(Affiliation.FIRSTFILTER, "first filter in Affiliation Subgroup Page");
	   selectByVisibleText(Affiliation.FIRSTFILTER,"Sub Group Name", "first filter in Affiliation Subgroup Page");
	   //SECONDFILTER
	   waitForElementPresent(Affiliation.SECONDFILTER, "Second filter in Affiliation Subgroup Page");
	   selectByVisibleText(Affiliation.SECONDFILTER,"contains", "Second filter in Affiliation Subgroup Page");
	   //FILTERTEXTBOX
	   assertElementPresent(Affiliation.FILTERTEXTBOX, "filter text box in Affiliation Subgroup Page");
	   type(Affiliation.FILTERTEXTBOX,subgroupName, "filter text box in Affiliation Subgroup Page");
	   //GOBTN
	   assertElementPresent(Affiliation.GOBTN, "Go Button in Affiliation Subgroup Page");
	   click(Affiliation.GOBTN, "Click on Go Button in Affiliation Subgroup Page");
}
}
