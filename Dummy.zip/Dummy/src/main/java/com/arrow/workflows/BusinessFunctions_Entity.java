package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;

import com.arrow.accelerators.ActionEngine;
import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Alerts;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.EM;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Login;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.SOP;
import com.arrow.sqlqueries.SQL_Queries;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;


public class BusinessFunctions_Entity extends BusinessFunctions_Affiliation {

	public String createEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);
			String jurisdiction = Excelobject.getCellData(ReportSheet, "Jurisdiction", count);
			String serviceType = Excelobject.getCellData(ReportSheet, "Service Type", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			waitForElementPresent(Entity.BRANCH_PLANT_CREATE_ENTITY, "Select Branch Plant");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			waitForElementPresent(Entity.DOMESTIC_JURIS_DRPDWN, "Select domestic juris");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next
			// btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Entity.SERVICE_TYPE_DRPDWN, "Select Service Type");
			// click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// Enter state ID
			type(Entity.STATE_ID, "1234567", "State ID");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			Thread.sleep(3000);
			waitForElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			// Verify whether Entity Has been created
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			String EntityID = getText(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			String entityID = EntityID.substring(10);
			return entityID;

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchEntity(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter an Entity Name and click on Include Inactive Entities Btn and Include
		// Staffing Entities Btn
		type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
		click(Entity.INCLUDE_INACTIVE_ENTITIES_BTN, "Include Inactive Entities Btn");
		click(Entity.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Btn");
		// click on search button
		click(Entity.SEARCH_BTN, "Search Button");
		// select Entity#,Name,Type from drp dwn
		click(Entity.ENTITY_ID_DRPDWN, "Select Entity# from drp dwn");
		click(Entity.NAME_DRPDWN, "Select Name from drp dwn");
		click(Entity.TYPE_DRPDWN, "Select Type from drp dwn");
		click(Entity.AFFILIATON_DRPDWN, "Select Affiliation from drp dwn");
		click(Entity.DOMESTICJURIS_DRPDWN, "Select Domestic Juris from drp dwn");
		click(Entity.TEAM_DRPDWN, "Select Team from drp dwn");
		click(Entity.STATUS_DRPDWN, "Select status from drp dwn");
		click(Entity.STAFFING_ENTITY_DRPDWN, "Select staffing entity from drp dwn");
		click(Entity.GENERIC_CD_ENTITY_DRPDWN, "Select generic cd entity from drp dwn");
		click(Entity.BRANCH_PLANT_DRPDWN, "Select Branch Plant from drp dwn");
		// For Pagination Check
		// Click on First,Previous,1-10,11-20.,...,Next,Last Links
		click(Entity.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");
		click(Entity.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
		click(Entity.PAGE_11__20_LINK, "Click on 11-20 link");
		click(Entity.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
		click(Entity.LAST_PAGE_LINK, "Click on Last Link to display Last Page");
		// Check whether All sorting links are present
		isElementPresent(Entity.NAME_SORT, "Sort By Name Link");
		isElementPresent(Entity.TYPE_SORT, "Sort By Type Link");
		isElementPresent(Entity.AFFILIATION_SORT, "Sort By Affiliation Link");
		isElementPresent(Entity.DOMESTIC_JURIS_SORT, "Sort By Domestic Juris Link");
		isElementPresent(Entity.TEAM_SORT, "Sort By Team Link");
		isElementPresent(Entity.BRANCH_PLANT_SORT, "Sort By Branch Plant Link");
		isElementPresent(Entity.STATUS_SORT, "Sort By Status Link");
		isElementPresent(Entity.STAFFING_ENTITY_SORT, "Sort By Staffing Entity Link");
		isElementPresent(Entity.GENERIC_CD_ENTITY_SORT, "Sort By Generic CD Entity Link");

	}

	public void editEntity(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
		String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// click on Edit Button on Entity Profile Page
		click(Entity.ENTITY_EDIT, "Edit Button");
		// Edit entity type,fiscal year end and add comments
		selectBySendkeys(Entity.ENTITY_TYPE_DRPDWN, entityType, "Entity Type");
		click(Entity.JANUARY_FISCAL_YEAR_END_DRPDWN, "Fiscal Year End");
		Thread.sleep(3000);
		type(Entity.COMMENTS, comment, "Comments Text Box");
		// Click on Save Btn
		click(Entity.SAVE_BTN, "Save Button");
		// Verify whether changes made to the field are saved
		assertTextMatching(Entity.ENTITY_TYPE, entityType, "Entity Type Field");
		assertTextMatching(Entity.FISCAL_YEAR_END, "January", "Fiscal Year End");
	}

	public void editFederalIDOnEntityProfile(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
		String incorrectFederalID = Excelobject.getCellData(ReportSheet, "Incorrect Federal Id", count);
		String correctFederalID = Excelobject.getCellData(ReportSheet, "Correct Federal Id", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// click on Edit Button on Entity Profile Page
		click(Entity.ENTITY_EDIT, "Edit Button");
		// Enter an incorrect Federal ID
		type(Entity.FEDERAL_ID_EDIT, incorrectFederalID, "Enter an incorrect federal id");
		// Click on Save Btn and Verify whether an error msg is observed
		click(Entity.SAVE_BTN, "Save Button");
		assertTextMatching(Entity.FEDERAL_ID_ERR_MSG, "Enter Federal ID in the format nn-nnnnnnn.",
				"Federal ID Err Msg");
		// Enter a correct Federal ID and click on save btn
		type(Entity.FEDERAL_ID_EDIT, correctFederalID, "Enter a correct federal id");
		click(Entity.SAVE_BTN, "Save Button");
		// Verify whether changes made to the federal id field is saved
		assertTextMatching(Entity.FEDERAL_ID, correctFederalID, "Federal ID Field Value");
	}

	public void editStaffingEntity(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter an Entity Name and click on Staffing Entities Btn
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		// click(Entity.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Btn");
		// click on search button and click on first result on entity search result page
		click(Entity.SEARCH_BTN, "Search Button");
		// click(Entity.FIRST_ENTITY_IN_GRID, "First Entity In Grid");
		// click on Edit Button on Entity Profile Page
		click(Entity.ENTITY_EDIT, "Edit Button");
		// Edit fiscal year end and add comments
		click(Entity.JANUARY_FISCAL_YEAR_END_DRPDWN, "Fiscal Year End");
		type(Entity.COMMENTS, comment, "Comments Text Box");
		// Click on Save Btn
		click(Entity.SAVE_BTN, "Save Button");
		// Verify whether changes made to the field are saved
		assertTextMatching(Entity.FISCAL_YEAR_END, "January", "Fiscal Year End");

	}

	public void exportButtonOnCommentsScreen(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// Click on Comments Btn from left nav link
		click(Entity.COMMENT, "Comment Section");
		// click on Export Button
		click(Entity.COMMENT_SCREEEN_EXPORT_BUTTON, "Export Btn on Comments Screen");
		// Click on Sort By Author
		click(Entity.AUTHOR_SORTBY_LINK, "Author Sort By Link");
		isElementPresent(Entity.AUTHOR_SORTBY_LINK_BOLD, "Bold Author Link");

	}

	public void joinAffiliation(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
		String affName = Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);

		// click on Entity Search link
		click(HomePage.ENTITY_TAB, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// Click on Join Affiliation Button
		click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		click(Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");

		String selectedAffilationName = getText(Entity.NEW_AFFILIATION_NAME, "New Affiliation Name");

		// Complete the process for joining affiliation
		click(Entity.BULLETINRETAINCURRENTDI, "Bulletin Retain Current DI Button");
		click(Entity.COMMRETAINCURRENTDI, "Communication Retain Current DI Button");
		click(Entity.RENEWALINVOICERETAINCURRENTDI, "Renewal Invoice Retain Current DI Button");
		selectByIndex(Entity.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
		click(Entity.SOPRETAINCURRENTDI, "SOP 	Retain Current DI Button");
		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
		click(Entity.JOINBTN, "Join Button");
		// Verify The selected entity is joined
		assertTextMatching(Entity.AFFILIATION_NAME, selectedAffilationName, "Affiliation Name on Entity Profile");
		// Also Verify Quit Affiliation Button is present
		isElementPresent(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");

	}

	public void quitAffiliation(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
		String affName = Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);
		String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// Click on Join Affiliation Button
		click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		click(Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");

		String selectedAffilationName = getText(Entity.NEW_AFFILIATION_NAME, "New Affiliation Name");

		// Complete the process for joining affiliation
		click(Entity.BULLETINRETAINCURRENTDI, "Bulletin Retain Current DI Button");
		click(Entity.COMMRETAINCURRENTDI, "Communication Retain Current DI Button");
		click(Entity.RENEWALINVOICERETAINCURRENTDI, "Renewal Invoice Retain Current DI Button");
		selectByIndex(Entity.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
		click(Entity.SOPRETAINCURRENTDI, "SOP 	Retain Current DI Button");
		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
		click(Entity.JOINBTN, "Join Button");

		// Verify The selected entity is joined
		assertTextMatching(Entity.AFFILIATION_NAME, selectedAffilationName, "Affiliation Name on Entity Profile");
		// Also Verify Quit Affiliation Button is enabled
		// isEnabled(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
		click(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
		// select participant
		click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
		waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
		type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
		click(Entity.FINDBTN, "Find button");
		waitForElementPresent(Entity.TABLEID, "Recipient Table");
		clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
		// Click on Apply Same Recipient to other deliverables Button and click on next
		// btn
		click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN_QUIT_AFFPAGE,
				"Apply Same Recipient to other deliverables Button");
		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
		// Click on Quit The Affiliation Button and handle the popup
		click(Entity.QUIT_THE_AFFILIATION_BTN, "Quit The Affiliation Btn");
		handlepopup();

		// Verify Whether Quit Affiliation Btn is disabled
		getAttribute(Entity.DISABLED_QUIT_AFFILIATION_BTN, "disabled");

	}

	public void deadEnd(String ReportSheet, int count) throws Throwable {

		String filingDate = "";
		createEntity(ReportSheet, count);
		// Check whether dead end button is there on entity profile page
		isElementPresent(Entity.DEAD_END_BTN, "Dead End Button");

		// Click on Representation Tab
		click(Rep.REPRESENTATION_TAB, "Representation Tab");
		click(Generic.FIRST_DATA, "First Rep Data");
		filingDate = getText(Entity.REP_FILING_DATE, "Entity Rep Filing Date");
		click(Rep.DISCONTINUE_BUTTON, "Click on Discontinue Button");
		click(Rep.DISCONTINUE_REASON, "Discontinue Reason");
		//click(Rep.DISCONTINUE_DATE, "Click on Discontinue Date");
		//click(Rep.TODAYSDATE, "Select Today's Date");
		//int nextYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) + 1; 
		//String nextYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
		//		+ String.valueOf(nextYear); 			
		type(Rep.DISCONTINUE_DATES,filingDate,"Discontinue Date text box");
		click(Rep.REP_DISCONTINUE_BUTTON, "Discontinue Rep");

		click(Entity.ENTITY_PROFILE, "Entity Profile on left nav link");
		// click(Entity.ENTITY_PROFILE,"Entity Profile on left nav link");
		// Click on Dead End Button On Entity Profile Page
		click(Entity.DEAD_END_BTN, "DEAD_END_BTN");

		type(Entity.COMMENTS_ON_CONFIRM_REVERSE_DEAD_END, "test", "Comment Text Box");
		click(Entity.DEAD_END_BTN, "DEAD_END_BTN");
		waitForElementPresent(Entity.STATUS_ON_ENTITY_PROFILE, "Status On Entity Profile");
		assertTextMatching(Entity.STATUS_ON_ENTITY_PROFILE, "Dead End Instructions", "Status On Entity Profile");
	}

	public void cancelQuitingAffiliation(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
		String affName = Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);
		String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// Click on Join Affiliation Button
		click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		click(Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");

		String selectedAffilationName = getText(Entity.NEW_AFFILIATION_NAME, "New Affiliation Name");

		// Complete the process for joining affiliation
		click(Entity.BULLETINRETAINCURRENTDI, "Bulletin Retain Current DI Button");
		click(Entity.COMMRETAINCURRENTDI, "Communication Retain Current DI Button");
		click(Entity.RENEWALINVOICERETAINCURRENTDI, "Renewal Invoice Retain Current DI Button");
		selectByIndex(Entity.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
		click(Entity.SOPRETAINCURRENTDI, "SOP 	Retain Current DI Button");
		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
		click(Entity.JOINBTN, "Join Button");
		// Verify The selected entity is joined
		assertTextMatching(Entity.AFFILIATION_NAME, selectedAffilationName, "Affiliation Name on Entity Profile");
		// click on quit affiliation button
		click(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
		// select participant
		click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
		waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
		type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
		click(Entity.FINDBTN, "Find button");
		waitForElementPresent(Entity.TABLEID, "Recipient Table");
		clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
		// Click on Apply Same Recipient to other deliverables Button and click on next
		// btn
		click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN_QUIT_AFFPAGE,
				"Apply Same Recipient to other deliverables Button");
		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
		// click on cancel Button
		click(Entity.CANCEL_BTN, "Cancel Button");
		// Verify Whether Quit Affiliation Btn is still present
		isElementPresent(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");

	}

	public void noEditButtonForDeadEndEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on Staffing Entities Btn
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.INCLUDE_INACTIVE_ENTITIES_BTN, "Include Inactive Entities Btn");
			click(Entity.SEARCH_BTN, "Search Button");
			// Select Status from first filter and Select Dead End Instructions from RHS
			// Filter
			click(Entity.STATUS_DRPDWN, "Select Status from Drop Down");
			selectBySendkeys(Entity.RHS_FILTER, "Dead End Instructions", "RHS Filter");
			click(Entity.GO_BTN, "Go Button");
			// click on first result on the grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Result On grid");
			// Check whether edit button is not present
			isElementNotPresent(Entity.ENTITY_EDIT, "Edit Button");
		} catch (Exception e) {
			catchBlock(e);
		}

	}

	/********************************************************************************************************
	 * Method Name : DeadEndErrMsg() Author : Sweety Jaiswal Description : This
	 * method will Check an error msg is displayed on making an entity dead end for
	 * active rep unit Date of creation : 7/23/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/

	public void deadEndErrMsg(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click On dead end Button
			click(Entity.DEAD_END_BTN, "Dead End Button");
			if (isElementPresent(Entity.ACTIVE_REP_EXISTS_ERRMSG, "Error Msg For Active Rep Units")) {
				assertTextMatching(Entity.ACTIVE_REP_EXISTS_ERRMSG,
						"Active Rep exists. Discontinue all Rep in order to Dead-End.",
						"Error Msg For Active Rep Units");

			}

			if (isElementPresent(Entity.ENTITY_IS_AFFILIATED_ERRMSG, "Error Msg For Affiliated Entity")) {
				assertTextMatching(Entity.ENTITY_IS_AFFILIATED_ERRMSG,
						"Entity is Affiliated. Quit all Affiliations in order to Dead-End.",
						"Error Msg For Affiliated Entity");

			}
			// click on cancel button
			click(Entity.CANCEL_BTN, "Cancel Button");
			// Verify entity profile page is displayed back
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");

		} catch (Exception e) {
			catchBlock(e);
		}

	}

	/********************************************************************************************************
	 * Method Name : DeadEndErrMsg() Author : Sweety Jaiswal Description : This
	 * method will Check an error msg is displayed on making an entity dead end for
	 * active rep unit Date of creation : 7/23/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/

	public void NRAIEntityRecipientForAllDIs(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String bulletinRecipient = Excelobject.getCellData(ReportSheet, "Bulletin Participant Name", count);
			String jurisdiction = Excelobject.getCellData(ReportSheet, "Jurisdiction", count);
			String serviceType = Excelobject.getCellData(ReportSheet, "Service Type", count);
			String federalId = Excelobject.getCellData(ReportSheet, "Federal ID", count);
			String entityRef1 = Excelobject.getCellData(ReportSheet, "Entity Ref1", count);
			String entityRef2 = Excelobject.getCellData(ReportSheet, "Entity Ref2", count);
			String communicationRecipient = Excelobject.getCellData(ReportSheet, "Communication Participant Name",
					count);
			String renewalInvoiceRecipient = Excelobject.getCellData(ReportSheet, "Renewal Invoice Participant Name",
					count);
			String sopRecipient = Excelobject.getCellData(ReportSheet, "SOP Participant Name", count);
			String xsopRecipient = Excelobject.getCellData(ReportSheet, "XSOP Participant Name", count);
			String comments = Excelobject.getCellData(ReportSheet, "Comments", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// Enter Federal Id,Entity Ref1 and Entity Ref2
			type(Entity.FEDERAL_ID_TEXTBOX, federalId, "Federal ID Text Box");
			type(Entity.ENTITY_REF1_TEXTBOX, entityRef1, "Entity Ref1 Text Box");
			type(Entity.ENTITY_REF2_TEXTBOX, entityRef2, "Entity Ref2 Text Box");
			// click on minus icon of client contact field
			click(Entity.CLIENT_CONTACT_MINUS_ICON, "Minus icon of Client Contact Field");
			// Switch to frame for participant search
			waitForFrameToLoadAndSwitchToIt(Entity.CLIENT_CONTACT_PARTICIPANT_SEARCH_FRAME,
					"Frame for Participant Search");
			// Enter Participant and click on search button
			type(Entity.PARTICIPANT_NAME_SEARCH_TEXTBOX, bulletinRecipient, "Participant Name");
			click(Entity.SEARCH_BTN, "Search Button");
			// Select a particpant
			waitForElementPresent(Entity.PARTCIPANT_SELECT_BTN_ON_FRAME, "Participant Select btn on frame");
			click(Entity.PARTCIPANT_SELECT_BTN_ON_FRAME, "Participant Select btn on frame");
			// Verify partcipant selected is populated in Client Contact Field
			waitForElementPresent(Entity.CLIENT_CONTACT_MINUS_ICON, "Minus icon of Client Contact Field");
			isElementPresent(Entity.CLIENT_CONTACT_VALUE, "Value for Client Contact");
			// Click on Centralized Team Enabled Checkbox
			click(Entity.CENTRALIZED_TEAM_ENABLED_CHECKBOX, "Centralized Team Enabled CheckBox");
			// click on minus icon of Attorney of Record field
			click(Entity.ATTORNEY_OF_RECORD_MINUS_ICON, "Minus icon of Attorney of Record field");
			// Switch to frame for participant search
			waitForFrameToLoadAndSwitchToIt(Entity.ATTORNEY_OF_RECORD_PARTICIPANT_SEARCH_FRAME,
					"Frame for Participant Search");
			// Enter Participant and click on search button
			type(Entity.PARTICIPANT_NAME_SEARCH_TEXTBOX, bulletinRecipient, "Participant Name");
			click(Entity.SEARCH_BTN, "Search Button");
			// Select a particpant
			waitForElementPresent(Entity.PARTCIPANT_SELECT_BTN_ON_FRAME, "Participant Select btn on frame");
			click(Entity.PARTCIPANT_SELECT_BTN_ON_FRAME, "Participant Select btn on frame");
			waitForElementPresent(Entity.ATTORNEY_OF_RECORD_MINUS_ICON, "Minus icon of Attorney of Record field");
			// select participant for Bulletin DI
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, bulletinRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Verify whether the selected particpant is populated to Bulletin field
			assertTextMatching(Entity.BULLETIN_PARTICIPANT_TITLE, bulletinRecipient,
					"Participant Title field of Bulletin DI");
			// select participant for Communication DI
			click(Entity.COMM_PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, communicationRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Verify whether the selected participant is populated to Bulletin field
			assertTextMatching(Entity.COMM_PARTICIPANT_TITLE, communicationRecipient,
					"Participant Title field of Communication DI");
			// select participant for Renewal Invoice DI
			click(Entity.RENEWAL_INVOICE_PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, renewalInvoiceRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Verify whether the selected participant is populated to Bulletin field
			assertTextMatching(Entity.RENEWAL_INVOICE_COMM_PARTICIPANT_TITLE, renewalInvoiceRecipient,
					"Participant Title field of Renewal Invoice DI");
			// select participant for SOP DI
			click(Entity.SOP_PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, sopRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Verify whether the selected participant is populated to Bulletin field
			assertTextMatching(Entity.SOP_COMM_PARTICIPANT_TITLE, sopRecipient,
					"Participant Title field of Renewal Invoice DI");
			// select participant for XSOP DI
			click(Entity.XSOP_PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, xsopRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Verify whether the selected participant is populated to Bulletin field
			assertTextMatching(Entity.XSOP_COMM_PARTICIPANT_TITLE, xsopRecipient,
					"Participant Title field of Renewal Invoice DI");
			// Enter Comments
			type(Entity.COMMENT_ON_ENTITY_CREATE, comments, "Comments");
			// Click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Entity.SERVICE_TYPE_DRPDWN, "Select Service Type");
			// click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// Enter state ID
			type(Entity.STATE_ID, "1234567", "State ID");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// Enter Comments
			type(Entity.COMMENT_ON_ENTITY_CREATE, comments, "Comments");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			waitForElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			// Verify whether Entity Has been created
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			// String EntityID=getText(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On
			// Entity Profile page");

		} catch (Exception e) {
			catchBlock(e);
		}

	}

	public void cancelCreatingEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next
			// btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			// Click on cancel button
			click(Entity.CANCEL_BTN, "Cancel Button");
			// Verify whether it is returned back to Entity Search Page
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

		} catch (Exception e) {
			catchBlock(e);
		}

	}

	public void joinAffiliationUsingSubGroupDI(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity New Id", count);
			String affName = Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
			String comment = Excelobject.getCellData(ReportSheet, "Comment", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Join Affiliation Button
			click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
			// Enter an Affiliation Name and click on Find Button
			type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
			click(Entity.FINDBTN, "Find Btn");
			// Click on First result from the grid
			// click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
			click(Entity.FIRST_VIEW_AND_JOIN_BUTTON_ON_GRID, "First View and Join Button on Grid");

			String selectedAffilationName = getText(Entity.NEW_AFFILIATION_NAME, "New Affiliation Name");

			// Complete the process for joining affiliation
			selectByIndex(Entity.BULLETINSUBGROUPDROPDWN, 1, "Bulletin Sub Group Drop Down Select");
			selectByIndex(Entity.COMMSUBGROUPDROPDWN, 1, "Communication Sub Group Drop Down Select");
			selectByIndex(Entity.RENEWALINVOICESUBGROUPDROPDWN, 1, "Renewal Invoice Sub Group Drop Down Select");
			selectByIndex(Entity.SOPSUBGROUPDROPDWN, 1, "SOP Sub Group Drop Down Select");
			selectByIndex(Entity.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
			type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
			click(Entity.JOINBTN, "Join Button");
			// Verify The selected entity is joined
			assertTextMatching(Entity.AFFILIATION_NAME, selectedAffilationName, "Affiliation Name on Entity Profile");
			// Also Verify Quit Affiliation Button is present
			isElementPresent(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
			click(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next
			// btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN_QUIT_AFFPAGE,
					"Apply Same Recipient to other deliverables Button");
			type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, comment, "Comments");
			// Click on Quit The Affiliation Button and handle the popup
			click(Entity.QUIT_THE_AFFILIATION_BTN, "Quit The Affiliation Btn");
			handlepopup();
			// Verify Whether Quit Affiliation Btn is disabled
			getAttribute(Entity.DISABLED_QUIT_AFFILIATION_BTN, "disabled");

		} catch (Exception e) {
			catchBlock(e);
		}

	}

	public void noSelectButtonForInactiveParticipant(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);
			String strInactiveRecipient = Excelobject.getCellData(ReportSheet, "Inactive Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			// Click on Include Inactive Participants Button and enter a partcipant name
			click(Entity.INCLUDE_INACTIVE_PARTICIPANTS_BTN, "Include Inactive Participants Button");
			type(Entity.PARTICIPANTNAMEFIELD, strInactiveRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			// Verify whether select Button is not present for inactive participant
			isElementNotPresent(Entity.SELECTRECIPIENTBTN, "Select button in the grid");
			// Click on Search Again Button
			click(Entity.SEARCH_AGAIN_BTN, "Search Again Button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			// Enter a partcipant name
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Verify Whether selected participant is populated to bulletin field
			assertTextMatching(Entity.BULLETIN_PARTICIPANT_TITLE, strRecipient,
					"Participant Title field of Bulletin DI");

		} catch (Exception e) {
			catchBlock(e);
		}

	}

	public void salesAssignment(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String salesAssignment = Excelobject.getCellData(ReportSheet, "Sales Assignment", count);

			createEntity(ReportSheet, count);

			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");
			assertTextMatching(Entity.PAGE_TITLE, "Edit Entity Information", "Page Title");
			// Click on sales assignment checkbox
			click(Entity.SALES_ASSIGNMENT_CHECKBOX, "Sales Assignment Checkbox");
			// Select a sales assignment from drop down and click on save button
			selectBySendkeys(Entity.SALES_ASSIGNMENT_DROPDOWN, salesAssignment, "Sales Assignment Dropdown");
			click(Entity.SAVE_BTN, "Save Button");
			Thread.sleep(3000);
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");
			// Verify sales assignment field on entity profile page
			assertTextMatching(Entity.SALES_ASSIGNMENT_VALUE, salesAssignment, "Value of sales asssignment field");
		} catch (Exception e) {
			catchBlock(e);
		}

	}

	public void noEditButtonForDeadEndedEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.INCLUDE_INACTIVE_ENTITIES_BTN, "Include Inactive Entities Button");
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Results", "Page Title");
			// Select Status from first filter and Select Dead End Instructions from RHS
			// Filter
			click(Entity.STATUS_DRPDWN, "Select Status from Drop Down");
			click(Entity.DEAD_END_ISTRUCTIONS_RHS_FILTER, "RHS Filter");
			click(Entity.GO_BTN, "Go Button");
			// Select first entity from grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity In Grid");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");
			// Verify edit button is not present
			isElementNotPresent(Entity.ENTITY_EDIT, "Edit Button");

		} catch (Exception e) {
			catchBlock(e);
		}

	}

	public String reverseDeadEnd(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Recipient Name", count);
			//String strTitle = Excelobject.getCellData(ReportSheet, "Title", count);
			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.INCLUDE_INACTIVE_ENTITIES_BTN, "Include Inactive Entities Button");
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Results", "Page Title");
			// Select Status from first filter and Select Dead End Instructions from RHS
			// Filter
			click(Entity.STATUS_DRPDWN, "Select Status from Drop Down");
			click(Entity.DEAD_END_ISTRUCTIONS_RHS_FILTER, "RHS Filter");
			click(Entity.GO_BTN, "Go Button");
			// Select first entity from grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity In Grid");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");
			// Click on Reverse dead end btn
			click(Entity.REVERSE_DEAD_END_BTN, "Reverse Dead End Button");
			// Click On Select Btn on Confirm Reverse Dead-end Page
			click(Entity.PARTCIPANT_SELECT_BTN, "Participant Select Btn");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			waitForElementPresent(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_IMAGE_BTN,
					"Apply Same Recipient to other deliverables Button");
			// Click on Apply Same Recipient to other deliverables Button and enter comments
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_IMAGE_BTN,
					"Apply Same Recipient to other deliverables Button");
			type(Entity.COMMENTS_ON_CONFIRM_REVERSE_DEAD_END, "TEST", "Comments Text Box");
			// click on Reverse Dead End Btn
			click(Entity.REVERSE_DEAD_END_BTN, "Reverse Dead End Button");
			//if(isElementPresent(Entity.REINSTATEMENT_REASON, "Reinstatement Reason")) {
			//if(strTitle.equals("Reinstate Multiple Representation Units")){
			//if(assertTextMatching(Entity.REINSTATE_TITLE, "Reinstate Multiple Representation Units", "Page Title")) {


			if (verifyIfElementPresent(Entity.REINSTATEMENT_REASON, "Reinstatement Reason")){

				click(Entity.ENTITY_PROFILE, "entity profile");
				assertElementPresent(Entity.ENTITY_PROFILE_PAGE, "Entity Profile Page");
				assertElementPresent(Entity.INACTIVE_PROFILE_STATUS, "Inactive Profile Status");
				assertElementPresent(Entity.DEAD_END_BTN, "Dead End Button");

			} else {
				assertElementPresent(Entity.ENTITY_PROFILE_PAGE, "Entity Profile Page");
				assertElementPresent(Entity.INACTIVE_PROFILE_STATUS, "Inactive Profile Status");
				assertElementPresent(Entity.DEAD_END_BTN, "Dead End Button");
			}
		}
			/*
			 * //if(isElementPresent(Entity.REINSTATEMENT_REASON, "Reinstatement Reason"))
			 * if(driver.findElement(By.id("lstReinstatementReason")).isDisplayed()) {
			 * //Enter Effective Date, Reinstatement Reason on Reinstate Multiple
			 * Representation Units Page selectByIndex(Entity.REINSTATEMENT_REASON,1,
			 * "Reinstatement Reason"); click(Entity.
			 * EFFECTIVE_DATE_CALENDER_ICON_ON_REINSTATE_MULTIPLE_REP_UNITS_PAGE,
			 * "Effective Date Calendar Icon"); click(Entity.TODAYSDATE, "Todays Date");
			 * //Select Service Type
			 * click(Entity.SERVICE_TYPE_CHECKBOX,"Service Type Check Box"); //Click On
			 * Reinstate Button click(Entity.REINSTATE_BTN,"Reinstate Button");
			 * click(Entity.ENTITY_PROFILE_TAB,"Entity Profile on left nav link");
			 * assertElementPresent(Entity.ENTITY_PROFILE,"Entity Profile on left nav link"
			 * ); click(Entity.ENTITY_PROFILE,"Entity Profile on left nav link");
			 * click(Entity.DEAD_END_BTN,"DEAD_END_BTN"); } else {
			 * assertElementPresent(Entity.ENTITY_PROFILE,"Entity Profile on left nav link"
			 * ); //click(Entity.ENTITY_PROFILE,"Entity Profile on left nav link"); //Click
			 * on Dead End Button On Entity Profile Page
			 * click(Entity.DEAD_END_BTN,"DEAD_END_BTN"); }
			 */

		 catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : inactiveParticipant() Author : Pradyumna Description : This
	 * method will verify that select button is not displayed for Inactive
	 * Participants Date of creation : 11/8/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String inactiveParticipant(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strInactiveRecipient = Excelobject.getCellData(ReportSheet, "InactiveParticipant", count);
			String strActiveRecipient = Excelobject.getCellData(ReportSheet, "ActiveParticipant", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			click(Entity.PARTCIPANT_SELECT_BTN, "Participant Select Btn");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strInactiveRecipient, "Inactive Participant Name");
			click(Entity.INCLUDE_INACTIVE_PARTICIPANTS_BTN, "Include Inactive Participants");
			click(Entity.FINDBTN, "Find button");
			assertElementPresent(Entity.SELECT_PARTICIPANT_PAGE, "Select Participant Page");
			isElementNotPresent(Entity.SELECT_PARTICIPANT_BUTTON, "Select Button is not displayed");
			click(Entity.SEARCH_AGAIN_BTN, "Search Again button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strActiveRecipient, "Active Participant Name");
			click(Entity.INCLUDE_INACTIVE_PARTICIPANTS_BTN, "Include Inactive Participants");
			click(Entity.FINDBTN, "Find button");
			assertElementPresent(Entity.SELECT_PARTICIPANT_PAGE, "Select Participant Page");
			isElementPresent(Entity.SELECT_PARTICIPANT_BUTTON, "Select Button is displayed");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : customerSelectError() Author : Pradyumna Description : This
	 * method will verify that only Customer selection throws error in DI Selection
	 * Date of creation : 11/8/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String customerSelectError(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strCustomer = Excelobject.getCellData(ReportSheet, "CustomerName", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			assertElementPresent(Entity.ENTITY_SEARCH_RESULTS_PAGE, "Entity Search Results Page");
			// Search for Affiliated Entities via Dropdown
			click(Entity.AFFILIATON_DRPDWN, "Select Affiliation from Drop Down");
			click(Generic.SECOND_DROP_CONTAINS, "Select Contains from Drop Down");
			type(Generic.DROP_DOWN_TEXT, "apple", "Affiliation Name");
			click(Entity.GO_BTN, "Go Button");
			assertElementPresent(Entity.ENTITY_SEARCH_RESULTS_PAGE, "Entity Search Results Page");
			// Select First Entity in Grid and Click on Quit Affiliation
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity In Grid");
			assertElementPresent(Entity.ENTITY_PROFILE_PAGE, "Entity Profile Page");
			click(Entity.QUIT_AFFILIATION_BTN, "First Entity In Grid");
			assertElementPresent(Entity.CONFIRM_QUIT_AFFLN_PAGE, "Confirm Qutting the Affiliation Page");
			// In select Participant, Try adding only Customer Name and not Participant Name
			click(Entity.PARTCIPANT_SELECT_BTN, "Select Participant Button");
			assertElementPresent(Entity.FIND_DI_RECIPIENT_PAGE, "Find DI Participant Page");
			type(Entity.CUSTOMER_NAME_TEXT, strCustomer, "Inactive Participant Name");
			click(Entity.FINDBTN, "Find button");
			assertElementPresent(Entity.CUSTOMER_SELECT_ERROR,
					"Participant name not enetered Error message is displayed");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : revenueForNoCommonRenewalMonthEntity() Author : Pradyumna
	 * Description : Verify "View Revenue for Year" in Pricing Details in Entity
	 * when No Common Renewal month is Present Date of creation : 11/20/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void revenueForNoCommonRenewalMonthEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			createEntity(ReportSheet, count);
			click(Affiliation.PRICING_DETAILS, "Pricing Details Button");
			assertElementPresent(Affiliation.PRICING_DETAILS_PAGE, "Pricing Details Page");
			click(Affiliation.REVENUE_YEAR_RADIO_BUTTON, "Revenue Year Radio button");
			type(Affiliation.REVENUE_YEAR_TEXT, "2020", "Revenue Year: 2020");
			click(Affiliation.CALCULATE_BTN, "Calculate button");
			assertElementPresent(Affiliation.GROSS_AMOUNT, "Gross Amount");
			assertElementPresent(Affiliation.ERROR_MESSAGE_FOR_REVENUE, "No revenue exists for specified year.");
		} catch (Exception e) {
			throw e;
		}
	}

	public void updateBTD(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");
			// Click on Update Invoice Button
			click(Entity.UPDATE_INVOICE_BTN, "Update Invoice Button");

			assertTextMatching(Entity.PAGE_TITLE, "Update Invoice", "Page Title");

			// Click on Calendar and select todays date
			click(Entity.BTDCALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");

			// Click on checkbox and click on update button
			click(Entity.SERVICE_TYPE_CHECKBOX, "Service Type Checkbox");
			click(Entity.UPDATE_BTN, "Update Button");
			waitForElementPresent(Entity.PAGE_TITLE, "Page Title");

		} catch (Exception e) {
			throw e;
		}
	}
	public void searchForTheEntity(String entityId) throws Throwable {

		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		type(Entity.ENTITY_ID, entityId , "Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");

	}
	public void selectPriceDetailsAndValidateRevenue() throws Throwable{

		//ENTITY_PRICING
		assertElementPresent(Entity.ENTITY_PRICING, "Pricing Details Button in Entity Profile page");
		click(Entity.ENTITY_PRICING, "Click on Pricing Details Button in Entity Profile page");
		//VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON
		assertElementPresent(Entity.VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON, "View revenue for year radio Button in Revenue Summary page");
		click(Entity.VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON, "Click on View revenue for year radio Button in Revenue Summary page");
		//VIEW_REVENUE_FOR_YEAR_TEXT_BOX
		assertElementPresent(Entity.VIEW_REVENUE_FOR_YEAR_TEXT_BOX, "text box to enter year against radio Button in Revenue Summary page");
		type(Entity.VIEW_REVENUE_FOR_YEAR_TEXT_BOX,"2020", "text box to enter year against radio Button in Revenue Summary page");
		//CALCULATE_REVENUE_BUTTON
		assertElementPresent(Entity.CALCULATE_REVENUE_BUTTON, "Calculate Button in Revenue Summary page");
		click(Entity.CALCULATE_REVENUE_BUTTON, "Click on Calculate Button in Revenue Summary page");
		//GROSS_REP_AMOUNT
		assertElementPresent(Entity.GROSS_REP_AMOUNT, "Gross REp Amount value in Revenue Summary page");
		String grossRepAmountInRevenueSummary = getText(Entity.GROSS_REP_AMOUNT, "Gross REp Amount value in Revenue Summary page");
		//VIEW_REVENUE_DETAILS_BUTTON
		assertElementPresent(Entity.VIEW_REVENUE_DETAILS_BUTTON, "View revenue details Button in Revenue Summary page");
		click(Entity.VIEW_REVENUE_DETAILS_BUTTON, "Click on view revenue details Button in Revenue Summary page");
		//GROSS_REP_AMOUNT_REVENUE_DETAILS
		assertElementPresent(Entity.GROSS_REP_AMOUNT_REVENUE_DETAILS, "Gross REp Amount value in Revenue Details page");
		String grossRepAmountInRevenueDetails = getText(Entity.GROSS_REP_AMOUNT_REVENUE_DETAILS, "Gross REp Amount value in Revenue Details page");
		if(grossRepAmountInRevenueSummary.equals(grossRepAmountInRevenueDetails)) {

			printMessageInReport("Gross Rep Amount in Revenue Summary : " + grossRepAmountInRevenueSummary + 
					" and Gross Rep amount in Revnue Details : " + grossRepAmountInRevenueDetails);
		}

	}	
	public String getTheEntityHavingInvoicesForTheCurrentYear() {
		ArrayList<String> entityId  =  new ArrayList<String>();
		try {

			entityId = SQL_Queries.getTheEntityHavingInvoicesForTheCurrentYear();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityId.get(0);
	}
	public void annualInvoiceVerification(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");
			// Click o Generate Renewal Estimate Button
			click(Entity.GENERATE_RENEWAL_ESTIMATE_BTN, "Generate Renewal Estimate");
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");
			assertElementPresent(Entity.ANNUAL_INVOICE_FOR_STATUTORY_REPRESENTATION_ESTIMATE_TEXT,
					"Annual Invoice For Statutory Representation Estimate Text");
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			throw e;
		}
	}

	public void emPreferenceForNewEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = createEntity(ReportSheet, count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			// Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			// Enter Entity Name
			type(Entity.ENTITY_ID, entityId, "Entity Id textbox");
			// Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			// Select Internal Radio Button and Click on Deactivate button
			click(EM.RADIO_ACTIVE_INTERNAL, "EM Radio Button Internal");
			if (verifyIfElementPresent(EM.BEM_STATUS_EXTERNAL, "BEM Status")) {
				// if(isElementPresent(EM.ACTIVE_STATUS, "Active")) {
				click(EM.DEACTIVATE_BTN, "Deactivate Button");
				assertElementPresent(EM.DEACTIVATE_EM_PAGE, "Deactivate EM Page");
				// Select Discontinue Reason, Service Type and then click on Deactivate button
				click(EM.DEACTIVATE_REASON, "Correction/Entered in Error dropdown reason");
				type(EM.DEACTIVATE_COMMENT, "Testing", "Deactivate Comments");
				click(EM.SERVICE_TYPE_SELECT, "Service Type Select checkbox");
				click(EM.ACTIVATE_DEACTIVATE_BTN, "Deactivate button");
				assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
				assertElementPresent(EM.DEACTIVATE_MESSAGE, "The following units have been deactivated message");
			}
			// Click on Activate button
			click(EM.ACTIVATE_BTN, "Activate Button");
			assertElementPresent(EM.ACTIVATE_EM_PAGE, "Activate EM Page");
			click(EM.SERVICE_TYPE_SELECT, "Service Type Select checkbox");
			click(EM.ACTIVATE_BTN2, "Activate Button");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.ACTIVATE_MESSAGE, "The following units have been activated message");
			waitForElementPresent(EM.SAVEBTN, "Save Button");

			// Click on save button
			click(EM.SAVEBTN, "Save Button");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void updateEntityFilingDate(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity Id");
			click(Generic.SEARCH, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");

			// Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			assertTextMatching(Rep.PAGE_TITLE, "Representation Units", "Page Title");
			click(Rep.DOMESTIC_REP_UNIT,"Domestic Representation Service Type");
			assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE,"Representation Unit Profile");
			String ExistingFilingDate = getText(Entity.REP_FILING_DATE, "Existing Filing Dt On Rep Profile page");
			System.out.println(ExistingFilingDate);
			click(Rep.REP_EDIT_BUTTON,"Rep Edit Button");
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			click(Entity.SAVE_BTN, "Save Btn");
			click(Rep.COMPARE_TO_STATE_RECORD_BTN,"Compare To State Record Button");
			//assertElementPresent(Rep.STATE_RECORD_DETAILS_PAGE,"Details From State Data Repository");
			if (isElementPresent(Rep.STATE_BIZ_ERROR_MSG, "Error Msg For State Biz Service unavailable")) {
				assertTextMatching(Rep.STATE_BIZ_ERROR_MSG,
						"State biz data service not availaible. Please try again later.",
						"Error Msg For State Biz Service unavailable");

			}
			isElementNotPresent(Entity.REP_FILING_DATE, "Existing Entity Rep Filing Date");
			assertTextMatching(Rep.PAGE_TITLE, "Details From State Data Repository", "Page Title");
			String FilingDateStateDataRepository = getText(Rep.CT_FILING_DATE, "Filing Dt On Details From State Data Repository Profile page");
			click(Rep.GO_BACK_BTN,"Go Back Button");
			//Verify page title
			assertTextMatching(Rep.PAGE_TITLE, "Representation Unit - Profile", "Page Title");
			isElementNotPresent(Rep.CT_FILING_DATE, "CT Rep Filing Date");
			assertTextMatching(Entity.REP_FILING_DATE, FilingDateStateDataRepository, "Rep Filing Date Compared with CT Filing Date");
			//assertElementPresent(Rep.REPRESENTATION_UNIT_PROFILE,"Representation Unit Profile");
			
			} catch (Exception e) {
			throw e;
		}
	}

	public void editBEMStatus(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Click on Ref Data Maintenance left nav link
			click(Admin.REF_DATA_MAINTENANCE_LEFT_NAV_LINK, "Ref data maintenance left nav link");
			assertTextMatching(Entity.PAGE_TITLE, "Reference Data Types", "Page Title");

			// Click on Entity Default Activation Status btn
			click(Admin.ENTITY_DEFAULT_ACTIVATION_LINK, "Entity Default Activation Status link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Default Activation Status", "Page Title");

			// Click on Edit Button
			click(Admin.EDIT_IMAGE_BTN, "Edit Button");

			// Select Active External from default status drpdwn and click on save button
			click(Admin.DEFAULT_STATUS_DRPDWN, "Select Active External from default status drpdwn");
			click(Admin.SAVE_BUTTON, "save Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Default Activation Status", "Page Title");

			// Navigate to entity Page
			click(Entity.ENTITY_LINK_TOPNAV, "Entity Link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Page Title");

			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			waitForElementPresent(Entity.BRANCH_PLANT_CREATE_ENTITY, "Select Branch Plant");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			waitForElementPresent(Entity.DOMESTIC_JURIS_DRPDWN, "Select domestic juris");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next
			// btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Entity.SERVICE_TYPE_DRPDWN, "Select Service Type");
			// click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// Enter state ID
			type(Entity.STATE_ID, "1234567", "State ID");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			waitForElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			// Verify whether Entity Has been created
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");

			//Verify EM Preference for New Rep Value
			assertTextMatching(Entity.EM_PREFERENCE_FOR_NEW_REP_VALUE, "Active - External", " EM Preference for New Rep Value");

		} catch (Exception e) {
			throw e;
		}
	}

	public void emPreferenceForNewRepsCTCORPEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// Navigate to entity Page
			click(Entity.ENTITY_LINK_TOPNAV, "Entity Link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Page Title");

			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			waitForElementPresent(Entity.BRANCH_PLANT_CREATE_ENTITY, "Select Branch Plant");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			waitForElementPresent(Entity.DOMESTIC_JURIS_DRPDWN, "Select domestic juris");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Entity.SERVICE_TYPE_DRPDWN, "Select Service Type");
			// click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// Enter state ID
			type(Entity.STATE_ID, "12345", "State ID");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			waitForElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			// Verify whether Entity Has been created
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");

			//Verify EM Preference for New Rep Value for newly created CTCORP Entity
			assertTextMatching(Entity.EM_PREFERENCE_FOR_NEW_REP_VALUE, "Active - External", " EM Preference for New Rep Value");

			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			// Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			// Enter Entity Name
			type(Entity.ENTITY_NAME, entityName, "Entity Name textbox");
			// Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			click(EM.FIRST_EM_DATA,"First EM Data");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			// Select Internal Radio Button and Click on Deactivate button
			click(EM.RADIO_ACTIVE_INTERNAL, "EM Radio Button Internal");
			click(EM.SAVE_BTN, "Save Button");

			// Navigate to entity Page
			click(Entity.ENTITY_LINK_TOPNAV, "Entity Link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Page Title");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			assertElementPresent(Entity.ENTITY_SEARCH_RESULTS_PAGE, "Entity Search Results Page");
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity Data");
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");

			//Verify EM Preference for New Rep Value after change of Default Preference for New Reps 
			assertTextMatching(Entity.EM_PREFERENCE_FOR_NEW_REP_VALUE, "Active - Internal", " EM Preference for New Rep Value");

		}
		catch(Exception e) {
			throw e;
		}
	}

	public void emPreferenceForNewRepsNRAIEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// Navigate to entity Page
			click(Entity.ENTITY_LINK_TOPNAV, "Entity Link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Page Title");

			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			waitForElementPresent(Entity.BRANCH_PLANT_CREATE_ENTITY, "Select Branch Plant");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			waitForElementPresent(Entity.DOMESTIC_JURIS_DRPDWN, "Select domestic juris");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next
			// btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Entity.SERVICE_TYPE_DRPDWN, "Select Service Type");
			// click on next button
			click(Entity.NEXT_BTN, "Next Button");
			// Enter state ID
			type(Entity.STATE_ID, "54321", "State ID");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			waitForElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");
			// Verify whether Entity Has been created
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");

			//Verify EM Preference for New Rep Value for newly created NRAI Entity
			assertTextMatching(Entity.EM_PREFERENCE_FOR_NEW_REP_VALUE, "Active - Internal", " EM Preference for New Rep Value");

			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			// Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			// Enter Entity Name
			type(Entity.ENTITY_NAME, entityName, "Entity Name textbox");
			// Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			click(EM.FIRST_EM_DATA,"First EM Data");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			// Select Internal Radio Button and Click on Deactivate button
			click(EM.RADIO_ACTIVE_EXTERNAL, "EM Radio Button External");
			click(EM.SAVE_BTN, "Save Button");

			// Navigate to entity Page
			click(Entity.ENTITY_LINK_TOPNAV, "Entity Link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Page Title");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			assertElementPresent(Entity.ENTITY_SEARCH_RESULTS_PAGE, "Entity Search Results Page");
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity Data");
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity ID On Entity Profile page");

			//Verify EM Preference for New Rep Value after change of Default Preference for New Reps 
			assertTextMatching(Entity.EM_PREFERENCE_FOR_NEW_REP_VALUE, "Active - External", " EM Preference for New Rep Value");

        }
		catch(Exception e) {
			throw e;
		}
	}
	public void accountSearch(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			//Click on Account Search from left nav link
			click(Entity.ACCOUNT_SEARCH_LINK, "Account Search");
			assertTextMatching(Entity.PAGE_TITLE, "Account Search Criteria", "Page Title");
			// Enter an Account name and search by leading character
			type(Entity.ACCOUNT_NAME, "apple", "Account Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Account Search Results", "Page Title");
			//Select Branch Plant as CTCORP from Filter
			selectByIndex(Entity.FIRSTFILTER_DROP_DOWN, 1, "Select Branch Plant from first filter drop down");
			selectByIndex(Entity.SECONDFILTER_DROP_DOWN, 1, "Select CTCORP from second filter drop down");
			click(Entity.GOBTN,"Go Button");
			assertTextMatching(Entity.FIRST_RESULT_FROM_GRID, "apple", "First Result from grid");
			//Click on Search Again Button
			click(Entity.SEARCH_AGAIN_BTN,"Search Again Button");
			assertTextMatching(Entity.PAGE_TITLE, "Account Search Criteria", "Page Title");
			// Enter an Account name and search by Keyword
			type(Entity.ACCOUNT_NAME, "apple", "Account Name Text box");
			click(Entity.KEYWORD_RADIO_BTN,"Select Keyword Radio Button");
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Account Search Results", "Page Title");
			//Click on Export Button
			click(Entity.EXPORT_BUTTON,"Export Button");

		} catch (Exception e) {
			throw e;
		}
	}
	public void officerDirectorSearch(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String domesticJuris = Excelobject.getCellData(ReportSheet, "Domestic Juris", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);
			String employeeOld = Excelobject.getCellData(ReportSheet, "Employee A", count);
			String employeeNew = Excelobject.getCellData(ReportSheet, "Employee B", count);

			// Navigate to entity Page
			click(Entity.ENTITY_LINK_TOPNAV, "Entity Link");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Page Title");

			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// Click on Create Entity Btn
			click(Entity.CREATE_ENTITY_BTN, "Create Entity Btn");
			waitForElementPresent(Entity.BRANCH_PLANT_CREATE_ENTITY, "Select Branch Plant");
			// select a branch plant and enter a true name
			selectBySendkeys(Entity.BRANCH_PLANT_CREATE_ENTITY, branchPlant, "Select Branch Plant");
			type(Entity.TRUE_NAME, entityName, "True Name Text box");
			waitForElementPresent(Entity.DOMESTIC_JURIS_DRPDWN, "Select domestic juris");
			// Select a Domestic Juris
			selectBySendkeys(Entity.DOMESTIC_JURIS_DRPDWN, domesticJuris, "Select domestic juris");
			// select an entity type
			selectBySendkeys(Entity.ENTITY_TYPE_CREATE_ENTITY, entityType, "Select an entity type");
			// select participant
			click(Entity.PARTCIPANT_SELECT_BTN, "Select button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Apply Same Recipient to other deliverables Button and click on next
			// btn
			click(Entity.APPLY_SAME_RECIPIENT_TO_OTHER_DELIVERABLES_BTN,
					"Apply Same Recipient to other deliverables Button");
			click(Entity.NEXT_BTN, "Next Button");
			// select jurisdiction and Service Type
			click(Entity.JURISDICTION_DRPDWN, "Select Jurisdiction");
			click(Entity.SERVICE_TYPE_INDEPENDENT_DIRECTOR_DRPDWN, "Select Service Type");
			click(Entity.NEXT_BTN, "Next Btn");
			type(Entity.DESCRIPTION_TEXT, "Independent Director/Manager Services", "Description Entered");
			// Click on Calendar and select todays date
			click(Entity.CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			// click on save button
			click(Entity.SAVE_BTN, "Save Btn");
			assertTextMatching(Entity.PAGE_TITLE, "Maintain Officers / Directors", "Page Title");
			click(Entity.OFFICER_DIRECTOR_SELECT_BTN, "Select button");
			type(Entity.EMPLOYEE_NAME, employeeOld, "Employee Name Entered");
            click(Entity.FINDBTN, "Find Btn");
            assertTextMatching(Entity.PAGE_TITLE, "Pick Officer / Director", "Page Title");
            waitForElementPresent(Rep.SELECT_EMPLOYEE, "Click on 1st Select button in the grid");
            click(Rep.SELECT_EMPLOYEE, "Click on 1st Select button in the grid");
            assertTextMatching(Entity.PAGE_TITLE, "Maintain Officers / Directors", "Page Title");
            click(Entity.POSITION_DRPDWN, "Select Position");
            click(Entity.CALENDAR_APPOINTED, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			click(Entity.ADD_UPDATE_BTN, "Add/Update Btn");
			click(Entity.EDIT_BTN, "Edit Btn");
			click(Entity.EDITED_POSITION_DRPDWN, "Edited Position selected");
			click(Entity.ADD_UPDATE_BTN, "Add/Update Btn");
			click(Entity.DELETE_BTN, "Delete Btn");
			handlepopup();
			waitForElementPresent(Entity.NO_RECORDS_FOUND_TEXT,"No Records Found Text");
			assertTextMatching(Entity.NO_RECORDS_FOUND_TEXT, "No records found.", "No Records Found Text");
			
			//Again adding records for Employee Name after performing edit and delete operation
			assertTextMatching(Entity.PAGE_TITLE, "Maintain Officers / Directors", "Page Title");
			click(Entity.OFFICER_DIRECTOR_SELECT_BTN, "Select button");
			type(Entity.EMPLOYEE_NAME, employeeNew, "Employee Name Entered");
            click(Entity.FINDBTN, "Find Btn");
            assertTextMatching(Entity.PAGE_TITLE, "Pick Officer / Director", "Page Title");
            click(Rep.SELECT_EMPLOYEE, "Click on 1st Select button in the grid");
            assertTextMatching(Entity.PAGE_TITLE, "Maintain Officers / Directors", "Page Title");
            click(Entity.POSITION_DRPDWN, "Select Position");
            click(Entity.CALENDAR_APPOINTED, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");
			click(Entity.ADD_UPDATE_BTN, "Add/Update Btn");
			String employeeName = getText(Entity.NEW_EMPLOYEE, "Officer Name present on Rep Profile pg.");
			click(Rep.RETURN_TO_PROFILE_VIEW, "Return to Profile View Btn");
			assertTextMatching(Entity.PAGE_TITLE, "Representation Unit - Profile", "Page Title");
			assertTextMatching(Entity.NEW_EMPLOYEE, employeeName, "Verify Employee Name");
			
			//Search for the respective officer thru left nav link
			click(Entity.OFFICER_DIRECTOR_SEARCH, "Click on officer/director search left nav link");
			assertTextMatching(Entity.PAGE_TITLE, "Officer / Director Search Criteria", "Page Title");
			click(Entity.OFFICER_DIRECTOR_SELECT_BTN, "Select button");
			type(Entity.EMPLOYEE_NAME, employeeNew, "Employee Name Entered");
            click(Entity.FINDBTN, "Find Btn");
            assertTextMatching(Entity.PAGE_TITLE, "Pick Officer / Director", "Page Title");
            waitForElementPresent(Rep.SELECT_EMPLOYEE, "Click on 1st Select button in the grid");
            click(Rep.SELECT_EMPLOYEE, "Click on 1st Select button in the grid");
            click(Entity.SEARCH_BTN, "Search Btn");
            click(Entity.SELECT_ALL_BTN, "Select All Btn");
            click(Entity.REPLACE_DIRECTOR, "Replace Director");
            assertTextMatching(Entity.PAGE_TITLE, "Replace Officer / Director", "Page Title");
            click(Entity.OFFICER_DIRECTOR_SELECT_BTN, "Select button");
			type(Entity.EMPLOYEE_NAME, employeeOld, "Employee Name Entered");
            click(Entity.FINDBTN, "Find Btn");
            assertTextMatching(Entity.PAGE_TITLE, "Pick Officer / Director", "Page Title");
            click(Rep.SELECT_EMPLOYEE, "Click on 1st Select button in the grid");
            assertTextMatching(Entity.PAGE_TITLE, "Replace Officer / Director", "Page Title");
            click(Entity.POSITION_REPLACE_DRPDWN, "Select Position");
            click(Entity.REPLACE_BTN, "Replace Btn");
            assertTextMatching(Entity.PAGE_TITLE, "Officer / Director Search Results", "Page Title");
		} catch (Exception e) {
			throw e;
		}
	}

	
}
