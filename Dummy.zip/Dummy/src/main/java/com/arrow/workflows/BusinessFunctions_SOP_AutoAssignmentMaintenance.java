package com.arrow.workflows;

import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Communication;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_SOP_AutoAssignmentMaintenance extends BusinessFunctions {
	
	/********************************************************************************************************
	 * Method Name : customerNameMapping() 
	 * Author : Pradyumna 
	 * Description : This method will view customer Name Mapping
	 * Date of creation : 10/14/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String customerNameMapping(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String customerName=Excelobject.getCellData(ReportSheet, "CustomerName", count);
			String entityName=Excelobject.getCellData(ReportSheet, "EntityName", count);
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			type(SOP.CUSTOMER_NAME,customerName,"Customer Name");
			click(SOP.ENTITY_AFF_BTN_SELECT, "Entity Affiliation Select button");
			assertElementPresent(SOP.FIND_ENT_AFF_PAGE, "Find Entity/Affiliation Page");
			click(Generic.ENTITY_RADIO_BTN, "Entity Radio button");
			type(Generic.NAME_FIELD,entityName,"Entity Name");
			click(Generic.FIND_BUTTON, "Find button");
			assertElementPresent(SOP.PICK_ENTITY_PAGE, "Pick Entity Page");
			click(Generic.SELECT_BUTTON, "Select button");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			click(Generic.IMG_ADD_UPDATE, "Add/Update button");
			click(SOP.AFF_MAPPING_EDIT, "Edit button");
			assertElementPresent(SOP.EDITED_ENTITY_AFF_NAME, "Edited Entity Aff Name");
			click(Generic.IMG_CLEAR, "Clear button");
			assertElementPresent(SOP.DELETED_ENTITY_AFF_NAME, "Deleted Entity Aff Name");
			click(SOP.AFF_MAPPING_EDIT, "Edit button");
			click(SOP.AFF_MAPPING_DELETE, "Delete button");
			assertElementPresent(SOP.DELETED_ENTITY_AFF_NAME, "Deleted Entity Aff Name");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : methodOfServiceRanking() 
	 * Author : Pradyumna 
	 * Description : This method will view Method Of Service Ranking Setup
	 * Date of creation : 10/29/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String methodOfServiceRanking(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String txtRanking=Excelobject.getCellData(ReportSheet, "TextRanking", count);
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			//Click on Method of Service Ranking Setup
			click(SOP.METHOD_OF_SERVICE_RANKING_SETUP, "Method of Service Ranking Setup");
			assertElementPresent(SOP.METHOD_OF_SERVICE_RANKING_SETUP_PAGE, "Method of Service Ranking Setup Page");
			//Select Dropdown
			click(SOP.LAW_ENFORCEMENT_DROPDOWN, "Law Enforcement Dropdown");
			type(SOP.TEXT_RANKING,txtRanking,"Text Ranking");
			click(SOP.ADDUPDATE_BTN, "Add Update Button");
			//Select Law Enforcement from Filters
			click(SOP.METHOD_OF_SERVICE_DROPDOWN, "Method of Service Dropdown");
			click(SOP.LAW_ENFORCEMENT_RHS_DROPDOWN, "Law Enforcement Dropdown");
			click(Generic.GO_BUTTON, "Go Button");
			//Edit and Delete added Law Enforcement
			click(SOP.EDIT_BUTTON, "Edit Button");
			click(SOP.DELETE_BUTTON, "Delete Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : customerRankingSetup() 
	 * Author : Pradyumna 
	 * Description : This method will view Customer Ranking Setup
	 * Date of creation : 10/29/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String customerRankingSetup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName=Excelobject.getCellData(ReportSheet, "EntityName", count);
			String tierName=Excelobject.getCellData(ReportSheet, "TierName", count);
			String tierRank=Excelobject.getCellData(ReportSheet, "TierRank", count);
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			//Click on Customer Ranking Setup
			click(SOP.CUSTOMER_RANKING_SETUP, "Customer Ranking Setup");
			assertElementPresent(SOP.CUSTOMER_RANKING_SETUP_PAGE, "Customer Ranking Setup Page");
			//Select Entity Select Button
			click(SOP.ENTITY_AFF_BTN_SELECT, "Entity Affiliation Select button");
			assertElementPresent(SOP.FIND_ENT_AFF_PAGE, "Find Entity/Affiliation Page");
			click(Generic.ENTITY_RADIO_BTN, "Entity Radio button");
			type(Generic.NAME_FIELD,entityName,"Entity Name");
			click(Generic.FIND_BUTTON, "Find button");
			assertElementPresent(SOP.PICK_ENTITY_PAGE, "Pick Entity Page");
			click(Generic.SELECT_BUTTON, "Select button");
			assertElementPresent(SOP.CUSTOMER_RANKING_SETUP_PAGE, "Customer Ranking Setup Page");
			click(SOP.TIER_NAME, "Select Tier Name");
			click(Generic.IMG_ADD_UPDATE, "Add/Update button");
			//Select from Dropdown
			click(SOP.ENTITY_AFF_FILTER, "Select Entity Affiliation from Dropdown");
			click(Generic.SECOND_DROP_EQUALS, "Select drop down equals");
			type(Generic.DROP_DOWN_TEXT,entityName,"Drop down text");
			click(Generic.GO_BUTTON, "Go button");
			//Edit and Delete Customer Ranking data
			click(SOP.CUSTOMER_RANKING_EDIT_BUTTON, "Edit Button");
			click(SOP.CUSTOMER_RANKING_DELETE_BUTTON, "Delete Button");
			assertElementPresent(SOP.CUSTOMER_RANKING_SETUP_PAGE, "Customer Ranking Setup Page");
			//Create a new Tier
			click(SOP.CREATE_EDIT_TIER, "Create/Edit Tier Button");
			assertElementPresent(SOP.TIER_SETUP_PAGE, "Tier Setup Page");
			type(SOP.TIER_NAME_FIELD,tierName,"Tier Name Text");
			type(SOP.TIER_RANK_FIELD,tierRank,"Tier Rank Text");
			click(Generic.IMG_ADD_UPDATE, "Img Add Update Button");
			//Search for Created Tier, Edit it and Delete it
			click(SOP.TIER_NAME_FILTER, "Select Tier Name from Dropdown");
			click(Generic.SECOND_DROP_EQUALS, "Select drop down equals");
			type(Generic.DROP_DOWN_TEXT,tierName,"Drop down text");
			click(Generic.GO_BUTTON, "Go button");
			//Click on Edit and Delete Button
			click(SOP.TIER_EDIT_BUTTON, "Edit button displayed for Tier");
			click(SOP.TIER_DELETE_BUTTON, "Delete button displayed for Tier");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	
	
	/********************************************************************************************************
	 * Method Name : lawsuitRankingSetup() 
	 * Author : Pradyumna 
	 * Description : This method will view Customer Ranking Setup
	 * Date of creation : 10/29/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String lawsuitRankingSetup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			//Click on Lawsuit Ranking Setup
			click(SOP.LAWSUIT_RANKING_SETUP, "lawsuit Ranking Setup");
			assertElementPresent(SOP.LAWSUIT_RANKING_SETUP_PAGE, "lawsuit Ranking Setup Page");
			//Select Lawsuit and Tier from Dropdown
			click(SOP.LAWSUIT_TYPE_DROPDOWN, "Lawsuit Dropdown");
			click(SOP.TIER_DROPDOWN, "Tier Dropdown");
			click(Generic.IMG_ADD_UPDATE, "Add/Update button");
			
			//Select from Dropdown
			click(SOP.LAWSUIT_TYPE_FILTER, "Select Lawsuit type from Dropdown");
			click(SOP.LEVIS_FILTER, "Select text LEVIS from dropdown");
			click(Generic.GO_BUTTON, "Go button");
			//Edit and Delete Lawsuit Ranking data
			click(SOP.LAWSUIT_EDIT_BUTTON, "Edit Button");
			click(SOP.LAWSUIT_DELETE_BUTTON, "Delete Button");
			assertElementPresent(SOP.LAWSUIT_RANKING_SETUP_PAGE, "Lawsuit Ranking Setup Page");
			//Create a new Tier
			click(SOP.CREATE_EDIT_TIER, "Create/Edit Tier Button");
			assertElementPresent(SOP.TIER_SETUP_PAGE, "Tier Setup Page");
			//Click on Cancel Button
			click(Generic.CANCEL, "Cancel button");
			assertElementPresent(SOP.LAWSUIT_RANKING_SETUP_PAGE, "lawsuit Ranking Setup Page");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	
	/********************************************************************************************************
	 * Method Name : complexityRankingSetup() 
	 * Author : Pradyumna 
	 * Description : This method will view Complexity Ranking Setup
	 * Date of creation : 11/1/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String complexityRankingSetup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			//Click on Complexity Ranking Setup
			click(SOP.COMPLEXITY_RANKING_SETUP, "Complexity Ranking Setup");
			assertElementPresent(SOP.COMPLEXITY_RANKING_SETUP_PAGE, "Complexity Ranking Setup Page");
			//Select Lawsuit and Tier1 from Dropdown
			click(SOP.LAWSUIT_TYPE_DROPDOWN, "Lawsuit Dropdown");
			click(SOP.TIER1_DROPDOWN, "Tier1 Dropdown");
			click(Generic.IMG_ADD_UPDATE, "Add/Update button");			
			//Select from Dropdown
			click(SOP.LAWSUIT_TYPE_FILTER, "Select Lawsuit type from Dropdown");
			click(SOP.LEVIS_FILTER, "Select text LEVIS from dropdown");
			click(Generic.GO_BUTTON, "Go button");
			waitForElementPresent(SOP.LAWSUIT_EDIT_BUTTON, "Edit Button");
			//Edit and Delete Lawsuit Ranking data
			click(SOP.LAWSUIT_EDIT_BUTTON, "Edit Button");
			click(SOP.LAWSUIT_DELETE_BUTTON, "Delete Button");
			waitForElementPresent(SOP.COMPLEXITY_RANKING_SETUP_PAGE, "Complexity Ranking Setup Page");
			assertElementPresent(SOP.COMPLEXITY_RANKING_SETUP_PAGE, "Complexity Ranking Setup Page");
			//Create a new Tier
			click(SOP.CREATE_EDIT_TIER, "Create/Edit Tier Button");
			assertElementPresent(SOP.TIER_SETUP_PAGE, "Tier Setup Page");
			//Click on Cancel Button
			click(Generic.CANCEL, "Cancel button");
			waitForElementPresent(SOP.COMPLEXITY_RANKING_SETUP_PAGE, "Complexity Ranking Setup Page");
			assertElementPresent(SOP.COMPLEXITY_RANKING_SETUP_PAGE, "Complexity Ranking Setup Page");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : manageAssignmentGroup() 
	 * Author : Pradyumna 
	 * Description : This method will view manage Assignment Group
	 * Date of creation : 11/1/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String manageAssignmentGroup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String groupName=Excelobject.getCellData(ReportSheet, "GroupName", count);
			String employeeName=Excelobject.getCellData(ReportSheet, "EmployeeName", count);

			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			//Click on Manage Assignment Group
			click(SOP.MANAGE_ASSIGNMENT_GROUP, "Manage Assignment Group");
			assertElementPresent(SOP.MANAGE_ASSIGNMENT_GROUP_PAGE, "Manage Assignment Group Page");
			//Create New Group
			click(Generic.CREATE_GROUP, "Create Group");
			assertElementPresent(SOP.CREATE_AUTO_ASSIGNMENT_GROUP_PAGE, "Create Auto Assignment Group Page");
			type(SOP.GROUP_NAME_TEXT,groupName,"Group Name text");
			click(SOP.COMPLEXITY_TIER_1, "Complexity Tier 1");
			click(SOP.JURISDICTION, "Jurisdiction Drodown");
			click(Generic.SAVE, "Save button");
			assertElementPresent(SOP.MANAGE_ASSIGNMENT_GROUP_PAGE, "Manage Assignment Group Page");
			//Enter Created name in Filter
			selectByIndex(Generic.SELECT_DROPDOWN, 1, "Select Group Name");
			selectByIndex(Generic.SELECT_SECOND_DROPDOWN, 5, "Select Second Dropdown");
			type(Generic.DROP_DOWN_TEXT,groupName,"Group Name text");
			click(Generic.GO_BUTTON, "Go button");
			assertElementPresent(SOP.AUTO_ASSIGNMENT_GROUP_LIST, "Auto Assignment Group List Page");
			//Select the displayed Group Name
			click(SOP.SELECT_GROUPNAME, "Group Name");
			assertElementPresent(SOP.AUTO_ASSIGNMENT_GROUP_PROFILE_PAGE, "Auto Assignment Group Profile Page");
			click(Generic.MAINTAIN_BTN, "Maintain button");
			assertElementPresent(SOP.ASSIGNMENT_GROUP_USERS, "Assignment Group Users Page");
			click(Generic.ADD_BUTTON, "Add User Button");
			assertElementPresent(SOP.FIND_USER_PAGE, "Find User Page");
			type(SOP.EMPLOYEE_NAME,employeeName,"Employee Name");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(SOP.PICK_USER_PAGE, "Pick User Page");
			click(SOP.SELECT_EMPLOYEE, "Employee Checkbox");
			click(Generic.ADD_BUTTON, "Add Button");
			assertElementPresent(SOP.ASSIGNMENT_GROUP_USERS, "Assignment Group Users Page");
			click(SOP.UNSELECT_EMPLOYEE, "Employee Checkbox");
			click(Generic.REMOVE_BUTTON, "Remove Button");
			assertElementPresent(SOP.ASSIGNMENT_GROUP_USERS, "Assignment Group Users Page");
			//Navigate back to assignment Groups and Search name in Filter
			click(SOP.ASSIGNMENT_GROUP_PAGE, "Assignment Groups");
			selectByIndex(Generic.SELECT_DROPDOWN, 1, "Select Group Name");
			selectByIndex(Generic.SELECT_SECOND_DROPDOWN, 5, "Select Second Dropdown");
			type(Generic.DROP_DOWN_TEXT,groupName,"Group Name text");
			click(Generic.GO_BUTTON, "Go button");
			assertElementPresent(SOP.AUTO_ASSIGNMENT_GROUP_LIST, "Auto Assignment Group List Page");
			click(SOP.DELETE_BTN, "Delete button");
			assertElementPresent(SOP.AUTO_ASSIGNMENT_GROUP_LIST, "Auto Assignment Group List Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : groupProfileAndPriority() 
	 * Author : Pradyumna 
	 * Description : This method will view manage Assignment Group having Group Profile and Priority
	 * Date of creation : 11/1/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String groupProfileAndPriority(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String employeeName=Excelobject.getCellData(ReportSheet, "EmployeeName", count);
			// click on My Worksheets link
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			click(SOP.AUTO_ASSIGNMENT_MAINTENANCE, "Auto Assignment Maintainence");
			assertElementPresent(SOP.CUSTOMER_NAME_MAPPING, "Customer Name Mapping Page");
			//Click on Manage Assignment Group
			click(SOP.MANAGE_ASSIGNMENT_GROUP, "Manage Assignment Group");
			assertElementPresent(SOP.MANAGE_ASSIGNMENT_GROUP_PAGE, "Manage Assignment Group Page");
			//Navigate to User Group Profile
			click(SOP.USER_GROUP_PROFILE, "User Group Profile");
			assertElementPresent(SOP.EMPLOYEE_SEARCH_CRITERIA, "Employee Search Criteria Page");
			type(SOP.EMPLOYEE_NAME,employeeName,"Employee Name");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(SOP.EMPLOYEE_SEARCH_RESULT, "Employee Search Results");
			click(SOP.SELECT_FIRST_EMPLOYEE, "Select First Employee");
			assertElementPresent(SOP.AUTO_ASSIGNMENT_USER_GROUP_LIST, "Auto Assignment User Group List");
			//Navigate to Manage Group Priority
			click(SOP.MANAGE_GROUP_PRIORITY, "Manage Group Priority");
			assertElementPresent(SOP.GROUP_PRIORITY_MAINTENANCE_PAGE, "Auto Assignment Group Priority Maintenance");
			click(SOP.SERVICE_TEAM, "Select Service Team");
			waitForElementPresent(SOP.SERVICE_TEAM_MEMBER, "Service Team Member");
			//selectByIndex(SOP.SERVICE_TEAM, 1, "Select Service Team");
			click(SOP.SERVICE_TEAM_MEMBER, "Select Service Team Member");
			//selectByIndex(SOP.SERVICE_TEAM_MEMBER, 2, "Select Service Team Member");
			waitForElementPresent(Generic.SAVE, "Save Button");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(SOP.PRIORITY_ERROR_MESSAGE, "Priority Error Message");
	
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
}
