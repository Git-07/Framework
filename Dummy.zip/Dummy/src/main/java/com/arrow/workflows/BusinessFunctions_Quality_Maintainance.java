package com.arrow.workflows;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.QualityMaintainance_SOP;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_Quality_Maintainance extends BusinessFunctions_SOP{
	
	public void worksheetReviewSetup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//click on SOP link
			click(HomePage.SOPLINK, "SOP Link");
			//Click on Quality Maintainance Left Nav Link
			click(SOP.QUALITY_MAINTAINANCE_LEFT_NAV_LINK,"Quality Maintainance Left Nav Link");
			//Verify title of the page
			assertElementPresent(QualityMaintainance_SOP.WORKSHEET_REVIEW_SETUP_PAGE_TITLE, "Page title is Worksheet Review Setup");			
			//For Reviewable Fields			
			//Select Notice Of from left reviewable selector
			click(QualityMaintainance_SOP.LEFT_REVIEWABLE_SELECTOR_NOTICE_OF,"Select Notice Of from left reviewable selector");
			//click on move right button
			click(QualityMaintainance_SOP.REVIEWABLE_MOVE_RIGHT_BTN,"Move Right Button");
			//verify it is moved to right selector
			isElementPresent(QualityMaintainance_SOP.RIGHT_REVIEWABLE_SELECTOR_NOTICE_OF,"Verify Notice Of is present in right reviewable selector");
			//Click on save button
			click(QualityMaintainance_SOP.REVIEWABLE_SAVE_BTN,"Reviewable Save Button");
			//Select Notice Of from right reviewable selector
			click(QualityMaintainance_SOP.RIGHT_REVIEWABLE_SELECTOR_NOTICE_OF,"Select Notice Of is present in right reviewable selector");
			//click on move left button
			click(QualityMaintainance_SOP.REVIEWABLE_MOVE_LEFT_BTN,"Move Left Button");
			//verify it is moved to left selector
			isElementPresent(QualityMaintainance_SOP.LEFT_REVIEWABLE_SELECTOR_NOTICE_OF,"Verify Notice Of is present in left reviewable selector");
			//Click on save button
			click(QualityMaintainance_SOP.REVIEWABLE_SAVE_BTN,"Reviewable Save Button");		
			// For Fatal/Non-Fatal Fields
			//Select Remarks from left Fatal/Non-Fatal Fields selector
			click(QualityMaintainance_SOP.LEFT_FATAL_NONFATAL_SELECTOR_REMARKS,"Select Remarks from left Fatal/Non-Fatal Fields selector");
			//click on move right button
			click(QualityMaintainance_SOP.FATAL_NONFATAL_MOVE_RIGHT_BTN,"Fatal/Non-Fatal Move Right Button");
			//verify it is moved to right selector
			isElementPresent(QualityMaintainance_SOP.RIGHT_FATAL_NONFATAL_SELECTOR_REMARKS,"Verify Remarks is present in right Fatal/Non-Fatal selector");
			//Click on save button
			click(QualityMaintainance_SOP.FATAL_NONFATAL_SAVE_BTN,"Fatal/Non Fatal Save Button");
			//Select Remarks from right fatal/non fatal selector
			click(QualityMaintainance_SOP.RIGHT_FATAL_NONFATAL_SELECTOR_REMARKS,"Select Remarks is present in right Fatal/Non-Fatal selector");
			//click on move left button
			click(QualityMaintainance_SOP.FATAL_NONFATAL_MOVE_LEFT_BTN,"Fatal/Non-Fatal Move Left Button");
			//verify it is moved to left selector
			isElementPresent(QualityMaintainance_SOP.LEFT_FATAL_NONFATAL_SELECTOR_REMARKS,"Verify Remarks is present in left Fatal/Non-Fatal selector");
			//Click on save button
			click(QualityMaintainance_SOP.FATAL_NONFATAL_SAVE_BTN,"Fatal/Non Fatal Save Button");
			//For Typo Fields
			//Select Remarks from left Typo Fields selector
			click(QualityMaintainance_SOP.LEFT_TYPO_SELECTOR_REMARKS,"Select Remarks from left Typo Fields selector");
			//click on move right button
			click(QualityMaintainance_SOP.TYPO_MOVE_RIGHT_BTN,"Typo Move Right Button");
			//verify it is moved to right selector
			isElementPresent(QualityMaintainance_SOP.RIGHT_TYPO_SELECTOR_REMARKS,"Verify Remarks is present in right Typo selector");
			//Click on save button
			click(QualityMaintainance_SOP.TYPO_SAVE_BTN,"Typo Save Button");
			//Select Remarks from right typo selector
			click(QualityMaintainance_SOP.RIGHT_TYPO_SELECTOR_REMARKS,"Select Remarks is present in right Typo selector");
			//click on move left button
			click(QualityMaintainance_SOP.TYPO_MOVE_LEFT_BTN,"Fatal/Non-Fatal Move Left Button");
			//verify it is moved to left selector
			isElementPresent(QualityMaintainance_SOP.LEFT_TYPO_SELECTOR_REMARKS,"Verify Remarks Of is present in left Typo selector");
			//Click on save button
			click(QualityMaintainance_SOP.TYPO_SAVE_BTN,"Typo Save Button");
		} catch (Exception e) {
			throw e;
		}

	}

	public void excludeAffiliations(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affName=Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
			
			//click on SOP link
			click(HomePage.SOPLINK, "SOP Link");
			
			//Click on Quality Maintainance Left Nav Link
			click(SOP.QUALITY_MAINTAINANCE_LEFT_NAV_LINK,"Quality Maintainance Left Nav Link");
			
			//Click On Quality Randomiser SetUp Left nav link
			click(SOP.QUALITY_RANDOMISER_SETUP_LEFT_NAV_LINK,"Quality Randomiser SetUp Left Nav Link");
			
			//Click ON Exclude Affiliations Tab
			click(QualityMaintainance_SOP.EXCLUDE_AFFILIATIONS_TAB,"Exclude Affiliations Tab");
			
			//Verify title of the page
			assertElementPresent(QualityMaintainance_SOP.QUALITY_RANDOMISER_SETUP_PAGE_TITLE, "Page title is Quality Randomiser Setup");
			
			//Click On Affiliation Select Btn
			click(QualityMaintainance_SOP.AFFILIATION_SELECT_BTN,"Affiliation Select Button");
			
			//Enter Affiliation Name and click on Find Btn
			type(Affiliation.AFFILIATIONNAME,affName,"Affiliation Name text box");
			click(Affiliation.FINDBTN,"Find Button");
			
			//Click On First select btn from affiliation search result
			click(QualityMaintainance_SOP.FIRST_AFFILIATION_SELECT_BTN,"First Select Btn On Affilaition Search Result Page");
			
			//Click On save Btn
			click(QualityMaintainance_SOP.SAVE_BTN,"Save Btn");
			
			//Click On Delete Btn
			click(QualityMaintainance_SOP.FIRST_DELETE_BTN_ON_GRID,"Delete Btn");
			
				
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void excludeTeams(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//click on SOP link
			click(HomePage.SOPLINK, "SOP Link");
			//Click on Quality Maintainance Left Nav Link
			click(SOP.QUALITY_MAINTAINANCE_LEFT_NAV_LINK,"Quality Maintainance Left Nav Link");
			//Click On Quality Randomiser SetUp Left nav link
			click(SOP.QUALITY_RANDOMISER_SETUP_LEFT_NAV_LINK,"Quality Randomiser SetUp Left Nav Link");
			//Click ON Exclude Teams Tab
			click(QualityMaintainance_SOP.EXCLUDE_TEAMS_TAB,"Exclude Teams Tab");
			//Select First Team from Select a team Drop Down
			selectByIndex(QualityMaintainance_SOP.SELECT_A_TEAM_DRPDWN, 1, "Select a Team Drp dwn");	
			//Click On save Btn
			click(QualityMaintainance_SOP.SAVE_BTN,"Save Btn");
			//Click On Delete Btn
			click(QualityMaintainance_SOP.FIRST_DELETE_BTN_ON_GRID,"Delete Btn");
			
				
		} catch (Exception e) {
			throw e;
		}

	}


	

}
