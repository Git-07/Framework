package com.arrow.workflows;

import java.text.SimpleDateFormat;
import java.util.Date;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.Reports;

public class BusinessFunctions_Reports extends BusinessFunctions{

	/********************************************************************************************************
	 * Method Name : RequestForSOPVolumesReport() 
	 * Author : Arpana 
	 * Description : To verify user can request for the SOP Volumes Report for an affiliation/entity
	 * Date of creation : 06/16/2020
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String RequestForSOPVolumesReport(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			
			//Variables to hold grid data
			String gridRequestedDate=null;
			String gridName=null;
			String gridDescription=null;
			String gridRequestedBy=null;
			String gridStatus=null;
			
			//Variables to hold excel data
			String requestedBy = Excelobject.getCellData(ReportSheet, "Member",count);
			String reportName = Excelobject.getCellData(ReportSheet, "ReportName", count);
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);
			String affiliationName = Excelobject.getCellData(ReportSheet, "AffiliationName", count);
			String todaysDate=formatter.format(date).toString(); 
			String status="In Queue";
			
			//Go to Reports Page and then Request for a Report
			click(Reports.REPORTS_LINK,"Reports Tab Link");
			assertElementPresent(Reports.REPORTS_PAGE_TITLE,"Reports Page Title");
			click(Reports.REQUEST_REPORT_LINK,"Request Report Left Nav Bar Link");
			
			//Create New Report-Step 1
			assertElementPresent(Reports.CREATE_NEW_REPORTS_STEP1_PAGE_TITLE,"Create New Reports Page Step1 Title");
			type(Reports.NAME_TEXTBOX,reportName,"Name Textbox");
			click(Reports.SOP_VOLUMES_REPORT_DESCRIPTION,"Description Drop-Down");
			click(Generic.NEXT_BUTTON,"Next Button");
			
			//Create New Report-Step 2
			assertElementPresent(Reports.CREATE_NEW_REPORTS_STEP2_PAGE_TITLE,"Create New Reports Step2 Page Title");
			click(Reports.SELECT_BUTTON,"Select Button");
			assertElementPresent(Reports.FIND_ENTITY_AFFILIATION_PAGE_TITLE,"Find Entity/Affiliation Page Title");
			
			if(entityName.isEmpty())
			{
				type(Reports.NAME_TEXTBOX,affiliationName,"Name Textbox");
				click(Reports.FIND_BUTTON,"Find Button");
				//Pick Affiliation Page
				assertElementPresent(Reports.PICK_AFFILIATION_PAGE_TITLE,"Pick Affiliation Page Title");
			}
			else
			{
				click(Reports.ENTITY_RADIO_BUTTON,"Entity Radio Button");
				type(Reports.NAME_TEXTBOX,entityName,"Name Textbox");
				click(Reports.FIND_BUTTON,"Find Button");
				//Pick Entity Page
				assertElementPresent(Reports.PICK_ENTITY_PAGE_TITLE,"Pick Entity Page Title");
			}
			
			click(Generic.SELECT_BUTTON,"Select Button");
			click(Reports.GENERATE_REPORT_BUTTON,"Generate Report Button");
			assertElementPresent(Reports.REPORTS_PAGE_TITLE,"Reports");
			
			//Verify if the report request data got updated in the grid correctly
			//Requested Date 
			assertElementPresent(Reports.REPORTS_FIRST_ROW_REQUESTED_DATE_DATA, "Requested Date First Row Grid Data");
			gridRequestedDate  = getText(Reports.REPORTS_FIRST_ROW_REQUESTED_DATE_DATA, "Requested Date First Row Grid Data");
			compareStrings(gridRequestedDate,todaysDate);
			
			//Name
			assertElementPresent(Reports.REPORTS_FIRST_ROW_NAME_DATA, "Name First Row Grid Data");
			gridName  = getText(Reports.REPORTS_FIRST_ROW_NAME_DATA, "Name First Row Grid Data");
			compareStrings(gridName,reportName);
			
			//Description
			assertElementPresent(Reports.REPORTS_FIRST_ROW_DESCRIPTION_DATA, "Description First Row Grid Data");
			gridDescription  = getText(Reports.REPORTS_FIRST_ROW_DESCRIPTION_DATA, "Description First Row Grid Data");
			compareStrings(gridDescription,reportName);
			
			//Requested By
			assertElementPresent(Reports.REPORTS_FIRST_ROW_REQUESTED_BY_DATA, "Requested By First Row Grid Data");
			gridRequestedBy  = getText(Reports.REPORTS_FIRST_ROW_REQUESTED_BY_DATA, "Requested By First Row Grid Data");
			compareStrings(gridRequestedBy,requestedBy);
			
			//Status
			assertElementPresent(Reports.REPORTS_FIRST_ROW_STATUS_DATA, "Status First Row Grid Data");
			gridStatus  = getText(Reports.REPORTS_FIRST_ROW_STATUS_DATA, "Status First Row Grid Data");
			compareStrings(gridStatus,status);
			
			//Delete Button
			assertElementPresent(Reports.REPORTS_FIRST_ROW_DELETE_BUTTON, "First Row Delete Button");
			
			//Delete the report request created
			click(Reports.REPORTS_FIRST_ROW_DELETE_BUTTON,"Delete Button");
			driver.switchTo().alert().accept();
			Thread.sleep(lSleep_VLow);
			//assertElementPresent(Reports.NO_RECORDS_FOUND_GRID_MSG, "No Records Found");
			
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : RequestForPaperlessSOPConversionsReport() 
	 * Author : Arpana 
	 * Description : To verify user can request for the Paperless SOP Conversions Report for an owning service
	 * Date of creation : 06/16/2020
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String RequestForPaperlessSOPConversionsReport(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			
			//Variables to hold grid data
			String gridRequestedDate=null;
			String gridName=null;
			String gridDescription=null;
			String gridRequestedBy=null;
			String gridStatus=null;
			
			//Variables to hold excel data
			String requestedBy = Excelobject.getCellData(ReportSheet, "Member",count);
			String reportName = Excelobject.getCellData(ReportSheet, "ReportName", count);
			//String owningServiceTeamName = Excelobject.getCellData(ReportSheet, "OwningServiceTeamName", count);
			String todaysDate=formatter.format(date).toString(); 
			String status="In Queue";
			
			//Go to Reports Page and then Request for a Report
			click(Reports.REPORTS_LINK,"Reports Tab Link");
			assertElementPresent(Reports.REPORTS_PAGE_TITLE,"Reports Page Title");
			click(Reports.CREATE_NEW_BUTTON,"Create New Button");
			
			//Create New Report-Step 1
			assertElementPresent(Reports.CREATE_NEW_REPORTS_STEP1_PAGE_TITLE,"Create New Reports Page Step1 Title");
			type(Reports.NAME_TEXTBOX,reportName,"Name Textbox");
			click(Reports.PAPERLESS_SOP_CONVERSION_REPORT_DESCRIPTION,"Description Drop-Down");
			click(Generic.NEXT_BUTTON,"Next Button");
			waitForElementPresent(Reports.CREATE_NEW_REPORTS_STEP2_PAGE_TITLE,"Create New Reports Step2 Page Title");
			
			//Create New Report-Step 2
			assertElementPresent(Reports.CREATE_NEW_REPORTS_STEP2_PAGE_TITLE,"Create New Reports Step2 Page Title");
			click(Reports.CT_CORPORATE_DEMO_TEAM_OWNING_SERVICE,"Owning Service Drop Down");
			click(Reports.GENERATE_REPORT_BUTTON,"Generate Report Button");
			waitForElementPresent(Reports.REPORTS_PAGE_TITLE,"Reports");
			assertElementPresent(Reports.REPORTS_PAGE_TITLE,"Reports");
			
			//Verify if the report request data got updated in the grid correctly
			//Requested Date 
			assertElementPresent(Reports.REPORTS_FIRST_ROW_REQUESTED_DATE_DATA, "Requested Date First Row Grid Data");
			gridRequestedDate  = getText(Reports.REPORTS_FIRST_ROW_REQUESTED_DATE_DATA, "Requested Date First Row Grid Data");
			compareStrings(gridRequestedDate,todaysDate);
			
			//Name
			assertElementPresent(Reports.REPORTS_FIRST_ROW_NAME_DATA, "Name First Row Grid Data");
			gridName  = getText(Reports.REPORTS_FIRST_ROW_NAME_DATA, "Name First Row Grid Data");
			compareStrings(gridName,reportName);
			
			//Description
			assertElementPresent(Reports.REPORTS_FIRST_ROW_DESCRIPTION_DATA, "Description First Row Grid Data");
			gridDescription  = getText(Reports.REPORTS_FIRST_ROW_DESCRIPTION_DATA, "Description First Row Grid Data");
			compareStrings(gridDescription,reportName);
			
			//Requested By
			assertElementPresent(Reports.REPORTS_FIRST_ROW_REQUESTED_BY_DATA, "Requested By First Row Grid Data");
			gridRequestedBy  = getText(Reports.REPORTS_FIRST_ROW_REQUESTED_BY_DATA, "Requested By First Row Grid Data");
			compareStrings(gridRequestedBy,requestedBy);
			
			//Status
			assertElementPresent(Reports.REPORTS_FIRST_ROW_STATUS_DATA, "Status First Row Grid Data");
			gridStatus  = getText(Reports.REPORTS_FIRST_ROW_STATUS_DATA, "Status First Row Grid Data");
			compareStrings(gridStatus,status);
			
			//Delete Button
			assertElementPresent(Reports.REPORTS_FIRST_ROW_DELETE_BUTTON, "First Row Delete Button");
			
			//Delete the report request created
			click(Reports.REPORTS_FIRST_ROW_DELETE_BUTTON,"Delete Button");
			driver.switchTo().alert().accept();
			Thread.sleep(lSleep_VLow);
			//assertElementPresent(Reports.NO_RECORDS_FOUND_GRID_MSG, "No Records Found");
			
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}
