package com.arrow.workflows;

import org.openqa.selenium.NoSuchElementException;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_SOP_AutoAssignmentDashboard extends BusinessFunctions{

	
	/********************************************************************************************************
	 * Method Name : assignmentDashboard() 
	 * Author : Pradyumna 
	 * Description : This method will view assignment team Dashboard
	 * Date of creation : 11/26/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String assignmentDashboard(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			//Click on Auto Assignment Dashboard
			click(SOP.AUTO_ASSIGNMENT_DASHBOARD, "Auto Assignment Dashboard");
			assertElementPresent(SOP.AUTO_ASSIGNMENT_DASHBOARD_PAGE, "Auto Assignment Dashboard");
			//Enter Date
			type(Generic.TEXT_DATE,"11/25/2019","Text Date");
			
			click(SOP.GO_BUTTON, "Go Button");		
			assertElementPresent(SOP.TEAM_NAME_LINK, "Team Name Link");
			click(SOP.TEAM_NAME_LINK, "Team Link");		
			assertElementPresent(SOP.ASSIGNMENT_PROCESSOR_DASHBOARD_PAGE, "Assignment Processor Dashboard Page");
			click(Generic.REFRESH_BTN, "Refresh Button");		
			assertElementPresent(SOP.ASSIGNMENT_PROCESSOR_DASHBOARD_PAGE, "Assignment Processor Dashboard Page");
			click(SOP.SOP_COUNT_LINK, "SOP Count Link Button");		
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");	
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : loggedInUser() 
	 * Author : Pradyumna 
	 * Description : This method will view logged In User Dashboard
	 * Date of creation : 11/28/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String loggedInUser(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			//Click on Auto Assignment Dashboard
			click(SOP.AUTO_ASSIGNMENT_DASHBOARD, "Auto Assignment Dashboard");
			//Click on User Dashboard Link
			click(SOP.LOGGED_IN_USERS_LINK, "Logged in User Dashboard Link");
			assertElementPresent(SOP.LOGGED_IN_USERS_PAGE, "Logged in Users Dashboard Page");
			
			//Non-Prod does not have any Test data present. When Present will add in more verification part 
			click(Generic.REFRESH_BTN, "Refresh Button");		

	
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : assignmentByTier() 
	 * Author : Pradyumna 
	 * Description : This method will view "Assignment By Tier Dashboard" in Auto Assignment Dashboard
	 * Date of creation : 11/28/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String assignmentByTier(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			//Click on Auto Assignment Dashboard
			click(SOP.AUTO_ASSIGNMENT_DASHBOARD, "Auto Assignment Dashboard");
			//Click on Assignment Tier Dashboard
			click(SOP.ASSIGNMENT_TIER_DASHBOARD, "Assignment By Tier Dashboard Link");
			assertElementPresent(SOP.ASSIGNMENT_TIER_DASHBOARD_PAGE, "Auto Assignment Team and Tier Dashboard Page");
			
			type(Generic.TEXT_DATE,"10/23/2020","Text Date");
			
			click(SOP.GO_BUTTON, "Go Button");		
			assertElementPresent(SOP.TEAM_NAME_LINK, "Team Name Link");
			click(SOP.TEAM_NAME_LINK, "Team Link");		
			assertElementPresent(SOP.ASSIGNMENT_PROCESSOR_TIER_DASHBOARD_PAGE, "Assignment Processor and Tier Dashboard");
			//click(Generic.REFRESH_BTN, "Refresh Button");		
			//assertElementPresent(SOP.ASSIGNMENT_PROCESSOR_TIER_DASHBOARD_PAGE, "Assignment Processor and Tier Dashboard");
			click(Generic.BACK_BTN, "Back Button");	
			assertElementPresent(SOP.ASSIGNMENT_TIER_DASHBOARD_PAGE, "Auto Assignment Team and Tier Dashboard Page");
			click(SOP.SOP_COUNT_LINK, "SOP Count Link Button");		
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : userAvailabilityDashboard() 
	 * Author : Pradyumna 
	 * Description : This method will view "User Availability Dashboard" in Auto Assignment Dashboard
	 * Date of creation : 11/28/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String userAvailabilityDashboard(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			//Click on Auto Assignment Dashboard
			click(SOP.AUTO_ASSIGNMENT_DASHBOARD, "Auto Assignment Dashboard");
			//Click on User Availability Dashboard Link
			click(SOP.USER_AVAILABILITY_DASHBOARD, "User Availability Dashboard Link");
			assertElementPresent(SOP.USER_AVAILABILITY_DASHBOARD_PAGE, "User Availability Dashboard Page");
			//Enter Date and Select NY Team from Dropdown
			type(Generic.TEXT_DATE,"10/28/2020","Text Date");
			click(SOP.TEST_NY_TEAM_DRPDOWN, "Test NY Team Drop Down");	
			click(SOP.GO_BTN, "Go Button");		
			//Available Status should be displayed
			assertElementPresent(SOP.AVAILABLE_STATUS, "Available Status");
			click(Generic.CLEAR_BTN, "Clear Button");		
			assertElementPresent(SOP.NO_RECORDS_FOUND_ERR_MSG, "No Records Found Message");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	public void qualityRandomiserSetup(String reportSheet , int count) throws Throwable{
		
		String qualityLimit = 	Excelobject.getCellData(reportSheet, "Quality Limit", count);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");		
	    //QUALITY_MAINTENANCE
		waitForElementPresent(SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		assertElementPresent(SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		click(SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");		
		//QUALITY_RANDOMISER_SETUP
		waitForElementPresent(SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		assertElementPresent(SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		click(SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		//QUALITY_LIMIT_PER_DAY
		waitForElementPresent(SOP.QUALITY_LIMIT_PER_DAY, "Quality limit per day in left nav bar");
		assertElementPresent(SOP.QUALITY_LIMIT_PER_DAY, "Quality limit per day in left nav bar");
		type(SOP.QUALITY_LIMIT_PER_DAY,qualityLimit, "Quality limit per day in left nav bar");
		//SAVE_BTN
		click(SOP.SAVE_BTN, "Quality limit per day in left nav bar");
		
		if(Integer.valueOf(qualityLimit) >= 0) {
			
			String qualityLimitCountSet = SQL_Queries.criteriaLimitCount().get(0);
			compareStrings(qualityLimit,qualityLimitCountSet);
		}
		try {	
			driver.findElement(SOP.INVALID_LIMIT_ERROR);
			String error = getText(SOP.INVALID_LIMIT_ERROR, "Invalid Limit error message");
			compareStrings("Please provide valid Limit.",error);		
		}catch(NoSuchElementException e) {		
		}	
		
	}	

	
public void deleteTheSOPs(String reportSheet , int count) throws Throwable{
		
		String sopFrom = Excelobject.getCellData(reportSheet, "SOP From", count); 
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		
		if(sopFrom.equals("SOP > 15 days")) {
			//SOP_15DAYS_TAB
			waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			click(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");	
			
		}
		//FIRST_ESOP_ID_SELECTED		
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		String firstESOPId = getText(SOP.FIRST_ESOP_ID_SELECTED, "First Esop Id selected");
		waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		//DELETE_SOPS
		assertElementPresent(SOP.DELETE_SOPS, "Delete button is SOP List page");
		click(SOP.DELETE_SOPS, "Delete button in SOP List page");
		handlepopup();
		Thread.sleep(700);
		//Below validate the Data is not present in the tables for the esop
		String esopCountInCESInbox = SQL_Queries.getTheCountInSOPCesInbox(firstESOPId).get(0);
		String esopCountInESOPInbox = SQL_Queries.getTheCountInESOPInbox(firstESOPId).get(0);
		//getTheFieldsForTheESOPs		
        compareStrings("0",esopCountInCESInbox);
        compareStrings("0",esopCountInESOPInbox);
	}

public void rejectionRulesMaintenanceApplication(String reportSheet, int count) throws Throwable {
	try {
		
		String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
		String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);        
		String status = Excelobject.getCellData(reportSheet, "Status", count);
		String action = Excelobject.getCellData(reportSheet, "Action", count);		

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//REJECTION_RULE_MAINTENANCE_LINK
		waitForElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
		assertElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
		click(SOP.REJECTION_RULE_MAINTENANCE_LINK,"Rejection Rule Maintenance link in lft nav bar");
		//PAGE_TITLE
		waitForElementPresent(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
		assertElementPresent(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
		String pageTitle = getText(SOP.PAGE_TITLE,"Rejection Rule Maintenance Page Title");
		compareStrings("SOP Rejection Rules Maintenance",pageTitle);
		//US_RADIO_BTN
		waitForElementPresent(SOP.US_RADIO_BTN,"US Radio button");
		assertElementPresent(SOP.US_RADIO_BTN,"US Radio button");
		waitForElementPresent(SOP.US_LABEL,"US label");
		assertElementPresent(SOP.US_LABEL,"US label");
		//CANADA_RADIO_BTN
		waitForElementPresent(SOP.CANADA_RADIO_BTN,"Canada Radio button");
		assertElementPresent(SOP.CANADA_RADIO_BTN,"canada Radio button");	
		waitForElementPresent(SOP.CANADA_LABEL,"Canada label");
		assertElementPresent(SOP.CANADA_LABEL,"canada label");		
		waitForElementPresent(SOP.INTERNATIONAL_RADIO_BTN,"International Radio button");
		assertElementPresent(SOP.INTERNATIONAL_RADIO_BTN,"International Radio button");
		waitForElementPresent(SOP.INTERNATIONAL_LABEL,"International label");
		assertElementPresent(SOP.INTERNATIONAL_LABEL,"International label");
		//JURIS_DRP_DWN
		waitForElementPresent(SOP.JURIS_DRP_DWN,"Jurisdiction drop down");
		assertElementPresent(SOP.JURIS_DRP_DWN,"Jurisdiction drop down");
		//ADD_BUTTON
		waitForElementPresent(SOP.ADD_BUTTON,"Add button in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.ADD_BUTTON,"Add button in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.SORT_BY_JURISDICTION_LABEL,"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.SORT_BY_JURISDICTION_LABEL,"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.SORT_BY_MODIFIED_BY_LABEL,"Sort by Modified By in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.SORT_BY_MODIFIED_BY_LABEL,"Sort by Modified By in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.SORT_BY_MODIFIED_DATE_LABEL,"Sort by Modified Date in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.SORT_BY_MODIFIED_DATE_LABEL,"Sort by Modified Date in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.TABLE_HEADER_JURISDICTION,"Table header Jurisdiction in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.TABLE_HEADER_JURISDICTION,"Table header Jurisdiction in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.TABLE_HEADER_MODIFIED_BY,"Table header Modified By in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.TABLE_HEADER_MODIFIED_BY,"Table header Modified By in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.TABLE_HEADER_MODIFIED_DATE,"Table header Modified Date in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.TABLE_HEADER_MODIFIED_DATE,"Table header Modified Date in SOP Rejection Rules Maintenance");
		//FIRST_EDIT_BUTTON
		waitForElementPresent(SOP.FIRST_EDIT_BUTTON,"First Edit button in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.FIRST_EDIT_BUTTON,"First Edit button in SOP Rejection Rules Maintenance");
		click(SOP.FIRST_EDIT_BUTTON,"First Edit button in SOP Rejection Rules Maintenance");
		//REJECTION_RULE_DROP_DOWN
		waitForElementPresent(SOP.REJECTION_RULE_DROP_DOWN,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
		assertElementPresent(SOP.REJECTION_RULE_DROP_DOWN,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
		
		if(addEditOrDel.equals("Add")) {
			selectByVisibleText(SOP.REJECTION_RULE_DROP_DOWN,ruleText,"Rejection Rule in SOP Rejection Rules by Jurisdiction");
		}
		else if (addEditOrDel.equals("Edit")) {
		
			if(ruleText.equals("SOS/Arrow Entity Statuses")) {

			click(SOP.REJECTION_RULE1_FIRST_EDIT,"First Edit button in SOP Rejection Rules Maintenance");	
			}

			else if(ruleText.equals("Post Descriptive - Take or Reject")){

			click(SOP.REJECTION_RULE2_FIRST_EDIT,"First Edit button in SOP Rejection Rules Maintenance");	
			}
		}
		else if (addEditOrDel.equals("Delete")) {
		
			if(ruleText.equals("SOS/Arrow Entity Statuses")) {

			click(SOP.REJECTION_RULE1_FIRST_DELETE,"First Delete button in SOP Rejection Rules Maintenance");
			Thread.sleep(1000);
			handlepopup();
			}

			else if(ruleText.equals("Post Descriptive - Take or Reject")){

			click(SOP.REJECTION_RULE2_FIRST_DELETE,"First Delete button in SOP Rejection Rules Maintenance");
			Thread.sleep(1000);
			handlepopup();
			}
			
			
		}
		//STATUS_TEXT_FIELD
		waitForElementPresent(SOP.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.STATUS_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
		type(SOP.STATUS_TEXT_FIELD,status,"Status text field in SOP Rejection Rules Maintenance");
		waitForElementPresent(SOP.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
		assertElementPresent(SOP.ACTION_TEXT_FIELD,"Status text field in SOP Rejection Rules Maintenance");
		type(SOP.ACTION_TEXT_FIELD,action,"Status text field in SOP Rejection Rules Maintenance");
		if(addEditOrDel.equals("Add")) {
			click(SOP.ADD_BTN,"Add button in SOP Rejection Rules by Jurisdiction");
		}
		else if(addEditOrDel.equals("Edit")) {
			click(SOP.SAVE_BUTTON,"Save button in SOP Rejection Rules by Jurisdiction");	
		}
		
	}
	catch (Exception e) {
	}
 }


}

