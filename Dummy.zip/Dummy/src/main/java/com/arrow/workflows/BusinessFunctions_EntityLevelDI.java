package com.arrow.workflows;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.DI;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_EntityLevelDI extends BusinessFunctions_Entity {

	public void bulletinDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Check whether Bulletin edit btn,di source,options,delivery method,recipient
			// fields are present
			isElementPresent(DI.BULLETIN_EDIT_BTN, "Bulletin Edit Button");
			isElementPresent(DI.BULLETIN_DI_SOURCE_LABEL, "Bulletin DI Source Label");
			isElementPresent(DI.BULLETIN_OPTIONS_LABEL, "Bulletin Options Label");
			isElementPresent(DI.BULLETIN_DELIVERY_METHOD_LABEL, "Bulletin Delivery Method label");
			isElementPresent(DI.BULLETIN_RECIPIENT_LABEL, "Bulletin Recipient label");
			isElementPresent(DI.BULLETIN_RECIPIENT_NAME, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void communicationDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Check whether Communication edit btn,di source,delivery
			// method,icomm,recipient fields are present
			isElementPresent(DI.COMM_EDIT_BTN, "Communication Edit Button");
			isElementPresent(DI.COMM_DI_SOURCE_LABEL, "Communication DI Source Label");
			isElementPresent(DI.COMM_DELIVERY_METHOD_LABEL, "Communication Delivery Method label");
			isElementPresent(DI.COMM_ICOMM_LABEL, "Communication ICOMM label");
			isElementPresent(DI.COMM_RECIPIENT_LABEL, "Communication Recipient label");
			isElementPresent(DI.COMM_RECIPIENT_NAME, "Communication Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void renewalInvoiceDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Check whether Renewal Invoice edit btn,di source,Entity Name On Invoice
			// Address,auto renew,delivery method,recipient fields are present
			isElementPresent(DI.RENEWALINVOICE_EDIT_BTN, "Renewal Invoice Edit Button");
			isElementPresent(DI.RENEWALINVOICE_DI_SOURCE_LABEL, "Renewal Invoice  DI Source Label");
			isElementPresent(DI.RENEWALINVOICE_ENTITY_NAME_ON_INVOICE_ADDRESS_LABEL,
					"Entity Name On Invoice Address label");
			isElementPresent(DI.RENEWALINVOICE_DELIVERY_METHOD_LABEL, "Renewal Invoice Delivery method label");
			isElementPresent(DI.RENEWALINVOICE_AUTO_RENEW_LABEL, "Renewal Invoice Auto Renew label");
			isElementPresent(DI.RENEWALINVOICE_RECIPIENT_LABEL, "Renewal Invoice Recipient label");
			isElementPresent(DI.RENEWALINVOICE_RECIPIENT_NAME, "Renewal Invoice Recipient Name label");

		} catch (Exception e) {
			throw e;
		}

	}

	public void sopDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Check whether SOP edit btn,di source,lawsuit type,expand all and collapse all
			// link,deliverables,delivery method,recipient fields are present
			isElementPresent(DI.SOP_EDIT_BTN, "SOP Edit Button");
			isElementPresent(DI.SOP_DI_SOURCE_LABEL, "SOP  DI Source Label");
			isElementPresent(DI.SOP_LAWSUIT_TYPE, "SOP Lawsuit Type label");
			isElementPresent(DI.SOP_EXPAND_ALL_LINK, "SOP Expand All Link");
			isElementPresent(DI.SOP_COLLAPSE_ALL_LINK, "SOP Collapse All link");
			isElementPresent(DI.SOP_RECIPIENT_LABEL, "SOP Recipient label");
			isElementPresent(DI.SOP_RECIPIENT_NAME, "SOP Recipient Name");
			isElementPresent(DI.SOP_DELIVERABLES, "SOP papers with transmittal");
			isElementPresent(DI.SOP_DELIVERY_METHODS_LABEL, "SOP Delivery Methods label");

		} catch (Exception e) {
			throw e;
		}

	}

	public void xsopDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Check whether Bulletin edit btn,di source,delivery method,recipient fields
			// are present
			isElementPresent(DI.XSOP_EDIT_BTN, "XSOP Edit Button");
			isElementPresent(DI.XSOP_DI_SOURCE_LABEL, "XSOP  DI Source Label");
			isElementPresent(DI.XSOP_DELIVERY_METHOD_LABEL, "XSOP Delivery Method label");
			isElementPresent(DI.XSOP_RECIPIENT_LABEL, "XSOP Recipient label");
			isElementPresent(DI.XSOP_RECIPIENT_NAME, "XSOP Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void bulletinDIEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On Bulletin Edit Button
			click(DI.BULLETIN_EDIT_BTN, "Bulletin Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.BULLETIN_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void communicationEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On Communication Edit Button
			click(DI.COMM_EDIT_BTN, "Communication Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.COMM_RECIPIENT_NAME, participantName, "Communication DI Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void renewalInvoiceEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On Communication Edit Button
			click(DI.RENEWALINVOICE_EDIT_BTN, "Renewal Invoice DI Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.RENEWALINVOICE_RECIPIENT_NAME, participantName, "Renewal Invoice Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void xsopEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On Communication Edit Button
			click(DI.XSOP_EDIT_BTN, "Communication Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.XSOP_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void replaceMultipleDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click on Replace Multiple DI Button
			click(DI.REPLACE_MULTIPLE_DI_BTN, "Replace Multiple DI Btn");
			// Click On Select All Button
			click(DI.SELECT_ALL_BTN, "Select All Btn");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Replace button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.REPLACEBTN, "Replace button");
			// Handle Popup
			handlepopup();
			// Verify recipeints all DIs are changed
			assertTextMatching(DI.BULLETIN_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			assertTextMatching(DI.COMM_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			assertTextMatching(DI.RENEWALINVOICE_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			assertTextMatching(DI.SOP_RECIPIENT_NAME, participantName, "SOP Recipient Name");
			assertTextMatching(DI.XSOP_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void sopRecipientEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			// Click On Edit button on Edit SOP DI Page
			click(DI.SOP_RECIPIENT_EDIT_BTN, "Recipient Edit Btn");
			// Click On Delivery Actions Edit btn
			click(DI.DELIVERY_ACTIONS_EDIT_BTN, "Delivery Actions Edit Btn");
			// Select UPS 2nd Day Air from delivery method drpdwn
			click(DI.UPS_2ND_DAY_AIR, "UPS 2nd Day Air");
			// Click On Add to list button and click on preview changes button
			click(DI.ADD_TO_LIST_BTN, "Add to list btn");
			click(DI.PREVIEW_CHANGES_BTN, "Preview Changes Button");
			// Enter comments and click on save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comments Text Box");
			click(DI.SAVEBTN, "Save Button");
			// Verify whether the delivery method is changed
			assertElementPresent(DI.UPS_2ND_DAY_AIR_SOP_DELIVERY_METHODS, "Delivery Method Value");

		} catch (Exception e) {
			throw e;
		}

	}

	public void cancelbulletinDIEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			String recipientName = getText(DI.BULLETIN_RECIPIENT_NAME, "Recipient Name");
			// Click On Bulletin Edit Button
			click(DI.BULLETIN_EDIT_BTN, "Bulletin Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.CANCELBTN, "Cancel button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.BULLETIN_RECIPIENT_NAME, recipientName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void createCondition(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);
			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			// Click On Create Condition Button
			click(DI.CREATE_CONDITION_BTN, "Create Condition Button");
			// Select first value from special circumstances drpdwn
			selectByIndex(DI.SPECIAL_CIRUCMSTANCES_DRPDWN, 1,
					"Select first value from special circumstances drop down");
			// Select Levies from lawsuit type left selector
			click(DI.LAWSUIT_TYPE_LEFT_SELECTOR_LEVIES, "Select Levies from left selector of lawsuit");
			// Click on Move right button
			click(DI.LAWSUIT_TYPE_MOVE_RIGHT_BTN, "Lawsuit Type Move Right Button");
			// Select first value from lawsuit type dropdown
			selectByIndex(DI.LAWSUIT_SUBTYPE_DRPDWN, 1, "Lawsuit subtype drpdwn");
			// Click on right arrow of jurisdiction
			click(DI.JURISDICTION_RIGHT_ARROW, "Right Arrow of Jurisdiction");
			// Select state,country and sub country
			click(DI.STATE_ALABAMA, "Select Alabama as state");
			click(DI.COUNTRY_ALABAMA, "Select Alabama as country");
	//		selectByIndex(DI.SUB_COUNTRY, 1, "Select first value from sub country");
			// Click on Move right button
			click(DI.JURISDICTION_MOVE_RIGHT_BTN, "Jurisdiction Move Right Btn");
			// Select first country from city dropdwn
			selectByIndex(DI.CITY_DRPDWN, 1, "City DropDwn");
			// Click on right arrow of other
			click(DI.OTHER_RIGHT_ARROW, "Right Arrow of Other Field");
			// Enter Amount for Damage Amount Field,answer days and specfic condition
			type(DI.DAMAGE_AMOUNT_TEXT_FIELD, "40", "Damage Amount Text Box");
			type(DI.ANSWER_DATE_TEXTBOX, "10", "Answer Date TextBox");
			type(DI.SPECIFIC_CONDITION_TEXTBOX, "test", "Specific Condition TextBox");
			// Click on Manage Delivery Actions Button
			click(DI.MANAGE_DELIVERY_ACTIONS_BTN, "Manage Delivery Actions Button");
			// Select SOP Papers With Transmittal from Deliverable drpdwn
			click(DI.SOP_PAPERS_WITH_TRANSMITTAL, "Select SOP Papers With Transmittal from Deliverable drpdwn");
			// Click on recipient select button and select a recipient
			click(DI.RECIPIENT_SELECT_BTN, "Recipient Select button");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click on Add to list button and click on preview changes button
			click(DI.ADD_TO_LIST_BTN, "ADD to list Btn");
			click(DI.PREVIEW_CHANGES_BTN, "Preview Changes Button");
			waitForElementPresent(DI.DI_COMMENTS_TEXTBOX, "SOP DI Comments text box");
			// Enter comments and click on save btn
			type(DI.DI_COMMENTS_TEXTBOX, "TEST", "SOP DI Comments text box");
			click(DI.SAVEBTN, "Save Button");
			// Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			// Delete the Condition Generated
			click(DI.DELETEBTN, "Delete the generated condition");
			// handle popup
			handlepopup();
			waitForElementPresent(DI.DI_COMMENTS_TEXTBOX, "SOP DI Comments text box");
			// Enter comments and click on save btn
			type(DI.DI_COMMENTS_TEXTBOX, "TEST", "SOP DI Comments text box");
			click(DI.SAVEBTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void cancelCommunicationDIEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			String recipientName = getText(DI.COMM_RECIPIENT_NAME, "Recipient Name");

			// Click On Communciation Edit Button
			click(DI.COMM_EDIT_BTN, "Communication Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.CANCELBTN, "Cancel button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.COMM_RECIPIENT_NAME, recipientName, "Communciation Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void cancelRenewalInvoiceDIEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			String recipientName = getText(DI.RENEWALINVOICE_RECIPIENT_NAME, "Recipient Name");

			// Click On Renewal Invoice Edit Button
			click(DI.RENEWALINVOICE_EDIT_BTN, "Renewal Invoice Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.CANCELBTN, "Cancel button");

			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.RENEWALINVOICE_RECIPIENT_NAME, recipientName, "Renewal Invoice Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void cancelxsopDIEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			String recipientName = getText(DI.XSOP_RECIPIENT_NAME, "Recipient Name");

			// Click On XSOP Edit Button
			click(DI.XSOP_EDIT_BTN, "XSOP Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.CANCELBTN, "Cancel button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.XSOP_RECIPIENT_NAME, recipientName, "XSOP Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void formerDIs(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on DI History left nav link
			click(Entity.DI_HISTORY, "DI History Left Nav Link");
			// Verify title of the page is DI History
			assertTextMatching(DI.PAGE_TITLE, "DI History", "Title of the page");
			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");
			// Select Bulletin from second filter and click on Go Btn
			click(DI.BULLETIN_FILTER, "Select Bulletin from second filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");
			// Verify DI Type is Bulletin and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "Bulletin", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");
			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");
			// Select Communication from second filter and click on Go Btn
			click(DI.COMMUNICATION_FILTER, "Select Communication from second filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");
			// Verify DI Type is Communication and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "Communication", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");
			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");
			// Select Renewal from second filter and click on Go Btn
			click(DI.RENEWAL_FILTER, "Select Renewal from second filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");
			// Verify DI Type is Renewal and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "Renewal", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");
			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");
			// Select SOP from second filter and click on Go Btn
			click(DI.SOP_FILTER, "Select SOP from second filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");
			// Verify DI Type is SOP and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "SOP", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");
			// Select DI type from first filter
			click(DI.DI_TYPE_FILTER, "Select DI type from first filer");
			// Select XSOP from second filter and click on Go Btn
			click(DI.XSOP_FILTER, "Select XSOP from second filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			// Verify title of the page is Review Former DI
			assertTextMatching(DI.PAGE_TITLE, "Review Former DI", "Title of the page");
			// Verify DI Type is XSOP and click on Return to History Button
			assertTextMatching(DI.DI_TYPE, "XSOP", "DI Type");
			click(DI.RETURN_TO_HISTORY_BUTTON, "Return To History Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void entityTypeDISource(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");
			// Select Limited Liability Company from entity type drop down
			click(Entity.LLC_ENTITY_TYPE, "Select Limited Liability Company from entity type drop down");
			// Click on Save Btn
			click(Entity.SAVE_BTN, "Save Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Verify Entity Type On DI page is LLC
			assertTextMatching(DI.ENTITY_TYPE, "Limited Liability Company", "Entity Type on DI Page");
			// Click on Entity Profile left nav link
			click(Entity.ENTITY_PROFILE, "Entity Profile left nav link");
			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");
			// Select Limited Liability Partnership from entity type drop down
			click(Entity.LLP_ENTITY_TYPE, "Select Limited Liability Partnership from entity type drop down");
			// Click on Save Btn
			click(Entity.SAVE_BTN, "Save Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Verify Entity Type On DI page is LLP
			assertTextMatching(DI.ENTITY_TYPE, "Limited Liability Partnership", "Entity Type on DI Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void replaceDIForLPEntity(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");
			// Select Limited Partnership from entity type drop down
			click(Entity.LP_ENTITY_TYPE, "Select Limited Partnership from entity type drop down");
			// Click on Save Btn
			click(Entity.SAVE_BTN, "Save Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click on Replace Multiple DI Button
			click(DI.REPLACE_MULTIPLE_DI_BTN, "Replace Multiple DI Button");
			// Verify title of the page is Replace Delivery Instructions
			assertTextMatching(DI.PAGE_TITLE, "Replace Delivery Instructions", "Title Of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void commentsForRenewalInvoiceDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String comment = Excelobject.getCellData(ReportSheet, "Comment", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On Communication Edit Button
			click(DI.RENEWALINVOICE_EDIT_BTN, "Communication Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, comment, "Comment field");
			click(DI.SAVEBTN, "Save button");
			// click on DI History left nav link
			click(Entity.DI_HISTORY, "DI History Left Nav Link");
			// Verify comments are displayed on DI History Page
			assertTextMatching(DI.DI_HISTORY_COMMENT, comment, "Comment On DI History Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void cancelsopDIEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			String recipientName = getText(DI.SOP_DI_RECIPIENT_NAME, "Recipient Name");

			// Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			// Click On Edit button on Edit SOP DI Page
			click(DI.SOP_RECIPIENT_EDIT_BTN, "Recipient Edit Btn");
			// Click On Delivery Actions Edit btn
			click(DI.DELIVERY_ACTIONS_EDIT_BTN, "Delivery Actions Edit Btn");
			// Select UPS 2nd Day Air from delivery method drpdwn
			click(DI.UPS_2ND_DAY_AIR, "UPS 2nd Day Air");
			// Click On Add to list button and click on preview changes button
			click(DI.ADD_TO_LIST_BTN, "Add to list btn");
			click(DI.PREVIEW_CHANGES_BTN, "Preview Changes Button");
			// Enter comments and click on save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comments Text Box");
			click(DI.CANCELBTN, "Cancel Button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.SOP_DI_RECIPIENT_NAME, recipientName, "SOP Recipient Name");

		} catch (Exception e) {
			throw e;
		}
	}

	//
	public void editSOPDIConditions(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// Create Entity
			createEntity(ReportSheet, count);
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			assertElementPresent(DI.EDIT_SOP_DI_PAGE, "Edit SOP DI Page");
			// Click On Edit button on Edit SOP DI Page
			click(DI.EDIT_IMG_BTN, "Recipient Edit Btn");
			// Delete Default Condition already present
			click(DI.SOP_DELETE_IMG, "Delete Already Present One");
			// handle popup
			handlepopup();
			// Select UPS 2nd Day Air from delivery method drpdwn
			click(DI.SELECT_SOP_TRANSMITTAL, "Select SOP Papers with Transmittal");
			click(DI.RECIPIENT_SELECT_BTN, "Select Recipient");
			assertElementPresent(DI.DI_RECIPIENT_PAGE, "DI Recipient Page");
			type(DI.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Included");
			click(DI.FINDBTN, "Find Button");
			assertElementPresent(DI.SELECT_RECIPIENT_PAGE, "Select Recipient Page");
			click(DI.SELECTRECIPIENTBTN, "Select Recipient");
			assertElementPresent(DI.MANAGE_DELIVERY_ACTIONS_PAGE, "Select Recipient Page");
			// Click On Add to list button and click on preview changes button
			click(DI.ADD_TO_LIST_BTN, "Add to list btn");
			click(DI.PREVIEW_CHANGES_BTN, "Preview Changes Button");
			assertElementPresent(DI.EDIT_SOP_DI_PAGE, "Edit SOP DI Page");
			// Enter comments and click on save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comments Text Box");
			click(DI.SAVEBTN, "Save Button");
			assertElementPresent(DI.DI_PAGE, "Edit SOP DI Page");
			// Navigate to DI History Tab
			click(DI.DI_HISTORY_TAB, "DI History Tab");
			click(DI.DI_TYPE_FILTER, "DI Type Filter");
			click(DI.SOP_FILTER, "SOP Filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			assertElementPresent(DI.DI_HISTORY_PAGE, "DI History Page");
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			assertElementPresent(DI.REVIEW_FORMER_DI_PAGE, "Review Former DI Page");

		} catch (Exception e) {
			throw e;
		}

	}

	// User logs Views DI History List for an Affiliated entity with regular rep
	public void editAffiliatedDIConditions(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String affName = Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
			// Create Entity
			createEntity(ReportSheet, count);

			// Click on Join Affiliation Button
			click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
			assertElementPresent(DI.FIND_AFFILIATION_TO_JOIN_PAGE, "Find Affiation to Join Page");
			// Enter an Affiliation Name and click on Find Button
			type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
			click(Entity.FINDBTN, "Find Btn");
			assertElementPresent(DI.PICK_AFFILIATION_TO_JOIN_PAGE, "Pick Affiation to Join Page");
			// Click on First result from the grid
			click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
			assertElementPresent(DI.CONFIRM_JOINING_AFFILIATION, "Confirm Joining Affiation");
			// Complete the process for joining affiliation
			click(Entity.BULLETINRETAINCURRENTDI, "Bulletin Retain Current DI Button");
			click(Entity.COMMRETAINCURRENTDI, "Communication Retain Current DI Button");
			click(Entity.RENEWALINVOICERETAINCURRENTDI, "Renewal Invoice Retain Current DI Button");
			click(Entity.SOPRETAINCURRENTDI, "SOP 	Retain Current DI Button");
			selectByIndex(Entity.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
			type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, "comments", "Comments");
			click(Entity.JOINBTN, "Join Button");
			assertElementPresent(DI.ENTITY_PROFILE, "Entity Profile");
			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			assertElementPresent(DI.EDIT_SOP_DI_PAGE, "Edit SOP DI Page");
			// Click On Edit button on Edit SOP DI Page
			click(DI.EDIT_IMG_BTN, "Recipient Edit Btn");
			// Delete Default Condition already present
			click(DI.SOP_DELETE_IMG, "Delete Already Present One");
			// handle popup
			handlepopup();
			// Select UPS 2nd Day Air from delivery method drpdwn
			click(DI.SELECT_SOP_TRANSMITTAL, "Select SOP Papers with Transmittal");
			click(DI.RECIPIENT_SELECT_BTN, "Select Recipient");
			assertElementPresent(DI.DI_RECIPIENT_PAGE, "DI Recipient Page");
			type(DI.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Included");
			click(DI.FINDBTN, "Find Button");
			assertElementPresent(DI.SELECT_RECIPIENT_PAGE, "Select Recipient Page");
			click(DI.SELECTRECIPIENTBTN, "Select Recipient");
			assertElementPresent(DI.MANAGE_DELIVERY_ACTIONS_PAGE, "Select Recipient Page");
			// Click On Add to list button and click on preview changes button
			click(DI.ADD_TO_LIST_BTN, "Add to list btn");
			click(DI.PREVIEW_CHANGES_BTN, "Preview Changes Button");
			assertElementPresent(DI.EDIT_SOP_DI_PAGE, "Edit SOP DI Page");
			// Enter comments and click on save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comments Text Box");
			click(DI.SAVEBTN, "Save Button");
			assertElementPresent(DI.DI_PAGE, "Edit SOP DI Page");
			// Navigate to DI History Tab
			click(DI.DI_HISTORY_TAB, "DI History Tab");
			click(DI.DI_TYPE_FILTER, "DI Type Filter");
			click(DI.SOP_FILTER, "SOP Filter");
			click(DI.GO_BTN, "Go Button");
			// Click on first view button on the grid
			assertElementPresent(DI.DI_HISTORY_PAGE, "DI History Page");
			click(DI.FIRST_VIEW_BTN_ON_GRID, "First View Button On Grid");
			assertElementPresent(DI.REVIEW_FORMER_DI_PAGE, "Review Former DI Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void manageEntityMonitoringCOMMDI(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// Create Entity
			createEntity(ReportSheet, count);


			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Click on Manage Entity Monitoring Notification Recipients
			click(Entity.MANAGE_ENTITY_MONITORING_NOTIFICATION_RECIPIENTS,
					"Manage Entity Monitoring Notification Recipients");

			//Thread.sleep(4000);
			//String parentWindow = driver.getWindowHandle();
			driver.switchTo().frame(0);
			Thread.sleep(150);

			assertTextMatching(Entity.PAGE_TITLE, "Manage Entity Monitoring Notification Recipient(s)", "Page Title");

			// Add Recipient
			click(Entity.ADD_RECIPIENTS_BTN, "Add Recipients Btn");
			type(Entity.PARTICIPANT_NAME_SEARCH_TEXTBOX, "Chuck Meyer", "Participant Name Search textbox");
			click(Entity.SEARCH_BTN, "Search Button");
			waitForElementPresent(Entity.PARTICIPANT_NAME_CHECKBOX, "Participant Name Checkbox");
			click(Entity.PARTICIPANT_NAME_CHECKBOX, "Participant Name Checkbox");
			click(Entity.SELECT_PARTICIPANTS_BTN, "Select Participants Button");

			click(Entity.TURN_OFF_NOTIFICATION_BTN, "Turn Off Notification to COMM DI Recipient Button");
			handlepopup();
			click(Entity.REMOVE_BTN, "Remove Button");
			handlepopup();
			Thread.sleep(1000);
			//assertElementPresent(Entity.NOTIFICATION_ERROR,"Notification Error");
			assertTextMatching(Entity.NOTIFICATION_ERROR, "Turn-on notification to COMM DI recipient before removing all the recipients.", "Notification Error");
			click(Entity.TURN_ON_NOTIFICATION_BTN, "Turn On Notification to COMM DI Recipient Button");
			handlepopup();
			click(Entity.REMOVE_BTN, "Remove Button");
			handlepopup();
			Thread.sleep(2000);
			assertTextMatching(Entity.NO_RECORDS_FOUND_TEXT, "No records found.", "No Records Found Text");
			//waitForElementPresent(Entity.NO_RECORDS_FOUND_TEXT, "No Records Found Text");
			//assertElementPresent(Entity.NO_RECORDS_FOUND_TEXT, "No Records Found Text");
			//driver.close();
			//driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}

	}
	public void searchForTheEntity(String entityId) throws Throwable {

		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		type(Entity.ENTITY_ID, entityId , "Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");

	}
	public String getTheActiveStandaloneEntity() {
		ArrayList<String> entityId  =  new ArrayList<String>();
		try {

			entityId = SQL_Queries.getTheActiveStandaloneEntity();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityId.get(0);
	}
	public void editTheRenewalDIToPaperLessDeliveryMethod() throws Throwable{

		waitForElementToBeClickable(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instruction link in left nav bar");
		click(Entity.DELIVERY_INSTRUCTIONS, "Click on Delivery Instruction Link in left nav bar");
		//RENEWAL_EDIT_BUTTON
		waitForElementPresent(Entity.RENEWAL_EDIT_BUTTON, "Edit button for Renewal Invoice in Delivery Instruction Page");
		assertElementPresent(Entity.RENEWAL_EDIT_BUTTON, "Edit button for Renewal Invoice in Delivery Instruction Page");
		click(Entity.RENEWAL_EDIT_BUTTON, "Click on Edit button for Renewal Invoice in Delivery Instruction Page");
		//DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT
		waitForElementPresent(Entity.DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT, "Select button for recipient under Delivery Instruction in Edit DI Page");
		assertElementPresent(Entity.DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT, "Select button for recipient under Delivery Instruction in Edit DI Page");
		click(Entity.DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT, "Click on Select button for recipient under Delivery Instruction in Edit DI Page");
		//PARTICIPANTNAMEFIELD
		waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
		assertElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
		type(Entity.PARTICIPANTNAMEFIELD,"CHERYL TURLEY", "Participant text field in Find DI Recipient Page");
		//FINDBTN
		assertElementPresent(Entity.FINDBTN, "Find Button in Find DI Recipient Page");
		click(Entity.FINDBTN, "Click on Find Button in Find DI Recipient Page");
		//SELECTRECIPIENTBTN
		assertElementPresent(Entity.SELECTRECIPIENTBTN, "Select button for recipient under Delivery Instruction in Edit DI Page");
		click(Entity.SELECTRECIPIENTBTN, "Click on Select button for recipient under Delivery Instruction in Edit DI Page");
		//AUTO_RENEW_RADIO_BUTTON
		waitForElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
		assertElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
		click(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
		
		//COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION
		assertElementPresent(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, "Comments text box for Renewal Invoice in Delivery Instruction Page");
		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION,"Test", "Comments text box for Renewal Invoice in Delivery Instruction Page");
		//SAVE_BTN
		assertElementPresent(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
		click(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
		try {
			List<WebElement> deliveryInstructions = driver.findElements(Entity.DELIVERY_INSTRUCTIONS);
			if(deliveryInstructions.size() > 0) {
				waitForElementToBeClickable(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instruction link in left nav bar");
				click(Entity.DELIVERY_INSTRUCTIONS, "Click on Delivery Instruction Link in left nav bar");
			}
		}catch(NoSuchElementException e) {}
		//RENEWAL_DI_DELIVERY_METHOD
		waitForElementPresent(Entity.RENEWAL_DI_DELIVERY_METHOD, "Delivery Method text");
		assertElementPresent(Entity.RENEWAL_DI_DELIVERY_METHOD, "Delivery Method text in Delivery Instruction Page");
		assertTextMatching(Entity.RENEWAL_DI_DELIVERY_METHOD,"Paperless", "Delivery Method text in Delivery Instruction Page");

	}
}
