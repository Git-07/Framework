package com.arrow.workflows;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CRM extends BusinessFunctions {

	/********************************************************************************************************
	 * Method Name : createSopIncidentReport() Author : Pradyumna Description : This
	 * method will create New SOP Incident Reports Date of creation : 9/10/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String createSopIncidentReport(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets link to get log ID
			click(HomePage.MY_WORKSHEET_LINK, "SOP Link TAB");
			String logID = getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			click(CRM.CREATE_BUTTON, "Create Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
			click(CRM.SOP_INCIDENT_REPORT, "Select SOP Incident Report from Dropdown");
			String parentWindow = driver.getWindowHandle();
			click(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			handlePopUpWindwow();
			assertElementPresent(CRM.WORKSHEET_SEARCH_POPUP, "Worksheet Search Popup");
			type(CRM.ENTER_LOGID, logID, "Log ID Entered");
			click(CRM.LOGID_SEARCH_BUTTON, "Log ID Search Button");
			click(Generic.SELECT, "Select Button");
			// driver.close();
			driver.switchTo().window(parentWindow);
			click(CRM.ERROR_TYPE, "Error Type");
			click(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.SERVICE_LEVEL, "Service Level");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : viewRequestID() Author : Pradyumna Description : This method
	 * will create New SOP Incident Reports Date of creation : 9/10/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String viewRequestID(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on CRM link to view Request ID
			String requestID = Excelobject.getCellData(ReportSheet, "RequestID", count);
			click(HomePage.CRM_LINK, "CRM Link TAB");
			type(CRM.REQUESTID, requestID, "Request ID Entered");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(CRM.REQUEST_LIST_PAGE, "Request List Page");
			click(Generic.EDIT_BUTTON, "First Request ID link");
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.COMPLETED_STATUS, "Completed Status");
			String parentWindow = driver.getWindowHandle();
			click(CRM.VIEW_HISTORY, "View History");
			handlePopUpWindwow();
			assertElementPresent(CRM.REQUEST_HISTORY, "Request History Popup");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : createRequestForCustomer() Author : Pradyumna Description :
	 * This method will create New Request with Customer Selected Date of creation :
	 * 9/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String createRequestForCustomer(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String customerName = Excelobject.getCellData(ReportSheet, "CustomerName", count);
			String participantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			click(CRM.CREATE_BUTTON, "Create Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
			click(CRM.SERVICE_TYPE, "Select Auto Renew Setup from Dropdown");
			click(CRM.CST_SEARCH_LINK, "Customer Search Link");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			type(Customer.CUSTOMER_NAME_SEARCH, customerName, "Customer Name");
			click(Customer.SEARCH, "Search Button");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.PARTICIPANT_LOOKUP, "Participant Lookup Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			type(Customer.NAME_SEARCH, participantName, "Participant Name");
			click(Customer.SEARCH, "Search Button");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.EMAIL_WHEN_COMPLETE_CHECKBOX, "Email when complete checkbox");
			waitForElementPresent(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.SERVICE_LEVEL_OPTION, "Service Level");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : createRequestForEntity() Author : Pradyumna Description : This
	 * method will create New Request with Entity Selected Date of creation :
	 * 9/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String createRequestForEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);
			String participantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			click(CRM.CREATE_BUTTON, "Create Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
			click(CRM.SERVICE_TYPE, "Select Auto Renew Setup from Dropdown");
			click(CRM.ENTITY_SEARCH_LINK, "Entity Search Link");
			type(Entity.ENTITY_NAME, entityName, "Entity Name Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.PARTICIPANT_LOOKUP, "Participant Lookup Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			type(Customer.NAME_SEARCH, participantName, "Participant Name");
			click(Customer.SEARCH, "Search Button");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.EMAIL_WHEN_COMPLETE_CHECKBOX, "Email when complete checkbox");
			waitForElementPresent(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.SERVICE_LEVEL_OPTION, "Service Level");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : createRequestForAffiliation() Author : Pradyumna Description :
	 * This method will create New Request with Affiliation Selected Date of
	 * creation : 9/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String createRequestForAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationName = Excelobject.getCellData(ReportSheet, "AffiliationName", count);
			String participantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			click(CRM.CREATE_BUTTON, "Create Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
			click(CRM.SERVICE_TYPE, "Select Auto Renew Setup from Dropdown");
			click(CRM.AFFILIATION_SEARCH_LINK, "Affiliation Search Link");
			type(Affiliation.AFFILIATIONNAME, affiliationName, "Affiliation Name Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			click(CRM.AFFILIATION_SELECT, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.PARTICIPANT_LOOKUP, "Participant Lookup Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			type(Customer.NAME_SEARCH, participantName, "Participant Name");
			click(Customer.SEARCH, "Search Button");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.EMAIL_WHEN_COMPLETE_CHECKBOX, "Email when complete checkbox");
			waitForElementPresent(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.SERVICE_LEVEL_OPTION, "Service Level");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Button");
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : createRequestForNonCT() Author : Pradyumna Description : This
	 * method will create New Request with Non-CT Name Text Date of creation :
	 * 9/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String createRequestForNonCT(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String participantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			click(CRM.CREATE_BUTTON, "Create Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
			click(CRM.SERVICE_TYPE, "Select Auto Renew Setup from Dropdown");
			click(CRM.NONCT_SEARCH_LINK, "Non CT Search Link");
			type(CRM.NAME_TEXT_BOX, "Name Entered For Testing", "Name Text box");
			click(CRM.PARTICIPANT_LOOKUP, "Participant Lookup Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			type(Customer.NAME_SEARCH, participantName, "Participant Name");
			click(Customer.SEARCH, "Search Button");
			click(Generic.SELECT_BUTTON, "Select Button");
			assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
			click(CRM.EMAIL_WHEN_COMPLETE_CHECKBOX, "Email when complete checkbox");
			waitForElementPresent(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.REQUESTED_VIA, "Requested Via");
			click(CRM.SERVICE_LEVEL_OPTION, "Service Level");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
			assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : CustomerReportedIncidentReview() Author : Pradyumna Description
	 * : This method will review Customer Incident Review Date of creation :
	 * 9/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CustomerReportedIncidentReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets Link
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			click(CRM.MY_WORKSHEETS_TO_REVIEW_TAB, "My Worksheets to Review tab");
			click(CRM.CLEAR_BTN,"Clear Button");
			click(CRM.REVIEW_TYPE_DROPDOWN, "Review Type Dropdown");
			click(CRM.CUSTOMER_INCIDENT_REPORT_DROPDOWN, "Customer Incident Report Dropdown");
			click(Generic.GO_BUTTON, "Go button");
			String logID = getText(CRM.FIRST_SOP_TO_REVIEW, "First SOP ID");
			click(CRM.FIRST_SOP_TO_REVIEW, "First SOP ID");
			//assertElementPresent(CRM.REVIEW_PAGE, "Review Page");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			if (verifyIfElementPresent(CRM.REVIEW_SUB_TYPE, "Review Sub-Type")) {
				click(CRM.REVIEW_SUB_TYPE_OPTION, "Review Sub-Type Option");
			}
			if (verifyIfElementPresent(SOP.DEFENDANT_TEXTFIELD, "Check Defendant Name")) {
				type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			}
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementToBePresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			click(CRM.MY_WORKSHEETS_TO_REVIEW_TAB, "My Worksheets to Review tab");
			// click(Generic.CLEAR_BUTTON, "Clear Button");
			click(CRM.LOG_ID, "Log ID");
			click(Generic.EQUAL, "Equal");
			type(Generic.DROP_DOWN_TEXT, logID, "Enter LogID");
			click(Generic.GO_BUTTON, "Go Button");
			assertElementPresent(Generic.NO_RECORDS_FOUND2, "No Records Found");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : MyTeamsIncidentReview() Author : Pradyumna Description : This
	 * method will review my Team's Customer Incident Review Date of creation :
	 * 9/16/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String MyTeamsIncidentReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheets Link
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			click(CRM.MY_TEAMS_WORKSHEET_TO_REVIEW_TAB, "My Team's Worksheets to Review tab");
			click(CRM.CLEAR_BTN,"Clear Button");
			click(CRM.REVIEW_TYPE_DROPDOWN, "Review Type Dropdown");
			click(CRM.CUSTOMER_INCIDENT_REPORT_DROPDOWN, "Customer Incident Report Dropdown");
			click(Generic.GO_BUTTON, "Go button");
			String logID = getText(CRM.TEAMS_FIRST_SOP_TO_REVIEW, "First SOP ID");
			click(CRM.TEAMS_FIRST_SOP_TO_REVIEW, "First SOP ID");
			//assertElementPresent(CRM.REVIEW_PAGE, "Review Page");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			if (verifyIfElementPresent(CRM.REVIEW_SUB_TYPE, "Review Sub-Type")) {
				click(CRM.REVIEW_SUB_TYPE_OPTION, "Review Sub-Type Option");
			}
			if (verifyIfElementPresent(SOP.DEFENDANT_TEXTFIELD, "Check Defendant Name")) {
				type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			}
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementToBePresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			click(CRM.MY_TEAMS_WORKSHEET_TO_REVIEW_TAB, "My Team's Worksheets to Review tab");
			// click(Generic.CLEAR_BUTTON, "Clear Button");
			click(CRM.LOG_ID, "Log ID");
			click(Generic.EQUAL, "Equal");
			type(Generic.DROP_DOWN_TEXT, logID, "Enter LogID");
			click(Generic.GO_BUTTON, "Go Button");
			assertElementPresent(Generic.NO_RECORDS_FOUND2, "No Records Found");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void addDeleteEmailText(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.EMAIL_TEXT_MAINTANANCE_LEFT_NAV_LINK, "Email Text Maintanance left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "Manage Email Text", "Page Title");

			// Add value
			type(CRM.VALUE_TEXTBOX, "Automation Testing", "Value Textbox");
			click(CRM.ADD_UPDATE_BTN, "Add Update Button");

			// Delete Value from grid
			click(CRM.FIRST_DELETE_BTN, "Delete Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void enableDisableDataOnAdminstration(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.ADMINISTRATION_LEFT_NAV_LINK, "Administration left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "Administration", "Page Title");
			if (verifyIfElementPresent(CRM.FIRST_DISABLE_BTN_ON_GRID, "First Disable Button on grid")) {
				click(CRM.FIRST_DISABLE_BTN_ON_GRID, "First Disable Button on grid");
				handlepopup();
				waitForElementPresent(CRM.FIRST_ENABLE_BTN_ON_GRID, "First Enable Button on grid");
				assertElementPresent(CRM.FIRST_ENABLE_BTN_ON_GRID, "First Enable Button on grid");
				click(CRM.FIRST_ENABLE_BTN_ON_GRID, "First Enable Button on grid");
				handlepopup();
			} else if (verifyIfElementPresent(CRM.FIRST_ENABLE_BTN_ON_GRID, "First Enable Button on grid")) {
				click(CRM.FIRST_ENABLE_BTN_ON_GRID, "First Enable Button on grid");
				handlepopup();
				waitForElementPresent(CRM.FIRST_DISABLE_BTN_ON_GRID, "First Disable Button on grid");
				assertElementPresent(CRM.FIRST_DISABLE_BTN_ON_GRID, "First Disable Button on grid");
				click(CRM.FIRST_DISABLE_BTN_ON_GRID, "First Disable Button on grid");
				handlepopup();
			}

		} catch (Exception e) {
			throw e;
		}

	}

	
	
	public void reportsCoreAssignment(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.REPORTS_CORE_ASSIGNMENT_LEFT_NAV_LINK, "Reports Core Assignment left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "CORE Assignment", "Page Title");

			// Generate Report for region
			// click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
		} catch (Exception e) {
			throw e;
		}

	}

		public void verifyRSSLink(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			waitForElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			
			//Click on RSS Button
			click(CRM.RSS_BTN,"RSS Button");
			elementIsNotPresent(CRM.SERVER_ERROR, "Server Error Text");

			
		} catch (Exception e) {
			throw e;
		}

	}


}
