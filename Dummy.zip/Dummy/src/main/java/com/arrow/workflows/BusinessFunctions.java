package com.arrow.workflows;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.accelerators.ActionEngine;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Login;
import com.arrow.objectrepo.SopHub;

public class BusinessFunctions extends ActionEngine {
	
	/********************************************************************************************************
	 * Method Name : signIn() 
	 * Author : Description : This method will Log into the ARROW Application using default selected Team and Member 
	 * Date of modification : 8th Feb 2019
	 * @throws Throwable
	 ********************************************************************************************************/
	
	public void SignIn(String strTeam,String strMember) throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			//Commenting below line and  adding another wait to encounter the login failures, we will monitor if sign in failures are not occuring
			//if(waitForVisibilityOfElementWithoutReport(Login.LOGINBTN, "Login button")) {
			if(waitForElementToBePresent(Login.LOGINBTN, "Login button")) {
				SuccessReport("Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				selectByVisibleText(Login.TEAMDROPDOWN, strTeam, "Team Dropdown");
				selectByVisibleText(Login.MEMBERDROPDOWN, strMember, "Member Dropdown");
				click(Login.LOGINBTN, "Log In button");
			}else {
				failureReport("Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementToBePresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport("Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport("Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method 	Name		:	catchBlock()
	 * Author				:	Vrushali Kakade
	 * Description			:	This method will catch the Exception
	 * Date of creation 	:	
	 * modifying person 	: 	
	 * Date of modification	: 
	 * @throws Throwable	:
	 ********************************************************************************************************/
	public  void catchBlock(Exception e) throws Throwable{
		if(e.getMessage() != null)
			parent.appendChild(child);
			gStrErrMsg=e.getMessage();
			closeSummaryReport(browsertype);
			driver.quit();
			openBrowser();
			Thread.sleep(lSleep_VLow);
		
		
	}
	
	public void SignInFromSOPSupportTeam() throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			//if(waitForVisibilityOfElementWithoutReport(Login.LOGINBTN, "Login button")) {
			if(waitForElementToBePresent(Login.LOGINBTN, "Login button")) {
				SuccessReport("Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				click(Login.TEAM_DROPDOWN, "Team Dropdown");
				click(Login.MEMBER_DROPDOWN, "Member Dropdown");
				click(Login.LOGINBTN, "Log In button");
			}else {
				failureReport("Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementToBePresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport("Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport("Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}
	
	public void loginToSOPHub(String userName,String password, String firstName ,String lastName) throws Throwable {
		try {
			blnEventReport = true;
			if(waitForElementToBePresent(Login.USER_NAME, "User name")) {
				SuccessReport("Validate whether User is navigated to SOP Hub Login Page", "User Is succesfully navigated to SOP Hub Login Page");
				type(Login.USER_NAME, userName, "User name");
				Thread.sleep(300);
				selectBySendkeys(Login.PASSWORD, password, "Pass word");
				click(Login.LOGIN, "Log In button");
				Thread.sleep(300);
			}else {
				failureReport("Validate whether User is navigated to SOP Hub Login Page", "Failed to Navigate to SOP hub Login Page");
			}
			
			waitForElementToBePresent(Login.INDIVIDUAL_FIRST_NAME, "Individuals First Name");						
			type(Login.INDIVIDUAL_FIRST_NAME,firstName, "Individuals First Name");			
			Thread.sleep(300);
			waitForElementToBePresent(Login.INDIVIDUAL_LAST_NAME, "Individuals Last Name");
			type(Login.INDIVIDUAL_LAST_NAME,lastName, "Individuals Last Name");
			Thread.sleep(300);
			waitForElementToBePresent(Login.SEARCH, "Search button");
			click(Login.SEARCH, "Search button");
			Thread.sleep(300);
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}
	
	public void loginToSOPHubWithCustomer(String userName,String password,
			String firstName ,String lastName,String customer) throws Throwable {
		try {
			//blnEventReport = true;
			//if(waitForElementPresent(Login.USER_NAME, "User name")) {
			Thread.sleep(1200);
			waitForElementPresent(Login.USER_NAME, "User name");
				//SuccessReport("Validate whether User is navigated to SOP Hub Login Page", "User Is succesfully navigated to SOP Hub Login Page");			
			type(Login.USER_NAME, userName, "User name");
			Thread.sleep(300);
			waitForElementPresent(Login.PASSWORD, "Password");			
			type(Login.PASSWORD, password, "Pass word");
			Thread.sleep(300);
			waitForElementPresent(Login.LOGIN, "Log In button");
			click(Login.LOGIN, "Log In button");
			Thread.sleep(300);
			waitForElementPresent(Login.INDIVIDUAL_FIRST_NAME, "Individuals First Name");						
			type(Login.INDIVIDUAL_FIRST_NAME,firstName, "Individuals First Name");			
			Thread.sleep(300);
			waitForElementPresent(Login.INDIVIDUAL_LAST_NAME, "Individuals Last Name");
			type(Login.INDIVIDUAL_LAST_NAME,lastName, "Individuals Last Name");
			Thread.sleep(300);
			//CUSTOMER_NAME_TEXT_BOX
			waitForElementPresent(Login.CUSTOMER_NAME_TEXT_BOX, "Customer Name");
			type(Login.CUSTOMER_NAME_TEXT_BOX,customer, "Customer Name");
			Thread.sleep(300);
			waitForElementPresent(Login.SEARCH, "Search button");
			click(Login.SEARCH, "Search button");
			Thread.sleep(300);			
		} catch (Exception e) {			
			throw e;
		}
	}
	
	public void logoutFromSopHub() throws Throwable {
		try {
			//blnEventReport = true;
			//if(waitForElementPresent(Login.WK_ICON, "WK icon")) {
				//SuccessReport("Validate whether User is already logged to SOP Hub ", "User Is already logged to SOP Hub");
			Thread.sleep(900);
			waitForElementPresent(Login.WK_ICON, "WK icon");	
			click(Login.WK_ICON, "WK icon");
			Thread.sleep(300);
			waitForElementPresent(Login.LOG_OUT, "Log out button");
			assertElementPresent(Login.LOG_OUT, "Log out button");
			click(Login.LOG_OUT, "Log out button");
			Thread.sleep(300);
				//CONFIRM_LOG_OUT
			waitForElementPresent(Login.CONFIRM_LOG_OUT, "Confirm Log out button");
			assertElementPresent(Login.CONFIRM_LOG_OUT, "Confirm Log out button");
			click(Login.CONFIRM_LOG_OUT, "confirm Log out button");
			Thread.sleep(300);
		} catch (Exception e) {			
			
		}
	}

	public void SignInFromLevel1() throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			if(waitForVisibilityOfElementWithoutReport(Login.LOGINBTN, "Login button")) {
				SuccessReport("Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				click(Login.TEAM_DROPDOWN, "Team Dropdown");
				click(Login.LEVEL1_MEMBER_DROPDOWN, "Member Dropdown");
				click(Login.LOGINBTN, "Log In button");
			}else {
				failureReport("Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport("Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport("Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}

	public void SignInFromLevel2() throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			if(waitForVisibilityOfElementWithoutReport(Login.LOGINBTN, "Login button")) {
				SuccessReport("Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				click(Login.TEAM_DROPDOWN, "Team Dropdown");
				click(Login.LEVEL2_MEMBER_DROPDOWN, "Member Dropdown");
				click(Login.LOGINBTN, "Log In button");
			}else {
				failureReport("Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport("Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport("Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}
	
	public void SignInFromGlobalOperationsTeamIndia() throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			if(waitForVisibilityOfElementWithoutReport(Login.LOGINBTN, "Login button")) {
				SuccessReport("Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				click(Login.GLOBAL_TEAM_DROPDOWN, "Team Dropdown");
				click(Login.GLOBAL_MEMBER_DROPDOWN, "Member Dropdown");
				click(Login.LOGINBTN, "Log In button");
			}else {
				failureReport("Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport("Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport("Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}
	
	public void SignInFromAlabamaCTReps() throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			if(waitForVisibilityOfElementWithoutReport(Login.LOGINBTN, "Login button")) {
				SuccessReport("Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				click(Login.ALABAMA_TEAM_DROPDOWN, "Team Dropdown");
				click(Login.ALABAMA_MEMBER_DROPDOWN, "Member Dropdown");
				click(Login.LOGINBTN, "Log In button");
			}else {
				failureReport("Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport("Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport("Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}
	
	public void worksheetInSOPHub(String reportSheet, int count) throws Throwable {
		
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		String worksheetId = null;
	    
		if(workflow.equals("151004")) {
		
			worksheetId = Excelobject.getCellData(reportSheet, "OptimizedManual Log", count);
		}
		else if(workflow.equals("151001")) {
			
			worksheetId = Excelobject.getCellData(reportSheet, "Full Log", count);
			
		}
		//SELECT
		waitForElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
		assertElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
		click(SopHub.SELECT, "Select button in Customer Search Page");
		//SOP_HUB_LINK
		waitForElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
		assertElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
		click(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
		for(int i = 0; i<10; i++) {
		//LOG_SEARCH_TEXT_FIELD
		waitForElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");
		assertElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");		
		type(SopHub.LOG_SEARCH_TEXT_FIELD,worksheetId, "Log Search test field in SOP Received Page");
		//SEARCH_BUTTON
		waitForElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
		assertElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
		click(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");	
		WebElement noSuchWorksheet = null;
		try {
			
			noSuchWorksheet = driver.findElement(By.xpath("//span[contains(text(),'There are no entries in this list.')]"));
			//HOME_BUTTON
			assertElementPresent(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
			click(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
			
		}catch(NoSuchElementException e) {
			
		}	
		if(noSuchWorksheet != null) {
		 
			Thread.sleep(5000);
		}
		else {
			break;
		}
	  }
		//CT_LOG_NUMBER
		waitForElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
		assertElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
		compareStrings(worksheetId,getText(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub"));
	}
}
