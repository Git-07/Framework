package com.arrow.workflows;

import org.openqa.selenium.By;

import com.arrow.objectrepo.ActionItemsFailure;
import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.USOP;
import com.arrow.objectrepo.WorksheetCreate;

import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

public class BusinessFunctions_SOP_ActionItem extends BusinessFunctions_CommonCESAndWorksheet {

	public String editAndDeleteActionItems(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet ID", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			waitForElementPresent(ActionItems_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			// Click On Choose DI Button
			click(ActionItems_SOP.CHOOSE_DI_BTN, "Choose DI Button");
			waitForElementPresent(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			// Click on Actions List Btn and then click on Mangage Actions List Button
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			// Select Copy of Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN, "Deliverable DropDown");
			// Select hand delivered by ct from Delivery Method Drpdown
			click(ActionItems_SOP.HAND_DELIVERED_BY_CT_DELIVERY_METHOD_DRPDWN, "Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name
			type(ActionItems_SOP.PARTICIPANTNAMEFIELD, participantName, "Participant Name Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
			// Verify Edit and delete btns are available
			isElementPresent(ActionItems_SOP.ACTION_ITEM_EDIT_BUTTON, "Action Item Edit Btn");
			isElementPresent(ActionItems_SOP.ACTION_ITEM_DELETE_BUTTON, "Action Item Delete Btn");
			// Click On Delete Btn
			click(ActionItems_SOP.ACTION_ITEM_DELETE_BUTTON, "Action Item Delete Btn");
			// Add Internal Comments
			type(ActionItems_SOP.INTERNAL_COMMENTS_TEXTBOX, "Test", "Text Field for Internal Comments");
			click(ActionItems_SOP.DELETE_ACTION_ITEM_BTN, "Delete Action Item Btn");

			waitForElementPresent(Carrier_SOP.COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN, "Deliverable DropDown");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String noDeleteButton(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			/*// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");
			// Enter an entity name and click on search btn
			type(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "apple", "Entity Name Text Field");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			// Select entity from the grid
			click(Carrier_SOP.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity On Grid");
			// Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(Carrier_SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,
					"Create Quicklog/Attempted/Rejection/Multiple Button");*/
			// Create a Worksheet
			//createWorksheet(ReportSheet, count);
			
			// Create a Worksheet
		    viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			waitForElementPresent(ActionItems_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			// Click On Choose DI Button
			click(ActionItems_SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// Click on Actions List Btn and then click on Mangage Actions List Button
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			// Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN, "Deliverable DropDown");
			// Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(ActionItems_SOP.FED_EX_PRIORITY_OVERNIGHT_DELIVERY_METHOD_DRPDWN, "Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name
			type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
			// Verify delete btn is not available
			isElementNotPresent(ActionItems_SOP.ACTION_ITEM_DELETE_BUTTON, "Action Item Delete Btn");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String noRecipientInfoForISOP(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet ID", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			waitForElementPresent(ActionItems_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			// Click On Choose DI Button
			click(ActionItems_SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// Click on Actions List Btn and then click on Mangage Actions List Button
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			// Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN, "Deliverable DropDown");
			// Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(ActionItems_SOP.ISOP_DELIVERY_METHOD_DRPDWN, "Delivery Method Dropdown");
			// Click On select Button of Recipient
			isElementNotPresent(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String viewTransmittal(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet ID", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			waitForElementPresent(ActionItems_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			// Click On Choose DI Button
			click(ActionItems_SOP.ACTION_ITEMS_TAB, "Action Items");
			click(ActionItems_SOP.TRANSMITTAL_BUTTON, "Transmittal Button");
			// View Tranmittal PDF
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			// assertElementPresent(ActionItems_SOP.PDF_TOOLBAR, "PDF ToolBar");
			elementIsNotPresent(ActionItems_SOP.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name: executeEmailSOP() Author : Sweety Description : This method will
	 * execute Email Action Item Date of creation :12/09/2020 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String executeEmailSOP(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			/*// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");
			// Enter an entity name and click on search btn
			type(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "apple", "Entity Name Text Field");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			// Select entity from the grid
			click(Carrier_SOP.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity On Grid");
			// Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(Carrier_SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,
					"Create Quicklog/Attempted/Rejection/Multiple Button");*/
			viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			// Create a Worksheet
			//createWorksheet(ReportSheet, count);
			waitForElementPresent(ActionItems_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			// Click On Action Items Tab
			click(ActionItems_SOP.ACTION_ITEMS_TAB, "Action Items");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			// Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN, "Deliverable DropDown");
			// Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(ActionItems_SOP.AIRBORNE_DELIVERY_METHOD_DRPDWN, "Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name
			type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");

			// Select Copy of Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN, "Deliverable DropDown");
			// Select hand delivered by ct from Delivery Method Drpdown
			click(ActionItems_SOP.EMAIL_DROPDOWN, "Email Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name - You may need to change the participant name next
			// time
			selectBySendkeys(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
			// type(ActionItems_SOP.PARTICIPANTNAMEFIELD, participantName, "Participant Name
			// Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			assertElementPresent(ActionItems_SOP.RECIPIENT_EMAIL_ID_CHECK, "Check Email ID of Recipient");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Action List Btn");
			assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");

			click(ActionItems_SOP.EXECUTE_BTN, "Execute Airborne Action Item");
			assertElementPresent(ActionItems_SOP.AIRBORNE_ACTION_ITEM_STATUS,
					"Verify the status of Airborne Action Item is changed to Executed");
			click(ActionItems_SOP.POST_LOG_BTN, "Post Log Btn");

			click(ActionItems_SOP.EXECUTE_BTN, "Execute Email Action Item");
			assertElementPresent(ActionItems_SOP.EMAIL_ACTION_ITEM_STATUS_PENDING,
					"Verify the status of Email Action Item is changed to Pending");

			TimeUnit.MINUTES.sleep(8);
			refreshPage();

			assertElementPresent(ActionItems_SOP.EMAIL_ACTION_ITEM_STATUS_PROCESSED,
					"Verify the status of Email Action Item is changed to Processed");
			assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : executeISOP() Author : Pradyumna Description : This method will
	 * verify execute Copy of Transmittal in Action Items Date of creation :
	 * 8/14/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String executeISOP(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet ID", count);
			// String participantName = Excelobject.getCellData(ReportSheet, "Participant
			// Name", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click On Action Items Tab
			click(ActionItems_SOP.ACTION_ITEMS_TAB, "Action Items");
			assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
			if (isElementPresent(ActionItems_SOP.ISOP_UNEXECUTED_STATUS, "Unexecuted Status")) {
				click(ActionItems_SOP.ISOP_EXECUTE_BTN, "Execute Btn");
				assertElementPresent(ActionItems_SOP.SCAN_PAPERS_AND_TRANSMITTAL, "Scan papers and Transmittal");
				click(ActionItems_SOP.CONTINUE_BTN, "Continue Btn");
				assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
				assertElementPresent(ActionItems_SOP.ISOP_PENDING_STATUS, "ISOP Pending Status");
				click(ActionItems_SOP.ISOP_UNEXECUTE_BTN, "Unexecute Button");
				type(ActionItems_SOP.UNEXECUTE_COMMENTS, "Comments", "Comments Entered");
				click(ActionItems_SOP.UNEXECUTE_ACTION_ITEM_BTN, "Unexecute Action Item Button");
				assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
				assertElementPresent(ActionItems_SOP.ISOP_UNEXECUTED_STATUS, "Unexecuted Status");
			} else {
				click(ActionItems_SOP.ISOP_UNEXECUTE_BTN, "Unexecute Button");
				type(ActionItems_SOP.UNEXECUTE_COMMENTS, "Comments", "Comments Entered");
				click(ActionItems_SOP.UNEXECUTE_ACTION_ITEM_BTN, "Unexecute Action Item Button");
				assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : myActionItems() Author : Pradyumna Description : This method
	 * will verify myAction Items tab Date of creation : 8/27/2019 modifying person
	 * : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String myActionItems(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(HomePage.MY_ACTIONS_ITEMS, "My Action Items Link");
			assertElementPresent(ActionItems_SOP.ACTION_ITEMS_PAGE, "Action Items Page");
			assertElementPresent(ActionItems_SOP.MY_ACTION_ITEMS_TAB, "My Actions Tab");
			// Click On Action Items Tab
			String logID = getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log #");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, logID, "Log ID");
			click(Generic.GO_BUTTON, "Go Button");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : myTeamsActionItem() Author : Pradyumna Description : This
	 * method will verify my Teams Action Items tab Date of creation : 8/27/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String myTeamsActionItem(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(HomePage.MY_ACTIONS_ITEMS, "My Action Items Link");
			assertElementPresent(ActionItems_SOP.ACTION_ITEMS_PAGE, "Action Items Page");
			click(ActionItems_SOP.MY_TEAMS_ACTION_TAB, "My Teams Action Items Tab");
			// assertElementPresent(ActionItems_SOP.MY_TEAMS_ACTION_TAB, "My Teams Actions
			// Tab");
			// Click On Action Items Tab
			String logID = getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log #");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, logID, "Log ID");
			click(Generic.GO_BUTTON, "Go Button");
			click(WorksheetCreate.FIRST_SOP_DATA, "First Result");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

public void actionItemFailuresUI() throws Throwable {
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
        //ACTION_ITEM_FAILURES
		waitForElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		assertElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		click(ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		//ACTION_ITEM_FAILURE_PAGE_TITLE
		waitForElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title");
		assertElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title");
		compareStrings("Action Item Failures", getText(ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title"));
		//SORT_BY
		waitForElementPresent(ActionItemsFailure.SORT_BY, "Sort By label");
		assertElementPresent(ActionItemsFailure.SORT_BY, "Sort By label");
		//RECEIVED_DATE_SORT
		waitForElementPresent(ActionItemsFailure.RECEIVED_DATE_SORT, "Received Date sort link");
		assertElementPresent(ActionItemsFailure.RECEIVED_DATE_SORT, "Received Date sort link");
		//ERROR_REASON_SORT
		waitForElementPresent(ActionItemsFailure.ERROR_REASON_SORT, "Error reason sort link");
		assertElementPresent(ActionItemsFailure.ERROR_REASON_SORT, "Error reason sort link");
		//ASSIGNED_TO_SORT
		waitForElementPresent(ActionItemsFailure.ASSIGNED_TO_SORT, "Assigned to sort link");
		assertElementPresent(ActionItemsFailure.ASSIGNED_TO_SORT, "Assigned to sort link");
		//BRANCH_PLANT_SORT
		waitForElementPresent(ActionItemsFailure.BRANCH_PLANT_SORT, "Branch Plant sort link");
		assertElementPresent(ActionItemsFailure.BRANCH_PLANT_SORT, "Branch Plant sort link");
		//EXPORT_BUTTON
		waitForElementPresent(ActionItemsFailure.EXPORT_BUTTON, "Export button in Action Items failure page");
		assertElementPresent(ActionItemsFailure.EXPORT_BUTTON, "Export button in Action Items failure page");
		//HELP_PAGE_ICON
		waitForElementPresent(ActionItemsFailure.HELP_PAGE_ICON, "Help Page icon in Action Item Failures page");
		assertElementPresent(ActionItemsFailure.HELP_PAGE_ICON, "Help Page icon in Action Item Failures page");
		//CURRENT_FILTER
		waitForElementPresent(ActionItemsFailure.CURRENT_FILTER, "Current filter label in Action Item Failures page");
		assertElementPresent(ActionItemsFailure.HELP_PAGE_ICON, "current filter label  in Action Item Failures page");
		//Below one more check needs to be added for 
		
		
	}

	
}
