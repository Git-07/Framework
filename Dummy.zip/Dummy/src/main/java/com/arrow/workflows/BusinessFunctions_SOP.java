package com.arrow.workflows;

import org.openqa.selenium.By;

import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP extends BusinessFunctions_Entity {

	/********************************************************************************************************
	 * Method Name : catchBlock() Author : Vrushali Kakade Description : This method
	 * will catch the Exception Date of creation : modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void catchBlock(Exception e) throws Throwable {
		if (e.getMessage() != null)
			parent.appendChild(child);
		gStrErrMsg = e.getMessage();
		closeSummaryReport(browsertype);
		driver.quit();
		openBrowser();
		Thread.sleep(lSleep_VLow);

	}
	
	

	/********************************************************************************************************
	 * Method Name : ViewPartnersPage() Author : Vrushali Kakade Description : This
	 * method will search for SOP using by applying file name filter Date of
	 * creation : 6/28/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void searchSOPUsingFileName(String strFileName, String filterDD2Value) throws Throwable {
		try {
			blnEventReport = true;
			// click on Clear button of filter
			click(SOP.CLEARBTN, "Clear Button of filter");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// select value 'Confirmation Number' in filter dropdown 1 and '=' in dropdown 2
			selectByVisibleText(SOP.FILTERDROPDOWN1, "File Name", "Filter Dropdown 1");
			selectByVisibleText(SOP.FILTERDROPDOWN2, filterDD2Value, "Filter Dropdown 2");

			// Enter confirmation number in filter text box and hit Go button
			type(SOP.FILTERTEXTFIELD, strFileName, "Filter text field");
			click(SOP.FILTERGOBTN, "Go button of filter");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

		} catch (Exception e) {
			throw e;
		}
	}
	
	public void searchWorksheet(String worksheetId) throws Throwable {
		try {
			blnEventReport = true;
			//Click On Worksheet Search Link from left nav bar
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK,"Worksheet Search On Left Nav Link");
			click(SOP.CLASSIC_SEARCH_BTN,"Classic Search Button");
			waitForElementPresent(SOP.SEARCH_BTN, "Search Button");
			
			//Enter an entity Id to be searched and click on search btn
			type(SOP.WORKSHEET_ID_TEXTBOX,worksheetId,"Workhseet Id text Box");
			click(SOP.WORKSHEET_SEARCH_BTN,"Worksheet Search Btn");
						
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	
	public void editEntityOnWorksheetEditPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On Worksheet Edit Btn
			click(SOP.WORKSHEET_EDIT_BTN,"Worksheet Edit Btn");			
			//Click On Select Btn for Entity Field
			click(SOP.SELECT_ENTITY_BTN,"Select Entity Btn");			
			//Select an Entity
			type(SOP.ENTITY_NAME_TEXTFIELD,"apple","Entity Name Text Field");
			click(SOP.SEARCH_BTN,"Search Btn");
			click(SOP.SELECT_FIRST_ENTITY_ON_GRID,"Select First Entity On Grid");			
			//Click On Save Btn
			click(SOP.TOP_SAVE_BTN,"Save Btn");
			
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void errorMessageOnEntityEdit() throws Throwable {
		try {
			blnEventReport = true;
			String message = "This SOP has been transmitted to the customer via the Expedited SOP Feed and you cannot edit the Entity. Please contact your manager.";
			
			//Click On Worksheet Edit Btn
			click(SOP.WORKSHEET_EDIT_BTN,"Worksheet Edit Btn");		
			//Click On Select Btn for Entity Field
			click(SOP.SELECT_ENTITY_BTN,"Select Entity Btn");			
			//Verify error msg is displayed
			assertTextMatching(SOP.ERROR_MSG_ON_ENTITY_EDIT, message, message);
			
		} catch (Exception e) {
			throw e;
		}
	}

	public void createWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Create Worksheet Page 1
			selectBySendkeys(Carrier_SOP.METHOD_OF_SERVICE, "Fax", "Method Of Service");
			waitForElementPresent(Carrier_SOP.TIME_TEXTFIELD,"Text Field for Time");
			selectBySendkeys(Carrier_SOP.TIME_TEXTFIELD,"12:00","Text Field for Time");
			click(Carrier_SOP.INITIAL_RADIOBTN, "Initiatl Radio Button");
			click(Carrier_SOP.CASE_NUMBER_NONE_RADIOBTN, "Initial Radio Button");
			click(Carrier_SOP.PLAINTIFF_NONE_RADIOBTN, "Plaintiff Radio Button");
			type(Carrier_SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", " Defendant/Creditor Name");
			click(Carrier_SOP.NEXT_BTN, "Next Button");			
			// On Create Worksheet Step 2
			click(Carrier_SOP.COURT_NONE_RADIOBTN, "Court Radio Button");
			click(Carrier_SOP.NEXT_BTN, "Next Button");		
			// On Create Worksheet Step 3
			type(Carrier_SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(Carrier_SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "LawSuitType Drpdwn");
			click(Carrier_SOP.ANSWER_NONE_RADIOBTN, "Answer Radio Button");
			click(Carrier_SOP.SAVE_BTN, "Save Button");
			
			
		} catch (Exception e) {
			throw e;
		}
		
	}
	
}