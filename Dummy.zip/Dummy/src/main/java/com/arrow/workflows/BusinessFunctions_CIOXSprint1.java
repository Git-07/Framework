package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CIOXSprint1 extends BusinessFunctions {

	public String createWorksheetViaSOPList(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			searchForESOPId(esopId);
			try {
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOPId(esopId);
			} catch (NoSuchElementException e) {
			}
			Thread.sleep(5000);
			selectAndThenAssignTheFileToTeam();
			Thread.sleep(5000);
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOPId(esopId);
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");
			click(SOP.VIEW_BTN, "View button");
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(3000);
			WebElement createWs = null;
			try {
				createWs = driver.findElement(SOP.CREATE_WORKSHEET);
				waitForElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			} catch (NoSuchElementException e) {
			}
			if (createWs == null) {
				Thread.sleep(4000);
				selectAndThenAssignTheFileToTeam();
				Thread.sleep(4000);
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOPId(esopId);
				Thread.sleep(2000);
				String parentWin = driver.getWindowHandle();
				waitForElementPresent(SOP.VIEW_BTN, "View button");
				assertElementPresent(SOP.VIEW_BTN, "View button");
				click(SOP.VIEW_BTN, "View button");
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void searchForESOPId(String esopId) throws Throwable {

		waitForElementPresent(SOP.FILTER_DROPDOWN1, "Filter drop down");
		click(SOP.FILTER_DROPDOWN1, "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");

	}

	public void selectAndThenAssignTheFileToTeam() throws Throwable {

		waitForElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		assertElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		click(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign button");
		click(SOP.ASSIGN_BTN, "Assign button");
		Thread.sleep(1000);
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		click(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		Thread.sleep(1000);

	}

	public String entityDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			if (!levelOfUser.equals("Level1")) {
				if (cesQueue.equals("New")) {
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");
					click(SOP.FILTERGOBTN, "Go Button");
					Thread.sleep(1000);
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");
					click(SOP.FILTERGOBTN, "Go Button");

					try {
						WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
						waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(SOP.CLEARBTN, "Clear Button");
						click(SOP.CLEARBTN, "Clear Button");
						waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
						assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
						selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
						waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
						waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
						assertElementPresent(SOP.FILTERGOBTN, "Go Button");
						click(SOP.FILTERGOBTN, "Go Button");
						Thread.sleep(1000);
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					Thread.sleep(1000);
					waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
					waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

					// enter entity name in Entity Search page and click on Search button
					type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
					click(SOP.SEARCH_BTN, "Search button");
					Thread.sleep(5000);
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");

					// click on 1st entity of the search result, click on Home icon
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");
					Thread.sleep(5000);
					waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

					// Enter log id in log text field
					type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
					click(SOP.SEARCH_BTN, "Search button");
					Thread.sleep(4000);

					// Click on Unrelated worksheet
					click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
					waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

					// Select Lawsuit Type,enter Plaintiff and Defendant data and click on Submit
					// button
					selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
					selectBySendkeys(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text added");
					selectBySendkeys(SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text added");
					click(SOP.SUBMITBTN, "Submit Button");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return esopId.split("\\: ")[1];
	}

	public String verifyNOAfieldstMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --", "Amount $", "Breach of Contract",
					"Breach of Contract -", "Class Action -", "Continue withholding the nonexempt earnings of the...",
					"Continuing lien is extended until", "Default Judgment", "Hearing has been scheduled",
					"Lien - Amount $", "Motion for Summary Final Judgment of Foreclosure", "Notice of hearing",
					"Order of continuing lien", "Pertaining to", "Product Name: VIN:", "Release of Garnishment",
					"Request for status of Garnishment previously serve...",
					"Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation",
					"Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {

				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());
				}
				compareTwoArrayList(updatedNOAList, originalNOAList);
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyNOAWorksheetCreate(String reportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				verifyNOAfieldstMethod(reportSheet, count);
				click(Generic.CANCEL_BUTTON, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			} else {
				System.out.println("No Nature of Action Field present on Create Worksheet Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyNOAWorksheetEdit(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL_BUTTON, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			click(Generic.CANCEL_BUTTON, "Cancel Btn");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Review Worksheet
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_BUTTON, "Review Worksheet");
			click(WorksheetCreate.REVIEW_WORKSHEET_BUTTON, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL_BUTTON, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public void UICreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;
			assertElementPresent(SOP.HELP_PAGE_ICON, "Help Page Icon");
			assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON, "Save Incomplete Button");
			assertElementPresent(SOP.BAD_LOG_FIELD, "Bad Log Field");
			assertElementPresent(SOP.BAD_LOG_CHECKBOX, "Bad Log Checkbox");
			assertElementPresent(SOP.WORKSHEET_TYPE_FIELD, "Worskheet Type Field");
			String WorksheetType = getText(SOP.WORKSHEET_TYPE, "WOrksheet Type");
			if (WorksheetType.equals("DSSOP")) {
				assertElementPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				assertElementPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				assertElementPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN, "Direct Served Process Method of Service Dropdown");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_DATE ,"Direct Served Process Received Date");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_TIME, "Direct Served Process Received Time");
				assertElementPresent(SOP.CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION, "Customer Comments CDSOP Only Section");
				assertElementPresent(SOP.CUSTOMER_COMMENTS_BOX, "Customer Comments Box");

			

			} else {
				isElementNotPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				isElementNotPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				isElementNotPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN, "Direct Served Process Method of Service Dropdown");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_DATE ,"Direct Served Process Received Date");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_TIME, "Direct Served Process Received Time");
				isElementNotPresent(SOP.CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION, "Customer Comments CDSOP Only Section");
				isElementNotPresent(SOP.CUSTOMER_COMMENTS_BOX, "Customer Comments Box");

			}
			
			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_TEAM, "Received By Team Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_MEMBER_DPDOWN, "Received By Member Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Received By Collapsable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_TEAM_DPDOWN, "Assigned To Team Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_MEMBER_DPDOWN, "Assigned To Member Dropdown");
			assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Yes Radio Button");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.INITIAL_RADIOBTN, "Inintial/Subsequent Field");
			assertElementPresent(SOP.CONSOLIDATED_YES_RADIO_BUTTON, "Consolidated Field");
			assertElementPresent(SOP.BANKRUPTCY_YES_RADIO_BUTTON, "Bankruptcy Field");
			assertElementPresent(SOP.LETTER_YES_RADIO_BUTTON, "Letter Field");
			assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			assertElementPresent(SOP.TARGET_DETAILS_SECTION, "Target details Section");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.REJECT_DETAILS_SECTION, "Reject details Section");
			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason Dropdown");
			assertElementPresent(SOP.REJECT_DATE, "Reject Date");
			assertElementPresent(SOP.COURT_DETAILS_SECTION, "Court details Section");
			assertElementPresent(SOP.COURT_NONE_RADIOBTN, "Court None Specified Radio button");
			assertElementPresent(SOP.AGENCY_DETAILS_SECTION, "Agency details Section");
			assertElementPresent(SOP.AGENCY_NONE_RADIOBTN, "Agency None Specified Radio button");
			assertElementPresent(SOP.ATTORNEY_DETAILS_SECTION, "Attorney details Section");
			assertElementPresent(SOP.ATTORNEY_NONE_RADIOBTN, "Attorney None Specified Radio button");
			assertElementPresent(SOP.COURT_HELP_ICON, "Court Help Icon");
			assertElementPresent(SOP.CUSTOMER_PARTICIPANT_SEARCHBTN, "Customer/Participant Search Button");
			assertElementPresent(SOP.ATTORNEY_DETAILS_SECTION, "Attorney details Section");

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					assertElementPresent(SOP.LAWSUIT_TYPE_DROPDOWN,"Lawsuit Type Dropdown");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				
				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					assertElementPresent(SOP.LAWSUIT_TYPE_DROPDOWN,"Lawsuit Type Dropdown");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
			}
			
			assertElementPresent(SOP.AMOUNT_DUE_DRPDWN, "Amount Due Dropdown");
			assertElementPresent(SOP.ANSWER_NONE_RADIOBTN, "Answer Date Field");
			assertElementPresent(SOP.REMARKS_SECTION, "Remarks Section");
			assertElementPresent(SOP.REMARKS_DRPDWN, "Remarks dropdown");
			assertElementPresent(SOP.COMMENTS_SECTION, "Comments Section");
			assertElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Dropdown");
			
			assertElementPresent(SOP.BOTTOM_CANCELBTN, "Cancel Button at Buttom");
			assertElementPresent(SOP.BOTTOM_SAVEBTN, "Save Button at Buttom");
			assertElementPresent(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Buttom");
			assertElementPresent(SOP.WIREFRAME_NUMBER, "Wireframe Number");
			assertElementPresent(SOP.BOTTOM_MODULE_LINK, "Module links at bottom of the page");

			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Send Message Button");
			isElementNotPresent(SOP.NEXT_BTN, "Next Button");
			isElementNotPresent(SOP.PREV_BTN, "Previous Button");
		
		} catch (Exception e) {
			throw e;
		}
	
	}

	public String verifyUIofCreateWorksheetPage(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_HEADER, "Create Worksheet", "Header of the page");
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			assertElementPresent(SOP.PDF_ICONBTN, "PDF Icon");
			UICreateEditReviewWorksheetPage();

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
