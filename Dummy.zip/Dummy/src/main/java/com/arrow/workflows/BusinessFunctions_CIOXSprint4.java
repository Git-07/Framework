package com.arrow.workflows;

import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;

public class BusinessFunctions_CIOXSprint4 extends BusinessFunctions_CIOXSprint2 {

	public String multipleFieldVerification(String pageTitle, String flagShip) throws Throwable {
		String flag = "false";

		try {
			if (pageTitle.equals("SOP Worksheet Profile")) {
				if (verifyIfElementPresent(SOP.MULTIPLE_YES_FIELD, "Multiple Yes Field")) {
					assertElementPresent(SOP.MULTIPLE_FIELD_ON_WORKSHEET_PROFILE,
							"Mutiple fields on Worksheet Profile Page");
					flag = "true";
					return flag;
				} else {
					isElementNotPresent(SOP.MULTIPLE_YES_FIELD, "Multiple Yes Field");
				}
			} else if (pageTitle.equals("Edit Worksheet") || pageTitle.equals("Review Worksheet")) {
				if(flagShip.equalsIgnoreCase("1")) {
					if (verifyIfElementPresent(SOP.MULTIPLE_YES_RADIO_BTN_SELECTED, "Multiple Yes Radio Button Selected")) {
						assertElementPresent(SOP.DISABLED_CASE_ID_TEXTBOX, "Disabled Case Id Textbox");
						assertElementPresent(SOP.DISABLED_PLAINTIFF_DEBTOR_TEXTBOX, "Disabled Plaintiff/Debtor Textbox");
						assertElementPresent(SOP.CASE_SORTING_GRID, "Case Sorting Grid");
						isElementNotPresent(SOP.ADDUPDATELIST_BTN, "Add Update List Button");
						isElementNotPresent(SOP.CLEAR_BTN, "Clear Button");
						isElementNotPresent(SOP.GRID_EDIT_BTN, "Edit Button");
						isElementNotPresent(SOP.GRID_DELETE_BTN, "Delete Button");
						assertElementPresent(SOP.CREATE_SEPARATE_TRANSMITTAL_PER_CASE_CHECKBOX,
								"Disabled Create Separate Transmittal Per case checkbox");
						click(SOP.MULTIPLE_FIELD_NO_RADIO_BTN, "Multiple Field Radio Button");
						assertElementPresent(SOP.CASE_ID_NONE_SPECIFIED, "Case Id None Specified Radio Button");
						isElementNotPresent(SOP.CREATE_SEPARATE_TRANSMITTAL_PER_CASE_CHECKBOX,
								"Disabled Create Separate Transmittal Per case checkbox");
						isElementNotPresent(SOP.CASE_SORTING_GRID, "Case Sorting Grid");
						click(SOP.CONSOLIDATED_YES_RADIO_BTN, "Consolidated Radio Button as Yes");
						type(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX, "test", "Consolidated Defendant Textbox");
						selectByIndex(SOP.REMARKS_DRPDWN, 1, "Remarks dropdown");
						click(SOP.BOTTOM_SAVEBTN, "Save Button");
						waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Edit Worksheet Title");
						assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile Title");
						isElementNotPresent(SOP.MULTIPLE_YES_FIELD, "Multiple Yes Field");

					}
				}
				else {
					isElementNotPresent(SOP.MULTIPLE_FIELD_ON_WORKSHEET_PROFILE,
							"Mutiple fields on Worksheet Profile Page");

				}

			} else {
				isElementNotPresent(SOP.MULTIPLE_FIELD, "Multiple Field");
				isElementNotPresent(SOP.MULTIPLE_FIELD_YES_RADIO_BTN, "Multiple Field Yes Radio Button");
				isElementNotPresent(SOP.MULTIPLE_FIELD_NO_RADIO_BTN, "Multiple Field No Radio Button");

			}
			return flag;
		}

		catch (Exception e) {
			throw e;
		}
	}

	public void priorityFieldVerification(String pageTitle) throws Throwable {

		try {
			if (pageTitle.equals("Worksheet Profile")) {
				isElementNotPresent(SOP.PRIORITY_FIELD_ON_WORKSHEET_PRO_PAGE,
						"Priority Field on Worksheet Profile Page");

			} else {
				isElementNotPresent(SOP.PRIORITY_FIELD_DRPDWN, "Priority Field Dropdown");
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyMultipleFieldOnCreateWorksheetPage(String ReportSheet, int count, String esopId)
			throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			
			multipleFieldVerification(PageTitle, "0");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFieldOnCreateWorksheetPage(String ReportSheet, int count, String esopId)
			throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			
			priorityFieldVerification(PageTitle);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMultipleFieldOnEditandWorksheetProfilePage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			String flag = multipleFieldVerification(PageTitle, "0");

			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			if (flag.equalsIgnoreCase("true")) {
				PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
				multipleFieldVerification(PageTitle,"1");
			}
			else if(flag.equalsIgnoreCase("false")){
				PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
				multipleFieldVerification(PageTitle,"0");
			}
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFieldOnEditandWorksheetProfilePage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			
			priorityFieldVerification(PageTitle);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyWorksheetPopUpPageForWorksheetType(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			String WorksheetType = getText(SOP.WORKSHEET_TYPE, "WOrksheet Type");
			if (WorksheetType.equals("DSSOP")) {
				assertElementPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				assertElementPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				assertElementPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");

			} else {
				isElementNotPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				isElementNotPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				isElementNotPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");

			}
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMessageTextOnSOPPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.NEW_MESSAGE_HEADER, "You have new messages");
			isElementNotPresent(SOP.NEW_MESSAGE_HEADER, "Your team has new messages");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNewMessagesLeftNavLink(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.MY_MESSAGES, "My Messages Left Nav Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetCreate(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Top Send Message Button");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetEdit(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Top Send Message Button");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			//Verify Review Worksheet Page
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Top Send Message Button");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMessageOnSOPList(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.SEND_MESSAGE_ON_SOP_LIST, "Send Message Btn on SOP List Pg.");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnFedexPackageProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			click(SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Package Search", "Title Of The Page");
			click(SOP.SEARCH_BTN, "Search Button");
			click(SOP.FIRST_WORKSHEET, "First Package ID");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Package Profile", "Title Of The Page");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnChooseDIPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
			assertTextMatching(SOP.PAGE_TITLE, "Choose Delivery Instruction", "Title of the page");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnActionItemsPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.ACTION_ITEMS_LEFT_NAV_LINK, "Action Items Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Execute Action Items", "Title of the page");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN_ON_ACTIONLIST, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String uploadImage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Upload button
			click(SOP.UPLOADIMAGEBTN, "Upload Image button");
			assertElementPresent(SOP.UPLOADIMAGE_PAGE, "Upload Image Page");
			// Select mandatory Fields in Upload Image
			type(SOP.BATCHNUMBER_TEXT, "12345", "Batch Number Text");
			click(SOP.CERTIFIED_MAIL_DROPDOWN, "Certified Mail DropDown");
			waitForElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
			assertElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
			int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(WorksheetCreate.POST_MARKED_DATE,lastYearDate,"Post marked Date text box");
			// click(SOP.UPLOAD_IMG, "Upload Image button");
			uploadFile("Automation_SOPUpload.pdf", SOP.UPLOAD_IMG, "Image Upload");
			click(Generic.SAVE, "Save button");
			waitForElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String entityDetailsOnProcessingCESUploadImage(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			blnEventReport = true;
			String caseNumber = "";
			int relatedWorksheet = 0;
			String cesQueue = Excelobject.getCellData(ReportSheet, "CES Queue", count);
			String arrowEntity = Excelobject.getCellData(ReportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(ReportSheet, "User Level", count);				
			String caseNum1 = Excelobject.getCellData(ReportSheet, "Case Number", count);
			String caseNum2 = Excelobject.getCellData(ReportSheet, "New Case Number", count);
			String escalationReason = Excelobject.getCellData(ReportSheet, "Escalation Reason", count);
			String rejectionReason = Excelobject.getCellData(ReportSheet, "Rejection Reason", count);
			String notRejecting = Excelobject.getCellData(ReportSheet, "Reason for Not Rejecting", count);
			String error = Excelobject.getCellData(ReportSheet, "Error Message", count);
			String plaintiff = Excelobject.getCellData(ReportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(ReportSheet, "Defendant", count);
			String reject = Excelobject.getCellData(ReportSheet, "Reject", count);
			String onHold = Excelobject.getCellData(ReportSheet, "On Hold", count);
			String attorneyName = Excelobject.getCellData(ReportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(ReportSheet, "Court", count);
			uploadImage(ReportSheet, count);
			TimeUnit.MINUTES.sleep(5);
			refreshPage();
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");			
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"Batch #","Filter drop down");
			waitForElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN2,"contains","Filter drop down");
			waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter second drop down");
			assertElementPresent(SOP.FILTERTEXTFIELD, "Filter second drop down");
			type(SOP.FILTERTEXTFIELD,"12345", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");

			try {		 
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);	
			}catch(NoSuchElementException e) {}
			Thread.sleep(1000);
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(1000);

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			Thread.sleep(3000);

			//TRAINGLE_ICON_ARROW_ENTITY			
			//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			//INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
			if(!arrowEntity.equals("")) {				
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {			
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 

				if(!cdsop.equals("CDSOP")) {											
					if (branchPlant.equals("CTCORP")) {
						//CTCORP_RADIO_BUTTON
						waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
					}
				}
				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
				if(cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
				}
				else if(!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
				}
				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				//ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if(entitySearchCount == 0) {
					//Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {				
						disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					}catch(NullPointerException e) {}
					if(disabledUnEntity == null) {
						click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
					Thread.sleep(1500);
					System.out.println("REached here in line 6420");
					try {
						if(disabledUnEntity.equals("true")) {					
							//SEARCH_AGAIN_BUTTON
							waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
							assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							//CANCEL_BUTTON
							waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
							assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							click(SOP.CANCEL_BUTTON, "Cancel Button");
						}}catch(NullPointerException e) {}				
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					//below will be a go ahead when the value for unidentified Entity above is selected
					String unEntityRadioSelected = "";
					try {                	 
						unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
					}catch(NoSuchElementException e) {}
					catch(NullPointerException e) {}
					Thread.sleep(1000);
					try {
						if(unEntityRadioSelected == null) {
							click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}}catch(NullPointerException e) {}
					//ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
					//DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
					//REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
					try {
						//waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
						//assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
					}catch(NoSuchElementException e) {}
					//DOCUMENT_TYPE_DROPDWN
					try {
						//waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
						//assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}
					//PLAINTIFF_TEXT_BOX			
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
					//DEFENDANT_TEXT_BOX				
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
					type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
				}
				else if(entitySearchCount != 0) {
					//REP_STATUS_SORT
					waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					//FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					//CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if(action.size()>0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					}
					catch(NoSuchElementException e) {

					}
					if(!caseNum1.equals("")){					
						//CASEID_TEXTBOX
						waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						if(cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,"19342919","Case number Search text box");
							click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
							click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
						}
						else if(!cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,caseNum1,"Case number Search text box");
							click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
							click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
							
						}
						//SEARCH_BTN
						waitForElementPresent(SOP.SEARCH_BTN, "Search button");
						assertElementPresent(SOP.SEARCH_BTN, "Search button");
						click(SOP.SEARCH_BTN, "Search button");
						//TOTAL_RECORDS_RELATED_WORKSHEET				 				 
						waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results");				 
						relatedWorksheet = Integer.parseInt(getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results"));
						Thread.sleep(1000);
						if(relatedWorksheet == 0) {

							click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
							Thread.sleep(2000);
							//RADIO_PRESENTATION_BUTTON
							String repChecked = "";
							try {
								repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked"); 
							}catch(NoSuchElementException e) {}
							if(repChecked == null) {
								//REP_JURISDICTION_SELECTION
								waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
								assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
								selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");
							}
							Thread.sleep(2000);
							try {
								driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);					 
								selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law suit type in CES Page");
							}catch(NoSuchElementException e) {}
							Thread.sleep(2000);					 
							try {						 
								driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
								selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
							}catch(NoSuchElementException e) {}				
							Thread.sleep(3000);
							waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
							assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
							type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box in CES Page");

							waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
							assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
							type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box CES Page");	

							waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
							assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
							type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");

						}
						else if (relatedWorksheet != 0) {
							//FIRST_WORKSHEET_RADIO_BTN
							waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							//ADD_TO_DOCKET_HISTORY_BUTTON
							waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
							Thread.sleep(2000);
							waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
							caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 
							if(cdsop.equals("CDSOP")) {
								compareStrings(caseNumber,"19342919");
							}

							else if(!cdsop.equals("CDSOP")) {

								compareStrings(caseNumber,caseNum1);
							}				 
						}
					}
					if(!caseNum2.equals("")){
						//SELECT_BUTTON_IN_RELATED_LOG
						waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
						assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
						click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
						//CASEID_TEXTBOX
						waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						if(cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,"19342919", "Case number Search text box");					 
						}
						else if(!cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,caseNum2, "Case number Search text box");					 
						}

						//SEARCH_BTN
						waitForElementPresent(SOP.SEARCH_BTN, "Search button");
						assertElementPresent(SOP.SEARCH_BTN, "Search button");
						click(SOP.SEARCH_BTN, "Search button");
						//FIRST_WORKSHEET_RADIO_BTN
						waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
						assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
						click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
						//ADD_TO_DOCKET_HISTORY_BUTTON
						waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
						assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
						click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
						Thread.sleep(2000);
						waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
						caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 	
						if(cdsop.equals("CDSOP")) {
							compareStrings(caseNumber,"19342919");
						}
						else if(!cdsop.equals("CDSOP")) {

							compareStrings(caseNumber,caseNum2);
						}
					}


					if(caseNum1.equals("")){
						Thread.sleep(1000);
						driver.switchTo().defaultContent();
						assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
						click(SOP.GLYPHICON_HOME, "glyphicon button");
						Thread.sleep(3000);
						driver.switchTo().frame("frame1");		
						//PLAINTIFF_TEXT_BOX			
						waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
						//DEFENDANT_TEXT_BOX				
						waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
						try {
							driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
						}catch(NoSuchElementException e) {}
						//DOCUMENT_TYPE_DROPDWN
						try {
							driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
							selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}				
					}
				}
			}
			Thread.sleep(3000);
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			//Below one check can be applied if attorney and court modification needs to be done - 1476
			if(!attorneyName.equals("")) {			 			
				//RADIO_BUTTON_ATTORNEYNONE					
				String attorneyNoneAttribute = "";

				try {
					attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");   			
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
					//DROP_DOWN_ATTORNEY_SENDER_NAME
					waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"Drop down for Attorney Sender Name");
					assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"DROP down for Attorney Sender Name");
					selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"DROP down for Attorney Sender Name");
				} catch (NoSuchElementException e) {}}

			if(!courtName.equals("")) {					
				try {
					String courtNoneAttribute = "";
					courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					//DROP_DOWN_COURT_NAME
					waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
					assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
					selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");
				} catch (NoSuchElementException e) {}
				/*if(attorneyNoneAttribute == null) {						
					//TEXT_BOX_ATTORNEYNAME
					waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
					assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
					type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"text field for Attorney Sender Name");	
				}
				if(courtNoneAttribute == null) {						
					//TEXT_BOX_COURTNAME
					waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
					assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
					type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");	

				}	*/															
			}			 

			//Below one code is to escalate as Possible REjection
			if(!escalationReason.equals("")) {
				//Below one condition needs to be set if the L2 user processing CES from Escalated List
				//then update to possible rejection click can be done from here.		
				if((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List")) && escalationReason.equals("Update to Possible Rejection")) {
					//UPDATE_TO_POSSIBLE_REJECTION
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");

				}
				if(cesQueue.equals("Escalated List") && escalationReason.equals("Update to Possible Rejection & GetNext")) {
					//UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");	
					Thread.sleep(5000);
				}				
				if(!escalationReason.equals("Update to Possible Rejection") && !escalationReason.equals("Update to Possible Rejection & GetNext")){								
					//ESCALATION_DETAILS
					waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
					//REASON_DRPDWN
					waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");
					//ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Could be a Possible Rejection", "Escalation text box");
					//ESCALATE_BTN
					waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					click(SOP.ESCALATE_BTN, "Escalate button");
				}	
			}
			else if(rejectionReason.equals("") && reject.equals("Y")) {
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");	
				//REJECT_REASON_EMPTY_ERROR
				waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				compareStrings(error,errorMessage);

			}
			else if(!rejectionReason.equals("") && !reject.equals("")) {
				//REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
				if(!notRejecting.equals("")) {
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reason for not Rejecting drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");								
					//ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
				else if(notRejecting.equals("")) {
					if(attorneyName.equals("")) {
						//ATTORNEY_SENDER_NONE_SPECIFIED
						waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					//commenting below as List of WebElemets not required
					//List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {				
						traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}
					//HARD_COPY_DELIVERY
					waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
					String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);												
					if(hardCopy.equals("No") && error.equals("")) {		
						String parentWin= driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow();
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1]).get(0);		
						assertTextContains(letterPopup,rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}				
					//ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if(attorneyName.equals("")) {
						waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						compareStrings(error,errorMessage);
					}
				}
			}			
			else if(escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
				if  (!rejectionReason.equals("")){
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {				
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}
					//SUBMIT_CES				
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
					//SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
				else if  (rejectionReason.equals("")){
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 

							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}	

					/* Below Code is addded on 1/21 as part of GCNBO-1740
			  To handle the onhold submit scenario when the
			  Escalation Reason for the esop is Possible Rejection    			  
					 */
					if(cesQueue.equals("OnHold List")) {
						//ESCALATION_DETAILS
						waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");	
						//ESCALATION_REASON
						waitForElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						assertElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						String escalationReasonInOnHold = getText(SOP.ESCALATION_REASON, "Escalation Reason");	

						if(escalationReasonInOnHold.equals("Possible Rejection")) {
							waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							selectByIndex(SOP.REASON_FOR_NOT_REJECTING,1,"Reject Reason drop down");
							Thread.sleep(2000);	

						}
					}    			    			
					/* Till here the code change made as on 1/21 */






					//REASON_FOR_NOT_REJECTING
					if(cesQueue.equals("Rejections List")) {
						waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
						Thread.sleep(2000);
					}
					//SUBMIT_CES
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
				}
			}
			else if(!onHold.equals("")) {
				//REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
				//ONHOLD_BTN
				waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				click(SOP.ONHOLD_BTN, "On Hold button");
			}


		}catch(Exception e) {}
		return esopId.split("\\: ")[1];	

	}

	public String verifyRelatedLogSubsequentByDefault(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementPresent(SOP.SUBSEQUENT_TYPE, "Subsequent");
			//assertTextMatching(SOP.SUBSEQUENT_TYPE, "Subsequent", "Initial field changed to Subsequent");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyExistingLogOnWorksheetProfilePage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");

			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "autolog", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");
			click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet");
			click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket History");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.SUBSEQUENT, "Subsequent", "Subsequent");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyExistingLogOnWorksheetEditPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");

			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");
			click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet");
			click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket History");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementPresent(SOP.SUBSEQUENT_TYPE, "Subsequent");
			//assertTextMatching(SOP.SUBSEQUENT_TYPE, "Subsequent", "Initial field changed to Subsequent");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityColumnOnMyWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.PRIORITY_COLUMN, "Priority Column On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPrioritySortOnMyWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.PRIORITY_SORT_LINK_MYWORKSHEETS_PAGE, "Priority Sort Link On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFilterOnMyWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.PRIORITY_FILTER, "Priority Field Dropdown On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityColumnOnMyTeamsWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.PRIORITY_COLUMN, "Priority Column On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPrioritySortOnMyTeamsWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.PRIORITY_SORT_LINK_MYWORKSHEETS_PAGE, "Priority Sort Link On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFilterOnMyTeamsWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.PRIORITY_FILTER, "Priority Field Dropdown On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFieldOnWorksheetPopUpPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			isElementNotPresent(SOP.PRIORITY_FIELD_ON_WORKSHEET_PRO_PAGE, "Priority Field Verification");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyCreateQuicklogBtnOnRelatedWorksheetSearchPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
            click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			isElementNotPresent(SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN, "Create Quicklog Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCheckboxesOnWorksheetProfilePage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.PRIORITY_CHECKBOX, "Priority Checkbox");
			isElementNotPresent(SOP.REJECTED_CHECKBOX, "Rejected Checkbox");
			isElementNotPresent(SOP.ATTEMPTED_CHECKBOX, "Attempted Checkbox");
			isElementNotPresent(SOP.CONSOLIDATED_CHECKBOX, "Consolidated Checkbox");
			isElementNotPresent(SOP.MULTIPLE_CHECKBOX, "Multiple Checkbox");
			isElementNotPresent(SOP.BANKRUPTCY_CHECKBOX, "Bankruptcy Checkbox");
			isElementNotPresent(SOP.LETTER_CHECKBOX, "Letter Checkbox");
			isElementNotPresent(SOP.DEFENDANT_CHECKBOX, "Defendant Checkbox");
			isElementNotPresent(SOP.ENTITY_CHECKBOX, "Entity Checkbox");
			isElementNotPresent(SOP.COURT_CHECKBOX, "Court Checkbox");
			isElementNotPresent(SOP.AGENCY_CHECKBOX, "Agency Checkbox");
			isElementNotPresent(SOP.ATTORNEY_CHECKBOX, "Attorney Checkbox");
			isElementNotPresent(SOP.CASEID_CHECKBOX, "CaseID Checkbox");
			isElementNotPresent(SOP.PLAINTIFF_CHECKBOX, "Plaintiff Checkbox");
			isElementNotPresent(SOP.DOCUMENT_TYPE_CHECKBOX, "Document Type Checkbox");
			isElementNotPresent(SOP.SPECIAL_CIRCUMSTANCES_CHECKBOX, "Special Circumstances Checkbox");
			isElementNotPresent(SOP.LAWSUIT_TYPE_CHECKBOX, "LawsuitType Checkbox");
			isElementNotPresent(SOP.NATURE_OF_ACTION_CHECKBOX, "NOA Checkbox");
			isElementNotPresent(SOP.ANSWER_DATE_CHECKBOX, "Answer Date Checkbox");


		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySelectAllAndSelectNoneBtnOnWorksheetProfilePage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.SELECT_ALL_BTN, "Select All Btn Verification");
			isElementNotPresent(SOP.SELECT_NONE_BTN, "Select None Btn Verification");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedFieldOnNewlyCreatedWorksheetProfilePage(String reportSheet, int count, String esopId) throws Throwable {

		try {
			/*createWorksheetViaSOPList(reportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			// Create Worksheet Method Called
			createWorksheetMethod(reportSheet, count);
			click(Generic.SAVE, "Save Button");*/
			viewAndCreateTheWorkSheetUsingESOPId(reportSheet, count, esopId);
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.CLONED_COPIED_FIELD, "Cloned/Copied Field");

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyClonedCopiedFieldOnWorksheetPopUpPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			isElementNotPresent(SOP.CLONED_COPIED_FIELD, "Cloned/Copied Field");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedColumnOnMyWorksheets(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.CLONED_COPIED_COLUMN, "Cloned/Copied Column On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedColumnOnMyTeamsWorksheets(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.CLONED_COPIED_COLUMN, "Cloned/Copied Column On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyDefaultSortingOnMyWorksheetPageIsReceivedDt(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementPresent(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySortingOnMyWorksheetPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Check whether All sorting links are present
			click(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");
			isElementPresent(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.PLAINTIFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.DEFENDANT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");

			click(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ACTIVE_LOG_ID_SORT_LINK, "Active Sort By Log# Link");
			click(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.ACTIVE_ENTITY_NAME_SORT_LINK, "Active Sort By Entity Name Link");
			click(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.ACTIVE_STATUS_SORT_LINK, "Active Sort By Status Link");
			click(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.ACTIVE_CASE_ID_SORT_LINK, "Active Sort By Case Id Link");
			click(SOP.PLAINTIFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.ACTIVE_PLAINTIFF_DEBTOR_SORT_LINK, "Active Sort By Plaintiff/Debtor Link");
			click(SOP.DEFENDANT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.ACTIVE_DEFENDANT_CREDITOR_SORT_LINK, "Active Sort By Defendant/Creditor Link");
			click(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.ACTIVE_RECEIVED_BY_OFFICE_SORT_LINK, "Active Sort By Received By Office Link");
			click(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");
			isElementPresent(SOP.ACTIVE_BRANCH_PLANT_SORT_LINK, "Active Sort By Branch Plant Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyDefaultSortingOnMyTeamsWorksheetPageIsReceivedDt(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementPresent(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySortingOnMyTeamsWorksheetPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			// Check whether All sorting links are present
			click(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");
			isElementPresent(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.PLTFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.ASSIGNED_TO_SORT, "Inactive Sort By Assigned To Link");
			isElementPresent(SOP.DEFT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");

			click(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ACTIVE_LOG_ID_SORT_LINK, "Active Sort By Log# Link");
			click(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.ACTIVE_ENTITY_NAME_SORT_LINK, "Active Sort By Entity Name Link");
			click(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.ACTIVE_STATUS_SORT_LINK, "Active Sort By Status Link");
			click(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.ACTIVE_CASE_ID_SORT_LINK, "Active Sort By Case Id Link");
			click(SOP.PLTFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.ACTIVE_PLTFF_DEBTOR_SORT_LINK, "Active Sort By Plaintiff/Debtor Link");
			click(SOP.ASSIGNED_TO_SORT, "Inactive Sort By Assigned To Link");
			isElementPresent(SOP.ACTIVE_ASSIGNED_TO_SORT_LINK, "Active Sort By Assigned To Link");
			click(SOP.DEFT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.ACTIVE_DEFT_CREDITOR_SORT_LINK, "Active Sort By Defendant/Creditor Link");
			click(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.ACTIVE_RECEIVED_BY_OFFICE_SORT_LINK, "Active Sort By Received By Office Link");
			click(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");
			isElementPresent(SOP.ACTIVE_BRANCH_PLANT_SORT_LINK, "Active Sort By Branch Plant Link");


		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}
