package com.arrow.workflows;

import com.arrow.objectrepo.EM;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_EM extends BusinessFunctions{
	
	/********************************************************************************************************
	 * Method Name : entityEMSearch() 
	 * Author : Pradyumna 
	 * Description : This method will Verify Entity can be searched in EM Entity Search
	 * Date of creation : 12/02/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String entityEMSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);
			String entityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			//Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			//Enter Entity Name
			type(Entity.ENTITY_NAME,entityName,"Entity Name");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			waitForElementPresent(EM.EM_ENTITY_SEARCH_RESULT, "EM Entity Search Result");
			assertElementPresent(EM.EM_ENTITY_SEARCH_RESULT, "EM Entity Search Result");
			click(EM.FIRST_EM_DATA, "First EM Data");
			waitForElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			//Search Entity by ID
			click(EM.EM_ENTITY_SEARCH_LINK, "EM Entity Search Link");
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			type(Generic.ENTITY_ID,entityID,"Entity ID");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			waitForElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : affiliationEMSearch() 
	 * Author : Pradyumna 
	 * Description : This method will Verify Affiliation can be searched in EM Affiliation Search
	 * Date of creation : 12/03/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String affiliationEMSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationName = Excelobject.getCellData(ReportSheet, "AffiliationName", count);
			String affiliationID = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			//Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			click(EM.EM_AFFLN_SEARCH_LINK, "EM Affiliation Search Link");
			assertElementPresent(EM.EM_AFFILIATION_PAGE, "EM Affiliation Page");
			//Enter Affiliation Name
			type(Generic.NAME_FIELD,affiliationName,"Affiliation Name");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			waitForElementPresent(EM.EM_AFFLN_SEARCH_RESULT, "EM Affiliation Search Result");
			assertElementPresent(EM.EM_AFFLN_SEARCH_RESULT, "EM Affiliation Search Result");
			click(EM.FIRST_AFFLN_EM_DATA, "First EM Data");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			//Search Affiliation by ID
			click(EM.EM_AFFLN_SEARCH_LINK, "EM Affiliation Search Link");
			assertElementPresent(EM.EM_AFFILIATION_PAGE, "EM Affiliation Page");
			type(Generic.CT_LOG,affiliationID,"Affiliation ID");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			waitForElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
		
	
	/********************************************************************************************************
	 * Method Name : entityActivateDeactivate() 
	 * Author : Pradyumna 
	 * Description : This method will Verify Activate and Deactivate buttons in EM Maintenance for Entity
	 * Date of creation : 12/03/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String entityActivateDeactivate(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			//Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			//Enter Entity ID
			type(Generic.ENTITY_ID,entityID,"Entity ID");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			//Select Internal Radio Button and Click on Deactivate button
			click(EM.RADIO_ACTIVE_INTERNAL, "EM Radio Button Internal");
			if(verifyIfElementPresent(EM.BEM_STATUS_EXTERNAL,"BEM Status")){
			//if(isElementPresent(EM.ACTIVE_STATUS, "Active")) {
			click(EM.DEACTIVATE_BTN, "Deactivate Button");
			assertElementPresent(EM.DEACTIVATE_EM_PAGE, "Deactivate EM Page");
			//Select Discontinue Reason, Service Type and then click on Deactivate button
			click(EM.DEACTIVATE_REASON, "Correction/Entered in Error dropdown reason");
			type(EM.DEACTIVATE_COMMENT,"Testing","Deactivate Comments");
			click(EM.SERVICE_TYPE_SELECT, "Service Type Select checkbox");
			click(EM.ACTIVATE_DEACTIVATE_BTN, "Deactivate button");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.DEACTIVATE_MESSAGE, "The following units have been deactivated message");
			}
			//Click on Activate button
			click(EM.ACTIVATE_BTN, "Activate Button");
			assertElementPresent(EM.ACTIVATE_EM_PAGE, "Activate EM Page");
			click(EM.SERVICE_TYPE_SELECT, "Service Type Select checkbox");
			click(EM.ACTIVATE_BTN2, "Activate Button");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.ACTIVATE_MESSAGE, "The following units have been activated message");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	
	/********************************************************************************************************
	 * Method Name : afflnActivateDeactivate() 
	 * Author : Pradyumna 
	 * Description : This method will Verify Activate and Deactivate buttons in EM Maintenance for Affiliation
	 * Date of creation : 12/03/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String afflnActivateDeactivate(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationID = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			//Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			//Click on Affiliation Search Link
			click(EM.EM_AFFLN_SEARCH_LINK, "EM Affiliation Search Link");
			assertElementPresent(EM.EM_AFFILIATION_PAGE, "EM Affiliation Page");
			type(Generic.CT_LOG,affiliationID,"Affiliation ID");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			if(isElementPresent(EM.ACTIVE_STATUS, "Active")) {
			//Click on Deactivate button
			click(EM.DEACTIVATE_BTN, "Deactivate Button");
			assertElementPresent(EM.DEACTIVATE_EM_PAGE, "Deactivate EM Page");
			//Select Discontinue Reason, Service Type and then click on Deactivate button
			click(EM.DEACTIVATE_REASON, "Correction/Entered in Error dropdown reason");
			type(EM.DEACTIVATE_COMMENT,"Testing","Deactivate Comments");
			click(EM.SERVICE_TYPE_SELECT, "Service Type Select checkbox");
			click(EM.AFFLN_DEACTIVATE_BTN, "Deactivate button");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			assertElementPresent(EM.AFFI_DEACTIVATE_MESSAGE, "The following units have been deactivated message");
			}
			//Click on Activate button
			click(EM.ACTIVATE_BTN, "Activate Button");
			assertElementPresent(EM.ACTIVATE_EM_PAGE, "Activate EM Page");
			click(EM.SERVICE_TYPE_SELECT, "Service Type Select checkbox");
			click(EM.ACTIVATE_BTN, "Activate Button");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			assertElementPresent(EM.AFFI_ACTIVATE_MESSAGE, "The following units have been activated message");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/*
	
	/********************************************************************************************************
	 * Method Name : EMAfflnHistory() 
	 * Author : Pradyumna 
	 * Description : This method will Verify Records displayed in EM History for Affiliation
	 * Date of creation : 12/03/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String EMAfflnHistory(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationID = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			// click on EM link on top nav
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			//Click on Affiliation Search Link
			click(EM.EM_AFFLN_SEARCH_LINK, "EM Affiliation Search Link");
			assertElementPresent(EM.EM_AFFILIATION_PAGE, "EM Affiliation Page");
			type(Generic.CT_LOG,affiliationID,"Affiliation ID");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			waitForElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			//Select Internal Radio Button and Click on Deactivate button
			click(EM.VIEW_HISTORY_LINK, "View History Link");
			waitForElementPresent(EM.EM_HISTORY_PAGE, "EM History Page");
			assertElementPresent(EM.EM_HISTORY_PAGE, "EM History Page");
			click(EM.RETURN_TO_EM_MAINTENANCE, "Return to EM Maintenance Page");
			waitForElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE_BY_AFFLN, "EM Maintainenace Page");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : EMEntityHistory() 
	 * Author : Pradyumna 
	 * Description : This method will Verify Records displayed in EM History for Entity
	 * Date of creation : 12/03/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String EMEntityHistory(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on EM link on top nav
			click(HomePage.EM_TOP_NAV, "EM Link on Top Nav");
			//Verify if EM Page is displayed
			assertElementPresent(EM.EM_ENTITY_PAGE, "EM Entity Page");
			//Enter Entity ID
			type(Generic.ENTITY_ID,entityID,"Entity ID");
			//Search button
			click(Generic.SEARCH_BUTTON, "Search Button");
			waitForElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			//Select Internal Radio Button and Click on Deactivate button
			click(EM.VIEW_HISTORY_LINK, "View History Link");
			waitForElementPresent(EM.EM_HISTORY_PAGE, "EM History Page");
			assertElementPresent(EM.EM_HISTORY_PAGE, "EM History Page");
			click(EM.RETURN_TO_EM_MAINTENANCE, "Return to EM Maintenance Page");
			waitForElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			assertElementPresent(EM.EM_MAINTENANCE, "EM Maintainenace Page");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}
