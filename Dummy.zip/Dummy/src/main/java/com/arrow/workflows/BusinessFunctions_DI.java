package com.arrow.workflows;

import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.DI;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;

public class BusinessFunctions_DI extends BusinessFunctions {

	public void bulletinDI(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Check whether Bulletin edit btn,di source,options,delivery method,recipient
			// fields are present
			isElementPresent(DI.BULLETIN_EDIT_BTN, "Bulletin Edit Button");
			isElementPresent(DI.BULLETIN_DI_SOURCE_LABEL, "Bulletin DI Source Label");
			isElementPresent(DI.BULLETIN_OPTIONS_LABEL, "Bulletin Options Label");
			isElementPresent(DI.BULLETIN_DELIVERY_METHOD_LABEL, "Bulletin Delivery Method label");
			isElementPresent(DI.BULLETIN_RECIPIENT_LABEL, "Bulletin Recipient label");
			isElementPresent(DI.BULLETIN_RECIPIENT_NAME, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void communicationDI(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Check whether Communication edit btn,di source,delivery
			// method,icomm,recipient fields are present
			isElementPresent(DI.COMM_EDIT_BTN, "Communication Edit Button");
			isElementPresent(DI.COMM_DI_SOURCE_LABEL, "Communication DI Source Label");
			isElementPresent(DI.COMM_DELIVERY_METHOD_LABEL, "Communication Delivery Method label");
			isElementPresent(DI.COMM_ICOMM_LABEL, "Communication ICOMM label");
			isElementPresent(DI.COMM_RECIPIENT_LABEL, "Communication Recipient label");
			isElementPresent(DI.COMM_RECIPIENT_NAME, "Communication Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void renewalInvoiceDI(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Check whether Renewal Invoice edit btn,di source,Entity Name On Invoice
			// Address,auto renew,delivery method,recipient fields are present
			isElementPresent(DI.RENEWALINVOICE_EDIT_BTN, "Renewal Invoice Edit Button");
			isElementPresent(DI.RENEWALINVOICE_DI_SOURCE_LABEL, "Renewal Invoice  DI Source Label");
			isElementPresent(DI.RENEWALINVOICE_ENTITY_NAME_ON_INVOICE_ADDRESS_LABEL,
					"Entity Name On Invoice Address label");
			isElementPresent(DI.RENEWALINVOICE_DELIVERY_METHOD_LABEL, "Renewal Invoice Delivery method label");
			isElementPresent(DI.RENEWALINVOICE_AUTO_RENEW_LABEL, "Renewal Invoice Auto Renew label");
			isElementPresent(DI.RENEWALINVOICE_RECIPIENT_LABEL, "Renewal Invoice Recipient label");
			isElementPresent(DI.RENEWALINVOICE_RECIPIENT_NAME, "Renewal Invoice Recipient Name label");

		} catch (Exception e) {
			throw e;
		}

	}

	public void sopDI(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Check whether SOP edit btn,di source,lawsuit type,expand all and collapse all
			// link,deliverables,delivery method,recipient fields are present
			isElementPresent(DI.SOP_EDIT_BTN, "SOP Edit Button");
			isElementPresent(DI.SOP_DI_SOURCE_LABEL, "SOP  DI Source Label");
			isElementPresent(DI.SOP_LAWSUIT_TYPE, "SOP Lawsuit Type label");
			isElementPresent(DI.SOP_EXPAND_ALL_LINK, "SOP Expand All Link");
			isElementPresent(DI.SOP_COLLAPSE_ALL_LINK, "SOP Collapse All link");
			isElementPresent(DI.SOP_RECIPIENT_LABEL, "SOP Recipient label");
			isElementPresent(DI.SOP_RECIPIENT_NAME, "SOP Recipient Name");
			isElementPresent(DI.SOP_DELIVERABLES, "SOP papers with transmittal");
			isElementPresent(DI.SOP_DELIVERY_METHODS_LABEL, "SOP Delivery Methods label");

		} catch (Exception e) {
			throw e;
		}

	}

	public void xsopDI(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Check whether Bulletin edit btn,di source,delivery method,recipient fields
			// are present
			isElementPresent(DI.XSOP_EDIT_BTN, "XSOP Edit Button");
			isElementPresent(DI.XSOP_DI_SOURCE_LABEL, "XSOP  DI Source Label");
			isElementPresent(DI.XSOP_DELIVERY_METHOD_LABEL, "XSOP Delivery Method label");
			isElementPresent(DI.XSOP_RECIPIENT_LABEL, "XSOP Recipient label");
			isElementPresent(DI.XSOP_RECIPIENT_NAME, "XSOP Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void bulletinDIEdit(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Click On Bulletin Edit Button
			click(DI.BULLETIN_EDIT_BTN, "Bulletin Edit Button");

			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");

			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.BULLETIN_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void communicationEdit(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Click On Communication Edit Button
			click(DI.COMM_EDIT_BTN, "Communication Edit Button");

			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");

			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.COMM_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void renewalInvoiceEdit(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Click On Communication Edit Button
			click(DI.RENEWALINVOICE_EDIT_BTN, "Communication Edit Button");

			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");

			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.RENEWALINVOICE_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void xsopEdit(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Click On Communication Edit Button
			click(DI.XSOP_EDIT_BTN, "Communication Edit Button");

			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");

			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.XSOP_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}

	public void replaceMultipleDI(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");

			// Click on Replace Multiple DI Button
			click(DI.REPLACE_MULTIPLE_DI_BTN, "Replace Multiple DI Btn");

			// Click On Select All Button
			click(DI.SELECT_ALL_BTN, "Select All Btn");

			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			
			// enter Comments and click on Replace button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.REPLACEBTN, "Replace button");
			
			//Handle Popup
			handlepopup();
			
			//Verify recipeints all DIs are changed
			assertTextMatching(DI.BULLETIN_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			assertTextMatching(DI.COMM_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			assertTextMatching(DI.RENEWALINVOICE_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			assertTextMatching(DI.SOP_RECIPIENT_NAME, participantName, "SOP Recipient Name");
			assertTextMatching(DI.XSOP_RECIPIENT_NAME, participantName, "Bulletin Recipient Name");
			

		} catch (Exception e) {
			throw e;
		}

	}
	
		
	public void sopRecipientEdit(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			
			
			//Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			
			//Click On Edit button on Edit SOP DI Page
			click(DI.SOP_RECIPIENT_EDIT_BTN,"Recipient Edit Btn");
			
			//Click On Delivery Actions Edit btn
			click(DI.DELIVERY_ACTIONS_EDIT_BTN,"Delivery Actions Edit Btn");
			
			//Select UPS 2nd Day Air from delivery method drpdwn
			click(DI.UPS_2ND_DAY_AIR,"UPS 2nd Day Air");
			
			//Click On Add to list button and click on preview changes button
			click(DI.ADD_TO_LIST_BTN,"Add to list btn");
			click(DI.PREVIEW_CHANGES_BTN,"Preview Changes Button");
			
			//Enter comments and click on save button
			type(DI.DI_COMMENTS_TEXTBOX,"test","Comments Text Box");
			click(DI.SAVEBTN,"Save Button");
			
			//Verify whether the delivery method is changed
			assertElementPresent(DI.UPS_2ND_DAY_AIR_SOP_DELIVERY_METHODS, "Delivery Method Value");
		
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void cancelbulletinDIEdit(String ReportSheet, int count) throws Throwable {

		try {

			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			
			String recipientName=getText(DI.BULLETIN_RECIPIENT_NAME, "Recipient Name");

			// Click On Bulletin Edit Button
			click(DI.BULLETIN_EDIT_BTN, "Bulletin Edit Button");

			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.CANCELBTN, "Cancel button");

			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.BULLETIN_RECIPIENT_NAME, recipientName, "Bulletin Recipient Name");

		} catch (Exception e) {
			throw e;
		}

	}
	
	public void createCondition(String ReportSheet, int count) throws Throwable {

		try {
			
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			
			//Click On SOP Edit Button
			click(DI.SOP_EDIT_BTN, "SOP Edit Button");
			
			//Click On Create Condition Button
			click(DI.CREATE_CONDITION_BTN,"Create Condition Button");
			
			//Select Complaint from document type left selector
			//click(DI.DOCUMENT)
			
			
			


			
		} catch (Exception e) {
			throw e;
		}

	}





}
