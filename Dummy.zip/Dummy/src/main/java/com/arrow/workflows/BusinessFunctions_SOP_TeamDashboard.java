package com.arrow.workflows;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.TeamSOPDashboard;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;
import com.gargoylesoftware.htmlunit.javascript.host.Console;
import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

public class BusinessFunctions_SOP_TeamDashboard extends BusinessFunctions_SOP {
	
	/********************************************************************************************************
	 * Method Name : viewTeamSOPDashboard() 
	 * Author : Pradyumna 
	 * Description : This method will verify Team SOP Dashboard Page
	 * Date of creation : 8/19/2019
	 * modifying person : Ekta
	 * Date of modification : 12/18/2020
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String viewTeamSOPDashboard(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(HomePage.SOPLINK, "SOP Link");
			//Click on Team SOP Dashboard
			click(TeamSOPDashboard.TEAM_SOP_DASHBOARD, "Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.TEAM_SOP_DASHBOARD_PAGE, "Team SOP Dashboard Page");
			assertElementPresent(TeamSOPDashboard.TEAM, "Team");
			assertElementPresent(TeamSOPDashboard.TOTAL_SOP_COUNT_15DAYS, "Total SOP Count for 15 days");
			assertElementPresent(TeamSOPDashboard.COMPLETED_SOPS, "Completed SOP");
			assertElementPresent(TeamSOPDashboard.SOP_LIST_WITHOUT_WORKSHEET, "SOP List Without Worksheet");
			assertElementPresent(TeamSOPDashboard.PENDING_WORKSHEET_AND_ACTION_ITEM, "Pending Worksheet and Action Item");	
			//Status
			assertElementPresent(TeamSOPDashboard.REJECTED_AND_HARD_COPY, "Rejected And Hard Copy Delivery Required");
			assertElementPresent(TeamSOPDashboard.PHONE_CALL_REQUIRED, "Phone call required");
			assertElementPresent(TeamSOPDashboard.INCOMPLETE_WORKSHEETS, "Incomplete Worksheets");
			assertElementPresent(TeamSOPDashboard.PENDING_ACTION_ITEMS, "Pending Action Items");
			//assertElementPresent(TeamSOPDashboard.REJECTION_FOR_REVIEW, "Rejection for Review");			
			//Click on Refresh Button
			click(TeamSOPDashboard.REFRESH_BUTTON, "Refresh Button");
			assertElementPresent(TeamSOPDashboard.TEAM_SOP_DASHBOARD_PAGE, "Team SOP Dashboard Page");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : SOPListWithoutWorksheet() 
	 * Author : Pradyumna 
	 * Description : This method will verify SOPListWithoutWorksheet navigating to SOP List page
	 * Date of creation : 8/19/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SOPListWithoutWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(HomePage.SOPLINK, "SOP Link");
			//Click on Team SOP Dashboard
			click(TeamSOPDashboard.TEAM_SOP_DASHBOARD, "Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.TEAM_SOP_DASHBOARD_PAGE, "Team SOP Dashboard Page");
			//Select Test New York SOP Team
			//selectBySendkeys(TeamSOPDashboard.TEAM_SELECTION, "CT - New York SOP Team", "CT - New York SOP Team");
			click(TeamSOPDashboard.NY_TEAM_SELECTION, "CT - New York SOP Team");
			click(TeamSOPDashboard.LINK_WITHOUT_WS, "Link Without WS");
			assertElementPresent(WorksheetCreate.SOP_LIST_PAGE, "Team");
			
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : approveRejectionandActionItem() 
	 * Author : Pradyumna 
	 * Description : This method will verify SOPListWithoutWorksheet navigating to SOP List page and will work
	 * only if worksheets are rejected. Execute rejectWorksheet() method before this method
	 * Date of creation : 8/22/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String approveRejectionandActionItem(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(HomePage.SOPLINK, "SOP Link");
			//Click on Team SOP Dashboard
			click(TeamSOPDashboard.TEAM_SOP_DASHBOARD, "Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.TEAM_SOP_DASHBOARD_PAGE, "Team SOP Dashboard Page");
			//Select Test New York SOP Team
			click(TeamSOPDashboard.NY_TEAM_SELECTION, "CT - New York SOP Team");
			
			click(TeamSOPDashboard.PENDING_ACTION_ITEMS_LINK, "Pending Action Items Link");
			assertElementPresent(TeamSOPDashboard.SOP_DASHBOARD_ITEMS, "SOP Dashboard Items Page");
			String WorksheetID=getText(TeamSOPDashboard.FIRST_SOP_ID, "Log ID");
			click(TeamSOPDashboard.FIRST_SOP_ID, "First SOP Link");
			if(verifyIfElementPresent(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button")) {	
				click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
				//Select Copy of Transmittal From Deliverable Drp Dwn
				click(ActionItems_SOP.COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");
				click(ActionItems_SOP.HAND_DELIVERED_BY_CT_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");
				click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
				// Enter a participant name
				type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
				click(ActionItems_SOP.FINDBTN, "Find Button");
				waitForElementPresent(Entity.TABLEID, "Recipient Table");
				clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
				// Click On Add/Update Btn
				click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
				click(ActionItems_SOP.ACTIONS_LIST_BTN, "Action List Btn");
				click(ActionItems_SOP.EXECUTE_BTN, "Execute Btn");
				click(TeamSOPDashboard.TEAM_SOP_DASHBOARD, "Team SOP Dashboard");
				click(TeamSOPDashboard.NY_TEAM_SELECTION, "CT - New York SOP Team");
				click(TeamSOPDashboard.PENDING_ACTION_ITEMS_LINK, "Pending Action Items Link");
				selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log ID");
				selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
				type(Generic.DROP_DOWN_TEXT, WorksheetID, "Log ID Entered");
				click(Generic.GO_BUTTON,"Go Button");
				assertElementPresent(Generic.NO_RECORDS_FOUND2, "No Records found");
			}
			else{
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(Carrier_SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(TeamSOPDashboard.REJECTION_APPROVED_BUTTON, "Rejection Approved");
			selectBySendkeys(WorksheetCreate.REMARKS, "allstate", "Remarks Selected");
			click(Generic.SAVE, "Save Approved");
			//Select UPS Package
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(TeamSOPDashboard.REJECTION_APPROVED_YES, "Rejection Approved: Yes");
			click(TeamSOPDashboard.CREATE_UPS_PACKAGE, "Create UPS Package");	
			if(verifyIfElementPresent(TeamSOPDashboard.CREATE_PACKAGE_BUTTON, "Create Package Button")) {
				click(TeamSOPDashboard.CREATE_PACKAGE_BUTTON, "Create Package Button");
			}
			else
			{
				System.out.println("Create Package Button is not Present");
			}
			//click(TeamSOPDashboard.CREATE_PACKAGE_BUTTON, "Create Package Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PAGE, "Carrier Package Page");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			click(TeamSOPDashboard.TEAM_SOP_DASHBOARD, "Team SOP Dashboard");
			//Check on Approval if worksheet if displayed anymore
			click(TeamSOPDashboard.PENDING_ACTION_ITEMS_LINK, "Pending Action Items Link");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log ID");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, WorksheetID, "Log ID Entered");
			click(Generic.GO_BUTTON,"Go Button");
			assertElementPresent(TeamSOPDashboard.NO_RECORDS_FOUND, "No Records Found");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : rejectedAndHardCopy() 
	 * Author : Pradyumna 
	 * Description : This method will verify worksheet link and also verify content
	 * Date of creation : 8/22/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String rejectedAndHardCopy(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			click(HomePage.SOPLINK, "SOP Link");
			//Click on Team SOP Dashboard
			click(TeamSOPDashboard.TEAM_SOP_DASHBOARD, "Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.TEAM_SOP_DASHBOARD_PAGE, "Team SOP Dashboard Page");
			//Select Test New York SOP Team
			click(TeamSOPDashboard.NY_TEAM_SELECTION, "CT - New York SOP Team");
			click(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO, "Rejected Hard Copy for CTCORP");
			assertElementPresent(TeamSOPDashboard.SOP_DASHBOARD_ITEMS, "SOP Dashboard Items Page");
			click(TeamSOPDashboard.STATUS_DRPDWN, "Select Status from Drop Down");
			click(TeamSOPDashboard.HARD_COPY_DELIVERY_CONTAINS_FILTER, "Contains Filter");
			type(TeamSOPDashboard.HARD_COPY_DELIVERY_RHS_FILTER, "Hard Copy Delivery Required", "Hard Copy Delivery Required");
			click(TeamSOPDashboard.GO_BTN, "Go Button");
			click(TeamSOPDashboard.FIRST_SOP_ID, "First SOP Link");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			selectBySendkeys(TeamSOPDashboard.DROP_OPTION, "View Packing Slip", "View Packing Slip");
			click(Generic.IMG_GO_BUTTON, "Go Button");
			String parentWindow= driver.getWindowHandle();
			handlePopUpWindwow();
			assertElementPresent(TeamSOPDashboard.CT_PACKING_SLIP, "CT Packing Slip");
			driver.close();
			driver.switchTo().window(parentWindow);
			waitForElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
//Below function is added as part of CEs enhancement changes
	
	public void teamSOPDashboard(String reportSheet, int count) throws Throwable{
		String dashboard = Excelobject.getCellData(reportSheet, "Team Dashboard", count);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//TEAM_SOP_DASHBOARD
		waitForElementPresent(SOP.TEAM_SOP_DASHBOARD, "Team SOP Dashboard link in left nav SOP List Page");
		assertElementPresent(SOP.TEAM_SOP_DASHBOARD, "assert Team SOP Dashboard link in left nav SOP List Page");
		click(SOP.TEAM_SOP_DASHBOARD, "click Team SOP Dashboard link in left nav SOP List Page");
		//REJECTED_HARD_COPY_REQUIRED
		assertElementPresent(SOP.REJECTED_HARD_COPY_REQUIRED, "Rejected and hard copy required status assert Team SOP Dashboard Page");
		//PHONE_CALL_REQUIRED
		assertElementPresent(SOP.PHONE_CALL_REQUIRED, "Phone Call Required status assert Team SOP Dashboard Page");
		//INCOMPLETE_WORKSHEETS
		assertElementPresent(SOP.INCOMPLETE_WORKSHEETS, "Incomplete Worksheet status assert Team SOP Dashboard Page");
		//PENDING_ACTION_ITEMS
		assertElementPresent(SOP.PENDING_ACTION_ITEMS, "Pending Action Items status assert Team SOP Dashboard Page");		
		if(!dashboard.equals("")) {			
		//TEAM_DROP_DOWN
		waitForElementPresent(SOP.TEAM_DROP_DOWN, "Team drop down fields in Team SOP Dashboard Page");
		assertElementPresent(SOP.TEAM_DROP_DOWN, "assert Team drop down fields in Team SOP Dashboard Page");
		click(SOP.TEAM_DROP_DOWN, "click Team drop down fields in Team SOP Dashboard Page");
		selectByVisibleText(SOP.TEAM_DROP_DOWN,dashboard,"select the text in Team drop down");			
		//REJECTION_FOR_REVIEW
		if(dashboard.equals("SOP Support Team") && dashboard.equals("SOP Dallas Processing Team")) {
		waitForElementPresent(SOP.REJECTION_FOR_REVIEW,"Rejection for review status assert Team SOP Dashboard Page");
		assertElementPresent(SOP.REJECTION_FOR_REVIEW, "Rejection for review status assert Team SOP Dashboard Page");			
		}	
	}	
}

	public void rejectedLogHardCopyRequiredSOPTeamDashboard(String reportSheet, int count, String esopId) throws Throwable{
		
		try{
			teamSOPDashboard(reportSheet,count);
			String branchPlant = SQL_Queries.getTheBranchPlantForTheESOPs(esopId).get(0);
			String rejectedLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
			if(branchPlant.equals("92001")){
				// added REJECT_AND_HARDCOPY_ASSIGNED_TO instead of below web element
				//REJECT_AND_HARDCOPY_LINK
				waitForElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO, "Reject and Hard Copy Required For CTCORP");
				assertElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO, "Reject and Hard Copy Required For CTCORP");
				click(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO, "Reject and Hard Copy Required For CTCORP");		
			}
			else if(branchPlant.equals("92003")){
				//REJECT_AND_HARDCOPY_LINK_NRAI
				waitForElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI, "Reject and Hard Copy Required For NRAI");
				assertElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI, "Reject and Hard Copy Required For NRAI");
				click(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI, "Reject and Hard Copy Required For NRAI");			
			}
			searchForLog(rejectedLog);
			//FIRST_SOP_ID
			waitForElementPresent(TeamSOPDashboard.FIRST_SOP_ID, "Reject Log with hard cop required is present in the Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.FIRST_SOP_ID, "Reject Log with hard cop required is present in the Team SOP Dashboard");
			
		}catch(NoSuchElementException e){}
		catch(Exception e){}
	}
	
	public void searchForLog(String log) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1,"Log #","Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, log, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");		
		click(SOP.FILTERGOBTN, "Go Button");
	}
}
