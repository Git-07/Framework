package com.arrow.workflows;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP_AutoUpload extends BusinessFunctions{
	
	/********************************************************************************************************
	 * Method Name : autoUpload() 
	 * Author : Pradyumna 
	 * Description : This method will verify error images, In Process Queue and Pending upload present in SOP
	 * Date of creation : 11/13/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String autoUpload(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");		
			//Click on Auto Upload Link 
			click(SOP.AUTO_UPLOAD_LINK, "Upload Image button");
			assertElementPresent(SOP.AUTO_UPLOAD_PAGE, "Auto Upload Page");
			assertElementPresent(SOP.ERROR_IMAGES_TAB, "Error Images Tab");
			assertElementPresent(SOP.IMAGE_PATH, "Image Path");
			//Click on InProcess Queue
			click(SOP.INPROCESS_QUEUE, "In Process Queue Tab");
			assertElementPresent(SOP.PROCESS_START_TIME, "Process Start Time");
			//Click on Pending Upload
			click(SOP.PENDING_UPLOAD, "Pending Upload");
			assertElementPresent(SOP.IMAGE_PATH, "Image Path");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
