package com.arrow.workflows;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Campaign;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_Campaign extends BusinessFunctions {

	public void viewCreateNewCampaign(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String campaignName = Excelobject.getCellData(ReportSheet, "Campaign Name", count);
			String firstReminder = Excelobject.getCellData(ReportSheet, "First Reminder", count);
			String secondReminder = Excelobject.getCellData(ReportSheet, "Second Reminder", count);

			// click on Campaign link
			click(Campaign.CAMPAIGN_LINK, "Campaign Link");
			// click on Manage Campaign link
			click(Campaign.MANAGE_CAMPAIGN_LINK, "Manage Campaign Link");
			// click on Create New Campaign link
			click(Campaign.CREATE_NEW_CAMPAIGN_BTN, "Create New Campaign Button");
			// Verify title of the page is Create Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Create Campaign", "Title of the Page");
			// Enter the values for Campaign Name, 1st Reminder and 2nd Reminder fields
			type(Campaign.CAMPAIGN_NAME_TEXTFIELD, campaignName, "Campaign Name Text box");
			type(Campaign.FIRST_REMINDER_TEXTFIELD, firstReminder, "First Reminder Text box");
			type(Campaign.SECOND_REMINDER_TEXTFIELD, secondReminder, "Second Reminder Text box");
			// click on Cancel button
			click(Campaign.CANCEL_BTN, "Cancel Button");
			// Verify title of the page is Manage Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Manage Campaign", "Title of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void viewTracking(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String customerName = Excelobject.getCellData(ReportSheet, "Customer Name", count);

			// Click on Campaign link
			click(Campaign.CAMPAIGN_LINK, "Campaign Link");

			// Click on Manage Campaign link
			click(Campaign.MANAGE_CAMPAIGN_LINK, "Manage Campaign Link");

			// Click on View Tracking link
			click(Campaign.VIEW_TRACKING_LINK, "View Tracking Link");

			// Verify title of the page is Campaign Tracking - Paperless Invoice
			assertTextMatching(Campaign.PAGE_TITLE, "Campaign Tracking - Paperless Invoice", "Title of the Page");

			// Enter the value for Customer Name field and click on Search button
			type(Campaign.CUSTOMER_NAME_TEXTFIELD, customerName, "Customer Name Text box");
			click(Campaign.SEARCH_BTN, "Search Button");

			// Click on Deliverables Link
			click(Campaign.DELIVERABLES_LINK, "Deliverables Link");

			// On clicking Print Button, New window is opened. Below steps manages Jumps
			// from Parent to child & back to Parent Window
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();

			// Verify title of the page is Participant's Deliverables List
			assertTextMatching(Campaign.PAGE_TITLE, "Participant's Deliverables List", "Title of the Page");
			// assertElementPresent(Customer.CUSTOMER_PRINT_VIEW, "Participant's
			// Deliverables List");

			driver.close();
			driver.switchTo().window(parentWindow);

			// Verify title of the page is Campaign Tracking - Paperless Invoice
			assertTextMatching(Campaign.PAGE_TITLE, "Campaign Tracking - Paperless Invoice", "Title of the Page");
			// assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Click on Cancel button
			click(Campaign.CANCEL_BTN, "Cancel Button");

			// Verify title of the page is Manage Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Manage Campaign", "Title of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void editCampaign(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on Campaign link
			click(Campaign.CAMPAIGN_LINK, "Campaign Link");
			// click on Manage Campaign link
			click(Campaign.MANAGE_CAMPAIGN_LINK, "Manage Campaign Link");
			// click on Edit Campaign link
			click(Campaign.EDIT_CAMPAIGN_LINK, "Edit Campaign Link");
			// Verify title of the page is Edit Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Edit Campaign", "Title of the Page");
			// click on Save button
			click(Campaign.SAVE_BTN, "Save Button");
			// Verify title of the page is Manage Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Manage Campaign", "Title of the Page");

		} catch (Exception e) {
			throw e;
		}

	}

	public void targetSearchRepresentation(String ReportSheet, int count) throws Throwable {
	
		int counter = 0;
		try {
			blnEventReport = true;
          
			// click on Campaign link
			
			click(Campaign.CAMPAIGN_LINK, "Campaign Link");
			// Verify title of the page is Manage Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Target Search - Representation", "Title of the Page");
			
			int latestCounter = selectTheCampaignTargetAndCampaign(counter);
			
			//SELECTED_CAMPAIGN
			String selectedCampaign = getText(Campaign.SELECTED_CAMPAIGN, "Selected Campaign");
			// Select todays date for campaign schedule date
			waitForElementPresent(Campaign.CAMPAIGN_SCHEDULE_DATE_CALENDAR, "Campaign schedule date Calender icon");
			click(Campaign.CAMPAIGN_SCHEDULE_DATE_CALENDAR, "Campaign schedule date Calender icon");
			waitForElementPresent(Campaign.TODAYSDATE, "Select todays date");
			click(Campaign.TODAYSDATE, "Select todays date");
        
			//FIRST_REMINDER_TEXTFIELD
			waitForElementPresent(Campaign.FIRST_REMINDER_TEXTFIELD ,"First reminder text field");
			String firstReminder = getText(Campaign.FIRST_REMINDER_TEXTFIELD ,"First reminder text field");
			if(firstReminder.equals("")) {
				type(Campaign.FIRST_REMINDER_TEXTFIELD ,"1","First reminder text field");
			}
	        //SECOND_REMINDER_TEXTFIELD	
			waitForElementPresent(Campaign.SECOND_REMINDER_TEXTFIELD ,"Second reminder text field");
			String secondReminder = getText(Campaign.SECOND_REMINDER_TEXTFIELD ,"Second reminder text field");
			if(secondReminder.equals("")) {
				type(Campaign.SECOND_REMINDER_TEXTFIELD ,"2","Second reminder text field");
			}
			// Click on schedule campaign target btn
			waitForElementPresent(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
			click(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
			//below one check for one error
			
			try {
				WebElement campaignError = null;
				campaignError = driver.findElement(Campaign.SCHEDULED_CAPMAIGN_ERROR);
				if(campaignError != null) {
					selectTheCampaignTargetAndCampaign(latestCounter);				
				// Click on schedule campaign target btn
				waitForElementPresent(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
				click(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");					
				}
			}catch(NoSuchElementException e) {}
			waitForElementPresent(Campaign.PAGE_TITLE,"Page Title");
			assertTextMatching(Campaign.PAGE_TITLE, "Scheduled Campaign Targets - "+selectedCampaign, "Page Title");

			
			//Below click on first link will not work in dynamic scenarios need to remove this
			// Click on First link
		/*	waitForElementPresent(Campaign.FIRST_CAMPAIGN_TARGET_NAME, "First Campaign target name");
			click(Campaign.FIRST_CAMPAIGN_TARGET_NAME, "First Campaign target name");*/
			/// till here
			
			String schedulerId = SQL_Queries.getTheCampaignSchedulerId().get(0);
			By campaignTargetName = By.xpath("//td[contains(text(),'"+ schedulerId + "')]/following-sibling::td/a[contains(@id,'TargetName')]");
			waitForElementPresent(campaignTargetName,"wait for the Campaign Target name");
			click(campaignTargetName, "Campaign Target name created in the previous step");
			// WebElement campaignTargetName = driver.findElement(By.xpath("//td[contains(text(),'"+ schedulerId + "')]/following-sibling::td/a[contains(@id,'TargetName')]"));
			// Click on email opt-out btn and check for the error msg
			waitForElementPresent(Campaign.EMAIL_OPT_OUT_BTN, "Email opt out button");
			click(Campaign.EMAIL_OPT_OUT_BTN, "Email opt out button");
			waitForElementPresent(Campaign.EMAIL_OPT_OUT_ERR_MSG, "Error msg for email opt out");
			assertElementPresent(Campaign.EMAIL_OPT_OUT_ERR_MSG, "Error msg for email opt out");

			//Implementation of Cancel is pending
			
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void targetSearchOnDemand(String ReportSheet, int count) throws Throwable {

		int counter = 0;
		try {
			blnEventReport = true;

			// click on Campaign link
			click(Campaign.CAMPAIGN_LINK, "Campaign Link");
			// Verify title of the page is Manage Campaign
			assertTextMatching(Campaign.PAGE_TITLE, "Target Search - Representation", "Title of the Page");
			
			click(Campaign.ON_DEMAND_LINK,"On Demad Link");
			assertTextMatching(Campaign.PAGE_TITLE, "Target Search - On Demand", "Title of the Page");

			int latestCounter = selectTheCampaignTargetAndCampaign(counter);
						
			//SELECTED_CAMPAIGN
			String selectedCampaign = getText(Campaign.SELECTED_CAMPAIGN, "Selected Campaign");
			// Select todays date for campaign schedule date
			waitForElementPresent(Campaign.CAMPAIGN_SCHEDULE_DATE_CALENDAR, "Campaign schedule date Calender icon");
			click(Campaign.CAMPAIGN_SCHEDULE_DATE_CALENDAR, "Campaign schedule date Calender icon");
			waitForElementPresent(Campaign.TODAYSDATE, "Select todays date");
			click(Campaign.TODAYSDATE, "Select todays date");

			//FIRST_REMINDER_TEXTFIELD
			waitForElementPresent(Campaign.FIRST_REMINDER_TEXTFIELD ,"First reminder text field");
			String firstReminder = getText(Campaign.FIRST_REMINDER_TEXTFIELD ,"First reminder text field");
			if(firstReminder.equals("")) {
				type(Campaign.FIRST_REMINDER_TEXTFIELD ,"1","First reminder text field");
			}
	        //SECOND_REMINDER_TEXTFIELD	
			waitForElementPresent(Campaign.SECOND_REMINDER_TEXTFIELD ,"Second reminder text field");
			String secondReminder = getText(Campaign.SECOND_REMINDER_TEXTFIELD ,"Second reminder text field");
			if(secondReminder.equals("")) {
				type(Campaign.SECOND_REMINDER_TEXTFIELD ,"2","Second reminder text field");
			}
			// Click on schedule campaign target btn
			waitForElementPresent(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
			click(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
			
             //below one check for one error			
			try {
				WebElement campaignError = null;
				campaignError = driver.findElement(Campaign.SCHEDULED_CAPMAIGN_ERROR);
				if(campaignError != null) {
					selectTheCampaignTargetAndCampaign(latestCounter);				
				// Click on schedule campaign target btn
				waitForElementPresent(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
				click(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");					
				}
			}catch(NoSuchElementException e) {}
			
			waitForElementPresent(Campaign.PAGE_TITLE, "Page Title");
			assertTextMatching(Campaign.PAGE_TITLE, "Scheduled Campaign Targets - "+selectedCampaign, "Page Title");

/*			// Click on First link
			waitForElementPresent(Campaign.FIRST_CAMPAIGN_TARGET_NAME, "First Campaign target name");
			click(Campaign.FIRST_CAMPAIGN_TARGET_NAME, "First Campaign target name");*/

			String schedulerId = SQL_Queries.getTheCampaignSchedulerId().get(0);
			By campaignTargetName = By.xpath("//td[contains(text(),'"+ schedulerId + "')]/following-sibling::td/a[contains(@id,'TargetName')]");
			waitForElementPresent(campaignTargetName,"wait for the Campaign Target name");
			click(campaignTargetName, "Campaign Target name created in the previous step");
			
			// Click on email opt-out btn and check for the error msg
			waitForElementPresent(Campaign.EMAIL_OPT_OUT_BTN, "Email opt out button");
			click(Campaign.EMAIL_OPT_OUT_BTN, "Email opt out button");
			waitForElementPresent(Campaign.EMAIL_OPT_OUT_ERR_MSG, "Error msg for email opt out");
			assertElementPresent(Campaign.EMAIL_OPT_OUT_ERR_MSG, "Error msg for email opt out");
			
			// Select apple from select existing campaign target dropdown
			/*selectByIndex(Campaign.SELECT_EXISTING_CAMPAIGN_DROPDOWN,3,
					"Select first value from select existing campaign target dropdown");

			// Click on clone button
			click(Campaign.CLONE_BTN, "Clone Button");

			// On clicking Print Button, New window is opened. Below steps manages Jumps
			// from Parent to child & back to Parent Window
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();

			// Verify there is no server error
			elementIsNotPresent(Campaign.SERVER_ERROR, "Server Error Text");

			driver.close();
			driver.switchTo().window(parentWindow);

			// select first value in select campaign dropdown
			selectByIndex(Campaign.SELECT_CAMPAIGN_DRPDWN, 1, "Select Campaign dropdown");
			// Click on save and search button					
			click(Campaign.TOP_SAVE_AND_SEARCH_BTN, "Save and Search Button");

			// cLick on View Count Details Link
			//click(Campaign.VIEW_COUNT_DETAILS_LINK, "View Count Details Link");

			// Select todays date for campaign schedule date
			click(Campaign.CAMPAIGN_SCHEDULE_DATE_CALENDAR, "Campaign schedule date Calender icon");
			click(Campaign.TODAYSDATE, "Select todays date");

			// Click on schedule campaign target btn
			click(Campaign.SCHEDULE_CAMPAIGN_TARGET_BTN, "Schedule Campaign Target Btn");
			assertTextMatching(Campaign.PAGE_TITLE, "Scheduled Campaign Targets - Paperless Invoice ", "Page Title");

			// Click on First link
			click(Campaign.FIRST_CAMPAIGN_TARGET_NAME, "First Campaign target name");

			// Click on email opt-out btn and check for the error msg
			click(Campaign.EMAIL_OPT_OUT_BTN, "Email opt out button");
			assertElementPresent(Campaign.EMAIL_OPT_OUT_ERR_MSG, "Error msg for email opt out");
*/
		} catch (Exception e) {
			throw e;
		}

	}

	public int  selectTheCampaignTargetAndCampaign(int counter) throws Throwable{
		//CHANGE_SELECT_EXISTING_CAMPAIGN
		int latestCounter = counter;
		for (int i=counter ; i<20 ; i++) {
			int flag = 0;
			waitForElementPresent(Campaign.CHANGE_SELECT_EXISTING_CAMPAIGN, "select existing campaign target dropdown");
			selectByIndex(Campaign.CHANGE_SELECT_EXISTING_CAMPAIGN,i+1, "select existing campaign target dropdown");
			// Click on clone button
			click(Campaign.CLONE_BTN, "Clone Button");
			// from Parent to child & back to Parent Window
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();

			// Verify there is no server error
			elementIsNotPresent(Campaign.SERVER_ERROR, "Server Error Text");

			driver.close();
			driver.switchTo().window(parentWindow);
			
			for (int  j=0 ; j<7 ; j++) {
			// select first value in select campaign dropdown
			selectByIndex(Campaign.SELECT_CAMPAIGN_DRPDWN, j+1, "Select Campaign dropdown");
			// Click on save and search button
			click(Campaign.TOP_SAVE_AND_SEARCH_BTN, "Save and Search Button");
			
            // cLick on View Count Details Link
			//click(Campaign.VIEW_COUNT_DETAILS_LINK, "View Count Details Link");
			//RESULTED_RECIPIENTS
			waitForElementPresent(Campaign.RESULTED_RECIPIENTS, "Resulted recipients count");
			String recipientCount = getText(Campaign.RESULTED_RECIPIENTS, "Resulted recipients count");
			if(Integer.parseInt(recipientCount) > 0) {
				flag = 1;
				break;
			
			}
		}
			latestCounter++;
			if(flag == 1) {
				break;
				}
			}
      return latestCounter;
	}

}
