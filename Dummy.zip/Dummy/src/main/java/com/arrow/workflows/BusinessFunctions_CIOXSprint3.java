package com.arrow.workflows;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CIOXSprint3 extends BusinessFunctions_CIOXSprint2{

	public void verifyMLSliderfields(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// Verify ML Slider on CES page is closed by default
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "ML Slider is closed by default on CES page");

			// click on arrow icon and verify the slider is opened
			click(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

			// verify ML Slider is opened
			assertElementPresent(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			// verify Slider title is "ML Extracted Data"
			assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider");

			// verify eye icon is displayed next to "ML Extracted Data" title
			assertElementPresent(SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");

			// click on eye icon and verify slider is transparent
			click(SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");
			assertElementPresent(SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");
			String style = getAttribute(SOP.SLIDER_ID, "style");
			assertTextContains(style, "background-color: transparent");

			// click on eye icon again
			click(SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");

			// ML Slider Fields block has 3 fields- Case#, Jurisdiction, Plaintiff, Defendant, Lawsuit type, Lawsuit subtype
			// Answer Date, Postmark Date, Priority Mail#, and following fields..
			assertElementPresent(SOP.CASEIDFIELD, "Case #");
			assertElementPresent(SOP.JURISDICTIONFIELD, "JURISDICTION FIELD");
			assertElementPresent(SOP.PLAINTIFF, "PLAINTIFF FIELD");
			assertElementPresent(SOP.DEFENDANT, "DEFENDANT FIELD");
			assertElementPresent(SOP.LAWSUITTYPEFIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(SOP.LAWSUITSUBTYPEFIELD, "LAWSUIT SUB TYPE FIELD");
			assertElementPresent(SOP.ANSWERDATE, "ANSWER DATE");
			assertElementPresent(SOP.POSTMARKDATE, "POSTMARK DATE");
			assertElementPresent(SOP.PRIORITYMAILIDFIELD, "PRIORITYMAIL ID FIELD");
			assertElementPresent(SOP.INITIAL_SUBSEQUENT_FIELD, "INITIAL SUBSEQUENT FIELD");
			assertElementPresent(SOP.COURTNAME, "COURT NAME FIELD");
			assertElementPresent(SOP.COURTADDRESS, "COURT ADDRESS FIELD");
			assertElementPresent(SOP.AGENCYNAME, "AGENCY NAME FIELD");
			assertElementPresent(SOP.ATTORNEYNAME, "ATTORNEY NAME FIELD");
			assertElementPresent(SOP.NATUREOFACTION, "NATUREOFACTION FIELD");
			assertElementPresent(SOP.AMOUNTDUE, "AMOUNT DUE FIELD");
			assertElementPresent(SOP.DOCUMENTTYPE, "DOCUMENT TYPE FIELD");
			assertElementPresent(SOP.ATTORNEYADDRESS, "ATTORNEY ADDRESS FIELD");
			assertElementPresent(SOP.AGENCYADDRESS, "AGENCY ADDRESS FIELD");

			// close the slider
			click(SOP.SLIDER_OPENED_BTN, "Slider Opened button");
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");
		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyMLSliderWithDataForWorksheetCreation(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of ML Slider");
			if(assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider")) {
				verifyMLSliderfields(ReportSheet, count);
			}
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMLSliderWithDataForWorksheetEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			verifyMLSliderfields(ReportSheet, count);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMLSliderWithDataForWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			//click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			verifyMLSliderfields(ReportSheet, count);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void verifyAdminMLSliderPage(String ReportSheet, int count) throws Throwable {
		try {

			// Click on Admin Module
			click(HomePage.ADMINLINK, "Admin Link");

			// Verify Whether section 'Manage ML Slider Fields' on the left nav
			// And click on 'Manage ML Slider Fields' link
			assertElementPresent(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");
			click(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");

			// Verify Title of the page is Manage CES ML Slider Fields
			assertTextMatching(Admin.PAGE_TITLE, "Manage ML Slider Fields", "Title of the page");

			// Verify the page has 2 blocks - SOP ML Slider Fields and Maintain
			// SOP ML
			// Slider Fields
			// and save & cancel buttons at the bottom
			isElementPresent(Admin.MLSLIDERFIELDSBLOCK, "ML Slider Fields Block");
			isElementPresent(Admin.MAINTAINMLSLIDERFIELDSBLOCK, "Maintain ML Slider Fields Block");
			isElementPresent(Admin.SAVEBTN, "Save Button");
			isElementPresent(Admin.CANCELBTN, "Cancel Button");

			// ML Slider Fields block has given fields- Case#,Jurisdiction,Plaintiff,Defendant,lawsuit type, lawsuitsubtype
			assertElementPresent(Admin.CASEID_FIELD, "Case #");
			assertElementPresent(Admin.JURISDICTION_FIELD, "JURISDICTION FIELD");
			assertElementPresent(Admin.PLAINTIFF_FIELD, "PLAINTIFF FIELD");
			assertElementPresent(Admin.DEFENDANT_FIELD, "DEFENDANT FIELD");
			assertElementPresent(Admin.LAWSUITTYPE_FIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(Admin.LAWSUITSUBTYPE_FIELD, "LAWSUIT SUB TYPE FIELD");
			assertElementPresent(Admin.ANSWER_DATE, "ANSWER DATE");
			assertElementPresent(Admin.POSTMARK_DATE, "POSTMARK DATE");
			assertElementPresent(Admin.PRIORITYMAILID_FIELD, "PRIORITYMAIL ID FIELD");
			assertElementPresent(Admin.INITIALSUBSEQUENT_FIELD, "INITIAL SUBSEQUENT FIELD");
			assertElementPresent(Admin.COURT_NAME, "COURT NAME FIELD");
			assertElementPresent(Admin.COURT_ADDRESS, "COURT ADDRESS FIELD");
			assertElementPresent(Admin.AGENCY_NAME, "AGENCY NAME FIELD");
			assertElementPresent(Admin.ATTORNEY_NAME, "ATTORNEY NAME FIELD");
			assertElementPresent(Admin.NATURE_OFACTION, "NATUREOFACTION FIELD");
			assertElementPresent(Admin.AMOUNT_DUE, "AMOUNT DUE FIELD");
			assertElementPresent(Admin.DOCUMENT_TYPE, "DOCUMENT TYPE FIELD");
			assertElementPresent(Admin.ATTORNEY_ADDRESS, "ATTORNEY ADDRESS FIELD");
			assertElementPresent(Admin.AGENCY_ADDRESS, "AGENCY ADDRESS FIELD");

			// Maintain ML Slider Fields block has 2 fields- Index and Name
			assertTextMatching(Admin.INDEX_FIELD, "Index", "Verify 1st col is Index");
			assertTextMatching(Admin.NAME_FIELD, "Name", "Verify 2nd col is Name");

			// Verify Fields can be moved within ML Slider Fields block
			draganddrop(Admin.CASEID_FIELD, Admin.JURISDICTION_FIELD, "CASE ID AND JURISDICTION FIELD DRAG AND DROP");
			click(Admin.SAVEBTN, "Save Button");

			//Verify ML Slider fields on Create Worksheet Page
			String esopId = entitySectionDetailsOnProcessingCES(ReportSheet, count);
			try {
				createWorksheetViaSOPList(ReportSheet, count, esopId);
				String jurisdiction = getText(SOP.JURISDICTIONFIELD, "Jurisdiction present as First Field on ML Slider pg.");
				String caseId = getText(SOP.CASEIDFIELD, "CaseId present as Second Field on ML Slider pg.");
				assertTextMatching(SOP.FIRSTELEMENT_ON_ML_SLIDER, jurisdiction, "Verify Jurisdiction as the First Field");
				assertTextMatching(SOP.SECONDELEMENT_ON_ML_SLIDER, caseId, "Verify CaseId as the Second Field");
				waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
				
				
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

				click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				// Click on Edit Worksheet
				waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
				click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
				waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
				assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
				// click on arrow icon and verify the slider is opened
				click(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

				// verify ML Slider is opened
				assertElementPresent(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

				// verify Slider title is "ML Extracted Data"
				assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider");
				assertTextMatching(SOP.FIRSTELEMENT_ON_ML_SLIDER, jurisdiction, "Verify Jurisdiction");
				assertTextMatching(SOP.SECONDELEMENT_ON_ML_SLIDER, caseId, "Verify CaseId");
				waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
				
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

				// Click on Admin Module
				click(HomePage.ADMINLINK, "Admin Link");

				// Verify Whether section 'Manage ML Slider Fields' on the left nav
				// And click on 'Manage ML Slider Fields' link
				assertElementPresent(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");
				click(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");

				draganddrop(Admin.JURISDICTION_FIELD, Admin.CASEID_FIELD, "CASE ID AND JURISDICTION FIELD DRAG AND DROP");
				click(Admin.SAVEBTN, "Save Button");

				//Verify page title 'Manage ML Slider Fields'
				assertTextMatching(Admin.PAGE_TITLE, "Manage ML Slider Fields", "Title of Manage ML Slider Fields Page");

			}
			catch (Exception e) {
				throw e;
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyNoQuicklogOnCreateWorksheet(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementNotPresent(SOP.QUICKLOG_BUTTON, "No Quicklog button present on Create Worksheet Page");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyEditedQuicklogWorksheet(String ReportSheet, int count) throws Throwable {

		try {
			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			// click on Worksheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.QUICKLOG_STATUS, "Quicklog", "Quicklog is the current status of worksheet");
			//click on Edit button on Worksheet Profile Page
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementNotPresent(SOP.QUICKLOG_BUTTON, "No Quicklog button present on Create Worksheet Page");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}





