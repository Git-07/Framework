package com.arrow.workflows;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.ManageDefaultAssignment_SOP;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP_Reconciliation extends BusinessFunctions_SOP {

	public void reconciliationLinks(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");

			// Click On Reconciliation from left nav bar
			click(SOP.RECONCILIATION_LEFT_NAV_LINK, "Reconciliation Link from left nav bar");
			assertTextMatching(SOP.PAGE_TITLE, "Reconciliation", "Page Title");
			assertElementPresent(SOP.TRACEABLE_MAIL_RECONCILIATION_SELECTED_TAB, "Traceable mail reconciliation tab");

			// select team,mailtype,no of days,calender,status and source
			click(SOP.ALABAMA_CT_REPS_TEAM_DRPDWN, "Select Alabama CT Reps from team dropdown");
			click(SOP.CERTIFIED_MAIL_MAIL_TYPE_DRPDWN, "Select Cerified Mail from Mail Type Dropdown");
			click(SOP.FIVE_DAY_NO_OF_DAYS_DRPDWN, "Select 5 Day from No. of days Dropdown");
			// Click on Calendar and select todays date
			click(SOP.CALENDAR, "Calendar Icon");
			click(SOP.TODAYSDATE, "Todays Date");
			click(SOP.GO_BUTTON, "Go Button");
			click(SOP.ALL_STATUS_DRPDWN, "Select All from status Dropdown");
			click(SOP.ALL_SOURCE_DRPDWN, "Select All from source Dropdown");
			click(SOP.GO_BUTTON, "Go Button");

			// Go to Process Server Reconciliation tab
			click(SOP.PROCESS_SERVER_RECONCILIATION_TAB, "Process Server reconciliation tab");
			assertElementPresent(SOP.PROCESS_SERVER_RECONCILIATION_SELECTED_TAB, "Process Server reconciliation tab");

			// select team,process server,no of days,calender,status
			click(SOP.ALABAMA_CT_REPS_TEAM_DRPDWN, "Select Alabama CT Reps from team dropdown");
			click(SOP.PROCESS_SERVER_SERVED_TYPE_DRPDWN, "Select Process Server from Served Type Dropdown");
			click(SOP.FIVE_DAY_NO_OF_DAYS_DRPDWN, "Select 5 Day from No. of days Dropdown");
			click(SOP.CALENDAR, "Calendar Icon");
			click(SOP.TODAYSDATE, "Todays Date");
			click(SOP.GO_BUTTON, "Go Button");
			click(SOP.ALL_STATUS_DRPDWN, "Select All from status Dropdown");
			click(SOP.GO_BUTTON, "Go Button");

			// Click On Calender from left nav bar
			click(SOP.CALENDER_LEFT_NAV_LINK, "Calender Link from left nav bar");
			assertTextMatching(SOP.PAGE_TITLE, "Reconcilation Calendar", "Page Title");

			// Click on Traceable mail Link
			click(SOP.TRACEABLE_MAIL_LINK, "Traceable Mail Link");
			assertElementPresent(SOP.TRACEABLE_MAIL_RECONCILIATION_SELECTED_TAB, "Traceable mail reconciliation tab");

			// Click On Calender from left nav bar
			click(SOP.CALENDER_LEFT_NAV_LINK, "Calender Link from left nav bar");
			assertTextMatching(SOP.PAGE_TITLE, "Reconcilation Calendar", "Page Title");

			// Click on Process Sever Link
			click(SOP.PROCESS_SERVER_LINK, "Process Server Link");
			assertElementPresent(SOP.PROCESS_SERVER_RECONCILIATION_SELECTED_TAB, "Process Server reconciliation tab");

		} catch (Exception e) {
			throw e;
		}
	}

	public void traceableMailReconciliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");

			// Click On Reconciliation from left nav bar
			click(SOP.RECONCILIATION_LEFT_NAV_LINK, "Reconciliation Link from left nav bar");
			assertTextMatching(SOP.PAGE_TITLE, "Reconciliation", "Page Title");
			assertElementPresent(SOP.TRACEABLE_MAIL_RECONCILIATION_SELECTED_TAB, "Traceable mail reconciliation tab");

			// Upload file on Reference Manifest
			uploadFile(fileName, SOP.CHOOSE_FILE_BUTTON, "Upload File");
			click(SOP.UPLOAD_BUTTON, "Upload Button");
			click(SOP.DELETE_BTN_RECONCILIATION, "Delete Button");

			// Add new Manifest
			waitForElementPresent(SOP.MANIFEST_ARTICLE_TEXTBOX, "Manifest Article Textbox");
			assertElementPresent(SOP.MANIFEST_ARTICLE_TEXTBOX, "Manifest Article Textbox");
			type(SOP.MANIFEST_ARTICLE_TEXTBOX, "appletesting", "Manifest Article Textbox");
			click(SOP.ADD_MANIFEST_BTN, "Add Button");
			click(SOP.MANIFEST_CHECKBOX, "Checkbox");
			waitForElementPresent(SOP.MANIFEST_ARTICLE_NUMBER, "Manifest Article Number");
			assertElementPresent(SOP.MANIFEST_ARTICLE_NUMBER, "Manifest Article Number");

			// Delete the manifest
			click(SOP.DELETE_BTN_MANIFEST, "Delete Button Reconciiation");

		} catch (Exception e) {
			throw e;
		}
	}

	public void processServerReconciliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");

			// Click On Reconciliation from left nav bar
			click(SOP.RECONCILIATION_LEFT_NAV_LINK, "Reconciliation Link from left nav bar");
			assertTextMatching(SOP.PAGE_TITLE, "Reconciliation", "Page Title");

			// Go to Process Server Reconciliation tab
			click(SOP.PROCESS_SERVER_RECONCILIATION_TAB, "Process Server reconciliation tab");
			assertElementPresent(SOP.PROCESS_SERVER_RECONCILIATION_SELECTED_TAB, "Process Server reconciliation tab");

			// Add new log
			type(SOP.TIME_TEXTBOX, "12:00", "Time Textbox");
			selectByIndex(SOP.PSNAME_DRPDWN, 1, "PSName Dropdown");
			type(SOP.SERVED_NAME, "apple", "Served Name Textbox");
			selectByIndex(SOP.NAME_TYPE_DRPDWN, 1, "Name Type Dropdown");
			type(SOP.NAME_TAKEN_UNDER_TEXTBOX, "apple", "Name Taken Under textbox");
			type(SOP.CASE_ID_TEXTBOX, "123456", "Case id textbox");
			selectByIndex(SOP.COMMENTS_DRPDWN, 1, "Comments Dropdown");
			selectByIndex(SOP.REMARKS_DRPDWN, 1, "Remarks Dropdown");
			click(SOP.ADD_MANIFEST_BTN, "Add Button");

			// Delete the log from the grid
			click(SOP.MANIFEST_CHECKBOX, "Checkbox");
			click(SOP.DELETE_BTN_MANIFEST, "Delete Button");

		} catch (Exception e) {
			throw e;
		}
	}

}
