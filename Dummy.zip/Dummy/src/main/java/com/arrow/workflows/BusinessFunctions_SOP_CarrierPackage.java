package com.arrow.workflows;

import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.TeamSOPDashboard;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_SOP_CarrierPackage extends BusinessFunctions_CommonCESAndWorksheet{
	

	public void createWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String lawsuitType=Excelobject.getCellData(ReportSheet, "Lawsuit Type", count);		
			//Create Worksheet Page 1
			selectBySendkeys(Carrier_SOP.METHOD_OF_SERVICE, "Fax", "Method Of Service");
			waitForElementPresent(Carrier_SOP.TIME_TEXTFIELD,"Text Field for Time");
			type(Carrier_SOP.TIME_TEXTFIELD,"08:00","Text Field for Time");
			click(Carrier_SOP.INITIAL_RADIOBTN, "Initiatl Radio Button");
			click(Carrier_SOP.CASE_NUMBER_NONE_RADIOBTN, "Initial Radio Button");
			click(Carrier_SOP.PLAINTIFF_NONE_RADIOBTN, "Plaintiff Radio Button");
			type(Carrier_SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", " Defendant/Creditor Name");
			click(Carrier_SOP.NEXT_BTN, "Next Button");
			// On Create Worksheet Step 2
			click(Carrier_SOP.COURT_NONE_RADIOBTN, "Court Radio Button");
			click(Carrier_SOP.NEXT_BTN, "Next Button");
			// On Create Worksheet Step 3
			type(Carrier_SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(Carrier_SOP.LAWSUITTYPE_DROPDOWN, lawsuitType, "LawSuitType Drpdwn");
			click(Carrier_SOP.ANSWER_NONE_RADIOBTN, "Answer Radio Button");
			click(Carrier_SOP.SAVE_BTN, "Save Button");
			
			
		} catch (Exception e) {
			throw e;
		}
		
	}
	
	
	public void carrierPackageSearchErrMsg(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String carrierTrackingId = Excelobject.getCellData(ReportSheet, "Carrier Tracking Id", count);
			// click on Carrier Package Search link
			click(HomePage.CARRIER_PACKAGE_SEARCH_LINK, "Carrier Package Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Carrier_SOP.CARRIER_TRACKING_ID, "Carrier Tracking ID Text box");
			// Enter a carrier tracking id and click on search button
			type(Carrier_SOP.CARRIER_TRACKING_ID, carrierTrackingId, "Carrier Tracking ID Text Box");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			// Verify No records found err msg is displayed
			waitForElementPresent(Carrier_SOP.NO_RECORDS_FOUND_ERR_MSG, "No Records Found Msg");
			assertElementPresent(Carrier_SOP.NO_RECORDS_FOUND_ERR_MSG, "No Records Found Msg");
			

		} catch (Exception e) {
			throw e;
		}
	}

	public void fedExIntEconomyDelivery(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			//String entityName=Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String participantName=Excelobject.getCellData(ReportSheet, "Participant Name", count);

			/*// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");	
			//Enter an entity name and click on search btn
			type(Carrier_SOP.ENTITY_NAME_TEXTFIELD,entityName,"Entity Name Text Field");
			click(Carrier_SOP.SEARCH_BTN,"Search Button");	
			//Select entity from the grid
			click(Carrier_SOP.SELECT_FIRST_ENTITY_ON_GRID,"Select First Entity On Grid");
			//Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(Carrier_SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,"Create Quicklog/Attempted/Rejection/Multiple Button");
			//Create a Worksheet
			createWorksheet(ReportSheet,count);		*/
			
			// Create a Worksheet
		    viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			waitForElementPresent(Carrier_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			//Click On Choose DI Button
			click(Carrier_SOP.CHOOSE_DI_BTN,"Choose DI Button");
			//Click on Actions List Btn and then click on Mangage Actions List Button
			click(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");
			click(Carrier_SOP.MANAGE_ACTIONS_ITEM_BTN,"Manage Actions List Button");
			//Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(Carrier_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");
			//Select Fed Ex International Economy from Delivery Method Drpdown
			click(Carrier_SOP.FED_EX_INTERNATIONAL_ECONOMY_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");
		    //Click On select Button of Recipient
		    click(Carrier_SOP.RECIPIENT_SELECT_BTN,"Recipient Select Button");
		    //Enter a participant name
		    type(Carrier_SOP.PARTICIPANTNAMEFIELD, participantName, "Participant Name Field");
		    click(Carrier_SOP.FINDBTN,"Find Button");
		    waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");	
			//Click On Add/Update Btn
			click(Carrier_SOP.ADDUPDATE_BTN, "Add/Update Btn");	
			//Verify The selected delivery method is not valid for this recipient. err msg is displayed
			assertTextMatching(Carrier_SOP.MANAGE_ACTIONS_ITEM_ERR_MSG, "The selected delivery method is not valid for this recipient.", "Manage Actions Item Err msg");
			
		    
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void executeSOPPapersWithTransmittal(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			//String entityName=Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String participantName=Excelobject.getCellData(ReportSheet, "Participant Name", count);

			/*// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");			
			//Enter an entity name and click on search btn
			type(Carrier_SOP.ENTITY_NAME_TEXTFIELD,entityName,"Entity Name Text Field");
			click(Carrier_SOP.SEARCH_BTN,"Search Button");
			//Select entity from the grid
			click(Carrier_SOP.SELECT_FIRST_ENTITY_ON_GRID,"Select First Entity On Grid");
			//Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(Carrier_SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,"Create Quicklog/Attempted/Rejection/Multiple Button");
			//Create a Worksheet
			createWorksheet(ReportSheet,count);	*/
			
			// Create a Worksheet
		    viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			waitForElementPresent(Carrier_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			//Click On Choose DI Button
			waitForElementToBePresent(Carrier_SOP.CHOOSE_DI_BTN,"Choose DI Button");
			assertElementPresent(Carrier_SOP.CHOOSE_DI_BTN,"Choose DI Button");
			click(Carrier_SOP.CHOOSE_DI_BTN,"Choose DI Button");
			//Click on Actions List Btn and then click on Mangage Actions List Button
			waitForElementToBePresent(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");
			assertElementPresent(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");
			click(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");
			click(Carrier_SOP.MANAGE_ACTIONS_ITEM_BTN,"Manage Actions List Button");		
			//Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(Carrier_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");		
			//Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(Carrier_SOP.FED_EX_PRIORITY_OVERNIGHT_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");		    
		    //Click On select Button of Recipient
		    click(Carrier_SOP.RECIPIENT_SELECT_BTN,"Recipient Select Button");		    
		    //Enter a participant name
		    type(Carrier_SOP.PARTICIPANTNAMEFIELD, participantName, "Participant Name Field");
		    click(Carrier_SOP.FINDBTN,"Find Button");
		    waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");			
			//Click On Add/Update Btn
			click(Carrier_SOP.ADDUPDATE_BTN, "Add/Update Btn");			
			//click again on Actions list Button
			click(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");			
			//click on Execute Button
			click(Carrier_SOP.EXECUTE_BTN,"Execute Button");			
			//Verify status of the action item is Executed
			assertElementPresent(Carrier_SOP.STATUS_OF_FIRST_ACTION_ITEM_ON_GRID, "Status of first Action Item");
			
		    
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	public void verificationOfFedExPackageDetails(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName=Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String participantName=Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");			
			//Enter an entity name and click on search btn
			type(Carrier_SOP.ENTITY_NAME_TEXTFIELD,entityName,"Entity Name Text Field");
			click(Carrier_SOP.SEARCH_BTN,"Search Button");
			//Select entity from the grid
			click(Carrier_SOP.SELECT_FIRST_ENTITY_ON_GRID,"Select First Entity On Grid");			
			//Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(Carrier_SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,"Create Quicklog/Attempted/Rejection/Multiple Button");			
			//Create a Worksheet
			createWorksheet(ReportSheet,count);			
			waitForElementPresent(Carrier_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");			
			//Click On Edit Button
			click(Carrier_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");			
			//Enter a reject reason and reason date
			selectByIndex(Carrier_SOP.REJECT_REASON_DRPDWN,1,"Selects first resaon from reject reason drop down");
			//Click on Calendar and select todays date
			click(Carrier_SOP.REJECT_CALENDAR, "Calendar Icon");
			click(Carrier_SOP.TODAYSDATE, "Todays Date");			
			//Click on save btn
			click(Carrier_SOP.TOP_SAVE_BTN,"Top Save Btn");			
			//Click On UPS package
			click(Carrier_SOP.CREATE_UPS_PACKAGE_BTN,"Create UPS Package Button");			
			//Verify Page Title is Select Carrier Package
			assertTextMatching(Carrier_SOP.PAGE_TITLE, "Select Carrier Package", "Title Of The Page");
			
			
		    
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	public void executeCopyOfTransmittal(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			//String entityName=Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String participantName=Excelobject.getCellData(ReportSheet, "Participant Name", count);

			/*// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(Carrier_SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");			
			//Enter an entity name and click on search btn
			type(Carrier_SOP.ENTITY_NAME_TEXTFIELD,entityName,"Entity Name Text Field");
			click(Carrier_SOP.SEARCH_BTN,"Search Button");			
			//Select entity from the grid
			click(Carrier_SOP.SELECT_FIRST_ENTITY_ON_GRID,"Select First Entity On Grid");			
			//Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(Carrier_SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,"Create Quicklog/Attempted/Rejection/Multiple Button");			
			//Create a Worksheet
			createWorksheet(ReportSheet,count);	*/
			
			// Create a Worksheet
		    viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			waitForElementPresent(Carrier_SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			//Click On Choose DI Button
			click(Carrier_SOP.CHOOSE_DI_BTN,"Choose DI Button");
			//Click on Actions List Btn and then click on Mangage Actions List Button
			click(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");
			click(Carrier_SOP.MANAGE_ACTIONS_ITEM_BTN,"Manage Actions List Button");
			//Select Copy of Transmittal From Deliverable Drp Dwn
			click(Carrier_SOP.COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");		
			//Select hand delivered by ct from Delivery Method Drpdown
			click(Carrier_SOP.HAND_DELIVERED_BY_CT_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");		    
		    //Click On select Button of Recipient
		    click(Carrier_SOP.RECIPIENT_SELECT_BTN,"Recipient Select Button");		    
		    //Enter a participant name
		    type(Carrier_SOP.PARTICIPANTNAMEFIELD, participantName, "Participant Name Field");
		    click(Carrier_SOP.FINDBTN,"Find Button");
		    waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");			
			//Click On Add/Update Btn
			click(Carrier_SOP.ADDUPDATE_BTN, "Add/Update Btn");			
			//click again on Actions list Button
			click(Carrier_SOP.ACTIONS_LIST_BTN,"Actions List Button");			
			//click on Execute Button
			click(Carrier_SOP.EXECUTE_BTN,"Execute Button");			
			//Verify status of the action item is Executed
			assertElementPresent(Carrier_SOP.STATUS_OF_FIRST_ACTION_ITEM_ON_GRID, "Status of first Action Item");
		} catch (Exception e) {
			throw e;
		}
	}
	

	/********************************************************************************************************
	 * Method Name : editCarrierPackage() 
	 * Author : Pradyumna 
	 * Description : This method will verify edit Carrier package and check its content
	 * Date of creation : 8/23/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String editCarrierPackage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String carrierTrackingId = Excelobject.getCellData(ReportSheet, "TrackingID", count);
			//Comment above one and Uncomment below for QA tracking ID - Content diff on both env
			//String carrierTrackingId = Excelobject.getCellData(ReportSheet, "QATrackingID", count);
			// click on Carrier Package Search link
			click(HomePage.CARRIER_PACKAGE_SEARCH_LINK, "Carrier Package Search");
			assertElementPresent(Carrier_SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Page");
			// Enter a carrier tracking id and click on search button
			type(Carrier_SOP.CARRIER_TRACKING_ID, carrierTrackingId, "Carrier Tracking ID Text Box");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			assertElementPresent(Carrier_SOP.STATUS_OPEN, "Status Open");
			assertElementPresent(Carrier_SOP.SHIPMENT_TYPE, "Shipment Type");
			assertElementPresent(Carrier_SOP.PACKAGE_TYPE, "Package Type");
			//Edit and Click on Cancel, No change in result should be displayed
			click(Carrier_SOP.EDIT_CARRIER_PACKAGE, "Edit Button");
			assertElementPresent(Carrier_SOP.EDIT_CARRIER_PACKAGE_PAGE, "Package Type");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(Carrier_SOP.STATUS_OPEN, "Status Open");
			assertElementPresent(Carrier_SOP.SHIPMENT_TYPE, "Shipment Type");
			assertElementPresent(Carrier_SOP.PACKAGE_TYPE, "Package Type");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : editCarrierPackage() 
	 * Author : Pradyumna 
	 * Description : This method will verify edit Carrier package and check its content
	 * Date of creation : 8/23/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String editAndSaveCarrierPackage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String carrierTrackingId = Excelobject.getCellData(ReportSheet, "TrackingID", count);
			//Comment above one and Uncomment below for QA tracking ID - Content diff on both env
			//String carrierTrackingId = Excelobject.getCellData(ReportSheet, "QATrackingID", count);
			
			// click on Carrier Package Search link
			click(HomePage.CARRIER_PACKAGE_SEARCH_LINK, "Carrier Package Search");
			assertElementPresent(Carrier_SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Page");
			// Enter a carrier tracking id and click on search button
			type(Carrier_SOP.CARRIER_TRACKING_ID, carrierTrackingId, "Carrier Tracking ID Text Box");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			assertElementPresent(Carrier_SOP.STATUS_OPEN, "Status Open");
			//Edit and Click on Cancel, No change in result should be displayed
			click(Carrier_SOP.EDIT_CARRIER_PACKAGE, "Edit Button");
			assertElementPresent(Carrier_SOP.EDIT_CARRIER_PACKAGE_PAGE, "Package Type");
			selectBySendkeys(Carrier_SOP.SHIPMENT_TYPE_DROPDOWN, "UPS 2nd Day Air", "UPS 2nd Day Air");
			click(Carrier_SOP.BOX_RADIO_BUTTON, "Box Radio Button");
			click(Carrier_SOP.PIGGYBACK_NO_BUTTON, "Piggyback No Button");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Carrier_SOP.EDITED_SHIPMENT_TYPE, "Shipment Type");
			assertElementPresent(Carrier_SOP.EDITED_PACKAGE_TYPE, "Package Type");
			assertElementPresent(Carrier_SOP.PIGGYBACK_NO, "Piggyback No");
			click(Carrier_SOP.EDIT_CARRIER_PACKAGE, "Edit Button");
			selectBySendkeys(Carrier_SOP.SHIPMENT_TYPE_DROPDOWN, "UPS Next Day Air", "UPS Next Day Air");
			click(Carrier_SOP.ENVELOPE_RADIO_BUTTON, "Envelope Radio Button");
			click(Carrier_SOP.PIGGYBACK_YES_BUTTON, "Piggyback Yes Button");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			assertElementPresent(Carrier_SOP.SHIPMENT_TYPE, "Shipment Type");
			assertElementPresent(Carrier_SOP.PACKAGE_TYPE, "Package Type");
			assertElementPresent(Carrier_SOP.PIGGYBACK_YES, "Piggyback Yes");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}	


	/********************************************************************************************************
	 * Method Name : worksheetLinkInPackage() 
	 * Author : Pradyumna 
	 * Description : This method will verify worksheet ID link displayed in Package
	 * Date of creation : 8/23/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String worksheetLinkInPackage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String carrierTrackingId = Excelobject.getCellData(ReportSheet, "TrackingID", count);
			//Comment above one and Uncomment below for QA tracking ID - Content diff on both env
			//String carrierTrackingId = Excelobject.getCellData(ReportSheet, "QATrackingID", count);
			
			// click on Carrier Package Search link
			click(HomePage.CARRIER_PACKAGE_SEARCH_LINK, "Carrier Package Search");
			assertElementPresent(Carrier_SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Page");
			// Enter a carrier tracking id and click on search button
			type(Carrier_SOP.CARRIER_TRACKING_ID, carrierTrackingId, "Carrier Tracking ID Text Box");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			//Click on Worksheet ID and observe the result
			click(WorksheetCreate.FIRST_SOP_DATA, "Worksheet ID");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : closedPackage() 
	 * Author : Pradyumna 
	 * Description : This method will verify Package having status as closed
	 * Date of creation : 8/23/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String closedPackage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String carrierTrackingId = Excelobject.getCellData(ReportSheet, "TrackingID", count);
			// click on Carrier Package Search link
			click(HomePage.CARRIER_PACKAGE_SEARCH_LINK, "Carrier Package Search");
			assertElementPresent(Carrier_SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Page");
			// Enter a carrier tracking id and click on search button
			type(Carrier_SOP.CARRIER_TRACKING_ID, carrierTrackingId, "Carrier Tracking ID Text Box");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			//Click on Worksheet ID and observe the result
			assertElementPresent(Carrier_SOP.CLOSED_STATUS, "Closed Status");
			assertElementPresent(Carrier_SOP.DELIVERY_STATUS, "Delivered Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : undeliveredPackage() 
	 * Author : Pradyumna 
	 * Description : This method will verify Package having status as Undelivered
	 * Date of creation : 8/23/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	
	public String undeliveredPackage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String carrierTrackingId = Excelobject.getCellData(ReportSheet, "TrackingID", count);
			// click on Carrier Package Search link
			click(HomePage.CARRIER_PACKAGE_SEARCH_LINK, "Carrier Package Search");
			assertElementPresent(Carrier_SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Page");
			// Enter a carrier tracking id and click on search button
			type(Carrier_SOP.CARRIER_TRACKING_ID, carrierTrackingId, "Carrier Tracking ID Text Box");
			click(Carrier_SOP.SEARCH_BTN, "Search Button");
			waitForElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			assertElementPresent(TeamSOPDashboard.CARRIER_PACKAGE_PROFILE, "Carrier Package Profile");
			//Click on Worksheet ID and observe the result
			assertElementPresent(Carrier_SOP.UNDELIVERED_STATUS, "Undelivered Status");
			assertElementPresent(Carrier_SOP.DELIVERY_STATUS_UNAVAILABLE, "Unavailable Status");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
