package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CIOX extends BusinessFunctions{
	
	public String verifyNOAfieldstMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --",
					"Amount $",
					"Breach of Contract",
					"Breach of Contract -",
					"Class Action -",
					"Continue withholding the nonexempt earnings of the...", "Continuing lien is extended until",
					"Default Judgment",
					"Hearing has been scheduled", "Lien - Amount $",
					"Motion for Summary Final Judgment of Foreclosure", "Notice of hearing", "Order of continuing lien",
					"Pertaining to", "Product Name: VIN:",
					"Release of Garnishment",
					"Request for status of Garnishment previously serve...", "Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation", "Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());	
				}
                compareTwoArrayList(updatedNOAList, originalNOAList);
			}

		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
		
	}

	public String createWorksheetMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String lawsuitType = Excelobject.getCellData(ReportSheet, "LawsuitType", count);
			String amountDue = Excelobject.getCellData(ReportSheet, "AmountDue", count);

			// Create Worksheet Page
			if (verifyIfElementPresent(SOP.METHOD_OF_SERVICE, "Method of Service")) {
				selectBySendkeys(SOP.METHOD_OF_SERVICE, "Fax", "Method Of Service as Fax");
				waitForElementPresent(SOP.TIME_TEXTFIELD, "Text Field for Time");
				type(SOP.TIME_TEXTFIELD, "08:00", "Text Field for Time");
			}
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYFACILITY, "New York Facility 1 (LIS)");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYTEAM, "CT - New York SOP Team");
			click(WorksheetCreate.EDIT_RECEIVED_BYNY, "TEST New York SOP Team");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "123-234", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Entity Radio Button");
			click(WorksheetCreate.ENTITY_SELECT, "Select Entity Button");
			assertElementPresent(WorksheetCreate.ENTITY_NAME_SEARCH, "Entity Search Page");
			click(Generic.CANCEL, "Cancel Button");
			// Select Unidentified Radio Button
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			selectBySendkeys(WorksheetCreate.ENTITY_NAME, "Entity Name for Testing", "Enter Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Select Alabama");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Alabama", "Select Alabama");
			
            // Create Worksheet Step 2
			click(WorksheetCreate.RADIO_BUTTON_COURT, "Court Radio Button");
			selectBySendkeys(WorksheetCreate.COURT, "U.S. Marshall", "Court");
			click(WorksheetCreate.RADIO_BUTTON_AGENCY, "Agency Radio Button");
			selectBySendkeys(WorksheetCreate.AGENCY, "U.S. Marshall", "Agency");
			click(WorksheetCreate.RADIO_BUTTON_SENDER, "Attorney Radio Button");
			selectBySendkeys(WorksheetCreate.ATTORNEY_OR_SENDER, "Adam Cooper", "Attorney");

			// Create Worksheet Step 3
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(SOP.LAWSUITTYPE_DROPDOWN, lawsuitType, "LawSuitType Drpdwn");
			verifyNOAfieldstMethod(ReportSheet, count);
			/*List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --",
					"Amount $",
					"Breach of Contract",
					"Breach of Contract -",
					"Class Action -",
					"Continue withholding the nonexempt earnings of the...", "Continuing lien is extended until",
					"Default Judgment",
					"Hearing has been scheduled", "Lien - Amount $",
					"Motion for Summary Final Judgment of Foreclosure", "Notice of hearing", "Order of continuing lien",
					"Pertaining to", "Product Name: VIN:",
					"Release of Garnishment",
					"Request for status of Garnishment previously serve...", "Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation", "Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());	
				}
                compareTwoArrayList(updatedNOAList, originalNOAList);
			}*/
			type(WorksheetCreate.AMOUNT_DUE, "200", "Amount Due");
			click(WorksheetCreate.RADIO_BUTTON_ANSWERDATE, "Answer Radio Button");
			click(WorksheetCreate.FIRST_ANSWER_DATE, "First Answer");
			selectBySendkeys(WorksheetCreate.ANSWER_DATE, "Immediately", "Answer Date Selected");
			click(WorksheetCreate.INTERNAL_COMMENTS_FIRST_OPTION, "Internal Comments First Option");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
		}
			catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}


	public String verifyNOAWorksheetCreate(String reportSheet, int count) throws Throwable{

		try {
			blnEventReport = true;

			// click on SOP List link on Home page
			click(HomePage.SOP_LIST_LINK, "SOP List Link");
			assertElementPresent(WorksheetCreate.SOP_LIST_PAGE, "SOP List Page");
			if (isElementPresent(WorksheetCreate.CREATE_WORKSHEET, "Create Worksheet")) {
				click(WorksheetCreate.VIEW_WORKSHEET, "View Worksheet Button");
				// Close the view pop up window once viewed
				String parentWindow = driver.getWindowHandle();
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWindow);
				// if(verifyIfElementPresent(WorksheetCreate.CREATE_WORKSHEET, "Create
				// Worksheet")) {
				click(WorksheetCreate.CREATE_WORKSHEET, "Create Worksheet");
				// Thread.sleep(500);
				if (verifyIfElementPresent(WorksheetCreate.ENTITY_NAME_SEARCH, "Entity Search Page")) {
					selectBySendkeys(WorksheetCreate.ENTITY_SEARCH_NAME, "apple", "Entity Name");
					click(WorksheetCreate.ENTITY_SEARCH, "Entity Search");
					click(Generic.SELECT_BUTTON, "Select Button");
				}
				assertElementPresent(WorksheetCreate.CREATE_WORKSHEET_SINGLE, "Create Worksheet Pg.");
				// Create Worksheet Method Called
				createWorksheetMethod(reportSheet, count);
				click(Generic.SAVE, "Save Button");
				waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			} else {
				System.out.println("Create Worksheet field is not present on page");
			}

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}
	
	public String verifyNOAWorksheetEdit(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "Test-123-456", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Test-Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			// Select Unidentified Entity and Rep
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			type(WorksheetCreate.ENTITY_NAME, "Test Entity Name", "Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Domestic Jurisdiction");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Hawaii", "Jurisdiction for Rep");
			verifyNOAfieldstMethod(ReportSheet, count);
			/*List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --",
					"Amount $",
					"Breach of Contract",
					"Breach of Contract -",
					"Class Action -",
					"Continue withholding the nonexempt earnings of the...", "Continuing lien is extended until",
					"Default Judgment",
					"Hearing has been scheduled", "Lien - Amount $",
					"Motion for Summary Final Judgment of Foreclosure", "Notice of hearing", "Order of continuing lien",
					"Pertaining to", "Product Name: VIN:",
					"Release of Garnishment",
					"Request for status of Garnishment previously serve...", "Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation", "Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();
				//int i=0;

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());
					
				}
				
				compareTwoArrayList(updatedNOAList, originalNOAList);
			}*/
			
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(Generic.SAVE, "Save Button");
			// Verify all text entered during Edit Worksheet
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.EDITED_ENTITY_NAME, "Edited Entity Name");
			assertElementPresent(WorksheetCreate.EDITED_REP_JURISDICTION, "Edited Rep Jurisdiction");
			assertElementPresent(WorksheetCreate.EDITED_CASE, "Edited Case ID");
			assertElementPresent(WorksheetCreate.EDITED_PLAINTIFF, "Edited Plaintiff");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyNOAWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			
			//click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");
			
			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			click(Generic.CANCEL_BUTTON, "Cancel Btn");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Review Worksheet
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_BUTTON, "Review Worksheet");
			click(WorksheetCreate.REVIEW_WORKSHEET_BUTTON, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "Test-123-456", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Test-Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			// Select Unidentified Entity and Rep
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			type(WorksheetCreate.ENTITY_NAME, "Test Entity Name", "Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Domestic Jurisdiction");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Hawaii", "Jurisdiction for Rep");
			verifyNOAfieldstMethod(ReportSheet, count);
			/*List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --",
					"Amount $",
					"Breach of Contract",
					"Breach of Contract -",
					"Class Action -",
					"Continue withholding the nonexempt earnings of the...", "Continuing lien is extended until",
					"Default Judgment",
					"Hearing has been scheduled", "Lien - Amount $",
					"Motion for Summary Final Judgment of Foreclosure", "Notice of hearing", "Order of continuing lien",
					"Pertaining to", "Product Name: VIN:",
					"Release of Garnishment",
					"Request for status of Garnishment previously serve...", "Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation", "Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();
				//int i=0;

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());
					
				}
				
				compareTwoArrayList(updatedNOAList, originalNOAList);
			}*/

			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(Generic.CANCEL_BUTTON, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}



