package com.arrow.workflows;


import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SopMessages_SOP;

public class BusinessFunctions_SOP_Messages  extends BusinessFunctions_SOP{
	
	public void myActiveMessages(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");
			//Click On My Messages from left nav bar
			click(SOP.MY_MESSAGES,"My Messages Link from left nav bar");
			//Select first view button from the grid
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//click on Back to Messages Btn
			click(SopMessages_SOP.BACK_TO_MESSAGES_BTN,"Back To Messages Btn");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Click On Reply Button
			click(SopMessages_SOP.REPLY_BTN,"Reply Button");
			//Verify the title of the page is "Reply Message" and click on back btn
			assertElementPresent(SopMessages_SOP.REPLY_MESSAGE_PAGE_TITLE, "Page Title");
			click(SopMessages_SOP.BACK_BTN,"Back Button");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Click On Close Conversation Button
			//[11/6/2019][Paddy] - Updated below line
			//click(SopMessages_SOP.CLOSE_CONVERSATION_BTN,"Close Conversation Button");
			click(SopMessages_SOP.BACK_TO_MESSAGES_BTN,"Back To Messages Btn");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Click On Send New Messages Button
			click(SopMessages_SOP.SEND_NEW_MESSAGES_BTN,"Send New Messages Button");
			//Verify the title of the page is "Create Message" and click on back btn
			assertElementPresent(SopMessages_SOP.CREATE_MESSAGE_PAGE_TITLE, "Page Title");	
			
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void myTeamsActiveMessages(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");
			//Click On My Messages from left nav bar
			click(SOP.MY_MESSAGES,"My Messages Link from left nav bar");
			//Click On My Team's Active Messages Tab
			click(SopMessages_SOP.MY_TEAMS_ACTIVE_MESSAGES_TAB,"My Teams Active Messages Tab");
			//Select first view button from the grid
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//click on Back to Messages Btn
			click(SopMessages_SOP.BACK_TO_MESSAGES_BTN,"Back To Messages Btn");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Click On Reply Button
			click(SopMessages_SOP.REPLY_BTN,"Reply Button");
			//Verify the title of the page is "Reply Message" and click on back btn
			assertElementPresent(SopMessages_SOP.REPLY_MESSAGE_PAGE_TITLE, "Page Title");
			click(SopMessages_SOP.BACK_BTN,"Back Button");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Click On Close Conversation Button
			//[11/6/2019][Paddy] - Updated below line
			//click(SopMessages_SOP.CLOSE_CONVERSATION_BTN,"Close Conversation Button");
			click(SopMessages_SOP.BACK_TO_MESSAGES_BTN,"Back To Messages Btn");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Click On Send New Messages Button
			click(SopMessages_SOP.SEND_NEW_MESSAGES_BTN,"Send New Messages Button");
			//Verify the title of the page is "Create Message" and click on back btn
			assertElementPresent(SopMessages_SOP.CREATE_MESSAGE_PAGE_TITLE, "Page Title");	
			
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void myMessageHistory(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");
			//Click On My Messages from left nav bar
			click(SOP.MY_MESSAGES,"My Messages Link from left nav bar");
			//Click On My Team's Active Messages Tab
			click(SopMessages_SOP.MY_MESSAGE_HISTORY_TAB,"My Message History Tab");
			//Select first view button from the grid
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//click on Back to Messages Btn
			click(SopMessages_SOP.BACK_TO_MESSAGES_BTN,"Back To Messages Btn");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Verify Reply Button and Close Conversation buttons are disabled
			getAttribute(SopMessages_SOP.REPLY_BTN, "disabled");
			getAttribute(SopMessages_SOP.CLOSE_CONVERSATION_BTN,"disabled");
			//Click On Send New Messages Button
			click(SopMessages_SOP.SEND_NEW_MESSAGES_BTN,"Send New Messages Button");
			//Verify the title of the page is "Create Message" and click on back btn
			assertElementPresent(SopMessages_SOP.CREATE_MESSAGE_PAGE_TITLE, "Page Title");	
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void myTeamsMessageHistory(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");
			//Click On My Messages from left nav bar
			click(SOP.MY_MESSAGES,"My Messages Link from left nav bar");
			//Click On My Team's Active Messages Tab
			click(SopMessages_SOP.MY_TEAMS_MESSAGE_HISTORY_TAB,"My Teams Message History Tab");
			//Select first view button from the grid
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//click on Back to Messages Btn
			click(SopMessages_SOP.BACK_TO_MESSAGES_BTN,"Back To Messages Btn");
			//Verify the title of the page is "Messages"
			assertElementPresent(SopMessages_SOP.MESSAGES_PAGE_TITLE, "Page Title");
			//Click On View Button Again
			click(SopMessages_SOP.FIRST_VIEW_BTN_ON_GRID,"First View Button On Grid");
			//Verify Reply Button and Close Conversation buttons are disabled
			getAttribute(SopMessages_SOP.REPLY_BTN, "disabled");
			getAttribute(SopMessages_SOP.CLOSE_CONVERSATION_BTN,"disabled");
			//Click On Send New Messages Button
			click(SopMessages_SOP.SEND_NEW_MESSAGES_BTN,"Send New Messages Button");
			//Verify the title of the page is "Create Message" and click on back btn
			assertElementPresent(SopMessages_SOP.CREATE_MESSAGE_PAGE_TITLE, "Page Title");	
			
		} catch (Exception e) {
			throw e;
		}

	}





}
