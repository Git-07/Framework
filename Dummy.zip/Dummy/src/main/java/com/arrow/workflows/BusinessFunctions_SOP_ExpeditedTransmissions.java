package com.arrow.workflows;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP_ExpeditedTransmissions extends BusinessFunctions {

	public String expeditedTransmissions(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");

			// Click on SOP Volume link
			click(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmissions Page");
			assertTextMatching(SOP.PAGE_TITLE, "Expedited Transmissions", "Page Title");

			// Click on first pdf on the grid
			click(SOP.PDF_BTN, "Pdf Button");
			// View PDF
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(ActionItems_SOP.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);

			// Click on Resend Button
			click(SOP.FIRST_RESEND_BTN, "Resend Button on grid");

			// Click on checkbox and then click on resend button
			click(SOP.FIRST_CHECKBOX, "First Checkbox on grid");
			click(SOP.RESEND_BTN, "Resend Button on page");

			// Click on first delete button
			click(SOP.FIRST_DELETE_BTN_ON_GRID, "Delete Button");
			cancelpopup();

			// Click on Refresh Button
			click(SOP.REFRESH_BTN, "Refresh Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
