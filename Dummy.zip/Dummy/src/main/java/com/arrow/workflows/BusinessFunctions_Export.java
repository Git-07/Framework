package com.arrow.workflows;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.RenewalInvoice;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.XSOP;

public class BusinessFunctions_Export extends BusinessFunctions {

	public void fileAndEventSelectionPageCountAndDownloadFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String fileNameHavingErrorRecords = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");

			// Select an Event from Dropdown and click on choose file button
			// selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, delawareEventName,
			// "Select a Delaware Event from delaware event drop down box");
			click(Admin.TEST_RADIO_BTN, "Test Radio Button");
			uploadFile(fileNameHavingErrorRecords, Admin.CHOOSE_FILE_BUTTON, "Upload File");

			// Upload the file
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			// TODO Verify Count
			// Verify File uploaded is downloadable
			click(Admin.FIRST_FILE_NAME_ON_GRID, "Download File Uploaded On Grid");

		} catch (Exception e) {
			throw e;
		}

	}

	public void uploadGoodRecordAndBadRecordFile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware
			// Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String badRecordCSVfileName = Excelobject.getCellData(ReportSheet, "Bad Record CSV File Name", count);
			String goodRecordCSVfileName = Excelobject.getCellData(ReportSheet, "Good Record CSV File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");

			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(30000);
			refreshPage();

			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			// Upload a bad record csv File
			uploadFile(badRecordCSVfileName, Admin.CHOOSE_FILE_BTN, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");
			// Verify the error message
			assertTextMatching(Admin.ERROR_MSG, "There is invalid data in uploaded file at line 2.", "Error Message");
			click(Admin.CANCEL_BTN, "Cancel Button");
			Thread.sleep(2000);
			isElementNotPresent(Admin.ERROR_MSG, "Error Message");

			// Upload good record csv File
			uploadFile(goodRecordCSVfileName, Admin.CHOOSE_FILE_BTN, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			isElementNotPresent(Admin.UPLOAD_BUTTON, "Upload Button");
			isElementNotPresent(Admin.CHOOSE_FILE_BTN, "Upload File");
			isElementNotPresent(Admin.CANCEL_BTN, "Cancel Button");
			assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, "Acknowledged By Printer", "Status");

			click(Admin.FILE_LINK, "File Link");
			assertTextMatching(Admin.UPDATED_BY, "TEST New York SOP Team", "Updated By");
			click(Admin.DELETE_IMG, "Delete Button");
			handlepopup();

			Thread.sleep(2000);

			// Upload good record csv File
			uploadFile(goodRecordCSVfileName, Admin.CHOOSE_FILE_BTN, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(2000);
			click(Admin.CREATE_COMM_BTN, "Create COMM Button");
			cancelpopup();

			click(Admin.CREATE_COMM_BTN, "Create COMM Button");
			handlepopup();
			assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, "Creating COMM", "Status");
			isElementNotPresent(Admin.DELETE_IMG, "Delete Button");
			getAttribute(Admin.CREATE_COMM_BTN, "disabled");

			flag = true;
			do {
				if (verifyIfElementPresent(Admin.DELETE_IMG, "Delete Button")) {
					assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, "COMM Error", "Status");
					getAttribute(Admin.CREATE_COMM_BTN, "disabled");

					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);
			click(Admin.DELETE_IMG, "Delete Button");
			handlepopup();
			assertElementPresent(Admin.UPLOAD_BUTTON, "Upload Button");
			click(Admin.BACK_BTN, "Back Button");
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

	public void sortAndExportSubGroups(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Profile", "Verify Page Title is Affiliation Profile");

			// Click on Sub Groups Link
			click(Affiliation.SUBGROUPSBTN, "Sub Group left nav link");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Sub Groups",
					"Verify Page Title is Affiliation Sub Groups");

			// Check whether All sorting links are present
			click(Affiliation.ACTIVE_SUB_GROUP_NAME_SORT_LINK, "Active Sort By Sub Group Name Link");
			isElementPresent(Affiliation.INACTIVE_SUB_GROUP_TYPE_SORT_LINK, "Inactive Sort By Sub Group Type Link");
			isElementPresent(Affiliation.INACTIVE_MEMBER_COUNT_SORT_LINK, "Inactive Sort By Member Count Link");

			click(Affiliation.INACTIVE_SUB_GROUP_TYPE_SORT_LINK, "Inactive Sort By Sub Group Type Link");
			isElementPresent(Affiliation.ACTIVE_SUB_GROUP_TYPE_SORT_LINK, "Active Sort By Sub Group Type Link");
			click(Affiliation.INACTIVE_MEMBER_COUNT_SORT_LINK, "Inactive Sort By Member Count Link");
			isElementPresent(Affiliation.ACTIVE_MEMBER_COUNT_SORT_LINK, "Active Sort By Member Count Link");

			// Click On Export Button
			click(Affiliation.EXPORT_BTN, "Export Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Sub Groups",
					"Verify Page Title is Affiliation Sub Groups");

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyXSOPInvoicesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Affiliation.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Click on XSOP Invoices button from left nav links on affiliation profile page
			click(Affiliation.XSOP_INVOICES_LEFT_NAV_LINK, "Members Button");
			assertTextMatching(Affiliation.PAGE_TITLE, "XSOP Invoices", "Page Title");

			// Click o Generate Current Estimate Button
			click(Affiliation.GENERATE_CURRENT_ESTIMATE_BTN, "Generate Curren Estimate");
			Thread.sleep(3000);

			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");

			assertElementPresent(Entity.ESTIMATE_EXCESSS_SOP_TEXT, "Estimate Excess SOP Text");

			driver.close();
			driver.switchTo().window(parentWindow);
			waitForElementPresent(Affiliation.GENERATE_DETAIL_REPORT_BTN, "Generate Detail Report Button");

			// Click on Generate Detail Report Button on grid
			click(Affiliation.GENERATE_DETAIL_REPORT_BTN, "Generate Detail Report Button");
			waitForElementPresent(Affiliation.FIRST_XSOP_INVOICE_ON_GRID, "first invoice on the grid");

			// Click on first invoice on the grid
			click(Affiliation.FIRST_XSOP_INVOICE_ON_GRID, "first invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "XSOP Invoice Profile", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void subGroupBundleMaintainance(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Affiliation.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Click On View Definition Button on Enabled Bundle Grid
			click(Affiliation.VIEW_DEFINITION_BTN, "View Definition Button");

			// Click on Bundle Name link in Bundle Section
			click(Affiliation.BUNDLE_NAME_LINK, "Bundle Name Link");
			assertTextMatching(Affiliation.PAGE_TITLE, "Sub Group Bundle Maintenance", "Page Title");

			// select Reparms bundle from bundle dropdown
			click(Affiliation.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from Bundle dropdown");
			// Click on Calendar icon of End Date and select todays date
			click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
			click(Affiliation.TODAYSDATE, "Todays Date");
			// Enter Comments
			type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

			// Select a sub group and click on Disable button
			click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
			click(Affiliation.DISABLE_BTN, "Disable Button");

			// Click On Inactive Bundle Subgroups Tab
			click(Affiliation.INACTIVE_BUNDLE_SUBGROUPS_TAB, "Inactive Bundle Subgroups Tab");

			// select Rep and Annual Report from bundle dropdown
			click(Affiliation.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from Bundle dropdown");

			// Click on Calendar icon of Effective Start Date and select
			// todays date
			click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
			click(Affiliation.TODAYSDATE, "Todays Date");

			// Enter Comments
			type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");
			// Select a sub group and click on Enable button
			click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
			click(Affiliation.ENABLE_BTN, "Enable Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void exportButtonOnCommentsScreen(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

		// click on Entity Search link
		click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		// Click on Comments Btn from left nav link
		click(Entity.COMMENT, "Comment Section");
		// click on Export Button
		click(Entity.COMMENT_SCREEEN_EXPORT_BUTTON, "Export Btn on Comments Screen");
		// Click on Sort By Author
		click(Entity.AUTHOR_SORTBY_LINK, "Author Sort By Link");
		isElementPresent(Entity.AUTHOR_SORTBY_LINK_BOLD, "Bold Author Link");

	}

	/********************************************************************************************************
	 * Method Name : ExportRepresentation() Author : Pradyumna Description : This
	 * method will Export Rep Present on page Date of creation : 7/17/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ExportRepresentation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Top Nav link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			type(Generic.ENTITY_ID, strEntityID, "Entity ID");
			click(Generic.SEARCH, "Search Button");
			// Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			click(Generic.EXPORT_BUTTON, "Click on Export Button");
			// TODO Verify if Export has been done successfully

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void outputFilesPageVerification(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String fileNames = Excelobject.getCellData(ReportSheet, "File Names", count);
			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 2,
					"Select a Delaware Event from delaware event drop down box");
			//selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, editEventName,
			//		"Select a Delaware Event from delaware event drop down box");
			
            // Upload 1 kb File
			uploadFile(fileNames, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");
			
			Thread.sleep(5000);
			
			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;
				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);


			String eventId = getText(Admin.FIRST_EVENT_ID_ON_GRID, "First Event Id On Grid");
			String eventName = getText(Admin.FIRST_EVENT_NAME_ON_GRID, "First Event Name On Grid");
			String isProd = getText(Admin.FIRST_IS_PROD_ON_GRID, "First Is Prod On Grid");
			String status = getText(Admin.FIRST_STATUS_ON_GRID, "First Status On Grid");

			System.out.println(eventId + "." + eventName + "." + isProd + "." + status);
			// Click on First View Results Link
			if (isProd.equalsIgnoreCase("Y")) {
				click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
				assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");

				// Verify event name,test/production and event id on context bar
				assertTextMatching(Admin.EVENT_NAME_ON_CONTEXTBAR, eventName, "Event Name On Context bar");
				String eventIdOnContextBar = getText(Admin.EVENT_ID_ON_CONTEXTBAR, "Event Id On Context Bar");
				assertTextContains(eventIdOnContextBar, eventId);
				/*
				 * if (isProd.equalsIgnoreCase("N")) {
				 * assertElementPresent(Admin.TEST_ON_CONTEXTBAR, "Test On Context bar");
				 * 
				 * } else if (isProd.equalsIgnoreCase("Y")) {
				 * assertElementPresent(Admin.PRODUCTION_ON_CONTEXTBAR,
				 * "Production On Context bar");
				 * 
				 * }
				 */ assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, status, "Status on output files page");
				assertElementPresent(Admin.PRINTER_OUTPUT_FILES_LABEL, "Printer output files label");
				assertElementPresent(Admin.ADDITIONAL_OUTPUT_FILES_LABEL, "Additional output files label");
				assertElementPresent(Admin.PRINTER_ACKNOWLEDGE_FILES_LABEL, "Printer Acknowledge files label");
				click(Admin.PRINT_FILE, "Print File");
				click(Admin.DISCREPANCY_FILE, "Discrepancy File");
				click(Admin.SUPPRESSION_FILE, "Suppression File");
				click(Admin.UNMATCH_FILE, "Unmatch File");
				assertElementPresent(Admin.CHOOSE_FILE_BTN, "Choose File Button");
				assertElementPresent(Admin.UPLOAD_BUTTON, "Upload File Button");
				assertElementPresent(Admin.CANCELBTN, "Cancel Button");
				click(Admin.BACKBTN, "Back Button");
				assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			} else {
				click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
				assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");

				// Verify event name,test/production and event id on context bar
				assertTextMatching(Admin.EVENT_NAME_ON_CONTEXTBAR, eventName, "Event Name On Context bar");
				String eventIdOnContextBar = getText(Admin.EVENT_ID_ON_CONTEXTBAR, "Event Id On Context Bar");
				assertTextContains(eventIdOnContextBar, eventId);
				assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, status, "Status on output files page");
				assertElementPresent(Admin.PRINTER_OUTPUT_FILES_LABEL, "Printer output files label");
				assertElementPresent(Admin.ADDITIONAL_OUTPUT_FILES_LABEL, "Additional output files label");
				
				click(Admin.PRINT_FILE, "Print File");
				click(Admin.DISCREPANCY_FILE, "Discrepancy File");
				click(Admin.SUPPRESSION_FILE, "Suppression File");
				click(Admin.UNMATCH_FILE, "Unmatch File");
				click(Admin.BACKBTN, "Back Button");
				assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			}

		} catch (Exception e) {
			throw e;
		}

	}

	public void printerAcknowledgeFilesSection(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware
			// Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");
			click(Admin.TEST_RADIO_BTN, "Test Radio Button");

			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(30000);
			refreshPage();

			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			isElementNotPresent(Admin.PRINTER_ACKNOWLEDGE_FILES_LABEL, "Printer Acknowledge Files(s) section");
			click(Admin.BACK_BTN, "Back Button");
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");
			handlepopup();

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");

			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(30000);
			refreshPage();

			flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			isElementPresent(Admin.PRINTER_ACKNOWLEDGE_FILES_LABEL, "Printer Acknowledge Files(s) section");
			click(Admin.BACK_BTN, "Back Button");
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

	public void reportsByServiceType(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.REPORTS_BY_SERVICE_TYPE_LEFT_NAV_LINK, "Reports By Service Type left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "Items - By Service Type", "Page Title");

			// Generate Report for region
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.GRID_HEADER, "Grid header");

			// Generate Report for all regions
			click(CRM.ALL_REGIONS_RADIO_BTN, "All Regions radio button");
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.GRID_HEADER, "Grid header");

			// Click on export button
			click(CRM.EXPORT_BTN, "Generate Report Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void reportsByServiceLevel(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.REPORTS_BY_SERVICE_LEVEL_LEFT_NAV_LINK, "Reports By Service Level left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "Items - By Service Level", "Page Title");

			// Generate Report for region
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.SERVICE_LEVEL_GRID_HEADER, "Grid header");

			// Generate Report for all regions
			click(CRM.ALL_REGIONS_RADIO_BTN, "All Regions radio button");
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.SERVICE_LEVEL_GRID_HEADER, "Grid header");

			// Click on export button
			click(CRM.EXPORT_BTN, "Generate Report Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void reportsByRequestedVia(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.REPORTS_BY_REQUESTED_VIA_LEFT_NAV_LINK, "Reports By Requested Via left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "Items - By Requested Via", "Page Title");

			// Generate Report for region
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.REQUESTED_VIA_GRID_HEADER, "Grid header");

			// Generate Report for all regions
			click(CRM.ALL_REGIONS_RADIO_BTN, "All Regions radio button");
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.REQUESTED_VIA_GRID_HEADER, "Grid header");

			// Click on export button
			click(CRM.EXPORT_BTN, "Generate Report Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void reportsCoreTeamCycle(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on CRM Link
			click(HomePage.CRM_LINK, "CRM Link TAB");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");

			// Click on Adminstration left nav link
			click(CRM.REPORTS_CORE_TEAM_CYCLE_LEFT_NAV_LINK, "Reports Core Team Cycle left nav link");
			assertTextMatching(CRM.PAGE_TITLE, "CORE Team Cycle Time", "Page Title");

			click(CRM.YEARDRPDWN_2019, "Select 2019 from year dropdown");

			// Generate Report for region
			click(CRM.GENERATE_REPORT_BTN, "Generate Report Button");
			assertElementPresent(CRM.CORE_TEAM_GRID_HEADER, "Grid header");

			// Click on export button
			click(CRM.EXPORT_BTN, "Generate Report Button");

		} catch (Exception e) {
			throw e;
		}

	}

	/********************************************************************************************************
	 * Method Name : exportName() Author : Pradyumna Description : This method will
	 * click on export Date of creation : 9/3/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String exportName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity ID Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click on Names Link
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Generic.EXPORT_BUTTON, "Export Button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : xsopPrintAndReportView() Author : Pradyumna Description : This
	 * method will check Print, Export and Generate Detailed Report view for XSOP
	 * Date of creation : 11/12/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String xsopPrintAndReportView(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on Renewal Invoice Search link on Home page
			click(HomePage.RENEWAL_INVOICE_SEARCH_LINK, "Renewal Invoice Search Link");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_SEARCH_PAGE, "Renewal Invoice Search Page");
			// Search for XSOP Invoice by Status and Date
			click(XSOP.XSOP_INVOICE_SEARCH, "XSOP Invoice Search");
			assertElementPresent(XSOP.XSOP_INVOICE_SEARCH_PAGE, "XSOP Invoice Search Page");
			click(XSOP.INVOICE_STATUS, "Open Invoice Status");
			type(Generic.SELECT_DATE, "07/01/2020", "Enter Date");
			click(Generic.SEARCH, "Search Button");
			// Search Results should be displayed
			assertElementPresent(XSOP.XSOP_INVOICE_RESULT_PAGE, "XSOP Invoice Result Page");
			click(Generic.FIRST_RESULT, "First Result");
			assertElementPresent(XSOP.XSOP_PROFILE, "XSOP Profile");
			// Click on Generated Detailed Report
			click(Generic.GENERATE_DETAILED_REPORT, "Generate Detailed Report");
			// Click on Export Button
			click(Generic.EXPORT_BUTTON2, "Generate Detailed Report");
			// Click on Print Button
			String parentWindow = driver.getWindowHandle();
			click(Generic.PRINT, "Print Button");
			// On clicking Print Button, New window is opened. Below steps manages Jumps
			// from Parent to child & back to Parent Window
			handlePopUpWindwow();
			assertElementPresent(XSOP.XSOP_PROFILE, "XSOP Profile");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertElementPresent(XSOP.XSOP_PROFILE, "XSOP Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
