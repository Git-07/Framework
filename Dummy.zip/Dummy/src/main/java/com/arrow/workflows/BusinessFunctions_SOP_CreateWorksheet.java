package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.PostLog;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;

public class BusinessFunctions_SOP_CreateWorksheet extends BusinessFunctions_CommonCESAndWorksheet {

	/********************************************************************************************************
	 * Method Name : CreateWorksheetMethod() Author : Pradyumna Description : This
	 * method will create SOP with Mandatory and not Mandatory fields filled in Date
	 * of creation : 8/01/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String createWorksheetMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String lawsuitType = Excelobject.getCellData(ReportSheet, "LawsuitType", count);
			String amountDue = Excelobject.getCellData(ReportSheet, "AmountDue", count);

			// Create Worksheet Page 1
			if (verifyIfElementPresent(SOP.METHOD_OF_SERVICE, "Method of Service")) {
				selectBySendkeys(SOP.METHOD_OF_SERVICE, "Fax", "Method Of Service as Fax");
				//waitForElementPresent(SOP.TIME_TEXTFIELD, "Text Field for Time");
				Thread.sleep(2000);
				type(SOP.TIME_TEXTFIELD, "08:00", "Text Field for Time");
			}

			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYFACILITY, "New York Facility 1 (LIS)");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYTEAM, "CT - New York SOP Team");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BYNY, "TEST New York SOP Team");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "123-234", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Entity Radio Button");
			click(WorksheetCreate.ENTITY_SELECT, "Select Entity Button");
			assertElementPresent(WorksheetCreate.ENTITY_NAME_SEARCH, "Entity Search Page");
			click(Generic.CANCEL, "Cancel Button");

			// Select Unidentified Radio Button
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			Thread.sleep(2000);
			click(WorksheetCreate.ENTITY_NAME, "Entity Name");
			type(WorksheetCreate.ENTITY_NAME, "Entity Name for Testing", "Enter Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Select Alabama");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			click(WorksheetCreate.UNIDENTIFIED_JURIS_GLYPHICON, "Unidentified Juris Glyphicon Click");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Alabama", "Select Alabama");

			// Create Worksheet Step 2
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			//selectBySendkeys(WorksheetCreate.COURT, "U.S. Marshall", "Court");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			//selectBySendkeys(WorksheetCreate.AGENCY, "U.S. Marshall", "Agency");
			click(WorksheetCreate.RADIO_BUTTON_SENDER, "Existing Attorney Radio Button");
			selectByIndex(WorksheetCreate.ATTORNEY_OR_SENDER, 2, "Attorney");

			// Create Worksheet Step 3
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(SOP.LAWSUITTYPE_DROPDOWN, lawsuitType, "LawSuitType Drpdwn");
			Thread.sleep(2000);
			if (verifyIfElementPresent(WorksheetCreate.SPECIAL_CIRCUMSTANCES, "Special Circumstances")) {
				selectBySendkeys(WorksheetCreate.SPECIAL_CIRCUMSTANCES, "None", "Special Circumstances");
			}
			type(WorksheetCreate.AMOUNT_DUE, amountDue, "Amount Due");
			click(WorksheetCreate.RADIO_BUTTON_ANSWERDATE, "Answer Radio Button");
			click(WorksheetCreate.FIRST_ANSWER_DATE, "First Answer");
			selectBySendkeys(WorksheetCreate.ANSWER_DATE, "Immediately", "Answer Date Selected");
			click(SOP.SOP_INTERNAL_COMMENTS_DRPDWN, "Internal Comments Text");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : CreateWorksheet() Author : Pradyumna Description : This method
	 * will verify Create Worksheet Date of creation : 7/31/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void createWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);

			// click on Create Worksheet link on Home page
			click(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");
			// Enter an entity name and click on search btn
			type(SOP.ENTITY_NAME_TEXTFIELD, entityName, "Entity Name Text Field");
			click(SOP.SEARCH_BTN, "Search Button");
			// Select entity from the grid
			click(SOP.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity On Grid");
			// Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,
					"Create Quicklog/Attempted/Rejection/Multiple Button");

			createWorksheetMethod(ReportSheet, count);
			click(Generic.SAVE, "Save Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}

	}

	/********************************************************************************************************
	 * Method Name : MyWorksheet() Author : Pradyumna Description : This method will
	 * verify create worksheet via My Worksheet Date of creation : 8/9/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String myWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityName = Excelobject.getCellData(ReportSheet, "EntityName", count);

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// click on create worksheet btn
			click(WorksheetCreate.CREATE_WORKSHEET_BUTTON, "Create Worksheet Button");
			// Enter an entity name and click on search btn
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");
			type(SOP.ENTITY_NAME_TEXTFIELD, entityName, "Entity Name Text Field");
			click(SOP.SEARCH_BTN, "Search Button");
			// Select entity from the grid
			click(SOP.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity On Grid");
			// Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,
					"Create Quicklog/Attempted/Rejection/Multiple Button");
			createWorksheetMethod(ReportSheet, count);
			click(Generic.SAVE, "Save Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : SOPList() Author : Pradyumna Description : This method will
	 * verify create worksheet via SOP List Date of creation : 8/9/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String sopList(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on SOP List link on Home page
			click(HomePage.SOP_LIST_LINK, "SOP List Link");
			assertElementPresent(WorksheetCreate.SOP_LIST_PAGE, "SOP List Page");
			//click(WorksheetCreate.OLD_SOP_LIST, "SOP Greater than 15 days");
			if (isElementPresent(WorksheetCreate.CREATE_WORKSHEET, "Create Worksheet")) {
				click(WorksheetCreate.VIEW_WORKSHEET, "View Worksheet Button");
				// Close the view pop up window once viewed
				String parentWindow = driver.getWindowHandle();
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWindow);
				// if(verifyIfElementPresent(WorksheetCreate.CREATE_WORKSHEET, "Create
				// Worksheet")) {
				click(WorksheetCreate.CREATE_WORKSHEET, "Create Worksheet");
				// Thread.sleep(500);
				/*if (verifyIfElementPresent(WorksheetCreate.ENTITY_NAME_SEARCH, "Entity Search Page")) {
					selectBySendkeys(WorksheetCreate.ENTITY_SEARCH_NAME, "apple", "Entity Name");
					click(WorksheetCreate.ENTITY_SEARCH, "Entity Search");
					click(Generic.SELECT_BUTTON, "Select Button");
					click(WorksheetCreate.CREATE_QUICKLOG_BUTTON, "Create Quicklog Button");
				}*/

				assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
				Thread.sleep(2000);
				click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
				waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
				// TODO Uncomment below when on Staging
				// assertElementPresent(WorksheetCreate.ML_EXTRACTED_DATA, "ML Extracted Data/ML
				// Slider");
				// click(SOP.SLIDER_OPENED_BTN,"ML Slider Close");
				//assertElementPresent(WorksheetCreate.CREATE_WORKSHEET_STEP1, "Create Worksheet  - Step 1");
				// Create Worksheet Method Called
				createWorksheetMethod(ReportSheet, count);

				// click(WorksheetCreate.ANSWER_DATE_NONE, "Answer Date None");
				/*click(Generic.SAVE, "Save Button");
				waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");*/
			} else {
				System.out.println("Create Worksheet is not present on page");
			}
			// }

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : EditMyWorksheet() Author : Pradyumna Description : This method
	 * will verify create worksheet via SOP List Date of creation : 8/9/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String editMyWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(Generic.LAST, "Last Link");
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "Test-123-456", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Test-Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			// Select Unidentified Entity and Rep
			waitForElementPresent(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			assertElementPresent(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			waitForElementPresent(WorksheetCreate.ENTITY_NAME, "Entity Name");
			assertElementPresent(WorksheetCreate.ENTITY_NAME, "Entity Name");
			click(WorksheetCreate.ENTITY_NAME, "Entity Name");
			type(WorksheetCreate.ENTITY_NAME, "Test Entity Name (Alabama)", "Entity Name");
			Thread.sleep(2000);
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Domestic Jurisdiction");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			click(WorksheetCreate.UNIDENTIFIED_JURIS_GLYPHICON, "Unidentified Juris Glyphicon Click");
			selectByVisibleText(WorksheetCreate.REP_JURISDICTION, "Hawaii", "Jurisdiction for Rep");
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			//click(WorksheetCreate.RADIO_BUTTON_SENDER, "Existing Attorney Radio Button");
			//selectByIndex(WorksheetCreate.ATTORNEY_OR_SENDER, 2, "Attorney");
			click(SOP.RADIO_BUTTON_ATTORNEYNONE, "None Specified Attorney Radio Button");
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.WORKSHEET_REMARKS_TEXTBOX, "", "Clear Remarks Textbox");
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.REMARKS_TEXTBOX, "Worksheet Edited", "Remarks Text");
			waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			click(SOP.SAVE_BTN, "Save Button");
			//Enter a value for Remarks.
			try {
				WebElement remarksNotEntered = null;	
				remarksNotEntered = driver.findElement(SOP.REMARKS_ERRMSG);
				if(remarksNotEntered != null) {	
					type(SOP.REMARKS_TEXTBOX,"Remarks entered in Selenium Automation","Remarks text box");
					waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
					assertElementPresent(SOP.SAVE_BTN, "Save Button");
					click(SOP.SAVE_BTN, "Save Button");
				}
			}
			catch (NoSuchElementException e) {}

			// Verify all text entered during Edit Worksheet
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			waitForElementPresent(WorksheetCreate.EDITED_ENTITY_NAME, "Edited Entity Name");
			assertElementPresent(WorksheetCreate.EDITED_ENTITY_NAME, "Edited Entity Name");
			waitForElementPresent(WorksheetCreate.EDITED_REP_JURISDICTION, "Edited Rep Jurisdiction");
			assertElementPresent(WorksheetCreate.EDITED_REP_JURISDICTION, "Edited Rep Jurisdiction");
			waitForElementPresent(WorksheetCreate.EDITED_CASE, "Edited Case ID");
			assertElementPresent(WorksheetCreate.EDITED_CASE, "Edited Case ID");
			waitForElementPresent(WorksheetCreate.EDITED_PLAINTIFF, "Edited Plaintiff");
			assertElementPresent(WorksheetCreate.EDITED_PLAINTIFF, "Edited Plaintiff");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : internalComments() Author : Pradyumna Description : This method
	 * will verify Internal Comments added for Worksheet Date of creation : 8/9/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String internalComments(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Comments Section and add in Comments
			click(WorksheetCreate.INTERNAL_COMMENT_IMAGE, "Comments");
			type(WorksheetCreate.INTERNAL_TEXT_COMMENT, "MV - Second Review", "Enter Internal Comment");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.ADDED_TEXT_COMMENT, "Comment Text");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : reviewSOP() Author : Pradyumna Description : This method will
	 * verify Review Comments added for Worksheet Date of creation : 8/9/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String reviewSOP(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Review Button and add in Comments
			click(WorksheetCreate.REVIEW_BUTTON, "Review Button");
			type(WorksheetCreate.REVIEW_COMMENT, "Review for Testing", "Enter Review Comment");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.ADDED_REVIEW_COMMENT, "Review Text");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : rejectWorksheet() Author : Pradyumna Description : This method
	 * will verify Reject Worksheet Date of creation : 8/9/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String rejectWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Button
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			/*click(WorksheetCreate.ASSIGNED_TO_GLYPHICON_WORKSHEET, "Glyphicon Click");
			click(WorksheetCreate.SELECT_GLOBAL_PROCESSING_CENTRE, "Global Processing Center");
			click(WorksheetCreate.ASSIGNED_TO_GLYPHICON_WORKSHEET, "Glyphicon Click");
			click(WorksheetCreate.EDITED_ASSIGNED_TO_TEAM, "SOP Support Team");
			click(WorksheetCreate.ASSIGNED_TO_GLYPHICON_WORKSHEET, "Glyphicon Click");
			click(WorksheetCreate.EDITED_ASSIGN_TO, "Amy McLaren");*/
			
			click(WorksheetCreate.ATTEMPTED_NO, "Select Attempted as No");
			// Reject the Worksheet
			selectByIndex(WorksheetCreate.REJECT_REASON, 2, "Reject Reason from Drop Down");
			waitForElementPresent(SOP.REJECT_DATE,"Reject Date text box");
			assertElementPresent(SOP.REJECT_DATE,"Reject Date text box");
			int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(SOP.REJECT_DATE, lastYearDate, "Reject Date text box");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			//click(SOP.NEXT_BTN, "Next Button");
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");

			waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			click(SOP.USE_THIS_COURT,"Use this court radio button");
			//COURT_NAME_TEXT_BOX
			waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			type(SOP.COURT_NAME_TEXT_BOX, "Alice Wonderland","Court NAme");
			//ADDRESS_LINE_ONE
			waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
			//CITY_NAME
			waitForElementPresent(SOP.CITY_NAME,"City Name text box");
			assertElementPresent(SOP.CITY_NAME,"City Name text box");
			type(SOP.CITY_NAME,"Houston","City Name text box");
			//STATE_NAME
			waitForElementPresent(SOP.STATE_NAME,"State Name text box");
			assertElementPresent(SOP.STATE_NAME,"State Name text box");
			type(SOP.STATE_NAME,"TX","State Name text box");
			//ZIP_CODE
			waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
			assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
			type(SOP.ZIP_CODE,"77550","Zip code text box");
			click(SOP.RADIO_BUTTON_ATTORNEYNONE, "None Specified Attorney Radio Button");
			/*selectBySendkeys(WorksheetCreate.REMARKS,
					"According to the records of the New York Secretary of State, the entity status is: active and CT Corporation is listed as the registered agent.",
					"Remarks Selected");*/
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.WORKSHEET_REMARKS_TEXTBOX, "", "Clear Remarks Textbox");
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.REMARKS_TEXTBOX, "Worksheet Edited", "Remarks Text");
			waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			click(SOP.SAVE_BTN, "Save Button");
			//Enter a value for Remarks.
			try {
				WebElement remarksNotEntered = null;	
				remarksNotEntered = driver.findElement(SOP.REMARKS_ERRMSG);
				if(remarksNotEntered != null) {	
					type(SOP.REMARKS_TEXTBOX,"Remarks entered in Selenium Automation","Remarks text box");
					waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
					assertElementPresent(SOP.SAVE_BTN, "Save Button");
					click(SOP.SAVE_BTN, "Save Button");
				}
			}
			catch (NoSuchElementException e) {}

			// View Rejected Worksheet
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// assertElementPresent(WorksheetCreate.REJECTED_REASON, "Rejected Reason");
			assertElementPresent(WorksheetCreate.REJECTION_PENDING, "Rejection Pending");
			// assertElementPresent(WorksheetCreate.REJECT_COMMENTS, "Reject Comments");

			// Click on Edit Button
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			

			selectBySendkeys(WorksheetCreate.REJECT_REASON, "-- Select One --", "Clear Reject Drpdwn");
			assertElementPresent(SOP.REJECT_DATE, "Reject Field");
			type(SOP.REJECT_DATE, "", "Clear Reject Field Textbox");
			waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ReceivedValue() Author : Pradyumna Description : This method
	 * will verify Received By and Assigned To in Worksheet Date of creation :
	 * 7/31/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String editAssignedReceivedValue(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			// click on My Worksheet link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.RECEIVED_BY_TEAM, "Received By Team");
			assertElementPresent(WorksheetCreate.ASSIGNED_TO_TEAM, "Assigned To Team");
			// Click On Edit Worksheet
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			// Change Received By and Assigned To
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			selectBySendkeys(WorksheetCreate.EDIT_RECEIVED_BY, "Nora Dindyal", "Received By Updated");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			selectBySendkeys(WorksheetCreate.EDIT_ASSIGNED_TO, "Nora Dindyal", "Assigned To Updated");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.EDITED_RECEIVED_BY, "Edited Received By");
			assertElementPresent(WorksheetCreate.EDITED_ASSIGNED_TO, "Edited Assigned To");
			// Click On Edit Worksheet and change assigned and Received back to original
			// Value
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			selectBySendkeys(WorksheetCreate.EDIT_RECEIVED_BY, "TEST New York SOP Team", "Received By Updated");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			selectBySendkeys(WorksheetCreate.EDIT_ASSIGNED_TO, "TEST New York SOP Team", "Assigned To Updated");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(Generic.SAVE, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.RECEIVED_BY, "Original Received By");
			assertElementPresent(WorksheetCreate.ASSIGNED_TO, "Original Assigned To");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : uploadImage() Author : Pradyumna Description : This method will
	 * verify Images can be uploaded Date of creation : 11/13/2019 modifying person
	 * : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String uploadImage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			// Click on Upload button
			click(SOP.UPLOADIMAGEBTN, "Upload Image button");
			assertElementPresent(SOP.UPLOADIMAGE_PAGE, "Upload Image Page");
			// Select mandatory Fields in Upload Image
			type(SOP.BATCHNUMBER_TEXT, "12345", "Batch Number Text");
			click(SOP.CERTIFIED_MAIL_DROPDOWN, "Certified Mail DropDown");
			/*click(SOP.POST_MARKED_DATE_BTN, "Post Marked Date");
			click(Generic.TODAYSDATE, "Today's Date");*/
			waitForElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
			assertElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
			int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(WorksheetCreate.POST_MARKED_DATE,lastYearDate,"Post marked Date text box");
			// click(SOP.UPLOAD_IMG, "Upload Image button");
			uploadFile("Automation_SOPUpload.pdf", SOP.UPLOAD_IMG, "Image Upload");
			click(Generic.SAVE, "Save button");
			waitForElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void expeditedSOPPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {

			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Update Entity on posted
			// Expedited SOP
			// Log is Present
			isElementPresent(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			assertTextMatching(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_LABEL,
					"Update Entity on posted Expedited SOP Log",
					"Label For Update Entity on posted Expedited SOP Log Field");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(Admin.EDIT_BTN, "Edit Button");

			// Click on Update Entity on posted Expedited SOP Log Checkbox and
			// click on save
			// button
			click(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			click(Admin.SAVEBTN, "Save Button");

			// Verify whether Update Entity on posted Expedited SOP Log is added
			// in
			// Expedited SOP Permission Field
			assertTextMatching(Admin.EXPEDITED_SOP_PERMISSION_FIELD, "Update Entity on posted Expedited SOP Log",
					"Update Entity on posted Expedited SOP Log on Expedited SOP Permission Field");

			// Click on Edit Button again and uncheck Update Entity on posted
			// Expedited SOP
			// Log
			click(Admin.EDIT_BTN, "Edit Button");
			click(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");

			// Click on save btn
			click(Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Expedited SOP Permission
			// Field
			assertTextMatching(Admin.EXPEDITED_SOP_PERMISSION_FIELD, "No permissions",
					"No permissions Msg on Expedited SOP Permission Field");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			Thread.sleep(1000);
			// waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void errorForExpeditedSOPLog(String ReportSheet, int count) throws Throwable {
		try {
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			String errorMessage = Excelobject.getCellData(ReportSheet, "Error Message", count);
			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			if (!errorMessage.equals("")) {

				errorMessageOnEntityEdit();
			} else if (errorMessage.equals("")) {

				editEntityOnWorksheetEditPage(ReportSheet, count);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchWorksheet(String worksheetId) throws Throwable {
		try {
			blnEventReport = true;
			// Click On Worksheet Search Link from left nav bar
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "Worksheet Search On Left Nav Link");
			click(SOP.CLASSIC_SEARCH_BTN, "Classic Search Button");
			waitForElementPresent(SOP.SEARCH_BTN, "Search Button");
			// Enter an entity Id to be searched and click on search btn
			type(SOP.WORKSHEET_ID_TEXTBOX, worksheetId, "Workhseet Id text Box");
			click(SOP.WORKSHEET_SEARCH_BTN, "Worksheet Search Btn");

		} catch (Exception e) {
			throw e;
		}
	}

	//below function is modified as per the ciox changes
	public void errorMessageOnEntityEdit() throws Throwable {
		try {

			blnEventReport = true;
			String message = "This SOP has been transmitted to the customer via the Expedited SOP Feed and you cannot edit the Entity. Please contact your manager.";
			// Click On Worksheet Edit Btn
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			click(SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			// Click On Select Btn for Entity Field
			waitForElementPresent(SOP.SELECT_ENTITY_BTN, "Select Entity Btn");
			click(SOP.SELECT_ENTITY_BTN, "Select Entity Btn");
			// Verify error msg is displayed
			waitForElementPresent(SOP.ERROR_MSG_ON_ENTITY_EDIT,"Error Message" );
			assertTextMatching(SOP.ERROR_MSG_ON_ENTITY_EDIT, message, message);

		} catch (Exception e) {
			throw e;
		}
	}

	public void editEntityForVariousSOP(String ReportSheet, int count) throws Throwable {
		try {
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			editEntityOnWorksheetEditPage(ReportSheet, count);

		} catch (Exception e) {
			throw e;
		}
	}
	//Below function is modified as per the ciox changes
	public void editEntityOnWorksheetEditPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// Click On Worksheet Edit Btn
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			click(SOP.WORKSHEET_EDIT_BTN, "Worksheet Edit Btn");
			Thread.sleep(4000);
			driver.switchTo().frame("frame1");
			// Click On Select Btn for Entity Field
			waitForElementPresent(SOP.SELECT_ENTITY_BTN, "Select Entity Btn");
			click(SOP.SELECT_ENTITY_BTN, "Select Entity Btn");
			// Select an Entitys
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD,"Entity Name Text Field");
			type(SOP.ENTITY_NAME_TEXTFIELD, "apple", "Entity Name Text Field");
			waitForElementPresent(SOP.SEARCH_BTN, "Search Btn");
			click(SOP.SEARCH_BTN, "Search Btn");
			waitForElementPresent(SOP.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity On Grid");
			click(SOP.SELECT_FIRST_ENTITY_ON_GRID, "Select First Entity On Grid");
			// Click On Save Btn
			/*Thread.sleep(1000);
			driver.switchTo().frame("frame1");*/
			waitForElementPresent(SOP.SAVE_BTN, "Save Btn");
			click(SOP.SAVE_BTN, "Save Btn");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addDocketHistory(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);

			// Click on Modify Docket History btn
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");

			// Enter Case id and click on search button
			type(SOP.CASEID_TEXTBOX, "sel", "Case id textbox");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep Jurisdiction");
			click(SOP.WORKSHEET_SEARCH_BTN, "Search Button");

			// Click on First radio button for selecting a worksheet
			click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First radio button for selecting a worksheet");

			// Click on Add to Docket History Button
			click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket History Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addorRemoveTheExpeditedPermissionFromRole(String reportSheet, int count) {
		String roleName = Excelobject.getCellData(reportSheet, "Role Name", count);
		String permission = Excelobject.getCellData(reportSheet, "Permission", count);
		try {
			// ADMIN_TAB
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			click(Admin.ADMIN_TAB, "Admin Tab in the header");
			// FIRST_FILTER_DRPDWN
			assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "Filter drop down in Role Page");
			selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "Filter Dropdown 1");
			// SECOND_FILTER_DRPDWN
			assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Filter drop down in Role Page");
			selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "equals", "Filter Dropdown 2");
			// FILTER_TEXT_FILED
			assertElementPresent(Admin.FILTER_TEXT_FILED, "Filter text feild in Role Page");
			selectBySendkeys(Admin.FILTER_TEXT_FILED, roleName, "Filter text feild in Role Page");
			// GO_BTN
			assertElementPresent(Admin.GO_BTN, "GO Button in the Role Page");
			click(Admin.GO_BTN, "GO Button in the Role Page");
			// FIRST_ROLE_ON_THE_GRID
			assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "Role Name in the Role Page");
			click(Admin.FIRST_ROLE_ON_THE_GRID, "Role Name in the Role Page");
			// EDIT_BTN
			assertElementPresent(Admin.EDIT_BTN, "Edit Button in the Role Page");
			click(Admin.EDIT_BTN, "Edit Button in the Role Page");

			if (permission.equals("Not Permitted")) {
				// MAINTAIN_EXPEDITED_CHECK_BOX
				assertElementPresent(Admin.MAINTAIN_EXPEDITED_CHECK_BOX, "Maintain Expedited Service of Process");
				String maintainExpeditedAttribute = getAttribute(Admin.MAINTAIN_EXPEDITED_CHECK_BOX, "checked");

				if (maintainExpeditedAttribute != null) {
					click(Admin.MAINTAIN_EXPEDITED_CHECK_BOX, "Maintain Expedited Service of Process");
				}
				// UPDATE_ENTITY_ON_POSTED
				assertElementPresent(Admin.UPDATE_ENTITY_ON_POSTED, "Update Entity on posted Expedited SOP Log");
				String updateEntityAttribute = getAttribute(Admin.UPDATE_ENTITY_ON_POSTED, "checked");

				if (updateEntityAttribute != null) {
					click(Admin.UPDATE_ENTITY_ON_POSTED, "Update Entity on posted Expedited SOP Log");
				}
			} else if (permission.equals("Permitted")) {

				// MAINTAIN_EXPEDITED_CHECK_BOX
				assertElementPresent(Admin.MAINTAIN_EXPEDITED_CHECK_BOX, "Maintain Expedited Service of Process");
				String maintainExpeditedAttribute = getAttribute(Admin.MAINTAIN_EXPEDITED_CHECK_BOX, "checked");

				if (maintainExpeditedAttribute == null) {
					click(Admin.MAINTAIN_EXPEDITED_CHECK_BOX, "Maintain Expedited Service of Process");
				}
				// UPDATE_ENTITY_ON_POSTED
				assertElementPresent(Admin.UPDATE_ENTITY_ON_POSTED, "Update Entity on posted Expedited SOP Log");
				String updateEntityAttribute = getAttribute(Admin.UPDATE_ENTITY_ON_POSTED, "checked");

				if (updateEntityAttribute == null) {
					click(Admin.UPDATE_ENTITY_ON_POSTED, "Update Entity on posted Expedited SOP Log");
				}
			}
			// SAVEBTN
			assertElementPresent(Admin.SAVEBTN, "Save Button in the Edit Role Page");
			click(Admin.SAVEBTN, "Save Button in the Edit Role Page");
			Thread.sleep(5000);

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	//Below Function is added as part of CEs enhancement Rejection workflow
	public void workSheetContainsPlaintiffAndDefendantValuesAsESOP(String reportSheet, int count,String esopId) throws Throwable{
		try{

			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			//FIRST_SOP_CHECKBOX
			searchForESOP(esopId);		
			try {		 
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);			

			}catch(NoSuchElementException e) {}
			for(int i=0 ;i<10; i++) {			
				String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
				if(isHandlerProcessed.equals("N")) {
					Thread.sleep(10000);
				}
				else {
					break;
				}		
			}
			selectAndAssignTheFileToTeam();
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			Thread.sleep(1000);
			searchForESOP(esopId);		
			String parentWindow= driver.getWindowHandle();		
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");		
			click(SOP.VIEW_BTN, "View button");		
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(1000);
			WebElement createWs = null;
			try {
				createWs = driver.findElement(SOP.CREATE_WORKSHEET);
				waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
				click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			}catch(NoSuchElementException e) {			
			}
			if(createWs == null) {
				Thread.sleep(4000);
				selectAndAssignTheFileToTeam();
				Thread.sleep(4000);
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				Thread.sleep(2000);
				String parentWin= driver.getWindowHandle();		
				waitForElementPresent(SOP.VIEW_BTN, "View button");
				assertElementPresent(SOP.VIEW_BTN, "View button");		
				click(SOP.VIEW_BTN, "View button");		
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
				click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			}

			//Below changes are added as per the ciox changes
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			//CERTIFIED_MAIL_NUMBER
			waitForElementPresent(SOP.CERTIFIED_MAIL_NUMBER,"certified mail number text box");
			assertElementPresent(SOP.CERTIFIED_MAIL_NUMBER,"certified mail number text box");
			String traceableMail = getText(SOP.CERTIFIED_MAIL_NUMBER,"certified mail number text box");
			printMessageInReport(
					"Value of Traceable Mail Field : " + traceableMail);			
			//PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plantiff text field");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plantiff text field");
			String worksheetPltf = getAttribute(SOP.PLAINTIFF_TEXT_BOX,"value");
			compareStrings(plaintiff,worksheetPltf);
			//DEFENDANT_TEXTFIELD
			waitForElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
			assertElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
			String worksheetDft = getText(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
			compareStrings(defendant,worksheetDft);
		} catch (Exception e) {
		}
	}

	//This is added in common fxn file
	/*public void searchForESOP(String esopId) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1,"ESOP Id","Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");		
		click(SOP.FILTERGOBTN, "Go Button");
	}
	 */

	//This is added in common fxn file
	/*public void selectAndAssignTheFileToTeam() throws Throwable{
		waitForElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		assertElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");		
		click(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign button");
		click(SOP.ASSIGN_BTN, "Assign button");
		Thread.sleep(1000);
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		click(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		Thread.sleep(1000);
	}
	 */
	public void assignmentHistoryAndAudtitTrail(String esopId,String worksheetId) throws Throwable{

		try {
			String parentWindow = driver.getWindowHandle();
			//WORKSHEET_PROFILE_ASSIGNMENTHISTORY
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,"Worksheet profile Assignment History link");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,"Worksheet profile Assignment History link");	
			click(WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,"Worksheet profile Assignment History link");		
			//below all the scenarios will come which needs to be validated		
			handlePopUpWindwow();
			//DOCKET_HISTORY_CES_AUDIT_TRAIL
			waitForElementPresent(WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL," Docket History in Audit Trail");
			assertElementPresent(WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL," Docket History in Audit Trail");
			String docketHistoryCES = getText(WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL," Docket History in Audit Trail");
			String attorneyWorksheet = getText(WorksheetCreate.ATTORNEY_WORKSHEET_AUDIT_TRAIL," Attorney in Audit Trail");
			String courtWorksheet = getText(WorksheetCreate.COURT_WORKSHEET_AUDIT_TRAIL," Court in Audit Trail");
			String plaintiffWorksheet = getText(WorksheetCreate.PLAINTIFF_WORKSHEET_AUDIT_TRAIL," Plaintiff in Audit Trail");
			String defendantWorksheet = getText(WorksheetCreate.DEFENDANT_WORKSHEET_AUDIT_TRAIL," Defendant in Audit Trail");
			driver.close();
			driver.switchTo().window(parentWindow);
			if(attorneyWorksheet.equals("")) {
				attorneyWorksheet = null;
			}
			if (courtWorksheet.equals("")) {
				courtWorksheet = null;
			}
			if (plaintiffWorksheet.equals("")) {
				plaintiffWorksheet = null;
			}
			if (defendantWorksheet.equals("")) {
				defendantWorksheet = null;
			}
			if (docketHistoryCES.equals("")) {
				docketHistoryCES = null;
			}
			ArrayList<String> fieldsModifiedInWorksheet = SQL_Queries.fieldsModifiedInWorksheet(worksheetId);		
			ArrayList<String> getTheRelatedLogForCompletedESOPs = SQL_Queries.getTheRelatedLogForCompletedESOPs(esopId);
			compareStrings(docketHistoryCES,getTheRelatedLogForCompletedESOPs.get(0));
			compareStrings(attorneyWorksheet,fieldsModifiedInWorksheet.get(0));
			compareStrings(courtWorksheet,fieldsModifiedInWorksheet.get(1));
			compareStrings(defendantWorksheet,fieldsModifiedInWorksheet.get(2));
			compareStrings(plaintiffWorksheet,fieldsModifiedInWorksheet.get(3));
			//Need to comment below		
		}catch (Exception e) {

		}	
	}

	public String validatePlaintiffAndDefendantFieldsAreMandatory(String reportSheet, int count) throws Throwable {

		String esopId = null;
		try {

			String plaintiffError = Excelobject.getCellData(reportSheet, "Plaintiff Error", count);
			String defendantError = Excelobject.getCellData(reportSheet, "Defendant Error", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");			
			Thread.sleep(1000);
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			//CESSELECTBTN
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(3000);
			//CLOSE_THE_ML_SLIDER
			/*	try {
		//waitForElementToBeClickable(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
		click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
		}catch(NoSuchElementException e) {}
		catch(WebDriverException e) {}*/
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			if (branchPlant.equals("CTCORP")) {
				//CTCORP_RADIO_BUTTON
				assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
				click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

			}
			else if (branchPlant.equals("NRAI")) {
				//NRAI_RADIO_BUTTON
				assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
				click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	

			}	
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
			// SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			// FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			driver.switchTo().defaultContent();
			assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
			click(SOP.GLYPHICON_HOME, "glyphicon button");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			List<WebElement> traceableMail = null;
			//TRACEABLE_MAIL_FIELD
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}

			//CASE_ID_TEXTBOX
			waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(SOP.CASE_ID_TEXTBOX,caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}			
			//PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box");
			//DEFENDANT_TEXT_BOX
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box");	

			//SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			click(SOP.SUBMIT_CES, "Click on Submit button in CES Page");
			if(plaintiff.equals("")) {
				waitForElementPresent(SOP.PLAINTIFF_EMPTY_ERROR,"Enter Plaintiff value in CES Page");
				assertElementPresent(SOP.PLAINTIFF_EMPTY_ERROR,"Enter Plaintiff value in CES Page");
				compareStrings(plaintiffError, getText(SOP.PLAINTIFF_EMPTY_ERROR,"Enter Plaintiff value in CES Page"));
			}
			if (defendant.equals("")) {
				//DEFENDANT_EMPTY_ERROR
				waitForElementPresent(SOP.DEFENDANT_EMPTY_ERROR,"Enter Defendant value in CES Page");
				assertElementPresent(SOP.DEFENDANT_EMPTY_ERROR,"Enter Defendant value in CES Page");
				compareStrings(defendantError, getText(SOP.DEFENDANT_EMPTY_ERROR,"Enter Defendant value in CES Page"));
			}

		} catch (Exception e) {
		}
		return esopId.split("\\: ")[1];
	}

	//This is added in common fxn file
	/*public String esopEscalatedOrOnHold(String reportSheet, int count) throws Throwable {

	  String esopId = "";
		try {
			String escalated = Excelobject.getCellData(reportSheet, "Escalate", count);
			String onHold = Excelobject.getCellData(reportSheet, "Hold", count);
			String unidentifiedEntity = Excelobject.getCellData(reportSheet, "Unidentified Entity", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");				
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");

			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			//To run Sprint 33 and 34 us we need this to be uncommented
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			//CESSELECTBTN
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if(!arrowEntity.equals("")) {
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				if (branchPlant.equals("CTCORP")) {
					//CTCORP_RADIO_BUTTON
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	

						}	
				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				//(SOP.FILTERTEXTFIELD, filename, "Filter text field");		
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				driver.switchTo().defaultContent();
				assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
				click(SOP.GLYPHICON_HOME, "glyphicon button");
				driver.switchTo().frame("frame1");
				Thread.sleep(2000);

			}
			else if(!unidentifiedEntity.equals("")) {
				//UNIDENTIFIED_ENTITY_RADIO_BUTTON
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
				click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Click on Unidentified entity radio button");	
				if (branchPlant.equals("CTCORP")) {
				//BRANCH_PLANT_UNIDENTIFIED_ENTITY
				waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
				assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
				selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY,"CTCORP", "Branch Plant drop down");	

			} else if (branchPlant.equals("NRAI")) {
				//Select the drop down for NRAI
				waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
				assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
				selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY,"NRAI", "Branch Plant drop down");	
				}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");	
				type(SOP.ENTITY_TEXT_BOX,unidentifiedEntity,"Entity search text box on ESOP");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");	
				selectByVisibleText(SOP.DOMESTIC_JURISDICTION_SELECTION,"Arizona","Domestic Jurisdiction in CES Page");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");	
				selectByVisibleText(SOP.REP_JURISDICTION_SELECTION,"Arizona","Rep Jurisdiction in CES Page");				
				}
			//CASE_ID_TEXTBOX
			waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(SOP.CASE_ID_TEXTBOX,caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			//PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box");
			//DEFENDANT_TEXT_BOX
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box");

			waitForElementPresent(SOP.ESOPID,"ESOP ID");
			assertElementPresent(SOP.ESOPID,"ESOP ID");
			esopId = getText(SOP.ESOPID,"ESOP ID");

			if(!escalated.equals("")) {
			//ESCALATION_DETAILS
			waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
			//REASON_DRPDWN
			waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
			assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
			selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");//
			//ESCALATION_COMMENTS_TEXTBOX
			waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Entity escalated", "Escalation text box");
			//ESCALATE_BTN
			waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
			assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
			click(SOP.ESCALATE_BTN, "Escalate button");			
			}
			else if(!onHold.equals("")) {
			//REASON_FOR_HOLD_TEXTBOX
			assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On hold text box in CES Page");
			type(SOP.REASON_FOR_HOLD_TEXTBOX,"On hold for verification", "Reason for On hold text box in CES Page");
			//ONHOLD_BTN
			waitForElementToBeClickable(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
			assertElementPresent(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
			click(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
			}		

		} catch (Exception e) {
		}
		return esopId;
  }
	 */

	//This is added in common fxn file
	/*public void processEscalatedOrOnHoldESOP(String reportSheet, int count,String esopId) throws Throwable {

	try {
		String checkedArrowEntity = "";
		String caseNumber = "";
		String lawSuitType = "";
		String docType = "";
		String plaintiff = "";
		String defendant = "";
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String arrowEntity = Excelobject.getCellData(reportSheet, "New Entity Searched", count);
		String relatedLog = Excelobject.getCellData(reportSheet, "Related Log", count);
		String hold = Excelobject.getCellData(reportSheet, "Hold", count);			
		//CES_LEFT_NAV_LINK
		waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
		assertElementPresent(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
		click(SOP.CES_LEFT_NAV_LINK,"Click on CES Link in SOP List Page");
		if(!hold.equals("")){
		//ON_HOLD_LIST_TAB
		waitForElementToBeClickable(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");
		assertElementPresent(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");
		click(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");	
		}
		//FILTERDROPDOWN1
		waitForElementPresent(SOP.FILTERDROPDOWN1,"First Filter in CES Page");
		assertElementPresent(SOP.FILTERDROPDOWN1,"First Filter in CES Page");
		selectByVisibleText(SOP.FILTERDROPDOWN1,"ESOP Id","First Filter in CES Page");
		//FILTERDROPDOWN2
		waitForElementPresent(SOP.FILTERDROPDOWN2,"Second Filter in CES Page");
		assertElementPresent(SOP.FILTERDROPDOWN2,"Second Filter in CES Page");
		selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Second Filter in CES Page");
		//FILTERTEXTFIELD
		assertElementPresent(SOP.FILTERTEXTFIELD,"Text box in CES Page");
		type(SOP.FILTERTEXTFIELD,esopId,"Text box in CES Page");
		//FILTERGOBTN
		assertElementPresent(SOP.FILTERGOBTN,"Go Button in CES Page");
		click(SOP.FILTERGOBTN,"Go Button in CES Page");
		if(hold.equals("")){
		//FIRST_CES_SELECT_BUTTON
		waitForElementToBeClickable(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
		assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
		click(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
		}
		else if(!hold.equals("")){
		waitForElementToBeClickable(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");
		assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");
		click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");			
		}
		Thread.sleep(1000);
		//CLOSE_THE_ML_SLIDER
		try {
		//waitForElementPresent(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
		click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
	   }catch(NoSuchElementException e) {}
		catch(WebDriverException e) {}
		driver.switchTo().frame("frame1");
		Thread.sleep(2000);
		if(branchPlant.contains("NRAI")) {

			docType = getText(SOP.SELECTED_DOC_TYPE, "Document Type drop down in CES Page");
		}
		else if (branchPlant.contains("CTCORP")) {
			lawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
		}
		Thread.sleep(1000);
		List<WebElement> traceableMail = null;
		//TRACEABLE_MAIL_FIELD
		try {
		traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
		if(traceableMail != null) { 
		type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
		}
		}catch(NoSuchElementException e) {}
		plaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
        defendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
        caseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
		try {
		checkedArrowEntity = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON,"checked");
		}catch(NullPointerException e) {}
		if(checkedArrowEntity == null) {
			assertElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Arrow Entity Radio button");
			click(SOP.ARROW_ENTITY_RADIO_BUTTON,"Click on Arrow Entity Radio button");
		}

		waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

			if (branchPlant.equals("CTCORP")) {
				//CTCORP_RADIO_BUTTON
					assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
					click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

				}
				else if (branchPlant.equals("NRAI")) {
					//NRAI_RADIO_BUTTON
					assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
					click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	

					}

			//ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			//(SOP.FILTERTEXTFIELD, filename, "Filter text field");		
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
			assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
			click(SOP.SEARCH_BTN, "Search button in CES Page");
			Thread.sleep(2000);
			//UNIDENTIFIED_ENTITY_BTN
			List<WebElement> entityNotFound = null;
			try {
				entityNotFound = driver.findElements(SOP.FIRST_ENTITY_IN_SEARCH_RESULT);
			}catch(NoSuchElementException e) {}
			if(entityNotFound == null) {
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "unidentified Entity button in CES Page");
				click(SOP.UNIDENTIFIED_ENTITY_BTN, "click on unidentified Entity button in CES Page");
				Thread.sleep(2000);

				if(branchPlant.contains("NRAI")) {
					waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					Thread.sleep(1000);
					String newDocType = getText(SOP.SELECTED_DOC_TYPE,"selected Doc type value");			
					printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
				}
				else if (branchPlant.contains("CTCORP")) {
					waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
					Thread.sleep(1000);
					String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
					printMessageInReport("Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);								
				}
			}
			else if(entityNotFound != null) {
			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			//FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT,"First entity link in CES Page");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "click on First entity link in CES Page");
			if(relatedLog.equals("")) {
				driver.switchTo().defaultContent();
				assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
				click(SOP.GLYPHICON_HOME, "glyphicon button");
				Thread.sleep(1000);
				driver.switchTo().frame("frame1");
				Thread.sleep(1000);

			}
			else if(!relatedLog.equals("")) {
				//WORKSHEET_ID_TEXTBOX
				waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
				assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
				type(SOP.WORKSHEET_ID_TEXTBOX,relatedLog,"Worksheet id text box in CES Page");
				//SEARCH_BTN
				assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
				click(SOP.SEARCH_BTN, "Click on Search button in CES Page");
				//FIRST_WORKSHEET_RADIO_BTN
				waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				//ADD_MANIFEST_BTN
				assertElementPresent(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
				click(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
				Thread.sleep(1000);
			}	
		}
			if(branchPlant.contains("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				Thread.sleep(1000);
				String newDocType = getText(SOP.SELECTED_DOC_TYPE,"selected Doc type value");			
				printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
			}
			else if (branchPlant.contains("CTCORP")) {
				waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
				Thread.sleep(1000);
				String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
				printMessageInReport("Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);								
			}
			String newPlaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
			Thread.sleep(1000);
			String newDefendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
			Thread.sleep(1000);
			String newCaseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			//SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			click(SOP.SUBMIT_CES, "Submit button in CES Page");	
			printMessageInReport("Previous plaintiff : " + plaintiff + " and new plaintiff : " + newPlaintiff);
			printMessageInReport("Previous defendant : " + defendant + " and new defendant : " + newDefendant);
			printMessageInReport("Previous case number : " + caseNumber + " and new case Number : " + newCaseNumber);


	}catch (Exception e) {
			e.printStackTrace();
		}

 }
	 */

	//This is added in common fxn file
	/*public String entitySectionDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

	String esopId = "";
		try {			
			String caseNumber = "";
			int relatedWorksheet = 0;
			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);				
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String caseNum2 = Excelobject.getCellData(reportSheet, "New Case Number", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
			String rejectionReason = Excelobject.getCellData(reportSheet, "Rejection Reason", count);
			String notRejecting = Excelobject.getCellData(reportSheet, "Reason for Not Rejecting", count);
			String error = Excelobject.getCellData(reportSheet, "Error Message", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String reject = Excelobject.getCellData(reportSheet, "Reject", count);
			String onHold = Excelobject.getCellData(reportSheet, "On Hold", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			//String worksheetType = Excelobject.getCellData(reportSheet, "WorkSheet Type", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			if(levelOfUser.equals("Level1")) {
				//CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
	 		    //CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
				//UNPROCESSED_COUNT
				waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				Thread.sleep(2000);
				driver.switchTo().frame("frame1");
				Thread.sleep(3000);
			}

			else if(!levelOfUser.equals("Level1")) {
			if(cesQueue.equals("New")) {
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");			
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);			
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");			
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");			
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");

			try {		 
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);	
			}catch(NoSuchElementException e) {}
			Thread.sleep(1000);
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(1000);

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			}
			else if(!cesQueue.equals("New")) {
			//CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");			
			click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
 		    //CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

			 if(cesQueue.equals("Escalated List")) {			
			  //ESCALATED_LIST_TAB
			  waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
			  assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
			  click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");				    
			  //FIRST_CES_SELECT_BUTTON
			  waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			  assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
			  click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			 }

			else if(cesQueue.equals("OnHold List")) {			
		    //ON_HOLD_LIST_TAB
		    waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
			assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
			click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
			//FIRST_ONHOLD_CES_SELECT_BUTTON
			 waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			 assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
			 click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
			 //create on filter search for New York SOP Team
		    }

		    else  if(cesQueue.equals("Rejections List")) {			
			 //REJECTION_LIST_TAB
			 waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
			 assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
			 click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
			 //REJECTIONS_LIST_FIRST_CES_SELECT
			 waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
			 assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
			 click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		
			 }
			}
			Thread.sleep(2000);
			//System.out.println("Reached Here ewjdjkjlkwdlkjw");
			Thread.sleep(1000);
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			//TRAINGLE_ICON_ARROW_ENTITY			
			//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			//INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
			if(!arrowEntity.equals("")) {				
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
			    String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {			
				        click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
			    }
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 

				if(!cdsop.equals("CDSOP")) {											
				 if (branchPlant.equals("CTCORP")) {
					//CTCORP_RADIO_BUTTON
					 	waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
						}
				}
				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
				if(cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
				}
				else if(!cdsop.equals("CDSOP")) {
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
				}
				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				//ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			    if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
				disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
				System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
				click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
				if(disabledUnEntity.equals("true")) {					
				  //SEARCH_AGAIN_BUTTON
				  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
				  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
				  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
				  //CANCEL_BUTTON
				  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
				  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
				  click(SOP.CANCEL_BUTTON, "Cancel Button");
				}}catch(NullPointerException e) {}				
                 System.out.println("REached here in line 6431");
                 Thread.sleep(2000);
                 //below will be a go ahead when the value for unidentified Entity above is selected
                 String unEntityRadioSelected = "";
                 try {                	 
                	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
                 }catch(NoSuchElementException e) {}
                 catch(NullPointerException e) {}
                 Thread.sleep(1000);
                 try {
                 if(unEntityRadioSelected == null) {
                	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
                 }}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
				try {
				//waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				//assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
				Thread.sleep(1500);
				selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
				}catch(NoSuchElementException e) {}
				//DOCUMENT_TYPE_DROPDWN
				try {
				//waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				//assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
			    driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
				selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
				}catch(NoSuchElementException e) {}
				//PLAINTIFF_TEXT_BOX			
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
				//DEFENDANT_TEXT_BOX				
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");

				waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
				type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
				}
				else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				 //FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				//CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if(action.size()>0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				}
				 catch(NoSuchElementException e) {

			     }
				if(!caseNum1.equals("")){					
				 //CASEID_TEXTBOX
				 waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
				 assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
				 if(cdsop.equals("CDSOP")) {
					 type(SOP.CASEID_TEXTBOX,"19342919","Case number Search text box");
				 }
				 else if(!cdsop.equals("CDSOP")) {
					 type(SOP.CASEID_TEXTBOX,caseNum1,"Case number Search text box");
				 }
				 //SEARCH_BTN
				 waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				 assertElementPresent(SOP.SEARCH_BTN, "Search button");
				 click(SOP.SEARCH_BTN, "Search button");
				 //TOTAL_RECORDS_RELATED_WORKSHEET				 				 
				 waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results");				 
				 relatedWorksheet = Integer.parseInt(getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results"));
				 Thread.sleep(1000);
				 if(relatedWorksheet == 0) {

					 click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
					 Thread.sleep(2000);
					 //RADIO_PRESENTATION_BUTTON
					 String repChecked = "";
					 try {
						 repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked"); 
					 }catch(NoSuchElementException e) {}
					 if(repChecked == null) {
					 //REP_JURISDICTION_SELECTION
					 waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					 assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					 selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");
					 }
					 Thread.sleep(2000);
					 try {
					 driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);					 
					 selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law suit type in CES Page");
					 }catch(NoSuchElementException e) {}
					 Thread.sleep(2000);					 
					 try {						 
					  driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
					  selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}				
					 Thread.sleep(3000);
					 waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
					 assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
					 type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box in CES Page");

					 waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
					 assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
					 type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box CES Page");	

					 waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
					 assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
					 type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");

				  }
				 else if (relatedWorksheet != 0) {
				 //FIRST_WORKSHEET_RADIO_BTN
				 waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				 assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				 click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				 //ADD_TO_DOCKET_HISTORY_BUTTON
				 waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
				 assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
				 click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
				 Thread.sleep(2000);
				 waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
				 caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 
				 if(cdsop.equals("CDSOP")) {
					 compareStrings(caseNumber,"19342919");
				 }

				 else if(!cdsop.equals("CDSOP")) {

					 compareStrings(caseNumber,caseNum1);
				 }				 
				}
			}
				 if(!caseNum2.equals("")){
				 //SELECT_BUTTON_IN_RELATED_LOG
				 waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
				 assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
				 click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
				 //CASEID_TEXTBOX
				 waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
				 assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
				 if(cdsop.equals("CDSOP")) {
					 type(SOP.CASEID_TEXTBOX,"19342919", "Case number Search text box");					 
				 }
				 else if(!cdsop.equals("CDSOP")) {
					 type(SOP.CASEID_TEXTBOX,caseNum2, "Case number Search text box");					 
				 }

				 //SEARCH_BTN
				 waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				 assertElementPresent(SOP.SEARCH_BTN, "Search button");
				 click(SOP.SEARCH_BTN, "Search button");
				 //FIRST_WORKSHEET_RADIO_BTN
				 waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				 assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				 click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
				 //ADD_TO_DOCKET_HISTORY_BUTTON
				 waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
				 assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
				 click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
				 Thread.sleep(2000);
				 waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
				 caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 	
				 if(cdsop.equals("CDSOP")) {
					 compareStrings(caseNumber,"19342919");
				 }
				 else if(!cdsop.equals("CDSOP")) {

					 compareStrings(caseNumber,caseNum2);
				 }
				}


			if(caseNum1.equals("")){
				Thread.sleep(1000);
				driver.switchTo().defaultContent();
				assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
				click(SOP.GLYPHICON_HOME, "glyphicon button");
				Thread.sleep(3000);
				driver.switchTo().frame("frame1");		
				//PLAINTIFF_TEXT_BOX			
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
				//DEFENDANT_TEXT_BOX				
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
				try {
					driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
					selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
					}catch(NoSuchElementException e) {}
					//DOCUMENT_TYPE_DROPDWN
					try {
					driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
					selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}				
			}
		}
	}
		}
			Thread.sleep(3000);
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			//Below one check can be applied if attorney and court modification needs to be done - 1476
			if(!attorneyName.equals("")) {			 			
					//RADIO_BUTTON_ATTORNEYNONE					
					String attorneyNoneAttribute = "";				
					try {					
						//USE_THIS_ATTORNEY
						waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
						assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
						click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");

						//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						type(SOP.TEXT_BOX_ATTORNEYNAME,"Alan H. Weinreb","Text box to enter attorney name");

						//ATTORNEY_ADDRESS_LINE_ONE
					    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	

						//CITY_NAME
						waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");

						//ATTORNEY_STATE_NAME
						waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");

						//ATTORNEY_ZIP_CODE
						waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");


				   } catch (NoSuchElementException e) {}}

			if(!courtName.equals("")) {					
					try {

						//USE_THIS_COURT
						waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
						assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
						click(SOP.USE_THIS_COURT,"Use this court radio button");
						//COURT_NAME_TEXT_BOX
						waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
						assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
						type(SOP.COURT_NAME_TEXT_BOX,courtName,"Court NAme");
						//ADDRESS_LINE_ONE
						waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
						assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
						type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
						//CITY_NAME
						waitForElementPresent(SOP.CITY_NAME,"City Name text box");
						assertElementPresent(SOP.CITY_NAME,"City Name text box");
						type(SOP.CITY_NAME,"Houston","City Name text box");
						//STATE_NAME
						waitForElementPresent(SOP.STATE_NAME,"State Name text box");
						assertElementPresent(SOP.STATE_NAME,"State Name text box");
						type(SOP.STATE_NAME,"TX","State Name text box");
						//ZIP_CODE
						waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
						type(SOP.ZIP_CODE,"77550","Zip code text box");

				   } catch (NoSuchElementException e) {}
					if(attorneyNoneAttribute == null) {						
						//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
						assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
						type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"text field for Attorney Sender Name");	
					}
					if(courtNoneAttribute == null) {						
						//TEXT_BOX_COURTNAME
						waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
						assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
						type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");	

					}																
			}			 

			//Below one code is to escalate as Possible REjection
			if(!escalationReason.equals("")) {
				//Below one condition needs to be set if the L2 user processing CES from Escalated List
				//then update to possible rejection click can be done from here.		
				if((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List")) && escalationReason.equals("Update to Possible Rejection")) {
				//UPDATE_TO_POSSIBLE_REJECTION
				 waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
				 assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
				 click(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");

				}
				 if(cesQueue.equals("Escalated List") && escalationReason.equals("Update to Possible Rejection & GetNext")) {
				//UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
				waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
				assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
				click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");	
				Thread.sleep(5000);
				 }				
				 if(!escalationReason.equals("Update to Possible Rejection") && !escalationReason.equals("Update to Possible Rejection & GetNext")){								
				//ESCALATION_DETAILS
				waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
				//REASON_DRPDWN
				waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");
				//ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Could be a Possible Rejection", "Escalation text box");
				//ESCALATE_BTN
				waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				click(SOP.ESCALATE_BTN, "Escalate button");
				}	
			}
			else if(rejectionReason.equals("") && reject.equals("Y")) {
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");	
				//REJECT_REASON_EMPTY_ERROR
				waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				compareStrings(error,errorMessage);

			}
			else if(!rejectionReason.equals("") && !reject.equals("")) {
				//REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
				if(!notRejecting.equals("")) {
				//REASON_FOR_NOT_REJECTING
				waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
				assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
				selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reason for not Rejecting drop down");
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");								
				//ERROR_REASON_FOR_NOT_REJECTING_SELECTED
				waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
				assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
				String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
				compareStrings(error,errorMessage);
			}
				else if(notRejecting.equals("")) {
				if(attorneyName.equals("")) {
				//ATTORNEY_SENDER_NONE_SPECIFIED
				waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
				assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
				click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
				}
				Thread.sleep(2000);
				//commenting below as List of WebElemets not required
				//List<WebElement> traceableMail = null;
				WebElement traceableMail = null;
				try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
				type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
				}catch(NoSuchElementException e) {}
			    //HARD_COPY_DELIVERY
				waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
				String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				//REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				Thread.sleep(5000);												
				if(hardCopy.equals("No") && error.equals("")) {		
					String parentWin= driver.getWindowHandle();
					Thread.sleep(2000);
					handlePopUpWindwow();
					String letterPopup = driver.getCurrentUrl();
					String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1]).get(0);		
					assertTextContains(letterPopup,rejectLog);
					driver.close();
					driver.switchTo().window(parentWin);
				}				
				//ATTORNEY_SENDER_NOT_SELECTED_ERROR
				if(attorneyName.equals("")) {
				waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
				assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
				String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
				compareStrings(error,errorMessage);
				}
			}
		}			
            else if(escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
            	if  (!rejectionReason.equals("")){
    			waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
    			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
    			selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
    			//REASON_FOR_NOT_REJECTING
				waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
				assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
				selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
				Thread.sleep(2000);
				List<WebElement> traceableMail = null;
				//TRACEABLE_MAIL_FIELD
				try {				
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
				type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
				}catch(NoSuchElementException e) {}
				//SUBMIT_CES				
				waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
				assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
				click(SOP.SUBMIT_CES, "Submit button in CES Page");	
				//SUBMIT_ERROR_REJECT_REASON_SELECTED
				waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
				assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
				String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
				compareStrings(error,errorMessage);
            	}
            	else if  (rejectionReason.equals("")){
    			List<WebElement> traceableMail = null;
    			//TRACEABLE_MAIL_FIELD
    			try {
    			traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
    			if(traceableMail != null) { 

    				type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
    			 }
    			}catch(NoSuchElementException e) {}	
    			//REASON_FOR_NOT_REJECTING
    			if(cesQueue.equals("Rejections List")) {
				waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
				assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
				selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
				Thread.sleep(2000);
    			}
    			//SUBMIT_CES
    			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
    			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
    			click(SOP.SUBMIT_CES, "Submit button in CES Page");	
            	}
            }
            else if(!onHold.equals("")) {
            	//REASON_FOR_HOLD_TEXTBOX
            	waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
    			assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
    			type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
    			//ONHOLD_BTN
    			waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
    			assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
    			click(SOP.ONHOLD_BTN, "On Hold button");
            }

	}catch(Exception e) {}
	return esopId.split("\\: ")[1];	
  }
	 */

	//This is added in common fxn file
	/*public String viewAndCreateTheWorkSheetUsingESOPId(String reportSheet, int count,String esopId) throws Throwable{
	String worksheetId = null;
	try{				
	String defendentName = Excelobject.getCellData(reportSheet, "WS Defendent Name", count);
	String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
	String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);
	String attorney = Excelobject.getCellData(reportSheet, "WS Attorney", count);
	String court = Excelobject.getCellData(reportSheet, "WS Court", count);
	String documentServed = Excelobject.getCellData(reportSheet, "Document Served", count);
	String caseNum = Excelobject.getCellData(reportSheet, "WS Case Number", count);
	String plaintiff = Excelobject.getCellData(reportSheet, "WS Plaintiff", count);

	waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
	assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
	click(SOP.SOP_LINK_HEADER, "SOP link in header");
	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
	assertElementPresent(SOP.CLEARBTN, "Clear Button");
	click(SOP.CLEARBTN, "Clear Button");
    searchForESOP(esopId);		
	try {		 
		WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
		waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
	    searchForESOP(esopId);			

	}catch(NoSuchElementException e) {}
	Thread.sleep(10000);
	selectAndAssignTheFileToTeam();
	Thread.sleep(10000);
	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
	assertElementPresent(SOP.CLEARBTN, "Clear Button");
	click(SOP.CLEARBTN, "Clear Button");
	searchForESOP(esopId);
	Thread.sleep(2000);
	String parentWindow= driver.getWindowHandle();		
	waitForElementPresent(SOP.VIEW_BTN, "View button");
	assertElementPresent(SOP.VIEW_BTN, "View button");		
	click(SOP.VIEW_BTN, "View button");		
	handlePopUpWindwow();
	driver.close();
	driver.switchTo().window(parentWindow);
	Thread.sleep(3000);
	WebElement createWs = null;
	try {
	createWs = driver.findElement(SOP.CREATE_WORKSHEET);
	waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	}catch(NoSuchElementException e) {			
	}
	if(createWs == null) {
		Thread.sleep(4000);
		selectAndAssignTheFileToTeam();
		Thread.sleep(4000);
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOP(esopId);
		Thread.sleep(2000);
		String parentWin= driver.getWindowHandle();		
		waitForElementPresent(SOP.VIEW_BTN, "View button");
		assertElementPresent(SOP.VIEW_BTN, "View button");		
		click(SOP.VIEW_BTN, "View button");		
		handlePopUpWindwow();
		driver.close();
		driver.switchTo().window(parentWin);
		waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	}

	Thread.sleep(2000);
	WebElement initalRadioButton = null;
	try {			

		initalRadioButton = driver.findElement(SOP.INITIAL_RADIOBTN);	

	}catch(NoSuchElementException e) {}
	if(initalRadioButton == null) {
		 click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	}
	if(isAttempted.equalsIgnoreCase("Yes")){
		//ATTEMPTED_YES_RADIO_BUTTON
		waitForElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
		assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");	
		click(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
	}
	//INITIAL_RADIOBTN
	waitForElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");
	assertElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");	
	click(SOP.INITIAL_RADIOBTN,"Initial Radio button");
	if(!caseNum.equals("")) {
	//CASEID_TEXTBOX
	waitForElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");
	assertElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");	
	type(SOP.CASEID_TEXTBOX,caseNum,"Case Id text box");
	}
	if (!plaintiff.equals("")) {
	//PLAINTIFF_TEXT_BOX
	waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plaintiff text box");
	assertElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plantiff text box");	
	type(SOP.PLAINTIFF_TEXT_BOX,plaintiff,"Plantiff text box");
	}
	if(!defendentName.equals("")) {
	//DEFENDANT_TEXTFIELD
	waitForElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");	
	assertElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
	type(SOP.DEFENDANT_TEXTFIELD,defendentName,"Defendent text box");
	}
		//REJECT_REASON
	if(!rejectedReason.equals("")){
	assertElementPresent(WorksheetCreate.REJECTED_REASON,"Rejected Reason wroksheet step 1 page");
	selectByVisibleText(WorksheetCreate.REJECTED_REASON,rejectedReason,"Rejected Reason wroksheet step 1 page");
	assertElementPresent(SOP.DATE_CALENDAR, "Calendar Icon");
	click(SOP.DATE_CALENDAR, "Calendar Icon");
	click(Entity.TODAYSDATE, "Todays Date");
	assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");	
	click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
	Thread.sleep(1000);
	//COURT
	//below will be used to edit the court which will validate the story 1283
	assertElementPresent(WorksheetCreate.COURT,"Court in wroksheet step 2 page");		
	selectByVisibleText(WorksheetCreate.COURT,court,"Court in wroksheet step 2 page");
	}
	//else if(rejectedReason.equals("")){
	//For Certified mail below one check need to be added
	//POST_MARKED_DATE
	try {
	driver .findElement(WorksheetCreate.METHOD_OF_SERVICE);	
	String methodOfService = getText(WorksheetCreate.METHOD_OF_SERVICE,"Method of Service");
	if(methodOfService.contains("Mail") && !methodOfService.equals("Express Mail")){
		waitForElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
		assertElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
		int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
		String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
				+ String.valueOf(lastYear); 			
		type(WorksheetCreate.POST_MARKED_DATE,lastYearDate,"Post marked Date text box");
	}}catch(NoSuchElementException e) {}
	//EDIT_RECEIVED_BY
	selectByIndex(WorksheetCreate.EDIT_RECEIVED_BY,1,"Received By drop downs in wroksheet step 1 page");
	//WORKSHEET_TYPE
	waitForElementPresent(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in wroksheet step 1 page");
	String worksheetType = getText(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in wroksheet step 1 page");
	//ENTITY_IN_WORKSHEET_PROFILE
	waitForElementPresent(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"Entity in wroksheet profile step 1 page");
	String entityInWorksheet = getAttribute(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"value");
	//NEXT_BTN		
	waitForElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
	assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");	
	click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
	Thread.sleep(1200);
	//below check for if error- > 'Enter a value for Other Mehod of Serivce.		
	try {

		driver.findElement(SOP.OTHER_METHOD_OF_SERVICE);
		Thread.sleep(2000);
		type(SOP.OTHER_METHOD_OF_SERVICE_TEXT_BOX,"Other", "Type the Text for other Method of Service");
		click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
		Thread.sleep(700);
	}catch (NoSuchElementException e) {}
	//below check for if Error -> Enter a valid value for Case#.
	try {
		//Below code is modified on 12/23 
		driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
		Thread.sleep(1000);
		boolean caseTextPsNum = false;
		//Below try block is added as some method of srvice has different way of SElecting the CASe# in worksheet page 1
		try {				
			driver.findElement(SOP.CASE_TEXT_PS_CASENUM);
			Thread.sleep(500);
			type(SOP.CASE_TEXT_PS_CASENUM,"CNInWorksheet", "Type the Text for other Method of Service");
			click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
			caseTextPsNum = true;
		}catch(NoSuchElementException e) {}
		if(caseTextPsNum == false) {
		type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for other Method of Service");
		click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
		Thread.sleep(700);
		}
	}catch (NoSuchElementException e) {}
	//This try block is added on 12/23
	try {
		driver.findElement(SOP.CASE_NUMBER_BLANK);
		type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for other Method of Service");
		click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
		Thread.sleep(700);
	}catch (NoSuchElementException e) {}


	//COURT_NAME_TEXT_BOX
	String attorneyNoneAttribute = "";
	String courtNameInWorksheet = "";

	try {
		attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");  
	}catch (NoSuchElementException e) {}
	try {	
		driver.findElement(SOP.EXISTING_COURTNAME);
		courtNameInWorksheet = getText(SOP.TEXT_BOX_COURTNAME,"value");
		System.out.println("Court name in WS : " + courtNameInWorksheet);
	}catch (NoSuchElementException e) {}
	//below code changed on 4/9/21
	//added one more if condition to prevent null object
	if (courtNameInWorksheet.equals("")) {
	try {
		driver.findElement(SOP.COURT_NAME_TEXT_BOX);
		courtNameInWorksheet = getAttribute(SOP.COURT_NAME_TEXT_BOX,"value");
		System.out.println("Court name in WS 2 : " + courtNameInWorksheet);
	}catch (NoSuchElementException e) {}
	}
		if (courtNameInWorksheet.equals("")) {
			courtNameInWorksheet = null;				
		}			
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);		
		compareStrings(courtNameInWorksheet,courtNameInCES);
	//TEXT_BOX_ATTORNEYNAME
	if(attorneyNoneAttribute == null) {
	waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in wroksheet step 2 page");
	assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in wroksheet step 2 page");	
	String attorneyNameInWorksheet = getAttribute(SOP.TEXT_BOX_ATTORNEYNAME,"value");
	if(attorneyNameInWorksheet.equals("")) {
		attorneyNameInWorksheet = null;
	}		
	String attorneyNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(0);
	compareStrings(attorneyNameInWorksheet,attorneyNameInCES);
	}
	if(courtNameInWorksheet == null) {
	waitForElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in wroksheet step 2 page");
	assertElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in wroksheet step 2 page");
	click(SOP.COURT_NONE_RADIOBTN,"court none radio button in wroksheet step 2 page");
	}
	if(!court.equals("")) {
		//RADIO_BUTTON_EXISTING_COURT
		waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,"existing court radio button in wroksheet step 2 page");
		assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,"existing court radio button in wroksheet step 2 page");
		click(SOP.RADIO_BUTTON_EXISTING_COURT,"existing court radio button in wroksheet step 2 page");
		//DROP_DOWN_COURT_NAME
		assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"existing court drop down in wroksheet step 2 page");
		selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"existing court drop down in wroksheet step 2 page");
		Thread.sleep(1000);
	}
	if(!attorney.equals("")) {


		//USE_THIS_ATTORNEY
		waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
		assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
		click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");

		//TEXT_BOX_ATTORNEYNAME
		waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
		assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
	    type(SOP.TEXT_BOX_ATTORNEYNAME,attorney,"Text box to enter attorney name");

		//ADDRESS_NONE_SPECIFIED
	    waitForElementPresent(WorksheetCreate.ADDRESS_NONE_SPECIFIED,"None specified radio button in Address");
	    assertElementPresent(WorksheetCreate.ADDRESS_NONE_SPECIFIED,"None specified radio button in Address");
	    click(WorksheetCreate.ADDRESS_NONE_SPECIFIED,"None specified radio button in Address");

		//RADIO_BUTTON_EXISTING_ATTORNEYSENDER
		waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,"existing Attorney radio button in wroksheet step 2 page");
		assertElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,"existing Attorney radio button in wroksheet step 2 page");
		click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,"existing Attorney radio button in wroksheet step 2 page");
		//DROP_DOWN_ATTORNEY_SENDER_NAME
		assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"existing Attorney drop down in wroksheet step 2 page");
		selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"existing Attorney drop down in wroksheet step 2 page");
	}
	waitForElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 2 page");
	assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 2 page");	
	click(SOP.NEXT_BTN,"next button in wroksheet step 2 page");

	 WebElement docServed = null;
		try {
				docServed = driver.findElement(SOP.DOCUMENT_SERVED);					
				if (docServed != null) {
					click(SOP.FIRST_DOCUMENT_SERVED,"document Type drop down  in wroksheet step 3 page");
					Thread.sleep(2000);
					//DOCUMENT_SERVED_MOVE_RIGHT
					assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
				    click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
				    Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
			}
	if(!lawSuitSubtype.equals("")){
		//LAWSUITE_SUBTYPE
		assertElementPresent(WorksheetCreate.LAWSUITE_SUBTYPE,"law suit sub type in wroksheet step 3 page");
		selectByVisibleText(WorksheetCreate.LAWSUITE_SUBTYPE,lawSuitSubtype,"law suit sub type in wroksheet step 3 page");
	} 

	WebElement specialCircumStances = null;
	try {
		specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);					
			if (specialCircumStances != null) {
					selectByIndex(WorksheetCreate.SPECIAL_CIRCUMSTANCES,1," Special Cicumstances drop down  in wroksheet step 3 page");
				    Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
		}						
	else if(branchPlant.equals("NRAI")) {
		selectByVisibleText(SOP.DOCUMENT_SERVED,documentServed,"document Type drop down  in wroksheet step 3 page");
		//DOCUMENT_SERVED_MOVE_RIGHT
		assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
		click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
	}
	//ANSWER_DATE_NONE
	waitForElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in wroksheet step 3 page");
	assertElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in wroksheet step 3 page");	
	click(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in wroksheet step 3 page");
	if(saveIncomplete.equalsIgnoreCase("Yes")){
		//SAVE_INCOMPLETE_BUTTON
		waitForElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in wroksheet step 3 page");
		assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in wroksheet step 3 page");	
		click(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in wroksheet step 3 page");
	}
	//SAVE_BTN
	else if(saveIncomplete.equalsIgnoreCase("No")){		
	waitForElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	assertElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	click(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	Thread.sleep(2000);
	//DOCUMENT_TYPE_DROPDWN
	//here one check for if doc type is not selected	
	//Enter a value for Document Type.
try {
 WebElement docNotSelected = null;	
 docNotSelected = driver.findElement(WorksheetCreate.DOCUMENT_TYPE_NOT_SELECTED);
 if(docNotSelected != null) {	
	 selectByIndex(SOP.DOCUMENT_TYPE_DROPDWN,3,"document Type drop down  in wroksheet step 3 page");
	 waitForElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	 assertElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	 click(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
 }
}
 catch (NoSuchElementException e) {}
	}
	//WORKSHEET_ID_ON_CONTEXT_BAR
	waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
	assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");	
	//click(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
	worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
	if(worksheetId.equals(null)){
		throw new NullPointerException();
	}
	}catch(NullPointerException e){
		e.printStackTrace();
	}
	System.out.println("Worksheet id : " + worksheetId);
	Thread.sleep(3000);
	return worksheetId.split("\\: ")[1];
}
	 */

	public void metaDataInTheRejectedLog(String esopId) throws Throwable{	

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//WOKSHEET_SEARCH_LEFT_NAV_LINK
		waitForElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "worksheet search link in left nav");
		assertElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "assert worksheet search link in left nav");
		click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "click on worksheet search link in left nav");
		//CLASSIC_SEARCH_BTN
		waitForElementPresent(SOP.CLASSIC_SEARCH_BTN, "Classic search button in Worksheet Search Criteria Page");
		assertElementPresent(SOP.CLASSIC_SEARCH_BTN, "assert Classic search button in Worksheet Search Criteria Page");
		click(SOP.CLASSIC_SEARCH_BTN, "click on Classic search button in Worksheet Search Criteria Page");
		String worskheetId = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
		//WORKSHEET_ID_TEXTBOX
		waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Id text box in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "assert Id text box in Classic Worksheet Search Criteria Page");
		type(SOP.WORKSHEET_ID_TEXTBOX,worskheetId, "type Id in text box in Classic Worksheet Search Criteria Page");
		//WORKSHEET_SEARCH_BTN
		waitForElementPresent(SOP.WORKSHEET_SEARCH_BTN, "Search button in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_SEARCH_BTN, "assert Search button in Classic Worksheet Search Criteria Page");
		click(SOP.WORKSHEET_SEARCH_BTN, "click Search button in Classic Worksheet Search Criteria Page");

		//METADATA
		waitForElementPresent(SearchWorksheet.METADATA, "Meta data in Worksheet profile Page");
		assertElementPresent(SearchWorksheet.METADATA, "assert Meta data in Worksheet profile Page");
		String metaData = getText(SearchWorksheet.METADATA, "get the text for Meta data in Worksheet profile Page");
		String damageAmount = metaData.split("\\ Damage Amount : ")[1].split("\\ ,")[0].split("")[0];
		String timeSensitive = metaData.split("\\ Time Sensitive : ")[1].split("\\,")[0].split("")[0];
		String secondReview = metaData.split("\\Second Review : ")[1].split("\\,")[0].split("")[0];
		String shortAnswerDate = metaData.split("\\Short Answer : ")[1].split("\\ ")[0].split("")[0];
		System.out.println(damageAmount);
		System.out.println(timeSensitive);
		System.out.println(secondReview);
		System.out.println(shortAnswerDate);
		if(shortAnswerDate.equals("-")) {
			shortAnswerDate = "N";
		}		
		ArrayList<String> metaDataInRejectedLog = SQL_Queries.metaDataInRejectionLog(esopId);
		compareStrings(damageAmount,metaDataInRejectedLog.get(0));
		compareStrings(timeSensitive,metaDataInRejectedLog.get(1));
		compareStrings(secondReview,metaDataInRejectedLog.get(2));
		compareStrings(shortAnswerDate,metaDataInRejectedLog.get(3));		
	}

	public void validateCESDataInWorksheet(int test,String reportSheet, String [] esops) throws Throwable{

		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);						
			workSheetContainsPlaintiffAndDefendantValuesAsESOP(reportSheet, i+2,esops[i]);	
			driver.manage().deleteAllCookies();

		}				
	}

	public void validateCESDataModificationInWorksheet(int test,String reportSheet, String [] esops) throws Throwable{

		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);
			String worksheetId = viewAndCreateTheWorkSheetUsingESOPId(reportSheet, i+2,esops[i]);
			assignmentHistoryAndAudtitTrail(esops[i],worksheetId);		
			driver.manage().deleteAllCookies();

		}				
	}

	public Map<Integer,String> executeActionItemAfterWorksheetCreation(int test,String reportSheet, String [] esops) throws Throwable{

		Map<Integer,String> worksheets = new HashMap<Integer,String>();
		int logKey = 1;
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);						
			String worksheetId = viewAndCreateTheWorkSheetUsingESOPId(reportSheet, i+2,esops[i]);
			sopWorkflow(reportSheet, i+2,esops[i]);
			executeActionItem(reportSheet, i+2,esops[i]);					
			//executeActionItem("OptimizedManual Worksheet",iLoop,"");
			worksheets.put(logKey, worksheetId);
			logKey++;
			driver.manage().deleteAllCookies();
		}
		//Below one function to check if the log is posted
		driver.get(URL);
		String member = Excelobject.getCellData(reportSheet, "Member", 2);
		String team = Excelobject.getCellData(reportSheet, "Team", 2);
		SignIn(team, member);
		for(int i= 1; i<=worksheets.size() ; i++) {			
			searchWorksheet(worksheets.get(i));
			validateThePostStatusOfworksheet(worksheets.get(i));		
		}
		return worksheets;
	}

	public String verifyCreateWrksheetLinkAtArrowHomePage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			waitForElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			isElementNotPresent(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyCreateWrksheetLeftNavLink(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyCreateWrksheetLeftNavLinkDisabled(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.CES_LEFT_NAV_LINK, "CES Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "Worksheet Search Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Worksheet Search Criteria", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.WS_SEARCH_BY_BATCHNO_NAV_LINK, "WS Search By Batch No. Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Worksheet Search Criteria", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Package Search", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.CARRIER_PENDING_QUEUE, "Carrier Pending Queue Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Pending Queue", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.MY_ACTION_ITEMS_NAV_LINK, "My Action Items Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Action Items", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyCreateWrksheetBtnOnMyWorksheetsPg(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_BUTTON, "Create Worksheet Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_BUTTON, "Create Worksheet Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWorksheetNavLinkHighlighted(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title Of The Page");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyCreateWorksheetNavLinkHighlightedLevel1(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");
			//click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			createWorksheetViaSOPList(ReportSheet, count, esopID);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title Of The Page");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyUpdatedCourtListForCreateWorksheetPage(String reportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing Court drpdwn");
				verifyCourtListfieldstMethod(reportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			} else {
				System.out.println("No Court Field present on Create Worksheet Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyUpdatedCourtListForEditWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing court drpdwn");
				verifyCourtListfieldstMethod(ReportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyUpdatedCourtListForReviewWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");

			// Review Worksheet
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing Court drpdwn");
				verifyCourtListfieldstMethod(ReportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyExistingWorksheetWithOldCourt(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.OLD_COURT_JURISDICTION, "11th Judicial District Court Harris County", "Old Court Jurisdiction");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing court drpdwn");
				verifyCourtListfieldstMethod(ReportSheet, count);
				Thread.sleep(2000);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				assertTextMatching(SOP.OLD_COURT_JURISDICTION, "11th Judicial District Court Harris County", "Old Court Jurisdiction");

			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNoneSpecifiedCourtCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			//Use Non-Specified Court
			waitForElementPresent(SOP.COURT_NONE_RADIOBTN,"Court None Specified Radio Btn");
			assertElementPresent(SOP.COURT_NONE_RADIOBTN,"Court None Specified Radio Btn");
			click(SOP.COURT_NONE_RADIOBTN,"Court None Specified Radio Btn");

			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");


			createWorksheetViaSOPList(reportSheet, count, esopID);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			//Close the ML Slider
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			Thread.sleep(5000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			waitForElementPresent(SOP.RADIO_EXISTING_COURT, "Existing Court");
			assertElementPresent(SOP.RADIO_EXISTING_COURT, "Existing Court");
			if (verifyIfElementPresent(SOP.RADIO_EXISTING_COURT, "Existing Court")) {
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyUseThisCourtCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "mt", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "mt", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			//USE_THIS_COURT
			waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			click(SOP.USE_THIS_COURT,"Use this court radio button");
			//COURT_NAME_TEXT_BOX
			waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			type(SOP.COURT_NAME_TEXT_BOX, "Tesla Court","Court NAme");
			//ADDRESS_LINE_ONE
			waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
			//CITY_NAME
			waitForElementPresent(SOP.CITY_NAME,"City Name text box");
			assertElementPresent(SOP.CITY_NAME,"City Name text box");
			type(SOP.CITY_NAME,"Houston","City Name text box");
			//STATE_NAME
			waitForElementPresent(SOP.STATE_NAME,"State Name text box");
			assertElementPresent(SOP.STATE_NAME,"State Name text box");
			type(SOP.STATE_NAME,"TX","State Name text box");
			//ZIP_CODE
			waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
			assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
			type(SOP.ZIP_CODE,"77550","Zip code text box");

			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");

			createWorksheetViaSOPList(reportSheet, count, esopID);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			assertElementPresent(SOP.RADIO_USE_THIS_COURT, "Use This Court");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyStateOfCourtForLevel1User(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			isElementNotPresent(SOP.COURT_LABEL, "Court Label");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");

			createWorksheetViaSOPList(ReportSheet, count, esopID);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyStateOfCourtForLevel2User(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "kent", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "kent", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			isElementNotPresent(SOP.COURT_LABEL, "Court Label");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			createWorksheetViaSOPList(ReportSheet, count, esopID);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyUpdatedCourtListForCESPage(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");

			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");

			/*// click on Select button of ARROW Entity box

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

			// enter entity name in Entity Search page and click on Search
			// button
			type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
			click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(5000);
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");

			// click on 1st entity of the search result, click on Home icon
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");
			Thread.sleep(5000);
			waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

			// Enter log id in log text field
			type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(4000);
			// Click on Unrelated worksheet
			click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");*/

			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Received Jurisdcition");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing Court drpdwn");
				verifyCourtListfieldstMethod(reportSheet, count);
			}
			/*waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");
			// select Lawsuit Type 
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");*/

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;

	}
	
	public String verifyCourtListfieldstMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalCourtList = new ArrayList<String>();
			List<String> updatedCourtList = Arrays.asList("-- Select One --", "Alleghany County Superior Court", "Eastern District of New York - U.S. District Court...",
					"Eastern District of New York United States Distric...", "Nassau County Circuit Court", "Nassau County District Court",
					"Nassau County: District Court, 1st District: Hemps...", "Nassau County: District Court, 2nd District: Hemps...", "Nassau County: District Court, 3rd District: Great...",
					"Nassau County: District Court, 4th District: Hicks...", "New York District - Supreme Court - Erie Division", "New York Eastern District - U.S. Bankruptcy Court",
					"New York Eastern District - U.S. Bankruptcy Court ...", "New York Eastern District - U.S. Bankruptcy Court ...", "New York Eastern District - U.S. Bankruptcy Court ...", "New York Middle District - U.S. Bankruptcy Court -...",
					"New York Northern District - U.S. Bankruptcy Court...",
					"New York Northern District - U.S. District Court",
					"New York Southern District - Bankruptcy Court - Wh...", "New York Southern District - U. S. Bankruptcy Cour...", "New York Southern District - U.S. Bankruptcy Court",
					"New York Southern District - U.S. Bankruptcy Court...", "New York Southern District - U.S. Bankruptcy Court...", "New York Southern District - U.S. Bankruptcy Court...", "New York Southern District - U.S.District Court", "New York Southern District: United States District...",
					"New York Western District - U.S. Bankruptcy Court ...", "New York Western District -U.S. Bankruptcy Court", "Queens County: Criminal Court", "Southern District New York - United States Distric...", "Southern District of New York -United States Distr...", "Suffolk County: District Court", "Suffolk County: District Court, 10th District",
					"Suffolk County: District Court, 1st District: Ronk...", "Suffolk County: District Court, 2nd District", "Suffolk County: District Court, 3rd District: Hunt...", "Suffolk County: District Court, 4th District: Haup...", "Suffolk County: District Court, 6th District", "Suffolk County: District Court: 5th District", "Superior Court of Monroe County", "U.S. District Court, Western District, Buffalo Div...",
					"United States District Court, Western District");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {

				// Select Court from dropdown
				click(SOP.DROP_DOWN_COURT_NAME, "Select Court Name from dropdown");

				List<WebElement> arr = getAllDropDownData(SOP.DROP_DOWN_COURT_NAME);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalCourtList.add(we.getText());
				}
				compareTwoArrayList(updatedCourtList, originalCourtList);
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}
	
	public String multipleFieldVerification(String pageTitle, String flagShip) throws Throwable {
		String flag = "false";

		try {
			if (pageTitle.equals("SOP Worksheet Profile")) {
				if (verifyIfElementPresent(SOP.MULTIPLE_YES_FIELD, "Multiple Yes Field")) {
					assertElementPresent(SOP.MULTIPLE_FIELD_ON_WORKSHEET_PROFILE,
							"Mutiple fields on Worksheet Profile Page");
					flag = "true";
					return flag;
				} else {
					isElementNotPresent(SOP.MULTIPLE_YES_FIELD, "Multiple Yes Field");
				}
			} else if (pageTitle.equals("Edit Worksheet") || pageTitle.equals("Review Worksheet")) {
				if(flagShip.equalsIgnoreCase("1")) {
					if (verifyIfElementPresent(SOP.MULTIPLE_YES_RADIO_BTN_SELECTED, "Multiple Yes Radio Button Selected")) {
						assertElementPresent(SOP.DISABLED_CASE_ID_TEXTBOX, "Disabled Case Id Textbox");
						assertElementPresent(SOP.DISABLED_PLAINTIFF_DEBTOR_TEXTBOX, "Disabled Plaintiff/Debtor Textbox");
						assertElementPresent(SOP.CASE_SORTING_GRID, "Case Sorting Grid");
						isElementNotPresent(SOP.ADDUPDATELIST_BTN, "Add Update List Button");
						isElementNotPresent(SOP.CLEAR_BTN, "Clear Button");
						isElementNotPresent(SOP.GRID_EDIT_BTN, "Edit Button");
						isElementNotPresent(SOP.GRID_DELETE_BTN, "Delete Button");
						assertElementPresent(SOP.CREATE_SEPARATE_TRANSMITTAL_PER_CASE_CHECKBOX,
								"Disabled Create Separate Transmittal Per case checkbox");
						click(SOP.MULTIPLE_FIELD_NO_RADIO_BTN, "Multiple Field Radio Button");
						assertElementPresent(SOP.CASE_ID_NONE_SPECIFIED, "Case Id None Specified Radio Button");
						isElementNotPresent(SOP.CREATE_SEPARATE_TRANSMITTAL_PER_CASE_CHECKBOX,
								"Disabled Create Separate Transmittal Per case checkbox");
						isElementNotPresent(SOP.CASE_SORTING_GRID, "Case Sorting Grid");
						click(SOP.CONSOLIDATED_YES_RADIO_BTN, "Consolidated Radio Button as Yes");
						type(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX, "test", "Consolidated Defendant Textbox");
						selectByIndex(SOP.REMARKS_DRPDWN, 1, "Remarks dropdown");
						click(SOP.BOTTOM_SAVEBTN, "Save Button");
						waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Edit Worksheet Title");
						assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile Title");
						isElementNotPresent(SOP.MULTIPLE_YES_FIELD, "Multiple Yes Field");

					}
				}
				else {
					isElementNotPresent(SOP.MULTIPLE_FIELD_ON_WORKSHEET_PROFILE,
							"Mutiple fields on Worksheet Profile Page");

				}

			} else {
				isElementNotPresent(SOP.MULTIPLE_FIELD, "Multiple Field");
				isElementNotPresent(SOP.MULTIPLE_FIELD_YES_RADIO_BTN, "Multiple Field Yes Radio Button");
				isElementNotPresent(SOP.MULTIPLE_FIELD_NO_RADIO_BTN, "Multiple Field No Radio Button");

			}
			return flag;
		}

		catch (Exception e) {
			throw e;
		}
	}

	public void priorityFieldVerification(String pageTitle) throws Throwable {

		try {
			if (pageTitle.equals("Worksheet Profile")) {
				isElementNotPresent(SOP.PRIORITY_FIELD_ON_WORKSHEET_PRO_PAGE,
						"Priority Field on Worksheet Profile Page");

			} else {
				isElementNotPresent(SOP.PRIORITY_FIELD_DRPDWN, "Priority Field Dropdown");
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyMultipleFieldOnCreateWorksheetPage(String ReportSheet, int count, String esopId)
			throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			
			multipleFieldVerification(PageTitle, "0");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFieldOnCreateWorksheetPage(String ReportSheet, int count, String esopId)
			throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			
			priorityFieldVerification(PageTitle);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMultipleFieldOnEditandWorksheetProfilePage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			String flag = multipleFieldVerification(PageTitle, "0");

			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			if (flag.equalsIgnoreCase("true")) {
				PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
				multipleFieldVerification(PageTitle,"1");
			}
			else if(flag.equalsIgnoreCase("false")){
				PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
				multipleFieldVerification(PageTitle,"0");
			}
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFieldOnEditandWorksheetProfilePage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			String PageTitle = getText(SOP.PAGE_TITLE, "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			
			priorityFieldVerification(PageTitle);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyWorksheetPopUpPageForWorksheetType(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			String WorksheetType = getText(SOP.WORKSHEET_TYPE, "WOrksheet Type");
			if (WorksheetType.equals("DSSOP")) {
				assertElementPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				assertElementPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				assertElementPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");

			} else {
				isElementNotPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				isElementNotPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				isElementNotPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");

			}
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMessageTextOnSOPPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.NEW_MESSAGE_HEADER, "You have new messages");
			isElementNotPresent(SOP.NEW_MESSAGE_HEADER, "Your team has new messages");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNewMessagesLeftNavLink(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.MY_MESSAGES, "My Messages Left Nav Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetCreate(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Top Send Message Button");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetEdit(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Top Send Message Button");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			//Verify Review Worksheet Page
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Top Send Message Button");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMessageOnSOPList(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.SEND_MESSAGE_ON_SOP_LIST, "Send Message Btn on SOP List Pg.");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnFedexPackageProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			click(SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Package Search", "Title Of The Page");
			click(SOP.SEARCH_BTN, "Search Button");
			click(SOP.FIRST_WORKSHEET, "First Package ID");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Package Profile", "Title Of The Page");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnChooseDIPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
			assertTextMatching(SOP.PAGE_TITLE, "Choose Delivery Instruction", "Title of the page");
			isElementNotPresent(SOP.SEND_MSG_BTN, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySendMessageOnActionItemsPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.ACTION_ITEMS_LEFT_NAV_LINK, "Action Items Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Execute Action Items", "Title of the page");
			isElementNotPresent(SOP.SEND_MESSAGE_BTN_ON_ACTIONLIST, "Send Message Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	

	public String entityDetailsOnProcessingCESUploadImage(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			blnEventReport = true;
			String caseNumber = "";
			int relatedWorksheet = 0;
			String cesQueue = Excelobject.getCellData(ReportSheet, "CES Queue", count);
			String arrowEntity = Excelobject.getCellData(ReportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(ReportSheet, "User Level", count);				
			String caseNum1 = Excelobject.getCellData(ReportSheet, "Case Number", count);
			String caseNum2 = Excelobject.getCellData(ReportSheet, "New Case Number", count);
			String escalationReason = Excelobject.getCellData(ReportSheet, "Escalation Reason", count);
			String rejectionReason = Excelobject.getCellData(ReportSheet, "Rejection Reason", count);
			String notRejecting = Excelobject.getCellData(ReportSheet, "Reason for Not Rejecting", count);
			String error = Excelobject.getCellData(ReportSheet, "Error Message", count);
			String plaintiff = Excelobject.getCellData(ReportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(ReportSheet, "Defendant", count);
			String reject = Excelobject.getCellData(ReportSheet, "Reject", count);
			String onHold = Excelobject.getCellData(ReportSheet, "On Hold", count);
			String attorneyName = Excelobject.getCellData(ReportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(ReportSheet, "Court", count);
			uploadImage(ReportSheet, count);
			TimeUnit.MINUTES.sleep(5);
			refreshPage();
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");			
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"Batch #","Filter drop down");
			waitForElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN2,"contains","Filter drop down");
			waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter second drop down");
			assertElementPresent(SOP.FILTERTEXTFIELD, "Filter second drop down");
			type(SOP.FILTERTEXTFIELD,"12345", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");

			try {		 
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);	
			}catch(NoSuchElementException e) {}
			Thread.sleep(1000);
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(1000);

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			Thread.sleep(3000);

			//TRAINGLE_ICON_ARROW_ENTITY			
			//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			//INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
			if(!arrowEntity.equals("")) {				
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {			
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 

				if(!cdsop.equals("CDSOP")) {											
					if (branchPlant.equals("CTCORP")) {
						//CTCORP_RADIO_BUTTON
						waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
					}
				}
				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
				if(cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
				}
				else if(!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
				}
				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				//ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if(entitySearchCount == 0) {
					//Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {				
						disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					}catch(NullPointerException e) {}
					if(disabledUnEntity == null) {
						click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
					Thread.sleep(1500);
					System.out.println("REached here in line 6420");
					try {
						if(disabledUnEntity.equals("true")) {					
							//SEARCH_AGAIN_BUTTON
							waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
							assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							//CANCEL_BUTTON
							waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
							assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							click(SOP.CANCEL_BUTTON, "Cancel Button");
						}}catch(NullPointerException e) {}				
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					//below will be a go ahead when the value for unidentified Entity above is selected
					String unEntityRadioSelected = "";
					try {                	 
						unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
					}catch(NoSuchElementException e) {}
					catch(NullPointerException e) {}
					Thread.sleep(1000);
					try {
						if(unEntityRadioSelected == null) {
							click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}}catch(NullPointerException e) {}
					//ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
					//DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
					//REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
					try {
						//waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
						//assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
					}catch(NoSuchElementException e) {}
					//DOCUMENT_TYPE_DROPDWN
					try {
						//waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
						//assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}
					//PLAINTIFF_TEXT_BOX			
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
					//DEFENDANT_TEXT_BOX				
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
					type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
				}
				else if(entitySearchCount != 0) {
					//REP_STATUS_SORT
					waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					//FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					//CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if(action.size()>0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					}
					catch(NoSuchElementException e) {

					}
					if(!caseNum1.equals("")){					
						//CASEID_TEXTBOX
						waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						if(cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,"19342919","Case number Search text box");
							click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
							click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
						}
						else if(!cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,caseNum1,"Case number Search text box");
							click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
							click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
							
						}
						//SEARCH_BTN
						waitForElementPresent(SOP.SEARCH_BTN, "Search button");
						assertElementPresent(SOP.SEARCH_BTN, "Search button");
						click(SOP.SEARCH_BTN, "Search button");
						//TOTAL_RECORDS_RELATED_WORKSHEET				 				 
						waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results");				 
						relatedWorksheet = Integer.parseInt(getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results"));
						Thread.sleep(1000);
						if(relatedWorksheet == 0) {

							click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
							Thread.sleep(2000);
							//RADIO_PRESENTATION_BUTTON
							String repChecked = "";
							try {
								repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked"); 
							}catch(NoSuchElementException e) {}
							if(repChecked == null) {
								//REP_JURISDICTION_SELECTION
								waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
								assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
								selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");
							}
							Thread.sleep(2000);
							try {
								driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);					 
								selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law suit type in CES Page");
							}catch(NoSuchElementException e) {}
							Thread.sleep(2000);					 
							try {						 
								driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
								selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
							}catch(NoSuchElementException e) {}				
							Thread.sleep(3000);
							waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
							assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
							type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box in CES Page");

							waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
							assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
							type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box CES Page");	

							waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
							assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
							type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");

						}
						else if (relatedWorksheet != 0) {
							//FIRST_WORKSHEET_RADIO_BTN
							waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							//ADD_TO_DOCKET_HISTORY_BUTTON
							waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
							Thread.sleep(2000);
							waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
							caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 
							if(cdsop.equals("CDSOP")) {
								compareStrings(caseNumber,"19342919");
							}

							else if(!cdsop.equals("CDSOP")) {

								compareStrings(caseNumber,caseNum1);
							}				 
						}
					}
					if(!caseNum2.equals("")){
						//SELECT_BUTTON_IN_RELATED_LOG
						waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
						assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
						click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
						//CASEID_TEXTBOX
						waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
						if(cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,"19342919", "Case number Search text box");					 
						}
						else if(!cdsop.equals("CDSOP")) {
							type(SOP.CASEID_TEXTBOX,caseNum2, "Case number Search text box");					 
						}

						//SEARCH_BTN
						waitForElementPresent(SOP.SEARCH_BTN, "Search button");
						assertElementPresent(SOP.SEARCH_BTN, "Search button");
						click(SOP.SEARCH_BTN, "Search button");
						//FIRST_WORKSHEET_RADIO_BTN
						waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
						assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
						click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
						//ADD_TO_DOCKET_HISTORY_BUTTON
						waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
						assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
						click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
						Thread.sleep(2000);
						waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
						caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 	
						if(cdsop.equals("CDSOP")) {
							compareStrings(caseNumber,"19342919");
						}
						else if(!cdsop.equals("CDSOP")) {

							compareStrings(caseNumber,caseNum2);
						}
					}


					if(caseNum1.equals("")){
						Thread.sleep(1000);
						driver.switchTo().defaultContent();
						assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
						click(SOP.GLYPHICON_HOME, "glyphicon button");
						Thread.sleep(3000);
						driver.switchTo().frame("frame1");		
						//PLAINTIFF_TEXT_BOX			
						waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
						//DEFENDANT_TEXT_BOX				
						waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
						try {
							driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
						}catch(NoSuchElementException e) {}
						//DOCUMENT_TYPE_DROPDWN
						try {
							driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
							selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}				
					}
				}
			}
			Thread.sleep(3000);
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			//Below one check can be applied if attorney and court modification needs to be done - 1476
			if(!attorneyName.equals("")) {			 			
				//RADIO_BUTTON_ATTORNEYNONE					
				String attorneyNoneAttribute = "";

				try {
					attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");   			
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
					//DROP_DOWN_ATTORNEY_SENDER_NAME
					waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"Drop down for Attorney Sender Name");
					assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"DROP down for Attorney Sender Name");
					selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"DROP down for Attorney Sender Name");
				} catch (NoSuchElementException e) {}}

			if(!courtName.equals("")) {					
				try {
					String courtNoneAttribute = "";
					courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					//DROP_DOWN_COURT_NAME
					waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
					assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
					selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");
				} catch (NoSuchElementException e) {}
				/*if(attorneyNoneAttribute == null) {						
					//TEXT_BOX_ATTORNEYNAME
					waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
					assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
					type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"text field for Attorney Sender Name");	
				}
				if(courtNoneAttribute == null) {						
					//TEXT_BOX_COURTNAME
					waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
					assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
					type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");	

				}	*/															
			}			 

			//Below one code is to escalate as Possible REjection
			if(!escalationReason.equals("")) {
				//Below one condition needs to be set if the L2 user processing CES from Escalated List
				//then update to possible rejection click can be done from here.		
				if((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List")) && escalationReason.equals("Update to Possible Rejection")) {
					//UPDATE_TO_POSSIBLE_REJECTION
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");

				}
				if(cesQueue.equals("Escalated List") && escalationReason.equals("Update to Possible Rejection & GetNext")) {
					//UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");	
					Thread.sleep(5000);
				}				
				if(!escalationReason.equals("Update to Possible Rejection") && !escalationReason.equals("Update to Possible Rejection & GetNext")){								
					//ESCALATION_DETAILS
					waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
					//REASON_DRPDWN
					waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");
					//ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Could be a Possible Rejection", "Escalation text box");
					//ESCALATE_BTN
					waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					click(SOP.ESCALATE_BTN, "Escalate button");
				}	
			}
			else if(rejectionReason.equals("") && reject.equals("Y")) {
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");	
				//REJECT_REASON_EMPTY_ERROR
				waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				compareStrings(error,errorMessage);

			}
			else if(!rejectionReason.equals("") && !reject.equals("")) {
				//REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
				if(!notRejecting.equals("")) {
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reason for not Rejecting drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");								
					//ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
				else if(notRejecting.equals("")) {
					if(attorneyName.equals("")) {
						//ATTORNEY_SENDER_NONE_SPECIFIED
						waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					//commenting below as List of WebElemets not required
					//List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {				
						traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}
					//HARD_COPY_DELIVERY
					waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
					String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);												
					if(hardCopy.equals("No") && error.equals("")) {		
						String parentWin= driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow();
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1]).get(0);		
						assertTextContains(letterPopup,rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}				
					//ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if(attorneyName.equals("")) {
						waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						compareStrings(error,errorMessage);
					}
				}
			}			
			else if(escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
				if  (!rejectionReason.equals("")){
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {				
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}
					//SUBMIT_CES				
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
					//SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
				else if  (rejectionReason.equals("")){
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 

							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}	

					/* Below Code is addded on 1/21 as part of GCNBO-1740
			  To handle the onhold submit scenario when the
			  Escalation Reason for the esop is Possible Rejection    			  
					 */
					if(cesQueue.equals("OnHold List")) {
						//ESCALATION_DETAILS
						waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");	
						//ESCALATION_REASON
						waitForElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						assertElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						String escalationReasonInOnHold = getText(SOP.ESCALATION_REASON, "Escalation Reason");	

						if(escalationReasonInOnHold.equals("Possible Rejection")) {
							waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							selectByIndex(SOP.REASON_FOR_NOT_REJECTING,1,"Reject Reason drop down");
							Thread.sleep(2000);	

						}
					}    			    			
					/* Till here the code change made as on 1/21 */






					//REASON_FOR_NOT_REJECTING
					if(cesQueue.equals("Rejections List")) {
						waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
						Thread.sleep(2000);
					}
					//SUBMIT_CES
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
				}
			}
			else if(!onHold.equals("")) {
				//REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
				//ONHOLD_BTN
				waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				click(SOP.ONHOLD_BTN, "On Hold button");
			}


		}catch(Exception e) {}
		return esopId.split("\\: ")[1];	

	}

	public String verifyRelatedLogSubsequentByDefault(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementPresent(SOP.SUBSEQUENT_TYPE, "Subsequent");
			//assertTextMatching(SOP.SUBSEQUENT_TYPE, "Subsequent", "Initial field changed to Subsequent");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyExistingLogOnWorksheetProfilePage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");

			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "autolog", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");
			click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet");
			click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket History");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.SUBSEQUENT, "Subsequent", "Subsequent");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyExistingLogOnWorksheetEditPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");

			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");
			click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet");
			click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket History");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementPresent(SOP.SUBSEQUENT_TYPE, "Subsequent");
			//assertTextMatching(SOP.SUBSEQUENT_TYPE, "Subsequent", "Initial field changed to Subsequent");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityColumnOnMyWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.PRIORITY_COLUMN, "Priority Column On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPrioritySortOnMyWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.PRIORITY_SORT_LINK_MYWORKSHEETS_PAGE, "Priority Sort Link On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFilterOnMyWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.PRIORITY_FILTER, "Priority Field Dropdown On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityColumnOnMyTeamsWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.PRIORITY_COLUMN, "Priority Column On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPrioritySortOnMyTeamsWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.PRIORITY_SORT_LINK_MYWORKSHEETS_PAGE, "Priority Sort Link On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFilterOnMyTeamsWorksheetsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.PRIORITY_FILTER, "Priority Field Dropdown On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFieldOnWorksheetPopUpPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			isElementNotPresent(SOP.PRIORITY_FIELD_ON_WORKSHEET_PRO_PAGE, "Priority Field Verification");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyCreateQuicklogBtnOnRelatedWorksheetSearchPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
            click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			isElementNotPresent(SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN, "Create Quicklog Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCheckboxesOnWorksheetProfilePage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.PRIORITY_CHECKBOX, "Priority Checkbox");
			isElementNotPresent(SOP.REJECTED_CHECKBOX, "Rejected Checkbox");
			isElementNotPresent(SOP.ATTEMPTED_CHECKBOX, "Attempted Checkbox");
			isElementNotPresent(SOP.CONSOLIDATED_CHECKBOX, "Consolidated Checkbox");
			isElementNotPresent(SOP.MULTIPLE_CHECKBOX, "Multiple Checkbox");
			isElementNotPresent(SOP.BANKRUPTCY_CHECKBOX, "Bankruptcy Checkbox");
			isElementNotPresent(SOP.LETTER_CHECKBOX, "Letter Checkbox");
			isElementNotPresent(SOP.DEFENDANT_CHECKBOX, "Defendant Checkbox");
			isElementNotPresent(SOP.ENTITY_CHECKBOX, "Entity Checkbox");
			isElementNotPresent(SOP.COURT_CHECKBOX, "Court Checkbox");
			isElementNotPresent(SOP.AGENCY_CHECKBOX, "Agency Checkbox");
			isElementNotPresent(SOP.ATTORNEY_CHECKBOX, "Attorney Checkbox");
			isElementNotPresent(SOP.CASEID_CHECKBOX, "CaseID Checkbox");
			isElementNotPresent(SOP.PLAINTIFF_CHECKBOX, "Plaintiff Checkbox");
			isElementNotPresent(SOP.DOCUMENT_TYPE_CHECKBOX, "Document Type Checkbox");
			isElementNotPresent(SOP.SPECIAL_CIRCUMSTANCES_CHECKBOX, "Special Circumstances Checkbox");
			isElementNotPresent(SOP.LAWSUIT_TYPE_CHECKBOX, "LawsuitType Checkbox");
			isElementNotPresent(SOP.NATURE_OF_ACTION_CHECKBOX, "NOA Checkbox");
			isElementNotPresent(SOP.ANSWER_DATE_CHECKBOX, "Answer Date Checkbox");


		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySelectAllAndSelectNoneBtnOnWorksheetProfilePage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.SELECT_ALL_BTN, "Select All Btn Verification");
			isElementNotPresent(SOP.SELECT_NONE_BTN, "Select None Btn Verification");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedFieldOnNewlyCreatedWorksheetProfilePage(String reportSheet, int count, String esopId) throws Throwable {

		try {
			/*createWorksheetViaSOPList(reportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			// Create Worksheet Method Called
			createWorksheetMethod(reportSheet, count);
			click(Generic.SAVE, "Save Button");*/
			viewAndCreateTheWorkSheetUsingESOPId(reportSheet, count, esopId);
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			isElementNotPresent(SOP.CLONED_COPIED_FIELD, "Cloned/Copied Field");

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyClonedCopiedFieldOnWorksheetPopUpPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			isElementNotPresent(SOP.CLONED_COPIED_FIELD, "Cloned/Copied Field");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedColumnOnMyWorksheets(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementNotPresent(SOP.CLONED_COPIED_COLUMN, "Cloned/Copied Column On My Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedColumnOnMyTeamsWorksheets(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementNotPresent(SOP.CLONED_COPIED_COLUMN, "Cloned/Copied Column On My Teams Worksheets Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyDefaultSortingOnMyWorksheetPageIsReceivedDt(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			isElementPresent(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySortingOnMyWorksheetPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Check whether All sorting links are present
			click(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");
			isElementPresent(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.PLAINTIFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.DEFENDANT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");

			click(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ACTIVE_LOG_ID_SORT_LINK, "Active Sort By Log# Link");
			click(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.ACTIVE_ENTITY_NAME_SORT_LINK, "Active Sort By Entity Name Link");
			click(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.ACTIVE_STATUS_SORT_LINK, "Active Sort By Status Link");
			click(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.ACTIVE_CASE_ID_SORT_LINK, "Active Sort By Case Id Link");
			click(SOP.PLAINTIFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.ACTIVE_PLAINTIFF_DEBTOR_SORT_LINK, "Active Sort By Plaintiff/Debtor Link");
			click(SOP.DEFENDANT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.ACTIVE_DEFENDANT_CREDITOR_SORT_LINK, "Active Sort By Defendant/Creditor Link");
			click(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.ACTIVE_RECEIVED_BY_OFFICE_SORT_LINK, "Active Sort By Received By Office Link");
			click(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");
			isElementPresent(SOP.ACTIVE_BRANCH_PLANT_SORT_LINK, "Active Sort By Branch Plant Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyDefaultSortingOnMyTeamsWorksheetPageIsReceivedDt(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			isElementPresent(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifySortingOnMyTeamsWorksheetPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Link");
			// Check whether All sorting links are present
			click(SOP.ACTIVE_RECEIVED_DATE_SORT_LINK, "Active Received Date Sort Link");
			isElementPresent(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.PLTFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.ASSIGNED_TO_SORT, "Inactive Sort By Assigned To Link");
			isElementPresent(SOP.DEFT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");

			click(SOP.LOG_ID_SORT, "Inactive Sort By Log# Link");
			isElementPresent(SOP.ACTIVE_LOG_ID_SORT_LINK, "Active Sort By Log# Link");
			click(SOP.ENTITY_NAME_SORT, "Inactive Sort By Entity Name Link");
			isElementPresent(SOP.ACTIVE_ENTITY_NAME_SORT_LINK, "Active Sort By Entity Name Link");
			click(SOP.STATUS_SORT, "Inactive Sort By Status Link");
			isElementPresent(SOP.ACTIVE_STATUS_SORT_LINK, "Active Sort By Status Link");
			click(SOP.CASE_ID_SORT, "Inactive Sort By Case Id Link");
			isElementPresent(SOP.ACTIVE_CASE_ID_SORT_LINK, "Active Sort By Case Id Link");
			click(SOP.PLTFF_DEBTOR_SORT, "Inactive Sort By Plaintiff/Debtor Link");
			isElementPresent(SOP.ACTIVE_PLTFF_DEBTOR_SORT_LINK, "Active Sort By Plaintiff/Debtor Link");
			click(SOP.ASSIGNED_TO_SORT, "Inactive Sort By Assigned To Link");
			isElementPresent(SOP.ACTIVE_ASSIGNED_TO_SORT_LINK, "Active Sort By Assigned To Link");
			click(SOP.DEFT_CREDITOR_SORT, "Inactive Sort By Defendant/Creditor Link");
			isElementPresent(SOP.ACTIVE_DEFT_CREDITOR_SORT_LINK, "Active Sort By Defendant/Creditor Link");
			click(SOP.RECEIVED_BY_OFFICE_SORT, "Inactive Sort By Received By Office Link");
			isElementPresent(SOP.ACTIVE_RECEIVED_BY_OFFICE_SORT_LINK, "Active Sort By Received By Office Link");
			click(SOP.BRANCH_PLANT_SORT, "Inactive Sort By Branch Plant Link");
			isElementPresent(SOP.ACTIVE_BRANCH_PLANT_SORT_LINK, "Active Sort By Branch Plant Link");


		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public void verifyMLSliderfields(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// Verify ML Slider on CES page is closed by default
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "ML Slider is closed by default on CES page");

			// click on arrow icon and verify the slider is opened
			click(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

			// verify ML Slider is opened
			assertElementPresent(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			// verify Slider title is "ML Extracted Data"
			assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider");

			// verify eye icon is displayed next to "ML Extracted Data" title
			assertElementPresent(SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");

			// click on eye icon and verify slider is transparent
			click(SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");
			assertElementPresent(SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");
			String style = getAttribute(SOP.SLIDER_ID, "style");
			assertTextContains(style, "background-color: transparent");

			// click on eye icon again
			click(SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");

			// ML Slider Fields block has 3 fields- Case#, Jurisdiction, Plaintiff, Defendant, Lawsuit type, Lawsuit subtype
			// Answer Date, Postmark Date, Priority Mail#, and following fields..
			assertElementPresent(SOP.CASEIDFIELD, "Case #");
			assertElementPresent(SOP.JURISDICTIONFIELD, "JURISDICTION FIELD");
			assertElementPresent(SOP.PLAINTIFF, "PLAINTIFF FIELD");
			assertElementPresent(SOP.DEFENDANT, "DEFENDANT FIELD");
			assertElementPresent(SOP.LAWSUITTYPEFIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(SOP.LAWSUITSUBTYPEFIELD, "LAWSUIT SUB TYPE FIELD");
			assertElementPresent(SOP.ANSWERDATE, "ANSWER DATE");
			assertElementPresent(SOP.POSTMARKDATE, "POSTMARK DATE");
			assertElementPresent(SOP.PRIORITYMAILIDFIELD, "PRIORITYMAIL ID FIELD");
			assertElementPresent(SOP.INITIAL_SUBSEQUENT_FIELD, "INITIAL SUBSEQUENT FIELD");
			assertElementPresent(SOP.COURTNAME, "COURT NAME FIELD");
			assertElementPresent(SOP.COURTADDRESS, "COURT ADDRESS FIELD");
			assertElementPresent(SOP.AGENCYNAME, "AGENCY NAME FIELD");
			assertElementPresent(SOP.ATTORNEYNAME, "ATTORNEY NAME FIELD");
			assertElementPresent(SOP.NATUREOFACTION, "NATUREOFACTION FIELD");
			assertElementPresent(SOP.AMOUNTDUE, "AMOUNT DUE FIELD");
			assertElementPresent(SOP.DOCUMENTTYPE, "DOCUMENT TYPE FIELD");
			assertElementPresent(SOP.ATTORNEYADDRESS, "ATTORNEY ADDRESS FIELD");
			assertElementPresent(SOP.AGENCYADDRESS, "AGENCY ADDRESS FIELD");

			// close the slider
			click(SOP.SLIDER_OPENED_BTN, "Slider Opened button");
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");
		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyMLSliderWithDataForWorksheetCreation(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of ML Slider");
			if(assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider")) {
				verifyMLSliderfields(ReportSheet, count);
			}
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMLSliderWithDataForWorksheetEdit(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			verifyMLSliderfields(ReportSheet, count);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyMLSliderWithDataForWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			//click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			verifyMLSliderfields(ReportSheet, count);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void verifyAdminMLSliderPage(String ReportSheet, int count) throws Throwable {
		try {

			// Click on Admin Module
			click(HomePage.ADMINLINK, "Admin Link");

			// Verify Whether section 'Manage ML Slider Fields' on the left nav
			// And click on 'Manage ML Slider Fields' link
			assertElementPresent(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");
			click(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");

			// Verify Title of the page is Manage CES ML Slider Fields
			assertTextMatching(Admin.PAGE_TITLE, "Manage ML Slider Fields", "Title of the page");

			// Verify the page has 2 blocks - SOP ML Slider Fields and Maintain
			// SOP ML
			// Slider Fields
			// and save & cancel buttons at the bottom
			isElementPresent(Admin.MLSLIDERFIELDSBLOCK, "ML Slider Fields Block");
			isElementPresent(Admin.MAINTAINMLSLIDERFIELDSBLOCK, "Maintain ML Slider Fields Block");
			isElementPresent(Admin.SAVEBTN, "Save Button");
			isElementPresent(Admin.CANCELBTN, "Cancel Button");

			// ML Slider Fields block has given fields- Case#,Jurisdiction,Plaintiff,Defendant,lawsuit type, lawsuitsubtype
			assertElementPresent(Admin.CASEID_FIELD, "Case #");
			assertElementPresent(Admin.JURISDICTION_FIELD, "JURISDICTION FIELD");
			assertElementPresent(Admin.PLAINTIFF_FIELD, "PLAINTIFF FIELD");
			assertElementPresent(Admin.DEFENDANT_FIELD, "DEFENDANT FIELD");
			assertElementPresent(Admin.LAWSUITTYPE_FIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(Admin.LAWSUITSUBTYPE_FIELD, "LAWSUIT SUB TYPE FIELD");
			assertElementPresent(Admin.ANSWER_DATE, "ANSWER DATE");
			assertElementPresent(Admin.POSTMARK_DATE, "POSTMARK DATE");
			assertElementPresent(Admin.PRIORITYMAILID_FIELD, "PRIORITYMAIL ID FIELD");
			assertElementPresent(Admin.INITIALSUBSEQUENT_FIELD, "INITIAL SUBSEQUENT FIELD");
			assertElementPresent(Admin.COURT_NAME, "COURT NAME FIELD");
			assertElementPresent(Admin.COURT_ADDRESS, "COURT ADDRESS FIELD");
			assertElementPresent(Admin.AGENCY_NAME, "AGENCY NAME FIELD");
			assertElementPresent(Admin.ATTORNEY_NAME, "ATTORNEY NAME FIELD");
			assertElementPresent(Admin.NATURE_OFACTION, "NATUREOFACTION FIELD");
			assertElementPresent(Admin.AMOUNT_DUE, "AMOUNT DUE FIELD");
			assertElementPresent(Admin.DOCUMENT_TYPE, "DOCUMENT TYPE FIELD");
			assertElementPresent(Admin.ATTORNEY_ADDRESS, "ATTORNEY ADDRESS FIELD");
			assertElementPresent(Admin.AGENCY_ADDRESS, "AGENCY ADDRESS FIELD");

			// Maintain ML Slider Fields block has 2 fields- Index and Name
			assertTextMatching(Admin.INDEX_FIELD, "Index", "Verify 1st col is Index");
			assertTextMatching(Admin.NAME_FIELD, "Name", "Verify 2nd col is Name");

			// Verify Fields can be moved within ML Slider Fields block
			draganddrop(Admin.CASEID_FIELD, Admin.JURISDICTION_FIELD, "CASE ID AND JURISDICTION FIELD DRAG AND DROP");
			click(Admin.SAVEBTN, "Save Button");

			//Verify ML Slider fields on Create Worksheet Page
			String esopId = entitySectionDetailsOnProcessingCES(ReportSheet, count);
			try {
				createWorksheetViaSOPList(ReportSheet, count, esopId);
				String jurisdiction = getText(SOP.JURISDICTIONFIELD, "Jurisdiction present as First Field on ML Slider pg.");
				String caseId = getText(SOP.CASEIDFIELD, "CaseId present as Second Field on ML Slider pg.");
				assertTextMatching(SOP.FIRSTELEMENT_ON_ML_SLIDER, jurisdiction, "Verify Jurisdiction as the First Field");
				assertTextMatching(SOP.SECONDELEMENT_ON_ML_SLIDER, caseId, "Verify CaseId as the Second Field");
				waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
				
				
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

				click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				// Click on Edit Worksheet
				waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
				click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
				waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
				assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
				// click on arrow icon and verify the slider is opened
				click(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

				// verify ML Slider is opened
				assertElementPresent(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

				// verify Slider title is "ML Extracted Data"
				assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider");
				assertTextMatching(SOP.FIRSTELEMENT_ON_ML_SLIDER, jurisdiction, "Verify Jurisdiction");
				assertTextMatching(SOP.SECONDELEMENT_ON_ML_SLIDER, caseId, "Verify CaseId");
				waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
				
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

				// Click on Admin Module
				click(HomePage.ADMINLINK, "Admin Link");

				// Verify Whether section 'Manage ML Slider Fields' on the left nav
				// And click on 'Manage ML Slider Fields' link
				assertElementPresent(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");
				click(Admin.MANAGEMLSLIDERFIELDSLINK, "Manage ML Slider Fields Link");

				draganddrop(Admin.JURISDICTION_FIELD, Admin.CASEID_FIELD, "CASE ID AND JURISDICTION FIELD DRAG AND DROP");
				click(Admin.SAVEBTN, "Save Button");

				//Verify page title 'Manage ML Slider Fields'
				assertTextMatching(Admin.PAGE_TITLE, "Manage ML Slider Fields", "Title of Manage ML Slider Fields Page");

			}
			catch (Exception e) {
				throw e;
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyNoQuicklogOnCreateWorksheet(String ReportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementNotPresent(SOP.QUICKLOG_BUTTON, "No Quicklog button present on Create Worksheet Page");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyEditedQuicklogWorksheet(String ReportSheet, int count) throws Throwable {

		try {
			String logID = Excelobject.getCellData(ReportSheet, "LogID", count);
			// click on Worksheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Page");
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Page");
			click(SearchWorksheet.ACTIVE_DATA, "Active Data Radio Button");
			type(SearchWorksheet.LOG_ID_TEXT, logID, "Log ID Entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.QUICKLOG_STATUS, "Quicklog", "Quicklog is the current status of worksheet");
			//click on Edit button on Worksheet Profile Page
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementNotPresent(SOP.QUICKLOG_BUTTON, "No Quicklog button present on Create Worksheet Page");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyNOAfieldstMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --", "Amount $", "Breach of Contract",
					"Breach of Contract -", "Class Action -", "Continue withholding the nonexempt earnings of the...",
					"Continuing lien is extended until", "Default Judgment", "Hearing has been scheduled",
					"Lien - Amount $", "Motion for Summary Final Judgment of Foreclosure", "Notice of hearing",
					"Order of continuing lien", "Pertaining to", "Product Name: VIN:", "Release of Garnishment",
					"Request for status of Garnishment previously serve...",
					"Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation",
					"Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {

				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());
				}
				compareTwoArrayList(updatedNOAList, originalNOAList);
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyNOAWorksheetCreate(String reportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				verifyNOAfieldstMethod(reportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			} else {
				System.out.println("No Nature of Action Field present on Create Worksheet Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyNOAWorksheetEdit(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void UICreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;
			assertElementPresent(SOP.CREATE_HELP_ICON, "Help Page Icon");
			assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON, "Save Incomplete Button");
			assertElementPresent(SOP.BAD_LOG_FIELD, "Bad Log Field");
			assertElementPresent(SOP.BAD_LOG_CHECKBOX, "Bad Log Checkbox");
			assertElementPresent(SOP.WORKSHEET_TYPE_FIELD, "Worskheet Type Field");
			String WorksheetType = getText(SOP.WORKSHEET_TYPE, "WOrksheet Type");
			if (WorksheetType.equals("DSSOP")) {
				assertElementPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				assertElementPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				assertElementPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN, "Direct Served Process Method of Service Dropdown");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_DATE ,"Direct Served Process Received Date");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_TIME, "Direct Served Process Received Time");
				assertElementPresent(SOP.CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION, "Customer Comments CDSOP Only Section");
				assertElementPresent(SOP.CUSTOMER_COMMENTS_BOX, "Customer Comments Box");



			} else {
				isElementNotPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				isElementNotPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				isElementNotPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN, "Direct Served Process Method of Service Dropdown");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_DATE ,"Direct Served Process Received Date");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_TIME, "Direct Served Process Received Time");
				isElementNotPresent(SOP.CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION, "Customer Comments CDSOP Only Section");
				isElementNotPresent(SOP.CUSTOMER_COMMENTS_BOX, "Customer Comments Box");

			}

			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_TEAM, "Received By Team Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_MEMBER_DPDOWN, "Received By Member Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Received By Collapsable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_TEAM_DPDOWN, "Assigned To Team Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_MEMBER_DPDOWN, "Assigned To Member Dropdown");
			assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Yes Radio Button");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.INITIAL_RADIOBTN, "Inintial/Subsequent Field");
			assertElementPresent(SOP.CONSOLIDATED_YES_RADIO_BUTTON, "Consolidated Field");
			assertElementPresent(SOP.BANKRUPTCY_YES_RADIO_BUTTON, "Bankruptcy Field");
			assertElementPresent(SOP.LETTER_YES_RADIO_BUTTON, "Letter Field");
			assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			assertElementPresent(SOP.TARGET_DETAILS_SECTION, "Target details Section");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.REJECT_DETAILS_SECTION, "Reject details Section");
			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason Dropdown");
			assertElementPresent(SOP.REJECT_DATE, "Reject Date");
			assertElementPresent(SOP.COURT_DETAILS_SECTION, "Court details Section");
			assertElementPresent(SOP.COURT_NONE_RADIOBTN, "Court None Specified Radio button");
			assertElementPresent(SOP.AGENCY_DETAILS_SECTION, "Agency details Section");
			assertElementPresent(SOP.AGENCY_NONE_RADIOBTN, "Agency None Specified Radio button");
			assertElementPresent(SOP.ATTORNEY_DETAILS_SECTION, "Attorney details Section");
			assertElementPresent(SOP.ATTORNEY_NONE_RADIOBTN, "Attorney None Specified Radio button");
			assertElementPresent(SOP.COURT_HELP_ICON, "Court Help Icon");
			assertElementPresent(SOP.CUSTOMER_PARTICIPANT_SEARCHBTN, "Customer/Participant Search Button");
			assertElementPresent(SOP.ATTORNEY_DETAILS_SECTION, "Attorney details Section");

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					assertElementPresent(SOP.LAWSUIT_TYPE_DROPDOWN,"Lawsuit Type Dropdown");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					//assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					assertElementPresent(SOP.LAWSUIT_TYPE_DROPDOWN,"Lawsuit Type Dropdown");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					//assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
			}

			assertElementPresent(SOP.AMOUNT_DUE_DRPDWN, "Amount Due Dropdown");
			assertElementPresent(SOP.ANSWER_NONE_RADIOBTN, "Answer Date Field");
			assertElementPresent(SOP.REMARKS_SECTION, "Remarks Section");
			assertElementPresent(SOP.REMARKS_DRPDWN, "Remarks dropdown");
			assertElementPresent(SOP.COMMENTS_SECTION, "Comments Section");
			assertElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Dropdown");

			assertElementPresent(SOP.BOTTOM_CANCELBTN, "Cancel Button at Buttom");
			assertElementPresent(SOP.BOTTOM_SAVEBTN, "Save Button at Buttom");
			assertElementPresent(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Buttom");
			//assertElementPresent(SOP.WIREFRAME_NUMBER, "Wireframe Number");
			//assertElementPresent(SOP.BOTTOM_MODULE_LINK, "Module links at bottom of the page");

			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Send Message Button");
			isElementNotPresent(SOP.NEXT_BTN, "Next Button");
			isElementNotPresent(SOP.PREV_BTN, "Previous Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public String verifyUIofCreateWorksheetPage(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			Thread.sleep(5000);
			UICreateEditReviewWorksheetPage();

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void validateSaveCreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}

			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			waitForElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			click(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Criteria", "Page Title");
			selectBySendkeys(SOP.NAME_TEXTBOX, "ct", "Entering Entity Name");
			click(SOP.SEARCH_BTN, "Search Button");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Results", "Page Title");

			/*click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Btn");
			click(SOP.CANCEL_BUTTON, "Cancel Btn");*/
			waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			waitForElementToBePresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			waitForElementToBePresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Unidentified Entity Radio Button Selected");
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Unidentified Entity Radio Button Selected");
			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");

			waitForElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			assertElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementToBeClickable(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			click(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			waitForElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			selectBySendkeys(SOP.RECEIVED_BY_FACILITY, "-- Select One --", "Clear Received By Facility Dropdown");
			waitForElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			waitForElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			selectBySendkeys(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "-- Select One --", "Clear Assigned To Facility Dropdown");

			/*assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			click(SOP.CASE_NUMBER, "Case Number");
			type(SOP.CASE_TEXTFIELD, "", "Clear Case Id Textbox");

			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			selectByVisibleText(SOP.METHOD_OF_SERVICE, "Fax", "Method of service dropdown");*/

			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			/*selectByVisibleText(SOP.METHOD_OF_SERVICE, "Fax", "Clear Method of service dropdown");*/
			selectByVisibleText(SOP.METHOD_OF_SERVICE, "-- Select One --", "Clear Method of service dropdown");

			waitForElementToBePresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			assertElementPresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			click(SOP.CASE_RADIO_BTN, "Case Radio Button");
			waitForElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			assertElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			type(WorksheetCreate.CASE_TEXT, "", "Clear Text Field for Case");

			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			click(SOP.PLAINTIFF_RADIOBTN, "Plaintiff Radio Btn");
			type(SOP.PLAINTIFF_TEXT_BOX, "", "Clear Plaintiff Textbox");

			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			type(SOP.DEFENDANT_TEXTFIELD, "", "Clear Defendant Textbox");

			click(SOP.RADIO_BUTTON_EXISTING_COURT, "Court Existing Radio button");
			selectBySendkeys(SOP.STATE_OF_COURT_DRPDWN, "-- Select One --", "Clear State of Court Drpdown");
			//type(SOP.TEXT_BOX_COURTNAME, "", "Clear Court Textbox");
			//waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Court Drpdown");
			//selectBySendkeys(SOP.DROP_DOWN_COURT_NAME, "-- Select One --", "Clear Court Drpdown");
			click(SOP.EXISTING_AGENCY_RADIO_BTN, "Agency Existing Radio button");
			type(SOP.TEXT_BOX_AGENCY, "", "Clear Agency Textbox");
			selectBySendkeys(SOP.EXISTING_AGENCY_DRPDOWN, "-- Select One --", "Clear Existing Agency Drpdown");
			click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Attorney Existing Radio button");
			type(SOP.TEXTBOX_ATTORNEYNAME, "", "Clear Attorney Textbox");
			selectBySendkeys(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "-- Select One --", "Clear Existing Attorney Drpdown");

			assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
			selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Textbox");
			click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
			click(SOP.ANSWER_RADIOBTN, "Answer Date Field");
			click(SOP.ANSWER_SELECT_ONE_DRPDOWN, "Clear Answer Drpdown");
			type(SOP.ANSWER_DATE_TEXTFIELD, "", "Clear Answer Date Textbox");
			selectBySendkeys(SOP.REMARKS_DRPDWN, "-- Select One --", "Clear Remarks Drpdwn");
			type(SOP.REMARKS_TEXTBOX, "", "Clear Remarks Textbox");

			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			type(SOP.RECEIPT_DATE_FIELD, "", "Clear Receipt Date Textbox");

			click(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");

			isElementPresent(SOP.RECEIPT_DATE_ERRMSG, "Error Msg For Receipt Date");
			assertTextMatching(SOP.RECEIPT_DATE_ERRMSG, "Enter a value for Receipt Date.", "Error Msg For Receipt Date");

			isElementPresent(SOP.RECEIVED_BY_ERRMSG, "Error Msg For Received By Facility");
			assertTextMatching(SOP.RECEIVED_BY_ERRMSG, "Select a value for Received By Facility.", "Error Msg For Received By Facility");

			isElementPresent(SOP.ASSIGNED_TO_ERRMSG, "Error Msg For Assigned To Facility");
			assertTextMatching(SOP.ASSIGNED_TO_ERRMSG, "Select a value for Assigned To Facility.", "Error Msg For Assigned To Facility");

			isElementPresent(SOP.METHOD_OF_SERVICE_ERRMSG, "Error Msg For Method of Service.");
			assertTextMatching(SOP.METHOD_OF_SERVICE_ERRMSG, "Select a value for Method of Service.", "Error Msg For Method of Service.");

			if(verifyIfElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent")){

				isElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent");
				assertTextMatching(SOP.INITIAL_ERRMSG, "Choose Initial/Subsequent", "Error Msg For Initial/Subsequent");

			}

			if(verifyIfElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name")){
				isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG, "Enter a value for Plaintiff / Debtor.", "Error Msg For Plaintiff Name");

			}

			if(verifyIfElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor")){
				isElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor");
				assertTextMatching(SOP.CASEID_PLAINTIFF_ERRMSG, "Enter values for Case # and Plaintiff / Debtor.", "Error Msg For Case # and Plaintiff / Debtor");

			}
			isElementPresent(SOP.DEFENDANT_ERRMSG, "Error Msg For Defendant/Creditor Name");
			assertTextMatching(SOP.DEFENDANT_ERRMSG, "Enter a value for Defendant/Creditor Name.", "Error Msg For Defendant/Creditor Name");

			if(verifyIfElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity")){
				isElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity");
				assertTextMatching(SOP.CT_ENTITY_ERRMSG, "Select a value for CT Entity.", "Error Msg For CT Entity");
			}

			if(verifyIfElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation")){
				isElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation");
				assertTextMatching(SOP.REPRESENTATION_ERRMSG, "Select a value for Representation.", "Error Msg For Representation");
			}

			isElementPresent(SOP.COURT_ERRMSG, "Error Msg For Court");
			assertTextMatching(SOP.COURT_ERRMSG,
					"Court must be entered or 'None Specified' selected.",
					"Error Msg For Court");

			isElementPresent(SOP.AGENCY_ERRMSG, "Error Msg For Agency");
			assertTextMatching(SOP.AGENCY_ERRMSG,
					"Agency must be entered or 'None Specified' selected.",
					"Error Msg For Agency");

			isElementPresent(SOP.ATTORNEY_ERRMSG, "Error Msg For Attorney");
			assertTextMatching(SOP.ATTORNEY_ERRMSG,
					"Attorney must be entered or 'None Specified' selected.",
					"Error Msg For Attorney");

			isElementPresent(SOP.CT_DOCUMENT_TYPE_ERRMSG, "Error Msg For Document Type");
			assertTextMatching(SOP.CT_DOCUMENT_TYPE_ERRMSG,
					"Enter a value for Document Type.",
					"Error Msg For Document Type");

			if(verifyIfElementPresent(SOP.SPECIAL_CIRCUMSTANCES_ERRMSG, "Error Msg For Special Circumstances")){
				isElementPresent(SOP.SPECIAL_CIRCUMSTANCES_ERRMSG, "Error Msg For Special Circumstances");
				assertTextMatching(SOP.SPECIAL_CIRCUMSTANCES_ERRMSG,
						"Select a value for Special Circumstance.",
						"Error Msg For Special Circumstances");
			}

			isElementPresent(SOP.LAWSUIT_ERRMSG, "Error Msg For LawsuitType");
			assertTextMatching(SOP.LAWSUIT_ERRMSG,
					"Select a value for LawsuitType.",
					"Error Msg For LawsuitType");

			isElementPresent(SOP.ANSWER_DATE_ERRMSG, "Error Msg For Answer Date");
			assertTextMatching(SOP.ANSWER_DATE_ERRMSG,
					"Answer Date must be entered or 'None Specified' selected.",
					"Error Msg For Answer Date");	

			if(verifyIfElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks")){
				isElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks");
				assertTextMatching(SOP.REMARKS_ERRMSG,
						"Enter a value for valid Remarks.",
						"Error Msg For Remarks");
			}

			if(verifyIfElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype"))
			{
				/*isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG,
						"Enter a value for Plaintiff / Debtor.",
						"Error Msg For Plaintiff");*/

				assertElementPresent(SOP.REVIEW_SUB_TYPE, "Review Subtype dropdown");
				selectBySendkeys(SOP.REVIEW_SUB_TYPE, "-- Select One --", "Clear Method of service dropdown");

				isElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype");
				assertTextMatching(SOP.REVIEW_SUBTYPE_ERRMSG,
						"Select a value for Review sub type.",
						"Error Msg For Review Subtype");

			}

		} catch (Exception e) {
			throw e;
		}

	}

	public void validateSaveIncompleteCreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}

			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			waitForElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			click(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Criteria", "Page Title");
			selectBySendkeys(SOP.NAME_TEXTBOX, "ct", "Entering Entity Name");
			click(SOP.SEARCH_BTN, "Search Button");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Results", "Page Title");

			/*click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Btn");
			click(SOP.CANCEL_BUTTON, "Cancel Btn");*/
			waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			waitForElementToBePresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			waitForElementToBePresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected");
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected");
			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");

			waitForElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			assertElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementToBeClickable(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			click(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			waitForElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			selectBySendkeys(SOP.RECEIVED_BY_FACILITY, "-- Select One --", "Clear Received By Facility Dropdown");
			waitForElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			waitForElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			selectBySendkeys(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "-- Select One --", "Clear Assigned To Facility Dropdown");


			/*assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			click(SOP.CASE_NUMBER, "Case Number");
			type(SOP.CASE_TEXTFIELD, "", "Clear Case Id Textbox");
			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			selectBySendkeys(SOP.METHOD_OF_SERVICE, "Fax", "Method of service dropdown");*/

			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			/*selectByVisibleText(SOP.METHOD_OF_SERVICE, "Fax", "Clear Method of service dropdown");*/
			selectByVisibleText(SOP.METHOD_OF_SERVICE, "-- Select One --", "Clear Method of service dropdown");

			waitForElementToBePresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			assertElementPresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			click(SOP.CASE_RADIO_BTN, "Case Radio Button");
			waitForElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			assertElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			type(WorksheetCreate.CASE_TEXT, "", "Clear Text Field for Case");

			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			click(SOP.PLAINTIFF_RADIOBTN, "Plaintiff Radio Btn");
			type(SOP.PLAINTIFF_TEXT_BOX, "", "Clear Plaintiff Textbox");

			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			type(SOP.DEFENDANT_TEXTFIELD, "", "Clear Defendant Textbox");

			click(SOP.RADIO_BUTTON_EXISTING_COURT, "Court Existing Radio button");
			selectBySendkeys(SOP.STATE_OF_COURT_DRPDWN, "-- Select One --", "Clear State of Court Drpdown");
			//type(SOP.TEXT_BOX_COURTNAME, "", "Clear Court Textbox");
			//waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Court Drpdown");
			//selectBySendkeys(SOP.DROP_DOWN_COURT_NAME, "-- Select One --", "Clear Court Drpdown");
			click(SOP.EXISTING_AGENCY_RADIO_BTN, "Agency Existing Radio button");
			type(SOP.TEXT_BOX_AGENCY, "", "Clear Agency Textbox");
			selectBySendkeys(SOP.EXISTING_AGENCY_DRPDOWN, "-- Select One --", "Clear Existing Agency Drpdown");
			click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Attorney Existing Radio button");
			type(SOP.TEXTBOX_ATTORNEYNAME, "", "Clear Attorney Textbox");
			selectBySendkeys(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "-- Select One --", "Clear Existing Attorney Drpdown");

			assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
			selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Textbox");
			click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
			click(SOP.ANSWER_RADIOBTN, "Answer Date Field");
			click(SOP.ANSWER_SELECT_ONE_DRPDOWN, "Clear Answer Drpdown");
			type(SOP.ANSWER_DATE_TEXTFIELD, "", "Clear Answer Date Textbox");

			selectBySendkeys(SOP.REMARKS_DRPDWN, "-- Select One --", "Clear Remarks Drpdwn");
			type(SOP.REMARKS_TEXTBOX, "", "Clear Remarks Textbox");

			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			type(SOP.RECEIPT_DATE_FIELD, "", "Clear Receipt Date Textbox");

			if(verifyIfElementPresent(SOP.SAVE_INCOMPLETE_REVIEW_BUTTON, "Save Incomplete Review Button at Bottom")) {
				click(SOP.SAVE_INCOMPLETE_REVIEW_BUTTON, "Save Incomplete Review Button at Bottom");
			}
			else
			{
				click(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Bottom");
			}


			isElementPresent(SOP.RECEIPT_DATE_ERRMSG, "Error Msg For Receipt Date");
			assertTextMatching(SOP.RECEIPT_DATE_ERRMSG, "Enter a value for Receipt Date.", "Error Msg For Receipt Date");

			isElementPresent(SOP.RECEIVED_BY_ERRMSG, "Error Msg For Received By Facility");
			assertTextMatching(SOP.RECEIVED_BY_ERRMSG, "Select a value for Received By Facility.", "Error Msg For Received By Facility");

			isElementPresent(SOP.ASSIGNED_TO_ERRMSG, "Error Msg For Assigned To Facility");
			assertTextMatching(SOP.ASSIGNED_TO_ERRMSG, "Select a value for Assigned To Facility.", "Error Msg For Assigned To Facility");

			isElementPresent(SOP.METHOD_OF_SERVICE_ERRMSG, "Error Msg For Method of Service.");
			assertTextMatching(SOP.METHOD_OF_SERVICE_ERRMSG, "Select a value for Method of Service.", "Error Msg For Method of Service.");

			if(verifyIfElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent")){

				isElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent");
				assertTextMatching(SOP.INITIAL_ERRMSG, "Choose Initial/Subsequent", "Error Msg For Initial/Subsequent");

			}

			if(verifyIfElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name")){
				isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG, "Enter a value for Plaintiff / Debtor.", "Error Msg For Plaintiff Name");

			}

			if(verifyIfElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor")){
				isElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor");
				assertTextMatching(SOP.CASEID_PLAINTIFF_ERRMSG, "Enter values for Case # and Plaintiff / Debtor.", "Error Msg For Case # and Plaintiff / Debtor");

			}

			isElementPresent(SOP.DEFENDANT_ERRMSG, "Error Msg For Defendant/Creditor Name");
			assertTextMatching(SOP.DEFENDANT_ERRMSG, "Enter a value for Defendant/Creditor Name.", "Error Msg For Defendant/Creditor Name");

			if(verifyIfElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity")){
				isElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity");
				assertTextMatching(SOP.CT_ENTITY_ERRMSG, "Select a value for CT Entity.", "Error Msg For CT Entity");
			}

			if(verifyIfElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation")){
				isElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation");
				assertTextMatching(SOP.REPRESENTATION_ERRMSG, "Select a value for Representation.", "Error Msg For Representation");
			}

			isElementPresent(SOP.COURT_ERRMSG, "Error Msg For Court");
			assertTextMatching(SOP.COURT_ERRMSG,
					"Court must be entered or 'None Specified' selected.",
					"Error Msg For Court");

			isElementPresent(SOP.AGENCY_ERRMSG, "Error Msg For Agency");
			assertTextMatching(SOP.AGENCY_ERRMSG,
					"Agency must be entered or 'None Specified' selected.",
					"Error Msg For Agency");

			if(verifyIfElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks"))
			{
				isElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks");
				assertTextMatching(SOP.REMARKS_ERRMSG,
						"Enter a value for valid Remarks.",
						"Error Msg For Remarks");

			}

			if(verifyIfElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype"))
			{
				/*isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG,
						"Enter a value for Plaintiff / Debtor.",
						"Error Msg For Plaintiff");*/

				assertElementPresent(SOP.REVIEW_SUB_TYPE, "Review Subtype dropdown");
				selectBySendkeys(SOP.REVIEW_SUB_TYPE, "-- Select One --", "Clear Method of service dropdown");

				isElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype");
				assertTextMatching(SOP.REVIEW_SUBTYPE_ERRMSG,
						"Select a value for Review sub type.",
						"Error Msg For Review Subtype");

			}

			isElementNotPresent(SOP.CT_DOCUMENT_TYPE_ERRMSG, "Error Msg For Document Type");
			isElementNotPresent(SOP.LAWSUIT_ERRMSG, "Error Msg For LawsuitType");
			isElementNotPresent(SOP.ANSWER_DATE_ERRMSG, "Error Msg For Answer Date");

		} catch (Exception e) {
			throw e;
		}
	}

	public String validateErrMsgofCreateWorksheetPage(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			validateSaveCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

			String esop_Id = entitySectionDetailsOnProcessingCES(ReportSheet, count);
			createWorksheetViaSOPList(ReportSheet, count, esop_Id);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			validateSaveIncompleteCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String validateErrMsgofEditWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			/*// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");*/

			// click on WorkSheet Search link on Home page
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Worksheet Search Left Nav");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			validateSaveCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			// click on WorkSheet Search link on Home page
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Worksheet Search Left Nav");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			validateSaveIncompleteCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String validateErrMsgofReviewWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			//Verify Review Worksheet Page
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			validateSaveCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			// Verify Review Worksheet Page
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			validateSaveIncompleteCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAExistingWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_DATE_CALENDAR, "Date Calendar (Personal Injury)", "NOA Date Calendar");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_DATE_CALENDAR, "Date Calendar (Personal Injury)", "NOA Date Calendar");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAExistingWorksheetEditedSaved(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			assertElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			//verifyNOAfieldstMethod(ReportSheet, count);
			selectByVisibleText(SOP.NOA_DRPDWN, "Termination of Garnishment", "NOA dropdown field");
			/*
			Thread.sleep(2000);
			type(SOP.REMARKS_TEXTBOX, "Remarks Entered:-Testing In Progress", "Clear Remarks Textbox");*/
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.WORKSHEET_REMARKS_TEXTBOX, "", "Clear Remarks Textbox");
			waitForElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
			assertElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
			type(SOP.INTERNAL_COMMENTS_TEXTBOX, "Worksheet Processed", "Internal Comments Text");
			/*waitForElementToBePresent(SOP.REMARKS_DRPDWN, "Remarks dropdown field");
			assertElementPresent(SOP.REMARKS_DRPDWN, "Remarks dropdown field");
			selectByVisibleText(SOP.REMARKS_DRPDWN, "Refer to previous log #___ forwarded on ___.", "Remarks dropdown field");
			selectByIndex(SOP.REMARKS_DRPDWN,2, "Remarks dropdown field");*/
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.REMARKS_TEXTBOX, "Worksheet Edited", "Remarks Text");
			waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			click(SOP.SAVE_BTN, "Save Button");
			//Enter a value for Remarks.
			try {
				WebElement remarksNotEntered = null;	
				remarksNotEntered = driver.findElement(SOP.REMARKS_ERRMSG);
				if(remarksNotEntered != null) {	
					type(SOP.REMARKS_TEXTBOX,"Remarks entered in Selenium Automation","Remarks text box");
					waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
					assertElementPresent(SOP.SAVE_BTN, "Save Button");
					click(SOP.SAVE_BTN, "Save Button");
				}
			}
			catch (NoSuchElementException e) {}

			waitForElementToBePresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_TERMINATIONOFGARNISHMENT, "Termination of Garnishment", "NOA Termination of Garnishment");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAExistingWorksheetReviewedSaved(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			//Click on Review WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			//verifyNOAfieldstMethod(ReportSheet, count);
			selectBySendkeys(SOP.NOA_DRPDWN, "Default Judgment", "NOA dropdown field");
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_DEFAULTJUDGMENT, "Default Judgment", "NOA Default Judgment");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}