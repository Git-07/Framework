package com.arrow.workflows;

import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Alerts;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;

public class BusinessFunctions_Alerts extends BusinessFunctions {
	/********************************************************************************************************
	 * Method Name : AlertsInEntity() Author : Vrushali Kakade Description : Search
	 * for an Entity and add 12 alerts, navigate to My Expiring Alerts page and
	 * verify Sort By, Paginations and Filter dropdown options are clickable and
	 * Extend end date of an alert Date of creation : 6/06/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void AlertsInEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search Link");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// type Entity Name in Name field
			type(Entity.ENTITY_NAME, strName, "Entity Name Field");
			click(Entity.SEARCH_BTN, "Search Button");
			waitForElementPresent(Entity.CREATE_ENTITY_BTN, "Create Entity Button");
			// click on 1st Entity Name in Search Result Grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity in grid");
			waitForElementPresent(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
			// click on Alerts link in left nav
			click(Entity.ALERTS, "Alerts Link");
			waitForElementPresent(Alerts.ALERTS_TEXTFIELD, "Alerts Text box");
			// Add more than 10 Alerts
			for (int i = 0; i < 12; i++) {
				AddAlerts(strAlertText);
			}
			// click on My Expiring Alerts
			click(Entity.MYEXPIRINGALERTS, "My Expiring Alerts Link");
			// Verify Sort By Links are clickable
			waitForElementToBeClickable(Alerts.ALERT_TYPE_SORTBY_LINK, "Alert Type link");
			click(Alerts.ALERT_TYPE_SORTBY_LINK, "Alert Type Link");
			isElementPresent(Alerts.ALERT_LINK_BOLD, "Bold Alert Type Link");
			waitForElementToBeClickable(Alerts.STATE_SORTBY_LINK, "State link");
			click(Alerts.STATE_SORTBY_LINK, "State Link");
			isElementPresent(Alerts.STATE_LINK_BOLD, "Bold State Link");
			waitForElementToBeClickable(Alerts.AUDIENCE_SORTBY_LINK, "Audience link");
			click(Alerts.AUDIENCE_SORTBY_LINK, "Audience Link");
			isElementPresent(Alerts.AUDIENCE_LINK_BOLD, "Bold Audience Link");
			waitForElementToBeClickable(Alerts.END_DATE_SORTBY_LINK, "End Date link");
			click(Alerts.END_DATE_SORTBY_LINK, "End Date Link");
			isElementPresent(Alerts.END_DATE_LINK_BOLD, "Bold End Date Link");
			// Verify Pagination links are clickable
			isEnabled(Alerts.NEXT_LINK, "Next Pagination Link");
			isEnabled(Alerts.LAST_LINK, "Last Pagination Link");
			click(Alerts.LAST_LINK, "Last Pagination Link");
			isEnabled(Alerts.FIRST_LINK, "First Pagination Link");
			isEnabled(Alerts.PREVIOUS_LINK, "Previous Pagination Link");
			// Verify State Filter options are clickable
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN1, "State", "Filter Dropdown 1");
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN2, "ALABAMA", "Filter Dropdown 2");
			click(Alerts.ALERT_FILTER_GO_BTN, "Go Button");
			click(Alerts.ALERT_FILTER_CLEAR_BTN, "Clear Button");
			// Verify Audience Filter options are clickable
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN1, "Audience", "Filter Dropdown 1");
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN2, "All", "Filter Dropdown 2");
			click(Alerts.ALERT_FILTER_GO_BTN, "Go Button");
			click(Alerts.ALERT_FILTER_CLEAR_BTN, "Clear Button");
			// Verify Alert Type Filter options are clickable
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN1, "Alert Type", "Filter Dropdown 1");
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN2, "Entity", "Filter Dropdown 2");
			click(Alerts.ALERT_FILTER_GO_BTN, "Go Button");
			click(Alerts.ALERT_FILTER_CLEAR_BTN, "Clear Button");
			// Verify End Date Filter options are clickable
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN1, "End Date", "Filter Dropdown 1");
			selectByVisibleText(Alerts.ALERT_FILTER_DROPDOWN3, "Is after", "Filter Dropdown 2");
			type(Alerts.ALERT_FILTER_TEXTFIELD, "01/01/2009", "Filter Text Field");
			click(Alerts.ALERT_FILTER_GO_BTN, "Go Button");
			click(Alerts.ALERT_FILTER_CLEAR_BTN, "Clear Button");
			// click on Extend button
			click(Alerts.FIRST_EXTEND_BUTTON, "Extend Button");
			waitForElementToBeClickable(Alerts.NEW_END_DATE_FIELD, "New End Date field");
			// click on Cancel button on Extend Alerts page
			click(Alerts.ALERTS_CANCEL_BTN, "Cancel Button Extend Alerts page");
			waitForElementToBeClickable(Alerts.FIRST_EXTEND_BUTTON, "Extend Button");
			// click on Extend button again from the grid
			click(Alerts.FIRST_EXTEND_BUTTON, "Extend Button");
			waitForElementToBeClickable(Alerts.NEW_END_DATE_FIELD, "New End Date field");
			// Getting Today date and modifying the End date, doing it after 1 month
			String date = addMonthInCurrentDate();
			type(Alerts.NEW_END_DATE_FIELD, date, "New date");
			click(Alerts.ALERTS_SAVE_BTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : AlertsInEntity() Author : Vrushali Kakade Description : Search
	 * for an Entity and add 12 alerts, click on link 'There are Alerts for this
	 * Entity' on Entity profile page and extend expiring alert by 7 days Date of
	 * creation : 6/06/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void ExtendAlertInEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search Link");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// type Entity Name in Name field
			type(Entity.ENTITY_NAME, strName, "Entity Name Field");
			click(Entity.SEARCH_BTN, "Search Button");
			waitForElementPresent(Entity.CREATE_ENTITY_BTN, "Create Entity Button");
			// click on 1st Entity Name in Search Result Grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity in grid");
			waitForElementPresent(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
			// click on 'There are Alerts for this Entity' link on Entity Profile page
			click(Entity.ALERTS_FOR_ENTITY_LINK, "There are Alerts for this Entity link");
			waitForElementPresent(Alerts.ALERTS_TEXTFIELD, "Alerts Text box");
			// Add more than 10 Alerts
			for (int i = 0; i < 12; i++) {
				AddAlerts(strAlertText);
			}
			// click on My Expiring Alerts
			click(Entity.MYEXPIRINGALERTS, "My Expiring Alerts Link");
			// click on Extend button
			click(Alerts.FIRST_EXTEND_BUTTON, "Extend Button");
			waitForElementToBeClickable(Alerts.NEW_END_DATE_FIELD, "New End Date field");
			// Getting Today date and modifying the End date, doing it after 1 month
			String date = addDaysInCurrentDate(7);
			type(Alerts.NEW_END_DATE_FIELD, date, "New date");
			click(Alerts.ALERTS_SAVE_BTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : AddAlerts() Author : Vrushali Kakade Description : Add alerts
	 * to an Entity/Affiliation Date of creation : 06/03/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/

	public void AddAlerts(String strAlertText) throws Throwable {
		blnEventReport = true;
		// type text in Alert Text field
		type(Alerts.ALERTS_TEXTFIELD, strAlertText, "Alert Text Field");
		// Click on Calendar and select todays date
		click(Alerts.CALENDAR, "Calendar Icon");
		click(Alerts.TODAYSDATE, "Todays Date");
		// Click on Add/Update button
		click(Alerts.ADDUPDATE_BTN, "Add/Update button");
	}

	public void addAlertForAllAudienceAndStates(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search Link");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// type Entity Name in Name field
			type(Entity.ENTITY_NAME, strName, "Entity Name Field");
			click(Entity.SEARCH_BTN, "Search Button");
			waitForElementPresent(Entity.CREATE_ENTITY_BTN, "Create Entity Button");
			// click on 1st Entity Name in Search Result Grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity in grid");
			// Verify the page is entity profile
			assertTextMatching(Alerts.PAGE_TITLE, "Entity Profile", "Verify Page title is Entity Profile");
			// click on ALerts Link from left nav bar
			click(Entity.ALERTS, "Click On Alerts Link from left nav bar");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text fieldAlerts
			type(Alerts.ALERTS_TEXTFIELD, strAlertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALL_STATE, "Select All from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			assertElementPresent(Alerts.ADDUPDATE_BTN, "Add/Update button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addAlertForAllAudienceAndSpecificStates(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strName = Excelobject.getCellData(ReportSheet, "Entity Name", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search Link");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// type Entity Name in Name field
			type(Entity.ENTITY_NAME, strName, "Entity Name Field");
			click(Entity.SEARCH_BTN, "Search Button");
			waitForElementPresent(Entity.CREATE_ENTITY_BTN, "Create Entity Button");
			// click on 1st Entity Name in Search Result Grid
			click(Entity.FIRST_ENTITY_IN_GRID, "First Entity in grid");
			// Verify the page is entity profile
			assertTextMatching(Alerts.PAGE_TITLE, "Entity Profile", "Verify Page title is Entity Profile");
			// click on ALerts Link from left nav bar
			click(Entity.ALERTS, "Click On Alerts Link from left nav bar");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text field
			type(Alerts.ALERTS_TEXTFIELD, strAlertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALABAMA_STATE, "Select Alabama from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			assertElementPresent(Alerts.ADDUPDATE_BTN, "Add/Update button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addAlertForAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// BusinessFunctions_Alerts ob = new BusinessFunctions_Alerts();
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
			String alertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);
			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			// Verify the page is Affiliation Profile
			assertTextMatching(Alerts.PAGE_TITLE, "Affiliation Profile", "Verify Page title is Affiliation Profile");
			// Click on Affiliation Alerts Button
			click(Affiliation.AFFILIATIONALERTSBTN, "Affiliation Alerts Button");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text field
			type(Alerts.ALERTS_TEXTFIELD, alertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALABAMA_STATE, "Select Alabama from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			assertElementPresent(Alerts.ADDUPDATE_BTN, "Add/Update button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expireAlertForUnaffEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify the page is entity profile
			assertTextMatching(Alerts.PAGE_TITLE, "Entity Profile", "Verify Page title is Entity Profile");
			// click on ALerts Link from left nav bar
			click(Entity.ALERTS, "Click On Alerts Link from left nav bar");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text fieldAlerts
			type(Alerts.ALERTS_TEXTFIELD, strAlertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALL_STATE, "Select All from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Verify the radio buttons for expiration field
			assertElementPresent(Alerts.EXPIRATION_ON_END_DATE_RADIO_BTN, "Expiration for end date radio button");
			assertElementPresent(Alerts.PROMPT_BRFORE_EXPIRATION_RADIO_BTN, "Prompt Before Expiration radio button");
			click(Alerts.PROMPT_BRFORE_EXPIRATION_RADIO_BTN, "Prompt Before Expiration radio button");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			assertElementPresent(Alerts.ADDUPDATE_BTN, "Add/Update button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expireAlertForAffiliatedEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify the page is entity profile
			assertTextMatching(Alerts.PAGE_TITLE, "Entity Profile", "Verify Page title is Entity Profile");
			// click on ALerts Link from left nav bar
			click(Entity.ALERTS, "Click On Alerts Link from left nav bar");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text fieldAlerts
			type(Alerts.ALERTS_TEXTFIELD, strAlertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALL_STATE, "Select All from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Verify the radio buttons for expiration field
			assertElementPresent(Alerts.EXPIRATION_ON_END_DATE_RADIO_BTN, "Expiration for end date radio button");
			assertElementPresent(Alerts.PROMPT_BRFORE_EXPIRATION_RADIO_BTN, "Prompt Before Expiration radio button");
			click(Alerts.PROMPT_BRFORE_EXPIRATION_RADIO_BTN, "Prompt Before Expiration radio button");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			assertElementPresent(Alerts.ADDUPDATE_BTN, "Add/Update button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expireAlertForAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// BusinessFunctions_Alerts ob = new BusinessFunctions_Alerts();

			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
			String alertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);
			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			// Verify the page is Affiliation Profile
			assertTextMatching(Alerts.PAGE_TITLE, "Affiliation Profile", "Verify Page title is Affiliation Profile");
			// Click on Affiliation Alerts Button
			click(Affiliation.AFFILIATIONALERTSBTN, "Affiliation Alerts Button");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text field
			type(Alerts.ALERTS_TEXTFIELD, alertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALABAMA_STATE, "Select Alabama from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Verify the radio buttons for expiration field
			assertElementPresent(Alerts.EXPIRATION_ON_END_DATE_RADIO_BTN, "Expiration for end date radio button");
			assertElementPresent(Alerts.PROMPT_BRFORE_EXPIRATION_RADIO_BTN, "Prompt Before Expiration radio button");
			click(Alerts.PROMPT_BRFORE_EXPIRATION_RADIO_BTN, "Prompt Before Expiration radio button");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			assertElementPresent(Alerts.ADDUPDATE_BTN, "Add/Update button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expiringAlerts(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Expiring ALerts Link from left nav bar
			click(Entity.MYEXPIRINGALERTS, "Click On My Expiring Alerts Link from left nav bar");
			// Verify the page is My Expiring Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "My Expiring Alerts", "Verify Page title is My Expiring Alerts");
			// Select filter as All state
			click(Alerts.STATE_FIRST_FILTER, "Select state from First Filter");
			click(Alerts.ALL_SECOND_FILTER, "Select All from Second Filter");
			click(Entity.GO_BTN, "Go Button");
			// Click On First Extend Button
			click(Alerts.FIRST_EXTEND_BUTTON, "Click On First Extend Button");
			// Verify the page is Extend Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Extend Alerts", "Verify Page title is Extend Alerts");
			// Verify State field is All and click on cancel btn
			assertTextMatching(Alerts.STATE_LABEL_VALUE, "All", "Verify State Value is All");
			click(Alerts.ALERTS_CANCEL_BTN, "Cancel Button");
			// Verify the page is My Expiring Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "My Expiring Alerts", "Verify Page title is My Expiring Alerts");
			// Select filter as All state
			click(Alerts.AUDIENCE_FIRST_FILTER, "Select Audience from First Filter");
			click(Alerts.ALL_SECOND_FILTER, "Select All from Second Filter");
			click(Entity.GO_BTN, "Go Button");
			// Click On First Extend Button
			click(Alerts.FIRST_EXTEND_BUTTON, "Click On First Extend Button");
			// Verify the page is Extend Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Extend Alerts", "Verify Page title is Extend Alerts");
			// Verify State field is All and click on cancel btn
			assertTextMatching(Alerts.AUDIENCE_LABEL_VALUE, "All", "Verify Auidience Value is All");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expireAnAlert(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String strAlertText = Excelobject.getCellData(ReportSheet, "Alert Text", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify the page is entity profile
			assertTextMatching(Alerts.PAGE_TITLE, "Entity Profile", "Verify Page title is Entity Profile");
			// click on ALerts Link from left nav bar
			click(Entity.ALERTS, "Click On Alerts Link from left nav bar");
			// Verify the page is Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "Alerts", "Verify Page title is Alerts");
			// type text in Alert Text fieldAlerts
			type(Alerts.ALERTS_TEXTFIELD, strAlertText, "Alert Text Field");
			// Select All from state and audience drpdwn
			click(Alerts.ALL_STATE, "Select All from state dropdown");
			click(Alerts.ALL_AUDIENCE, "Select All from audience dropdown");
			// Click on Calendar and select todays date
			click(Alerts.CALENDAR, "Calendar Icon");
			click(Alerts.TODAYSDATE, "Todays Date");
			// Click on Add/Update button
			click(Alerts.ADDUPDATE_BTN, "Add/Update button");
			// click on My Expiring ALerts Link from left nav bar
			click(Entity.MYEXPIRINGALERTS, "Click On My Expiring Alerts Link from left nav bar");
			Thread.sleep(4000);
			// Verify the page is My Expiring Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "My Expiring Alerts", "Verify Page title is My Expiring Alerts");
			// Click On First Expire Button
			click(Alerts.FIRST_EXPIRE_BUTTON, "Click On First Expire Button");
			// Handle Popup
			handlepopup();
			// Verify the page is My Expiring Alerts
			assertTextMatching(Alerts.PAGE_TITLE, "My Expiring Alerts", "Verify Page title is My Expiring Alerts");
		} catch (Exception e) {
			throw e;
		}
	}
}
