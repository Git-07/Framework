package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CIOXSprint8 extends BusinessFunctions_CIOXSprint2 {

	public String verifyCESInternalCommentsWorksheetCreate(String reportSheet, int count) throws Throwable {

		String esopId = "";
		String cesInternalComments = "";
		String internalComments = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID").split("\\: ")[1];

			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
			
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

			// enter entity name in Entity Search page and click on Search
			// button
			type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
			click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}
			
			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			
			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
		    if(entitySearchCount == 0) {
			//Click on unidentified entity
			waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
			String disabledUnEntity = "";
			try {				
			disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
			System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
			}catch(NullPointerException e) {}
			if(disabledUnEntity == null) {
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
			Thread.sleep(1500);
			System.out.println("REached here in line 6420");
			try {
			if(disabledUnEntity.equals("true")) {					
			  //SEARCH_AGAIN_BUTTON
			  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
			  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
			  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
			  //CANCEL_BUTTON
			  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
			  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
			  click(SOP.CANCEL_BUTTON, "Cancel Button");
			}}catch(NullPointerException e) {}				
             System.out.println("REached here in line 6431");
             Thread.sleep(2000);
             //below will be a go ahead when the value for unidentified Entity above is selected
             String unEntityRadioSelected = "";
             try {                	 
            	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
             }catch(NoSuchElementException e) {}
             catch(NullPointerException e) {}
             Thread.sleep(1000);
             try {
             if(unEntityRadioSelected == null) {
            	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
             }}catch(NullPointerException e) {}
			//ENTITY_TEXT_BOX
			waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
			//DOMESTIC_JURISDICTION_SELECTION
			waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
			//REP_JURISDICTION_SELECTION
			waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 
			
		    }
		    else if(entitySearchCount != 0) {
			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			//FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			//CONTINUE_BUTTON
			try {
				List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
				if(action.size()>0) {

					click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
				}
			}
			catch(NoSuchElementException e) {

			}
			waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

			// Enter log id in log text field
			type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(4000);
			// Click on Unrelated worksheet
			click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
		    }
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			//USE_THIS_COURT
			waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			click(SOP.USE_THIS_COURT,"Use this court radio button");
			//COURT_NAME_TEXT_BOX
			waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			type(SOP.COURT_NAME_TEXT_BOX, "Tesla Court","Court NAme");
			//ADDRESS_LINE_ONE
			waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
			//CITY_NAME
			waitForElementPresent(SOP.CITY_NAME,"City Name text box");
			assertElementPresent(SOP.CITY_NAME,"City Name text box");
			type(SOP.CITY_NAME,"Houston","City Name text box");
			//STATE_NAME
			waitForElementPresent(SOP.STATE_NAME,"State Name text box");
			assertElementPresent(SOP.STATE_NAME,"State Name text box");
			type(SOP.STATE_NAME,"TX","State Name text box");
			//ZIP_CODE
			waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
			assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
			type(SOP.ZIP_CODE,"77550","Zip code text box");

			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			/*click(SOP.CES_INTERNAL_COMMENTS_DRPDWN, "CES Internal Comments Drpdwn");
			cesInternalComments = getText(SOP.CES_INTERNAL_COMMENTS_DRPDWN, "CES Internal Comments");*/
			type(SOP.CES_INTERNAL_COMMENTS, "Process Validated", "Internal Comments Text");
			Thread.sleep(2000);
			cesInternalComments = getAttribute(SOP.CES_INTERNAL_COMMENTS, "value");

			click(SOP.SUBMITBTN, "Submit Button");
			//click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			createWorksheetViaSOPList(reportSheet, count, esopId);

			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");

			assertElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			assertElementPresent(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments Drpdwn");
			internalComments = getText(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments").split(": ")[1];

			compareStrings(cesInternalComments, internalComments);

			assertElementPresent(SOP.INTERNAL_COMMENTS_FIELD, "Internal Comments Field");
			assertElementPresent(SOP.INTERNAL_COMMENTS_METADATA, "Internal Comments Metadata");
			isElementNotPresent(SOP.CES_INTERNAL_COMMENTS_TEXT, "CES Internal Comments");
			assertElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Drpdwn");
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
					"Service of Process Destination Page");

		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyAddedInternalCommentsForCreateWorksheetPage(String reportSheet, int count, String esopId) throws Throwable {

		//String internalComments = "";
		String newInternalComments = "";
		String cesMetaData = "";
		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			//viewAndCreateTheWorkSheetUsingESOPId(reportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window")) {
				assertElementPresent(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments Drpdwn");
				//internalComments = getText(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments").split(": ")[1];
			}
			// Create Worksheet Page
			if (verifyIfElementPresent(SOP.METHOD_OF_SERVICE, "Method of Service")) {
				selectBySendkeys(SOP.METHOD_OF_SERVICE, "Fax", "Method Of Service as Fax");
				//waitForElementPresent(SOP.TIME_TEXTFIELD, "Text Field for Time");
				Thread.sleep(2000);
				type(SOP.TIME_TEXTFIELD, "08:00", "Text Field for Time");
			}

			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYFACILITY, "New York Facility 1 (LIS)");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYTEAM, "CT - New York SOP Team");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BYNY, "TEST New York SOP Team");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "123-234", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Entity Radio Button");
			click(WorksheetCreate.ENTITY_SELECT, "Select Entity Button");
			assertElementPresent(WorksheetCreate.ENTITY_NAME_SEARCH, "Entity Search Page");
			click(Generic.CANCEL, "Cancel Button");
			/*waitForElementPresent(WorksheetCreate.CREATE_WORKSHEET_SINGLE, "Create Worksheet");
			assertElementPresent(WorksheetCreate.CREATE_WORKSHEET_SINGLE, "Create Worksheet");*/
			// Select Unidentified Radio Button
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			Thread.sleep(2000);
			type(WorksheetCreate.ENTITY_NAME, "Entity Name for Testing", "Enter Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Select Alabama");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			click(WorksheetCreate.UNIDENTIFIED_JURIS_GLYPHICON, "Unidentified Juris Glyphicon Click");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Alabama", "Select Alabama");

			/*selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1, "First Reject Reason");
			click(SOP.DATE_CALENDAR, "Calendar Icon");
			click(Entity.TODAYSDATE, "Todays Date");*/

			// Create Worksheet Step 2
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			//selectBySendkeys(WorksheetCreate.COURT, "U.S. Marshall", "Court");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			//selectBySendkeys(WorksheetCreate.AGENCY, "U.S. Marshall", "Agency");
			click(WorksheetCreate.RADIO_BUTTON_SENDER, "Existing Attorney Radio Button");
			selectBySendkeys(WorksheetCreate.ATTORNEY_OR_SENDER, "Adam Cooper", "Attorney");

			// Create Worksheet Step 3
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "LawSuitType Drpdwn");
			Thread.sleep(2000);
			type(WorksheetCreate.AMOUNT_DUE, "200", "Amount Due");
			click(WorksheetCreate.RADIO_BUTTON_ANSWERDATE, "Answer Radio Button");
			click(WorksheetCreate.FIRST_ANSWER_DATE, "First Answer");
			selectBySendkeys(WorksheetCreate.ANSWER_DATE, "Immediately", "Answer Date Selected");
			click(SOP.FIRST_INTERNAL_COMMENTS, "Internal Comments Text");
			//click(SOP.SOP_INTERNAL_COMMENTS_DRPDWN, "Internal Comments Text");
			Thread.sleep(2000);
			newInternalComments = getText(SOP.FIRST_INTERNAL_COMMENTS, "Internal Comments Text");
			//newInternalComments = getText(SOP.SOP_INTERNAL_COMMENTS_DRPDWN, "Internal Comments Text");
			/*waitForElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "SOP Internal Comments");
			assertElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "SOP Internal Comments");
	        type(SOP.INTERNAL_COMMENTS_TEXTBOX,"CIOX Testing In Progress", "Internal Comments Text");
			Thread.sleep(2000);
	        newInternalComments = getAttribute(SOP.INTERNAL_COMMENTS_TEXTBOX, "value");*/
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(SOP.COMMENTS_LABEL_METADATA, "Internal Comments Metadata");
			cesMetaData = getText(SOP.COMMENTS_LABEL_METADATA, "Internal Comments Metadata");
			assertTextContains(cesMetaData, newInternalComments);

		}catch (Exception e) {
			throw e;
		}
		return newInternalComments;
	}

	public String verifyCESInternalCommentsForWorksheetEditPage(String reportSheet, int count, String newIntrnalComments) throws Throwable {

		String cesInternalComments = "";
		String metaData = "";
		String newInternalComments = "";
		String modifiedMetaData = "";
		String worksheetId = "";
		try {
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			Thread.sleep(2000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			assertElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			assertElementPresent(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments Drpdwn");
			cesInternalComments = getText(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments");
			assertTextContains(cesInternalComments, "Process Validated");
			assertElementPresent(SOP.INTERNAL_COMMENTS_FIELD, "Internal Comments Field");
			assertElementPresent(SOP.INTERNAL_COMMENTS_METADATA, "Internal Comments Metadata");
			metaData = getText(SOP.INTERNAL_COMMENTS_METADATA, "Internal Comments Metadata");
			isElementNotPresent(SOP.CES_INTERNAL_COMMENTS_TEXT, "CES Internal Comments");
			assertTextContains(metaData, newIntrnalComments);
			waitForElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Drpdwn");
			assertElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Drpdwn");
			/*click(SOP.FIRST_INTERNAL_COMMENTS, "First option for Internal Comments");
				newInternalComments = getText(SOP.FIRST_INTERNAL_COMMENTS, "Text for Internal Comments");*/

			waitForElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
			assertElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
			type(SOP.INTERNAL_COMMENTS_TEXTBOX, "Post Issues Observed Identify Fix", "Internal Comments Text");
			Thread.sleep(2000);
			newInternalComments = getAttribute(SOP.INTERNAL_COMMENTS_TEXTBOX, "value");

			click(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			assertElementPresent(SOP.SPECIFIC_COMMENTS_METADATA, "Internal Comments Metadata");
			modifiedMetaData = getText(SOP.SPECIFIC_COMMENTS_METADATA, "Internal Comments Metadata");
			compareStrings(newInternalComments, modifiedMetaData);
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			compareStrings(modifiedMetaData, newInternalComments);
			isElementNotPresent(SOP.USER_COMMENTS, "User Comments");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");
			worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");


		}catch (Exception e) {
			throw e;
		}
		return worksheetId.split("\\: ")[1];
	}

	public String verifyCESInternalCommentsForWorksheetReviewPage(String reportSheet, int count, String newIntrnalComments) throws Throwable {

		String cesInternalComments = "";
		String metaData = "";
		String newInternalComments = "";
		String modifiedMetaData = "";
		String worksheetId = "";
		try {
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");
			worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID").split("\\: ")[1];

			createSOPIncidentReport(worksheetId);


			waitForElementPresent(HomePage.SOPLINK,"SOP Link");
			assertElementPresent(HomePage.SOPLINK,"SOP Link");
			click(HomePage.SOPLINK,"SOP Link");
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "Worksheet Search Left Nav Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			waitForElementPresent(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			Thread.sleep(2000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			if (verifyIfElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window")) {
				assertElementPresent(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments Drpdwn");
				cesInternalComments = getText(SOP.CES_INTERNAL_COMMENTS_LABEL, "CES Internal Comments");
				assertTextContains(cesInternalComments, "Process Validated");
				assertElementPresent(SOP.REVIEW_SUB_TYPE, "Review Subtype dropdown");
				selectBySendkeys(SOP.REVIEW_SUB_TYPE, "Customer Impact", "Review Subtype dropdown");
				assertElementPresent(SOP.INTERNAL_COMMENTS_FIELD, "Internal Comments Field");
				assertElementPresent(SOP.INTERNAL_COMMENTS_METADATA, "Internal Comments Metadata");
				metaData = getText(SOP.INTERNAL_COMMENTS_METADATA, "Internal Comments Metadata");
				isElementNotPresent(SOP.CES_INTERNAL_COMMENTS_TEXT, "CES Internal Comments");
				assertTextContains(metaData, newIntrnalComments);
				waitForElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Drpdwn");
				assertElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Drpdwn");
				/*click(SOP.FIRST_INTERNAL_COMMENTS, "First option for Internal Comments");
				newInternalComments = getText(SOP.FIRST_INTERNAL_COMMENTS, "Text for Internal Comments");*/

				waitForElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
				assertElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
				type(SOP.INTERNAL_COMMENTS_TEXTBOX, "Post Issues Observed Identify Fix", "Internal Comments Text");
				Thread.sleep(2000);
				newInternalComments = getAttribute(SOP.INTERNAL_COMMENTS_TEXTBOX, "value");

				click(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");
				waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

				assertElementPresent(SOP.SPECIFIC_COMMENTS_METADATA, "Internal Comments Metadata");
				modifiedMetaData = getText(SOP.SPECIFIC_COMMENTS_METADATA, "Internal Comments Metadata");
				compareStrings(newInternalComments, modifiedMetaData);
				click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
				waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
				assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
				waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");

				compareStrings(modifiedMetaData, newInternalComments);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			}

		}catch (Exception e) {
			throw e;
		}
		return worksheetId;
	}

	public String verifyPdfIFrameFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "ML Slider is opened");
			assertElementPresent(SOP.PDF_CREATE_EDIT_REVIEW_IFRAMEID, "Pdf Details iFrame");
			assertElementPresent(SOP.EXPAND_PDF_CREATE_EDIT_REVIEW, "Expand Pdf Function");
			click(SOP.EXPAND_PDF_CREATE_EDIT_REVIEW, "Expand Pdf Function");
			assertElementPresent(SOP.COLLAPSE_PDF_CREATE_EDIT_REVIEW, "Collapse Pdf Function");
			click(SOP.COLLAPSE_PDF_CREATE_EDIT_REVIEW, "Collapse Pdf Function");
			assertElementPresent(SOP.CLOSE_PDF_CREATE_EDIT_REVIEW, "Close Pdf Function");
			click(SOP.CLOSE_PDF_CREATE_EDIT_REVIEW, "Close Pdf Function");
			assertElementPresent(SOP.OPEN_PDF_CREATE_EDIT_REVIEW, "Open Pdf Function");
			assertElementPresent(SOP.PDF_POPUP_CREATE_EDIT_REVIEW, "Pdf PopUp Function");
			click(SOP.OPEN_PDF_CREATE_EDIT_REVIEW, "Open Pdf Function");

			waitForElementPresent(SOP.PDF_POPUP_CREATE_EDIT_REVIEW, "Pdf PopUp Function");
			assertElementPresent(SOP.PDF_POPUP_CREATE_EDIT_REVIEW, "Pdf PopUp Function");
			String parentWindow = driver.getWindowHandle();
			click(SOP.PDF_POPUP_CREATE_EDIT_REVIEW, "Pdf PopUp Function");
			handlePopUpWindwow();
			isElementNotPresent(SOP.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyPdfIFrameWorksheetCreate(String reportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			//viewAndCreateTheWorkSheetUsingESOPId(reportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			verifyPdfIFrameFunctionality(reportSheet, count);
			assertElementPresent(SOP.CREATE_PAGE_TITLE, "Create Worksheet Page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			isElementNotPresent(SOP.PDF_ICONBTN, "Pdf Icon");
			isElementNotPresent(SOP.TOP_SAVE_BTN, "Save Button at Top");
			isElementNotPresent(Generic.CANCEL_BUTTON, "Cancel Button at Top");
			isElementNotPresent(SOP.TOP_SAVE_INCOMPLETE_BTN, "Save Incomplete Button at Top");
			assertElementPresent(SOP.BOTTOM_CANCELBTN, "Cancel Button at Bottom");
			assertElementPresent(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");
			assertElementPresent(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Bottom");

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyPdfIFrameWorksheetEdit(String reportSheet, int count) throws Throwable {

		try {
			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			assertTextMatching(SOP.PAGE_TITLE, "Edit Worksheet", "Title of the page");
			Thread.sleep(2000);
			verifyPdfIFrameFunctionality(reportSheet, count);
			assertElementPresent(SOP.EDIT_PAGE_TITLE, "Edit Worksheet Page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			isElementNotPresent(SOP.PDF_ICONBTN, "Pdf Icon");
			isElementNotPresent(SOP.TOP_SAVE_BTN, "Save Button at Top");
			isElementNotPresent(Generic.CANCEL_BUTTON, "Cancel Button at Top");
			isElementNotPresent(SOP.TOP_SAVE_INCOMPLETE_BTN, "Save Incomplete Button at Top");
			assertElementPresent(SOP.BOTTOM_CANCELBTN, "Cancel Button at Bottom");
			assertElementPresent(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");
			/*assertElementPresent(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Bottom");*/

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyPdfIFrameWorksheetReview(String reportSheet, int count) throws Throwable {

		try {
			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			assertTextMatching(SOP.PAGE_TITLE, "Review Worksheet", "Title of the page");
			Thread.sleep(2000);
			verifyPdfIFrameFunctionality(reportSheet, count);
			assertElementPresent(SOP.REVIEW_PAGE_TITLE, "Review Worksheet Page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			isElementNotPresent(SOP.PDF_ICONBTN, "Pdf Icon");
			isElementNotPresent(SOP.TOP_SAVE_BTN, "Save Button at Top");
			isElementNotPresent(Generic.CANCEL_BUTTON, "Cancel Button at Top");
			isElementNotPresent(SOP.TOP_SAVE_INCOMPLETE_BTN, "Save Incomplete Button at Top");
			assertElementPresent(SOP.BOTTOM_CANCELBTN, "Cancel Button at Bottom");
			assertElementPresent(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");
			/*assertElementPresent(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Bottom");*/

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public void verifyBackToCRMButttonForReviewWorksheetPage(String reportSheet, int count) throws Throwable {

		try {
			String requestId = Excelobject.getCellData(reportSheet, "Request Id", count);
			//CRM_LINK
			waitForElementPresent(HomePage.CRM_LINK,"CRM Link");
			assertElementPresent(HomePage.CRM_LINK,"CRM Link");
			click(HomePage.CRM_LINK,"CRM Link");
			assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
			type(CRM.REQUESTID, requestId, "Request Id");
			click(Generic.SEARCH, "Search Button");
			click(CRM.FIRST_CRM_DATA, "CRM Data");
			assertTextMatching(CRM.PAGE_TITLE, "Edit Request", "Title of the page");
			click(CRM.WORKSHEET_LINK, "WorksheetCRM Link");
			assertTextMatching(SOP.PAGE_TITLE, "Review Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			isElementNotPresent(CRM.TOP_BACK_TO_CRM_BTN, "Back To CRM Button at Top");
			assertElementPresent(CRM.BOTTOM_BACK_TO_CRM_BTN, "Back To CRM Button at Bottom");

		} catch (Exception e) {
			throw e;
		}

	}
}
