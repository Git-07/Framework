package com.arrow.workflows;

import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_CIOXSprint5 extends BusinessFunctions_CIOXSprint2{

	public String verifyPriorityColumnOnUnpostedLogsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			click(SOP.UNPOSTED_LOGS_NAV_LINK, "Unposted Logs Link");
			assertTextMatching(SOP.PAGE_TITLE, "Un-Posted Logs", "Title Of The Page");
			isElementNotPresent(SOP.PRIORITY_COLUMN, "Priority Column On Uposted Logs Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPrioritySortOnUnpostedLogsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			click(SOP.UNPOSTED_LOGS_NAV_LINK, "Unposted Logs Link");
			assertTextMatching(SOP.PAGE_TITLE, "Un-Posted Logs", "Title Of The Page");
			isElementNotPresent(SOP.PRIORITY_SORT_LINK, "Priority Sort Link On Uposted Logs Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFilterOnUnpostedLogsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			click(SOP.UNPOSTED_LOGS_NAV_LINK, "Unposted Logs Link");
			assertTextMatching(SOP.PAGE_TITLE, "Un-Posted Logs", "Title Of The Page");
			isElementNotPresent(SOP.PRIORITY_FILTER, "Priority Field Dropdown On Uposted Logs Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedFieldOnDocketHistoryPopUpPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			isElementNotPresent(SOP.CLONED_COPIED_FIELD, "Cloned/Copied Field");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedColumnOnDocketHistoryPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.DOCKET_HISTORY_NAV_LINK, "Docket History Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Docket History", "Title of the page");
			isElementNotPresent(SOP.CLONED_COPIED_COLUMN, "Cloned/Copied Field");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	
}
