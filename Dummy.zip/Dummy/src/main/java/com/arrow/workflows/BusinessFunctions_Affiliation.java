package com.arrow.workflows;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.USOP;
//import com.thoughtworks.selenium.webdriven.commands.Click;

public class BusinessFunctions_Affiliation extends BusinessFunctions_Alerts {

	public void CreateEntity(String ReportSheet, int count) throws Throwable {
		try {

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : catchBlock() Author : Vrushali Kakade Description : This method
	 * will catch the Exception Date of creation : modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void catchBlock(Exception e) throws Throwable {
		if (e.getMessage() != null)
			parent.appendChild(child);
		gStrErrMsg = e.getMessage();
		closeSummaryReport(browsertype);
		driver.quit();
		openBrowser();
		Thread.sleep(lSleep_VLow);

	}

	/********************************************************************************************************
	 * Method Name : CreateAffiliation() Author : Vrushali Kakade Description : This
	 * method will create affiliation Date of creation : 3/28/2019 modifying person
	 * : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CreateAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strBranchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String strName = Excelobject.getCellData(ReportSheet, "Name", count);
			String strDefSalesAssignment = Excelobject.getCellData(ReportSheet, "Def. Sales Assignment", count);
			String strLawFirm = Excelobject.getCellData(ReportSheet, "Law Firm", count);
			String strCommonRenewal = Excelobject.getCellData(ReportSheet, "Common Renewal", count);
			String strSubGroupName = Excelobject.getCellData(ReportSheet, "Sub Group Name", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Recipient", count);
			String strComment = Excelobject.getCellData(ReportSheet, "Comment", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATION_TAB, "Affiliation tab");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// type any value(valid or invalid) in the name text field and click on Search
			// button
			type(Affiliation.AFFILIATIONNAME, strName, "Affiliation Name Field");
			click(Affiliation.SEARCHBTN, "Search Button");
			waitForElementPresent(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");

			// click on Create Affiliation button
			click(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");
			waitForElementPresent(Affiliation.NAMEFIELD, "Affiliation Name Text Field");

			// Enter Branch Plant, Name, Def Sales Assignment, Law Firm, Common Renewal,
			// SubGroup Name
			selectByVisibleText(Affiliation.BRANCHPLANTDRPDWN, strBranchPlant, "Branch Plant Dropdown");
			waitForElementPresent(Affiliation.NAMEFIELD, "Name field");
			type(Affiliation.NAMEFIELD, strName, "Name field");
			selectByVisibleText(Affiliation.SALESASSGNMNTDRPDWN, strDefSalesAssignment,
					"Def. Sales Assignment Drop down");
			selectByVisibleText(Affiliation.LAWFIRMDRPDWN, strLawFirm, "Law Firm Drop down");
			selectByVisibleText(Affiliation.COMMONRENEWALDRPDWN, strCommonRenewal, "Common Renewal Drop down");
			type(Affiliation.SUBGROUPNAMEFIELD, strSubGroupName, "Sub Group Name field");

			// select participant
			click(Affiliation.SELECTBTN, "Select button");
			waitForElementPresent(Affiliation.PARTICIPANTNAMEFIELD, "Participant Name Text Field");

			type(Affiliation.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Affiliation.FINDBTN, "Find button");

			waitForElementPresent(Affiliation.TABLEID, "Recipient Table");
			clickOnFirstElement(Affiliation.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(Affiliation.COMMENTFIELD, strComment, "Comment field");
			click(Affiliation.SAVEBTN, "Save button");

			waitForElementPresent(Affiliation.AFFILIATIONIDONPROFILE, "Affiliation ID on affiliation profile page");

			String affl_id = getText(Affiliation.AFFILIATIONIDONPROFILE, "Affiliation ID");

			return affl_id;

		} catch (Exception e) {
			throw e;
		}
	}

	public void manageAffiliationAlerts(String ReportSheet, int count) throws Throwable {
		// BusinessFunctions_Alerts ob = new BusinessFunctions_Alerts();
		blnEventReport = true;
		String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
		String alertText = Excelobject.getCellData(ReportSheet, "AlertText", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// Click on Affiliation Alerts Button
		click(Affiliation.AFFILIATIONALERTSBTN, "Affiliation Alerts Button");

		AddAlerts(alertText);

		// Click on Affiliation Profile Button and then click on print button
		click(Affiliation.AFFILIATIONPROFILEBTN, "Affiliation Profile Button");
		click(Affiliation.AFFILIATIONPROFILEPRINTBTN, "Affiliation Profile Print Button");

		// Verify that Affiliation Alerts is added on clicking of print page
		handlePopUpWindwow();
		waitForElementPresent(Affiliation.VERIFYAFFILIATIONALERTS, "Affiliation Alerts Text");
		assertTextMatching(Affiliation.VERIFYAFFILIATIONALERTS, "There are Alerts for this Affiliation",
				"Affiliation Alerts Text");

	}

	public void quitAffiliations(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);
		String entityID = Excelobject.getCellData(ReportSheet, "Entity ID", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// Click on members button from left nav links on affiliation profile page and
		// click on quit affiliation and then click on quit affiliation button
		click(Affiliation.MEMBERSBTN, "Members Button");
		click(Affiliation.QUITAFFILIATIONBTN, "Quit Affiliation Button");

		// Verify whether an error msg is displayed when no entity is selected and the
		// user clicks on quit affiliation btn
		assertTextMatching(Affiliation.QUIT_AFFILIATION_ERRMSG,
				"At least one member must be selected to quit the affiliation.", "Error Messsage on quit affiliation");

		// click on add members btn
		click(Affiliation.ADDMEMBERSBTN, "Add Members Button");
		// select entity radio button
		click(Affiliation.ENTITYRADIOBTN, "Entity Radio Button");

		// Enter an entity id in text box and click on search button
		type(Affiliation.ENTITYIDONADDAFFILIATIONMEMBERS, entityID, "Entity Id");
		click(Affiliation.SEARCHBTN, "Search Button");

		// Check the entity and click on Add Selected Entities Button and complete the
		// process
		click(Affiliation.ENTITYNAMESCHECKBOX1, "Entity Names CheckBox");
		click(Affiliation.ADDSELECTEDENTITIESBTN, "Add Selected Entities Button");
		click(Affiliation.BULLETINRETAINCURRENTDI, "Bulletin Retain Current DI Button");
		click(Affiliation.COMMRETAINCURRENTDI, "Communication Retain Current DI Button");
		click(Affiliation.RENEWALINVOICERETAINCURRENTDI, "Renewal Invoice Retain Current DI Button");
		click(Affiliation.SOPRETAINCURRENTDI, "SOP 	Retain Current DI Button");
		selectByIndex(Affiliation.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
		type(Affiliation.COMMENTS, comment, "Comments");
		click(Affiliation.JOINBTN, "Join Button");
		click(Affiliation.GOBACKBTN, "Go Back Button");

		// Select an entity name and again click on quit affiliation button
		click(Affiliation.ENTITYNAMESCHECKBOX1, "Entity Names CheckBox");
		click(Affiliation.QUITAFFILIATIONBTN, "Quit Affiliation Button");

		// Click on cancel button on Confirm Quitting Affiliation Page
		click(Affiliation.QUITAFFILIATIONCANCELBTN, "Quit Affiliation CANCEL Button");

		// Turn off the entity that was checked before and then click on another entity
		click(Affiliation.ENTITYNAMESCHECKBOX1, "Entity Names CheckBox");

		selectBySendkeys(Affiliation.FIRSTFILTER, "Entity#", "Select Entity Id from First Filter");
		selectBySendkeys(Affiliation.SECONDFILTER, "=", "Select = sign from First Filter");
		type(Affiliation.FILTERTEXTBOX, entityID, "Filter text Box");
		click(Affiliation.GOBTN, "Go Button");
		click(Affiliation.ENTITYNAMESCHECKBOX1, "Entity Names CheckBox");

		// Again click on Quit affiliation button
		waitForElementPresent(Affiliation.QUITAFFILIATIONBTN, "Quit Affiliation Button");
		click(Affiliation.QUITAFFILIATIONBTN, "Quit Affiliation Button");

		// Enter comments on Confirm Quitting Affiliation Page and then click on quit
		// affiliation button
		type(Affiliation.QUITAFFILIATIONCOMMENTSECTTION, comment, "Comments");
		click(Affiliation.QUITAFFILIATIONBTN2, "Quit Affiliation Button");

		Thread.sleep(5000);

		// HandlePopup and click on go back button
		handlepopup();
		click(Affiliation.MEMBERSBTN, "Members Button");

		// Verify Whether Entity is not present in the grid
		selectBySendkeys(Affiliation.FIRSTFILTER, "Entity#", "Select Entity Id from First Filter");
		selectBySendkeys(Affiliation.SECONDFILTER, "=", "Select = sign from First Filter");
		type(Affiliation.FILTERTEXTBOX, entityID, "Filter text Box");
		click(Affiliation.GOBTN, "Go Button");
		isElementPresent(Affiliation.NORECORDSFOUND, "No records Found msg");

	}

	public void navigateToSubGroup(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String strName = Excelobject.getCellData(ReportSheet, "Name", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// type any value(valid or invalid) in the name text field and click on Search
		// button
		type(Affiliation.AFFILIATIONNAME, strName, "Affiliation Name Field");
		click(Affiliation.SEARCHBTN, "Search Button");
		waitForElementPresent(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");

		// click on the first result on affiliation search result page and then click on
		// Sub Groups button
		click(Affiliation.FIRSTRESULTONSEARCHPAGE, "First Result On Affilaition Search Result Page");
		click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

	}

	public void unsuccessfulAffiliationSearch(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String incorrectAffID = Excelobject.getCellData(ReportSheet, "AfiiliationIDNotPresent", count);
		String correctAffID = Excelobject.getCellData(ReportSheet, "AffiliationIDPresent", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		Thread.sleep(lSleep_Medium);
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, incorrectAffID, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// click on search again button on affiliation search results page
		waitForElementPresent(Affiliation.NORECORDFOUNDTEXT, "NO RECORD FOUND Text");
		click(Affiliation.SEARCHAGAINBTN, "Search Again Button");

		// search for an affiliation again
		type(Affiliation.AFFILIATIONID, correctAffID, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");
		waitForElementPresent(Affiliation.PRICELISTBTN, "Price List Button");

	}

	public void createSubGroups(String ReportSheet, int count, String affID) throws Throwable {
		blnEventReport = true;
		System.out.println(affID);
		affID = affID.replaceAll("[^\\d.]", "");
		String bulletinSubGroupName = Excelobject.getCellData(ReportSheet, "BulletinSubGroupName", count);
		String communicationSubGroupName = Excelobject.getCellData(ReportSheet, "CommunicationSubGroupName", count);
		String renewalSubGroupName = Excelobject.getCellData(ReportSheet, "RenewalSubGroupName", count);
		String sopSubGroupName = Excelobject.getCellData(ReportSheet, "SopSubGroupName", count);
		String participantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

		// click on Affiliation Search link
		click(Affiliation.AFFILIATIONSEARCHLEFTNAVLINK, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, affID, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// click on Sub Groups Button
		waitForElementPresent(Affiliation.SUBGROUPSBTN, "Sub Group Button");
		click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

		// click on create sub group button
		click(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

		// click on Create Bulletin Sub Group Button on Create Sub Group(s) page and
		// turn off CROW Enabled Button
		click(Affiliation.CREATEBULLETINSUBGROUPBTN, "Create Bulletin Sub Group Button");
		click(Affiliation.CROWENABLEDBTN, "Crow Enabled Button");

		// Turn on Overridable Button and enter bulletin sub group name
		click(Affiliation.OVERRIDABLEBTN, "Overridable Button");
		waitForElementPresent(Affiliation.BULLETINSUBGROUPNAME, "Bulletin Sub Group Name");
		type(Affiliation.BULLETINSUBGROUPNAME, bulletinSubGroupName, "Bulletin Sub Group Name");

		Thread.sleep(5000);

		// click on Create Communication Sub Group Button and turn off CROW Enabled
		// Button
		click(Affiliation.CREATECOMMUNICATIONSUBGROUPBTN, "Create Communication Sub Group Button");
		click(Affiliation.CREATECOMMUNICATIONCROWENABLEDBTN, "Create Communication CROW Enabled Button");
		waitForElementPresent(Affiliation.CREATECOMMUNICATIONSUBGROUPNAME, "Comm Sub Group Name");
		type(Affiliation.CREATECOMMUNICATIONSUBGROUPNAME, communicationSubGroupName, "Comm Sub Group Name");
		Thread.sleep(5000);

		// click on Create Renewal Sub Group Button and turn off CROW Enabled
		// Button
		click(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Sub Group Button");
		click(Affiliation.CREATERENEWALCROWENABLEDBTN, "Create Renewal CROW Enabled Button");
		waitForElementPresent(Affiliation.CREATERENEWALSUBGROUPNAME, "Renewal Sub Group Name");
		type(Affiliation.CREATERENEWALSUBGROUPNAME, renewalSubGroupName, "Renewal Sub Group Name");
		Thread.sleep(5000);

		// click on Create SOP Sub Group Button and turn off CROW Enabled
		// Button
		click(Affiliation.CREATESOPSUBGROUPBTN, "Create SOP Sub Group Button");
		click(Affiliation.CREATESOPCROWENABLEDBTN, "Create SOP CROW Enabled Button");
		waitForElementPresent(Affiliation.CREATESOPSUBGROUPNAME, "SOP Sub Group Name");
		type(Affiliation.CREATESOPSUBGROUPNAME, sopSubGroupName, "SOP Sub Group Name");
		Thread.sleep(5000);

		// click on select button of Recipient Field
		click(Affiliation.RECIPIENTSELECTBTN, "Recipient Select Button");

		// Enter a participant on Find DI Recipient Page and click on find button
		type(Affiliation.PARTICIPANTNAME, participantName, "Participant Name");
		click(Affiliation.FINDDIRECIPENTBTN, "DI Recepient Find Button");

		// Select a participant
		click(Affiliation.PARTICIPANTSELECTBTN, "Participant Select Button");

		// click on save button
		click(Affiliation.CREATESUBGROUPSAVEBTN, "Save Button");
		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

		selectBySendkeys(Affiliation.FIRSTFILTER, "Sub Group Name", "Select Sub Group Name from first filter");
		selectBySendkeys(Affiliation.SECONDFILTER, "contains", "Select contains filter from second filter");
		type(Affiliation.FILTERTEXTBOX, sopSubGroupName, "Filter text box");
		click(Affiliation.GOBTN, "Go Button");
		click(Affiliation.FIRSTRESULTONSEARCHPAGE, "First Result On Search Page");
		assertTextMatching(Affiliation.SUBGROUPPROFILETITLE, "Sub Group Profile View", "Tiltle of the Page");
		assertTextMatching(Affiliation.SUBGROUPNAME, sopSubGroupName, "Sub Group Name");
	}

	public void manageSubGroupMembershipPage(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// click on Sub Groups Button
		click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

		// click on Move Members button
		click(Affiliation.MOVEMEMBERSBTN, "Move Members Button");

		// Verify whether it is navigated to Manage Sub Group Membership Page
		assertTextMatching(Affiliation.MANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE,
				"Manage Sub Group Membership - Search Criteria", "Title of the page");

	}

	public void entityOnManageSubGroupMembershipPage(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
		String entityId = Excelobject.getCellData(ReportSheet, "EntityID", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// click on Sub Groups Button
		click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

		// click on Move Members button
		click(Affiliation.MOVEMEMBERSBTN, "Move Members Button");

		// Verify whether it is navigated to Manage Sub Group Membership Page
		assertTextMatching(Affiliation.MANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE,
				"Manage Sub Group Membership - Search Criteria", "Title of the page");

		// Search for an entity that doesnt exists and click on search button
		type(Affiliation.ENTITYIDONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE, entityId, "Entity Id");
		click(Affiliation.SEARCHBTN, "Search Button");

		// Verify that "No Records Found" message is displayed
		assertTextMatching(Affiliation.NORECORDSFOUND, "No records found.", "No Records Found Message");

	}

	public void searchEntityInAffiliationSubGroup(String ReportSheet, int count) throws Throwable {
		blnEventReport = true;
		String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
		String entityId = Excelobject.getCellData(ReportSheet, "TestEntityID", count);
		String entityName = Excelobject.getCellData(ReportSheet, "TestEntityName", count);
		String comment = Excelobject.getCellData(ReportSheet, "Comment", count);

		// click on Affiliation Search link
		click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

		// Enter an id to be searched and click on search button
		type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
		click(Affiliation.SEARCHBTN, "Search Button");

		// click on Members button
		click(Affiliation.MEMBERSBTN, "Members Button");

		// Verify Whether entity is already added in the members list
		selectByIndex(Affiliation.FIRSTFILTER, 3, "Entity #");
		selectByIndex(Affiliation.SECONDFILTER, 2, "Equal Operator");
		type(Affiliation.FILTERTEXTBOX, entityId, "Filter Text box");
		click(Affiliation.GOBTN, "Go Button");

		if (verifyIfElementPresent(Affiliation.NORECORDSFOUND, "No Records Found Message")) {
			click(Affiliation.ADDMEMBERSBTN, "Add Members Button");
			// select entity radio button
			click(Affiliation.ENTITYRADIOBTN, "Entity Radio Button");

			// Enter an entity id in text box and click on search button
			type(Affiliation.ENTITYIDONADDAFFILIATIONMEMBERS, entityId, "Entity Id");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Check the entity and click on Add Selected Entities Button and complete the
			// process
			click(Affiliation.ENTITYNAMESCHECKBOX1, "Entity Names CheckBox");
			click(Affiliation.ADDSELECTEDENTITIESBTN, "Add Selected Entities Button");
			selectByIndex(Affiliation.BULLETINSUBGROUPDROPDWN, 1, "Bulletin Sub Group Drop Down Select");
			selectByIndex(Affiliation.COMMSUBGROUPDROPDWN, 1, "Communication Sub Group Drop Down Select");
			selectByIndex(Affiliation.RENEWALINVOICESUBGROUPDROPDWN, 1, "Renewal Invoice Sub Group Drop Down Select");
			selectByIndex(Affiliation.SOPSUBGROUPDROPDWN, 1, "Sop Sub Group Drop Down Select");
			selectByIndex(Affiliation.XSOPSUBGROUPDROPDWN, 1, "Xsop Sub Group Drop Down Select");
			type(Affiliation.COMMENTS, comment, "Comments");
			click(Affiliation.JOINBTN, "Join Button");
			click(Affiliation.GOBACKBTN, "Go Back Button");

			// click on Sub Groups Button
			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// click on Move Members button
			click(Affiliation.MOVEMEMBERSBTN, "Move Members Button");

			// Search for an entity by entering both id and name
			type(Affiliation.ENTITYIDONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE, entityId, "Entity Id");
			type(Affiliation.ENTITYNAMEONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE, entityName, "Entity Name");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify whether id overrides name
			assertTextMatching(Affiliation.VERIFYENTITYID, entityId,
					"Verify whether correct entity id is reflected in the grid");

		} else {
			// click on Sub Groups Button
			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// click on Move Members button
			click(Affiliation.MOVEMEMBERSBTN, "Move Members Button");

			// Search for an entity by entering both id and name
			type(Affiliation.ENTITYIDONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE, entityId, "Entity Id");
			type(Affiliation.ENTITYNAMEONMANAGESUBGROUPMEMBERSHIPSEARCHCRITERIAPAGE, entityName, "Entity Name");
			click(Affiliation.SEARCHBTN, "Search Button");
		}

	}

	public void unsuccessfulCreationOfAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strBranchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String strName = Excelobject.getCellData(ReportSheet, "Name", count);
			String strDefSalesAssignment = Excelobject.getCellData(ReportSheet, "Def. Sales Assignment", count);
			String strLawFirm = Excelobject.getCellData(ReportSheet, "Law Firm", count);
			String strCommonRenewal = Excelobject.getCellData(ReportSheet, "Common Renewal", count);
			String strSubGroupName = Excelobject.getCellData(ReportSheet, "Sub Group Name", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Recipient", count);
			String strComment = Excelobject.getCellData(ReportSheet, "Comment", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// type any value(valid or invalid) in the name text field and click on Search
			// button
			type(Affiliation.AFFILIATIONNAME, strName, "Affiliation Name Field");
			click(Affiliation.SEARCHBTN, "Search Button");
			waitForElementPresent(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");

			// click on Create Affiliation button
			click(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");
			waitForElementPresent(Affiliation.NAMEFIELD, "Affiliation Name Text Field");

			// Enter Branch Plant, Name, Def Sales Assignment, Law Firm, Common Renewal,
			// SubGroup Name
			selectByVisibleText(Affiliation.BRANCHPLANTDRPDWN, strBranchPlant, "Branch Plant Dropdown");
			type(Affiliation.NAMEFIELD, strName, "Name field");
			selectByVisibleText(Affiliation.SALESASSGNMNTDRPDWN, strDefSalesAssignment,
					"Def. Sales Assignment Drop down");
			selectByVisibleText(Affiliation.LAWFIRMDRPDWN, strLawFirm, "Law Firm Drop down");
			selectByVisibleText(Affiliation.COMMONRENEWALDRPDWN, strCommonRenewal, "Common Renewal Drop down");
			type(Affiliation.SUBGROUPNAMEFIELD, strSubGroupName, "Sub Group Name field");

			// select participant
			click(Affiliation.SELECTBTN, "Select button");
			waitForElementPresent(Affiliation.PARTICIPANTNAMEFIELD, "Participant Name Text Field");

			type(Affiliation.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Affiliation.FINDBTN, "Find button");

			waitForElementPresent(Affiliation.TABLEID, "Recipient Table");
			clickOnFirstElement(Affiliation.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(Affiliation.COMMENTFIELD, strComment, "Comment field");
			click(Affiliation.CANCELBTN, "Cancel button");
			waitForElementPresent(Affiliation.AFFILIATIONNAME, "Affiliation Name Field");

		} catch (Exception e) {
			throw e;
		}
	}

	public void validateFieldsAffiliationCreation(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			String strBranchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String strName = Excelobject.getCellData(ReportSheet, "Name", count);
			String strDefSalesAssignment = Excelobject.getCellData(ReportSheet, "Def. Sales Assignment", count);
			String strLawFirm = Excelobject.getCellData(ReportSheet, "Law Firm", count);
			String strCommonRenewal = Excelobject.getCellData(ReportSheet, "Common Renewal", count);
			String strSubGroupName = Excelobject.getCellData(ReportSheet, "Sub Group Name", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Recipient", count);
			String strComment = Excelobject.getCellData(ReportSheet, "Comment", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// type any value(valid or invalid) in the name text field and click on Search
			// button
			type(Affiliation.AFFILIATIONNAME, strName, "Affiliation Name Field");
			click(Affiliation.SEARCHBTN, "Search Button");
			waitForElementPresent(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");

			// click on Create Affiliation button
			click(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");
			waitForElementPresent(Affiliation.NAMEFIELD, "Affiliation Name Text Field");

			// Click on Save Button
			click(Affiliation.SAVEBTN, "Save button");
			waitForElementPresent(Affiliation.ERROR_BRANCH_PLANT, "Error entering Branch Plant is mandatory");
			;
			// Verify error messages are displayed for all mandatory fields
			assertElementPresent(Affiliation.ERROR_BRANCH_PLANT, "Error entering Branch Plant is mandatory");
			assertElementPresent(Affiliation.ERROR_AFFILIATION_NAME, "Error entering Affiliation name is mandatory");
			assertElementPresent(Affiliation.ERROR_RENEWAL_MONTH, "Error entering Renewal Month is mandatory");
			assertElementPresent(Affiliation.ERROR_XSOP_SUBGROUP_NAME,
					"Error entering XSOP Sub Group name is mandatory");
			assertElementPresent(Affiliation.ERROR_COMMENT, "Error entering Comment is mandatory");

			// Enter Branch Plant, Name, Def Sales Assignment, Law Firm, Common Renewal,
			// SubGroup Name
			selectByVisibleText(Affiliation.BRANCHPLANTDRPDWN, strBranchPlant, "Branch Plant Dropdown");
			type(Affiliation.NAMEFIELD, strName, "Name field");
			selectByVisibleText(Affiliation.SALESASSGNMNTDRPDWN, strDefSalesAssignment,
					"Def. Sales Assignment Drop down");
			selectByVisibleText(Affiliation.LAWFIRMDRPDWN, strLawFirm, "Law Firm Drop down");
			selectByVisibleText(Affiliation.COMMONRENEWALDRPDWN, strCommonRenewal, "Common Renewal Drop down");
			type(Affiliation.SUBGROUPNAMEFIELD, strSubGroupName, "Sub Group Name field");

			// select participant
			click(Affiliation.SELECTBTN, "Select button");
			waitForElementPresent(Affiliation.PARTICIPANTNAMEFIELD, "Participant Name Text Field");

			type(Affiliation.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Affiliation.FINDBTN, "Find button");

			waitForElementPresent(Affiliation.TABLEID, "Recipient Table");
			clickOnFirstElement(Affiliation.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(Affiliation.COMMENTFIELD, strComment, "Comment field");
			click(Affiliation.SAVEBTN, "Save button");
			waitForElementPresent(Affiliation.AFFILIATIONIDONPROFILE, "Affiliation ID on affiliation profile page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void entityTypeCorporate(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// click on Members button
			click(Affiliation.MEMBERSBTN, "Members Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Members", "Verify Page Title is Affiliation Members");

			click(Affiliation.TYPE_FIRSTFILTER, "Select Type from first filter");
			click(Affiliation.CORPORATION_SECONDFILTER, "Select Corporation from second filter");
			click(Affiliation.GOBTN, "Go Button");

			click(Affiliation.CORPORATEENTITYNAME, "Click on first corporate entity name from the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Verify Page Title is Entity Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public void editDomesticRep(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Verify Page Title is Entity Profile");

			// Click on Representation Tab
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			assertTextMatching(Entity.PAGE_TITLE, "Representation Units", "Verify Page Title is Representation Units");

			// Click On Domestic Rep Unit
			click(Rep.DOMESTIC_REP_UNIT_AGENT, "Domestic Rep Unit");
			assertTextMatching(Entity.PAGE_TITLE, "Representation Unit - Profile",
					"Verify Page Title is Representation Unit - Profile");

			// Edit Domestic Rep Unit
			click(Rep.REP_EDIT_BUTTON, "Edit Button");
			assertTextMatching(Entity.PAGE_TITLE, "Edit Representation Unit",
					"Verify Page Title is Edit Representation Unit");

			// Edit State id and click on save button
			type(Rep.STATE_ID_TEXTBOX, "2345678", "State ID text Box");
			click(Entity.SAVE_BTN, "Save Button");

			assertTextMatching(Entity.PAGE_TITLE, "Representation Unit - Profile",
					"Verify Page Title is Representation Unit - Profile");

		} catch (Exception e) {
		}
	}

	public void sortAndExportSubGroups(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Profile", "Verify Page Title is Affiliation Profile");

			// Click on Sub Groups Link
			click(Affiliation.SUBGROUPSBTN, "Sub Group left nav link");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Sub Groups",
					"Verify Page Title is Affiliation Sub Groups");

			// Check whether All sorting links are present
			click(Affiliation.ACTIVE_SUB_GROUP_NAME_SORT_LINK, "Active Sort By Sub Group Name Link");
			isElementPresent(Affiliation.INACTIVE_SUB_GROUP_TYPE_SORT_LINK, "Inactive Sort By Sub Group Type Link");
			isElementPresent(Affiliation.INACTIVE_MEMBER_COUNT_SORT_LINK, "Inactive Sort By Member Count Link");

			click(Affiliation.INACTIVE_SUB_GROUP_TYPE_SORT_LINK, "Inactive Sort By Sub Group Type Link");
			isElementPresent(Affiliation.ACTIVE_SUB_GROUP_TYPE_SORT_LINK, "Active Sort By Sub Group Type Link");
			click(Affiliation.INACTIVE_MEMBER_COUNT_SORT_LINK, "Inactive Sort By Member Count Link");
			isElementPresent(Affiliation.ACTIVE_MEMBER_COUNT_SORT_LINK, "Active Sort By Member Count Link");

			// Click On Export Button
			click(Affiliation.EXPORT_BTN, "Export Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Sub Groups",
					"Verify Page Title is Affiliation Sub Groups");

		} catch (Exception e) {
			throw e;
		}
	}

	public void assumedNameOfEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);
			String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Profile", "Verify Page Title is Affiliation Profile");

			// Click on Sub Groups Link
			click(Affiliation.SUBGROUPSBTN, "Sub Group left nav link");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Sub Groups",
					"Verify Page Title is Affiliation Sub Groups");

			// Select Second Sub Group from the grid
			click(Affiliation.SECOND_SUB_GROUP_ON_GRID, "Select Second Sub Group from the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Sub Group Profile View",
					"Verify Page Title is Sub Group Profile View");

			// Click on Sub Group Members Link
			click(Affiliation.SUB_GROUP_MEMBERS, "Sub Group Members left nav link");
			assertTextMatching(Entity.PAGE_TITLE, "Sub Group Members", "Verify Page Title is Sub Group Members");

			// Apply filter by entity
			click(Affiliation.ENTITY_ID_FIRST_FILTER, "Select Entity id from first filter");
			click(Affiliation.EQUAL_SECOND_FILTER, "Select = from second filter");
			type(Affiliation.FILTERTEXTBOX, entityId, "Filter Text box");
			click(Affiliation.GOBTN, "Go Button");

			// Select first entity from grid
			click(Affiliation.FIRST_ENTITY_ON_GRID, "Select First Entity on grid");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Verify Page Title is Entity Profile");
			// Verify the value of assumed names is 1
			assertTextMatching(Entity.ASSUMED_NAMES_VALUE, "1", "Value of assumed names field");

		} catch (Exception e) {
			throw e;
		}
	}

	public void createAffWithNoCommonRenewalMonth(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strName = Excelobject.getCellData(ReportSheet, "Affiliation Name", count);
			String strBranchPlant = Excelobject.getCellData(ReportSheet, "Branch Plant", count);
			String strSubGroupName = Excelobject.getCellData(ReportSheet, "Sub Group Name", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Recipient", count);
			String strComment = Excelobject.getCellData(ReportSheet, "Comment", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");

			// type any value(valid or invalid) in the name text field and click on Search
			// button
			type(Affiliation.AFFILIATIONNAME, strName, "Affiliation Name Field");
			click(Affiliation.SEARCHBTN, "Search Button");
			waitForElementPresent(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");

			// click on Create Affiliation button
			click(Affiliation.CREATEAFFILIATIONBTN, "Create Affiliation Button");
			assertTextMatching(Entity.PAGE_TITLE, "Create Affiliation", "Verify Page Title is Create Affiliation");

			// Enter Branch Plant, Name
			selectByVisibleText(Affiliation.BRANCHPLANTDRPDWN, strBranchPlant, "Branch Plant Dropdown");
			type(Affiliation.NAMEFIELD, strName, "Name field");

			// Select Customer Requested No Common Renewal Month Radio Button
			click(Affiliation.CUSTOMER_REQUESTED_NO_COMMON_RENEWAL_MONTH_RADIO_BUTTON,
					"Customer Requested No Common Renewal Month Radio Button");

			// Enter Subgroup name
			type(Affiliation.SUBGROUPNAMEFIELD, strSubGroupName, "Sub Group Name field");

			// select participant
			click(Affiliation.SELECTBTN, "Select button");
			waitForElementPresent(Affiliation.PARTICIPANTNAMEFIELD, "Participant Name Text Field");

			type(Affiliation.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Affiliation.FINDBTN, "Find button");

			waitForElementPresent(Affiliation.TABLEID, "Recipient Table");
			clickOnFirstElement(Affiliation.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");

			// enter Comments and click on Save button
			type(Affiliation.COMMENTFIELD, strComment, "Comment field");
			click(Affiliation.SAVEBTN, "Save button");
			waitForElementPresent(Affiliation.AFFILIATIONIDONPROFILE, "Affiliation id on profile page");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Profile", "Verify Page Title is Affiliation Profile");

			// Verify the value of common renewal is Customer Requested No Common Renewal
			// Month
			assertTextMatching(Affiliation.COMMON_RENEWAL, "Customer Requested No Common Renewal Month",
					"Common Renewal Value");

		} catch (Exception e) {
			throw e;
		}
	}

	public void defaultLayoutAndDIUsageLayout(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			// TODO
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Profile", "Verify Page Title is Affiliation Profile");

			// Click on members link
			click(Affiliation.MEMBERSBTN, "Members Button on left nav bar");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Members", "Verify Page Title is Affiliation Members");

			// Click On DI Usage Layout
			click(Affiliation.DI_USAGE_LAYOUT_TAB, "DI Usage Layout Tab");
			assertElementPresent(Affiliation.NORECORDFOUNDTEXT, "No records found text");

			// Click On Default Layout
			click(Affiliation.DEFAULT_LAYOUT_TAB, "Default Layout Tab");
			assertElementPresent(Affiliation.NORECORDFOUNDTEXT, "No records found text");
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectUnselectMembersOnDefaultLayout(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Profile", "Verify Page Title is Affiliation Profile");

			// Click on members link
			click(Affiliation.MEMBERSBTN, "Members Button on left nav bar");
			assertTextMatching(Entity.PAGE_TITLE, "Affiliation Members", "Verify Page Title is Affiliation Members");

			// Click On Select Page and update entity references button
			click(Affiliation.SELECT_PAGE_BTN, "Select Page Button");
			click(Affiliation.UPDATE_ENTITY_REFERENCES_BTN, "Update Entity References Button");
			assertTextMatching(Entity.PAGE_TITLE, "Update Entity Reference Numbers",
					"Verify Page Title is Update Entity Reference Numbers");

			click(Affiliation.CANCELBTN, "Cancel Button");

			// Click On Unselect Page and update entity references button
			click(Affiliation.UNSELECT_PAGE_BTN, "UnSelect Page Button");
			click(Affiliation.UPDATE_ENTITY_REFERENCES_BTN, "Update Entity References Button");

			// Verify error message
			assertElementPresent(Affiliation.UPDATE_ENTITY_REFERENCES_ERRMSG,
					"Error Message for Update Entity References");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : revenueForCommonRenewalMonth() Author : Pradyumna Description :
	 * This method will "View Revenue for Year" in Pricing Details when Common
	 * Renewal month is selected Date of creation : 11/15/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void revenueForCommonRenewalMonth(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			CreateAffiliation(ReportSheet, count);
			click(Affiliation.PRICING_DETAILS, "Pricing Details Button");
			assertElementPresent(Affiliation.PRICING_DETAILS_PAGE, "Pricing Details Page");
			click(Affiliation.REVENUE_YEAR_RADIO_BUTTON, "Revenue Year Radio button");
			type(Affiliation.REVENUE_YEAR_TEXT, "2020", "Revenue Year: 2020");
			click(Affiliation.CALCULATE_BTN, "Calculate button");
			assertElementPresent(Affiliation.GROSS_AMOUNT, "Gross Amount");
			assertElementPresent(Affiliation.ERROR_MESSAGE_FOR_REVENUE, "No revenue exists for specified year.");
		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : revenueForNoRenewalMonth() Author : Pradyumna Description :
	 * This method will "View Revenue for Year" in Pricing Details when no Common
	 * Renewal month is selected Date of creation : 11/15/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void revenueForNoRenewalMonth(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			createAffWithNoCommonRenewalMonth(ReportSheet, count);
			click(Affiliation.PRICING_DETAILS, "Pricing Details Button");
			assertElementPresent(Affiliation.PRICING_DETAILS_PAGE, "Pricing Details Page");
			click(Affiliation.REVENUE_YEAR_RADIO_BUTTON, "Revenue Year Radio button");
			type(Affiliation.REVENUE_YEAR_TEXT, "2020", "Revenue Year: 2020");
			click(Affiliation.CALCULATE_BTN, "Calculate button");
			assertElementPresent(Affiliation.GROSS_AMOUNT, "Gross Amount");
			assertElementPresent(Affiliation.ERROR_MESSAGE_FOR_REVENUE, "No revenue exists for specified year.");
		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : existingRevenueNoRenewalMonth() Author : Pradyumna Description
	 * : This method will "View Revenue for Year" in Pricing Details when no Common
	 * Renewal month is selected Date of creation : 11/15/2019 modifying person :
	 * Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void existingRevenueNoRenewalMonth(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			assertElementPresent(Affiliation.AFFLN_SEARCH_CRITERIA, "Affiliation Search Criteria");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, "310400651", "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			assertElementPresent(Affiliation.AFFLN_PROFILE, "Affiliation Profile Page");

			click(Affiliation.PRICING_DETAILS, "Pricing Details Button");
			assertElementPresent(Affiliation.PRICING_DETAILS_PAGE, "Pricing Details Page");
			click(Affiliation.REVENUE_YEAR_RADIO_BUTTON, "Revenue Year Radio button");
			type(Affiliation.REVENUE_YEAR_TEXT, "2020", "Revenue Year: 2020");
			click(Affiliation.CALCULATE_BTN, "Calculate button");
			assertElementPresent(Affiliation.GROSS_AMOUNT, "Gross Amount");
			// assertElementPresent(Affiliation.ERROR_MESSAGE_FOR_REVENUE, "No revenue
			// exists for specified year.");
			// Now check this pricing details for Entity
			click(Affiliation.MEMBERSBTN, "Members button");
			assertElementPresent(Affiliation.AFFLN_MEMBERS_PAGE, "Affiliation Members Page");
			click(Affiliation.CORPORATEENTITYNAME, "Select First Member");
			assertElementPresent(Entity.ENTITY_PROFILE_PAGE, "Entity Profile Page");
			click(Entity.ENTITY_PRICING, "Entity Pricing Details");
			assertElementPresent(Affiliation.PRICING_DETAILS_PAGE, "Pricing Details Page");
			click(Affiliation.REVENUE_YEAR_RADIO_BUTTON, "Revenue Year Radio button");
			type(Affiliation.REVENUE_YEAR_TEXT, "2020", "Revenue Year: 2020");
			click(Affiliation.CALCULATE_BTN, "Calculate button");
			assertElementPresent(Affiliation.GROSS_AMOUNT, "Gross Amount");

		} catch (Exception e) {
			throw e;
		}
	}

	public void companyTree(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;
			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			assertElementPresent(Affiliation.AFFLN_SEARCH_CRITERIA, "Affiliation Search Criteria");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONNAME, "as", "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			click(Affiliation.FIRST_AFFILIATION_ON_GRID, "First affiliation on grid");
			assertElementPresent(Affiliation.AFFLN_PROFILE, "Affiliation Profile Page");

			// Click on Company Tree left nav link
			waitForElementPresent(Affiliation.AFFLN_PROFILE, "Affiliation Profile Page");
			click(Affiliation.COMPANY_TREE_LINK, "Company Tree left nav link");
			assertTextMatching(Affiliation.PAGE_TITLE, "Company Tree", "Page Title");

			// Click on cancel button
			click(Affiliation.CANCELBTN, "Cancel Button");

			// Click on change topmost parent button
			click(Affiliation.CHANGE_TOPMOST_PARENT_BTN, "Change Topmost Parent Button");
			assertElementPresent(Affiliation.COMPANY_TREE_PAGE, "Company Tree Page");

			// Plus Button though getting highlighted its not getting clicked
			// Click on Plus and then minus button
			// click(Affiliation.PLUS_BTN, "Plus Button");
			// click(Affiliation.MINUS_BTN, "Minus Button");

			// Click on save button
			click(Affiliation.SAVEBTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void delawareARNotificationOptOutOnAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Verify Delaware AR Notification Opt-Out Label is present on Affiliation
			// Profile Page and its default value is No
			assertElementPresent(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_LABEL,
					"Delaware AR Notification Opt-Out Label");
			assertTextMatching(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE, "No",
					"Delaware AR Notification Opt-Out Value");

			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");
			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "Edit Affiliation", "Page Title");

			// Verify Delaware AR Notification Opt-Out Label is present on Affiliation Edit
			// Page and its checkbox is unchecked
			assertElementPresent(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_LABEL_ON_AFFI_EDIT,
					"Delaware AR Notification Opt-Out Label");
			isElementNotPresent(Affiliation.CHECKED_DELAWARE_NOTIFICATION_OPT_OUT,
					"Checked Delaware AR Notification Opt-Out");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminHavingPermissionsToEditDelawareARNotificationOptOut(String ReportSheet, int count)
			throws Throwable {
		try {
			blnEventReport = true;
			delawareARNotificationOptOutOnAffiliation(ReportSheet, count);
			// Click On Cancel Button
			click(Affiliation.CANCELBTN, "Cancel Button");
			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");

			// Check Delaware AR Notification Opt-Out checkbox
			click(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX, "Delaware AR Notification Opt-Out checkbox");

			// Enter comments and click on save button
			type(Affiliation.COMMENTFIELD, "Testing", "Comments Textbox");
			click(Affiliation.SAVEBTN, "Save Button");
			waitForElementPresent(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE,
					"Delaware AR Notification Opt-Out Value");

			// Verify Delaware AR Notification Opt-Out default value is Yes
			assertTextMatching(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE, "Yes",
					"Delaware AR Notification Opt-Out Value");

			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");

			// Verify Delaware AR Notification Opt-Out checkbox is checked
			assertElementPresent(Affiliation.CHECKED_DELAWARE_NOTIFICATION_OPT_OUT,
					"Checked Delaware AR Notification Opt-Out");

			// UnCheck Delaware AR Notification Opt-Out checkbox
			click(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX, "Delaware AR Notification Opt-Out checkbox");
			// Enter comments and click on save button
			type(Affiliation.COMMENTFIELD, "Testing", "Comments Textbox");
			click(Affiliation.SAVEBTN, "Save Button");
			waitForElementPresent(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE,
					"Delaware AR Notification Opt-Out Value");
			assertTextMatching(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE, "No",
					"Delaware AR Notification Opt-Out Value");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminNotHavingPermissionsToEditDelawareARNotificationOptOut(String ReportSheet, int count)
			throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");

			// Verify Delaware AR Notification Opt-Out checkbox is disabled
			isDisabled(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX, "Delaware AR Notification Opt-Out checkbox");

		} catch (Exception e) {
			throw e;
		}

	}

	public void updateInvoice(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Affiliation.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Click on members button from left nav links on affiliation profile page and
			click(Affiliation.MEMBERSBTN, "Members Button");
			assertTextMatching(Affiliation.PAGE_TITLE, "Affiliation Members", "Page Title");

			// Select first entity from grid
			click(Affiliation.ENTITYNAMESCHECKBOX1, "Select first entity from grid");

			// click on update invoice Button
			click(Affiliation.UPDATE_INVOICE_BTN, "Update Invoice Button");
			assertTextMatching(Affiliation.PAGE_TITLE, "Update Invoice", "Page Title");

			// Click on Assumed Name Details tab
			click(Affiliation.ASSUMED_NAMES_DETAILS_TAB, "Assumed Names Details tab");

			// Click on Calendar icon of Billed Through Date and select
			// todays date
			click(Affiliation.BILLED_THROUGH_DATE_CALENDAR, "Billed Through Date Calendar Icon");
			click(Affiliation.TODAYSDATE, "Todays Date");

			// Select first assumed name and click on update button
			click(Affiliation.ASSUMED_NAME_CHECKBOX1, "Select first assumed name");
			click(Affiliation.UPDATE_BTN, "Update button");
			assertTextMatching(Affiliation.PAGE_TITLE, "Update Invoice", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void verifyXSOPInvoicesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Affiliation.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Click on XSOP Invoices button from left nav links on affiliation profile page
			click(Affiliation.XSOP_INVOICES_LEFT_NAV_LINK, "Members Button");
			assertTextMatching(Affiliation.PAGE_TITLE, "XSOP Invoices", "Page Title");

			// Click o Generate Current Estimate Button
			click(Affiliation.GENERATE_CURRENT_ESTIMATE_BTN, "Generate Curren Estimate");
			Thread.sleep(3000);

			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");

			assertElementPresent(Entity.ESTIMATE_EXCESSS_SOP_TEXT, "Estimate Excess SOP Text");

			driver.close();
			driver.switchTo().window(parentWindow);
			waitForElementPresent(Affiliation.GENERATE_DETAIL_REPORT_BTN, "Generate Detail Report Button");

			// Click on Generate Detail Report Button on grid
			click(Affiliation.GENERATE_DETAIL_REPORT_BTN, "Generate Detail Report Button");
			waitForElementPresent(Affiliation.FIRST_XSOP_INVOICE_ON_GRID, "first invoice on the grid");

			// Click on first invoice on the grid
			click(Affiliation.FIRST_XSOP_INVOICE_ON_GRID, "first invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "XSOP Invoice Profile", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void createRenewalSubgroupWithInvalidElecProRecipient(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String renewalSubGroupName = Excelobject.getCellData(ReportSheet, "RenewalSubGroupName", count);
			String participantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

			navigateToSubGroup(ReportSheet, count);
			// click on create sub group button
			click(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");
			// click on Create Renewal Sub Group Button
			click(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Sub Group Button");
			waitForElementPresent(Affiliation.CREATERENEWALSUBGROUPNAME, "Renewal Sub Group Name");
			type(Affiliation.CREATERENEWALSUBGROUPNAME, renewalSubGroupName, "Renewal Sub Group Name");
			Thread.sleep(5000);
			// click on select button of Recipient Field
			click(Affiliation.RECIPIENTSELECTBTN, "Recipient Select Button");

			// Enter a participant on Find DI Recipient Page having invalid electronic
			// profile and click on find button
			type(Affiliation.PARTICIPANTNAME, participantName, "Participant Name");
			click(Affiliation.FINDDIRECIPENTBTN, "DI Recepient Find Button");

			// Select a participant
			click(Affiliation.PARTICIPANTSELECTBTN, "Participant Select Button");

			// click on save button
			click(Affiliation.CREATESUBGROUPSAVEBTN, "Save Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			selectBySendkeys(Affiliation.FIRSTFILTER, "Sub Group Name", "Select Sub Group Name from first filter");
			selectBySendkeys(Affiliation.SECONDFILTER, "contains", "Select contains filter from second filter");
			type(Affiliation.FILTERTEXTBOX, renewalSubGroupName, "Filter text box");
			click(Affiliation.GOBTN, "Go Button");
			click(Affiliation.FIRSTRESULTONSEARCHPAGE, "First Result On Search Page");
			assertTextMatching(Affiliation.SUBGROUPPROFILETITLE, "Sub Group Profile View", "Tiltle of the Page");
			assertTextMatching(Affiliation.SUBGROUPNAME, renewalSubGroupName, "Sub Group Name");

			// Verify AUTO Renew Field
			assertTextMatching(Affiliation.AUTORENEW_VALUE, "Inactive", "Auto Renew Field Value");

			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// Delete the subgroup
			selectBySendkeys(Affiliation.FIRSTFILTER, "Sub Group Name", "Select Sub Group Name from first filter");
			selectBySendkeys(Affiliation.SECONDFILTER, "contains", "Select contains filter from second filter");
			type(Affiliation.FILTERTEXTBOX, renewalSubGroupName, "Filter text box");
			click(Affiliation.GOBTN, "Go Button");
			click(Affiliation.FIRST_DELETE_BTN_ON_GRID, "First Delete Button on grid");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

	public void updateRenewalSubgroupWithInvalidElecProRecipient(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String renewalSubGroupName = Excelobject.getCellData(ReportSheet, "RenewalSubGroupName", count);
			String validparticipantName = Excelobject.getCellData(ReportSheet, "ValidParticipantName", count);
			String invalidparticipantName = Excelobject.getCellData(ReportSheet, "InvalidParticipantName", count);

			navigateToSubGroup(ReportSheet, count);
			// click on create sub group button
			click(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");
			// click on Create Renewal Sub Group Button
			click(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Sub Group Button");
			waitForElementPresent(Affiliation.CREATERENEWALSUBGROUPNAME, "Renewal Sub Group Name");
			type(Affiliation.CREATERENEWALSUBGROUPNAME, renewalSubGroupName, "Renewal Sub Group Name");
			Thread.sleep(5000);
			// click on select button of Recipient Field
			click(Affiliation.RECIPIENTSELECTBTN, "Recipient Select Button");

			// Enter a participant on Find DI Recipient Page having Valid electronic profile
			// and click on find button
			type(Affiliation.PARTICIPANTNAME, validparticipantName, "Participant Name");
			click(Affiliation.FINDDIRECIPENTBTN, "DI Recepient Find Button");

			// Select a participant
			click(Affiliation.PARTICIPANTSELECTBTN, "Participant Select Button");

			// click on save button
			click(Affiliation.CREATESUBGROUPSAVEBTN, "Save Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			selectBySendkeys(Affiliation.FIRSTFILTER, "Sub Group Name", "Select Sub Group Name from first filter");
			selectBySendkeys(Affiliation.SECONDFILTER, "contains", "Select contains filter from second filter");
			type(Affiliation.FILTERTEXTBOX, renewalSubGroupName, "Filter text box");
			click(Affiliation.GOBTN, "Go Button");
			click(Affiliation.FIRSTRESULTONSEARCHPAGE, "First Result On Search Page");
			assertTextMatching(Affiliation.SUBGROUPPROFILETITLE, "Sub Group Profile View", "Tiltle of the Page");
			assertTextMatching(Affiliation.SUBGROUPNAME, renewalSubGroupName, "Sub Group Name");

			// Click on EDit Button
			click(Affiliation.EDITDI_BTN, "edit DI Button");
			assertTextMatching(Affiliation.PAGE_TITLE, "Edit DI", "Tiltle of the Page");

			// Verify Active and Inactive Radio Buttons of Auto Renew Fields are Enabled
			assertElementPresent(Affiliation.ACTIVE_RADIO_BTN, "Active Radio Button");
			assertElementPresent(Affiliation.INACTIVE_RADIO_BTN, "Inactive Radio Button");
			// click on select button of Recipient Field
			click(Affiliation.SELECTBTN, "Recipient Select Button");

			// Enter a participant on Find DI Recipient Page having Valid electronic profile
			// and click on find button
			type(Affiliation.PARTICIPANTNAME, invalidparticipantName, "Participant Name");
			click(Affiliation.FINDDIRECIPENTBTN, "DI Recepient Find Button");

			// Select a participant
			click(Affiliation.PARTICIPANTSELECTBTN, "Participant Select Button");
			// Verify Active and Inactive Radio Buttons of Auto Renew Fields are Disabled
			getAttribute(Affiliation.ACTIVE_RADIO_BTN, "disabled");
			getAttribute(Affiliation.INACTIVE_RADIO_BTN, "disabled");
			type(Affiliation.EDITDI_COMMENTS_TEXTBOX, "Automation testing", "Edit DI Comments Text Box");
			// click on save button
			click(Affiliation.CREATESUBGROUPSAVEBTN, "Save Button");
			assertTextMatching(Affiliation.SUBGROUPNAME, renewalSubGroupName, "Sub Group Name");

			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// Delete the subgroup
			selectBySendkeys(Affiliation.FIRSTFILTER, "Sub Group Name", "Select Sub Group Name from first filter");
			selectBySendkeys(Affiliation.SECONDFILTER, "contains", "Select contains filter from second filter");
			type(Affiliation.FILTERTEXTBOX, renewalSubGroupName, "Filter text box");
			click(Affiliation.GOBTN, "Go Button");
			click(Affiliation.FIRST_DELETE_BTN_ON_GRID, "First Delete Button on grid");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

}
