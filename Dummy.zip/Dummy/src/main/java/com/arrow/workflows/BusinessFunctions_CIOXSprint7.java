package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_CIOXSprint7 extends BusinessFunctions_CIOXSprint2 {

	public String verifyCreateWrksheetLinkAtArrowHomePage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			waitForElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			isElementPresent(HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			isElementNotPresent(HomePage.CREATE_WORKSHEET_LINK, "Create Worksheet Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWrksheetLeftNavLink(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWrksheetLeftNavLinkDisabled(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.CES_LEFT_NAV_LINK, "CES Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "Worksheet Search Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Worksheet Search Criteria", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.WS_SEARCH_BY_BATCHNO_NAV_LINK, "WS Search By Batch No. Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Worksheet Search Criteria", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.CARRIER_PACKAGE_SEARCH, "Carrier Package Search Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Package Search", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.CARRIER_PENDING_QUEUE, "Carrier Pending Queue Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Carrier Pending Queue", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");
			click(SOP.MY_ACTION_ITEMS_NAV_LINK, "My Action Items Left Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Action Items", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_NAV_LINK, "Create Worksheet Nav Link");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWrksheetBtnOnMyWorksheetsPg(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_BUTTON, "Create Worksheet Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWrksheetBtnOnMyTeamsWorksheetsPg(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service Of Process List", "Title Of The Page");
			click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheets Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Service of Process Destination", "Title Of The Page");
			isElementNotPresent(SOP.CREATE_WORKSHEET_BUTTON, "Create Worksheet Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWorksheetNavLinkHighlighted(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title Of The Page");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCreateWorksheetNavLinkHighlightedLevel1(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");
			//click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			createWorksheetViaSOPList(ReportSheet, count, esopID);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title Of The Page");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyCourtListfieldstMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalCourtList = new ArrayList<String>();
			List<String> updatedCourtList = Arrays.asList("-- Select One --", "Alleghany County Superior Court", "Eastern District of New York - U.S. District Court...",
					"Eastern District of New York United States Distric...", "Nassau County Circuit Court", "Nassau County District Court",
					"Nassau County: District Court, 1st District: Hemps...", "Nassau County: District Court, 2nd District: Hemps...", "Nassau County: District Court, 3rd District: Great...",
					"Nassau County: District Court, 4th District: Hicks...", "New York District - Supreme Court - Erie Division", "New York Eastern District - U.S. Bankruptcy Court",
					"New York Eastern District - U.S. Bankruptcy Court ...", "New York Eastern District - U.S. Bankruptcy Court ...", "New York Eastern District - U.S. Bankruptcy Court ...", "New York Middle District - U.S. Bankruptcy Court -...",
					"New York Northern District - U.S. Bankruptcy Court...",
					"New York Northern District - U.S. District Court",
					"New York Southern District - Bankruptcy Court - Wh...", "New York Southern District - U. S. Bankruptcy Cour...", "New York Southern District - U.S. Bankruptcy Court",
					"New York Southern District - U.S. Bankruptcy Court...", "New York Southern District - U.S. Bankruptcy Court...", "New York Southern District - U.S. Bankruptcy Court...", "New York Southern District - U.S.District Court", "New York Southern District: United States District...",
					"New York Western District - U.S. Bankruptcy Court ...", "New York Western District -U.S. Bankruptcy Court", "Queens County: Criminal Court", "Southern District New York - United States Distric...", "Southern District of New York -United States Distr...", "Suffolk County: District Court", "Suffolk County: District Court, 10th District",
					"Suffolk County: District Court, 1st District: Ronk...", "Suffolk County: District Court, 2nd District", "Suffolk County: District Court, 3rd District: Hunt...", "Suffolk County: District Court, 4th District: Haup...", "Suffolk County: District Court, 6th District", "Suffolk County: District Court: 5th District", "Superior Court of Monroe County", "U.S. District Court, Western District, Buffalo Div...",
					"United States District Court, Western District");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {

				// Select Court from dropdown
				click(SOP.DROP_DOWN_COURT_NAME, "Select Court Name from dropdown");

				List<WebElement> arr = getAllDropDownData(SOP.DROP_DOWN_COURT_NAME);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalCourtList.add(we.getText());
				}
				compareTwoArrayList(updatedCourtList, originalCourtList);
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyUpdatedCourtListForCESPage(String reportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");

			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");

			/*// click on Select button of ARROW Entity box

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

			// enter entity name in Entity Search page and click on Search
			// button
			type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
			click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(5000);
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");

			// click on 1st entity of the search result, click on Home icon
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");
			Thread.sleep(5000);
			waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

			// Enter log id in log text field
			type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(4000);
			// Click on Unrelated worksheet
			click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");*/

			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Received Jurisdcition");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing Court drpdwn");
				verifyCourtListfieldstMethod(reportSheet, count);
			}
			/*waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");
			// select Lawsuit Type 
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");*/

		} catch (Exception e) {
			throw e;
		}
		return reportSheet;

	}

	public String verifyUpdatedCourtListForCreateWorksheetPage(String reportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing Court drpdwn");
				verifyCourtListfieldstMethod(reportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			} else {
				System.out.println("No Court Field present on Create Worksheet Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyUpdatedCourtListForEditWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing court drpdwn");
				verifyCourtListfieldstMethod(ReportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyUpdatedCourtListForReviewWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");

			// Review Worksheet
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing Court drpdwn");
				verifyCourtListfieldstMethod(ReportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyExistingWorksheetWithOldCourt(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.OLD_COURT_JURISDICTION, "11th Judicial District Court Harris County", "Old Court Jurisdiction");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				selectByVisibleText(SOP.STATE_OF_COURT_DRPDWN, "New York", "Existing court drpdwn");
				verifyCourtListfieldstMethod(ReportSheet, count);
				Thread.sleep(2000);
				click(Generic.CANCEL, "Cancel Button");
				assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
				assertTextMatching(SOP.OLD_COURT_JURISDICTION, "11th Judicial District Court Harris County", "Old Court Jurisdiction");

			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNoneSpecifiedCourtCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			//Use Non-Specified Court
			waitForElementPresent(SOP.COURT_NONE_RADIOBTN,"Court None Specified Radio Btn");
			assertElementPresent(SOP.COURT_NONE_RADIOBTN,"Court None Specified Radio Btn");
			click(SOP.COURT_NONE_RADIOBTN,"Court None Specified Radio Btn");

			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");


			createWorksheetViaSOPList(reportSheet, count, esopID);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			//Close the ML Slider
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			Thread.sleep(5000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			waitForElementPresent(SOP.RADIO_EXISTING_COURT, "Existing Court");
			assertElementPresent(SOP.RADIO_EXISTING_COURT, "Existing Court");
			if (verifyIfElementPresent(SOP.RADIO_EXISTING_COURT, "Existing Court")) {
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyUseThisCourtCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "mt", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "mt", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			//USE_THIS_COURT
			waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
			click(SOP.USE_THIS_COURT,"Use this court radio button");
			//COURT_NAME_TEXT_BOX
			waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
			type(SOP.COURT_NAME_TEXT_BOX, "Tesla Court","Court NAme");
			//ADDRESS_LINE_ONE
			waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
			type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
			//CITY_NAME
			waitForElementPresent(SOP.CITY_NAME,"City Name text box");
			assertElementPresent(SOP.CITY_NAME,"City Name text box");
			type(SOP.CITY_NAME,"Houston","City Name text box");
			//STATE_NAME
			waitForElementPresent(SOP.STATE_NAME,"State Name text box");
			assertElementPresent(SOP.STATE_NAME,"State Name text box");
			type(SOP.STATE_NAME,"TX","State Name text box");
			//ZIP_CODE
			waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
			assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
			type(SOP.ZIP_CODE,"77550","Zip code text box");

			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");

			createWorksheetViaSOPList(reportSheet, count, esopID);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			assertElementPresent(SOP.RADIO_USE_THIS_COURT, "Use This Court");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyStateOfCourtForLevel1User(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			isElementNotPresent(SOP.COURT_LABEL, "Court Label");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");

			createWorksheetViaSOPList(ReportSheet, count, esopID);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyStateOfCourtForLevel2User(String ReportSheet, int count) throws Throwable {

		String esopId = "";
		String esopID = "";
		try {
			blnEventReport = true;

			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");

			esopID = esopId.split("\\: ")[1];
			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			String ReceivedJurisdiction = getText(SOP.RECEIVED_JURISDICTION, "Received Jurisdiction");
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "kent", "Entity Name textfield on Entity Search page");
				//click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "kent", "Entity Name textfield on Entity Search page");
			}

			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if(entitySearchCount == 0) {
				//Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				}catch(NullPointerException e) {}
				if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
				Thread.sleep(1500);
				System.out.println("REached here in line 6420");
				try {
					if(disabledUnEntity.equals("true")) {					
						//SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						//CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				//below will be a go ahead when the value for unidentified Entity above is selected
				String unEntityRadioSelected = "";
				try {                	 
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
				}catch(NoSuchElementException e) {}
				catch(NullPointerException e) {}
				Thread.sleep(1000);
				try {
					if(unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}}catch(NullPointerException e) {}
				//ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
				//DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
				//REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down"); 

			}
			else if(entitySearchCount != 0) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, esopId, "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");
			}
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			isElementNotPresent(SOP.COURT_LABEL, "Court Label");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuit Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			createWorksheetViaSOPList(ReportSheet, count, esopID);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court")) {
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "Existing Court");
				verifyIfElementPresent(SOP.STATE_OF_COURT_DRPDWN, "Existing Court dropdown");
				assertTextMatching(SOP.STATE_OF_COURT_DRPDWN, ReceivedJurisdiction, "Existing Court drpdwn");
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyEsopAlertsCommentsForCreateWorksheetPage(String reportSheet, int count, String esopId) throws Throwable {

		String worksheetId = "";
		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");

			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Glyphicon Click for Received Label");
			waitForElementPresent(WorksheetCreate.DSSOP_EDIT_RECEIVED_BY, "DSSOP Received Member");
			click(WorksheetCreate.DSSOP_EDIT_RECEIVED_BY, "DSSOP Received Member");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
				waitForElementToBeClickable(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
				click(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
				assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Criteria", "Page Title");
				selectBySendkeys(SOP.NAME_TEXTBOX, "Jakobs and Wallis Real Estate Holding Company LLC", "Entering Entity Name");
				click(SOP.SEARCH_BTN, "Search Button");
				assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Results", "Page Title");
				click(SOP.SELECT_BUTTON_SELECT_RECIPIENT, "Select Button For Entity in the grid");
				waitForElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
				click(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
				click(WorksheetCreate.REP_SELECT, "Select Arrow Rep");
				waitForElementPresent(SOP.CLEARBTN, "Clear Btn");
				click(SOP.CLEARBTN, "Clear Btn");
				click(SOP.FIRST_REP_CES_REP_UNITS, "Select Button For Rep in the grid");
				WebElement specialCircumStances = null;
				try {
					specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);					
					if (specialCircumStances != null) {
						selectByVisibleText(WorksheetCreate.SPECIAL_CIRCUMSTANCES, "None"," Special Cicumstances drop down  in create wroksheet page");
						Thread.sleep(2000);
					}
				} catch (NoSuchElementException e) {
				}
			}

			assertElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			assertElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			assertElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			assertElementPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");

			waitForElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Static window in Expandable form & down arrow present");
			assertElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Static window in Expandable form & down arrow present");
			waitForElementToBeClickable(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Glyphicon Click for Collapsing Static Window");
			click(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Glyphicon Click for Collapsing Static Window");
			waitForElementToBeClickable(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click for Expanding Static Window");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click for Expanding Static Window");

			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			click(SOP.ATTORNEY_NONE_RADIOBTN, "None Specified Attorney Radio Button");

			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "LawSuitType Drpdwn");
			Thread.sleep(2000);
			type(WorksheetCreate.AMOUNT_DUE, "200", "Amount Due");
			click(WorksheetCreate.RADIO_BUTTON_ANSWERDATE, "Answer Radio Button");
			click(WorksheetCreate.FIRST_ANSWER_DATE, "First Answer");
			selectBySendkeys(WorksheetCreate.ANSWER_DATE, "Immediately", "Answer Date Selected");
			//type(SOP.INTERNAL_COMMENTS_TEXTBOX, "Testing in progress", "Internal Comments Text");
			click(SOP.FIRST_INTERNAL_COMMENTS, "Internal Comments Text");
			//click(SOP.SOP_INTERNAL_COMMENTS_DRPDWN, "Internal Comments Text");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");

			click(SOP.SAVE_BTN, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");
			worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet ID");

		} catch (Exception e) {
			throw e;
		}
		return worksheetId.split("\\: ")[1];
	}

	public String verifyEsopAlertsCommentsForEditWorksheetPage(String reportSheet, int count, String worksheetId) throws Throwable {

		try {
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			assertElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			Thread.sleep(2000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			waitForElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			assertElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			waitForElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			assertElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			waitForElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			assertElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			waitForElementPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");
			assertElementPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");

			waitForElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Static window in Expandable form & down arrow present");
			assertElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Static window in Expandable form & down arrow present");
			waitForElementToBeClickable(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Glyphicon Click for Collapsing Static Window");
			click(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Glyphicon Click for Collapsing Static Window");
			waitForElementToBeClickable(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click for Expanding Static Window");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click for Expanding Static Window");

			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyEsopAlertsCommentsForReviewWorksheetPage(String reportSheet, int count, String worksheetId) throws Throwable {

		try {
			//Create SOPIncidentReport On The Created Worksheet
			//CRM_LINK
			createSOPIncidentReport(worksheetId);

			waitForElementPresent(HomePage.SOPLINK,"SOP Link");
			assertElementPresent(HomePage.SOPLINK,"SOP Link");
			click(HomePage.SOPLINK,"SOP Link");
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "Worksheet Search Left Nav Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			waitForElementPresent(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			Thread.sleep(2000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");

			waitForElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			assertElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			waitForElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			assertElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			waitForElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			assertElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			waitForElementPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");
			assertElementPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");

			waitForElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Static window in Expandable form & down arrow present");
			assertElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Static window in Expandable form & down arrow present");
			waitForElementToBeClickable(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Glyphicon Click for Collapsing Static Window");
			click(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Glyphicon Click for Collapsing Static Window");
			waitForElementToBeClickable(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click for Expanding Static Window");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click for Expanding Static Window");

			click(Generic.CANCEL, "Cancel Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");


		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyNoAlertsCommentsOnEditWorksheetPage(String reportSheet, int count) throws Throwable {

		try {

			String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			isElementNotPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			isElementNotPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			isElementNotPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			isElementNotPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");

			click(Generic.CANCEL, "Cancel Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");


		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyNoAlertsCommentsOnReviewWorksheetPage(String reportSheet, int count) throws Throwable {

		try {

			String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			waitForElementPresent(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			Thread.sleep(2000);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");

			isElementNotPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			isElementNotPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			isElementNotPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			isElementNotPresent(SOP.CDSOP_ALERTS_LABEL, "CDSOP Comments Label in static window");

			click(Generic.CANCEL, "Cancel Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");


		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyAlertsCommentsForEditWorksheetExpeditedSOP(String reportSheet, int count) throws Throwable {

		try {

			String worksheetId = Excelobject.getCellData(reportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			waitForElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			assertElementPresent(SOP.INTERNAL_COMMENTS_LABEL, "Internal Comments Label in static window");
			waitForElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			assertElementPresent(SOP.COMMON_ALERTS_LABEL, "Common Alerts Label in static window");
			waitForElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");
			assertElementPresent(SOP.ENTITY_AFF_SG_ALERTS_LABEL, "Entity Affiliation Subgrp Alerts Label in static window");

			click(Generic.CANCEL, "Cancel Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");


		}catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}
}
