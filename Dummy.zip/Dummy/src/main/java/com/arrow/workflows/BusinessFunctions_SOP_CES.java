package com.arrow.workflows;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Invoice;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.SopHub;
import com.arrow.objectrepo.TeamSOPDashboard;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_SOP_CES extends BusinessFunctions_CommonCESAndWorksheet/*BusinessFunctions*/ {

	public String cesProcessingItem(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");

			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}
			
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			//FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

			// Enter log id in log text field
			type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(4000);
			// Click on Unrelated worksheet
			click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");

			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");

			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Lawsuit Type Dropdown");

			// select Lawsuite Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");

			//TODO add in sop list page

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String escalatedList(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");
			Thread.sleep(4000);

			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			
			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			String esopID = getText(SOP.ESOPID, "esop id");

			// Click on escalation details arrow
			click(SOP.ESCALATION_DETAILS_ARROW, "escalation details arrow");

			if(verifyIfElementPresent(SOP.ESCALATION_REASON, "Esclation Reason"))
			{
				// enter entity name in Entity Search page and click on Search
				// button

				waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
				String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
				if(cdsop.equalsIgnoreCase("CDSOP"))
				{
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

					// enter entity name in Entity Search page and click on Search
					// button
					type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
					click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
					click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
				}
				else {
					type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				}

				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");

				//PLAINTIFF_TEXT_BOX			
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
				//DEFENDANT_TEXT_BOX				
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN,"Lawsuit Type Dropdown");

				// select Lawsuite Type and click on Submit button
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
				click(SOP.SUBMITBTN, "Submit Button");

			}
			else {
				// Select reason and enter comments
				selectByIndex(SOP.REASON_DRPDWN, 1, "Reason Dropdown");
				type(SOP.ESCALATION_COMMENTS_TEXTBOX, "test", "Escalation Comments text box");

				// Click on Escalate Btn
				click(SOP.ESCALATE_BTN, "Escalate Button");

				// Click on Escalated List tab
				click(SOP.ESCALATED_LIST_TAB, "Escalated List tab");

				// Search for the log id escalated
				click(SOP.ESOP_ID_FIRST_FILTER, "Select Esop id from first filter");
				click(SOP.EQUAL_SECOND_FILTER, "Select equalts from second filter");
				type(SOP.FILTERTEXTFIELD, esopID, "Filter Text Field");
				click(SOP.FILTERGOBTN, "go btn");

				// Click on CES Select btn
				click(SOP.FIRST_CES_SELECT_BUTTON, "first ces select btn");
				Thread.sleep(4000);

				waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
				WebElement traceableMailId = null;
				try {				
					traceableMailId = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
					if(traceableMailId != null) { 
						type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
					}
				}catch(NoSuchElementException e) {}
				//Get Intake Method w.r.t Worksheet Type

				waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
				String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
				if(cdsop.equalsIgnoreCase("CDSOP"))
				{
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

					// enter entity name in Entity Search page and click on Search
					// button
					type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
					click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
					click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
				}
				else {
					type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				}
				
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");

				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

				// Enter log id in log text field
				type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
				click(SOP.SEARCH_BTN, "Search button");
				Thread.sleep(4000);
				// Click on Unrelated worksheet
				click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");

				//PLAINTIFF_TEXT_BOX			
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
				//DEFENDANT_TEXT_BOX				
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN,"Lawsuit Type Dropdown");

				// select Lawsuite Type and click on Submit button
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
				click(SOP.SUBMITBTN, "Submit Button");
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String onHoldList(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// Click on CES link from left nav bar
			click(SOP.CES_LEFT_NAV_LINK, "Ces left nav link");
			assertTextMatching(SOP.PAGE_TITLE, "Centralized Entity Selection", "Page Title");

			// Click on CES Processing Item tab
			click(SOP.CES_PROCESSING_TAB, "Ces Processing Item tab");

			// Click on Next in Queue button
			click(SOP.NEXT_IN_QUEUE_BTN, "Next in Queue Button");

			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");

			WebElement traceableMail = null;
			try {				
				traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type
			
			String esopID = getText(SOP.ESOPID, "esop id");


			//Enter Reason for hold
			type(SOP.REASON_FOR_HOLD_TEXTBOX, "test","Reason for hold text box");
			click(SOP.ONHOLD_BTN,"On Hold Btn");

			// Click on On Hold List tab
			click(SOP.ON_HOLD_LIST_TAB, "On Hold List tab");

			// Search for the log id on hold
			click(SOP.ESOP_ID_FIRST_FILTER, "Select Esop id from first filter");
			click(SOP.EQUAL_SECOND_FILTER, "Select equalts from second filter");
			type(SOP.FILTERTEXTFIELD, esopID, "Filter Text Field");
			click(SOP.FILTERGOBTN, "go btn");

			// Click on CES Select btn
			click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "first ces select btn");
			Thread.sleep(4000);

			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			WebElement traceableMailId = null;
			try {				
				traceableMailId = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMailId != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}
			//Get Intake Method w.r.t Worksheet Type

			waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			if(cdsop.equalsIgnoreCase("CDSOP"))
			{
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

				// enter entity name in Entity Search page and click on Search
				// button
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
				click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All Rep & Assumed Name Jurisdictions Checkbox");
				click(SOP.INCLUDE_STAFFING_ENTITIES_BTN, "Include Staffing Entities Checkbox");
			}
			else {
				type(SOP.ENTITY_NAME_TEXTFIELD, "ct", "Entity Name textfield on Entity Search page");
			}
			
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");

			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			//FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			waitForElementPresent(SOP.CASEID_TEXTBOX, "Case id text box");

			// Enter log id in log text field
			type(SOP.CASEID_TEXTBOX, "1234", "Case id text box");
			click(SOP.SEARCH_BTN, "Search button");
			Thread.sleep(4000);
			// Click on Unrelated worksheet
			click(SOP.UNRELATED_WORKSHEET_BTN, "Unrelated worksheet btn");

			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,"plaintiff", "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,"defendant", "defendant text box");
			waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN,"Lawsuit Type Dropdown");
			// select Lawsuite Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	// Below function is added as part of CES Enhancement REjection workflow

	//this is part of comon fxn file
	/*public String esopEscalatedOrOnHold(String reportSheet, int count) throws Throwable {

		  String esopId = "";
			try {
				String escalated = Excelobject.getCellData(reportSheet, "Escalate", count);
				String onHold = Excelobject.getCellData(reportSheet, "Hold", count);
				String unidentifiedEntity = Excelobject.getCellData(reportSheet, "Unidentified Entity", count);
				String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
				String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
				String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
				String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
				String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
				String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
				String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);

				waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				click(SOP.SOP_LINK_HEADER, "SOP link in header");				
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");

				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);
				//To run Sprint 33 and 34 us we need this to be uncommented
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				//CESSELECTBTN
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				Thread.sleep(2000);
				//CLOSE_THE_ML_SLIDER
				try {
				//waitForElementToBeClickable(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
				click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
				}catch(NoSuchElementException e) {}
				catch(WebDriverException e) {}
				driver.switchTo().frame("frame1");
				Thread.sleep(2000);
				if(!arrowEntity.equals("")) {
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					if (branchPlant.equals("CTCORP")) {
						//CTCORP_RADIO_BUTTON
							assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

						}
						else if (branchPlant.equals("NRAI")) {
							//NRAI_RADIO_BUTTON
							assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	

							}	
					//ENTITY_NAME_TEXTFIELD
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					//(SOP.FILTERTEXTFIELD, filename, "Filter text field");		
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
					//SEARCH_BTN
					waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					assertElementPresent(SOP.SEARCH_BTN, "Search button");
					click(SOP.SEARCH_BTN, "Search button");
					//FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					driver.switchTo().frame("frame1");
					Thread.sleep(2000);

				}
				else if(!unidentifiedEntity.equals("")) {
					//UNIDENTIFIED_ENTITY_RADIO_BUTTON
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
					click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Click on Unidentified entity radio button");	
					if (branchPlant.equals("CTCORP")) {
					//BRANCH_PLANT_UNIDENTIFIED_ENTITY
					waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY,"CTCORP", "Branch Plant drop down");	

				} else if (branchPlant.equals("NRAI")) {
					//Select the drop down for NRAI
					waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY,"NRAI", "Branch Plant drop down");	
					}
					//ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");	
					type(SOP.ENTITY_TEXT_BOX,unidentifiedEntity,"Entity search text box on ESOP");
					//DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");	
					selectByVisibleText(SOP.DOMESTIC_JURISDICTION_SELECTION,"Arizona","Domestic Jurisdiction in CES Page");
					//REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");	
					selectByVisibleText(SOP.REP_JURISDICTION_SELECTION,"Arizona","Rep Jurisdiction in CES Page");				
					}
				//CASE_ID_TEXTBOX
				waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
				type(SOP.CASE_ID_TEXTBOX,caseNumber, "Case Number text box");
				if (branchPlant.equals("CTCORP")) {
					waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
					assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
					selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
				} else if (branchPlant.equals("NRAI")) {
					waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

				}
				//PLAINTIFF_TEXT_BOX
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box");
				//DEFENDANT_TEXT_BOX
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box");

				waitForElementPresent(SOP.ESOPID,"ESOP ID");
				assertElementPresent(SOP.ESOPID,"ESOP ID");
				esopId = getText(SOP.ESOPID,"ESOP ID");

				if(!escalated.equals("")) {
				//ESCALATION_DETAILS
				waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
				//REASON_DRPDWN
				waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");//
				//ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Entity escalated", "Escalation text box");
				//ESCALATE_BTN
				waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				click(SOP.ESCALATE_BTN, "Escalate button");			
				}
				else if(!onHold.equals("")) {
				//REASON_FOR_HOLD_TEXTBOX
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On hold text box in CES Page");
				type(SOP.REASON_FOR_HOLD_TEXTBOX,"On hold for verification", "Reason for On hold text box in CES Page");
				//ONHOLD_BTN
				waitForElementToBeClickable(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
				assertElementPresent(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
				click(SOP.ONHOLD_BTN,"OnHold Button in CES Page");
				}		

			} catch (Exception e) {
			}
			return esopId;
	    }
	 */
	//Below Function is added as part of CES enhancement Rejection Workflow

	//this is part of comon fxn file
	/*public void processEscalatedOrOnHoldESOP(String reportSheet, int count,String esopId) throws Throwable {

		try {
			String checkedArrowEntity = "";
			String caseNumber = "";
			String lawSuitType = "";
			String docType = "";
			String plaintiff = "";
			String defendant = "";
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "New Entity Searched", count);
			String relatedLog = Excelobject.getCellData(reportSheet, "Related Log", count);
			String hold = Excelobject.getCellData(reportSheet, "Hold", count);			
			//CES_LEFT_NAV_LINK
			waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			click(SOP.CES_LEFT_NAV_LINK,"Click on CES Link in SOP List Page");
			if(!hold.equals("")){
			//ON_HOLD_LIST_TAB
			waitForElementToBeClickable(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");
			assertElementPresent(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");
			click(SOP.ON_HOLD_LIST_TAB,"OnHoldList button in CES Page");	
			}
			//FILTERDROPDOWN1
			waitForElementPresent(SOP.FILTERDROPDOWN1,"First Filter in CES Page");
			assertElementPresent(SOP.FILTERDROPDOWN1,"First Filter in CES Page");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"ESOP Id","First Filter in CES Page");
			//FILTERDROPDOWN2
			waitForElementPresent(SOP.FILTERDROPDOWN2,"Second Filter in CES Page");
			assertElementPresent(SOP.FILTERDROPDOWN2,"Second Filter in CES Page");
			selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Second Filter in CES Page");
			//FILTERTEXTFIELD
			assertElementPresent(SOP.FILTERTEXTFIELD,"Text box in CES Page");
			type(SOP.FILTERTEXTFIELD,esopId,"Text box in CES Page");
			//FILTERGOBTN
			assertElementPresent(SOP.FILTERGOBTN,"Go Button in CES Page");
			click(SOP.FILTERGOBTN,"Go Button in CES Page");
			if(hold.equals("")){
			//FIRST_CES_SELECT_BUTTON
			waitForElementToBeClickable(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			click(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			}
			else if(!hold.equals("")){
			waitForElementToBeClickable(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");
			assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");
			click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,"First CES select button in CES Page");			
			}
			Thread.sleep(1000);
			//CLOSE_THE_ML_SLIDER
			try {
			//waitForElementPresent(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
		   }catch(NoSuchElementException e) {}
			catch(WebDriverException e) {}
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if(branchPlant.contains("NRAI")) {

				docType = getText(SOP.SELECTED_DOC_TYPE, "Document Type drop down in CES Page");
			}
			else if (branchPlant.contains("CTCORP")) {
				lawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
			}
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			//TRACEABLE_MAIL_FIELD
			try {
			traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
			if(traceableMail != null) { 
			type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
			}
			}catch(NoSuchElementException e) {}
			plaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
	        defendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
	        caseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			try {
			checkedArrowEntity = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON,"checked");
			}catch(NullPointerException e) {}
			if(checkedArrowEntity == null) {
				assertElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Arrow Entity Radio button");
				click(SOP.ARROW_ENTITY_RADIO_BUTTON,"Click on Arrow Entity Radio button");
			}

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (branchPlant.equals("CTCORP")) {
					//CTCORP_RADIO_BUTTON
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

					}
					else if (branchPlant.equals("NRAI")) {
						//NRAI_RADIO_BUTTON
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	

						}

				//ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				//(SOP.FILTERTEXTFIELD, filename, "Filter text field");		
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");

				//SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
				assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
				click(SOP.SEARCH_BTN, "Search button in CES Page");
				Thread.sleep(2000);
				//UNIDENTIFIED_ENTITY_BTN
				List<WebElement> entityNotFound = null;
				try {
					entityNotFound = driver.findElements(SOP.FIRST_ENTITY_IN_SEARCH_RESULT);
				}catch(NoSuchElementException e) {}
				if(entityNotFound == null) {
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "unidentified Entity button in CES Page");
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "click on unidentified Entity button in CES Page");
					Thread.sleep(2000);

					if(branchPlant.contains("NRAI")) {
						waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
						Thread.sleep(1000);
						String newDocType = getText(SOP.SELECTED_DOC_TYPE,"selected Doc type value");			
						printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
					}
					else if (branchPlant.contains("CTCORP")) {
						waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
						Thread.sleep(1000);
						String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
						printMessageInReport("Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);								
					}
				}
				else if(entityNotFound != null) {
				//REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				//FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT,"First entity link in CES Page");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "click on First entity link in CES Page");
				if(relatedLog.equals("")) {
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(1000);
					driver.switchTo().frame("frame1");
					Thread.sleep(1000);

				}
				else if(!relatedLog.equals("")) {
					//WORKSHEET_ID_TEXTBOX
					waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					type(SOP.WORKSHEET_ID_TEXTBOX,relatedLog,"Worksheet id text box in CES Page");
					//SEARCH_BTN
					assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
					click(SOP.SEARCH_BTN, "Click on Search button in CES Page");
					//FIRST_WORKSHEET_RADIO_BTN
					waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					//ADD_MANIFEST_BTN
					assertElementPresent(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
					click(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
					Thread.sleep(1000);
				}	
			}
				if(branchPlant.contains("NRAI")) {
					waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					Thread.sleep(1000);
					String newDocType = getText(SOP.SELECTED_DOC_TYPE,"selected Doc type value");			
					printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
				}
				else if (branchPlant.contains("CTCORP")) {
					waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
					Thread.sleep(1000);
					String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
					printMessageInReport("Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);								
				}
				String newPlaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
				Thread.sleep(1000);
				String newDefendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
				Thread.sleep(1000);
				String newCaseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
				//SUBMIT_CES
				waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
				assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
				click(SOP.SUBMIT_CES, "Submit button in CES Page");	
				printMessageInReport("Previous plaintiff : " + plaintiff + " and new plaintiff : " + newPlaintiff);
				printMessageInReport("Previous defendant : " + defendant + " and new defendant : " + newDefendant);
				printMessageInReport("Previous case number : " + caseNumber + " and new case Number : " + newCaseNumber);


		}catch (Exception e) {
				e.printStackTrace();
			}

	 }
	 */

	//Below Function is added as part of CES enhancement REjection Workflow
	public String validatePlaintiffAndDefendantFieldsAreMandatory(String reportSheet, int count) throws Throwable {

		String esopId = null;
		try {

			String plaintiffError = Excelobject.getCellData(reportSheet, "Plaintiff Error", count);
			String defendantError = Excelobject.getCellData(reportSheet, "Defendant Error", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");			
			Thread.sleep(1000);
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
			click(SOP.FILTERGOBTN, "Go Button");
			//CESSELECTBTN
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(3000);
			//CLOSE_THE_ML_SLIDER
			/*	try {
			//waitForElementToBeClickable(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			}catch(NoSuchElementException e) {}
			catch(WebDriverException e) {}*/
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			if (branchPlant.equals("CTCORP")) {
				//CTCORP_RADIO_BUTTON
				assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
				click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

			}
			else if (branchPlant.equals("NRAI")) {
				//NRAI_RADIO_BUTTON
				assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
				click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");	

			}	
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
			// SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			// FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			driver.switchTo().defaultContent();
			assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
			click(SOP.GLYPHICON_HOME, "glyphicon button");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			List<WebElement> traceableMail = null;
			//TRACEABLE_MAIL_FIELD
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
				}
			}catch(NoSuchElementException e) {}

			//CASE_ID_TEXTBOX
			waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(SOP.CASE_ID_TEXTBOX,caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}			
			//PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box");
			//DEFENDANT_TEXT_BOX
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box");	

			//SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			click(SOP.SUBMIT_CES, "Click on Submit button in CES Page");
			if(plaintiff.equals("")) {
				waitForElementPresent(SOP.PLAINTIFF_EMPTY_ERROR,"Enter Plaintiff value in CES Page");
				assertElementPresent(SOP.PLAINTIFF_EMPTY_ERROR,"Enter Plaintiff value in CES Page");
				compareStrings(plaintiffError, getText(SOP.PLAINTIFF_EMPTY_ERROR,"Enter Plaintiff value in CES Page"));
			}
			if (defendant.equals("")) {
				//DEFENDANT_EMPTY_ERROR
				waitForElementPresent(SOP.DEFENDANT_EMPTY_ERROR,"Enter Defendant value in CES Page");
				assertElementPresent(SOP.DEFENDANT_EMPTY_ERROR,"Enter Defendant value in CES Page");
				compareStrings(defendantError, getText(SOP.DEFENDANT_EMPTY_ERROR,"Enter Defendant value in CES Page"));
			}

		} catch (Exception e) {
		}
		return esopId.split("\\: ")[1];

	}
	//Below Function is added as part of CES Enhancement REjection workflow changes
	public void rejectionListForPosssibleRejection(String reportSheet, int count) throws Throwable {
		try {
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//CES_LEFT_NAV_LINK
			waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			click(SOP.CES_LEFT_NAV_LINK,"Click on CES Link in SOP List Page");
			Thread.sleep(1500);
			//REJECTION_LIST_TAB
			List<WebElement> rejectionListTab = null;
			try {
				rejectionListTab = driver.findElements(SOP.REJECTION_LIST_TAB);
				if(rejectionListTab != null) {
					click(SOP.REJECTION_LIST_TAB,"Click on REjection List Tab in CES Page");
					//CREATED_ON_SORTING_LINK
					waitForElementPresent(SOP.CREATED_ON_SORTING_LINK,"Created On link in Rejection List Tab");
					assertElementPresent(SOP.CREATED_ON_SORTING_LINK,"Created On link in Rejection List Tab");
					assertElementPresent(SOP.FILE_NAME_SORTING_LINK,"File Name link in Rejection List Tab");
					assertElementPresent(SOP.ESOP_ID_SORTING_LINK,"File Name link in Rejection List Tab");
					assertElementPresent(SOP.ESCALATED_ON_SORTING_LINK,"File Name link in Rejection List Tab");
					assertElementPresent(SOP.FILTERDROPDOWN1,"Filter drop down in Rejection List Tab");
					assertElementPresent(SOP.FILTERTEXTFIELD,"Second Filter drop down in Rejection List Tab");
					assertElementPresent(SOP.FILTERGOBTN,"Go Button in Rejection List Tab");
					assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID,"First link in Rejection List Tab");
					assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID,"Previous link in Rejection List Tab");
					assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID,"Next link in Rejection List Tab");
					assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID,"Last link in Rejection List Tab");
					assertElementPresent(Entity.PSOP_INVOICES_CURRENT_FILTER,"Current Filter label in Rejection List Tab");						
				}
			}catch(NoSuchElementException e) {}
			if(rejectionListTab == null) {

				printMessageInReport("For the Logged in Member there are no permission to Rejection List");
			}
		} 
		catch (Exception e) {
		}		
	}

	//Below function is added as part of CES Enhancement Rejection workflow

	/*public String entitySectionDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
			try {			
				String caseNumber = "";
				int relatedWorksheet = 0;
				String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
				String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
				String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
				String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);				
				String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
				String caseNum2 = Excelobject.getCellData(reportSheet, "New Case Number", count);
				String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
				String rejectionReason = Excelobject.getCellData(reportSheet, "Rejection Reason", count);
				String notRejecting = Excelobject.getCellData(reportSheet, "Reason for Not Rejecting", count);
				String error = Excelobject.getCellData(reportSheet, "Error Message", count);
				String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
				String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
				String reject = Excelobject.getCellData(reportSheet, "Reject", count);
				String onHold = Excelobject.getCellData(reportSheet, "On Hold", count);
				String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
				String courtName = Excelobject.getCellData(reportSheet, "Court", count);
				//String worksheetType = Excelobject.getCellData(reportSheet, "WorkSheet Type", count);

				waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
				click(SOP.SOP_LINK_HEADER, "SOP link in header");
				if(levelOfUser.equals("Level1")) {
					//CES_LEFT_NAV_LINK
					waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
					assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
					click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
		 		    //CES_PRODUCTIVITY_TAB
					waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
					click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
					//UNPROCESSED_COUNT
					waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
					assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
					click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
					Thread.sleep(1000);
					waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					Thread.sleep(2000);
					driver.switchTo().frame("frame1");
					Thread.sleep(3000);
				}

				else if(!levelOfUser.equals("Level1")) {
				if(cesQueue.equals("New")) {
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");
				Thread.sleep(1000);			
				waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
				selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
				waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
				assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");			
				selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"Standard SOP", "Filter second drop down");			
				waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
				assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
				click(SOP.FILTERGOBTN, "Go Button");

				try {		 
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");			
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
					click(SOP.FILTERGOBTN, "Go Button");
					Thread.sleep(1000);	
				}catch(NoSuchElementException e) {}
				Thread.sleep(1000);
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				Thread.sleep(1000);

				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				}
				else if(!cesQueue.equals("New")) {
				//CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");			
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
	 		    //CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				 if(cesQueue.equals("Escalated List")) {			
				  //ESCALATED_LIST_TAB
				  waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				  assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
				  click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");				    
				  //FIRST_CES_SELECT_BUTTON
				  waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				  assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				  click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				 }

				else if(cesQueue.equals("OnHold List")) {			
			    //ON_HOLD_LIST_TAB
			    waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
				//FIRST_ONHOLD_CES_SELECT_BUTTON
				 waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				 assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				 click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
				 //create on filter search for New York SOP Team
			    }

			    else  if(cesQueue.equals("Rejections List")) {			
				 //REJECTION_LIST_TAB
				 waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				 assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
				 click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
				 //REJECTIONS_LIST_FIRST_CES_SELECT
				 waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				 assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
				 click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		
				 }
				}
				Thread.sleep(2000);
				//System.out.println("Reached Here ewjdjkjlkwdlkjw");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				driver.switchTo().frame("frame1");
				System.out.println("Switched to Frame 1");
				Thread.sleep(3000);
				//TRAINGLE_ICON_ARROW_ENTITY			
				//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				//INTAKEMETHODVALUE
				waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
				String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
				if(!arrowEntity.equals("")) {				
					waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
				    String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
					if (arrowEntityCheckedAttribute == null) {			
					        click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				    }
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 

					if(!cdsop.equals("CDSOP")) {											
					 if (branchPlant.equals("CTCORP")) {
						//CTCORP_RADIO_BUTTON
						 	waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

						}
						else if (branchPlant.equals("NRAI")) {
							//NRAI_RADIO_BUTTON
							waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
							}
					}
					//ENTITY_NAME_TEXTFIELD
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
					if(cdsop.equals("CDSOP")) {
						selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
					}
					else if(!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
					}
					//SEARCH_BTN
					waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					assertElementPresent(SOP.SEARCH_BTN, "Search button");
					click(SOP.SEARCH_BTN, "Search button");
					int entitySearchCount = 0;
					//ENTITY_SEARCH_RESULT_COUNT
					waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
					entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				    if(entitySearchCount == 0) {
					//Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {				
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					}catch(NullPointerException e) {}
					if(disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
					Thread.sleep(1500);
					System.out.println("REached here in line 6420");
					try {
					if(disabledUnEntity.equals("true")) {					
					  //SEARCH_AGAIN_BUTTON
					  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
					  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
					  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
					  //CANCEL_BUTTON
					  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
					  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
					  click(SOP.CANCEL_BUTTON, "Cancel Button");
					}}catch(NullPointerException e) {}				
	                 System.out.println("REached here in line 6431");
	                 Thread.sleep(2000);
	                 //below will be a go ahead when the value for unidentified Entity above is selected
	                 String unEntityRadioSelected = "";
	                 try {                	 
	                	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
	                 }catch(NoSuchElementException e) {}
	                 catch(NullPointerException e) {}
	                 Thread.sleep(1000);
	                 try {
	                 if(unEntityRadioSelected == null) {
	                	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
	                 }}catch(NullPointerException e) {}
					//ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
					//DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
					//REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
					try {
					//waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
					//assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
					driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
					Thread.sleep(1500);
					selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
					}catch(NoSuchElementException e) {}
					//DOCUMENT_TYPE_DROPDWN
					try {
					//waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
					//assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				    driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
					selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
					}catch(NoSuchElementException e) {}
					//PLAINTIFF_TEXT_BOX			
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX,"Test Plaintiff", "plaintiff text box");
					//DEFENDANT_TEXT_BOX				
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX,"Test Defendant", "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
					type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
					}
					else if(entitySearchCount != 0) {
					//REP_STATUS_SORT
					waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 //FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					//CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if(action.size()>0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					}
					 catch(NoSuchElementException e) {

				     }
					if(!caseNum1.equals("")){					
					 //CASEID_TEXTBOX
					 waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 if(cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,"19342919","Case number Search text box");
					 }
					 else if(!cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,caseNum1,"Case number Search text box");
					 }
					 //SEARCH_BTN
					 waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					 assertElementPresent(SOP.SEARCH_BTN, "Search button");
					 click(SOP.SEARCH_BTN, "Search button");
					 //TOTAL_RECORDS_RELATED_WORKSHEET				 				 
					 waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results");				 
					 relatedWorksheet = Integer.parseInt(getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results"));
					 Thread.sleep(1000);
					 if(relatedWorksheet == 0) {

						 click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
						 Thread.sleep(2000);
						 //RADIO_PRESENTATION_BUTTON
						 String repChecked = "";
						 try {
							 repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked"); 
						 }catch(NoSuchElementException e) {}
						 if(repChecked == null) {
						 //REP_JURISDICTION_SELECTION
						 waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						 assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						 selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");
						 }
						 Thread.sleep(2000);
						 try {
						 driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);					 
						 selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law suit type in CES Page");
						 }catch(NoSuchElementException e) {}
						 Thread.sleep(2000);					 
						 try {						 
						  driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
						  selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}				
						 Thread.sleep(3000);
						 waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
						 assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
						 type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box in CES Page");

						 waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
						 assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
						 type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box CES Page");	

						 waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
						 assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
						 type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");

					  }
					 else if (relatedWorksheet != 0) {
					 //FIRST_WORKSHEET_RADIO_BTN
					 waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 //ADD_TO_DOCKET_HISTORY_BUTTON
					 waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
					 Thread.sleep(2000);
					 waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
					 caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 
					 if(cdsop.equals("CDSOP")) {
						 compareStrings(caseNumber,"19342919");
					 }

					 else if(!cdsop.equals("CDSOP")) {

						 compareStrings(caseNumber,caseNum1);
					 }				 
					}
				}
					 if(!caseNum2.equals("")){
					 //SELECT_BUTTON_IN_RELATED_LOG
					 waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
					 assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
					 click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
					 //CASEID_TEXTBOX
					 waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
					 if(cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,"19342919", "Case number Search text box");					 
					 }
					 else if(!cdsop.equals("CDSOP")) {
						 type(SOP.CASEID_TEXTBOX,caseNum2, "Case number Search text box");					 
					 }

					 //SEARCH_BTN
					 waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					 assertElementPresent(SOP.SEARCH_BTN, "Search button");
					 click(SOP.SEARCH_BTN, "Search button");
					 //FIRST_WORKSHEET_RADIO_BTN
					 waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					 //ADD_TO_DOCKET_HISTORY_BUTTON
					 waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
					 click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
					 Thread.sleep(2000);
					 waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
					 caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 	
					 if(cdsop.equals("CDSOP")) {
						 compareStrings(caseNumber,"19342919");
					 }
					 else if(!cdsop.equals("CDSOP")) {

						 compareStrings(caseNumber,caseNum2);
					 }
					}


				if(caseNum1.equals("")){
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");		
					//PLAINTIFF_TEXT_BOX			
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
					//DEFENDANT_TEXT_BOX				
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
						}catch(NoSuchElementException e) {}
						//DOCUMENT_TYPE_DROPDWN
						try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}				
				}
			}
		}
			}
				Thread.sleep(3000);
				assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				//Below one check can be applied if attorney and court modification needs to be done - 1476
				if(!attorneyName.equals("")) {			 			
						//RADIO_BUTTON_ATTORNEYNONE					
						String attorneyNoneAttribute = "";

						try {
							attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");   			
				            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
							click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
							//DROP_DOWN_ATTORNEY_SENDER_NAME
							waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"Drop down for Attorney Sender Name");
							assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"DROP down for Attorney Sender Name");
							selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"DROP down for Attorney Sender Name");

							//USE_THIS_ATTORNEY
							waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
							assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
							click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");

							//TEXT_BOX_ATTORNEYNAME
							waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");

							//ATTORNEY_ADDRESS_LINE_ONE
						    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	

							//CITY_NAME
							waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");

							//ATTORNEY_STATE_NAME
							waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");

							//ATTORNEY_ZIP_CODE
							waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");

					   } catch (NoSuchElementException e) {}}

				if(!courtName.equals("")) {					
						try {
							String courtNoneAttribute = "";
							courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
				            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
							click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
							//DROP_DOWN_COURT_NAME
							waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
							assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
							selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");

							//USE_THIS_COURT
							waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
							assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
							click(SOP.USE_THIS_COURT,"Use this court radio button");
							//COURT_NAME_TEXT_BOX
							waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
							assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
							type(SOP.COURT_NAME_TEXT_BOX,courtName,"Court NAme");
							//ADDRESS_LINE_ONE
							waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
							assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
							type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
							//CITY_NAME
							waitForElementPresent(SOP.CITY_NAME,"City Name text box");
							assertElementPresent(SOP.CITY_NAME,"City Name text box");
							type(SOP.CITY_NAME,"Houston","City Name text box");
							//STATE_NAME
							waitForElementPresent(SOP.STATE_NAME,"State Name text box");
							assertElementPresent(SOP.STATE_NAME,"State Name text box");
							type(SOP.STATE_NAME,"TX","State Name text box");
							//ZIP_CODE
							waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
							assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
							type(SOP.ZIP_CODE,"77550","Zip code text box");

					   } catch (NoSuchElementException e) {}
						if(attorneyNoneAttribute == null) {						
							//TEXT_BOX_ATTORNEYNAME
							waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
							assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
							type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"text field for Attorney Sender Name");	
						}
						if(courtNoneAttribute == null) {						
							//TEXT_BOX_COURTNAME
							waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
							assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
							type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");	

						}																
				}			 

				//Below one code is to escalate as Possible REjection
				if(!escalationReason.equals("")) {
					//Below one condition needs to be set if the L2 user processing CES from Escalated List
					//then update to possible rejection click can be done from here.		
					if((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List")) && escalationReason.equals("Update to Possible Rejection")) {
					//UPDATE_TO_POSSIBLE_REJECTION
					 waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					 assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					 click(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");

					}
					 if(cesQueue.equals("Escalated List") && escalationReason.equals("Update to Possible Rejection & GetNext")) {
					//UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");	
					Thread.sleep(5000);
					 }				
					 if(!escalationReason.equals("Update to Possible Rejection") && !escalationReason.equals("Update to Possible Rejection & GetNext")){								
					//ESCALATION_DETAILS
					waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
					//REASON_DRPDWN
					waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");
					//ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Could be a Possible Rejection", "Escalation text box");
					//ESCALATE_BTN
					waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					click(SOP.ESCALATE_BTN, "Escalate button");
					}	
				}
				else if(rejectionReason.equals("") && reject.equals("Y")) {
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");	
					//REJECT_REASON_EMPTY_ERROR
					waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
					assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
					String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
					compareStrings(error,errorMessage);

				}
				else if(!rejectionReason.equals("") && !reject.equals("")) {
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					if(!notRejecting.equals("")) {
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reason for not Rejecting drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");								
					//ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
					else if(notRejecting.equals("")) {
					if(attorneyName.equals("")) {
					//ATTORNEY_SENDER_NONE_SPECIFIED
					waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					//commenting below as List of WebElemets not required
					//List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {				
					traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
					if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
					}
					}catch(NoSuchElementException e) {}
				    //HARD_COPY_DELIVERY
					waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
					String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);												
					if(hardCopy.equals("No") && error.equals("")) {		
						String parentWin= driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow();
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1]).get(0);		
						assertTextContains(letterPopup,rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}				
					//ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if(attorneyName.equals("")) {
					waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
					assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
					String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
					compareStrings(error,errorMessage);
					}
				}
			}			
	            else if(escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
	            	if  (!rejectionReason.equals("")){
	    			waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
	    			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
	    			selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
	    			//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {				
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
					}
					}catch(NoSuchElementException e) {}
					//SUBMIT_CES				
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
					//SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
	            	}
	            	else if  (rejectionReason.equals("")){
	    			List<WebElement> traceableMail = null;
	    			//TRACEABLE_MAIL_FIELD
	    			try {
	    			traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
	    			if(traceableMail != null) { 

	    				type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
	    			 }
	    			}catch(NoSuchElementException e) {}	

	    			 Below Code is addded on 1/21 as part of GCNBO-1740
	    			  To handle the onhold submit scenario when the
	    			  Escalation Reason for the esop is Possible Rejection    			  

	    			if(cesQueue.equals("OnHold List")) {
	    			//ESCALATION_DETAILS
	    			waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
	    			assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
	    			click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");	
	    			//ESCALATION_REASON
	    			waitForElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
	    			assertElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
	    			String escalationReasonInOnHold = getText(SOP.ESCALATION_REASON, "Escalation Reason");	

	    			if(escalationReasonInOnHold.equals("Possible Rejection")) {
	    				waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
	    				assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
	    				selectByIndex(SOP.REASON_FOR_NOT_REJECTING,1,"Reject Reason drop down");
	    				Thread.sleep(2000);	

	    			}
	    			}    			    			
	    			 Till here the code change made as on 1/21 






	    			//REASON_FOR_NOT_REJECTING
	    			if(cesQueue.equals("Rejections List")) {
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
	    			}
	    			//SUBMIT_CES
	    			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
	    			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
	    			click(SOP.SUBMIT_CES, "Submit button in CES Page");	
	            	}
	            }
	            else if(!onHold.equals("")) {
	            	//REASON_FOR_HOLD_TEXTBOX
	            	waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
	    			assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
	    			type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
	    			//ONHOLD_BTN
	    			waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
	    			assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
	    			click(SOP.ONHOLD_BTN, "On Hold button");
	            }

		}catch(Exception e) {}
		return esopId.split("\\: ")[1];	
	  }
	 */
	//Below function is for uploading SOPs to scanner path
	public ArrayList<String> uploadTheFilesToScannerRBCPath(int totalRows, String hardCopy , String environment) throws Throwable{
		String NasScanFirstPath = "";

		if(environment.equals("Stage")){

			NasScanFirstPath = NasScanFirstPathStg;

		}		
		else if(environment.equals("QA")){

			NasScanFirstPath = NasScanFirstPathQA;
		}

		ArrayList<String> fileNames = new ArrayList<String>();
		String fileName = "Test"+getCurrentDate().split("\\/")[0] + getCurrentDate().split("\\/")[1];
		String currentFileName = null;
		String fileNameWithHardCopy = "";
		String desktopPath = System.getProperty("user.home") + "//Desktop";
		copyTheFile(TestFileXMLToUploadScanRBCOld, desktopPath, PowerShellToCopy);
		copyTheFile(TestFilePDFToUploadScanRBCOld, desktopPath, PowerShellToCopy);
		if(hardCopy.equals("Yes")) {
			fileNameWithHardCopy = fileName + "HCY";
			renameTheFiles(desktopPath + "\\SOPTest.XML", fileNameWithHardCopy + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\SOPTest.PDF", fileNameWithHardCopy +".PDF", PowerShellToRename);
		}
		else if(hardCopy.equals("No")) {
			fileNameWithHardCopy = fileName + "HCN";
			renameTheFiles(desktopPath + "\\SOPTest.XML", fileNameWithHardCopy + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\SOPTest.PDF", fileNameWithHardCopy +".PDF", PowerShellToRename);
		}
		//updateTheXML(desktopPath + "\\" + fileName + ".XML", getCurrentDate(), PowerShellToUpdate);
		updateTheXML(desktopPath + "\\" + fileNameWithHardCopy + ".XML", getCurrentDate(), hardCopy, PowerShellToUpdate);
		//in above updateTheXML function needs to pass arg for Hard copy Yes or No
		int j = 0;

		for (int iLoop = 1; iLoop <totalRows; iLoop++) {
			if(j == 1){
				j++;
			}
			if (j == 0) {
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + ".XML", NasScanFirstPath, PowerShellToCopy);				
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + ".PDF", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(15000);
				currentFileName = fileName + ".PDF";
				fileNames.add(currentFileName);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + ".XML", fileNameWithHardCopy + ++j + ".XML",
						PowerShellToRename);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + ".PDF", fileNameWithHardCopy + j + ".PDF",
						PowerShellToRename);						
			}
			else if (j > 1) {
				int i = j - 1;
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + i + ".XML", NasScanFirstPath, PowerShellToCopy);					
				Thread.sleep(10000);
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + i + ".PDF", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(10000);
				currentFileName = fileName + i + ".PDF";
				fileNames.add(currentFileName);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + i + ".XML", fileNameWithHardCopy + j + ".XML",PowerShellToRename);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + i + ".PDF", fileNameWithHardCopy + j + ".PDF",PowerShellToRename);
				j++;

			}
		}

		if(j == 1) {
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".PDF",PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".XML",PowerShellToDelete);
		}
		else {
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + --j + ".PDF",PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".XML",PowerShellToDelete);
		}
		Thread.sleep(140000);
		return fileNames;

	}

	public void copyTheFile(String fileSourcePath , String fileDestinationPath ,String powershellFilePath){
		String command = "powershell.exe -file "+ powershellFilePath + " " + fileSourcePath + " " + fileDestinationPath;			
		getTheCommandToRunThePowerShell(command);
	}
	public void getTheCommandToRunThePowerShell(String command){
		try{
			Process powerShellProcess = Runtime.getRuntime().exec(command);
			powerShellProcess.getOutputStream().close();
			String line;      
			BufferedReader stdout = new BufferedReader(new InputStreamReader(
					powerShellProcess.getInputStream()));
			while ((line = stdout.readLine()) != null) {
				System.out.println(line);
			}
			stdout.close();        
			BufferedReader stderr = new BufferedReader(new InputStreamReader(
					powerShellProcess.getErrorStream()));
			while ((line = stderr.readLine()) != null) {
				System.out.println(line);
			}
			stderr.close();
			System.out.println("Done");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void renameTheFiles(String fileSourcePath , String fileRename, String powershellFilePath){
		String command = "powershell.exe -file " +  powershellFilePath + " " + fileSourcePath + " " + fileRename;
		getTheCommandToRunThePowerShell(command);	
	}

	public void updateTheXML(String fileSourcePath , String date, String hardCopy, String powershellFilePath){

		String command = "powershell.exe -file "+ powershellFilePath + " "+ fileSourcePath +" " + date + " " + hardCopy;
		getTheCommandToRunThePowerShell(command);

	}
	public void deleteTheFile(String fileSourcePath ,String powershellFilePath){
		String command = "powershell.exe -file "+ powershellFilePath + " " + fileSourcePath;			
		getTheCommandToRunThePowerShell(command);
	}

	public void compareTheCurrentStatus(String reportSheet, int count, String esopId) throws Throwable {
		String currentStatus = "";
		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		for(int i=0 ;i<10; i++) {			
		String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
		if(isHandlerProcessed.equals("N")) {
		Thread.sleep(10000);
		}
		else {
			break;
		}		
		}
		ArrayList<String> statusCode = new ArrayList<String>();
		try {
			//Added a double chek on status read from DB
			//Thread.sleep(10000);
			statusCode = SQL_Queries.getTheCurrentStatusCode(esopId);
			Thread.sleep(5000);
			statusCode = SQL_Queries.getTheCurrentStatusCode(esopId);
			currentStatus = statusCode.get(0);			
			compareStrings(currentStatus,status);
		} catch (IndexOutOfBoundsException e) {

		}		
	}

	public void cesProductivityGrandTotalAndTier3() throws Throwable {

		try {

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");			
			//CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
			//CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
			//CES_PRODUCTIVITY_TITLE
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title");	
			compareStrings("CES Productivity",getText(SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title"));
			//TIER3_HEADER
			waitForElementPresent(SOP.TIER3_HEADER, "CES Productivity Tier 3");
			assertElementPresent(SOP.TIER3_HEADER, "CES Productivity Tier 3");	
			compareStrings("Tier 3",getText(SOP.TIER3_HEADER, "CES Productivity Tier 3"));
			//GRAND_TOTALS_LABEL
			waitForElementPresent(SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals");
			assertElementPresent(SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals");	
			compareStrings("Grand Totals",getText(SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals"));
			//TOTAL_COUNT_GRAND_TOTALS
			waitForElementPresent(SOP.TOTAL_COUNT_GRAND_TOTALS, "CES Productivity Total count");
			assertElementPresent(SOP.TOTAL_COUNT_GRAND_TOTALS, "CES Productivity Total Count");			
		}catch (Exception e) {

		}	
	}


	// Below function is added as part of CES enhancement Rejection changes
	//This is also moved to common fxn file

	/*public String viewAndCreateTheWorkSheetUsingESOPId(String reportSheet, int count,String esopId) throws Throwable{

	String worksheetId = null;
	try{				
	String defendentName = Excelobject.getCellData(reportSheet, "WS Defendent Name", count);
	String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
	String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);
	String attorney = Excelobject.getCellData(reportSheet, "WS Attorney", count);
	String court = Excelobject.getCellData(reportSheet, "WS Court", count);
	String documentServed = Excelobject.getCellData(reportSheet, "Document Served", count);
	String caseNum = Excelobject.getCellData(reportSheet, "WS Case Number", count);
	String plaintiff = Excelobject.getCellData(reportSheet, "WS Plaintiff", count);

	waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
	assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
	click(SOP.SOP_LINK_HEADER, "SOP link in header");
	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
	assertElementPresent(SOP.CLEARBTN, "Clear Button");
	click(SOP.CLEARBTN, "Clear Button");
    searchForESOP(esopId);		
	try {		 
		WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
		waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
	    searchForESOP(esopId);			

	}catch(NoSuchElementException e) {}
	Thread.sleep(5000);
	selectAndAssignTheFileToTeam();
	Thread.sleep(5000);
	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
	assertElementPresent(SOP.CLEARBTN, "Clear Button");
	click(SOP.CLEARBTN, "Clear Button");
	searchForESOP(esopId);
	Thread.sleep(2000);
	String parentWindow= driver.getWindowHandle();		
	waitForElementPresent(SOP.VIEW_BTN, "View button");
	assertElementPresent(SOP.VIEW_BTN, "View button");		
	click(SOP.VIEW_BTN, "View button");		
	handlePopUpWindwow();
	driver.close();
	driver.switchTo().window(parentWindow);
	Thread.sleep(3000);
	WebElement createWs = null;
	try {
	createWs = driver.findElement(SOP.CREATE_WORKSHEET);
	waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	}catch(NoSuchElementException e) {			
	}
	if(createWs == null) {
		Thread.sleep(4000);
		selectAndAssignTheFileToTeam();
		Thread.sleep(4000);
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOP(esopId);
		Thread.sleep(2000);
		String parentWin= driver.getWindowHandle();		
		waitForElementPresent(SOP.VIEW_BTN, "View button");
		assertElementPresent(SOP.VIEW_BTN, "View button");		
		click(SOP.VIEW_BTN, "View button");		
		handlePopUpWindwow();
		driver.close();
		driver.switchTo().window(parentWin);
		waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	}

	Thread.sleep(2000);
	WebElement initalRadioButton = null;
	try {			

		initalRadioButton = driver.findElement(SOP.INITIAL_RADIOBTN);	

	}catch(NoSuchElementException e) {}
	if(initalRadioButton == null) {
		 click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
	}
	if(isAttempted.equalsIgnoreCase("Yes")){
		//ATTEMPTED_YES_RADIO_BUTTON
		waitForElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
		assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");	
		click(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
	}
	//INITIAL_RADIOBTN
	waitForElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");
	assertElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");	
	click(SOP.INITIAL_RADIOBTN,"Initial Radio button");
	if(!caseNum.equals("")) {
	//CASEID_TEXTBOX
	waitForElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");
	assertElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");	
	type(SOP.CASEID_TEXTBOX,caseNum,"Case Id text box");
	}
	if (!plaintiff.equals("")) {
	//PLAINTIFF_TEXT_BOX
	waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plaintiff text box");
	assertElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plantiff text box");	
	type(SOP.PLAINTIFF_TEXT_BOX,plaintiff,"Plantiff text box");
	}
	if(!defendentName.equals("")) {
	//DEFENDANT_TEXTFIELD
	waitForElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");	
	assertElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
	type(SOP.DEFENDANT_TEXTFIELD,defendentName,"Defendent text box");
	}
		//REJECT_REASON
	if(!rejectedReason.equals("")){
	assertElementPresent(WorksheetCreate.REJECTED_REASON,"Rejected Reason wroksheet step 1 page");
	selectByVisibleText(WorksheetCreate.REJECTED_REASON,rejectedReason,"Rejected Reason wroksheet step 1 page");
	assertElementPresent(SOP.DATE_CALENDAR, "Calendar Icon");
	click(SOP.DATE_CALENDAR, "Calendar Icon");
	click(Entity.TODAYSDATE, "Todays Date");
	assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");	
	click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
	Thread.sleep(1000);
	//COURT
	//below will be used to edit the court which will validate the story 1283
	assertElementPresent(WorksheetCreate.COURT,"Court in wroksheet step 2 page");		
	selectByVisibleText(WorksheetCreate.COURT,court,"Court in wroksheet step 2 page");
	}
	//else if(rejectedReason.equals("")){
	//For Certified mail below one check need to be added
	//POST_MARKED_DATE
	try {
	driver .findElement(WorksheetCreate.METHOD_OF_SERVICE);	
	String methodOfService = getText(WorksheetCreate.METHOD_OF_SERVICE,"Method of Service");
	if(methodOfService.contains("Mail") && !methodOfService.equals("Express Mail")){
		waitForElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
		assertElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post marked Date text box");
		int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
		String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
				+ String.valueOf(lastYear); 			
		type(WorksheetCreate.POST_MARKED_DATE,lastYearDate,"Post marked Date text box");
	}}catch(NoSuchElementException e) {}
	//EDIT_RECEIVED_BY
	selectByIndex(WorksheetCreate.EDIT_RECEIVED_BY,1,"Received By drop downs in wroksheet step 1 page");
	//WORKSHEET_TYPE
	waitForElementPresent(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in wroksheet step 1 page");
	String worksheetType = getText(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in wroksheet step 1 page");
	//ENTITY_IN_WORKSHEET_PROFILE
	waitForElementPresent(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"Entity in wroksheet profile step 1 page");
	String entityInWorksheet = getAttribute(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"value");
	//NEXT_BTN		
	waitForElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
	assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");	
	click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
	Thread.sleep(1200);
	//below check for if error- > 'Enter a value for Other Mehod of Serivce.		
	try {

		driver.findElement(SOP.OTHER_METHOD_OF_SERVICE);
		type(SOP.OTHER_METHOD_OF_SERVICE_TEXT_BOX,"Other", "Type the Text for other Method of Service");
		click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");	
		Thread.sleep(700);
	}catch (NoSuchElementException e) {}
	//below check for if Error -> Enter a valid value for Case#.
	try {

		driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
		type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for other Method of Service");
		click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
		Thread.sleep(700);
	}catch (NoSuchElementException e) {}

	//below check for if Error -> Enter a valid value for Case#.
			try {
				//Below code is modified on 12/23 
				driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
				Thread.sleep(1000);
				boolean caseTextPsNum = false;
				//Below try block is added as some method of srvice has different way of SElecting the CASe# in worksheet page 1
				try {				
					driver.findElement(SOP.CASE_TEXT_PS_CASENUM);
					Thread.sleep(500);
					type(SOP.CASE_TEXT_PS_CASENUM,"CNInWorksheet", "Type the Text for other Method of Service");
					click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
					caseTextPsNum = true;
				}catch(NoSuchElementException e) {}
				if(caseTextPsNum == false) {
				type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for other Method of Service");
				click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
				Thread.sleep(700);
				}
			}catch (NoSuchElementException e) {}


	//This try block is added on 12/23
			try {
				driver.findElement(SOP.CASE_NUMBER_BLANK);
				Thread.sleep(800);
				type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for other Method of Service");
				click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
				Thread.sleep(700);
			}catch (NoSuchElementException e) {}


	//COURT_NAME_TEXT_BOX
	String attorneyNoneAttribute = "";
	String courtNameInWorksheet = "";

	try {
		attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");  
	}catch (NoSuchElementException e) {}
	try {	
		driver.findElement(SOP.EXISTING_COURTNAME);
		courtNameInWorksheet = getText(SOP.TEXT_BOX_COURTNAME,"value");
	}catch (NoSuchElementException e) {} 
	try {
		driver.findElement(SOP.COURT_NAME_TEXT_BOX);
		courtNameInWorksheet = getAttribute(SOP.COURT_NAME_TEXT_BOX,"value");
	}catch (NoSuchElementException e) {}
		if (courtNameInWorksheet.equals("")) {
			courtNameInWorksheet = null;				
		}			
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);		
		compareStrings(courtNameInWorksheet,courtNameInCES);
	//TEXT_BOX_ATTORNEYNAME
	if(attorneyNoneAttribute == null) {
	waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in wroksheet step 2 page");
	assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in wroksheet step 2 page");	
	String attorneyNameInWorksheet = getAttribute(SOP.TEXT_BOX_ATTORNEYNAME,"value");
	if(attorneyNameInWorksheet.equals("")) {
		attorneyNameInWorksheet = null;
	}		
	String attorneyNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(0);
	compareStrings(attorneyNameInWorksheet,attorneyNameInCES);
	}
	if(courtNameInWorksheet == null) {
	waitForElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in wroksheet step 2 page");
	assertElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in wroksheet step 2 page");
	click(SOP.COURT_NONE_RADIOBTN,"court none radio button in wroksheet step 2 page");
	}
	if(!court.equals("")) {
		//RADIO_BUTTON_EXISTING_COURT
		waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,"existing court radio button in wroksheet step 2 page");
		assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,"existing court radio button in wroksheet step 2 page");
		click(SOP.RADIO_BUTTON_EXISTING_COURT,"existing court radio button in wroksheet step 2 page");
		//DROP_DOWN_COURT_NAME
		assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"existing court drop down in wroksheet step 2 page");
		selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"existing court drop down in wroksheet step 2 page");
		Thread.sleep(1000);
	}
	if(!attorney.equals("")) {

		//USE_THIS_ATTORNEY
		waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
		assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
		click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");

		//TEXT_BOX_ATTORNEYNAME
		waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
		assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
		type(SOP.TEXT_BOX_ATTORNEYNAME,attorney,"Text box to enter attorney name");

		//ADDRESS_NONE_SPECIFIED
		 waitForElementPresent(WorksheetCreate.ADDRESS_NONE_SPECIFIED,"None specified radio button in Address");
		 assertElementPresent(WorksheetCreate.ADDRESS_NONE_SPECIFIED,"None specified radio button in Address");
		 click(WorksheetCreate.ADDRESS_NONE_SPECIFIED,"None specified radio button in Address");

		//RADIO_BUTTON_EXISTING_ATTORNEYSENDER
		waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,"existing Attorney radio button in wroksheet step 2 page");
		assertElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,"existing Attorney radio button in wroksheet step 2 page");
		click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,"existing Attorney radio button in wroksheet step 2 page");
		//DROP_DOWN_ATTORNEY_SENDER_NAME
		assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"existing Attorney drop down in wroksheet step 2 page");
		selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"existing Attorney drop down in wroksheet step 2 page");
	}
	waitForElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 2 page");
	assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 2 page");	
	click(SOP.NEXT_BTN,"next button in wroksheet step 2 page");

	 WebElement docServed = null;
		try {
				docServed = driver.findElement(SOP.DOCUMENT_SERVED);					
				if (docServed != null) {
					click(SOP.FIRST_DOCUMENT_SERVED,"document Type drop down  in wroksheet step 3 page");
					Thread.sleep(2000);
					//DOCUMENT_SERVED_MOVE_RIGHT
					assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
				    click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
				    Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
			}
	if(!lawSuitSubtype.equals("")){
		//LAWSUITE_SUBTYPE
		assertElementPresent(WorksheetCreate.LAWSUITE_SUBTYPE,"law suit sub type in wroksheet step 3 page");
		selectByVisibleText(WorksheetCreate.LAWSUITE_SUBTYPE,lawSuitSubtype,"law suit sub type in wroksheet step 3 page");
	} 

	WebElement specialCircumStances = null;
	try {
		specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);					
			if (specialCircumStances != null) {
					selectByIndex(WorksheetCreate.SPECIAL_CIRCUMSTANCES,1," Special Cicumstances drop down  in wroksheet step 3 page");
				    Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
		}						
	else if(branchPlant.equals("NRAI")) {
		selectByVisibleText(SOP.DOCUMENT_SERVED,documentServed,"document Type drop down  in wroksheet step 3 page");
		//DOCUMENT_SERVED_MOVE_RIGHT
		assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
		click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
	}
	//ANSWER_DATE_NONE
	waitForElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in wroksheet step 3 page");
	assertElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in wroksheet step 3 page");	
	click(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in wroksheet step 3 page");
	if(saveIncomplete.equalsIgnoreCase("Yes")){
		//SAVE_INCOMPLETE_BUTTON
		waitForElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in wroksheet step 3 page");
		assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in wroksheet step 3 page");	
		click(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in wroksheet step 3 page");
	}
	//SAVE_BTN
	else if(saveIncomplete.equalsIgnoreCase("No")){		
	waitForElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	assertElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	click(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	Thread.sleep(2000);
	//DOCUMENT_TYPE_DROPDWN
	//here one check for if doc type is not selected	
	//Enter a value for Document Type.
try {
 WebElement docNotSelected = null;	
 docNotSelected = driver.findElement(WorksheetCreate.DOCUMENT_TYPE_NOT_SELECTED);
 if(docNotSelected != null) {	
	 selectByIndex(SOP.DOCUMENT_TYPE_DROPDWN,3,"document Type drop down  in wroksheet step 3 page");
	 waitForElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	 assertElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
	 click(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
 }
}
 catch (NoSuchElementException e) {}
	}
	//WORKSHEET_ID_ON_CONTEXT_BAR
	waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
	assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");	
	//click(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
	worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
	if(worksheetId.equals(null)){
		throw new NullPointerException();
	}
	}catch(NullPointerException e){
		e.printStackTrace();
	}
	System.out.println("Worksheet id : " + worksheetId);
	Thread.sleep(3000);
	return worksheetId.split("\\: ")[1];
}

	 */

	//This is also moved to common fxn file
	/*public void searchForESOP(String esopId) throws Throwable {

	waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
	assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
	selectByVisibleText(SOP.FILTERDROPDOWN1,"ESOP Id","Filter drop down");
	waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
	assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
	selectByVisibleText(SOP.FILTERDROPDOWN2,"=","Filter drop down2");
	waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
	assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
	selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
	assertElementPresent(SOP.FILTERGOBTN, "Go Button");		
	click(SOP.FILTERGOBTN, "Go Button");
 }
	 */

	//This is also moved to common fxn file
	/*public void selectAndAssignTheFileToTeam() throws Throwable{
	waitForElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
	assertElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");		
	click(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
	waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
	assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
	click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
	waitForElementPresent(SOP.ASSIGN_BTN, "Assign button");
	assertElementPresent(SOP.ASSIGN_BTN, "Assign button");
	click(SOP.ASSIGN_BTN, "Assign button");
	Thread.sleep(1000);
	waitForElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
	assertElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
	click(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
	Thread.sleep(1000);
}
	 */

	public void helpPageInCESQueue(String reportSheet , int count) throws Throwable{

		try {			

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);				
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");	
			//CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
			if(cesQueue.equals("New")) {
				//UNPROCESSED_COUNT
				waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");

			}
			else if(cesQueue.equals("Escalated List")) {			
				//ESCALATED_LIST_TAB
				waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
				click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");				    
				//FIRST_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			}

			else if(cesQueue.equals("OnHold List")) {			
				//ON_HOLD_LIST_TAB
				waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
				//FIRST_ONHOLD_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
				click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
				//create on filter search for New York SOP Team
			}

			else  if(cesQueue.equals("Rejections List")) {			
				//REJECTION_LIST_TAB
				waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
				click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
				//REJECTIONS_LIST_FIRST_CES_SELECT
				waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
				click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		

			}
			//HELP_PAGE_ICON
			waitForElementPresent(SOP.HELP_PAGE_ICON,"Help Page icon");
			assertElementPresent(SOP.HELP_PAGE_ICON,"Help Page icon");
			click(SOP.HELP_PAGE_ICON,"Help Page icon");
			Thread.sleep(2000);	
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			//TITLE_CES_HELP_PAGE
			waitForElementPresent(SOP.TITLE_CES_HELP_PAGE,"Help Page Title");
			assertElementPresent(SOP.TITLE_CES_HELP_PAGE,"Help Page Title");
			String helpPageTitle = getText(SOP.TITLE_CES_HELP_PAGE,"Help Page Title");
			compareStrings("Centralized Entity Selection - CES Processing Item tab",helpPageTitle);
			driver.close();
			driver.switchTo().window(parentWindow);			
		}catch(Exception e) {}		
	}

	public void rejectedLogFieldValidation(String esopId) throws Throwable{

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//WOKSHEET_SEARCH_LEFT_NAV_LINK
		waitForElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "worksheet search link in left nav");
		assertElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "assert worksheet search link in left nav");
		click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "click on worksheet search link in left nav");
		//CLASSIC_SEARCH_BTN
		waitForElementPresent(SOP.CLASSIC_SEARCH_BTN, "Classic search button in Worksheet Search Criteria Page");
		assertElementPresent(SOP.CLASSIC_SEARCH_BTN, "assert Classic search button in Worksheet Search Criteria Page");
		click(SOP.CLASSIC_SEARCH_BTN, "click on Classic search button in Worksheet Search Criteria Page");
		String worskheetId = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
		//WORKSHEET_ID_TEXTBOX
		waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Id text box in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "assert Id text box in Classic Worksheet Search Criteria Page");
		type(SOP.WORKSHEET_ID_TEXTBOX,worskheetId, "type Id in text box in Classic Worksheet Search Criteria Page");
		//WORKSHEET_SEARCH_BTN
		waitForElementPresent(SOP.WORKSHEET_SEARCH_BTN, "Search button in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_SEARCH_BTN, "assert Search button in Classic Worksheet Search Criteria Page");
		click(SOP.WORKSHEET_SEARCH_BTN, "click Search button in Classic Worksheet Search Criteria Page");
		//BAD_LOG
		assertElementPresent(SearchWorksheet.BAD_LOG, "Bad log in Worksheet Profile Page");
		String isBadLog = getText(SearchWorksheet.BAD_LOG, "Bad log in Worksheet Profile Page");
		compareStrings(isBadLog,"No");
		//WORKSHEET_TYPE
		assertElementPresent(SearchWorksheet.WORKSHEET_TYPE, "Worksheet Type in Worksheet Profile Page");
		String worksheetType = getText(SearchWorksheet.WORKSHEET_TYPE, "Worksheet Type in Worksheet Profile Page");
		compareStrings(worksheetType,"Standard SOP");

		//this is commented as per the ciox changes below commented fields will be hidden for Standard SOP
		//CONFIRMATION_NUMBER
		/*	assertElementPresent(SearchWorksheet.CONFIRMATION_NUMBER, "Confirmation Number in Worksheet Profile Page");
	String confNum = getText(SearchWorksheet.CONFIRMATION_NUMBER, "Confirmation Number in Worksheet Profile Page");
	compareStrings(confNum,"--");
	//CUSTOMER
	assertElementPresent(SearchWorksheet.CUSTOMER, "Customer in Worksheet Profile Page");
	String customer = getText(SearchWorksheet.CUSTOMER, "Customer in Worksheet Profile Page");
	compareStrings(customer,"--");
	//INDIVIDUAL
	assertElementPresent(SearchWorksheet.INDIVIDUAL, "Individual in Worksheet Profile Page");
	String individual = getText(SearchWorksheet.INDIVIDUAL, "Individual in Worksheet Profile Page");
	compareStrings(individual,"--");*/
		//REJECTION_APPROVED
		assertElementPresent(SearchWorksheet.REJECTION_APPROVED, "Rejection Approved in Worksheet Profile Page");
		String rejectionApproved = getText(SearchWorksheet.REJECTION_APPROVED, "Rejection Approved in Worksheet Profile Page");
		compareStrings(rejectionApproved,"Yes");
		//ATTEMPTED
		assertElementPresent(SearchWorksheet.ATTEMPTED, "ATTEMPTED in Worksheet Profile Page");
		String attempted = getText(SearchWorksheet.ATTEMPTED, "ATTEMPTED in Worksheet Profile Page");
		compareStrings(attempted,"No");
		//INITIAL_SUBSEQUENT
		assertElementPresent(SearchWorksheet.INITIAL_SUBSEQUENT, "Initial/Subsequent in Worksheet Profile Page");
		String intialSubsequent = getText(SearchWorksheet.INITIAL_SUBSEQUENT, "Initial/Subsequent in Worksheet Profile Page");
		compareStrings(intialSubsequent,"Initial");
		//CONSOLIDATED
		assertElementPresent(SearchWorksheet.CONSOLIDATED, "Consolidated in Worksheet Profile Page");
		String consolidated = getText(SearchWorksheet.CONSOLIDATED, "Consolidated in Worksheet Profile Page");
		compareStrings(consolidated,"No");
		//MULTIPLE
		/*	assertElementPresent(SearchWorksheet.MULTIPLE, "MULTIPLE in Worksheet Profile Page");
	String multiple = getText(SearchWorksheet.MULTIPLE, "MULTIPLE in Worksheet Profile Page");
	compareStrings(multiple,"No");*/
		//LETTER
		assertElementPresent(SearchWorksheet.LETTER, "Letter in Worksheet Profile Page");
		String letter = getText(SearchWorksheet.LETTER, "Letter in Worksheet Profile Page");
		compareStrings(letter,"No");
		//POST_STATUS
		assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus,"UnPosted");
		ArrayList<String> cesFields = SQL_Queries.getTheFieldsForTheESOPs(esopId);
		for(int i = 0 ; i< cesFields.size() ; i++) {
			if(cesFields.get(i) == null) {
				cesFields.set(i, "--");
			}
		}
		//DEFENDANT_NAME		
		assertElementPresent(SearchWorksheet.DEFENDANT_NAME, "Defendant in Worksheet Profile Page");
		String defendant = getText(SearchWorksheet.DEFENDANT_NAME, "Defendant in Worksheet Profile Page");
		compareStrings(defendant,cesFields.get(2));
		//AGENCY_TITLE
		assertElementPresent(SearchWorksheet.AGENCY_TITLE, "Agency in Worksheet Profile Page");
		String agencyTitle = getText(SearchWorksheet.AGENCY_TITLE, "Agency in Worksheet Profile Page");
		compareStrings(agencyTitle,"None Specified");
		//CASE_NUMBER
		assertElementPresent(SearchWorksheet.CASE_NUMBER, "case number in Worksheet Profile Page");
		String caseNumber = getText(SearchWorksheet.CASE_NUMBER, "case number in Worksheet Profile Page");
		compareStrings(caseNumber,cesFields.get(0));
		//PLAINTIFF
		assertElementPresent(SearchWorksheet.PLAINTIFF, "Plaintiff in Worksheet Profile Page");
		String plaintiff = getText(SearchWorksheet.PLAINTIFF, "Plaintiff in Worksheet Profile Page");
		compareStrings(plaintiff,cesFields.get(1));


	}

	//This is also moved to common fxn file
	/*public String rejectESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

	String esopId = "";			
	try {

		String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
		String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
		String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
		String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
		String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
		String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
		String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
		String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
		String courtName = Excelobject.getCellData(reportSheet, "Court", count);

		if(!cesQueue.equals("New")) {			
				moveESOPFromNewQueueToDiffCESQueue(reportSheet,count);
		 }

		esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], cesQueuCode).get(0);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");			    
		if(cesQueue.equals("New")) {
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");		
		searchForESOP(esopId);		
		try {		 
		WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
		waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOP(esopId);			
		}catch(NoSuchElementException e) {}

		Thread.sleep(1000);			
		waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		}
		else if(!cesQueue.equals("New")) {			

			//CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");			
			click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
 		    //CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

			 if(cesQueue.equals("Escalated List")) {			
			  //ESCALATED_LIST_TAB
			  waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
			  assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
			  click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
			  searchForESOP(esopId);
			  //FIRST_CES_SELECT_BUTTON
			  waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			  assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
			  click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			 }

			else if(cesQueue.equals("OnHold List")) {			
		    //ON_HOLD_LIST_TAB
		    waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
			assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
			click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
			searchForESOP(esopId);
			//FIRST_ONHOLD_CES_SELECT_BUTTON
			 waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			 assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
			 click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
			 //create on filter search for New York SOP Team
		    }

		    else  if(cesQueue.equals("Rejections List")) {			
			 //REJECTION_LIST_TAB
			 waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
			 assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
			 click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
			 searchForESOP(esopId);
			 //REJECTIONS_LIST_FIRST_CES_SELECT
			 waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
			 assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
			 click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		
			 }
			}
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		System.out.println("Switched to Frame 1");
		Thread.sleep(3000);
		//TRAINGLE_ICON_ARROW_ENTITY			
		//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
		assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
		//INTAKEMETHODVALUE
		waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
		String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");

		if(!arrowEntity.equals("")) {				
			waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
		    String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
			if (arrowEntityCheckedAttribute == null) {			
			        click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
		    }
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 

			if(!cdsop.equals("CDSOP")) {											
			 if (branchPlant.equals("CTCORP")) {
				//CTCORP_RADIO_BUTTON
				 	waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
					assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
					click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

				}
				else if (branchPlant.equals("NRAI")) {
					//NRAI_RADIO_BUTTON
					waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
					assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
					click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
					}
			}
			//ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
			if(cdsop.equals("CDSOP")) {
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
			}
			else if(!cdsop.equals("CDSOP")) {
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
			}
			//SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			int entitySearchCount = 0;
			//ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
		    if(entitySearchCount == 0) {
			//Click on unidentified entity
			waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
			String disabledUnEntity = "";
			try {				
			disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
			System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
			}catch(NullPointerException e) {}
			if(disabledUnEntity == null) {
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
			Thread.sleep(1500);
			try {
			if(disabledUnEntity.equals("true")) {					
			  //SEARCH_AGAIN_BUTTON
			  waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
			  assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
			  click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
			  //CANCEL_BUTTON
			  waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
			  assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
			  click(SOP.CANCEL_BUTTON, "Cancel Button");
			}}catch(NullPointerException e) {}				
             System.out.println("REached here in line 6431");
             Thread.sleep(2000);
             //below will be a go ahead when the value for unidentified Entity above is selected
             String unEntityRadioSelected = "";
             try {                	 
            	 unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
             }catch(NoSuchElementException e) {}
             catch(NullPointerException e) {}
             Thread.sleep(1000);
             try {
             if(unEntityRadioSelected == null) {
            	 click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
             }}catch(NullPointerException e) {}
			//ENTITY_TEXT_BOX
			waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
			//DOMESTIC_JURISDICTION_SELECTION
			waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
			//REP_JURISDICTION_SELECTION
			waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
			try {
			driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
			Thread.sleep(1500);
			selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
			}catch(NoSuchElementException e) {}
			//DOCUMENT_TYPE_DROPDWN
			try {
		    driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
			selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
			}catch(NoSuchElementException e) {}

			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");

			waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
			type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
			}
			else if(entitySearchCount != 0) {
			//REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			 //FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			//CONTINUE_BUTTON
			try {
				List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
				if(action.size()>0) {

					click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
				}
			}
			 catch(NoSuchElementException e) {}
			Thread.sleep(1000);
			driver.switchTo().defaultContent();
			assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
			click(SOP.GLYPHICON_HOME, "glyphicon button");
			Thread.sleep(3000);
			driver.switchTo().frame("frame1");		
			//PLAINTIFF_TEXT_BOX			
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
			//DEFENDANT_TEXT_BOX				
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");
			waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
			type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");
			try {
				driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
				selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
				}catch(NoSuchElementException e) {}
				//DOCUMENT_TYPE_DROPDWN
				try {
				driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
				selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
				}catch(NoSuchElementException e) {}
			}		
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				//Below one check can be applied if attorney and court modification needs to be done - 1476
				if(!attorneyName.equals("")) {			 			
						//RADIO_BUTTON_ATTORNEYNONE					
						String attorneyNoneAttribute = "";

						try {
							attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");   			
				            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
							click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
							//DROP_DOWN_ATTORNEY_SENDER_NAME
							waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"Drop down for Attorney Sender Name");
							assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"DROP down for Attorney Sender Name");
							selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"DROP down for Attorney Sender Name");
					   } catch (NoSuchElementException e) {}}

				 if(!courtName.equals("")) {					
					try {
							String courtNoneAttribute = "";
							courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
				            waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
							click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
							//DROP_DOWN_COURT_NAME
							waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
							assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
							selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");
					  } catch (NoSuchElementException e) {}}
				 Thread.sleep(1000);
				 List<WebElement> traceableMail = null;
					try {				
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if(traceableMail != null) { 
					type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
					}
					}catch(NoSuchElementException e) {}
			 //Below one check to validate Hard copy Required label and data
			//HARD_COPY_DELIVERY
			waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
			assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
			compareStrings(hardCopyDeliveryFlag,getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value"));
			//REJECT_REASON_DROP_DOWN
			waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
			selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
			//REJECT_BUTTON_IN_CES
			waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
			assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
			click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
			Thread.sleep(5000);

		}
	if(hardCopyDeliveryFlag.equals("No")) {		
		String parentWin= driver.getWindowHandle();
		Thread.sleep(2000);
		handlePopUpWindwow();
		String letterPopup = driver.getCurrentUrl();
		String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);		
		assertTextContains(letterPopup,rejectLog);
		driver.close();
		driver.switchTo().window(parentWin);
	}	
	}catch(Exception e){}	
	return esopId;
 }
	 */

	//This is also moved to common fxn file
	/*public void moveESOPFromNewQueueToDiffCESQueue(String reportSheet, int count) throws Throwable{

	String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);	
	String moveNewCES = Excelobject.getCellData(reportSheet, "Move New CES To", count);		
	String esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], "157001").get(0);		
	waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
	assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
	click(SOP.SOP_LINK_HEADER, "SOP link in header");			    		
	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
	assertElementPresent(SOP.CLEARBTN, "Clear Button");
	click(SOP.CLEARBTN, "Clear Button");		
	searchForESOP(esopId);		
	try {		 
	WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
	waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
	assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
	click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
	waitForElementPresent(SOP.CLEARBTN, "Clear Button");
	assertElementPresent(SOP.CLEARBTN, "Clear Button");
	click(SOP.CLEARBTN, "Clear Button");
	searchForESOP(esopId);			
	}catch(NoSuchElementException e) {}
	Thread.sleep(1000);			
	waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
	assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
	click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
	Thread.sleep(2000);
	driver.switchTo().frame("frame1");
	if(!moveNewCES.equals("OnHold")){								
	//ESCALATION_DETAILS
	waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
	assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
	click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
	//REASON_DRPDWN
	waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
	assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
	selectByVisibleText(SOP.REASON_DRPDWN,moveNewCES, "Escalation reason text box");
	//ESCALATION_COMMENTS_TEXTBOX
	waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
	assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
	type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Moving it to " + moveNewCES, "Escalation text box");
	//ESCALATE_BTN
	waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
	assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
	click(SOP.ESCALATE_BTN, "Escalate button");
	}

   else if(moveNewCES.equals("OnHold")){
	//REASON_FOR_HOLD_TEXTBOX
    waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
	assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
	type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
	//ONHOLD_BTN
	waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
	assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
	click(SOP.ONHOLD_BTN, "On Hold button"); 
   }   		 
}
	 */

	public void compareTheReasonForNotRejection(String reportSheet, int count, String esopId) throws Throwable {
		String currentStatus = "";
		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		ArrayList<String> statusCode = new ArrayList<String>();
		try {
			Thread.sleep(10000);
			statusCode = SQL_Queries.getTheReasonForNotRejection(esopId);
			currentStatus = statusCode.get(0);			
			compareStrings(currentStatus,status);
		} catch (IndexOutOfBoundsException e) {

		}		
	}

	//Below fxn is created as part of Bulk retirement project:
	//This is also moved to common fxn file
	/*public String submitESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

	String esopId = "";
	try {

		String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
		String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
		String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
		String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
		String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
		String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
		String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
		String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
		String courtName = Excelobject.getCellData(reportSheet, "Court", count);
		String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
		esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
				.get(0);
		if (!cesQueue.equals("New") && esopId == null) {
			moveESOPFromNewQueueToDiffCESQueue(reportSheet, count);
		}

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//Below change is Part of Sprint 53 changes
	      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
		  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
		  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
	     //Till here Sprint 53 changes
		if (cesQueue.equals("New")) {
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
			try {
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				//Below change is Part of Sprint 53 changes
			      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
				  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
				  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
			     //Till here Sprint 53 changes
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
			} catch (NoSuchElementException e) {
			}

			Thread.sleep(1000);
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		} else if (!cesQueue.equals("New")) {

			// CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
			click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

			if (cesQueue.equals("Escalated List")) {
				// ESCALATED_LIST_TAB
				waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
				searchForESOP(esopId);
				// FIRST_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			}

			else if (cesQueue.equals("OnHold List")) {
				// ON_HOLD_LIST_TAB
				waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				searchForESOP(esopId);
				// FIRST_ONHOLD_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				// create on filter search for New York SOP Team
			}

			else if (cesQueue.equals("Rejections List")) {
				// REJECTION_LIST_TAB
				waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				searchForESOP(esopId);
				// REJECTIONS_LIST_FIRST_CES_SELECT
				waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
			}
		}
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		System.out.println("Switched to Frame 1");
		Thread.sleep(3000);
		// TRAINGLE_ICON_ARROW_ENTITY
		// waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
		// Expaned");
		assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
		// INTAKEMETHODVALUE
		waitForElementPresent(SOP.INTAKEMETHODVALUE, "intake method value");
		String cdsop = getText(SOP.INTAKEMETHODVALUE, "intake method value");

		if (!arrowEntity.equals("")) {
			waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
			String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
			if (arrowEntityCheckedAttribute == null) {
				click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
			}
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

			if (!cdsop.equals("CDSOP")) {
				if (branchPlant.equals("CTCORP")) {
					// CTCORP_RADIO_BUTTON
					waitForElementPresent(SOP.CTCORP_RADIO_BUTTON,
							"CTCORP Radio Button on search Entity criteria page");
					assertElementPresent(SOP.CTCORP_RADIO_BUTTON,
							"CTCORP Radio Button on search Entity criteria page");
					click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

				} else if (branchPlant.equals("NRAI")) {
					// NRAI_RADIO_BUTTON
					waitForElementPresent(SOP.NRAI_RADIO_BUTTON,
							"NRAI Radio Button on search Entity criteria page");
					assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
					click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
				}
			}
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			if (cdsop.equals("CDSOP")) {
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
			} else if (!cdsop.equals("CDSOP")) {
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
			}

			//INCLUDE_ALL_REP_ASSUMED_BTN
			waitForElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
			assertElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
			click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");

			// SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			int entitySearchCount = 0;
			// ENTITY_SEARCH_RESULT_COUNT
			waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
			entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
			if (entitySearchCount == 0) {
				// Click on unidentified entity
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				String disabledUnEntity = "";
				try {
					disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
					System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
				} catch (NullPointerException e) {
				}
				if (disabledUnEntity == null) {
					click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
				}
				Thread.sleep(1500);
				try {
					if (disabledUnEntity.equals("true")) {
						// SEARCH_AGAIN_BUTTON
						waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
						// CANCEL_BUTTON
						waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
						click(SOP.CANCEL_BUTTON, "Cancel Button");
					}
				} catch (NullPointerException e) {
				}
				System.out.println("REached here in line 6431");
				Thread.sleep(2000);
				// below will be a go ahead when the value for unidentified Entity above is
				// selected
				String unEntityRadioSelected = "";
				try {
					unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
				} catch (NoSuchElementException e) {
				} catch (NullPointerException e) {
				}
				Thread.sleep(1000);
				try {
					if (unEntityRadioSelected == null) {
						click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
					}
				} catch (NullPointerException e) {
				}
				// ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
				type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
				// DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
				selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
				// REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
				selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
				try {
					driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
					Thread.sleep(1500);
					selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
				} catch (NoSuchElementException e) {
				}
				// DOCUMENT_TYPE_DROPDWN
				try {
					driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
					selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
				} catch (NoSuchElementException e) {
				}

				// PLAINTIFF_TEXT_BOX
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
				// DEFENDANT_TEXT_BOX
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

				waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
				type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
			} else if (entitySearchCount != 0) {
				// REP_STATUS_SORT

	 * waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
	 * assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
	 * click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");

				// FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				// CONTINUE_BUTTON
				try {
					List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
					if (action.size() > 0) {

						click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				Thread.sleep(1000);
				driver.switchTo().defaultContent();
				assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
				click(SOP.GLYPHICON_HOME, "glyphicon button");

				 Code changed during Accelerated Log Project 
				//Below try and catch block added as part of Sprint 53 scripting
				//from line 8891 to 9024
				String parentWindow = driver.getWindowHandle();
				try {		
					Set<String> windows = driver.getWindowHandles();
					if(windows.size() > 1) {
					handlePopUpWindwow();
					driver.close();
					driver.switchTo().window(parentWindow);
					}
				}catch(NoSuchSessionException e ) {

				}
				Thread.sleep(3000);
				driver.switchTo().frame("frame1");
				waitForElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
				assertElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
				click(SOP.ARROW_REPRESENTATION, "Arrow representation button");
				// CLEARBTN
				waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
				assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
				click(SOP.CLEARBTN, "Clear Button of filter");
				//FIRST_REP_CES_REP_UNITS
				waitForElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
				assertElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
				click(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
				try {		
					Set<String> windows = driver.getWindowHandles();
					if(windows.size() > 1) {
					handlePopUpWindwow();
					driver.close();
					driver.switchTo().window(parentWindow);
					Thread.sleep(1000);
					driver.switchTo().frame("frame1");
					}
				}catch(NoSuchSessionException e ) {

				}

				// PLAINTIFF_TEXT_BOX
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
				// DEFENDANT_TEXT_BOX
				waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
				type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
				waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
				assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
				type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				try {

					driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
					if (!lawSuit.equals("")) {
						System.out.println("Reached here with lawsuit value : " + lawSuit);
						selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");

					}

					else {

						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
					}
				} catch (NoSuchElementException e) {
				}
				// DOCUMENT_TYPE_DROPDWN
				try {
					driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
					selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
				} catch (NoSuchElementException e) {
				}
			}
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			// Below one check can be applied if attorney and court modification needs to be
			// done - 1476
			if (!attorneyName.equals("")) {
				// RADIO_BUTTON_ATTORNEYNONE
				String attorneyNoneAttribute = "";

				try {
					attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
							"Radio button for Existing Attorney Sender in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
							"Radio button for Existing Attorney Sender in CES Page");
					// DROP_DOWN_ATTORNEY_SENDER_NAME
					waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
					assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
					selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					//USE_THIS_ATTORNEY
					waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
					assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
					click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");

					//TEXT_BOX_ATTORNEYNAME
					waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
					assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
				    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");

					//ATTORNEY_ADDRESS_LINE_ONE
				    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
				    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
				    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	

					//CITY_NAME
					waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
					assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
					type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");

					//ATTORNEY_STATE_NAME
					waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
					assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
					type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");

					//ATTORNEY_ZIP_CODE
					waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
					assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
					type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");

				} catch (NoSuchElementException e) {
				}
			}

			if (!courtName.equals("")) {
				try {
					String courtNoneAttribute = "";
					courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,
							"Radio button for Existing Court in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					// DROP_DOWN_COURT_NAME
					waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
					assertElementPresent(SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
					selectByIndex(SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					//USE_THIS_COURT
					waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
					assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
					click(SOP.USE_THIS_COURT,"Use this court radio button");
					//COURT_NAME_TEXT_BOX
					waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
					assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
					type(SOP.COURT_NAME_TEXT_BOX,courtName,"Court NAme");
					//ADDRESS_LINE_ONE
					waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
					assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
					type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
					//CITY_NAME
					waitForElementPresent(SOP.CITY_NAME,"City Name text box");
					assertElementPresent(SOP.CITY_NAME,"City Name text box");
					type(SOP.CITY_NAME,"Houston","City Name text box");
					//STATE_NAME
					waitForElementPresent(SOP.STATE_NAME,"State Name text box");
					assertElementPresent(SOP.STATE_NAME,"State Name text box");
					type(SOP.STATE_NAME,"TX","State Name text box");
					//ZIP_CODE
					waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
					assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
					type(SOP.ZIP_CODE,"77550","Zip code text box");

				} catch (NoSuchElementException e) {
				}
			}
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}
			// Below one check to validate Hard copy Required label and data

	 * //HARD_COPY_DELIVERY waitForElementPresent(SOP.HARD_COPY_DELIVERY,
	 * "Hard Copy Delivery Flag Value");
	 * assertElementPresent(SOP.HARD_COPY_DELIVERY,
	 * "Hard Copy Delivery Flag Value");
	 * compareStrings(hardCopyDeliveryFlag,getText(SOP.HARD_COPY_DELIVERY,
	 * "Hard Copy Delivery Flag Value"));

			List<WebElement> reasonForNotRejection = null;
			// REASON_FOR_NOT_REJECTING
			try {
				reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
				if (reasonForNotRejection != null) {
					selectByIndex(SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
				}
			} catch (NoSuchElementException e) {
			}
			// SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
			click(SOP.SUBMIT_CES, "Submit button in CES");
			Thread.sleep(5000);

		}

	} catch (Exception e) {
		e.printStackTrace();
	}
	return esopId;
}
	 */

	public void compareExpeditedWorkflow(String reportSheet, int count, String esopId) throws Throwable {

		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		String expeditedFlag = Excelobject.getCellData(reportSheet, "Expedited Flag", count);
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		ArrayList<String> expeditedLog = new ArrayList<String>();
		//try {

		if (expeditedFlag.equals("")) {
			expeditedFlag = null;
		}
		if (workflow.equals("")) {

			workflow = null;
		}
		//Added below fxn to check if handler has processed the esop 6/11
		for(int i=0 ;i<10; i++) {			
		String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
		if(isHandlerProcessed.equals("N")) {
		Thread.sleep(3000);
		}
		else {
			break;
		}		
		}

		//Uncomment the below code before any code commit
		for(int i =0 ; i < 15 ; i++) {
			expeditedFlag = SQL_Queries.expeditedLogWorkflow(esopId).get(1);
			if(expeditedFlag == null) {
				Thread.sleep(3000);
			}
			else {
				break;
			}
		}
		try {
			expeditedLog = SQL_Queries.expeditedLogWorkflow(esopId);
			compareStrings(status, expeditedLog.get(0));
			compareStrings(expeditedFlag, expeditedLog.get(1));
			compareStrings(workflow, expeditedLog.get(2));
		}catch (Exception e) {}
		/*} catch (IndexOutOfBoundsException e) {

	}*/
	}

	//Below fxn is created as part of Bulk retirement project

	public void expeditedTransmissionLog(String esopId) throws Throwable {

		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		//Here one sop click function will come
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//EXPEDITED_TRANSMISSIONS
		waitForElementPresent(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		assertElementPresent(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		click(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		//CLEARBTN
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOPWithHash(esopId);

		//FIRST_ESOP_IN_EXPEDITED_TRANSMISSION
		waitForElementPresent(SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION, "First ESOP in Expedited Transmission Page");
		assertElementPresent(SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION, "First ESOP in Expedited Transmission Page");
		compareStrings(esopId, getText(SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION,"First ESOP in Expedited Transmission Page"));
		//FIRST_LOG_IN_EXPEDITED_TRANSMISSION
		waitForElementPresent(SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION, "First Log in Expedited Transmission Page");
		assertElementPresent(SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION, "First Log in Expedited Transmission Page");
		compareStrings(expeditedLog, getText(SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION,"First Log in Expedited Transmission Page"));
	}


	public void searchForESOPWithHash(String esopId) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "ESOP #", "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}

	public String actionItemExecution(String esopId) throws Throwable {

		String expeditedLog = "";
		try {
			Thread.sleep(30000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(expeditedLog);

		// ACTION_ITEMS
		waitForElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		assertElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		click(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		// RETAIN_SOP_STATUS
		waitForElementPresent(SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		assertElementPresent(SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		String retainSOPStatus = getText(SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		compareStrings(retainSOPStatus, "Retained");
		// ISOP_STATUS
		waitForElementPresent(SearchWorksheet.ISOP_STATUS, "ISOP Status");
		assertElementPresent(SearchWorksheet.ISOP_STATUS, "ISOP Status");
		String isopStatus = getText(SearchWorksheet.ISOP_STATUS, "ISOP Status");
		compareStrings(isopStatus, "Executed");

		return expeditedLog;
	}

	public void searchWorksheet(String worksheetId) throws Throwable {
		try {
			blnEventReport = true;
			//Click On Worksheet Search Link from left nav bar
			click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK,"Worksheet Search On Left Nav Link");
			click(SOP.CLASSIC_SEARCH_BTN,"Classic Search Button");
			waitForElementPresent(SOP.SEARCH_BTN, "Search Button");

			//Enter an entity Id to be searched and click on search btn
			type(SOP.WORKSHEET_ID_TEXTBOX,worksheetId,"Workhseet Id text Box");
			click(SOP.WORKSHEET_SEARCH_BTN,"Worksheet Search Btn");

		} catch (Exception e) {
			throw e;
		}
	}

	/*public void transmittalDataVerification(String reportSheet, int count, String esopId) throws Throwable{

		String recipientId = Excelobject.getCellData(reportSheet, "Recipient Id", count);
		String parentWindow = driver.getWindowHandle();
		//FIRST_TRANSMITTAL_BUTTON
		waitForElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		assertElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		click(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");		
		handlePopUpWindwow();
		String url = driver.getCurrentUrl(); 		
		String pdfData = getPDFContent(url);
		// below querry the DB to get the below items
		String caseNumber = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(0);
		String plaintiff = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(1);
		String defendant = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(2);
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
		String lawSuitType = SQL_Queries.getTheLawSuitTypeInCESInbox(esopId).get(0);
		String recipientName = SQL_Queries.getTheRecipientName(recipientId).get(0);
		if(courtNameInCES == null) {
			courtNameInCES = "None Specified";
		}
		String [] worksheetFields = {"TITLE OF ACTION:",			   			        
				"COURT/AGENCY: "+courtNameInCES,
				"Case # "+ caseNumber,
				"NATURE OF ACTION: " + lawSuitType,
				"ACTION ITEMS: CT has retained the current log, Retain Date:",
		};


		for(String str : worksheetFields) {
			if(pdfData.contains(str)){
				flag =  true;                 
				SuccessReport("Text : " , str + " is present in PDF");
			}
			else {
				failureReport("Text : " , str + " is not present in PDF");
			}		
		}

		String plaintiffInTransmittal = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[0].replaceAll("[^\\x00-\\x7F]", "");
		String defendantInTransmittal = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[1].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "");	    
		//System.out.println(pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0]);
		String recipientInTransmital = pdfData.split("TO: ")[1].split("\n")[0].split("\\R")[0].replace(" ", "");
		//System.out.println(recipientInTransmital);	   
		compareStrings(recipientInTransmital.toUpperCase(),recipientName.toUpperCase().replace(" ", ""));	    
		compareStrings(plaintiff,plaintiffInTransmittal);
		compareStrings(defendant,defendantInTransmittal);
		driver.close();
		driver.switchTo().window(parentWindow);
	}
*/
public void transmittalDataVerification(String reportSheet, int count, String esopId) throws Throwable{
		
		//As per the optimized Transmittal 1.2 , below Assertions:
		//compareStrings(plaintiff,plaintiffInTransmittal);
	    //compareStrings(defendant,defendantInTransmittal);
		//will be chaged to Title of Action Transmitta
		String branchPlant = Excelobject.getCellData(reportSheet,"Branch Plant", count);
		String consolidated = Excelobject.getCellData(reportSheet,"Consolidated", count);
		String parentWindow = driver.getWindowHandle();
		//FIRST_TRANSMITTAL_BUTTON
		waitForElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		assertElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		click(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");		
		handlePopUpWindwow();
		String url = driver.getCurrentUrl(); 		
		String pdfData = getPDFContent(url);
	  // below querry the DB to get the below items
		String caseNumber = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(0);
		String toaInWorksheet = SQL_Queries.toaInWorksheet(esopId).get(0);
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
		String lawSuitType = SQL_Queries.getTheLawSuitTypeInCESInbox(esopId).get(0);		
		if(courtNameInCES == null) {
			courtNameInCES = "None Specified";
		}
		if(caseNumber == null) {
			caseNumber = "None Specified";
		}
		String toaInTransmittal = "";
		String toaLabel = "";
		String court = "";
		String noaOrDoc = "";
		if(branchPlant.equals("CTCORP")){
		toaLabel = "TITLE OF ACTION: ";
		court = "COURT/AGENCY: "+courtNameInCES;
		noaOrDoc = "NATURE OF ACTION: ";
		
		}
		else if(branchPlant.equals("NRAI")){
		toaLabel = "Title of Action:";
		court = "Court of Jurisdiction/Case Number: "+courtNameInCES;
		noaOrDoc = "Document";
		}		
		
	   String [] worksheetFields = {toaLabel,			   			        
			        court,
			        noaOrDoc
	                 };
	   
	    	   
	   for(String str : worksheetFields) {
	   if(pdfData.contains(str)){
	       flag =  true;                 
	       SuccessReport("Text : " , str + " is present in PDF");
	   }
	   else {
			failureReport("Text : " , str + " is not present in PDF");
	 }		
	}
	
	    toaInTransmittal = pdfData.split(toaLabel)[1].split("\n")[0].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "");
	    if(consolidated.equals("Yes")) {
	    	
	    	toaInTransmittal = toaInTransmittal.split(" \\(0")[0];
	    }
	    compareStrings(toaInTransmittal,toaInWorksheet);
		driver.close();
		driver.switchTo().window(parentWindow);
	}

	
	public void bulkWorksheetInSOPHub(String reportSheet, int count) throws Throwable {


		String worksheetId = Excelobject.getCellData(reportSheet, "Accelerated Log", count);	
		//SELECT
		waitForElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
		assertElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
		click(SopHub.SELECT, "Select button in Customer Search Page");
		//SOP_HUB_LINK
		waitForElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
		assertElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
		click(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
		if(!worksheetId.equals("")) {
			for(int i = 0; i<10; i++) {
				//LOG_SEARCH_TEXT_FIELD
				waitForElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");
				assertElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");		
				type(SopHub.LOG_SEARCH_TEXT_FIELD,worksheetId, "Log Search test field in SOP Received Page");
				//SEARCH_BUTTON
				waitForElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
				assertElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
				click(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");	
				WebElement noSuchWorksheet = null;
				try {

					noSuchWorksheet = driver.findElement(By.xpath("//span[contains(text(),'There are no entries in this list.')]"));
					//HOME_BUTTON
					assertElementPresent(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
					click(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");

				}catch(NoSuchElementException e) {

				}	
				if(noSuchWorksheet != null) {

					Thread.sleep(12000);
				}
				else {
					break;
				}
			}
			//CT_LOG_NUMBER
			waitForElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
			assertElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
			compareStrings(worksheetId,getText(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub"));
		}
	}
	public void logInActionItemFailure(String esopId) throws Throwable {

		
		
		for(int i=0 ;i<10; i++) {			
			String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
			if(isHandlerProcessed.equals("N")) {
			Thread.sleep(3000);
			}
			else {
				break;
			}		
			}
		
		try {
			String expeditedLog = "";
			try {
				//Thread.sleep(1000);
				expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
			} catch (IndexOutOfBoundsException e) {
				e.printStackTrace();
			}
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// ACTION_ITEM_FAILURES
			waitForElementPresent(SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures link in left nav bar");
			assertElementPresent(SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures link in left nav bar");
			click(SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures in left nav bar");

			searchForLog(expeditedLog);
			// FIRST_WORKSHEET
			waitForElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
			assertElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
			click(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");

			// ACTION_ITEMS
			waitForElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
			assertElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
			click(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");

			// ACTION_ITEMS_NO_RECORDS
			waitForElementPresent(SearchWorksheet.ACTION_ITEMS_NO_RECORDS, "No Records found in Action Items Page");
			assertElementPresent(SearchWorksheet.ACTION_ITEMS_NO_RECORDS, "No Records found in Action Items Page");

			//WORKSHEET_PROFILE_LINK
			waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet Profile link");
			assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK, "workheet Profile link");
			click(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet Profile link");
		}catch(Exception e) {}
	}

	public void searchForLog(String log) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "Log #", "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, log, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}

/*	public void sopWorkflow(String reportSheet, int count, String esopId) throws Throwable {
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		String logNumber = "";
		try {
			Thread.sleep(2000);
			logNumber = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(logNumber);
		// SOP_WORKFLOW
		waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");

		if (workflow.equals("15001")) {

			compareStrings(workflowInWorksheet, "Full");

		}

		else if (workflow.equals("15002")) {

			compareStrings(workflowInWorksheet, "Accelerated");
		}
	}*/



	public void createAndExecuteActionItem(String reportSheet,int count,String esopId) throws Throwable {

		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		String  lawsuitType = Excelobject.getCellData(reportSheet, "Law Suit", count);
		String  hardCopyRequired = Excelobject.getCellData(reportSheet, "Hard Copy DI", count);
		String  entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);

		waitForElementToBePresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		click(SOP.CHOOSE_DI_BTN, "Choose DI Button");

		if(hardCopyRequired.equals("No")) {		
			//VALUE_OF_LAW_SUIT_TYPE_IN_DI
			int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI,lawsuitType);
			System.out.println("the index sent is : " + matchedIndexLawSuit);
			//USE_BUTTON_IN_LAWSUIT
			clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);	   

			//SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
			waitForElementToBePresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
			assertElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
			click(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");		

		}
		else if(hardCopyRequired.equals("Yes")) {
			//VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI
			int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI,lawsuitType);
			//USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES
			clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);

			//EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL
			waitForElementToBePresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
			assertElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
			click(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
			//COMMENTS_DRPDWN
			waitForElementToBePresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
			assertElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
			selectByVisibleText(SOP.COMMENTS_DRPDWN,"Hard Copy Required","Execute Manual in SOP Papers with Transmittal");
			//CONTINUE_BUTTON
			waitForElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
			assertElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
			click(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
			try {
				WebElement createPackage = driver.findElement(By.id("btnCreatePackage"));
				createPackage.click();
			}catch(NoSuchElementException e) {}
			//SAVE_BTN
			assertElementPresent(Entity.SAVE_BTN, "Save button");
			click(Entity.SAVE_BTN, "Save button");
			//ACTION_ITEMS_LEFT_NAV_LINK
			waitForElementToBePresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
			assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
			click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");		 				 
		}

		//EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL
		waitForElementToBePresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
		assertElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
		click(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
		//
       // Below Post status check is handled in different function
		//here is the issue in the bulk 
		/*for(int i = 0 ; i<10; i++) {
			ArrayList<String> executedBy = SQL_Queries.executedByInActionItem(expeditedLog);
			try {
			if(!executedBy.get(0).equals("1166") || !executedBy.get(1).equals("1166")) {
				Thread.sleep(10000);
			}
			else {
				break;
			}
			}catch(NullPointerException e) {
				   Thread.sleep(10000);
			}
		}
		//WORKSHEET_PROFILE_LINK
		waitForElementToBePresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		click(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");

		//POST_STATUS
		assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus, "Posted");*/

	}

	public void unexecuteActionItems(String esopId) throws Throwable{

		String expeditedLog = "";
		try {
			Thread.sleep(30000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(expeditedLog);
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementToBePresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");

		//UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
		waitForElementToBePresent(SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		assertElementPresent(SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		click(SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		//UNEXECUTE_COMMENTS_TEXT_BOX
		waitForElementToBePresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		assertElementPresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		type(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Unexecute Retain SOP","Text box for unexecute comments");
		//UNEXECUTE_ACTION_ITEM_BUTTON
		waitForElementToBePresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		assertElementPresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		click(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		//UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL
		waitForElementToBePresent(SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");
		assertElementPresent(SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");
		click(SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");		
		waitForElementToBePresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		assertElementPresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		type(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Unexecute ISOP","Text box for unexecute comments");
		waitForElementToBePresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		assertElementPresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		click(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");

		for(int i = 0 ; i<4; i++) {
			try {
			ArrayList<String> executedBy = SQL_Queries.executedByInActionItem(expeditedLog);		   
			if(executedBy.get(0) != null || executedBy.get(1) != null) {
				Thread.sleep(10000);
			}
			else {
				break;
			}
		}catch(NullPointerException e) {
			   Thread.sleep(10000);
		}
		}
		//WORKSHEET_PROFILE_LINK
		waitForElementToBePresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		click(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");

		//POST_STATUS
		assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus, "UnPosted");

	}

	public void rejectedLogHardCopyRequiredSOPTeamDashboard(String reportSheet, int count, String esopId)
			throws Throwable {

		try {
			teamSOPDashboard(reportSheet, count);
			String branchPlant = SQL_Queries.getTheBranchPlantForTheESOPs(esopId).get(0);
			String rejectedLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
			if (branchPlant.equals("92001")) {
				// REJECT_AND_HARDCOPY_LINK
				waitForElementToBePresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO,
						"Reject and Hard Copy Required For CTCORP");
				assertElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO,
						"Reject and Hard Copy Required For CTCORP");
				click(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO, "Reject and Hard Copy Required For CTCORP");
			} else if (branchPlant.equals("92003")) {
				// REJECT_AND_HARDCOPY_LINK_NRAI
				waitForElementToBePresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI,
						"Reject and Hard Copy Required For NRAI");
				assertElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI,
						"Reject and Hard Copy Required For NRAI");
				click(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI, "Reject and Hard Copy Required For NRAI");
			}
			searchForLog(rejectedLog);
			// FIRST_SOP_ID
			waitForElementToBePresent(TeamSOPDashboard.FIRST_SOP_ID,
					"Reject Log with hard cop required is present in the Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.FIRST_SOP_ID,
					"Reject Log with hard cop required is present in the Team SOP Dashboard");

		} catch (NoSuchElementException e) {
		} catch (Exception e) {
		}
	}

	public void teamSOPDashboard(String reportSheet, int count) throws Throwable {
		String dashboard = Excelobject.getCellData(reportSheet, "Team Dashboard", count);
		waitForElementToBePresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		// TEAM_SOP_DASHBOARD
		waitForElementToBePresent(SOP.TEAM_SOP_DASHBOARD, "Team SOP Dashboard link in left nav SOP List Page");
		assertElementPresent(SOP.TEAM_SOP_DASHBOARD, "assert Team SOP Dashboard link in left nav SOP List Page");
		click(SOP.TEAM_SOP_DASHBOARD, "click Team SOP Dashboard link in left nav SOP List Page");
		// REJECTED_HARD_COPY_REQUIRED
		assertElementPresent(SOP.REJECTED_HARD_COPY_REQUIRED,
				"Rejected and hard copy required status assert Team SOP Dashboard Page");
		// PHONE_CALL_REQUIRED
		assertElementPresent(SOP.PHONE_CALL_REQUIRED, "Phone Call Required status assert Team SOP Dashboard Page");
		// INCOMPLETE_WORKSHEETS
		assertElementPresent(SOP.INCOMPLETE_WORKSHEETS, "Incomplete Worksheet status assert Team SOP Dashboard Page");
		// PENDING_ACTION_ITEMS
		assertElementPresent(SOP.PENDING_ACTION_ITEMS, "Pending Action Items status assert Team SOP Dashboard Page");
		if (!dashboard.equals("")) {
			// TEAM_DROP_DOWN
			waitForElementToBePresent(SOP.TEAM_DROP_DOWN, "Team drop down fields in Team SOP Dashboard Page");
			assertElementPresent(SOP.TEAM_DROP_DOWN, "assert Team drop down fields in Team SOP Dashboard Page");
			click(SOP.TEAM_DROP_DOWN, "click Team drop down fields in Team SOP Dashboard Page");
			selectByVisibleText(SOP.TEAM_DROP_DOWN, dashboard, "select the text in Team drop down");
			// REJECTION_FOR_REVIEW
			if (dashboard.equals("SOP Support Team") && dashboard.equals("SOP Dallas Processing Team")) {
				waitForElementToBePresent(SOP.REJECTION_FOR_REVIEW,
						"Rejection for review status assert Team SOP Dashboard Page");
				assertElementPresent(SOP.REJECTION_FOR_REVIEW,
						"Rejection for review status assert Team SOP Dashboard Page");
			}
		}
	}

	public void createSOPIncidentReportOnTheCreatedWorksheet(String esopId) throws Throwable {


		String worksheetId = "";

		for(int i =0 ; i < 10 ; i++) {
			worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
			if(worksheetId == null) {
				Thread.sleep(10000);
			}
			else {
				break;
			}
		}

		/*	try {
		worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
	} catch (IndexOutOfBoundsException e) {
		e.printStackTrace();
	}*/
		//CRM_LINK
		waitForElementPresent(HomePage.CRM_LINK,"CRM Link");
		assertElementPresent(HomePage.CRM_LINK,"CRM Link");
		click(HomePage.CRM_LINK,"CRM Link");

		assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
		assertElementPresent(CRM.CREATE_BUTTON, "Create Button");
		click(CRM.CREATE_BUTTON, "Create Button");

		waitForElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
		assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");

		//click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
		waitForElementPresent(CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		assertElementPresent(CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		selectByVisibleText(CRM.SERVICE_TYPE_DROP_DOWN,"SOP Incident Report", "Select SOP Incident Report from Dropdown");

		String parentWindow = driver.getWindowHandle();
		assertElementPresent(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		click(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		handlePopUpWindwow();
		assertElementPresent(CRM.WORKSHEET_SEARCH_POPUP, "Worksheet Search Popup");
		type(CRM.ENTER_LOGID, worksheetId, "Log ID Entered");
		click(CRM.LOGID_SEARCH_BUTTON, "Log ID Search Button");
		click(Generic.SELECT, "Select Button");
		driver.switchTo().window(parentWindow);
		click(CRM.ERROR_TYPE, "Error Type");
		click(CRM.REQUESTED_VIA, "Requested Via");
		click(CRM.SERVICE_LEVEL, "Service Level");
		click(Generic.SAVE, "Save Button");
		assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
		assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");
	}

	public void worksheetInMyWorksheetsToReview(String esopId) throws Throwable{

		//MY_WORKSHEET
		waitForElementPresent(WorksheetCreate.MY_WORKSHEET,"My Worksheet link");
		assertElementPresent(WorksheetCreate.MY_WORKSHEET,"My Worksheet link");
		click(WorksheetCreate.MY_WORKSHEET,"My worksheet link");
		//MY_WORKSHEETS_TO_REVIEW_TAB
		waitForElementPresent(CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		assertElementPresent(CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		click(CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		// CLEARBTN
		waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
		assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
		click(SOP.CLEARBTN, "Clear Button of filter");
		String worksheetId = "";

		try {
			worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
			System.out.println("The values for WS is " + worksheetId);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchForLog(worksheetId);
		waitForElementPresent(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA,
				"Log is present in worksheets to review Tab");
		assertElementPresent(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA,
				"Log is present in worksheets to review Tab");
	}
		
	public Map<Integer,String> validateExpeditedTransmission(String actionItem,int test,String reportSheet, String [] esops) throws Throwable{
   
		String actionItemExecution = actionItem;
		Map<Integer,String> acceleratedWorksheet = new HashMap<Integer,String>();
		int acceleratedLogKey =1;	
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);
			compareExpeditedWorkflow(reportSheet, i+2,esops[i]);
			expeditedTransmissionLog(esops[i]);	
			if(actionItemExecution.equals("Success")) {
			acceleratedWorksheet.put(acceleratedLogKey, actionItemExecution(esops[i]));
			acceleratedLogKey++;			
			transmittalDataVerification(reportSheet, i+2,esops[i]);
			}
			else if(actionItemExecution.equals("Failed")) {
			
				logInActionItemFailure(esops[i]);				
			}
			driver.manage().deleteAllCookies();
			
		}
		return acceleratedWorksheet;				
		}
	
	public void validateSOPWorkflowInWorksheet(int test,String reportSheet, String [] esops) throws Throwable{
		   
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			String testCaseID = Excelobject.getCellData(reportSheet, "TestCase-ID", i+2);
			SignIn(team, member);						
			compareTheCurrentStatus(reportSheet, i+2,esops[i]);				
			if(testCaseID.contains("Create")) {			
			viewAndCreateTheWorkSheetUsingESOPId(reportSheet, i+2,esops[i]);
			}			
			sopWorkflow(reportSheet, i+2,esops[i]);	
			driver.manage().deleteAllCookies();
			
		}				
	}
	
	public void createAndExecuteActionItemForAcceleratedLog(int test,String reportSheet, String [] esops) throws Throwable{
		   
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);						
			logInActionItemFailure(esops[i]);
			createAndExecuteActionItem(reportSheet, i+2,esops[i]);
			compareExpeditedWorkflow(reportSheet, i+2,esops[i]);
			driver.manage().deleteAllCookies();			
		}
		//Below one function to check if the log is posted
		driver.get(URL);
		String member = Excelobject.getCellData(reportSheet, "Member", 2);
		String team = Excelobject.getCellData(reportSheet, "Team", 2);
		SignIn(team, member);	
		for(int i=0 ; i<esops.length ; i++) {
			String worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esops[i]).get(0);
			searchWorksheet(worksheetId);
			validateThePostStatusOfworksheet(worksheetId);				
		}
	}
	
	public void unExecuteActionItemForHardCopyDIAcceleratedLog(int test,String reportSheet, String [] esops) throws Throwable{
		   
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);						
			compareExpeditedWorkflow(reportSheet, i+2,esops[i]);
			unexecuteActionItems(esops[i]);
			createAndExecuteActionItem(reportSheet, i+2,esops[i]);						
			rejectedLogHardCopyRequiredSOPTeamDashboard(reportSheet, i+2,esops[i]);
			driver.manage().deleteAllCookies();		
		}
		//Below one function to check if the log is posted
		driver.get(URL);
		String member = Excelobject.getCellData(reportSheet, "Member", 2);
		String team = Excelobject.getCellData(reportSheet, "Team", 2);
		SignIn(team, member);
		for(int i=0 ; i<esops.length ; i++) {				
			String worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esops[i]).get(0);
			searchWorksheet(worksheetId);
			validateThePostStatusOfworksheet(worksheetId);				
		}
	}
	
	public void validateCRMForWorksheet(int test,String reportSheet, String [] esops) throws Throwable{
		   
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			String testCaseID = Excelobject.getCellData(reportSheet, "TestCase-ID", i+2);
			SignIn(team, member);
			if(testCaseID.contains("For Bulk not eligible")) {			
			viewAndCreateTheWorkSheetUsingESOPId(reportSheet, i+2,esops[i]);
			}
			createSOPIncidentReportOnTheCreatedWorksheet(esops[i]);
			driver.manage().deleteAllCookies();
			driver.get(URL);
			SignInFromSOPSupportTeam();
			worksheetInMyWorksheetsToReview(esops[i]);
			driver.manage().deleteAllCookies();
			
		}				
	}
}
