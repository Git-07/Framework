package com.arrow.workflows;

import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP_SOPVolume extends BusinessFunctions {

	public String sortByFilter(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on My Worksheet link on Home page
			click(HomePage.SOPLISTLINK, "SOP List Link");
			assertElementPresent(SOP.SOPLIST_TILE_PAGE, "SOP List Page");

			// Click on SOP Volume link
			click(SOP.SOP_VOLUME, "SOP Volume Page");

			// Verify Filters
			click(SOP.OFFICE_NAME_FILTER, "Office Name Filter");
			click(SOP.NO_OF_SOP_OVER_CAPACITY_FILTER, "Number of sop over capacity filter");
			click(SOP.NO_OF_SOP_UNDER_CAPACITY_FILTER, "Number of sop under capacity filter");
			click(SOP.PROJECTED_CARRYOVER_FILTER, "Projected Carryover filter");
			click(SOP.PROJECTED_EXCESS_CAPACITY_FILTER, "Projected Excess capacity filter");

			// Verify Sort By
			assertElementPresent(SOP.ACTIVE_OFFICE_NAME, "Active Office Name");
			assertElementPresent(SOP.INACTIVE_NO_OF_SOP_OVER_CAPACITY, "Inactive Number of sop over capacity");
			assertElementPresent(SOP.INACTIVE_NO_OF_SOP_UNDER_CAPACITY, "Inactive Number of sop Under capacity");
			assertElementPresent(SOP.INACTIVE_PROJECTED_CARRYOVER, "Inactive Projected Carryover");
			assertElementPresent(SOP.INACTIVE_PROJECTED_EXCESS_CAPACITY, "Inactive Projected Excess capacity");
			click(SOP.INACTIVE_NO_OF_SOP_OVER_CAPACITY, "Inactive Number of sop over capacity");
			assertElementPresent(SOP.ACTIVE_NO_OF_SOP_OVER_CAPACITY, "Active Number of sop over capacity");
			click(SOP.INACTIVE_NO_OF_SOP_UNDER_CAPACITY, "Inactive Number of sop Under capacity");
			assertElementPresent(SOP.ACTIVE_NO_OF_SOP_UNDER_CAPACITY, "Active Number of sop Under capacity");
			click(SOP.INACTIVE_PROJECTED_EXCESS_CAPACITY, "Inactive Projected Excess capacity");
			click(SOP.ACTIVE_PROJECTED_EXCESS_CAPACITY, "Active Projected Excess capacity");
			click(SOP.INACTIVE_PROJECTED_CARRYOVER, "Inactive Projected Carryover");
			assertElementPresent(SOP.ACTIVE_PROJECTED_CARRYOVER, "Active Projected Carryover");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
