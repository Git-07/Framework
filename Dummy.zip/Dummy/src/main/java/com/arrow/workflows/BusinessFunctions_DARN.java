package com.arrow.workflows;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.HomePage;

public class BusinessFunctions_DARN extends BusinessFunctions_Affiliation {

	public void verifyDEARNotificationsSection(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Click On Event Manager from left nav link
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");

			// Verify the page title is Event Manager
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");

			// Click On File & Event Selection link from left nav bar
			click(Admin.FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK, "File & Event Selection Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void deARNotificationsPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Delaware AR Admin is Present
			isElementPresent(Admin.DELAWARE_AR_ADMIN_CHECKBOX, "Delaware AR Admin Checkbox");
			assertTextMatching(Admin.DELAWARE_AR_ADMIN_LABEL, "Delaware AR Admin", "Label For Delaware AR Admin Field");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(Admin.EDIT_BTN, "Edit Button");

			// Click on Delaware AR Admin Checkbox and click on save
			// button
			click(Admin.DELAWARE_AR_ADMIN_CHECKBOX, "Delaware AR Admin Checkbox");
			click(Admin.SAVEBTN, "Save Button");

			// Verify Delware AR Admin is added under Administrative Permissions on Role
			// Profile Page
			assertElementPresent(Admin.DELAWARE_AR_ADMIN_ON_ROLE_PROFILE_PAGE,
					"Delware AR Admin is added under Administrative Permissions on Role Profile Page");

			// Click on Edit Button again and uncheck Delware AR Admin
			click(Admin.EDIT_BTN, "Edit Button");
			click(Admin.DELAWARE_AR_ADMIN_CHECKBOX, "Delaware AR Admin Checkbox");

			// Click on save btn
			click(Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Administrative Permissions Field
			assertTextMatching(Admin.ADMINISTRATIVE_PERMISSIONS_FIELD, "No permissions",
					"No permissions Msg on Administrative Permissions Field");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminHavingPermissions(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminNotHavingPermissions(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			isDisabled(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
		} catch (Exception e) {
			throw e;
		}

	}

	public void delawareARNotificationOptOutOnAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Verify Delaware AR Notification Opt-Out Label is present on Affiliation
			// Profile Page and its default value is No
			assertElementPresent(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_LABEL,
					"Delaware AR Notification Opt-Out Label");
			assertTextMatching(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE, "No",
					"Delaware AR Notification Opt-Out Value");

			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");
			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "Edit Affiliation", "Page Title");

			// Verify Delaware AR Notification Opt-Out Label is present on Affiliation Edit
			// Page and its checkbox is unchecked
			assertElementPresent(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_LABEL_ON_AFFI_EDIT,
					"Delaware AR Notification Opt-Out Label");
			isElementNotPresent(Affiliation.CHECKED_DELAWARE_NOTIFICATION_OPT_OUT,
					"Checked Delaware AR Notification Opt-Out");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminHavingPermissionsToEditDelawareARNotificationOptOut(String ReportSheet, int count)
			throws Throwable {
		try {
			blnEventReport = true;
			delawareARNotificationOptOutOnAffiliation(ReportSheet, count);
			// Click On Cancel Button
			click(Affiliation.CANCELBTN, "Cancel Button");
			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");

			// Check Delaware AR Notification Opt-Out checkbox
			click(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX, "Delaware AR Notification Opt-Out checkbox");

			// Enter comments and click on save button
			type(Affiliation.COMMENTFIELD, "Testing", "Comments Textbox");
			click(Affiliation.SAVEBTN, "Save Button");

			// Verify Delaware AR Notification Opt-Out default value is Yes
			assertTextMatching(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE, "Yes",
					"Delaware AR Notification Opt-Out Value");

			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");

			// Verify Delaware AR Notification Opt-Out checkbox is checked
			assertElementPresent(Affiliation.CHECKED_DELAWARE_NOTIFICATION_OPT_OUT,
					"Checked Delaware AR Notification Opt-Out");

			// UnCheck Delaware AR Notification Opt-Out checkbox
			click(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX, "Delaware AR Notification Opt-Out checkbox");
			// Enter comments and click on save button
			type(Affiliation.COMMENTFIELD, "Testing", "Comments Textbox");
			click(Affiliation.SAVEBTN, "Save Button");
			assertTextMatching(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_VALUE, "No",
					"Delaware AR Notification Opt-Out Value");

		} catch (Exception e) {
			throw e;
		}

	}

	public void adminNotHavingPermissionsToEditDelawareARNotificationOptOut(String ReportSheet, int count)
			throws Throwable {
		try {
			blnEventReport = true;
			String strId = Excelobject.getCellData(ReportSheet, "AffiliationID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "Affiliation Profile", "Page Title");

			// Click On Affiliation Edit Btn
			click(Affiliation.EDITBTN, "Edit Button");

			// Verify Delaware AR Notification Opt-Out checkbox is disabled
			isDisabled(Affiliation.DELAWARE_NOTIFICATION_OPT_OUT_CHECKBOX, "Delaware AR Notification Opt-Out checkbox");

		} catch (Exception e) {
			throw e;
		}

	}

	public void fileAndEventSelectionPageUploadFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Verify Delaware Event Label and its dropdown
			assertElementPresent(Admin.DELAWARE_EVENT_LABEL, "Delaware Event Label");
			assertElementPresent(Admin.DELAWARE_EVENT_DROPDOWN, "Delaware Event Dropdown");

			// Verify File Upload Label and its dropdown
			assertElementPresent(Admin.FILE__UPLOAD_LABEL, "File Uplaod Label");

			// Verify Production and Test radio button
			assertElementPresent(Admin.PRODUCTION_RADIO_BTN, "Production radio button");
			assertElementPresent(Admin.TEST_RADIO_BTN, "Test radio button");

			// Verify Production radio button is checked by default
			assertElementPresent(Admin.CHECKED_PRODUCTION_RADIO_BTN, "Checked Production radio button");

			// Click on Upload Button
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			// Verify the error messages
			assertElementPresent(Admin.DELAWARE_EVENT_ERR_MSG, "Delaware Event Error Message");
			assertElementPresent(Admin.FILE_UPLOAD_ERR_MSG, "File Upload Error Message");

			// Verify Choose File Button,Upload Button and Cancel Button is present
			assertElementPresent(Admin.CHOOSE_FILE_BUTTON, "Choose File Button");
			assertElementPresent(Admin.UPLOAD_BUTTON, "Upload Button");
			assertElementPresent(Admin.CANCEL_BUTTON, "Cancel Button");

			// Select an Event from Dropdown and click on choose file button
			selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, delawareEventName,
					"Select a Delaware Event from delaware event drop down box");

			if (fileName.contains("1 KB")) {
				// Upload 1 kb File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");

			} else if (fileName.contains("0 KB")) {
				// Upload 0 kb File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				assertTextMatching(Admin.ERROR, "Select a valid DAT file.", "Error");
			} else if (fileName.contains("Invalid File")) {
				// Upload an invalid File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				handlepopup();

			} else if (fileName.contains("Less than 150 MB")) {
				// Upload a 120 MB File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");

			} else if (fileName.contains("Greater than 150 MB")) {
				// Upload a 120 MB File
				uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
				handlepopup();

			}
			Thread.sleep(7000);

		} catch (Exception e) {
			throw e;
		}

	}

	public void fileAndEventSelectionPageGridFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware Event Name", count);
			String fileNameOf50Records = Excelobject.getCellData(ReportSheet, "File Name Of 50 Records", count);

			// Navigate to File and Event Selection Page
			verifyDEARNotificationsSection(ReportSheet, count);

			// Check Filters
			click(Admin.EVENT_ID_FILTER_DRPDWN, "Select event id from filter dropdown");
			click(Admin.EVENT_NAME_FILTER_DRPDWN, "Select event name from filter dropdown");
			click(Admin.IS_PROD_FILTER_DRPDWN, "Select Is Prod from filter dropdown");
			click(Admin.STATUS_FILTER_DRPDWN, "Select status from filter dropdown");

			// Check Sorting Links
			assertElementPresent(Admin.ACTIVE_EVENT_ID_SORT_LINK, "Active Event ID Sort link");
			assertElementPresent(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Status Sort Link");
			assertElementPresent(Admin.INACTIVE_UPDATED_ON_SORT_LINK, "Inactive Updated On Sort Link");
			click(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.ACTIVE_EVENT_NAME_SORT_LINK, "Active Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_EVENT_ID_SORT_LINK, "Inactive Event Name Sort Link");
			click(Admin.INACTIVE_STATUS_SORT_LINK, "Inactive Status Sort Link");
			assertElementPresent(Admin.ACTIVE_STATUS_SORT_LINK, "Active Status Sort Link");
			click(Admin.INACTIVE_UPDATED_ON_SORT_LINK, "Inactive Updated On Sort Link");
			assertElementPresent(Admin.ACTIVE_UPDATED_ON_SORT_LINK, "Active Updated On Sort Link");

			// Check Pagination
			assertElementPresent(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");
			assertElementPresent(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			assertElementPresent(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			assertElementPresent(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");

			// Verify Grid Columns
			assertElementPresent(Admin.EVENT_ID_COLUMN, "Event Id Column");
			assertElementPresent(Admin.EVENT_NAME_COLUMN, "Event Name Column");
			assertElementPresent(Admin.FILE_NAME_COLUMN, "File Name Column");
			assertElementPresent(Admin.COUNT_COLUMN, "Count Column");
			assertElementPresent(Admin.IS_PROD_COLUMN, "Is Prod Column");
			assertElementPresent(Admin.STATUS_COLUMN, "Status Column");
			assertElementPresent(Admin.UPLOADED_BY_COLUMN, "Uploaded By Column");
			assertElementPresent(Admin.UPDATED_ON_COLUMN, "Updated On Column");

			// Verify Current Filter label
			assertElementPresent(Admin.CURRENT_FILTER_LABEL, "Current Filter Label");

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");
			click(Admin.TEST_RADIO_BTN, "Test Radio Button");
			uploadFile(fileNameOf50Records, Admin.CHOOSE_FILE_BUTTON, "Upload File");

			// Upload the file
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			// Verify the data on the grid
			assertElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
			assertTextMatching(Admin.STATUS, "Uploaded", "Status of the File");
			String eventId = getText(Admin.FIRST_EVENT_ID_ON_GRID, "First Event Id On Grid");
			// assertTextMatching(Admin.FIRST_EVENT_NAME_ON_GRID, delawareEventName, "Event
			// Name On Grid");
			assertTextMatching(Admin.FIRST_FILE_NAME_ON_GRID, fileNameOf50Records, "File Name On Grid");
			assertTextMatching(Admin.FIRST_COUNT_ON_GRID, "--", "Count On Grid");
			assertTextMatching(Admin.FIRST_IS_PROD_ON_GRID, "N", "Is Prod On Grid");
			assertTextMatching(Admin.FIRST_UPLOADED_BY_ON_GRID, "TEST New York SOP Team", "Updated By On Grid");
			// TODO verify updated by
			Thread.sleep(30000);
			refreshPage();
			// isElementNotPresent(Admin.UPLOADED_STATUS, "Staus of the file as uploaded");
			// isElementNotPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On
			// Grid");
			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			click(Admin.BACK_BTN, "Back Button");

			// Verify Delete Functionality
			click(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
			handlepopup();

			// Select Event Id from filter drpdwn
			click(Admin.EVENT_ID_FILTER_DRPDWN, "Select Event Id Filter dropdown");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "=", "Select = from second filter");
			type(Admin.FILTER_TEXT_BOX, eventId, "Filter text Box");
			click(Admin.GO_BTN, "Go Button");

			// Verify No Records Found text
			assertElementPresent(Admin.NO_RECORDS_FOUND_ON_GRID, "No Records Found Text");

		} catch (Exception e) {
			throw e;
		}

	}

	public void fileAndEventSelectionPageCountAndDownloadFunctionality(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware Event Name", count);
			String fileNameHavingErrorRecords = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");

			// Select an Event from Dropdown and click on choose file button
			// selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, delawareEventName,
			// "Select a Delaware Event from delaware event drop down box");
			click(Admin.TEST_RADIO_BTN, "Test Radio Button");
			uploadFile(fileNameHavingErrorRecords, Admin.CHOOSE_FILE_BUTTON, "Upload File");

			// Upload the file
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			// TODO Verify Count
			// Verify File uploaded is downloadable
			click(Admin.FIRST_FILE_NAME_ON_GRID, "Download File Uploaded On Grid");

		} catch (Exception e) {
			throw e;
		}

	}

	public void addEditDeleteEvent(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String eventName = Excelobject.getCellData(ReportSheet, "Event Name", count);
			String eventType = Excelobject.getCellData(ReportSheet, "Event Type", count);
			String entityType = Excelobject.getCellData(ReportSheet, "Entity Type", count);
			String member = Excelobject.getCellData(ReportSheet, "Member", count);
			String editEventName = Excelobject.getCellData(ReportSheet, "Edit Event Name", count);
			String editEventType = Excelobject.getCellData(ReportSheet, "Edit Event Type", count);
			String editEntityType = Excelobject.getCellData(ReportSheet, "Edit Entity Type", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			// Click On Event Manager from left nav link
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");

			// Verify the page title is Event Manager
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");

			// Verify help icon
			assertElementPresent(Admin.HELP_ICON, "Help Icon");

			// Click on add/save btn
			click(Admin.EVENT_ADD_BTN, "Add/Save Button");
			// Verify error messages
			assertElementPresent(Admin.EVENT_NAME_ERR_MSG, "Event Name Error Message");
			assertElementPresent(Admin.EVENT_TYPE_ERR_MSG, "Event Type Error Message");
			assertElementPresent(Admin.ENTITY_TYPE_ERR_MSG, "Entity Type Error Message");

			// Enter Event Name,Event Type,Entity Type
			type(Admin.EVENT_NAME_TEXTBOX, eventName, "Event Name Textbox");
			selectBySendkeys(Admin.EVENT_TYPE_DRPDWN, eventType, "Event Type Dropdown");
			selectBySendkeys(Admin.ENTITY_TYPE_DRPDWN, entityType, "Entity Type Dropdown");
			assertElementPresent(Admin.NO_OPT_OUT_SUPPRESSION__RADIO_BTN, "No is selected for opt out suppression");
			assertElementPresent(Admin.NO_ARMS_SUPPRESSION__RADIO_BTN, "No is selected for arms suppression");
			assertElementPresent(Admin.NO_BFI_CTPRO_SUPPRESSION__RADIO_BTN, "No is selected for bfi/ctpro suppression");
			click(Admin.YES_OPT_OUT_SUPPRESSION__RADIO_BTN, "Yes for opt out suppression");
			click(Admin.YES_ARMS_SUPPRESSION__RADIO_BTN, "Yes for arms suppression");
			click(Admin.YES_BFI_CTPRO_SUPPRESSION__RADIO_BTN, "Yes for bfi/ctpro suppression");
			assertElementPresent(Admin.EVENT_CANCEL_BTN, "Cancel Button");
			click(Admin.EVENT_ADD_BTN, "Add Button");

			// Check Sorting Links
			assertElementPresent(Admin.ACTIVE_UPDATED_ON_SORT_LINK, "Active Updated On Sort Link");
			assertElementPresent(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_EVENT_TYPE_SORT_LINK, "Inactive Event Type Link");
			assertElementPresent(Admin.INACTIVE_ENTITY_TYPE_SORT_LINK, "Inactive Entity Type Sort Link");
			click(Admin.INACTIVE_EVENT_NAME_SORT_LINK, "Inactive Event Name Sort Link");
			assertElementPresent(Admin.ACTIVE_EVENT_NAME_SORT_LINK, "Active Event Name Sort Link");
			assertElementPresent(Admin.INACTIVE_UPDATED_ON_SORT_LINK, "Inactive Updated On Sort Link");
			click(Admin.INACTIVE_EVENT_TYPE_SORT_LINK, "Inactive Event Type Sort Link");
			assertElementPresent(Admin.ACTIVE_EVENT_TYPE_SORT_LINK, "Active Event Type Link");
			click(Admin.INACTIVE_ENTITY_TYPE_SORT_LINK, "Inactive Entity Type Sort Link");

			// Check Pagination
			assertElementPresent(Admin.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");
			assertElementPresent(Admin.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			assertElementPresent(Admin.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			assertElementPresent(Admin.LAST_PAGE_LINK, "Click on Last Link to display Last Page");

			// Verify Grid Columns
			assertElementPresent(Admin.EVENT_NAME_COLUMN_ON_EVENT_MANAGER, "Event Name Column");
			assertElementPresent(Admin.EVENT_TYPE_COLUMN_ON_EVENT_MANAGER, "Event Type Column");
			assertElementPresent(Admin.ENTITY_TYPE_COLUMN_ON_EVENT_MANAGER, "Entity Type Column");
			assertElementPresent(Admin.UPDATED_BY_COLUMN_ON_EVENT_MANAGER, "Updated By Column");
			assertElementPresent(Admin.UPDATED_ON_COLUMN_ON_EVENT_MANAGER, "Updated On Column");

			// Verify the event added on the grid
			assertTextMatching(Admin.FIRST_EVENT_NAME_ON_EVENT_DETAILS_GRID, eventName, "First Event Name On Grid");
			assertTextMatching(Admin.OPT_OUT_SUPPRESSION_VALUE, "Y", "First Opt Out Suppression Value On Grid");
			assertTextMatching(Admin.FIRST_EVENT_TYPE_ON_EVENT_DETAILS_GRID, eventType, "First Event Type On Grid");
			assertTextMatching(Admin.ARMS_SUPPRESSION_VALUE, "Y", "First ARMS Suppression Value On Grid");
			assertTextMatching(Admin.FIRST_ENTITY_TYPE_ON_EVENT_DETAILS_GRID, entityType, "First Entity Type On Grid");
			assertTextMatching(Admin.BFI_CTPRO_SUPPRESSION_VALUE, "Y", "First Bfi/Ctpro Suppression Value On Grid");
			assertTextMatching(Admin.FIRST_UPDATED_BY_ON_EVENT_DETAILS_GRID, member, "First Updated By On Grid");
			assertElementPresent(Admin.FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID, "First Edit Button On Grid");
			assertElementPresent(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First Delete Button On Grid");
			Thread.sleep(5000);

			// Edit Event
			click(Admin.FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID, "First Edit Button On Grid");
			type(Admin.EVENT_NAME_TEXTBOX, editEventName, "Event Name Textbox");
			selectBySendkeys(Admin.EVENT_TYPE_DRPDWN, editEventType, "Event Type Dropdown");
			selectBySendkeys(Admin.ENTITY_TYPE_DRPDWN, editEntityType, "Entity Type Dropdown");
			click(Admin.EVENT_ADD_BTN, "Add Button");
			Thread.sleep(5000);
			refreshPage();
			assertTextMatching(Admin.FIRST_EVENT_NAME_ON_EVENT_DETAILS_GRID, editEventName, "First Event Name On Grid");
			assertTextMatching(Admin.FIRST_EVENT_TYPE_ON_EVENT_DETAILS_GRID, editEventType, "First Event Type On Grid");
			assertTextMatching(Admin.FIRST_ENTITY_TYPE_ON_EVENT_DETAILS_GRID, editEntityType,
					"First Entity Type On Grid");

			// Upload a file for this event on file and event selection page
			// Click On File & Event Selection link from left nav bar
			click(Admin.FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK, "File & Event Selection Link");

			// Verify the page title is File And Event Selection
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");
			selectBySendkeys(Admin.DELAWARE_EVENT_DROPDOWN, editEventName,
					"Select a Delaware Event from delaware event drop down box");

			// Upload 1 kb File
			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(5000);
			// Check There is no delete button on event manager page for this event
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");
			isElementNotPresent(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First Delete Button On Grid");
			click(Admin.FIRST_EDIT_BTN_ON_EVENT_DETAILS_GRID, "First Edit Button On Grid");
			// Edit this event
			getAttribute(Admin.EVENT_NAME_TEXTBOX, "disabled");
			getAttribute(Admin.EVENT_TYPE_DRPDWN, "disabled");
			getAttribute(Admin.ENTITY_TYPE_DRPDWN, "disabled");
			click(Admin.NO_OPTOUT_SUPPRESSION__RADIO_BTN, "No is selected for opt out suppression");
			click(Admin.EVENT_ADD_BTN, "Add/save Button");
			assertTextMatching(Admin.OPT_OUT_SUPPRESSION_VALUE, "N", "First Opt Out Suppression Value On Grid");

			Thread.sleep(5000);
			// Delete the file uploaded on file and event selection page
			// Click On File & Event Selection link from left nav bar
			click(Admin.FILE_AND_EVENT_SELECTION_LEFT_NAV_LINK, "File & Event Selection Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");
			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;
				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Delete the file
			click(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
			handlepopup();

			// Delete the event
			click(Admin.EVENT_MANAGER_LEFT_NAV_LINK, "Event Manager Link");
			assertTextMatching(Admin.PAGE_TITLE, "Event Manager", "Page Title");
			click(Admin.FIRST_DELETE_BTN_ON_EVENT_DETAILS_GRID, "First Delete Button On Grid");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

	public void outputFilesPageVerification(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			String eventId = getText(Admin.FIRST_EVENT_ID_ON_GRID, "First Event Id On Grid");
			String eventName = getText(Admin.FIRST_EVENT_NAME_ON_GRID, "First Event Name On Grid");
			String isProd = getText(Admin.FIRST_IS_PROD_ON_GRID, "First Is Prod On Grid");
			String status = getText(Admin.FIRST_STATUS_ON_GRID, "First Status On Grid");

			System.out.println(eventId + "." + eventName + "." + isProd + "." + status);
			// Click on First View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");

			// Verify event name,test/production and event id on context bar
			assertTextMatching(Admin.EVENT_NAME_ON_CONTEXTBAR, eventName, "Event Name On Context bar");
			String eventIdOnContextBar = getText(Admin.EVENT_ID_ON_CONTEXTBAR, "Event Id On Context Bar");
			assertTextContains(eventIdOnContextBar, eventId);
			/*
			 * if (isProd.equalsIgnoreCase("N")) {
			 * assertElementPresent(Admin.TEST_ON_CONTEXTBAR, "Test On Context bar");
			 * 
			 * } else if (isProd.equalsIgnoreCase("Y")) {
			 * assertElementPresent(Admin.PRODUCTION_ON_CONTEXTBAR,
			 * "Production On Context bar");
			 * 
			 * }
			 */ assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, status, "Status on output files page");
			assertElementPresent(Admin.PRINTER_OUTPUT_FILES_LABEL, "Printer output files label");
			assertElementPresent(Admin.ADDITIONAL_OUTPUT_FILES_LABEL, "Additional output files label");
			assertElementPresent(Admin.PRINTER_ACKNOWLEDGE_FILES_LABEL, "Printer Acknowledge files label");
			click(Admin.PRINT_FILE, "Print File");
			click(Admin.DISCREPANCY_FILE, "Discrepancy File");
			click(Admin.SUPPRESSION_FILE, "Suppression File");
			click(Admin.UNMATCH_FILE, "Unmatch File");
			assertElementPresent(Admin.CHOOSE_FILE_BTN, "Choose File Button");
			assertElementPresent(Admin.UPLOAD_BUTTON, "Upload File Button");
			assertElementPresent(Admin.CANCELBTN, "Cancel Button");
			click(Admin.BACKBTN, "Back Button");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

		} catch (Exception e) {
			throw e;
		}

	}

	public void filesUploadOnOutputFilesPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware
			// Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Click on First View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");

			if (fileName.contains("More than 0 KB")) {
				// Upload More than 0 kb csv File
				uploadFile(fileName, Admin.CHOOSE_FILE_BTN, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				//click(Admin.PRINTER_ACKNOWLEDGE_FILE, "Printer Acknowledge File");
				assertElementPresent(Admin.CREATE_COMM_BTN, "Create COMM Button");
				click(Admin.DELETE_IMG, "Delete Image");
				handlepopup();
				assertElementPresent(Admin.CHOOSE_FILE_BTN, "Choose File Button");

			} else if (fileName.contains("0 KB")) {
				// Upload 0 kb File
				uploadFile(fileName, Admin.CHOOSE_FILE_BTN, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				assertTextMatching(Admin.ERROR, "Select a valid CSV file.", "Error");
			} else if (fileName.contains("Invalid CSV File")) {
				// Upload an invalid File
				uploadFile(fileName, Admin.CHOOSE_FILE_BTN, "Upload File");
				click(Admin.UPLOAD_BUTTON, "Upload Button");
				assertTextMatching(Admin.ERROR, "Select a CSV file.", "Error");

			}
		} catch (Exception e) {
			throw e;
		}

	}

	public void printerAcknowledgeFilesSection(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware
			// Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");
			click(Admin.TEST_RADIO_BTN, "Test Radio Button");

			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(30000);
			refreshPage();

			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			isElementNotPresent(Admin.PRINTER_ACKNOWLEDGE_FILES_LABEL, "Printer Acknowledge Files(s) section");
			click(Admin.BACK_BTN, "Back Button");
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");
			handlepopup();

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");

			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(30000);
			refreshPage();

			flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			isElementPresent(Admin.PRINTER_ACKNOWLEDGE_FILES_LABEL, "Printer Acknowledge Files(s) section");
			click(Admin.BACK_BTN, "Back Button");
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");
			handlepopup();

		} catch (Exception e) {
			throw e;
		}

	}

	public void uploadGoodRecordAndBadRecordFile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// String delawareEventName = Excelobject.getCellData(ReportSheet, "Delaware
			// Event Name", count);
			String fileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String badRecordCSVfileName = Excelobject.getCellData(ReportSheet, "Bad Record CSV File Name", count);
			String goodRecordCSVfileName = Excelobject.getCellData(ReportSheet, "Good Record CSV File Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// Click On DE AR Notifications link from left nav bar
			click(Admin.DE_AR_NOTIFICATIONS_LEFT_NAV_LINK, "DE AR Notifications Link");
			assertTextMatching(Admin.PAGE_TITLE, "File and Event Selection", "Page Title");

			// Select an Event from Dropdown and click on choose file button
			selectByIndex(Admin.DELAWARE_EVENT_DROPDOWN, 1,
					"Select a Delaware Event from delaware event drop down box");

			uploadFile(fileName, Admin.CHOOSE_FILE_BUTTON, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			Thread.sleep(30000);
			refreshPage();

			boolean flag = true;
			do {
				if (verifyIfElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid")) {
					assertTextMatching(Admin.STATUS, "Output Files Ready", "Status of the File");
					// assertElementPresent(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View
					// Results Link On Grid");
					verifyIfElementPresent(Admin.FIRST_DELETE_BTN_ON_GRID, "First Delete Button On Grid");
					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);

			// Verify View Results Link
			click(Admin.FIRST_VIEW_RESULTS_LINK_ON_GRID, "First View Results Link On Grid");
			assertTextMatching(Admin.PAGE_TITLE, "Output Files", "Page Title");
			// Upload a bad record csv File
			uploadFile(badRecordCSVfileName, Admin.CHOOSE_FILE_BTN, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");
			// Verify the error message
			assertTextMatching(Admin.ERROR_MSG, "There is invalid data in uploaded file at line 2.", "Error Message");
			click(Admin.CANCEL_BTN, "Cancel Button");
			Thread.sleep(2000);
			isElementNotPresent(Admin.ERROR_MSG, "Error Message");

			// Upload good record csv File
			uploadFile(goodRecordCSVfileName, Admin.CHOOSE_FILE_BTN, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");

			isElementNotPresent(Admin.UPLOAD_BUTTON, "Upload Button");
			isElementNotPresent(Admin.CHOOSE_FILE_BTN, "Upload File");
			isElementNotPresent(Admin.CANCEL_BTN, "Cancel Button");
			assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, "Acknowledged By Printer", "Status");

			click(Admin.FILE_LINK, "File Link");
			assertTextMatching(Admin.UPDATED_BY, "TEST New York SOP Team", "Updated By");
			click(Admin.DELETE_IMG, "Delete Button");
			handlepopup();

			Thread.sleep(2000);

			// Upload good record csv File
			uploadFile(goodRecordCSVfileName, Admin.CHOOSE_FILE_BTN, "Upload File");
			click(Admin.UPLOAD_BUTTON, "Upload Button");
			
			Thread.sleep(2000);
			click(Admin.CREATE_COMM_BTN, "Create COMM Button");
			cancelpopup();
			
			click(Admin.CREATE_COMM_BTN, "Create COMM Button");
			handlepopup();
			assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, "Creating COMM", "Status");
			isElementNotPresent(Admin.DELETE_IMG, "Delete Button");
			getAttribute(Admin.CREATE_COMM_BTN, "disabled");

			flag = true;
			do {
				if (verifyIfElementPresent(Admin.DELETE_IMG, "Delete Button")) {
					assertTextMatching(Admin.STATUS_ON_OUTPUT_FILES_PAGE, "COMM Error", "Status");
					getAttribute(Admin.CREATE_COMM_BTN, "disabled");

					flag = false;
					break;

				} else {
					refreshPage();
					flag = true;
				}
			} while (flag);
			click(Admin.DELETE_IMG, "Delete Button");
			handlepopup();
			assertElementPresent(Admin.UPLOAD_BUTTON, "Upload Button");
			click(Admin.BACK_BTN,"Back Button");
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");
			handlepopup();


		} catch (Exception e) {
			throw e;
		}

	}

}
