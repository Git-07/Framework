package com.arrow.workflows;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.RenewalInvoice;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.objectrepo.XSOP;

public class BusinessFunctions_XSOP extends BusinessFunctions {


	/********************************************************************************************************
	 * Method Name : xsopRevise() Author : Pradyumna Description : This method will
	 * Revise XSOP Invoice Date of creation : 11/12/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String xsopRevise(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on Renewal Invoice Search link on Home page
			click(HomePage.RENEWAL_INVOICE_SEARCH_LINK, "Renewal Invoice Search Link");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_SEARCH_PAGE, "Renewal Invoice Search Page");
			// Search for XSOP Invoice by Status and Date
			click(XSOP.XSOP_INVOICE_SEARCH, "XSOP Invoice Search");
			assertElementPresent(XSOP.XSOP_INVOICE_SEARCH_PAGE, "XSOP Invoice Search Page");
			// click(XSOP.INVOICE_STATUS, "Open Invoice Status");
			// Change Below Date one day ahead before executing this script.e.g If date is
			// 10/03/2019 change it to 10/04/2019
			type(RenewalInvoice.XSOP_INVOICEID_TEXTBOX, "19801052", "Invoice Id Text Box");
			click(Generic.SEARCH, "Search Button");
			// Search Results should be displayed
			// assertElementPresent(XSOP.XSOP_INVOICE_RESULT_PAGE, "XSOP Invoice Result
			// Page");
			// String invoiceID=getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");
			// click(Generic.FIRST_RESULT, "First Result");
			assertElementPresent(XSOP.XSOP_PROFILE, "XSOP Profile");
			// Click on Revise Button
			moveToElement(RenewalInvoice.REVISE_BTN, "Scroll to Revise Button");
			click(RenewalInvoice.REVISE_BTN, "Revise Button");

			// Click on XSOP Invoice Adjustment Button
			click(RenewalInvoice.XSOP_INVOICE_ADJUSTMENT_BUTTON, "XSOP Invoice Adjustment Button");
			// Handle Popup
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");

			assertTextMatching(Admin.PAGE_TITLE, "XSOP Invoice Adjustment", "Title of the page");

			driver.close();
			driver.switchTo().window(parentWindow);

			assertElementPresent(XSOP.ORDER_PREVIEW_PAGE, "Order Preview Page");
			click(XSOP.MAIL_TO_RECIPIENT_DROPDOWN, "Mail to Recipient Dropdown");
			click(XSOP.AFF_MAINTENANCE_DROPDOWN, "Aff Maintenance Dropdown");
			// click(Generic.SUBMIT_BTN, "Submit Button");
			// Check if Revised Invoice is displayed
			/*
			 * click(XSOP.INVOICE_ID_DROPDOWN, "Invoice ID Dropdown");
			 * click(Generic.SECOND_DROP_EQUALS2, "Invoice ID Dropdown");
			 * type(Generic.DROP_DOWN_TEXT, invoiceID, "Invoice ID entered");
			 * click(Generic.GO_BUTTON, "Invoice ID Dropdown");
			 * assertElementPresent(XSOP.XSOP_INVOICE_RESULT_PAGE,
			 * "XSOP Invoice Result Page"); assertElementPresent(XSOP.REVISED_REASON,
			 * "Revised Reason");
			 */

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String estimateExcessSOPVerification(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Page Title");

			// CLick on XSOP Invoices Left nav link
			click(Entity.XSOP_INVOICES_LEFT_NAV_LINK, "Xsop Invoices Left Nav Link");
			assertTextMatching(Entity.PAGE_TITLE, "XSOP Invoices", "Page Title");

			// Click o Generate Current Estimate Button
			click(Entity.GENERATE_CURRENT_ESTIMATE_BTN, "Generate Curren Estimate");

			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(Admin.SERVER_ERROR, "Server Error Text");

			assertElementPresent(Entity.ESTIMATE_EXCESSS_SOP_TEXT, "Estimate Excess SOP Text");

			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

}
