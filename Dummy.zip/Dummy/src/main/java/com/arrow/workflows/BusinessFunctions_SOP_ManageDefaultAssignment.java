package com.arrow.workflows;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Carrier_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.ManageDefaultAssignment_SOP;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP_ManageDefaultAssignment extends BusinessFunctions_SOP{
	
	public void editmanageDefaultAssignment(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");		
			//Click On Manage Default Assignment from left nav bar
			click(SOP.MANAGE_DEFAULT_ASSIGNMENT_LEFT_NAV_LINK,"Manage Default Assignment Link from left nav bar");	
			//Click On First Edit Button On Grid
			click(ManageDefaultAssignment_SOP.FIRST_EDIT_BTN_ON_GRID,"First Edit Btn On Grid");
			//Select any Jurisdiction from grid
			selectBySendkeys(ManageDefaultAssignment_SOP.JURIS_DRPDWN, "Arizona", "Received By Jurisdiction Dropdown");
			//Click On Save Btn
			click(SOP.SAVE_BTN,"Save Button");
			

		} catch (Exception e) {
			throw e;
		}

	}
	
	public void addAndDeleteDefaultAssignment(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			//Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");
			//Click On Manage Default Assignment from left nav bar
			click(SOP.MANAGE_DEFAULT_ASSIGNMENT_LEFT_NAV_LINK,"Manage Default Assignment Link from left nav bar");
			//Click On Add New Button
			click(ManageDefaultAssignment_SOP.ADD_NEW_BTN,"Add New Button");
			//Enter SOP Source
			type(ManageDefaultAssignment_SOP.SOP_SOURCE_TEXTBOX, "AAAA", "SOP Source TextBox");			
			//Select any Jurisdiction from grid
			selectBySendkeys(ManageDefaultAssignment_SOP.JURIS_DRPDWN, "Arizona", "Received By Jurisdiction Dropdown");
			//Select Received By Facility
			waitForElementPresent(ManageDefaultAssignment_SOP.RECEIVED_BY_FACILITY_DRPDWN,"Received By Facility Dropdown");
			selectByIndex(ManageDefaultAssignment_SOP.RECEIVED_BY_FACILITY_DRPDWN,3, "Received By Facility Dropdown");
			//Select Default Received By Team 
			waitForElementPresent(ManageDefaultAssignment_SOP.DEFAULT_RECEIVED_BY_TEAM_DRPDWN,"Default Received By Team Dropdown");
			selectByIndex(ManageDefaultAssignment_SOP.DEFAULT_RECEIVED_BY_TEAM_DRPDWN,1, "Default Received By Team Dropdown");
			//Select Default Assigned Team 
			waitForElementPresent(ManageDefaultAssignment_SOP.DEFAULT_ASSIGNED_TEAM_DRPDWN,"Default Assigned Team Dropdown");
			selectByIndex(ManageDefaultAssignment_SOP.DEFAULT_ASSIGNED_TEAM_DRPDWN,4, "Default Assigned Team Dropdown");
			//Click On Save Btn
			waitForElementPresent(SOP.SAVE_BTN,"Save Button");
			click(SOP.SAVE_BTN,"Save Button");
			//Click On Sort By SOP Source Link
			click(ManageDefaultAssignment_SOP.SORT_BY_SOP_SOURCE_LINK,"SOP Source Link");
			//Click On delete Button
			click(ManageDefaultAssignment_SOP.FIRST_DELETE_BTN_ON_GRID,"First Delete Btn On Grid");
			//Handle Popup
			handlepopup();				

		} catch (Exception e) {
			throw e;
		}

	}


	

}
