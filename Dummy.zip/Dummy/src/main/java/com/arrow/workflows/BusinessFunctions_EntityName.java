package com.arrow.workflows;

import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.WorksheetCreate;

public class BusinessFunctions_EntityName extends BusinessFunctions_Entity{
	
	/********************************************************************************************************
	 * Method Name : crossReferenceName() 
	 * Author : Pradyumna 
	 * Description : This method will verify crossReferenceName for Entity
	 * Date of creation : 9/2/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String crossReferenceName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			createEntity(ReportSheet, count);
			// Click On Action Items Tab
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Entity.CREATE_CROSSREFERENCE_NAME_BTN, "Create Cross Reference Name Button");
			assertElementPresent(Entity.CREATE_CROSSREFERENCE_PAGE, "Entity Name Page");
			type(Entity.CROSSREFERENCE_TEXT, "Cross Reference Text for Testing", "Cross-Reference Name Text");
			click(Entity.REQUEST_DATE, "Request Date");
			click(Entity.TODAYSDATE, "Today's Date");
			type(Generic.COMMENTS, "Comments for Testing", "Comment Text Entered");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Croos-Reference Page");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Name Type", "Name Type");
			selectBySendkeys(Generic.SELECT_2ND_DROPDOWN, "Cross Ref Name", "Cross Ref Name");
			click(Generic.GO_BUTTON, "Go Button");
			click(Generic.FIRST_DATA, "Select First Data Link");
			assertElementPresent(Entity.VIEW_CROSSREFERENCE_PAGE, "View Cross Reference Page");
			click(Generic.EDIT_NAME_LIST, "Edit Name List");
			assertElementPresent(Entity.EDIT_CROSSREFERENCE_PAGE, "Edit Cross Reference Page");
			type(Generic.COMMENTS, "Re-entered Comments for Testing", "Comment Text Re-entered");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.VIEW_CROSSREFERENCE_PAGE, "View Cross Reference Page");
			click(Generic.EDIT_NAME_LIST, "Edit Name List");
			assertElementPresent(Entity.EDIT_CROSSREFERENCE_PAGE, "Edit Cross Reference Page");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(Entity.VIEW_CROSSREFERENCE_PAGE, "View Cross Reference Page");
			click(Entity.RETURN_TO_NAME_LIST, "Return to Name List Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	
	/********************************************************************************************************
	 * Method Name : assumedName() 
	 * Author : Pradyumna 
	 * Description : This method will verify assumed Name for Entity
	 * Date of creation : 9/2/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String assumedName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strNumberOfYears = Excelobject.getCellData(ReportSheet, "NumberOfYears", count);
			//Create New Entity
			createEntity(ReportSheet, count);
			//add New Hampshire Rep
			click(Rep.REPRESENTATION_TAB, "Representation Tab");
			click(Rep.CREATE_REPRESENTATION, "Create Representation Button");
			click(Rep.NH_JURISDICTION, "Select NH Jurisdiction");
			click(Rep.DOMESTIC_REP, "Domestic Rep");
			click(Generic.NEXT_BUTTON, "Next Button");
			assertElementPresent(Rep.NEW_REPRESENTATION_UNIT_PAGE, "Rep Unit Page");
			type(Entity.STATE_ID,"1234567", "State ID");			
			click(Rep.FILING_DATE_BUTTON, "Filing Date Button");
			click(Rep.TODAYSDATE, "Select Today's Date");
			click(Generic.SAVE, "Save Button");
			//Click on Names Link Tab
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Entity.CREATE_ASSUMED_NAME_BTN, "Create Assumed Name Button");
			assertElementPresent(Entity.CREATE_ASSUMEDNAME_PAGE, "Create Assumed Name Page");
			type(Entity.ASSUMED_NAME_TEXT, "Assumed Name Text for Testing", "Assumed Name Text");
			click(Entity.RADIO_QUALIFIED, "Radio button Qualified");
			click(Entity.NEW_HAMPSHIRE_JURISDICTION,"New Hampshire Dropdown");
			click(Entity.FILING_DATE, "Filing Date");
			click(Entity.TODAYSDATE, "Today's Date");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Name Type", "Name Type");
			selectBySendkeys(Generic.SELECT_2ND_DROPDOWN, "Assumed Name", "Assumed Name Dropdown");
			click(Generic.GO_BUTTON, "Go Button");
			click(Generic.FIRST_DATA, "Select First Data Link");
			assertElementPresent(Entity.VIEW_ASSUMEDNAME_PAGE, "View Assumed Name Page");
			//Edit Only Name
			click(Generic.EDIT_NAME, "Edit Name");
			type(Entity.ASSUMED_NAME_TEXT, "Edited-Assumed Name Text for Testing", "Edit Assumed Name Text");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.EDITED_ASSUMED_NAME_TEXT, "Edited Assumed Name");
			//Edit Image Button 
			click(Generic.EDIT_BUTTON, "Edit Button");
			click(Entity.RADIO_VOLUNTARY, "Radio button Voluntary");
			click(Entity.NEW_HAMPSHIRE_JURISDICTION,"New Hampshire Dropdown");
			click(Entity.CALCULATE_END_DATE, "Calculate End Date Button");
			//click(Entity.DISCONTINUE_DATE, "Discontinue End Date Button");
			//click(Entity.TODAYSDATE, "Today's Date");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.VIEW_ASSUMEDNAME_PAGE, "View Assumed Name Page");
			//Add Jurisdiction
			click(Entity.ADD_JURISDICTION, "Add Jurisdiction");
			assertElementPresent(Entity.JURISDICTION_PAGE, "Jurisdiction Page");
			click(Entity.RADIO_QUALIFIED, "Radio button Qualified");
			click(Entity.NEW_HAMPSHIRE_JURISDICTION,"New Hampshire Dropdown");
			click(Entity.FILING_DATE, "Filing Date");
			click(Entity.TODAYSDATE, "Today's Date");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.JURISDICTION_ERROR, "Jurisdiction Error Page");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(Entity.VIEW_ASSUMEDNAME_PAGE, "View Assumed Name Page");
			click(Entity.RETURN_TO_NAME, "Return to Name Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	
	/********************************************************************************************************
	 * Method Name : formerName() 
	 * Author : Pradyumna 
	 * Description : This method will verify former for Entity
	 * Date of creation : 9/3/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String formerName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			createEntity(ReportSheet, count);
			// Click on Names Link
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Entity.CREATE_FORMER_NAME_BTN, "Former Name Button");
			assertElementPresent(Entity.CREATE_FORMERNAME_PAGE, "Entity Name Page");
			type(Entity.FORMERNAME_TEXT, "Former Name Text for Testing", "Former Name Text");
			click(Entity.EFFECTIVE_DATE, "Effective Date");
			click(Entity.TODAYSDATE, "Today's Date");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Name's Page");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Name Type", "Name Type");
			selectBySendkeys(Generic.SELECT_2ND_DROPDOWN, "Former Name", "Former Name Dropdown");
			click(Generic.GO_BUTTON, "Go Button");
			click(Generic.FIRST_DATA, "Select First Data Link");
			assertElementPresent(Entity.VIEW_FORMERNAME_PAGE, "View Former Name Page");
			click(Generic.EDIT_NAME_LIST, "Click on Edit button");
			type(Entity.FORMERNAME_TEXT, "Edited - Former Name Text for Testing", "Former Name Text");
			click(Generic.SAVE, "Save Button");
			assertElementPresent(Entity.EDITED_FORMER_NAME, "Edited Former Name");
			click(Generic.EDIT_NAME_LIST, "Click on Edit button");
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(Entity.VIEW_FORMERNAME_PAGE, "View Former Name Page");
			click(Entity.RETURN_TO_NAME_LIST, "Return to Name List Button");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : sortByNames() 
	 * Author : Pradyumna 
	 * Description : This method will verify sort by for Name
	 * Date of creation : 9/3/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String sortByNames(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter an Entity Name and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity ID Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			waitForElementPresent(Entity.ENTITY_NAME_LINK, "Names Link");
			// Click on Names Link
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			assertElementPresent(Entity.SORTBY_EFFECTIVE_DATE_INACTIVE, "Effective Date is Inactive");
			click(Entity.SORTBY_EFFECTIVE_DATE_INACTIVE, "Effective Date");
			assertElementPresent(Entity.SORTBY_EFFECTIVE_DATE_ACTIVE, "Effective Date is Active");
			assertElementPresent(Entity.SORTBY_NAMETYPE_INACTIVE, "Name type is Inactive");
			click(Entity.SORTBY_NAMETYPE_INACTIVE, "Name Type");
			assertElementPresent(Entity.SORTBY_NAMETYPE_ACTIVE, "Name type is Active");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String editTrueName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			createEntity(ReportSheet, count);
			String EntityTrueName = getText(Entity.ENTITY_NAME_ON_ENTITY_PROFILE, "Entity Name On Entity Profile page");
			// Click on Names Link
			click(Entity.ENTITY_NAME_LINK, "Names Link");
			assertElementPresent(Entity.ENTITY_NAME_PAGE, "Entity Name Page");
			click(Entity.FIRST_ENTITY_IN_GRID, "Entity link");
			assertElementPresent(Entity.VIEW_TRUENAME_PAGE, "Entity Name Page");
			click(Generic.EDIT_NAME_LIST, "Click on Edit button");
			assertElementPresent(Entity.CHANGE_TRUENAME_PAGE, "Change True Name Page");
			type(Entity.TRUENAME_TEXT, "True Name Text for Testing", "True Name Text");
			click(Entity.FILING_DATE, "Filing Date");
			click(Entity.TODAYSDATE, "Today's Date");
			click(Generic.SAVE, "Save Button");
			assertTextMatching(Entity.PAGE_TITLE, "View True Name", "View True Name Pg Title");
			click(Entity.RETURN_TO_NAME, "Return to Names Button");
			assertTextMatching(Entity.PAGE_TITLE, "Names", "Names Pg Title");
			String EditedTrueName = getText(Entity.ENTITY_NAME_ON_ENTITY_PROFILE, "Entity Name On Entity Profile page");
			assertTextMatching(Entity.ENTITY_TRUE_NAME, EntityTrueName, "Verify True Name changed to Former Name");
			assertTextMatching(Entity.EDITED_TRUE_NAME, EditedTrueName, "Verify Edited True Name");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}