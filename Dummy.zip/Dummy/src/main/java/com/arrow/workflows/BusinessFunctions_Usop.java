package com.arrow.workflows;

import com.arrow.objectrepo.USOP;
import com.arrow.objectrepo.WorksheetCreate;

import org.openqa.selenium.By;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;

public class BusinessFunctions_Usop extends BusinessFunctions {

	/********************************************************************************************************
	 * Method Name : catchBlock() Author : Vrushali Kakade Description : This method
	 * will catch the Exception Date of creation : modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void catchBlock(Exception e) throws Throwable {
		if (e.getMessage() != null)
			parent.appendChild(child);
		gStrErrMsg = e.getMessage();
		closeSummaryReport(browsertype);
		driver.quit();
		openBrowser();
		Thread.sleep(lSleep_VLow);

	}

	/********************************************************************************************************
	 * Method Name : ViewPartnersPage() 
	 * Author : Pradyumna 
	 * Description : This method will view Fields present in Partners Page of USOP 
	 * Date of creation : 6/4/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ViewPartnersPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");
			assertElementPresent(USOP.PARTNERS, "Partners text");
			assertElementPresent(USOP.USOP_INTERFACE_TEXT, "USOP Interface text");
			assertElementPresent(USOP.PARTNER_PROFILE, "Partners Profile text");
			assertElementPresent(USOP.CHANNELS, "Channels text");
			assertElementPresent(USOP.CHANNELS_PROFILE, "Channels Profile text");
			assertElementPresent(USOP.SUBSCRIPTION, "Subscription text");
			assertElementPresent(USOP.SUBSCRIPTION_PROFILE, "Subscription  text");
			assertElementPresent(USOP.FILTERS, "Filters text");

			// Sort by Text
			// waitForElementPresent(USOP.PARTNERSTITLE, "Partners Profile Page");
			assertElementPresent(USOP.PARTNER_NAME, "Partners name text");
			assertElementPresent(USOP.PARTNER_HASH, "Partner # text");
			assertElementPresent(USOP.CREATED, "Created text");

			// Click on Drop down and view options present on selecting Partner name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			assertElementPresent(USOP.BEGINS_WITH, "Begins With text");
			assertElementPresent(USOP.CONTAINS, "Contains With text");
			assertElementPresent(USOP.ENDS_WITH, "Ends With text");
			assertElementPresent(USOP.NOT_HAVING, "Not having With text");
			assertElementPresent(USOP.EQUALS, "Equals With text");

			// Click on Drop down and view options present on selecting Partner #
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_ID, "Select Partner#");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			assertElementPresent(USOP.GREATER_THAN, "> text");
			assertElementPresent(USOP.EQUAL, "= text");
			assertElementPresent(USOP.LESS_THAN, "< text");
			assertElementPresent(USOP.GREATER_THAN_EQUALS, ">= text");
			assertElementPresent(USOP.LESS_THAN_EQUALS, "<= text");
			assertElementPresent(USOP.NOT_EQUALS, "!= text");

			// Click on Drop down and view options present on selecting Created
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_CREATED, "Select Created");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			assertElementPresent(USOP.IS_ON, "Is on text");
			assertElementPresent(USOP.IS_AFTER, "Is After text");
			assertElementPresent(USOP.IS_BEFORE, "Is Before text");

			// Verify Drop down Text field, Go Button
			isElementPresent(USOP.DROP_DOWN_TEXT, "Drop Down text Field");
			isElementPresent(USOP.GO_BUTTON, "Go Button");

			// Verify Pagination Fields and Create Partner Button
			assertElementPresent(USOP.FIRST, "First text");
			assertElementPresent(USOP.PREVIOUS, "Previous text");
			assertElementPresent(USOP.NEXT, "Next text");
			assertElementPresent(USOP.LAST, "Last text");

			isElementPresent(USOP.CREATE_PARTNER_BUTTON, "Create Partner Button");
			//waitForFrameToLoadAndSwitchToIt(USOP.GENERATE_BUTTON, "Generate Button");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ErrorCreatePartner() 
	 * Author : Pradyumna 
	 * Description : This method will view Error Message present in Partners Page of USOP Date of
	 * creation : 6/6/2019 
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ErrorPartnerPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Page");
			click(USOP.CREATE_PARTNER_BUTTON, "Create Partner Button");
			// Enter Partner Fields

			// Data Security
			click(USOP.ENCRYPTION_STATUS_YES, "Select Encryption status as Yes");
			click(USOP.ENCRYPT_TRANSIENT_YES, "Select Encryption Transient as Yes");
			click(USOP.SAVE, "Click on Save button");

			assertElementPresent(USOP.ERROR_PARTNER_NAME, "Error mentioning Partner name is mandatory");
			assertElementPresent(USOP.ERROR_PARTNER_ADDRESS_LINE1, "Error mentioning Address Line 1 is mandatory");
			assertElementPresent(USOP.ERROR_PARTNER_CITY, "Error mentioning Partner City is mandatory");
			assertElementPresent(USOP.ERROR_PARTNER_STATE, "Error mentioning Partner State is mandatory");
			assertElementPresent(USOP.ERROR_ZIP_CODE, "Error mentioning Zip Code is mandatory");
			assertElementPresent(USOP.ERROR_PHONE, "Error mentioning Phone is mandatory");
			assertElementPresent(USOP.ERROR_TECHNICAL_CONTACT_NAME,
					"Error mentioning Technical Contact Name is mandatory");
			assertElementPresent(USOP.ERROR_TECHNICAL_CONTACT_EMAIL,
					"Error mentioning Technical Contact Email is mandatory");
			assertElementPresent(USOP.ERROR_BUSINESS_CONTACT_NAME,
					"Error mentioning Business Contact Name is mandatory");
			assertElementPresent(USOP.ERROR_BUSINESS_CONTACT_EMAIL,
					"Error mentioning Business Contact Email is mandatory");
			assertElementPresent(USOP.ERROR_KEY_DURATION, "Error mentioning Key Duration is mandatory");
			assertElementPresent(USOP.ERROR_KEY_VALUE, "Error mentioning Key Value is mandatory");

			click(USOP.CANCEL, "Click on Cancel button");
			waitForElementPresent(USOP.PARTNER_HEADER, "User is back on Partners Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ViewPartnersPage() 
	 * Author : Pradyumna 
	 * Description : This method will view Fields present in Partners Page of USOP 
	 * Date of creation : 6/4/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CreatePartner(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strName = Excelobject.getCellData(ReportSheet, "Name", count);
			String strAddressLine1 = Excelobject.getCellData(ReportSheet, "AddressLine1", count);
			String strAddressLine2 = Excelobject.getCellData(ReportSheet, "AddressLine2", count);
			String strCity = Excelobject.getCellData(ReportSheet, "City", count);
			String strState = Excelobject.getCellData(ReportSheet, "State", count);
			String strZipCode = Excelobject.getCellData(ReportSheet, "ZipCode", count);
			String strPhone = Excelobject.getCellData(ReportSheet, "Phone", count);

			// Technical Contact Details
			String strTechnicalContactName = Excelobject.getCellData(ReportSheet, "TechnicalContactName", count);
			String strTechnicalContactPhone = Excelobject.getCellData(ReportSheet, "TechnicalContactPhone", count);
			String strTechnicalContactFax = Excelobject.getCellData(ReportSheet, "TechnicalContactFax", count);
			String strTechnicalContactEmail = Excelobject.getCellData(ReportSheet, "TechnicalContactEmail", count);

			// Business Contact Details
			String strBusinessContactName = Excelobject.getCellData(ReportSheet, "BusinessContactName", count);
			String strBusinessContactPhone = Excelobject.getCellData(ReportSheet, "BusinessContactPhone", count);
			String strBusinessContacFax = Excelobject.getCellData(ReportSheet, "BusinessContacFax", count);
			String strBusinessContactEmail = Excelobject.getCellData(ReportSheet, "BusinessContactEmail", count);

			// Key Duration and Comments
			String strKeyDuration = Excelobject.getCellData(ReportSheet, "KeyDuration", count);
			String strComments = Excelobject.getCellData(ReportSheet, "Comments", count);

			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Page");
			click(USOP.CREATE_PARTNER_BUTTON, "Create Partner Button");
			// Enter Partner Fields
			type(USOP.NAME_FIELD, strName, "Name field Entered");
			type(USOP.ADDRESS_LINE1, strAddressLine1, "Address Line1 Entered");
			type(USOP.ADDRESS_LINE2, strAddressLine2, "Address Line2 Entered");
			type(USOP.CITY, strCity, "City Entered");
			type(USOP.STATE, strState, "State Entered");
			type(USOP.ZIP_CODE, strZipCode, "Address Line2 Entered");
			click(USOP.COUNTRY, "Select Country Dropdown");
			click(USOP.SELECT_COUNTRY, "Select Country");
			type(USOP.PHONE, strPhone, "Phone number entered");

			// Enter Technical Contact Details
			type(USOP.TECHNICAL_CONTACT_NAME, strTechnicalContactName, "Technical Contact Name entered");
			type(USOP.TECHNICAL_CONTACT_PHONE, strTechnicalContactPhone, "Technical Contact Phone entered");
			type(USOP.TECHNICAL_CONTACT_FAX, strTechnicalContactFax, "Technical Contact Fax entered");
			type(USOP.TECHNICAL_CONTACT_EMAIL, strTechnicalContactEmail, "Technical Contact Email entered");

			// Enter Business Contact Details
			type(USOP.BUSINESS_CONTACT_NAME, strBusinessContactName, "Business Contact Name entered");
			type(USOP.BUSINESS_CONTACT_PHONE, strBusinessContactPhone, "Business Contact Phone entered");
			type(USOP.BUSINESS_CONTACT_FAX, strBusinessContacFax, "Business Contact Fax entered");
			type(USOP.BUSINESS_CONTACT_EMAIL, strBusinessContactEmail, "Business Contact Eamil entered");

			// Data Security
			click(USOP.ENCRYPTION_STATUS_YES, "Select Encryption status as Yes");
			type(USOP.KEY_DURATION, strKeyDuration, "Key Duration entered");
			click(USOP.ENCRYPT_TRANSIENT_YES, "Select Encryption Transient as Yes");
			click(USOP.GENERATE_KEY, "Click on Generate key button");
			type(USOP.COMMENTS, strComments, "Comments Entered");
			click(USOP.SAVE, "Click on Save button");
			waitForElementPresent(USOP.PARTNER_PROFILE_PAGE, "User is on Partner Profile Page");
			// getText(USOP.PartnerID, "Partner ID is: ");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : SearchAndSelectParter() 
	 * Author : Pradyumna 
	 * Description : This method will search and select existing Partner 
	 * Date of creation : 6/6/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SearchAndSelectParter(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strPartnerName = Excelobject.getCellData(ReportSheet, "PartnerName", count);
			String strPartnerID = Excelobject.getCellData(ReportSheet, "PartnerID", count);
			String strCreatedDate = Excelobject.getCellData(ReportSheet, "CreatedDate", count);
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Click on Drop down and search Partner by Name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.CONTAINS, "Contains With text");
			type(USOP.DROP_DOWN_TEXT, strPartnerName, "Partner Name entered");
			click(USOP.GO_BUTTON, "Go Button");
			assertElementPresent(USOP.PARTNER_NAME_CONTAINS, "Partner Name");
			click(USOP.CLEAR_BUTTON, "Clear Button");
			assertElementPresent(USOP.PARTNER_HEADER, "Partner Name");

			// Click on Drop down and search Partner by ID
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_ID, "Select Partner#");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.EQUAL, "= text");
			type(USOP.DROP_DOWN_TEXT, strPartnerID, "Partner ID entered");
			click(USOP.GO_BUTTON, "Go Button");
			assertElementPresent(USOP.PARTNER_ID_EQUALS, "Partner ID is displayed");
			click(USOP.CLEAR_BUTTON, "Clear Button");
			assertElementPresent(USOP.PARTNER_HEADER, "Partner Name");

			// Click on Drop down and search Partner by Created Date
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_CREATED, "Select Created");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.IS_ON, "Is on text");
			type(USOP.DROP_DOWN_TEXT, strCreatedDate, "Created Date entered");
			click(USOP.GO_BUTTON, "Go Button");
			assertElementPresent(USOP.PARTNER_CREATED_ON, "Created date");

			// Select the Partner
			click(USOP.PARTNER_NAME_CONTAINS, "Partner Name");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");
			assertElementPresent(USOP.PARTNER_ID, "Partner ID");
			click(USOP.EDIT_BUTTON, "Edit Button");
			assertElementPresent(USOP.EDIT_PARTNER, "Edit Partner");
			click(USOP.CANCEL, "Cancel Button");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");
			click(USOP.MAINTAIN_CREDENTIALS_BUTTON, "Maintain credentials Button");
			assertElementPresent(USOP.MAINTAIN_CREDENTIALS_PAGE, "Maintain Credentials Profile");
			click(USOP.CANCEL, "Cancel Button");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");
			click(USOP.VIEW_METRICS_BUTTON, "View Metrics Button");
			//On clicking View Metrics Button, New window is opened. Below steps manages Jumps from Parent to child & back to Parent Window
		/*	String parentWindow= driver.getWindowHandle();
			Thread.sleep(1000);
			handlePopUpWindwow();
			Thread.sleep(1000);
			assertElementPresent(USOP.SOP_METRICS_FOR, "SOP Metrics Summary Text");
			assertElementPresent(USOP.METRICS_SUMMARY, "Summary Title");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");*/

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : Create Channel() Author : Pradyumna Description : This method
	 * will create a channel Date of creation : 6/11/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CreateChannels(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strPartnerName = Excelobject.getCellData(ReportSheet, "PartnerName", count);
			String strChannelName = Excelobject.getCellData(ReportSheet, "ChannelName", count);
			String strChannelComment = Excelobject.getCellData(ReportSheet, "ChannelComment", count);
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Click on Drop down and search Partner by Name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.CONTAINS, "Contains With text");
			type(USOP.DROP_DOWN_TEXT, strPartnerName, "Partner Name entered");
			click(USOP.GO_BUTTON, "Go Button");

			click(USOP.FIRST_PARTNER_ON_PAGE, "Select first Partner on page");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");

			// Select Channels
			click(USOP.CHANNELS_LINK, "Select Channels Link");
			assertElementPresent(USOP.MAINTAIN_CHANNELS, "Maintain Channels");
			type(USOP.CHANNEL_NAME, strChannelName, "Channel Name entered");
			type(USOP.COMMENTS, strChannelComment, "Comments entered");
			click(USOP.ADD_UPDATE, "Add/Update Button");
			assertElementPresent(USOP.CHANNEL_NAME_CHECK, "Channel Name");
			click(USOP.CHANNEL_NAME_CHECK, "Channel Name link");
			assertElementPresent(USOP.CHANNEL_PROFILE, "Channel Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : Create and View Subscription for Affiliation() Author :
	 * Pradyumna Description : This method will create a channel Date of creation :
	 * 6/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SubscriptionAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strPartnerName = Excelobject.getCellData(ReportSheet, "PartnerName", count);
			String strSubscriptionComment = Excelobject.getCellData(ReportSheet, "SubscriptionComment", count);
			String strAffiliationName = Excelobject.getCellData(ReportSheet, "AffiliationName", count);
			String strAffiliationID = Excelobject.getCellData(ReportSheet, "AffiliationID", count);
			// String strSubGroupName=Excelobject.getCellData(ReportSheet,"AffiliationName",
			// count);
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Click on Drop down and search Partner by Name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.CONTAINS, "Contains With text");
			type(USOP.DROP_DOWN_TEXT, strPartnerName, "Partner Name entered");
			click(USOP.GO_BUTTON, "Go Button");

			click(USOP.FIRST_PARTNER_ON_PAGE, "Select first Partner on page");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");

			// Select Channels
			click(USOP.CHANNELS_LINK, "Select Channels Link");
			click(USOP.CHANNEL_NAME_CHECK, "Channel Name link");

			// Select Subscriptions
			click(USOP.SUBSCRIPTION_LINK, "Subscription link");
			assertElementPresent(USOP.MAINTAIN_SUBSCRIPTION, "Maintain Subscription");
			try {
				if (driver.findElement(By.id("grdData_ctl02_imgDelete")).isDisplayed()) {
					click(USOP.DELETE_BUTTON, "Delete Button");
					handlepopup();
				} else {
					System.out.println("Old Subscription not Present");
				}
			} catch (Exception e) {
				// handle else
			}
			click(USOP.SELECT_SUBSCRIPTION_BUTTON, "Select Button");
			assertElementPresent(USOP.SUBSCRIPTION_UNIT_SEARCH_CRITERIA, "Subscription unit search criteria page");
			click(USOP.AFFILIATION_RADIO_BUTTON, "Affiliation Radio Button");
			type(USOP.ENTITY_AFFILIATION_TEXT_BOX, strAffiliationName, "Affiliation Name");
			click(USOP.FIND_BUTTON, "Find Button");
			assertElementPresent(USOP.SUBSCRIPTION_UNIT_SEARCH_RESULTS, "Subscription unit search criteria page");
			click(USOP.SELECT_ENTITY_AFFILIATION, "Select Affiliation");
			assertElementPresent(USOP.MAINTAIN_SUBSCRIPTION, "Maintain Subscription");
			type(USOP.COMMENTS, strSubscriptionComment, "Comments entered");
			click(USOP.ADD_UPDATE, "Add/Update Button");
			assertElementPresent(USOP.AFFILIATION_SUBSCRIPTION, "New Subscription");

			// Try adding now same Affiliation but with Affiliation ID and observe Error
			// Message
			click(USOP.SELECT_SUBSCRIPTION_BUTTON, "Select Button");
			assertElementPresent(USOP.SUBSCRIPTION_UNIT_SEARCH_CRITERIA, "Subscription unit search criteria page");
			click(USOP.AFFILIATION_RADIO_BUTTON, "Affiliation Radio Button");
			type(USOP.ENTITY_AFFILIATION_ID_BOX, strAffiliationID, "Affiliation ID");
			click(USOP.FIND_BUTTON, "Find Button");
			type(USOP.COMMENTS, strSubscriptionComment, "Comments entered");
			click(USOP.ADD_UPDATE, "Add/Update Button");
			assertElementPresent(USOP.SUBSCRIPTION_ERROR, "Subscription Error");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : Create and View Subscription for Entity() Author : Pradyumna
	 * Description : This method will create a channel Date of creation : 6/13/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SubscriptionEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strPartnerName = Excelobject.getCellData(ReportSheet, "PartnerName", count);
			String strSubscriptionComment = Excelobject.getCellData(ReportSheet, "SubscriptionComment", count);
			String strEntityName = Excelobject.getCellData(ReportSheet, "EntityName", count);
			String strEntityID = Excelobject.getCellData(ReportSheet, "EntityID", count);
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Click on Drop down and search Partner by Name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.CONTAINS, "Contains With text");
			type(USOP.DROP_DOWN_TEXT, strPartnerName, "Partner Name entered");
			click(USOP.GO_BUTTON, "Go Button");

			click(USOP.FIRST_PARTNER_ON_PAGE, "Select first Partner on page");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");

			// Select Channels
			click(USOP.CHANNELS_LINK, "Select Channels Link");
			click(USOP.CHANNEL_NAME_CHECK, "Channel Name link");

			// Select Subscriptions
			click(USOP.SUBSCRIPTION_LINK, "Subscription link");
			assertElementPresent(USOP.MAINTAIN_SUBSCRIPTION, "Maintain Subscription");
			try {
				if (driver.findElement(By.id("grdData_ctl02_imgDelete")).isDisplayed()) {
					click(USOP.DELETE_BUTTON, "Delete Button");
					handlepopup();
				} else {
					System.out.println("Old Subscription not Present");
				}
			} catch (Exception e) {
				// handle else
			}
			click(USOP.SELECT_SUBSCRIPTION_BUTTON, "Select Button");
			assertElementPresent(USOP.SUBSCRIPTION_UNIT_SEARCH_CRITERIA, "Subscription unit search criteria page");
			click(USOP.ENTITY_RADIO_BUTTON, "Entity Radio Button");
			type(USOP.ENTITY_AFFILIATION_TEXT_BOX, strEntityName, "Entity Name");
			click(USOP.FIND_BUTTON, "Find Button");
			assertElementPresent(USOP.SUBSCRIPTION_UNIT_SEARCH_RESULTS, "Subscription unit search criteria page");
			click(USOP.SELECT_ENTITY_AFFILIATION, "Select Entity");
			assertElementPresent(USOP.MAINTAIN_SUBSCRIPTION, "Maintain Subscription");
			type(USOP.COMMENTS, strSubscriptionComment, "Comments entered");
			click(USOP.ADD_UPDATE, "Add/Update Button");
			assertElementPresent(USOP.ENTITY_SUBSCRIPTION, "New Subscription");

			// Try adding now same Affiliation but with Affiliation ID and observe Error
			// Message
			click(USOP.SELECT_SUBSCRIPTION_BUTTON, "Select Button");
			assertElementPresent(USOP.SUBSCRIPTION_UNIT_SEARCH_CRITERIA, "Subscription unit search criteria page");
			click(USOP.ENTITY_RADIO_BUTTON, "Entity Radio Button");
			type(USOP.ENTITY_AFFILIATION_ID_BOX, strEntityID, "Entity ID");
			click(USOP.FIND_BUTTON, "Find Button");
			type(USOP.COMMENTS, strSubscriptionComment, "Comments entered");
			click(USOP.ADD_UPDATE, "Add/Update Button");
			assertElementPresent(USOP.SUBSCRIPTION_ERROR, "Subscription Error");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : Filters- Add SOP Attributes() 
	 * Author : Pradyumna 
	 * Description : This method will create and view new Recipient filter 
	 * Date of creation : 6/13/2019 
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String RecipientFilter(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strPartnerName = Excelobject.getCellData(ReportSheet, "PartnerName", count);
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Click on Drop down and search Partner by Name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.CONTAINS, "Contains With text");
			type(USOP.DROP_DOWN_TEXT, strPartnerName, "Partner Name entered");
			click(USOP.GO_BUTTON, "Go Button");

			click(USOP.FIRST_PARTNER_ON_PAGE, "Select first Partner on page");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");

			// Select Channels
			click(USOP.CHANNELS_LINK, "Select Channels Link");
			click(USOP.CHANNEL_NAME_CHECK, "Channel Name link");

			// Select Filter
			click(USOP.FILTER_LINK, "Filter link");
			assertElementPresent(USOP.FILTER_PAGE, "Filter Page");
			try {
				// If already Attribute is added then delete it
				if (driver.findElement(By.id("imgFiltersAttribsDelete")).isDisplayed()) {
					click(USOP.FILTER_ATTRIBUTE_DELETE, "Delete Button");
					handlepopup();
				} else {
					System.out.println("No previous attributes Present");
					// click(USOP.FILTER_ATTRIBUTE_ADD, "Add Button");
					// assertElementPresent(USOP.FILTER_SOP_ATTRIBUTE_PAGE, "Filter Attribute
					// Page");
				}
			} catch (Exception e) {
				// throw e;
			}
			click(USOP.FILTER_ATTRIBUTE_ADD, "Add Button");
			assertElementPresent(USOP.FILTER_SOP_ATTRIBUTE_PAGE, "Filter Attribute Page");

			// Radio Buttons and Selections for Special Circumstances
			click(USOP.FILTER_TYPE_EXCLUDE, "Exclude");
			click(USOP.FILTER_TYPE_SPECIFIC, "Specific");
			click(USOP.SELECT_NONE_CIRCUMSTANCES, "Select None");
			click(USOP.ADD_SPECIAL_CIRCUMSTANCE_VALUE, "Add the selected value");
			assertElementPresent(USOP.SELECTED_SPECIAL_CIRCUMSTANCE_VALUE, "None");

			// Radio Buttons and Selections for Lawsuite
			click(USOP.LAWSUITE_TYPE_RADIO_BUTTON, "Lawsuite");
			click(USOP.LAWSUITE_TYPE, "Type");
			click(USOP.ADD_LAWSUITE_TYPE_VALUE, "Add the selected  value");
			assertElementPresent(USOP.SELECTED_LAWSUITE_TYPE, "All Types not Specified");

			// Radio Buttons and Selections for Lawsuite SubType
			click(USOP.LAWSUITE_SUB_TYPE_DROPDOWN, "Lawsuite subtype dropdpown");
			click(USOP.LAWSUITE_SUB_TYPE_VALUE, "Select Banckruptcy Litigation");
			click(USOP.LAWSUITE_SUB_VALUE, "Select value");
			click(USOP.ADD_LAWSUITE_TYPE_VALUE, "Add the selected value");
			assertElementPresent(USOP.SELECTED_LAWSUITE_SUB_VALUE, "Bankruptcy Litigation - Chapter 13");

			// Radio Buttons and Selections for State
			click(USOP.SELECT_SPECIFIC_JURISDICTION, "Jurisdiction");
			click(USOP.SELECT_STATE, "Select State");
			click(USOP.US_STATE, "Select US State");
			click(USOP.ADD_US_STATE, "Add the selected value");
			assertElementPresent(USOP.SELECTED_US_STATE, "Alabama");

			click(USOP.SAVE, "Save");
			assertElementPresent(USOP.FILTER_ATTRIBUTE_EDIT, "Edit");
			assertElementPresent(USOP.VIEW_SPECIAL_CIRCUMSTANCE, "Special Circumstance");
			assertElementPresent(USOP.VIEW_LAWSUITE_TYPE_SUBTYPE, "Lawsuite type and subtype");
			assertElementPresent(USOP.VIEW_JURISDICTION, "Jurisdiction");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : Filters- Add SOP Recipient and Republish() 
	 * Author : Pradyumna
	 * Description : This method will create and view new Recipient filter
	 * Date of creation : 6/14/2019 
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String RecipientSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strPartnerName = Excelobject.getCellData(ReportSheet, "PartnerName", count);
			String strParticipantOneWorldID = Excelobject.getCellData(ReportSheet, "ParticipantOneWorldID", count);
			String strParticipantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);
			String strCustomerOneWorldID = Excelobject.getCellData(ReportSheet, "CustomerOneWorldID", count);
			String strCustomerName = Excelobject.getCellData(ReportSheet, "CustomerName", count);
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Click on Drop down and search Partner by Name
			click(USOP.SELECT_DROPDOWN, "Select DropDown");
			click(USOP.DROPDOWN_PARTNER_NAME, "Select Partner Name");
			click(USOP.SELECT_SECOND_DROPDOWN, "Select 2nd Drop Down");
			click(USOP.CONTAINS, "Contains With text");
			type(USOP.DROP_DOWN_TEXT, strPartnerName, "Partner Name entered");
			click(USOP.GO_BUTTON, "Go Button");

			click(USOP.FIRST_PARTNER_ON_PAGE, "Select first Partner on page");
			assertElementPresent(USOP.PARTNER_PROFILE_PAGE, "Partner Profile");

			// Select Channels
			click(USOP.CHANNELS_LINK, "Select Channels Link");
			click(USOP.CHANNEL_NAME_CHECK, "Channel Name link");

			// Select Filter
			click(USOP.FILTER_LINK, "Filter link");
			assertElementPresent(USOP.FILTER_PAGE, "Filter Page");
			try {
				// If already Attribute is added then delete it
				if (driver.findElement(By.id("imgFiltersRecipientsDelete")).isDisplayed()) {
					click(USOP.RECIPIENTS_DELETE, "Delete Button");
					handlepopup();
				} else {
					System.out.println("No previous recipients Present");
					// click(USOP.FILTER_ATTRIBUTE_ADD, "Add Button");
					// assertElementPresent(USOP.FILTER_SOP_ATTRIBUTE_PAGE, "Filter Attribute
					// Page");
				}
			} catch (Exception e) {
				// throw e;
			}
			click(USOP.RECIPIENTS_ADD, "Add Button");
			assertElementPresent(USOP.FILTER_SOP_RECIPIENTS, "Filter SOP Recipients Page");

			// Add New Recipient
			click(USOP.ADD_NEW_RECIPIENT, "Add New Recipient Button");
			click(USOP.RECIPIENT_FILTER_TYPE_INCLUDE, "Select Filter type Include");
			click(USOP.SELECT_RECIPIENT, "Select Recipient");
			type(USOP.ONE_WORLD_ID, strParticipantOneWorldID, "One World Recipient ID");
			type(USOP.NAME_FIELD, strParticipantName, "Recipient Name");
			click(USOP.SEARCH_BUTTON, "Search Button");
			assertElementPresent(USOP.VIEW_ADDED_PARTICIPANT, "Participant displayed");
			click(USOP.CANCEL_RESULT, "Cancel Result Button");

			// Add new Customer
			click(USOP.RECIPIENTS_ADD, "Add Button");
			click(USOP.ADD_NEW_RECIPIENT, "Add New Recipient Button");
			click(USOP.SELECT_CUSTOMER, "Select Customer");
			type(USOP.ONE_WORLD_ID, strCustomerOneWorldID, "One World Customer ID");
			type(USOP.NAME_FIELD, strCustomerName, "Customer Name");
			click(USOP.SEARCH_BUTTON, "Search Button");
			assertElementPresent(USOP.VIEW_ADDED_PARTICIPANT, "Participant displayed");

			click(USOP.PARTICIPANT_SELECTOR, "Select the searched participant");
			click(USOP.ADD_BUTTON, "Add Button");
			click(USOP.CANCEL, "Cancel Button");
			assertElementPresent(USOP.VIEW_SOP_RECEIPIENT, "Participant Name");

			// Filters - SOP Republish
			try {
				// If already Attribute is added then delete it
				if (driver.findElement(By.id("imgFiltersRepublishDelete")).isDisplayed()) {
					click(USOP.REPUBLISH_DELETE, "Delete Button");
					handlepopup();
				} else {
					System.out.println("No previous republishe Present");
				}
			} catch (Exception e) {
				// throw e;
			}
			click(USOP.REPUBLISH_ADD, "Add New SOP Republish Button");
			click(USOP.SELECT_HARDCOPY_DELIVERY, "Select Hardcopy delivery");
			click(USOP.ADD_BUTTON, "Add Button");
			assertElementPresent(USOP.VIEW_SOP_REPUBLISH, "Hardcopy Delivery Actions");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : USOP interface Test Page 
	 * Author : Pradyumna 
	 * Description : This method will get SOP Summary List and Details 
	 * Date of creation : 6/17/2019
	 * modifying person : Pradyumna
	 * Date of modification : 6/18/2019
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String UsopInterfaceTest(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strResultSetID = Excelobject.getCellData(ReportSheet, "ResultSetID", count);
			String strPageNumber = Excelobject.getCellData(ReportSheet, "PageNumber", count);
			String strWorksheetID = null;
			String strIncorrectWorksheetID = Excelobject.getCellData(ReportSheet, "IncorrectID", count);

			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Select Partner and view Initialize “Encrypted Results Session” Page
			click(USOP.USOP_INTERFACE_TEXT, "USOP Interface Test");
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");
			click(USOP.PARTNER_DROP_DOWN, "Partner Drop Down");
			click(USOP.PARTNER_DROP_DOWN_NAME, "Bank of America Partner name");
			click(USOP.INITIALIZE_ENCRYPTED_RESULTS, "Initialize Encrypted results button");
			assertElementPresent(USOP.INITIALIZE_ENCRYPTED_RESULTS_SESSION_PAGE, "Encrypted Results Session Page");
			assertElementPresent(USOP.PARTNER_FIELD_DISPLAY, "Partner Field");
			assertElementPresent(USOP.OPERATIONAL_FIELD_DISPLAY, "Operational Field");
			click(USOP.CANCEL, "Cancel Button");
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");

			// Select Partner and view Get SOP Summary List Page
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");
			click(USOP.PARTNER_DROP_DOWN, "Partner Drop Down");
			click(USOP.PARTNER_DROP_DOWN_NAME, "Bank of America Partner name");
			click(USOP.GET_SOP_SUMMARY_LIST, "Get SOP Summary List");
			assertElementPresent(USOP.SOP_SUMMARY_LIST_PAGE, "SOP Summary list page");
			try {
				// If Log is present then click on it else 'No records found' should be
				// displayed
				if (driver.findElement(By.xpath("//tr[@class='dataGrid2Row']")).isDisplayed()) {
					strWorksheetID = getText(USOP.WORKSHEET_LOG, "strWorksheetID");
					click(USOP.WORKSHEET_LOG, "Worksheet Log");
					assertElementPresent(USOP.SOP_DETAIL_PAGE, "SOP Detail page");
					// Navigate back to Previous Page
					driver.navigate().back();
				} else {
					driver.findElement(By.xpath("//table[@class='noRecordsBar']")).isDisplayed();
					assertElementPresent(USOP.NO_RECORDS_FOUND, "NO records found");
				}
			} catch (Exception e) {
				// throw e;
			}
			assertElementPresent(USOP.NEW_OR_MODIFIED_WORKSHEET, "New/Modified Worksheet(s) section");
			assertElementPresent(USOP.CREATED_WORKSHEET, "Created Worksheet(s) section");
			click(USOP.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");

			// Select Partner and view InitSOPSummaryListER Page
			click(USOP.PARTNER_DROP_DOWN, "Partner Drop Down");
			click(USOP.PARTNER_DROP_DOWN_NAME, "Bank of America Partner name");
			click(USOP.VERSION, "Version");
			click(USOP.VERSION_1, "Select Version 1");
			click(USOP.INIT_SOP_SUMMARY_LIST_ER, "Init SOP Summary List ER button");
			assertElementPresent(USOP.INIT_SOP_SUMMARY_LIST_ER_PAGE, "Init SOP Summary list ER page");
			assertElementPresent(USOP.RESULT_SET_ID_ON_LISTER_PAGE, "Result Set ID");
			click(USOP.CANCEL, "Cancel Button");
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");

			// Select Partner and view GetSOPSummaryListER Page
			click(USOP.PARTNER_DROP_DOWN, "Partner Drop Down");
			click(USOP.PARTNER_DROP_DOWN_NAME, "Bank of America Partner name");
			click(USOP.VERSION, "Version");
			click(USOP.VERSION_1, "Select Version 1");
			type(USOP.RESULT_SET_ID, strResultSetID, "Result Set ID");
			type(USOP.PAGE_NUMBER, strPageNumber, "Page Number");
			click(USOP.GET_SOP_SUMMARY_LIST_ER, "Init SOP Summary List ER button");
			assertElementPresent(USOP.ENCRYPTED_RESULT_PAGE, "Init SOP Summary list ER page");
			assertElementPresent(USOP.CIPHER_TEXT, "CIPHER text");
			click(USOP.CANCEL, "Cancel Button");
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");

			// Select Partner and view SOP Detail Page
			click(USOP.PARTNER_DROP_DOWN, "Partner Drop Down");
			click(USOP.PARTNER_DROP_DOWN_NAME, "Bank of America Partner name");
			click(USOP.VERSION, "Version");
			click(USOP.VERSION_1, "Select Version 1");
			if (strWorksheetID != null) {
				driver.findElement(By.id("txtID")).sendKeys(strWorksheetID);
				click(USOP.GET_SOP_DETAIL, "SOP Detail button");
				assertElementPresent(USOP.SOP_DETAIL_PAGE, "SOP Detail Page");
				// SOP Details
				assertElementPresent(USOP.TARGET_DETAILS, "USOP Interface Test Criteria");
				assertElementPresent(USOP.LAWSUIT_DETAILS, "USOP Interface Test Criteria");
				assertElementPresent(USOP.CASE_DETAILS, "USOP Interface Test Criteria");
				assertElementPresent(USOP.SOURCE_DETAILS, "USOP Interface Test Criteria");
				assertElementPresent(USOP.REMARKS, "USOP Interface Test Criteria");
				click(USOP.SEARCH_AGAIN, "Search Again Button");
				assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");
			} else {
				type(USOP.CT_LOG, strIncorrectWorksheetID, "Incorrect Worksheet ID");
				click(USOP.GET_SOP_DETAIL, "SOP Detail button");
				assertElementPresent(USOP.SOP_DETAIL_PAGE, "SOP Detail Page");
				assertElementPresent(USOP.INVALID_ID, "Incorrect Correct Log ID");
				click(USOP.SEARCH_AGAIN, "Search Again Button");
				assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");
			}
			
			//Pending - Verify rest of the buttons on page
			assertElementPresent(USOP.GET_SOP_DETAIL_ER, "GetSOPDetailER button");
			assertElementPresent(USOP.ACKNOWLEDGE_SOP, "AcknowledgeSOP button");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	/********************************************************************************************************
	 * Method Name : USOP interface Test Page - Get Doc URL
	 * Author : Pradyumna 
	 * Description : This method will get SOP Summary List and Details 
	 * Date of creation : 7/11/2019
	 * modifying person : Pradyumna
	 * Date of modification : 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String UsopGetDocUrl(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strTextImage = Excelobject.getCellData(ReportSheet, "TextImage", count);
			
			// click on USOP Top Nav link
			click(HomePage.USOP_LINK_TOP_NAV, "USOP TAB");
			waitForElementPresent(USOP.PARTNER_HEADER, "Partners Profile Page");

			// Select Partner
			click(USOP.USOP_INTERFACE_TEXT, "USOP Interface Test");
			assertElementPresent(USOP.USOP_INTERFACE_TEST_PAGE, "USOP Interface Test Criteria");
			click(USOP.PARTNER_DROP_DOWN, "Partner Drop Down");
			click(USOP.PARTNER_DROP_DOWN_NAME, "Bank of America Partner name");

			//Enter and view PDF for GetDocURL
			type(Generic.TEXT_IMAGE, strTextImage, "Text Image");
			click(USOP.GET_DOC_URL, "GetDocURLButton");
			String parentWindow= driver.getWindowHandle();
			handlePopUpWindwow();
			Thread.sleep(150);
			elementIsNotPresent(ActionItems_SOP.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);
			//Pending - Need to re-check view part
			//waitForElementPresent(USOP.GET_DOC_URL_PDF, "USOP Interface Test Criteria");
			//assertElementPresent(USOP.GET_DOC_URL_PDF, "USOP Interface Test Criteria");			

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}