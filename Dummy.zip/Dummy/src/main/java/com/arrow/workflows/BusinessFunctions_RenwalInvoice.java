package com.arrow.workflows;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ddf.EscherColorRef.SysIndexProcedure;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.DI;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Invoice;
import com.arrow.objectrepo.RenewalInvoice;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.SOP;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_RenwalInvoice extends BusinessFunctions {

	public void searchInvoice(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

			// click on Renewal Invoice Search link on Home page
			click(HomePage.RENEWAL_INVOICE_SEARCH_LINK, "Renewal Invoice Search Link");
			waitForElementPresent(RenewalInvoice.INVOICE_ID_TEXT_BOX, "Invoice Id Text Box");
			// Verify Title of the page is Renewal Invoice Search
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoice Search",
					"Title of the page is Renewal Invoice Search");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Renewal Invoices
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page is Renewal Invoices");
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchInvoiceByAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affID = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, affID, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			// Click on Renewal Invoices from left nav bar
			click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchInvoiceByEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Verify Title of the page is Renewal Invoices
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page is Renewal Invoices");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public void placeOnReferral(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Verify Title of the page is Renewal Invoices
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page is Renewal Invoices");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");
			// Click on Referrals from left nav link
			click(Entity.REFERRALS_LEFT_NAV_LINK, "Referrals Link");
			// Verify Title of the page is Referrals
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Referrals", "Title of the page is Referrals");

			// Click on Not On Referral Tab
			click(RenewalInvoice.NOT_ON_REFERRAL_TAB, "Not On Referral Tab");
			// Click on Place on Referal button and verify err message
			click(RenewalInvoice.PLACE_ON_REFERRAL_BTN, "Place On Referral Button");
			assertElementPresent(RenewalInvoice.PLACE_ON_REFERRAL_ERR_MSG,
					"Error Message when place on referral button is clicked without selecting an invoice");
			// Select an invoice and then click on place on referral button
			click(RenewalInvoice.INVOICE_CHECKBOX, "First Invoice On The Grid");
			click(RenewalInvoice.PLACE_ON_REFERRAL_BTN, "Place On Referral Button");
			// Verify Title of the page is Referrals
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Referrals", "Title of the page is Referrals");
			click(RenewalInvoice.ON_REFERRAL_TAB, "On Referral Tab");
			// Click on First invoice from the grid and click on remove referral button
			click(RenewalInvoice.INVOICE_CHECKBOX, "Select First invoice from the grid");
			click(RenewalInvoice.REMOVE_REFERRAL_BTN, "Remove Referral Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchRevisedInvoiceByEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Verify Title of the page is Renewal Invoices
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page is Renewal Invoices");
			// Click On Revisions Link from left nav
			click(Entity.REVISIONS_LEFT_NAV_LINK, "Revisions Left Nav Link");
			// Verify Title of the page is Revisions
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Revisions", "Title of the page is Revisions");
			//Click on All Revisable Invoices tab
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB,"All Revisable Invoices tab");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");

		} catch (Exception e) {
			throw e;
		}
	}

	public void invoiceForUnaffiliatedEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");
			// Verify arrow invoice status is not revised and place of referral button is
			// present
			isElementNotPresent(RenewalInvoice.ARROW_INVOICE_STATUS_IS_REVISED, "Verify the status of arrow invoice");
			assertElementPresent(RenewalInvoice.PLACE_ON_REFERRAL_BTN, "Place On Referral Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void invoiceForAffiliatedEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");
			// Verify it is not a part of subgroup
			assertElementPresent(RenewalInvoice.BLANK_SUBGROUP, "Verify invoice is not a part of subgroup");
			// Verify arrow invoice status is not revised and place of referral button is
			// present
			isElementNotPresent(RenewalInvoice.ARROW_INVOICE_STATUS_IS_REVISED, "Verify the status of arrow invoice");
			assertElementPresent(RenewalInvoice.PLACE_ON_REFERRAL_BTN, "Place On Referral Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void invoiceForAffiliatedEntityWithSubgroup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Select first invoice from the grid
			// Click on first invoice from the grid
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice On The Grid");
			// Verify Title of the page is Invoice Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Title of the page is Invoice Profile");
			// Verify Consolidated status is no
			assertTextMatching(RenewalInvoice.CONSOLIDATED_STATUS, "No", "Consolidated status");
			// Verify it is not a part of subgroup
			isElementPresent(RenewalInvoice.BLANK_SUBGROUP, "Verify invoice is not a part of subgroup");
			// Verify arrow invoice status is not revised and place of referral button is
			// present
			isElementNotPresent(RenewalInvoice.ARROW_INVOICE_STATUS_IS_REVISED, "Verify the status of arrow invoice");
			assertElementPresent(RenewalInvoice.PLACE_ON_REFERRAL_BTN, "Place On Referral Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void selectSingleInvoiceToReprint(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// TODO add page titles
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Click On All Renewal Invoices Tab
			click(RenewalInvoice.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab");
			// Select first checkbox for invoice
			click(RenewalInvoice.INVOICE_CHECKBOX, "Select First invoice");
			// Click on Reprint Button
			click(RenewalInvoice.REPRINT_BTN, "Reprint Button");
			// Verify Title of the page is Reprint Invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Reprint Invoice", "Title of the page");
			// Check for radio buttons
			assertElementPresent(RenewalInvoice.DELIVER_TO_CUSTOMER_RADIO_BTN, "Deliver To Customer Radio Button");
			click(RenewalInvoice.PRINT_LOCALLY_RADIO_BTN, "Print Locally Radio Button");
			// Enter comments
			type(Entity.COMMENTS, "Testing", "Comments Text Box");
			// Click on Reprint Button
			click(RenewalInvoice.REPRINT_BTN_ON_REPRINT_INVOICE_PAGE, "Reprint Button");
			// Verify Title of the page is Reprint Invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void selectMultipleInvoiceToReprint(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Click On All Renewal Invoices Tab
			click(RenewalInvoice.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab");
			// Select first and second checkbox for invoice
			click(RenewalInvoice.INVOICE_CHECKBOX, "Select First invoice");
			click(RenewalInvoice.SECOND_INVOICE_CHECKBOX, "Select Second invoice");
			// Click on Reprint Button
			click(RenewalInvoice.REPRINT_BTN, "Reprint Button");
			// Verify Title of the page is Reprint Invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Reprint Invoice", "Title of the page");
			// Check for radio buttons
			assertElementPresent(RenewalInvoice.DELIVER_TO_CUSTOMER_RADIO_BTN, "Deliver To Customer Radio Button");
			click(RenewalInvoice.PRINT_LOCALLY_RADIO_BTN, "Print Locally Radio Button");
			// Enter comments
			type(Entity.COMMENTS, "Testing", "Comments Text Box");
			// Click on Reprint Button
			click(RenewalInvoice.REPRINT_BTN_ON_REPRINT_INVOICE_PAGE, "Reprint Button");
			// Verify Title of the page is Reprint Invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void selectAllInvoiceToReprint(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Click On All Renewal Invoices Tab
			click(RenewalInvoice.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab");
			// Click on Select Page Button and then click on unselect page button
			click(RenewalInvoice.SELECT_PAGE_BTN, "Select Page Button");
			click(RenewalInvoice.UNSELECT_PAGE_BTN, "Unselect Page Button");
			// Click on Select Page Button Again
			click(RenewalInvoice.SELECT_PAGE_BTN, "Select Page Button");
			// Click on Reprint Button
			click(RenewalInvoice.REPRINT_BTN, "Reprint Button");
			// Verify Title of the page is Reprint Invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Reprint Invoice", "Title of the page");
			// Check for radio buttons
			assertElementPresent(RenewalInvoice.DELIVER_TO_CUSTOMER_RADIO_BTN, "Deliver To Customer Radio Button");
			click(RenewalInvoice.PRINT_LOCALLY_RADIO_BTN, "Print Locally Radio Button");
			// Enter comments
			type(Entity.COMMENTS, "Testing", "Comments Text Box");
			// Click on Reprint Button
			click(RenewalInvoice.REPRINT_BTN_ON_REPRINT_INVOICE_PAGE, "Reprint Button");
			// Verify Title of the page is Reprint Invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void selectSingleInvoiceToRevise(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Verify Title of the page is Renewal Invoices
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page is Renewal Invoices");
			// Click On Revisions Link from left nav
			click(Entity.REVISIONS_LEFT_NAV_LINK, "Revisions Left Nav Link");
			// Verify Title of the page is Revisions
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Revisions", "Title of the page is Revisions");
			// Click On All Revisable Invoices Tab
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices Tab");
			// Click on Reprint Button
			click(RenewalInvoice.REVISE_BTN, "Revise Button");
			// Verify Error Message when no invoice is selected to revise
			assertElementPresent(RenewalInvoice.REVISE_ERR_MSG, "Error Message when no invoice is selected to revise");
			// Select first checkbox for invoice
			click(RenewalInvoice.INVOICE_CHECKBOX, "Select First invoice");
			// Click on Reprint Button
			click(RenewalInvoice.REVISE_BTN, "Revise Button");
			// Select a revision reason
			selectByIndex(RenewalInvoice.REVISION_REASON_DRPDWN, 1, "Revision Reason DropDown");
			// Click on Revise Button
			click(RenewalInvoice.REVISE_BTN_ON_REVISE_INVOICE_PAGE, "Revise Button");
			// Verify Title of the page is Revisions
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Revisions", "Title of the page is Revisions");

		} catch (Exception e) {
			throw e;
		}
	}

	public void selectMultipleInvoiceToRevise(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Verify Title of the page is Entity Profile
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Entity Profile", "Title of the page is Entity Profile");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Verify Title of the page is Renewal Invoices
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Title of the page is Renewal Invoices");
			// Click On Revisions Link from left nav
			click(Entity.REVISIONS_LEFT_NAV_LINK, "Revisions Left Nav Link");
			// Verify Title of the page is Revisions
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Revisions", "Title of the page is Revisions");
			// Click On All Revisable Invoices Tab
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices Tab");
			// Select first and second checkbox for invoice
			click(RenewalInvoice.INVOICE_CHECKBOX, "Select First invoice");
			click(RenewalInvoice.SECOND_INVOICE_CHECKBOX, "Select Second invoice");
			// Click on Reprint Button
			click(RenewalInvoice.REVISE_BTN, "Revise Button");
			// Select a revision reason
			selectByIndex(RenewalInvoice.REVISION_REASON_DRPDWN, 1, "Revision Reason DropDown");
			// Click on Revise Button
			click(RenewalInvoice.REVISE_BTN_ON_REVISE_INVOICE_PAGE, "Revise Button");
			// Verify Title of the page is Revisions
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Revisions", "Title of the page is Revisions");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : invoiceExceptionAffiliationID() Author : Pradyumna Description
	 * : This method will allow searches of Invoice exception by entering
	 * Affiliation ID and Service Center. Date of creation : 10/29/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void invoiceExceptionAffiliationID(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationId = Excelobject.getCellData(ReportSheet, "AffiliationId", count);

			// click on Invoice Tab link
			waitForElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_SEARCH_PAGE, "Renewal Invoice Search Page");
			click(RenewalInvoice.INVOICE_EXCEPTION_SEARCH, "Invoice exception Link");
			assertElementPresent(RenewalInvoice.INVOICE_EXCEPTION_SEARCH_PAGE, "Invoice Exception Search Page");
			type(Generic.CT_LOG, affiliationId, "Affiliation ID");
			click(RenewalInvoice.SERVICE_CENTRE, "Service Centre");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(RenewalInvoice.INVOICE_EXCEPTION_PAGE, "Invoice Exception Search Page");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_EXCEPTION_TAB, "Renewanl Invoice Exception Tab");
			assertElementPresent(RenewalInvoice.EXCEPTION_REASON, "Exception Reason Column");
			assertElementPresent(RenewalInvoice.REINVOICE_BUTTON, "Re-Invoice button");
		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : invoiceExceptionWithServiceCentre() Author : Pradyumna
	 * Description : This method will allow searches of Invoice exception by
	 * entering Affiliation ID,Service Center and Service Team Date of creation :
	 * 10/29/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void invoiceExceptionWithServiceTeam(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationId = Excelobject.getCellData(ReportSheet, "AffiliationId", count);

			// click on Invoice Tab link
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_SEARCH_PAGE, "Renewal Invoice Search Page");
			click(RenewalInvoice.INVOICE_EXCEPTION_SEARCH, "Invoice exception Link");
			assertElementPresent(RenewalInvoice.INVOICE_EXCEPTION_SEARCH_PAGE, "Invoice Exception Search Page");
			type(Generic.CT_LOG, affiliationId, "Affiliation ID");
			click(RenewalInvoice.SERVICE_CENTRE, "Service Centre");
			click(RenewalInvoice.SERVICE_TEAM, "Service Team");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(RenewalInvoice.INVOICE_EXCEPTION_PAGE, "Invoice Exception Search Page");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_EXCEPTION_TAB, "Renewanl Invoice Exception Tab");
			assertElementPresent(RenewalInvoice.EXCEPTION_REASON, "Exception Reason Column");
			assertElementPresent(RenewalInvoice.REINVOICE_BUTTON, "Re-Invoice button");
		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : errorMsgForException() Author : Pradyumna Description : This
	 * method give error message by only searching with Affiliation ID Date of
	 * creation : 10/29/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void errorMsgForException(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String affiliationId = Excelobject.getCellData(ReportSheet, "AffiliationId", count);

			// click on Invoice Tab link
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(RenewalInvoice.RENEWAL_INVOICE_SEARCH_PAGE, "Renewal Invoice Search Page");
			click(RenewalInvoice.INVOICE_EXCEPTION_SEARCH, "Invoice exception Link");
			assertElementPresent(RenewalInvoice.INVOICE_EXCEPTION_SEARCH_PAGE, "Invoice Exception Search Page");
			type(Generic.CT_LOG, affiliationId, "Affiliation ID");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(RenewalInvoice.ERROR_MSG_FOR_EXCEPTION, "Error Message for exception");
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSForAllRenewalInvoicesTab() throws Throwable {
		try {
			// Verify the tab is current renewal invoices
			// commenting because no invoice with DS item in current renewal tab
			/*
			 * assertElementPresent(RenewalInvoice. CURRENT_RENEWAL_INVOICES_ACTIVE_TAB,
			 * "Verify Current Renewal Invoices Tab is Active");
			 * verifyCreditDSOnRenewalInvoicesPage();
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab"); verifyCreditDSOnRenewalInvoicesPage();
			 */
			// Click on All Renewal Invoices Tab
			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			verifyCreditDSOnRenewalInvoicesPage();

			// Click on All Invoice History Tab
			// click(RenewalInvoice.INVOICE_HISTORY_TAB, "Invoice History tab");
			// verifyCreditDSOnRenewalInvoicesPage();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSOnRenewalInvoicesPage() throws Throwable {
		try {
			// Filter By Credit DS
			waitForElementPresent(RenewalInvoice.CREDIT_DS_FIRST_FILTER, "Select Credit DS from first filter");
			click(RenewalInvoice.CREDIT_DS_FIRST_FILTER, "Select Credit DS from first filter");
			waitForElementPresent(RenewalInvoice.YES_SECOND_FILTER, "Select Yes from second filter");
			click(RenewalInvoice.YES_SECOND_FILTER, "Select Yes from second filter");
			waitForElementPresent(RenewalInvoice.GO_BTN, "Go Button");
			click(RenewalInvoice.GO_BTN, "Go Button");

			// Verify Credit DS Button
			waitForElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			waitForElementPresent(RenewalInvoice.ACTIVE_CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link is Active");
			assertElementPresent(RenewalInvoice.ACTIVE_CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link is Active");

			// Verify Credit DS Button
			waitForElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSOnRenewalInvoicesAndRevisionsPage(String ReportSheet, int count, String module)
			throws Throwable {
		try {

			if (module.equalsIgnoreCase("Invoice")) {

				String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

				click(HomePage.INVOICE_TAB, "Invoice Tab");
				// Search for an invoice ID
				type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
				click(RenewalInvoice.SEARCH_BTN, "Search Button");

				verifyCreditDSOnRenewalInvoicesPage();

			}

			else if (module.equalsIgnoreCase("Affiliation")) {

				String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);

				click(HomePage.AFFILIATION_TAB, "Affiliation Tab");
				// Enter an id to be searched and click on search button
				type(Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
				click(Affiliation.SEARCHBTN, "Search Button");

				// Click on Renewal Invoices from left nav bar
				click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");

				verifyCreditDSForAllRenewalInvoicesTab();
				verifyCreditDSForAllRevisionsTab();

			}

			else if (module.equalsIgnoreCase("Entity")) {

				String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);

				click(HomePage.ENTITY_TAB, "Entity Tab");

				// Enter Entity ID and click on search button
				type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
				click(Entity.SEARCH_BTN, "Search Button");

				// Click On Renewal Invoices from left nav links
				click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");

				verifyCreditDSForAllRenewalInvoicesTab();
				verifyCreditDSForAllRevisionsTab();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSForAllRevisionsTab() throws Throwable {
		try {
			click(RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");

			// commenting because no invoice with DS item in current renewal tab
			/*
			 * // Verify the tab is current renewal invoices
			 * assertElementPresent(RenewalInvoice. CURRENT_REVISABLE_INVOICES_ACTIVE_TAB,
			 * "Verify Current Revisable Invoices Tab is Active");
			 * verifyCreditDSOnRenewalInvoicesPage();
			 */

			// Click on all revisable invoices tab
			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");
			verifyCreditDSOnRenewalInvoicesPage();

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSButtonForInvoices(String ReportSheet, int count) throws Throwable {
		try {

			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Invoice");
			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Affiliation");
			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Entity");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String messageOfDisbursements1 = "You should verify with the ARMS Team that the Annual Report for the entity(s) have been filed before crediting the DS line.";
			String messageOfDisbursements2 = "If the Annual Report has been filed you should NOT issue a credit for the disbursement.";

			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			// Get invoice id
			String invoiceNumber = getText(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "Invoice name");

			// Click on Credit DS Button
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Verify context title,invoice id on context bar,page title
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Credit Disbursements", "Context Title");
			assertTextMatching(RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR, invoiceNumber, "Invoice Number");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Representation Units with Disbursements", "Page Title");

			String dsMessage = getText(RenewalInvoice.DISBURSEMENTS_MESSAGE, "Disbursements Message");
			System.out.println("dsMessage: " + dsMessage);
			assertTextContains(dsMessage, messageOfDisbursements1);
			assertTextContains(dsMessage, messageOfDisbursements2);

			// Verify invoice#, invoice date and reneal date are displayed
			assertElementPresent(RenewalInvoice.INVOICE_NUMBER, "Invoice id");
			assertElementPresent(RenewalInvoice.INVOICE_DATE, "Invoice Date");
			assertElementPresent(RenewalInvoice.RENEWAL_DATE, "Renewal Date");

			// verfiy Cancel, Revise and Revision Preview buttons are displayed
			// at top and bottom
			assertElementPresent(RenewalInvoice.REVISION_BTN_TOP, "Invoice Date");
			assertElementPresent(RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Invoice id");
			assertElementPresent(RenewalInvoice.REVISION_BTN_BOTTOM, "Invoice Date");
			assertElementPresent(RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Renewal Date");

			// Verify columns in the grid
			String entityName = getText(RenewalInvoice.ENTITY_NAME_COLUMN, "Entity Name column header");
			assertTextContains(entityName, "Entity Name");

			String dsServiceDescr = getText(RenewalInvoice.DS_SERVICE_DESCR_COLUMN,
					"DS Service Description column header");
			assertTextContains(dsServiceDescr, "Disbursements Service Description");

			String jurisdiction = getText(RenewalInvoice.JURISDICTION_COLUMN, "Jurisdiction column header");
			assertTextContains(jurisdiction, "Jurisdiction");

			String dsAmount = getText(RenewalInvoice.DS_AMOUNT_COLUMN, "DS Amount column header");
			assertTextContains(dsAmount, "DS Amount");

			String creditDS = getText(RenewalInvoice.CREDIT_DS_COLUMN, "Credit DS column header");
			assertTextContains(creditDS, "Credit DS");

			// verfiy Select All and Select None button
			assertElementPresent(RenewalInvoice.SELECT_ALL_BTN, "Select All button");
			assertElementPresent(RenewalInvoice.SELECT_NONE_BTN, "Select None button");

			// Sort By links
			assertElementPresent(RenewalInvoice.ENTITY_NAME_SORTING_LINK, "Entity Name sorting link");
			assertElementPresent(RenewalInvoice.DS_SERVICE_DESCR_SORTING_LINK,
					"Disbursements Service Description sorting link");
			assertElementPresent(RenewalInvoice.DS_AMOUNT_SORTING_LINK, "DS Amount sorting link");
			assertElementPresent(RenewalInvoice.JURISDICTION_SORTING_LINK, "Jurisdisction sorting link");

		} catch (Exception e) {
			throw e;
		}
	}

	public void backToInvoiceListButtonOnCreditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
             waitForElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
             waitForElementPresent(RenewalInvoice.INVOICE_ID_TEXT_BOX, "Invoice Id Text Box");
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			// Click on Credit DS Button
			waitForElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Back to Invoice List button is displayed if invoice is accessed
			// from Invoice tab
			waitForElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			waitForElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
					"Back to Invoice List button at the bottom");
			assertElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
					"Back to Invoice List button at the bottom");

			// Functionality of Back to Invoice List
			waitForElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			click(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			waitForElementPresent(RenewalInvoice.PAGE_TITLE, "Page Title");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Page Title");
			waitForElementPresent(RenewalInvoice.CONTEXT_TITLE,  "Context Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Renewal Invoice Search", "Context Title");
			waitForElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button");
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button");

			// Verify Back to Invoice List button is not displayed on Credit DS
			// page if invoice is accessed from Affiliatoin tab
			String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);
			waitForElementPresent(HomePage.AFFILIATION_TAB, "Affiliation Tab");
			click(HomePage.AFFILIATION_TAB, "Affiliation Tab");
			// Enter an id to be searched and click on search button
			waitForElementPresent(Affiliation.AFFILIATIONID,"Affiliation ID Text box");
			type(Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Click on Renewal Invoices from left nav bar
			waitForElementPresent(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			// Click on All Renewal Invoices Tab
			waitForElementPresent(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			// Click On Credit DS Sorting Link
			waitForElementPresent(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			waitForElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM, "Back to Invoice List button at the bottom");

			// Verify Back to Invoice List button is not displayed on Credit DS
			// page if invoice is accessed from Entity tab
			String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);
			waitForElementPresent(HomePage.ENTITY_TAB, "Entity Tab");
			click(HomePage.ENTITY_TAB, "Entity Tab");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			waitForElementPresent(Entity.SEARCH_BTN, "Search Button");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click On Renewal Invoices from left nav links
			waitForElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Click on All Renewal Invoices Tab
			waitForElementPresent(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			// Click On Credit DS Sorting Link
			waitForElementPresent(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			waitForElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM, "Back to Invoice List button at the bottom");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSButtonOnInvoiceProfilePage(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice in the grid");

			// verify Credit DS button is displayed on Invoice Profile page
			assertElementPresent(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// verify Credit DS button is disabled for revised invoice
			isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on Invoice tab");

			if (strTestCaseID.contains("'Credit DS' buton is enabled on Invoice Profile page for Issued invoice")) {
				// click on Credit DS button and verify Credit DS page is
				// displayed
				click(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");
				assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Credit Disbursements", "Context Title");
			} else if (strTestCaseID
					.contains("'Credit DS' buton is disabled on Invoice Profile page for Revised Invoice")) {
				isDisabled(RenewalInvoice.CREDIT_DS_BTN, "Credit DS button on Invoice tab");
			}

		} catch (Exception e) {
			throw e;
		}
	}
//Below codes ar added after 6/8
	public void intialiseTheReport(String testCaseID, String description, int iLoop) throws Throwable {
		child = extent.startTest(testCaseID, description);
		iterationReport(iLoop, testCaseID + " Started");

	}

	public void endTheReport(String testCaseID, int iLoop) throws Throwable {
		parent.appendChild(child);
		// This will mark end of the one row in data sheet
		iterationReport(iLoop, testCaseID + " Completed");
	}
	
	public String getTheAffiliationHavingMulitpleInvoices() {
		ArrayList<String> affiliationId  =  new ArrayList<String>();
		try {
			
			affiliationId = SQL_Queries.getTheAffiliationHavingMulitpleInvoices();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return affiliationId.get(0);
	}
	
	public String getTheEntityHavingInvoicesForTheCurrentYear() {
		ArrayList<String> entityId  =  new ArrayList<String>();
		try {
			
			entityId = SQL_Queries.getTheEntityHavingInvoicesForTheCurrentYear();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityId.get(0);
	}
	
	public String getTheActiveStandaloneEntity() {
		ArrayList<String> entityId  =  new ArrayList<String>();
		try {
			
			entityId = SQL_Queries.getTheActiveStandaloneEntity();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityId.get(0);
	}
	public void searchForTheAffiliation(String reportSheet, int count) throws Throwable {
		String affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
	
	}
	
	public void searchForTheEntity(String reportSheet, int count) throws Throwable {
		String entityId = Excelobject.getCellData(reportSheet, "Entity Id", count);
		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		type(Entity.ENTITY_ID, entityId , "Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");
	
	}
	
	
	public void reviseTheMultipleRenewalInvoices() throws Throwable{
		
	    waitForElementToBeClickable(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices link in left nav bar");
		click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices Link in left nav bar");
		//REVISIONS
		waitForElementPresent(Affiliation.REVISIONS, "Revisions Button in Affiliation search Page");
		assertElementPresent(Affiliation.REVISIONS, "Revisions Button in Affiliation search Page");
		click(Affiliation.REVISIONS, "Click on Revisions Button");
		//CHECK_BOXES_INVOICES
		try {
		waitForElementToBeClickable(Affiliation.CHECK_BOXES_INVOICES,"Check boxes of the invoices in Revisions Page");
		List<WebElement> checkBoxForInvoice = driver.findElements(Affiliation.CHECK_BOXES_INVOICES);
		for(int i =0 ; i < checkBoxForInvoice.size(); i++) {
			checkBoxForInvoice.get(i).click();
		  }
		
		//REVISION_PREVIEW_BUTTON_REVISIONS
		waitForElementPresent(Affiliation.REVISION_PREVIEW_BUTTON_REVISIONS, "Revisions Preview Button in Revisions Page");
		assertElementPresent(Affiliation.REVISION_PREVIEW_BUTTON_REVISIONS, "Revisions Preview Button in Revisions Page");
		click(Affiliation.REVISION_PREVIEW_BUTTON_REVISIONS, "Click on Revisions Preview Button in Revisions Page");	
		try {
			List<WebElement> action = driver.findElements(Invoice.NEXT_BUTTON_RELATED_INVOICE);
			if(action.size()>0) {
			
				click(Invoice.NEXT_BUTTON_RELATED_INVOICE, "Click on Next button in Related Invoices Needing Revision page");
			}
		}
		 catch(NoSuchElementException e) {
				
	     }
		waitForElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
		assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
		click(Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
		waitForElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
		assertElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
		click(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Click on Do not Print Radio Button in Affected Invoices page");
	   //REVISE_REASON_DROP_DOWN
		waitForElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
		assertElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
		selectByVisibleText(Invoice.REVISE_REASON_DROP_DOWN,"CT Assurance","Revision Reason drop down in Revise Invoice page");		
		//REVISE_BUTTON_REPRINT
		waitForElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
		assertElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");		
		click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
		//Test the Alert if there
		try {
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
			Thread.sleep(500);
			
		}catch(NoAlertPresentException e) {}
		
		} catch(NoSuchElementException e) {
			
		}
	}
	
    public void selectTheReprintAndReviseTheInvoice() throws Throwable{
		
	    waitForElementToBeClickable(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices link in left nav bar");
	    assertElementPresent(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices link in left nav bar");
	    click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices Link in left nav bar");
		//GET_FIRST_INVOICE_LINK
		waitForElementToBeClickable(Entity.GET_FIRST_INVOICE_LINK, "First Invoices link in Renewal Invoices Page");
		assertElementPresent(Entity.GET_FIRST_INVOICE_LINK, "First Invoices link in Renewal Invoices Page");
		click(Entity.GET_FIRST_INVOICE_LINK, "Click on Fisrt Invices link in Renewal Invoices Page");
		//REPRINT_BUTTON
		assertElementPresent(Invoice.REPRINT_BUTTON, "Reprint button in Renewal Invoices Page");
		click(Invoice.REPRINT_BUTTON, "Click on Reprint button in Renewal Invoices Page");
		//COMMENTFIELD
		assertElementPresent(Affiliation.COMMENTFIELD, "Comment text box in Reprint Invoice Page");
		type(Affiliation.COMMENTFIELD, "Reprint Test","Comment text box in Reprint Invoice Page");
		//REVISE_REPRINT_BUTTON
		assertElementPresent(Invoice.REVISE_REPRINT_BUTTON, "Reprint button in Reprint Invoice Page");
		click(Invoice.REVISE_REPRINT_BUTTON, "Click on Reprint button in Reprint Invoice Page");
		waitForElementToBeClickable(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
		assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
		click(Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
		try {
			List<WebElement> action = driver.findElements(Invoice.NEXT_BUTTON_RELATED_INVOICE);
			if(action.size()>0) {
			
				click(Invoice.NEXT_BUTTON_RELATED_INVOICE, "Click on Next button in Related Invoices Needing Revision page");
			}
		}
		 catch(NoSuchElementException e) {
				
	     }
		assertElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
		click(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Click on Do not Print Radio Button in Affected Invoices page");
	   //REVISE_REASON_DROP_DOWN
		assertElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
		selectByVisibleText(Invoice.REVISE_REASON_DROP_DOWN,"CT Assurance","Revision Reason drop down in Revise Invoice page");		
		//REVISE_BUTTON_REPRINT
		assertElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");		
		click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
		//Test the Alert if there
		try {
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
			Thread.sleep(500);
			
		}catch(NoAlertPresentException e) {}
		
		//
		//ARROW_INVOICE_STATUS
		assertElementPresent(Invoice.ARROW_INVOICE_STATUS, "Arrow invoice status Invoice Profile page");
		String invoiceStatusPostRevision = getText(Invoice.ARROW_INVOICE_STATUS, "Arrow invoice status Invoice Profile page");
		if(invoiceStatusPostRevision.equals("Revision Pending")) {
			
			printMessageInReport("Revised Invoice status is : "+invoiceStatusPostRevision);	
		}		
    }
    
    public void selectPriceDetailsAndValidateRevenue() throws Throwable{
    	
    	//ENTITY_PRICING
    	waitForElementToBeClickable(Entity.ENTITY_PRICING, "Pricing Details Button in Entity Profile page");
    	assertElementPresent(Entity.ENTITY_PRICING, "Pricing Details Button in Entity Profile page");
		click(Entity.ENTITY_PRICING, "Click on Pricing Details Button in Entity Profile page");
		//VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON
		waitForElementToBeClickable(Entity.VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON, "View revenue for year radio Button in Revenue Summary page");
		assertElementPresent(Entity.VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON, "View revenue for year radio Button in Revenue Summary page");
		click(Entity.VIEW_REVENUE_FOR_YEAR_RADIO_BUTTON, "Click on View revenue for year radio Button in Revenue Summary page");
		//VIEW_REVENUE_FOR_YEAR_TEXT_BOX
		waitForElementToBeClickable(Entity.VIEW_REVENUE_FOR_YEAR_TEXT_BOX, "text box to enter year against radio Button in Revenue Summary page");
		assertElementPresent(Entity.VIEW_REVENUE_FOR_YEAR_TEXT_BOX, "text box to enter year against radio Button in Revenue Summary page");
		type(Entity.VIEW_REVENUE_FOR_YEAR_TEXT_BOX,"2020", "text box to enter year against radio Button in Revenue Summary page");
		//CALCULATE_REVENUE_BUTTON
		waitForElementToBeClickable(Entity.CALCULATE_REVENUE_BUTTON, "Calculate Button in Revenue Summary page");
		assertElementPresent(Entity.CALCULATE_REVENUE_BUTTON, "Calculate Button in Revenue Summary page");
		click(Entity.CALCULATE_REVENUE_BUTTON, "Click on Calculate Button in Revenue Summary page");
		//GROSS_REP_AMOUNT
		assertElementPresent(Entity.GROSS_REP_AMOUNT, "Gross REp Amount value in Revenue Summary page");
		String grossRepAmountInRevenueSummary = getText(Entity.GROSS_REP_AMOUNT, "Gross REp Amount value in Revenue Summary page");
		//VIEW_REVENUE_DETAILS_BUTTON
		waitForElementToBeClickable(Entity.VIEW_REVENUE_DETAILS_BUTTON, "View revenue details Button in Revenue Summary page");
		assertElementPresent(Entity.VIEW_REVENUE_DETAILS_BUTTON, "View revenue details Button in Revenue Summary page");
		click(Entity.VIEW_REVENUE_DETAILS_BUTTON, "Click on view revenue details Button in Revenue Summary page");
		//GROSS_REP_AMOUNT_REVENUE_DETAILS
		assertElementPresent(Entity.GROSS_REP_AMOUNT_REVENUE_DETAILS, "Gross REp Amount value in Revenue Details page");
		String grossRepAmountInRevenueDetails = getText(Entity.GROSS_REP_AMOUNT_REVENUE_DETAILS, "Gross REp Amount value in Revenue Details page");
		if(grossRepAmountInRevenueSummary.equals(grossRepAmountInRevenueDetails)) {
			
			printMessageInReport("Gross Rep Amount in Revenue Summary : " + grossRepAmountInRevenueSummary + 
					" and Gross Rep amount in Revnue Details : " + grossRepAmountInRevenueDetails);
		}
		
    }
    
    public void editTheRenewalDIToPaperLessDeliveryMethod() throws Throwable{

    	waitForElementToBeClickable(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instruction link in left nav bar");
 		click(Entity.DELIVERY_INSTRUCTIONS, "Click on Delivery Instruction Link in left nav bar");
 		//RENEWAL_EDIT_BUTTON
 		waitForElementPresent(Entity.RENEWAL_EDIT_BUTTON, "Edit button for Renewal Invoice in Delivery Instruction Page");
 		assertElementPresent(Entity.RENEWAL_EDIT_BUTTON, "Edit button for Renewal Invoice in Delivery Instruction Page");
 		click(Entity.RENEWAL_EDIT_BUTTON, "Click on Edit button for Renewal Invoice in Delivery Instruction Page");
 		//DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT
 		waitForElementPresent(Entity.DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT, "Select button for recipient under Delivery Instruction in Edit DI Page");
 		assertElementPresent(Entity.DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT, "Select button for recipient under Delivery Instruction in Edit DI Page");
 		click(Entity.DELIVERY_INSTRUCTIONS_RECIPIENT_SELECT, "Click on Select button for recipient under Delivery Instruction in Edit DI Page");
 		//PARTICIPANTNAMEFIELD
 		waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
 		assertElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
    	type(Entity.PARTICIPANTNAMEFIELD,"Chuck Meyer", "Participant text field in Find DI Recipient Page");
    	//FINDBTN
    	assertElementPresent(Entity.FINDBTN, "Find Button in Find DI Recipient Page");
    	click(Entity.FINDBTN, "Click on Find Button in Find DI Recipient Page");
    	//SELECTRECIPIENTBTN
    	assertElementPresent(Entity.SELECTRECIPIENTBTN, "Select button for recipient under Delivery Instruction in Edit DI Page");
 		click(Entity.SELECTRECIPIENTBTN, "Click on Select button for recipient under Delivery Instruction in Edit DI Page");
    	//AUTO_RENEW_RADIO_BUTTON
 		waitForElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		assertElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		click(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 	    //COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION
 		assertElementPresent(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, "Comments text box for Renewal Invoice in Delivery Instruction Page");
 		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION,"Test", "Comments text box for Renewal Invoice in Delivery Instruction Page");
 		//SAVE_BTN
 		assertElementPresent(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
 		click(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
 		try {
 		List<WebElement> deliveryInstructions = driver.findElements(Entity.DELIVERY_INSTRUCTIONS);
 		if(deliveryInstructions.size() > 0) {
 		 waitForElementToBeClickable(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instruction link in left nav bar");
 	     click(Entity.DELIVERY_INSTRUCTIONS, "Click on Delivery Instruction Link in left nav bar");
 		}
 		}catch(NoSuchElementException e) {}
 		//RENEWAL_DI_DELIVERY_METHOD
 		waitForElementPresent(Entity.RENEWAL_DI_DELIVERY_METHOD, "Delivery Method text");
 		assertElementPresent(Entity.RENEWAL_DI_DELIVERY_METHOD, "Delivery Method text in Delivery Instruction Page");
 		assertTextMatching(Entity.RENEWAL_DI_DELIVERY_METHOD,"Paperless", "Delivery Method text in Delivery Instruction Page");
 		
    }
    
    public void createRenewalSubgroupAndRenewalDIPaperLessDeliveryMethod() throws Throwable{
    	
    	//SUBGROUPSBTN
    	waitForElementPresent(Affiliation.SUBGROUPSBTN, "Sub Groups Link in Affiliation Page");
 		assertElementPresent(Affiliation.SUBGROUPSBTN, "Sub Groups Link in Affiliation Page");
 		click(Affiliation.SUBGROUPSBTN, "Click on Sub Groups Link in Affiliation Page");
 		//CREATESUBGROUPBTN
 		waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Subgroup button in Affiliation Sub groups Page");
 		assertElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Subgroup button in Affiliation Sub groups Page");
 		click(Affiliation.CREATESUBGROUPBTN, "Click on Create Subgroup button in Affiliation Sub groups Page");
    	//CREATERENEWALSUBGROUPBTN
 		waitForElementPresent(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Subgroup Checkbox in Create groups Page");
 		assertElementPresent(Affiliation.CREATERENEWALSUBGROUPBTN, "Create Renewal Subgroup checkbox in Create Sub groups Page");
 		click(Affiliation.CREATERENEWALSUBGROUPBTN, "Click on Create Renewal Subgroup checkbox in Create Sub groups Page"); 		
 		String renewalSubgroupName  = "Test " + getCurrentDate().split("\\/")[1];
 		//CREATERENEWALSUBGROUPNAME
 		assertElementPresent(Affiliation.CREATERENEWALSUBGROUPNAME, "Create Renewal Subgroup name textbox in Create Sub groups Page");
 		type(Affiliation.CREATERENEWALSUBGROUPNAME,renewalSubgroupName,"Create Renewal Subgroup name textbox in Create Sub groups Page");
 		//RECIPIENTSELECTBTN
 		assertElementPresent(Affiliation.RECIPIENTSELECTBTN, "Select Button under Express DI Recipient details in Create Sub groups Page");
 		click(Affiliation.RECIPIENTSELECTBTN, "Click on Select Button under Express DI Recipient details in Create Sub groups Page");
 		//PARTICIPANTNAMEFIELD
 		waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
 		assertElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant text field in Find DI Recipient Page");
    	type(Entity.PARTICIPANTNAMEFIELD,"Chuck Meyer", "Participant text field in Find DI Recipient Page");
    	//FINDBTN
    	assertElementPresent(Entity.FINDBTN, "Find Button in Find DI Recipient Page");
    	click(Entity.FINDBTN, "Click on Find Button in Find DI Recipient Page");
    	//SELECTRECIPIENTBTN
    	assertElementPresent(Entity.SELECTRECIPIENTBTN, "Select button for recipient under Delivery Instruction in Edit DI Page");
 		click(Entity.SELECTRECIPIENTBTN, "Click on Select button for recipient under Delivery Instruction in Edit DI Page");
 		//SAVE_BTN
 		waitForElementPresent(Affiliation.SAVEBTN, "Save Button in Delivery Instruction Page");
 		assertElementPresent(Affiliation.SAVEBTN, "Save Button in Delivery Instruction Page");
 		click(Affiliation.SAVEBTN, "Save Button in Delivery Instruction Page"); 		
 		searchTheRenewalSubGroup(renewalSubgroupName);
 		//FIRSTRESULTONSEARCHPAGE
 		waitForElementPresent(Affiliation.FIRSTRESULTONSEARCHPAGE, "first result in Affiliation Subgroup Page");
 		assertElementPresent(Affiliation.FIRSTRESULTONSEARCHPAGE, "first result in Affiliation Subgroup Page");
 		click(Affiliation.FIRSTRESULTONSEARCHPAGE, "first result in Affiliation Subgroup Page");
 		//DELIVERY_INSTRUCTION_EDIT_BUTTON
 		waitForElementPresent(Affiliation.DELIVERY_INSTRUCTION_EDIT_BUTTON, "Edit button in Affiliation Subgroup Profile viewPage");
 		assertElementPresent(Affiliation.DELIVERY_INSTRUCTION_EDIT_BUTTON, "Edit button in Affiliation Subgroup Profile view Page");
 		click(Affiliation.DELIVERY_INSTRUCTION_EDIT_BUTTON, "Edit button in Affiliation Subgroup Profile view Page");
 		//AUTO_RENEW_RADIO_BUTTON
 		waitForElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		assertElementPresent(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		click(Entity.AUTO_RENEW_RADIO_BUTTON, "Auto Renew button for Renewal Invoice in Delivery Instruction Page");
 		//COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION
 		assertElementPresent(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION, "Comments text box for Renewal Invoice in Delivery Instruction Page");
 		type(Entity.COMMENTS_ON_JOINING_OR_QUITING_AFFILIATION,"Test", "Comments text box for Renewal Invoice in Delivery Instruction Page");
 		//SAVE_BTN
 		assertElementPresent(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
 		click(Entity.SAVE_BTN, "Save Button in Delivery Instruction Page");
 		//DELIVERY_INSTRUCTION_DELIVERY_METHOD
 		assertElementPresent(Affiliation.DELIVERY_INSTRUCTION_DELIVERY_METHOD, "Delivery Method text in Delivery Instruction Page");
 		assertTextMatching(Affiliation.DELIVERY_INSTRUCTION_DELIVERY_METHOD,"Paperless", "Delivery Method text in Delivery Instruction Page");
 		
    }
    
   public void searchTheRenewalSubGroup(String subgroupName) throws Throwable{
	   
	   //FIRSTFILTER
	   waitForElementPresent(Affiliation.FIRSTFILTER, "first filter in Affiliation Subgroup Page");
	   selectByVisibleText(Affiliation.FIRSTFILTER,"Sub Group Name", "first filter in Affiliation Subgroup Page");
	   //SECONDFILTER
	   waitForElementPresent(Affiliation.SECONDFILTER, "Second filter in Affiliation Subgroup Page");
	   selectByVisibleText(Affiliation.SECONDFILTER,"contains", "Second filter in Affiliation Subgroup Page");
	   //FILTERTEXTBOX
	   assertElementPresent(Affiliation.FILTERTEXTBOX, "filter text box in Affiliation Subgroup Page");
	   type(Affiliation.FILTERTEXTBOX,subgroupName, "filter text box in Affiliation Subgroup Page");
	   //GOBTN
	   assertElementPresent(Affiliation.GOBTN, "Go Button in Affiliation Subgroup Page");
	   click(Affiliation.GOBTN, "Click on Go Button in Affiliation Subgroup Page");
   }
	public String getTheEntityWithoutDSEnabled() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityHaveDERepLLCORDELP().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}
	//Below method commented as the dynamic Entity is not being picked
	//1.Reason -> slow response from DB and data unavailability for most of the scenarios
	public void bundleDSEffectiveStartDateEntityLevel(String reportSheet, int count) {
	 
		try {
			//Below parameter is used to hard code the entity values from the test data file
			String entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
			String backDateOrForwardDate = Excelobject.getCellData(reportSheet, "BackOrForward Date", count);
			String EntityOrSubgroupLevel = 	Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
			String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet, "Discontinue Or Add Rep", count);
			//Modifing the test data to flow from test data file not from DB
	/*		if(discontinueDERepLLCorLP.equals("")) {
				entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
			}
			else if(!discontinueDERepLLCorLP.equals("")) {
				entity = getTheEntityWithoutDSEnabled;
			}*/
			waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
			click(HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");			
			//Commenting below type method call as this is for dynamic entity received
			//type(Entity.ENTITY_ID,getTheEntityWithoutDSEnabled,"Entity Id text box");
			type(Entity.ENTITY_ID,entity,"Entity Id text box");
			assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(Entity.SEARCH_BTN, "Search Button");
			//RENEWAL_INVOICE_LEFT_NAV_LINK
			waitForElementToBeClickable(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
			assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
			//ALL_RENEWAL_INVOICES_TAB
			waitForElementToBeClickable(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
			assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
			click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");        	
			Thread.sleep(6000);
			waitForElementToBeClickable(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrwow Invoice Status in Renewal Invoices page");
			assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrwow Invoice Status in Renewal Invoices page");
			click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on Arrow Invoice status in Renewal Invoices page");
			Thread.sleep(2000);
			waitForElementPresent(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,"First Renewal invoices in Renewal Invoices Page");
			String renewalDate = getText(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,"First Renewal invoices in Renewal Invoices Page");
			String effectiveStartDate = "";
			String dseffectiveStartDate = "";
			effectiveStartDate = setTheDateForDS(backDateOrForwardDate,renewalDate).get(0);
			dseffectiveStartDate = setTheDateForDS(backDateOrForwardDate,renewalDate).get(1);
			Thread.sleep(3000);
			//ENTITY_PROFILE
			waitForElementToBeClickable(Entity.ENTITY_PROFILE, "Entity profile link in left nav bar");			
			assertElementPresent(Entity.ENTITY_PROFILE, "Entity profile link in left nav bar");
			click(Entity.ENTITY_PROFILE, "Click on Entity profile link in left nav bar");
			//ENTITY_EDIT
			waitForElementToBeClickable(Entity.ENTITY_EDIT, "Edit button on Entity profile page");
			assertElementPresent(Entity.ENTITY_EDIT, "Edit button on Entity profile page");
			click(Entity.ENTITY_EDIT, "Click on Edit button on Entity profile page");
			//REPARMS_BUNDLE_BUNDLE_DRPDWN
			Thread.sleep(5000);
			try {
			waitForElementPresent(Invoice.REPARMS_BUNDLE, "Select Reparms Bundle from Bundle dropdown");
			assertElementPresent(Invoice.REPARMS_BUNDLE, "Select Reparms Bundle from Bundle dropdown");
			selectByVisibleText(Invoice.REPARMS_BUNDLE,"REPARMS Bundle(Bundle)", "Select Reparms Bundle from Bundle dropdown");	
			}catch(Exception e) {}
			Thread.sleep(2000);
			//EFFECTIVE_START_DATE
			waitForElementPresent(Entity.EFFECTIVE_START_DATE,"Effective start Date text field");
			assertElementPresent(Entity.EFFECTIVE_START_DATE,"Effective start Date text field");
			type(Entity.EFFECTIVE_START_DATE,effectiveStartDate, "Effective start Date text field");	
			Thread.sleep(1000);
			//DISBURSEMENT_EFFECTIVE_START_DATE
			waitForElementPresent(Entity.DISBURSEMENT_EFFECTIVE_START_DATE,"DS Effective start Date text field");
			assertElementPresent(Entity.DISBURSEMENT_EFFECTIVE_START_DATE,"DS Effective start Date text field");
			type(Entity.DISBURSEMENT_EFFECTIVE_START_DATE,dseffectiveStartDate, "DS Effective start Date text field");
			//PLUS_DISBURSEMENTS_CHECKBOX
			waitForElementPresent(Entity.PLUS_DISBURSEMENTS_CHECKBOX,"Plus disbursement check box");
			assertElementPresent(Entity.PLUS_DISBURSEMENTS_CHECKBOX,"Plus disbursement check box");
			click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Click on Plus disbursement check box");
			//COMMENTS
			assertElementPresent(Entity.COMMENTS,"Comments box in Edit Entity Profile page");
			type(Entity.COMMENTS,"Test", "type test in Comments box in Edit Entity Profile page");
			//SAVE_BTN
			assertElementPresent(Entity.SAVE_BTN,"Save Button on edit entity Profile Page");
			click(Entity.SAVE_BTN, "Click on Save Button on edit entity profile page");
			Thread.sleep(2000);
			//commenting below method as this is for dynamic Entity received
			//reviseTheInvoice(EntityOrSubgroupLevel,"","",discontinueDERepLLCorLP,getTheEntityWithoutDSEnabled);
			reviseTheInvoice(EntityOrSubgroupLevel,"","",discontinueDERepLLCorLP,entity);
				
		} catch (Throwable e) {

			e.printStackTrace();		
		}
	}
	public void reviseTheInvoice(String entityOrSubgroupLevel, String subGroupName, String SubgroupOrEntityId,String discontinueDERepLLCorLP,String entity) throws Throwable {
	    
		//RENEWAL_INVOICE_LEFT_NAV_LINK
		waitForElementToBeClickable(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
		assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
		click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
		//ALL_RENEWAL_INVOICES_TAB
		waitForElementToBeClickable(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
		Thread.sleep(6000);
	if(entityOrSubgroupLevel.equals("EntityLevel")) {
		try {
		waitForElementToBeClickable(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow Invoice status in Renewal Invoices page");
		assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow Invoice status in Renewal Invoices page");
		click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow Invoice status in Renewal Invoices page");	
		Thread.sleep(2000);
		//GET_FIRST_INVOICE_LINK
		waitForElementToBeClickable(Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
		assertElementPresent(Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
		click(Entity.GET_FIRST_INVOICE_LINK, "Click on First Invoice link in Renewal Invoices page");
		//get the name of Entity from here ENTITY_NAME_LINK_INVOICE_PROFILE
		waitForElementPresent(Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity link in Renewal Invoices page");
		assertElementPresent(Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity link in Renewal Invoices page");
		String entityName = getText(Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity name");
		String parentWindow = null;			
		parentWindow = doARevisionPreviewOfTheInvoice(entityName);
		//move to new window
		try {
			
		handlePopUpWindwow();
		}catch(NoSuchSessionException e) {}
		//String parentWindow = doARevisionPreviewOfTheInvoice();
		//move to new window							
		//handlePopUpWindwow();			
		if(discontinueDERepLLCorLP.equals("Y")) {
			//By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = null;
			List<WebElement> annualReport = null;
			//("//td[contains(text(),'9400574631')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]")
			try {
		    By  ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'"+entity +"')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
		        annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
				if(annualReport.size() > 0)		    			
				{
					printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity );
				}
			}
			catch(NoSuchElementException e) {			
				printMessageInReport("No Disbursement are added for the Entity ID : " + entity+ " as the DS criteria does not met");
		}
	}
		else {
		//ANNUAL_REPORT_RENEWAL_DISBURSEMENT
		By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = null;
		List<WebElement> annualReport = null;
		try {
	     ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'"+ entityName +"')]/following-sibling::td[contains(text(),'Annual Report Renewal Disbursements')]");
	     annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
			if(annualReport.size() > 0)		    			
			{
				printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entityName );
			}
		}
		catch(NoSuchElementException e) {			
	
			printMessageInReport("No Disbursement are added for the Entity ID : " + entity+ " as the DS criteria does not met");
		
		}
	}
	Thread.sleep(2000);
	WebElement noRevisedMessage = null;
	int flagMessage = 0;
	try {								
		noRevisedMessage = driver.findElement(Invoice.NO_REVISED_NEW_INVOICE_MESSAGE);
		flagMessage = 1;
     }catch(NoSuchElementException e){}
	if(flagMessage == 0) {driver.close();}
	driver.switchTo().window(parentWindow);
	Thread.sleep(2000);
	waitForElementToBeClickable(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
	assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
	click(Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
	//DO_NOT_PRINT_RADIO_BUTTON
	waitForElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
	assertElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
	click(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Click on Do not Print Radio Button in Affected Invoices page");
   //REVISE_REASON_DROP_DOWN
	waitForElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
	assertElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
	selectByVisibleText(Invoice.REVISE_REASON_DROP_DOWN,"CT Assurance","Revision Reason drop down in Revise Invoice page");
	Thread.sleep(1200);
	//REVISE_BUTTON_REPRINT
	assertElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");	
	click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
	//Test the Alert if there
	try {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(500);
		
	}catch(NoAlertPresentException e) {}
	}	
	   catch(Exception e) {
		   
	   }	
 }	

	else if(entityOrSubgroupLevel.equals("SubgroupLevel")) {
		//DROP_DOWN_INVOICE_CONTENT
		waitForElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Name Drop down");
		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Name Drop down");
		selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT,"Name", "Name Drop down");
		Thread.sleep(1000);
		///SECOND_FILTER_DROP_DOWN
		waitForElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
		assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
		selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN,"contains","Second Filter Drop down");
		Thread.sleep(1000);
		//PSOP_INVOICES_TEXT_SEARCH
		waitForElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
		type(Entity.PSOP_INVOICES_TEXT_SEARCH,subGroupName,"Search text box");
		//GO_BTN
		waitForElementToBeClickable(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
		assertElementPresent(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
		click(Entity.GO_BTN, "Click on Go Button");
		//ARROW_INVOICE_STATUS_SORT_BY
		waitForElementToBeClickable(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow invoice Satatus in Renewal Invoices page");
		assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow invoice Satatus in Renewal Invoices page");
		click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on Arrow invoice Satatus in Renewal Invoices page");
		Thread.sleep(2000);
		//GET_FIRST_INVOICE_LINK
		waitForElementToBeClickable(Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
		assertElementPresent(Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
		click(Entity.GET_FIRST_INVOICE_LINK, "Click on First Invoice link in Renewal Invoices page");		
		String parentWindowSubGroup = null;		
		assertElementPresent(Entity.SUBGROUP_NAME_LINK_INVOICE_PROFILE, "subgroup link in Renewal Invoices page");
		String subgroupName = getText(Entity.SUBGROUP_NAME_LINK_INVOICE_PROFILE, "subgroup name");
		try {
		//here first identity the subgroup name
			
	    parentWindowSubGroup = doARevisionPreviewOfTheInvoice(subgroupName);
		
		//move to new window	    	
			handlePopUpWindwow();
			
	    
		//ANNUAL_REPORT_RENEWAL_DISBURSEMENT
		if(discontinueDERepLLCorLP.equals("Y")) {					
		
		try {
			List<WebElement> annualReport = null;
	     By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'"+entity +"')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
	     annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
	 	if(annualReport.size() > 0)		    			
		{
			printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
		}
		}
		catch(NoSuchElementException e) {					
	
			printMessageInReport("No Disbursement are added for the Entity ID : " + entity+ "as the DS criteria does not met");
			printMessageInReport("No Disbursement are added for the discontinued Rep");
		
	}
		try {	
			
		List<WebElement> totalDisbursement = null;
		totalDisbursement = driver.findElements(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
		if(totalDisbursement.size() >0 ) {
			printMessageInReport("Disbursement are added for the subgroup : "+subgroupName+ " and count is : " + totalDisbursement.size());
		}
		}
		catch(NoSuchElementException e) {

			printMessageInReport("No Disbursement are added for the subgroup");
		
	}
}		
		else {
		//assertElementPresent(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT, "Disbursement present");			
		try {
		By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
		+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
		List<WebElement> annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
		if (annualReport.size() > 0) {
				printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
		}
		}
		catch(NoSuchElementException e) {

			printMessageInReport("No Disbursement are added for the Entity ID : " + entity+ " as the DS criteria does not met");
						
	}
		try {	
			
		List<WebElement> totalDisbursement = null;
		totalDisbursement = driver.findElements(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
		if(totalDisbursement.size() >0 ) {
			printMessageInReport("Disbursement are added for the subgroup and count is : " + totalDisbursement.size() );
		}
		}
		catch(NoSuchElementException e) {

			printMessageInReport("No Disbursement are added for the subgroup");
		
	}
		}
		
		Thread.sleep(2000);
		WebElement noRevisedMessage = null;
		int flagMessage = 0;
		try {								
			noRevisedMessage = driver.findElement(Invoice.NO_REVISED_NEW_INVOICE_MESSAGE);
			flagMessage = 1;
	     }catch(NoSuchElementException e){}
		if(flagMessage == 0) {driver.close();}
		driver.switchTo().window(parentWindowSubGroup);
		Thread.sleep(2000);
	//REVISE_BUTTON
	waitForElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");	
	assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
	click(Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
	//DO_NOT_PRINT_RADIO_BUTTON
	waitForElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
	assertElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Do not Print Radio Button in Affected Invoices page");
	click(Invoice.DO_NOT_PRINT_RADIO_BUTTON, "Click on Do not Print Radio Button in Affected Invoices page");
   //REVISE_REASON_DROP_DOWN
	waitForElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
	assertElementPresent(Invoice.REVISE_REASON_DROP_DOWN, "Revision Reason drop down in Revise Invoice page");
	selectByVisibleText(Invoice.REVISE_REASON_DROP_DOWN,"CT Assurance","Revision Reason drop down in Revise Invoice page");		
	//REVISE_BUTTON_REPRINT
	assertElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
	click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
	Thread.sleep(1000);
	//Enter the data here before revision
	try {
		//REFUND_CHECK_COMMENTS
		driver.findElement(Invoice.REFUND_CHECK_COMMENTS);
		//REFUND_CHECK_COMMENTS_TEXT_BOX
		waitForElementPresent(Invoice.REFUND_CHECK_COMMENTS_TEXT_BOX, "Refund check comments text box in Revise Invoice page");
		assertElementPresent(Invoice.REFUND_CHECK_COMMENTS_TEXT_BOX, "Refund check comments text box in Revise Invoice page");
		type(Invoice.REFUND_CHECK_COMMENTS_TEXT_BOX , "Refund the amount to Original Billing Recipient", "Refund check comments text box in Revise Invoice page");
		Thread.sleep(500);
		click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");		
	}catch(NoSuchElementException e) {}
	//then finally revise it
	
	//Test the Alert if there
	try {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(500);

		
	}catch(NoAlertPresentException e) {}
		
	}
	   catch(Exception e) {
		
 }
	}
}

	public void viewInvoiceProfileOfDiscountedEntity(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {

			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);

			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Title of the page");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			// click on search button
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Title of the page");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			assertTextMatching(Entity.PAGE_TITLE, "Renewal Invoices", "Title of the page");

			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Clcik on First Invoice Id
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Invoice Profile", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void viewInvoiceProfileOfEntityHavingNoSubGrp(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {

			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);

			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Title of the page");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			// click on search button
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Title of the page");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			assertTextMatching(Entity.PAGE_TITLE, "Renewal Invoices", "Title of the page");

			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Clcik on First Invoice Id
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Invoice Profile", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void viewInvoiceProfileOfUnaffEntity(String ReportSheet, int count, String strTestCaseID) throws Throwable {
		try {

			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);

			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Title of the page");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			// click on search button
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Title of the page");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			assertTextMatching(Entity.PAGE_TITLE, "Renewal Invoices", "Title of the page");

			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Clcik on First Invoice Id
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Invoice Profile", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
	}

	public void updateParticipantForRevisionPreview(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {

			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);
			String participantName = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);

			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Title of the page");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			// click on search button
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Title of the page");

			// click on Delivery Instructions from left nav
			click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Left Nav Link");
			// Click On Communication Edit Button
			click(DI.RENEWALINVOICE_EDIT_BTN, "Renewal Invoice DI Edit Button");
			// Click on Recipient Select Btn and select a recipient
			click(DI.SELECTBTN, "Recipient Select Btn");
			type(DI.PARTICIPANTNAMEFIELD, participantName, "Participant Name text box");
			click(DI.FINDBTN, "Find Btn");
			waitForElementPresent(DI.TABLEID, "Recipient Table");
			clickOnFirstElement(DI.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// enter Comments and click on Save button
			type(DI.DI_COMMENTS_TEXTBOX, "test", "Comment field");
			click(DI.SAVEBTN, "Save button");
			// Verify Whether the entered Recipient is populated in recipient field
			assertTextMatching(DI.RENEWALINVOICE_RECIPIENT_NAME, participantName, "Renewal Invoice Recipient Name");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			assertTextMatching(Entity.PAGE_TITLE, "Renewal Invoices", "Title of the page");

			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Clcik on First Invoice Id
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Invoice Profile", "Title of the page");

			// Click on Revision Preview Button
			click(RenewalInvoice.REVISION_PREVIEW_BTN, "Revision Preview Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affected Invoices", "Title of the page");
			String participantNameOnGrid = getText(RenewalInvoice.PARTICIPANT_NAME_ON_GRID, "Participant Name on grid");

			assertTextContains(participantName, participantNameOnGrid);

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyNewInvoicesErrorMessage(String ReportSheet, int count, String strTestCaseID) throws Throwable {
		try {

			blnEventReport = true;
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			Thread.sleep(lSleep_Medium);

			assertTextMatching(Entity.PAGE_TITLE, "Entity Search Criteria", "Title of the page");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			// click on search button
			click(Entity.SEARCH_BTN, "Search Button");
			assertTextMatching(Entity.PAGE_TITLE, "Entity Profile", "Title of the page");

			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			assertTextMatching(Entity.PAGE_TITLE, "Renewal Invoices", "Title of the page");

			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Clcik on First Invoice Id
			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "Second Invoice on the grid");
			assertTextMatching(Entity.PAGE_TITLE, "Invoice Profile", "Title of the page");

			// Click on Revision Preview Button
			click(RenewalInvoice.REVISION_PREVIEW_BTN, "Revision Preview Button");
			assertTextMatching(Entity.PAGE_TITLE, "Affected Invoices", "Title of the page");
			
			//Verify error message on new invoices grid
			assertElementPresent(RenewalInvoice.NEW_INVOICES_ERROR_MSG, "Error message on new invoices grid");

		} catch (Exception e) {
			throw e;
		}
	}

	
	public ArrayList<String> setTheDateForDS(String backDateOrForwardDate, String renewalDate) {
		ArrayList<String> dates = new ArrayList<String>();
		String month = renewalDate.split("\\/")[0];
		String date = renewalDate.split("\\/")[1];
		String year = renewalDate.split("\\/")[2];
		String effectiveStartDate = "";
		String dseffectiveStartDate = "";
		if(backDateOrForwardDate.equals("backDate")) {
			if(Integer.valueOf(month) >= 3) {
				effectiveStartDate = String.valueOf(Integer.valueOf(month) - 2) + "/" + date + "/" + year;
				dseffectiveStartDate = String.valueOf(Integer.valueOf(month) - 1) + "/" + date + "/" + year;
			}
			else if(Integer.valueOf(month) < 3) {
				effectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 2);
				dseffectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 1);
			}
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);		
		}
		else if(backDateOrForwardDate.equals("forwardDate")) {	
			if(Integer.valueOf(month) <= 10) {
				effectiveStartDate = String.valueOf(Integer.valueOf(month) - 1) + "/" + date + "/" + year;
				dseffectiveStartDate = String.valueOf(Integer.valueOf(month) + 1) + "/" + date + "/" + year;
			}
			else if(Integer.valueOf(month) > 10) {
				effectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 1);
				dseffectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) + 1);
			}
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);			
		}
		else if(backDateOrForwardDate.equals("")) {
			effectiveStartDate = month + "/" + date + "/" + year;
			dseffectiveStartDate = month + "/" + date + "/" + year;
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);			
		}
		return dates;
	}
	public String doARevisionPreviewOfTheInvoice(String entityOrSubgroupName) throws Throwable {
		//REVISION_PREVIEW_BUTTON
		waitForElementPresent(Entity.REVISION_PREVIEW_BUTTON, "Revision Preview Button on Invoice Profile");
		assertElementPresent(Entity.REVISION_PREVIEW_BUTTON, "Revision Preview button in Renewal Invoices page");
		click(Entity.REVISION_PREVIEW_BUTTON, "Click on Revision Preview button in Renewal Invoices page");
		try {
			List<WebElement> action = driver.findElements(Invoice.NEXT_BUTTON_RELATED_INVOICE);
			if(action.size()>0) {
			
				click(Invoice.NEXT_BUTTON_RELATED_INVOICE, "Click on Next button in Related Invoices Needing Revision page");
			}
		}
		 catch(NoSuchElementException e) {
				
	     }
		String parentWindow = "";
		parentWindow = driver.getWindowHandle();		
		
		//Below is commente to test the enabled Next button on the page
	    List<WebElement> entOrSubgroup = null;
	    String next = "";
		//boolean elementPresent = false;
		
		//below one condition should be there to handle the No revised/new invoice(s) will be generated based on your current revisions:Billing Month has been changed. 	
	    //NO_REVISED_NEW_INVOICE_MESSAGE
	    Thread.sleep(2000);
		WebElement noRevisedMessage = null;
		int flagMessage = 0;
		try {								
			noRevisedMessage = driver.findElement(Invoice.NO_REVISED_NEW_INVOICE_MESSAGE);
			flagMessage = 1;
	     }catch(NoSuchElementException e){}
		if(flagMessage == 0) {
		By INVOICE_SUBGROUP_OR_ENTITY_LEVEL = By.xpath("//a[contains(text(),'" +entityOrSubgroupName.split("\\'")[0]+"')]");
		   Thread.sleep(15000);
		try {	
		//waitForElementPresent(INVOICE_SUBGROUP_OR_ENTITY_LEVEL,"entity or subgroup name");			
		//below is the original code which was updating the list entOrSubgroup
		entOrSubgroup = driver.findElements(INVOICE_SUBGROUP_OR_ENTITY_LEVEL);				
		//elementPresent = isElementPresent(INVOICE_SUBGROUP_OR_ENTITY_LEVEL,"entity or subgroup name");
		//isElementPresent
		}catch(NoSuchElementException e) {}
	    //below is commented to check if enabled check for the nxet element working fine
		while(entOrSubgroup == null /*&& enabled == true*/) {		
		waitForElementPresent(Invoice.NEXT_BUTTON, "Next Button on Invoice Profile Page");
		//assertElementPresent(Invoice.NEXT_BUTTON, "Next Button on Invoice Profile Page");			
		click(Invoice.NEXT_BUTTON, "Next Button on Invoice Profile Page");
		System.out.println("clicked on next button");
		try {
		Thread.sleep(5000);
		waitForElementPresent(INVOICE_SUBGROUP_OR_ENTITY_LEVEL,"entity or subgroup name");
		entOrSubgroup = driver.findElements(INVOICE_SUBGROUP_OR_ENTITY_LEVEL);				
		 }catch(NoSuchElementException e) {
			System.out.println("No Such element exception");
		 }
		}		
		waitForElementPresent(INVOICE_SUBGROUP_OR_ENTITY_LEVEL,"Entity or subgroup present in revision preview");											
		//assertElementPresent(INVOICE_SUBGROUP_OR_ENTITY_LEVEL, "Entity or subgroup present in revision preview");
		click(INVOICE_SUBGROUP_OR_ENTITY_LEVEL, "Entity or subgroup present in revision preview");
		}
		Thread.sleep(5000);
		return parentWindow;
	}
	public void bundleDSEffectiveStartDateSubgroupLevel(String reportSheet, int count) throws Throwable  {	
		try {
		String entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
		String subgroupId = Excelobject.getCellData(reportSheet, "Subgroup Id", count);
		String affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		String subGroupName = Excelobject.getCellData(reportSheet, "Subgroup Name", count);
		String backDateOrForwardDate = Excelobject.getCellData(reportSheet, "BackOrForward Date", count);
		String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet, "Discontinue Or Add Rep", count);
		//below parameters are commented as the dynamic data is not being passed now
/*		if(!discontinueDERepLLCorLP.equals("")) {
		subgroupId = getTheSubgroupWithoutDSEnabled;
		affiliationId = SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(subgroupId).get(0);	
		subGroupName = SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(subgroupId).get(1);
		}
		else if(discontinueDERepLLCorLP.equals("")) {
		subgroupId = Excelobject.getCellData(reportSheet, "Subgroup Id", count);
		affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		subGroupName = Excelobject.getCellData(reportSheet, "Subgroup Name", count);
		}*/
		String EntityOrSubgroupLevel = 	Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);		
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID,affiliationId,"Affiliation Id text box");		
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
		//RENEWAL_INVOICE_LEFT_NAV_LINK
		waitForElementToBeClickable(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
		assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
		click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");		
		//ALL_RENEWAL_INVOICES_TAB
		waitForElementToBeClickable(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
		Thread.sleep(6000);
		//DROP_DOWN_INVOICE_CONTENT
		waitForElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Name Drop down");
		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Name Drop down");
		selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT,"Name", "Name Drop down");
		Thread.sleep(3000);
		//SECOND_FILTER_DROP_DOWN
		waitForElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
		assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
		selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN,"contains","Second Filter Drop down");
		Thread.sleep(3000);
		//PSOP_INVOICES_TEXT_SEARCH
		waitForElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
		type(Entity.PSOP_INVOICES_TEXT_SEARCH,subGroupName,"Search Box in top right of renewal Invoices page");
		//GO_BTN
		waitForElementToBeClickable(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
		assertElementPresent(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
		click(Entity.GO_BTN, "Click on Go Button");
		//ARROW_INVOICE_STATUS_SORT_BY
		waitForElementToBeClickable(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow invoice status in Renewal Invoices page");
		assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Arrow invoice status in Renewal Invoices page");
		click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on Arrwo Invoices status in Renewal Invoices page");	
		waitForElementPresent(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,"First Renewal invoices in Renewal Invoices Page");
		String renewalDate = getText(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,"First Renewal invoices in Renewal Invoices Page");
		String effectiveStartDate = "";
		String dseffectiveStartDate = "";
		effectiveStartDate = setTheDateForDS(backDateOrForwardDate,renewalDate).get(0);
		dseffectiveStartDate = setTheDateForDS(backDateOrForwardDate,renewalDate).get(1);
		//SUB_GROUPS_LEFT_NAV_BAR
		waitForElementToBeClickable(Entity.SUB_GROUPS_LEFT_NAV_BAR, "Sub Group link in left nav bar of renewal Invoices page");
		assertElementPresent(Entity.SUB_GROUPS_LEFT_NAV_BAR, "Sub Group link in left nav bar of renewal Invoices page");
		click(Entity.SUB_GROUPS_LEFT_NAV_BAR, "Click on Sub Group link");	
		//SUB_GROUP_BUNDLE_MAINTENANCE
		waitForElementToBeClickable(Entity.SUB_GROUP_BUNDLE_MAINTENANCE, "Sub Group bundle maintenance link in left nav bar of renewal Invoices page");
		assertElementPresent(Entity.SUB_GROUP_BUNDLE_MAINTENANCE, "Sub Group bundle maintenance link in left nav bar of renewal Invoices page");
		click(Entity.SUB_GROUP_BUNDLE_MAINTENANCE, "Click on Sub Group bundle maintenance link in left nav bar of renewal Invoices page");		
		//below is the fxn  to validate if  bundle is already enable
		//REPARMS_BUNDLE_BUNDLE_DRPDWN
		Thread.sleep(5000);
		try {
		waitForElementPresent(Invoice.REPARMS_BUNDLE, "Select Reparms Bundle from Bundle dropdown");
		assertElementPresent(Invoice.REPARMS_BUNDLE, "Select Reparms Bundle from Bundle dropdown");
		selectByVisibleText(Invoice.REPARMS_BUNDLE,"REPARMS Bundle(Bundle)", "Select Reparms Bundle from Bundle dropdown");
		}catch(Exception e) {}
		Thread.sleep(1000);
		//EFFECTIVE_END_DATE		
		waitForElementPresent(Invoice.EFFECTIVE_END_DATE,"Effective end Date text field");
		assertElementPresent(Invoice.EFFECTIVE_END_DATE,"Effective end Date text field");
		type(Invoice.EFFECTIVE_END_DATE,effectiveStartDate, "Effective end Date text field");
		//COMMENTS		
		assertElementPresent(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,"Comments box in sub group bundle maintenance page");
		type(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,"Test", "type test in Comments box in sub group bundle maintenance page");		
		//DROP_DOWN_INVOICE_CONTENT
		waitForElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT,"First Drop down sub group bundle maintenance page");
		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT,"First Drop down sub group bundle maintenance page");
		selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT,"Sub Group Name","First Drop down sub group bundle maintenance page");
		Thread.sleep(1000);
		//DROP_DOWN_FISRT_OP
		waitForElementPresent(Invoice.DROP_DOWN_FISRT_OP,"Second Drop down sub group bundle maintenance page");
		assertElementPresent(Invoice.DROP_DOWN_FISRT_OP,"Second Drop down sub group bundle maintenance page");
		selectByVisibleText(Invoice.DROP_DOWN_FISRT_OP,"contains","Second Drop down sub group bundle maintenance page");
		//TEXT_BOX_IN_RHS
		waitForElementPresent(Invoice.TEXT_BOX_IN_RHS,"Text box in sub group bundle maintenance page");
		assertElementPresent(Invoice.TEXT_BOX_IN_RHS,"Text box in sub group bundle maintenance page");
		type(Invoice.TEXT_BOX_IN_RHS,subGroupName, "type subgroup name in text box of sub group bundle maintenance page");
		Thread.sleep(1000);
		assertElementPresent(Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
		click(Invoice.GO_BUTTON, "Click on Go Button in sub group bundle maintenance page");
		List<WebElement> gridCheckBox = null;		
		try {
		//GRID_CHECK_BOX_SELECTOR	
		gridCheckBox  = driver.findElements(Invoice.GRID_CHECK_BOX_SELECTOR);
		if(gridCheckBox.size() > 0) {
		assertElementPresent(Invoice.GRID_CHECK_BOX_SELECTOR, "select the subgroup check box in sub group bundle maintenance page");
		click(Invoice.GRID_CHECK_BOX_SELECTOR, "Click on check box in sub group bundle maintenance page");
		//BUTTON_DISABLE
		waitForElementToBeClickable(Invoice.BUTTON_DISABLE, "Click on disable button in sub group bundle maintenance page");
		assertElementPresent(Invoice.BUTTON_DISABLE, "disable button in sub group bundle maintenance page");
		click(Invoice.BUTTON_DISABLE, "Click on disable button in sub group bundle maintenance page");
		}
		}catch (Exception e) {
			
	}								
		//INACTIVE_BUNDLE_SUB_GROUPS
		waitForElementToBeClickable(Entity.INACTIVE_BUNDLE_SUB_GROUPS, "Inactive bundle sub groups tab sub group bundle maintenance page");
		assertElementPresent(Entity.INACTIVE_BUNDLE_SUB_GROUPS, "Inactive bundle sub groups tab sub group bundle maintenance page");
		click(Entity.INACTIVE_BUNDLE_SUB_GROUPS, "Click on Inactive bundle sub groups tab sub group bundle maintenance page");
		//REPARMS_BUNDLE_BUNDLE_DRPDWN
		Thread.sleep(5000);
		try {
		waitForElementPresent(Invoice.REPARMS_BUNDLE, "Select Reparms Bundle from Bundle dropdown");
		assertElementPresent(Invoice.REPARMS_BUNDLE, "Select Reparms Bundle from Bundle dropdown");
		selectByVisibleText(Invoice.REPARMS_BUNDLE,"REPARMS Bundle(Bundle)", "Select Reparms Bundle from Bundle dropdown");		
		}catch(Exception e) {}
		Thread.sleep(1000);
		//EFFECTIVE_START_DATE
		waitForElementPresent(Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL,"Effective start Date text field");
		assertElementPresent(Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL,"Effective start Date text field");
		type(Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL,effectiveStartDate, "Effective start Date text field");		
		//DISBURSEMENT_EFFECTIVE_START_DATE
		waitForElementPresent(Entity.DISBURSEMENT_EFFECTIVE_START_DATE,"DS Effective start Date text field");
		assertElementPresent(Entity.DISBURSEMENT_EFFECTIVE_START_DATE,"DS Effective start Date text field");
		type(Entity.DISBURSEMENT_EFFECTIVE_START_DATE,dseffectiveStartDate, "DS Effective start Date text field");
		//PLUS_DISBURSEMENTS_CHECKBOX
		waitForElementPresent(Entity.PLUS_DISBURSEMENTS_CHECKBOX,"Plus disbursement check box");
		assertElementPresent(Entity.PLUS_DISBURSEMENTS_CHECKBOX,"Plus disbursement check box");
		click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Click on Plus disbursement check box");
		//COMMENTS
		assertElementPresent(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,"Comments box in sub group bundle maintenance page");
		type(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,"Test", "type test in Comments box in sub group bundle maintenance page");		
		//DROP_DOWN_INVOICE_CONTENT
		waitForElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT,"First Drop down sub group bundle maintenance page");
		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT,"First Drop down sub group bundle maintenance page");
		selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT,"Sub Group Name","First Drop down sub group bundle maintenance page");
		//DROP_DOWN_FISRT_OP
		waitForElementPresent(Invoice.DROP_DOWN_FISRT_OP,"Second Drop down sub group bundle maintenance page");
		assertElementPresent(Invoice.DROP_DOWN_FISRT_OP,"Second Drop down sub group bundle maintenance page");
		selectByVisibleText(Invoice.DROP_DOWN_FISRT_OP,"contains","Second Drop down sub group bundle maintenance page");		
		//TEXT_BOX_IN_RHS
		waitForElementPresent(Invoice.TEXT_BOX_IN_RHS,"Text box in sub group bundle maintenance page");
		assertElementPresent(Invoice.TEXT_BOX_IN_RHS,"Text box in sub group bundle maintenance page");
		type(Invoice.TEXT_BOX_IN_RHS,subGroupName, "type subgroup name in text box of sub group bundle maintenance page");
		waitForElementToBeClickable(Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
		assertElementPresent(Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
		click(Invoice.GO_BUTTON, "Click on Go Button in sub group bundle maintenance page");
		Thread.sleep(1000);
		try {
		//GRID_CHECK_BOX_SELECTOR	
		gridCheckBox  = driver.findElements(Invoice.GRID_CHECK_BOX_SELECTOR);
		if(gridCheckBox.size() > 0) {
		assertElementPresent(Invoice.GRID_CHECK_BOX_SELECTOR, "select the subgroup check box in sub group bundle maintenance page");
		click(Invoice.GRID_CHECK_BOX_SELECTOR, "Click on check box in sub group bundle maintenance page");
		//ENABLE_BUTTON
		assertElementPresent(Invoice.ENABLE_BUTTON,"enable Button in sub group bundle maintenance page");
		click(Invoice.ENABLE_BUTTON, "click on enable button in sub group bundle maintenance page"); 
		
		}		
		}catch (Exception e) {
			
	}	
	   reviseTheInvoice(EntityOrSubgroupLevel,subGroupName,subgroupId,discontinueDERepLLCorLP,entity);
	}  catch (Exception e) {
		e.printStackTrace();
	}
}
	public String getTheSubgroupWithoutDSEnabled(String renewalMonth) {
		String subgroupInfo  =  "";
		try {
			
			subgroupInfo = SQL_Queries.getRenewalSubgroupHaveDERepLLCORDELP(renewalMonth).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}
	public String getEntityHavingMoreThanOneRepIncludingREPLLC() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityHavingMoreThanOneRepIncludingREPLLC().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}
	public void reinstateDomesticREPLLCorLP(String reportSheet, int count) throws Throwable {
		  
    	String entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		//type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id", count), "Entity Id text box");
		type(Entity.ENTITY_ID,entity,"Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");
		//REPRESENATION_LEFT_NAV_LINK
		waitForElementToBeClickable(Entity.REPRESENATION_LEFT_NAV_LINK, "Representation link in Entity Profile Page");
		assertElementPresent(Entity.REPRESENATION_LEFT_NAV_LINK, "Representation link in Entity Profile Page");
		click(Entity.REPRESENATION_LEFT_NAV_LINK, "Click on Representation link");
		//FIRST_DROP_DOWN
		waitForElementPresent(Entity.FIRST_DROP_DOWN, "First drop down in represenation units Page");
		assertElementPresent(Entity.FIRST_DROP_DOWN, "First drop down in represenation units Page");
		selectByVisibleText(Entity.FIRST_DROP_DOWN,"Service Type","First drop down in represenation units Page");
		//SECOND_FILTER_DROP_DOWN
		waitForElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second drop down in represenation units Page");
		assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second drop down in represenation units Page");
		selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN,"contains","Second drop down in represenation units Page");
		//PSOP_INVOICES_TEXT_SEARCH
		waitForElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Text box Represenation units Page");
		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Text box Represenation units Page");
		type(Entity.PSOP_INVOICES_TEXT_SEARCH,"Domestic Representation (Limited" , "Text box Represenation units Page");
		//GO_BTN
		waitForElementToBeClickable(Entity.GO_BTN, "Go Button in Represenation units Page");
		assertElementPresent(Entity.GO_BTN, "Go Button in Represenation units Page");
		click(Entity.GO_BTN, "Click on Go Button in Represenation units Page");
		//FIRST_ENTITY_IN_GRID
		waitForElementToBeClickable(Entity.FIRST_ENTITY_IN_GRID, "First Representation link in Represenation units Page");
		assertElementPresent(Entity.FIRST_ENTITY_IN_GRID, "First Representation link in Represenation units Page");
		click(Entity.FIRST_ENTITY_IN_GRID, "Click on First Representation link in Represenation units Page");
		Thread.sleep(3000);
		//here pick filing date logic should come from the rep profile
		//REP_FILING_DATE
/*		waitForElementPresent(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		assertElementPresent(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repFilingDate = getText(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repDiscontinueDate = setTheDateForDS("forwardDate",repFilingDate).get(1);*/
		//REINSTATE_BTN
		try {
		waitForElementPresent(Entity.REINSTATE_BTN, "Reinstate Button in Represenation units Page");
		assertElementPresent(Entity.REINSTATE_BTN, "Reinstate Button in Represenation units Page");
		click(Entity.REINSTATE_BTN, "Click on Reinstate Button in Represenation units Page");
		Thread.sleep(2000);
		//Below we need to identify is sgent needs to change
		List<WebElement> err = null;
		//boolean err = false;
		try {
		err = driver.findElements(Entity.FEDERAL_ID_ERR_MSG);
		}catch(NoSuchElementException e) {}
		if(err != null) {
		//ENTITY_EDIT
		waitForElementPresent(Entity.ENTITY_EDIT, "Edit button in Represenation units Page");
		assertElementPresent(Entity.ENTITY_EDIT, "Edit button in Represenation units Page");
		click(Entity.ENTITY_EDIT, "Edit button in Represenation units Page");
		//AGENT_DROP_DOWN
		waitForElementPresent(Rep.AGENT_DROP_DOWN, "Agent button in Represenation units Page");
		assertElementPresent(Rep.AGENT_DROP_DOWN, "Agent button in Represenation units Page");
		selectByIndex(Rep.AGENT_DROP_DOWN, 1,"Click on Agent button in Represenation units Page");	
		//SAVE_BTN
		waitForElementPresent(Entity.SAVE_BTN, "Save button in Represenation units Page");
		assertElementPresent(Entity.SAVE_BTN, "Save button in Represenation units Page");
		click(Entity.SAVE_BTN, "Save button in Represenation units Page");
		//REINSTATE_BTN
		waitForElementToBeClickable(Entity.REINSTATE_BTN, "Reinstate Button in Represenation units Page");
		assertElementPresent(Entity.REINSTATE_BTN, "Reinstate Button in Represenation units Page");
		click(Entity.REINSTATE_BTN, "Click on Reinstate Button in Represenation units Page");
		Thread.sleep(1000);
		//AGENT_APPOINTMENT_DATE
		}//
		waitForElementPresent(Rep.REINSTATEMENT_DATES, "Filing text box in Represenation units Page");
		assertElementPresent(Rep.REINSTATEMENT_DATES, "Filing text box in Represenation units Page");
		type(Rep.REINSTATEMENT_DATES,getText(Rep.AGENT_APPOINTMENT_DATE,"Date"), "Filing text box in Represenation units Page");
		Thread.sleep(1000);
		//REINSTATE_REASON_DROP_DOWN
		waitForElementPresent(Rep.REINSTATE_REASON_DROP_DOWN, "First drop down in Reinstate represenation units Page");
		assertElementPresent(Rep.REINSTATE_REASON_DROP_DOWN, "First drop down in  Reinstate Represenation units Page");
		selectByVisibleText(Rep.REINSTATE_REASON_DROP_DOWN,"Paid on Discontinuance","First drop down in Reinstate Represenation units Page");
		Thread.sleep(1000);
		//REINSTATE
		waitForElementToBeClickable(Rep.REINSTATE, "Reinstate Button in Represenation units Page");
		assertElementPresent(Rep.REINSTATE, "Reinstate Button in Represenation units Page");
		click(Rep.REINSTATE, "Click on Reinstate Button in Represenation units Page");
		Thread.sleep(3000);
		}catch(NoSuchElementException e) {}
		
   }
	public String getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(String subgroupId) {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(subgroupId).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}
	public String subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(String entity) {
		String subgroupInfo  =  "";
		try {
			
			subgroupInfo = SQL_Queries.subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(entity).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}
	public ArrayList<String> getTheSubgroupWhichAlreadyHavingDSPresent(String renewalMonth) {
		ArrayList<String> subgroupInfo  =  new ArrayList<String>();
		try {
			
			subgroupInfo = SQL_Queries.getTheSubgroupWhichAlreadyHavingDSPresent(renewalMonth);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}
	public void addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice(String reportSheet, int count) throws Throwable {

		String entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
		String affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		//String subgroupId = Excelobject.getCellData(reportSheet, "Subgroup Id", count);		
		String subGroupName = Excelobject.getCellData(reportSheet, "Subgroup Name", count);	
		String EntityOrSubgroupLevel = 	Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
		//String discontinueDERepLLCorLP = 	Excelobject.getCellData(reportSheet, "Discontinue Rep", count);
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID,affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
		//AFFILIATION_NAME
		assertElementPresent(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		String affName = getText(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");		
		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		//type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id", count), "Entity Id text box");
		type(Entity.ENTITY_ID,entity,"Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");
		click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		click(Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
        //BULLETINRETAINCURRENTDI
		assertElementPresent(Affiliation.BULLETINRETAINCURRENTDI," Bulletin Radio button in confirm joining affiliation Page");
		click(Affiliation.BULLETINRETAINCURRENTDI," Bulletin Radio button in confirm joining affiliation Page");
		//COMMRETAINCURRENTDI
		assertElementPresent(Affiliation.COMMRETAINCURRENTDI," Communication Radio button in confirm joining affiliation Page");
		click(Affiliation.COMMRETAINCURRENTDI," Communication Radio button in confirm joining affiliation Page");
		//RENEWALINVOICESUBGROUPDROPDWN
		assertElementPresent(Affiliation.RENEWALINVOICESUBGROUPDROPDWN," REnewal Invoice drop down in confirm joining affiliation Page");
		selectByVisibleText(Affiliation.RENEWALINVOICESUBGROUPDROPDWN,subGroupName,"REnewal Invoice drop down in confirm joining affiliation Page");
		//SOPRETAINCURRENTDI
		assertElementPresent(Affiliation.SOPRETAINCURRENTDI," SOP Radio button in confirm joining affiliation Page");
		click(Affiliation.SOPRETAINCURRENTDI," SOP Radio button in confirm joining affiliation Page");
		//XSOPSUBGROUPDROPDWN
		assertElementPresent(Affiliation.XSOPSUBGROUPDROPDWN,"XSOP drop down in confirm joining affiliation Page");
		selectByIndex(Affiliation.XSOPSUBGROUPDROPDWN,1,"XSOP drop down in confirm joining affiliation Page");
		//COMMENTS
		assertElementPresent(Affiliation.COMMENTS,"Comments text box in confirm joining affiliation Page");
		type(Affiliation.COMMENTS,"Test","Comments text box in confirm joining affiliation Page");
		//JOINBTN
		assertElementPresent(Affiliation.JOINBTN,"Join button in confirm joining affiliation Page");
		click(Affiliation.JOINBTN,"Join button in confirm joining affiliation Page");
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID,affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
		//Add bundle thing here
		if(EntityOrSubgroupLevel.equals("EntityLevel")) {	
			//Modifing to  make the data to floe from test data not from the DB
			//bundleDSEffectiveStartDateEntityLevel(reportSheet,count,entity);
			bundleDSEffectiveStartDateEntityLevel(reportSheet,count);
		}
		else if(EntityOrSubgroupLevel.equals("SubgroupLevel")) {
			//Modifing to  make the data to floe from test data not from the DB
			//bundleDSEffectiveStartDateSubgroupLevel(reportSheet,count,entity,subgroupId);
			bundleDSEffectiveStartDateSubgroupLevel(reportSheet,count);
		}
		//reviseTheInvoice(EntityOrSubgroupLevel,subGroupName,subgroupId,discontinueDERepLLCorLP,entity);
		
	}
	public String getEntityNotHavingDERepLLCORDELP() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityNotHavingDERepLLCORDELP().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}
	 public void validateTheInvoiceChangesPostRevision(String reportSheet, int count,String entityOrAffiliation) throws Throwable {
		   // below parameters are added as the dyanmic data is not being passed now		     
		      String subgroupId = Excelobject.getCellData(reportSheet, "Subgroup Id", count);
		      String entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
			  String affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
			  String subGroupName = Excelobject.getCellData(reportSheet, "Subgroup Name", count);
		      
		      if(entityOrAffiliation.equalsIgnoreCase("Entity")) {
		        waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
				click(HomePage.ENTITY_TAB, "Entity Search");
				waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");			
				//Commenting below type method call as this is for dynamic entity received
				//type(Entity.ENTITY_ID,getTheEntityWithoutDSEnabled,"Entity Id text box");
				type(Entity.ENTITY_ID,entity,"Entity Id text box");
				assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				click(Entity.SEARCH_BTN, "Search Button");
				//RENEWAL_INVOICE_LEFT_NAV_LINK
				waitForElementToBeClickable(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
				assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
				click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
				//ALL_RENEWAL_INVOICES_TAB
				waitForElementToBeClickable(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
				assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
				click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
		      }
		      else if(entityOrAffiliation.equalsIgnoreCase("Affiliation")) {
		    	waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		  		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		  		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		  		type(Affiliation.AFFILIATIONID,affiliationId,"Affiliation Id text box");		
		  		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		  		click(Affiliation.SEARCHBTN, "Search Button");
		  		//RENEWAL_INVOICE_LEFT_NAV_LINK
		  		waitForElementToBeClickable(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
		  		assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoices in left nav of entity profile page");
		  		click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");		
		  		//ALL_RENEWAL_INVOICES_TAB
		  		waitForElementToBeClickable(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		  		assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		  		click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
		  		Thread.sleep(6000);
		  		//DROP_DOWN_INVOICE_CONTENT
		  		waitForElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Name Drop down");
		  		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Name Drop down");
		  		selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT,"Name", "Name Drop down");
		  		Thread.sleep(3000);
		  		//SECOND_FILTER_DROP_DOWN
		  		waitForElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
		  		assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
		  		selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN,"contains","Second Filter Drop down");
		  		Thread.sleep(3000);
		  		//PSOP_INVOICES_TEXT_SEARCH
		  		waitForElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
		  		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
		  		type(Entity.PSOP_INVOICES_TEXT_SEARCH,subGroupName,"Search Box in top right of renewal Invoices page");
		  		//GO_BTN		  	
		  		waitForElementPresent(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
		  		assertElementPresent(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
		  		click(Entity.GO_BTN, "Click on Go Button");
		      }

		        //INVOICE_DATE_LABEL
		        waitForElementPresent(Invoice.INVOICE_DATE_SORT, "Invoice date sort");
	   			assertElementPresent(Invoice.INVOICE_DATE_SORT, "Invoice date sort");
	   			click(Invoice.INVOICE_DATE_SORT, "Invoice date sort");
	   			
	   			try {   			
	   			List<WebElement> noInvoiceChangesLink = null;
	   			List<WebElement> firstInvoiceLink= null;
	   			try {  				
	   			//NO_INVOICE_CHANGES_LINK
	   			noInvoiceChangesLink = driver.findElements(Invoice.NO_INVOICE_CHANGES_LINK);
	   			
	   			}
	            catch(NoSuchElementException e) {   				
	            	
	   			}
	   			try {  				
			   		 
	   				firstInvoiceLink = driver.findElements(Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE);
		   		  }
		            catch(NoSuchElementException e) {   				
		            	
		   			}
	   			if(firstInvoiceLink != null && noInvoiceChangesLink == null ) {
	   			try {
	   			//INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE
	   			waitForElementToBeClickable(Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE, "Invoice changes link for the first invoice");
	   			assertElementPresent(Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE, "Invoice changes link for the first invoice");
	   			click(Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE, "Invoice changes link for the first invoice");		   			    			   						
	   			//DS_ADDED   				   			
	      	   	  List<WebElement> ds = driver.findElements(Invoice.DS_ADDED);
	   	   		  printMessageInReport("Total DS Added = " + ds.size());
	   			}	   			
	   			catch(NoSuchElementException e) {}
	   			}	   		
	   		}
	         catch(NoSuchElementException e) {   				
	            	
	   			}
	   }
	 public String getTheOrderIdPostRevisionOfEntityLevelInvoice(String entityId) throws Throwable {
		 String orderId = "";
			try {
				orderId = SQL_Queries.getTheOrderIdPostRevisionOfEntityLevelInvoice(entityId).get(0);

			} catch (IndexOutOfBoundsException e) {

			}
			return orderId;
		}
	 

    public String getTheOrderIdPostRevisionOfSubgroupLevelInvoice(String subgroupId) throws Throwable {
	 String orderId = "";
		try {
			orderId = SQL_Queries.getTheOrderIdPostRevisionOfSubgroupLevelInvoice(subgroupId).get(0);

		} catch (IndexOutOfBoundsException e) {

		}
		return orderId;
	}
    
    
    public void discontinueDomesticREPLLCorLP(String reportSheet, int count) throws Throwable {
		  
    	String entity = Excelobject.getCellData(reportSheet, "Entity Id", count);
		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		//type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id", count), "Entity Id text box");
		type(Entity.ENTITY_ID,entity,"Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");
		//REPRESENATION_LEFT_NAV_LINK
		waitForElementToBeClickable(Entity.REPRESENATION_LEFT_NAV_LINK, "Representation link in Entity Profile Page");
		assertElementPresent(Entity.REPRESENATION_LEFT_NAV_LINK, "Representation link in Entity Profile Page");
		click(Entity.REPRESENATION_LEFT_NAV_LINK, "Click on Representation link");
		//FIRST_DROP_DOWN
		waitForElementPresent(Entity.FIRST_DROP_DOWN, "First drop down in represenation units Page");
		assertElementPresent(Entity.FIRST_DROP_DOWN, "First drop down in represenation units Page");
		selectByVisibleText(Entity.FIRST_DROP_DOWN,"Service Type","First drop down in represenation units Page");
		//SECOND_FILTER_DROP_DOWN
		waitForElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second drop down in represenation units Page");
		assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second drop down in represenation units Page");
		selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN,"contains","Second drop down in represenation units Page");
		//PSOP_INVOICES_TEXT_SEARCH
		waitForElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Text box Represenation units Page");
		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Text box Represenation units Page");
		type(Entity.PSOP_INVOICES_TEXT_SEARCH,"Domestic Representation (Limited" , "Text box Represenation units Page");
		//GO_BTN
		waitForElementToBeClickable(Entity.GO_BTN, "Go Button in Represenation units Page");
		assertElementPresent(Entity.GO_BTN, "Go Button in Represenation units Page");
		click(Entity.GO_BTN, "Click on Go Button in Represenation units Page");
		//FIRST_ENTITY_IN_GRID
		waitForElementToBeClickable(Entity.FIRST_ENTITY_IN_GRID, "First Representation link in Represenation units Page");
		assertElementPresent(Entity.FIRST_ENTITY_IN_GRID, "First Representation link in Represenation units Page");
		click(Entity.FIRST_ENTITY_IN_GRID, "Click on First Representation link in Represenation units Page");		
		//here pick filing date logic should come from the rep profile
		//REP_FILING_DATE
		waitForElementPresent(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		assertElementPresent(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repFilingDate = getText(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repDiscontinueDate = setTheDateForDS("forwardDate",repFilingDate).get(1);
		//DISCONTINUE_BUTTON
		waitForElementToBeClickable(Entity.DISCONTINUE_BUTTON, "Discontinue Button in Represenation units Page");
		assertElementPresent(Entity.DISCONTINUE_BUTTON, "Discontinue Button in Represenation units Page");
		click(Entity.DISCONTINUE_BUTTON, "Click on Discontinue Button in Represenation units Page");
		//FILING_DATE_FOR_DISCONTINUE
		waitForElementPresent(Entity.FILING_DATE_FOR_DISCONTINUE, "Filing text box in Represenation units Page");
		assertElementPresent(Entity.FILING_DATE_FOR_DISCONTINUE, "Filing text box in Represenation units Page");
		type(Entity.FILING_DATE_FOR_DISCONTINUE,repDiscontinueDate, "Filing text box in Represenation units Page");
		Thread.sleep(2000);
		//DISCONTINUE_REASON_DROP_DOWN
		waitForElementPresent(Entity.DISCONTINUE_REASON_DROP_DOWN, "First drop down in discontinue represenation units Page");
		assertElementPresent(Entity.DISCONTINUE_REASON_DROP_DOWN, "First drop down in discontinue represenation units Page");
		selectByVisibleText(Entity.DISCONTINUE_REASON_DROP_DOWN,"1 Year Suspension","First drop down in discontinue represenation units Page");
		Thread.sleep(2000);		
		//DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT
		waitForElementToBeClickable(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT, "Discontinue Button in Represenation units Page");
		assertElementPresent(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT, "Discontinue Button in Represenation units Page");		
		click(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT, "Click on Discontinue Button in Represenation units Page");
		Thread.sleep(1000);
		try {
			driver.findElement(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT);
			click(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT, "Click on Discontinue Button in Represenation units Page");
		}catch(NoSuchElementException e) {}
		Thread.sleep(3000);
   } 
    
}