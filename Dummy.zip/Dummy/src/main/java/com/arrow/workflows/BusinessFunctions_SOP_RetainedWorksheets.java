package com.arrow.workflows;

import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;

public class BusinessFunctions_SOP_RetainedWorksheets extends BusinessFunctions {

	public void retainedWorksheets(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// Click On SOP Link
			click(HomePage.SOPLINK, "SOP Link");

			// Click On Retained Worksheets from left nav bar
			click(SOP.RETAINED_WORKSHEETS_LEFT_NAV_LINK, "Retained Worksheets from left nav bar");
			waitForElementPresent(SOP.FIRST_WORKSHEET, "First Worksheet Link");
			assertTextMatching(SOP.PAGE_TITLE, "Retained Worksheets", "Page Title");

			//verify purge log
			click(SOP.PURGE_LOG_BTN,"Purge log Button");
			assertElementPresent(SOP.PURGE_LOG_ERROR, "Purge Log Error");
			
			// Click on First Checkbox and click on update remarks
			click(SOP.FIRST_CHECKBOX_ON_GRID, "First Checkbox on grid");
			click(SOP.UPDATE_REMARKS_BTN, "Update Remarks Button");

			assertTextMatching(SOP.PAGE_TITLE, "Update Remarks", "Page Title");

			// Update Remarks
			type(SOP.REMARKS_TEXTBOX, "Automation Testing", "Remarks Textbox");
			click(SOP.UPDATE_REMARKS_BTN, "Update Remarks Button");
			assertTextMatching(SOP.PAGE_TITLE, "Retained Worksheets", "Page Title");

			// Click on first worksheet link
			click(SOP.FIRST_WORKSHEET, "First Worksheet Link");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Page Title");

		} catch (Exception e) {
			throw e;
		}
	}

}
