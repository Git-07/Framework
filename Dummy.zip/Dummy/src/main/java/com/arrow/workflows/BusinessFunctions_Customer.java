package com.arrow.workflows;

import org.openqa.selenium.By;

import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Campaign;
import com.arrow.objectrepo.Customer;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Rep;
import com.arrow.objectrepo.XSOP;

public class BusinessFunctions_Customer extends BusinessFunctions {

	/********************************************************************************************************
	 * Method Name : SearchCustomerByID() Author : Pradyumna Description : This
	 * method will view Customers by Correct ID and Name Date of creation :
	 * 6/18/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SearchCustomerByID(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			String strCustomerName = Excelobject.getCellData(ReportSheet, "CustomerName", count);
			String strCity = Excelobject.getCellData(ReportSheet, "City", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer Name and ID but Customer ID should take priority over all
			// other entered fields
			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			type(Customer.CUSTOMER_NAME_SEARCH, strCustomerName, "Customer Name");
			type(Customer.CITY, strCity, "City Name");
			click(Customer.STATE_ALABAMA, "State");
			click(Customer.COUNTRY_ITALY, "Country");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");
			assertElementPresent(Customer.CUSTOMER_ID_MATCH, "Customer ID Matches");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : SearchCustomerByName() Author : Pradyumna Description : This
	 * method will view Customers by Correct Name Date of creation : 6/19/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SearchCustomerByName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strActiveCustomer = Excelobject.getCellData(ReportSheet, "ActiveCustomerName", count);
			String strInactiveCustomer = Excelobject.getCellData(ReportSheet, "InActiveCustomerName", count);
			String strCity = Excelobject.getCellData(ReportSheet, "City", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Active Customer Name
			type(Customer.CUSTOMER_NAME_SEARCH, strActiveCustomer, "Customer Name");
			type(Customer.CITY, strCity, "City Name");
			click(Customer.STATE_MICHIGAN, "State");
			click(Customer.COUNTRY_USA, "Country");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.ACTIVE_CUSTOMER_NAME, "Active Customer Name");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search by In-Active Customer Name
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			type(Customer.CUSTOMER_NAME_SEARCH, strInactiveCustomer, "In-Active Customer Name");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_RECORDS_FOUND, "No Records Found");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search by In-Active Customer Name again but with Inactive checkbox selected
			type(Customer.CUSTOMER_NAME_SEARCH, strInactiveCustomer, "In-Active Customer Name");
			click(Customer.INCLUDE_INACTIVE_CUSTOMER, "Inactive Checkbox");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.INACTIVE_CUSTOMER_NAME, "In-Active Customer Name");
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : UnsuccessfulCustomerSearch() Author : Pradyumna Description :
	 * This method will view Customers by Incorrect ID and Name Date of creation :
	 * 6/19/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String UnsuccessfulCustomerSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strIncorrectID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			String strIncorrectCustomerName = Excelobject.getCellData(ReportSheet, "CustomerName", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search for Incorrect Customer ID
			type(Customer.CUSTOMER_ID_SEARCH, strIncorrectID, "Incorrect Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_CUSTOMERID_ERROR, "No Customers found Error");
			// clear the text field now
			driver.findElement(By.id("txtCustomerNumber")).clear();

			// Search for Incorrect Customer Name
			type(Customer.CUSTOMER_NAME_SEARCH, strIncorrectCustomerName, "Incorrect Customer Name");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_RECORDS_FOUND, "No Records Found");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search with no Customer ID and Customer Name Error
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_CUSTOMERS_ERROR, "Error message with no Customer# or Name entered");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : SearchParticipantByID() Author : Pradyumna Description : This
	 * method will view Participants by ID and Name Date of creation : 6/26/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SearchParticipantByID(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			String strParticipantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);
			String strCity = Excelobject.getCellData(ReportSheet, "City", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Participant Name and ID but Participant ID should take priority
			// over all other entered fields
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			type(Customer.NAME_SEARCH, strParticipantName, "Participant Name");
			type(Customer.CITY, strCity, "City Name");
			click(Customer.STATE_ALABAMA, "State");
			click(Customer.COUNTRY_ITALY, "Country");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
			assertElementPresent(Customer.PARTICIPANT_NAME_MATCH, "Participant Name Matches with ID");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : SearchParticipantByName() Author : Pradyumna Description : This
	 * method will view Participants by Correct Name Date of creation : 7/2/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SearchParticipantByName(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strActiveParticipant = Excelobject.getCellData(ReportSheet, "ActiveParticipantName", count);
			String strInactiveParticipant = Excelobject.getCellData(ReportSheet, "InActiveParticipantName", count);
			String strCustomerName = Excelobject.getCellData(ReportSheet, "CustomerName", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search Page
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Active Participant Name
			type(Customer.NAME_SEARCH, strActiveParticipant, "Participant Name");
			type(Customer.CUSTOMER_NAME_SEARCH, strCustomerName, "Customer Name");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.ACTIVE_PARTICIPANT_NAME, "Active Participant Name");
			assertElementPresent(Customer.ACTIVE_PARTICIPANT_NAME, "Active Participant Name");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search by In-Active Customer Name
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			type(Customer.NAME_SEARCH, strInactiveParticipant, "In-Active Participant Name");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_RECORDS_FOUND, "No Records Found");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search by In-Active Customer Name again but with Inactive checkbox selected
			type(Customer.NAME_SEARCH, strInactiveParticipant, "In-Active Participant Name");
			click(Customer.INCLUDE_INACTIVE_PARTICIPANT, "Inactive Checkbox");
			click(Customer.SEARCH, "Search Button");
			Thread.sleep(5000);
			// waitForElementPresent(Customer.INACTIVE_PARTICIPANT_NAME, "In-Active
			// Participant Name");
			assertElementPresent(Customer.INACTIVE_PARTICIPANT_NAME, "In-Active Participant Name");
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : UnsuccessfulParticipantSearch() Author : Pradyumna Description
	 * : This method will view Participants by Incorrect ID and Name Date of
	 * creation : 7/2/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String UnsuccessfulParticipantsSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strIncorrectID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			String strIncorrectParticipantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search Page
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search for Incorrect Customer ID
			type(Customer.PARTICIPANT_ID_SEARCH, strIncorrectID, "Incorrect Participant ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_RECORDS_FOUND, "No Records Found");
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			// clear the text field now
			// driver.findElement(By.id("txtCustomerNumber")).clear();

			// Search for Incorrect Customer Name
			type(Customer.NAME_SEARCH, strIncorrectParticipantName, "Incorrect Participant Name");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_RECORDS_FOUND, "No Records Found");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search with no Participant ID and Participant Name Error
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_PARTICIPANTS_ERROR, "Error message with no Participants# or Name entered");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : CustomerPrint() Author : Pradyumna Description : This method
	 * will view Print option for Customers Date of creation : 7/5/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CustomerPrint(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer Name and ID but Customer ID should take priority over all
			// other entered fields
			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");
			assertElementPresent(Customer.CUSTOMER_ID_MATCH, "Customer ID Matches");
			click(Customer.CUSTOMER_PRINT, "Print Button");
			// On clicking Print Button, New window is opened. Below steps manages Jumps
			// from Parent to child & back to Parent Window
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			assertElementPresent(Customer.CUSTOMER_PRINT_VIEW, "Customer Profile View on Print Page");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : PaperlessParticipantSearch() Author : Pradyumna Description :
	 * This method will view Paperless Participant Search Date of creation :
	 * 7/5/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String PaperlessParticipantSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			String strParticipantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Paperless Participant Search Page
			click(Customer.PAPERLESS_PARTICIPANT_SEARCH, "Paperless Participant Search");
			assertElementPresent(Customer.PAPERLESS_PARTICIPANT_SEARCH_PAGE, "Paperless Participant Search Page");
			// Search by Paperless Participant ID
			type(Customer.PAPERLESS_ID_SEARCH, strParticipantID, "Paperless Participant ID");
			click(Customer.PAPERLESS_ID_CHECKBOX, "Paperless ID Checkbox");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.PAPERLESS_PARTICIPANT_NAME_MATCH, "Paperless Participant Name");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			// Search by Paperless Participant Name
			type(Customer.NAME_SEARCH, strParticipantName, "Paperless Participant Name");
			click(Customer.PAPERLESS_ID_CHECKBOX, "Paperless ID Checkbox");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.PAPERLESS_PARTICIPANT_NAME_MATCH, "Paperless Participant Name");
			click(Customer.SEARCH_AGAIN, "Search Again Button");

			assertElementPresent(Customer.PAPERLESS_PARTICIPANT_SEARCH_PAGE, "Paperless Participant Search Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : AccountSearch() Author : Pradyumna Description : This method
	 * will search for Account Date of creation : 7/5/2019 modifying person :
	 * Pradyumna Date of modification : 7/16/2019
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String AccountSearch(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strAccountName = Excelobject.getCellData(ReportSheet, "AccountName", count);
			String strAccountKeyword = Excelobject.getCellData(ReportSheet, "AccountKeyword", count);
			String strNoResult = Excelobject.getCellData(ReportSheet, "NoResult", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Account Search Page
			click(Customer.ACCOUNT_SEARCH, "Account Search");
			assertElementPresent(Customer.ACCOUNT_SEARCH_PAGE, "Account Search Page");

			// Search by Account Name with Leading Character Option
			type(Customer.NAME_SEARCH, strAccountName, "Account Name with leading character Search");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.ACCOUNT_NAME_MATCH, "Account Name Matches");
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(Customer.ACCOUNT_SEARCH_PAGE, "Account Search Page");

			// Search for Account Name with keyword option selected
			type(Customer.NAME_SEARCH, strAccountKeyword, "Account Keyword Character Search");
			click(Customer.KEYWORD, "Keyword Button");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.ACCOUNT_NAME_MATCH, "Account Name Matches");
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(Customer.ACCOUNT_SEARCH_PAGE, "Account Search Page");

			// Search for Account Name with default option selected but no records should be
			// displayed
			type(Customer.NAME_SEARCH, strNoResult, "No results Text Entered");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.NO_RECORDS_FOUND, "No Records Found");
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(Customer.ACCOUNT_SEARCH_PAGE, "Account Search Page");

			// Search Entity and Customer Links in Account Search Navigates user to correct
			// Page
			type(Customer.NAME_SEARCH, strAccountName, "Account Name with leading character Search");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.ACCOUNT_NAME_MATCH, "Account Name Matches");
			// Click on Entity Link
			click(Customer.ACCOUNT_ENTITY_LINK, "Entity Link");
			assertElementPresent(Generic.ENTITY_PROFILE, "Entity Profile");
			// Navigate back to Previous Page
			driver.navigate().back();
			// Click on Customer Link
			click(Customer.ACCOUNT_CUSTOMER_LINK, "Customer Link");
			assertElementPresent(Generic.CUSTOMER_PROFILE, "Customer Profile");
			// Navigate back to Previous Page
			driver.navigate().back();
			click(Customer.SEARCH_AGAIN, "Search Again Button");
			assertElementPresent(Customer.ACCOUNT_SEARCH_PAGE, "Account Search Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : NameHistory() Author : Pradyumna Description : This method will
	 * search for Name History of Customer Date of creation : 7/5/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ViewNameHistory(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer ID

			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			Thread.sleep(6000);
			waitForElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Navigate to Name History Page
			click(Customer.NAME_HISTORY, "Name History Tab");
			assertElementPresent(Customer.NAME_HISTORY_PAGE, "Name History Page");
			assertElementPresent(Customer.CUSTOMER_NAME_HISTORY, "View Name History of Customer");
			assertElementPresent(Customer.TYPE_IN_NAME_HISTORY, "Type of Name History");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ParticipantNoDeliverables() Author : Pradyumna Description :
	 * This method will search for Participant having no Deliverables Date of
	 * creation : 7/5/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ParticipantNoDeliverables(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			// click on Participant Search on Homepage
			click(Customer.PARTICIPANT_SEARCH, "Participant Search TAB");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Customer ID

			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");

			// Navigate to Participant Deliverables Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
			assertElementPresent(Customer.NO_RECORDS_DELIVERABLES, "No records for Participant Delieverables observed");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : CustomerDeliverables() Author : Pradyumna Description : This
	 * method will search for Customers having Deliverables Date of creation :
	 * 7/5/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String CustomerDeliverables(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			// click on Customer Tab on Homepage
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer ID

			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Navigate to Customer Deliverables Page
			click(Customer.CUSTOMER_DELIVERABLES, "Customer Deliverables Tab");
			assertElementPresent(Customer.CUSTOMER_DELIVERABLES_PAGE, "Customer Deliverables Page");

			assertElementPresent(Customer.DELIVERY_PARTICIPANT_NAME, "Participant Name");
			// Select Bulletin
			click(Generic.SELECT_DROPDOWN, "Select Dropdown");
			click(Customer.DELIVERABLE_TYPE, "Select Delivery Type");
			click(Generic.DROPDOWN_BULLETIN, "Select Bulletin");
			click(Generic.GO_BUTTON, "Select Go Button");
			assertElementPresent(Customer.BULLETIN_TEXT, "Bulletin Text");
			click(Generic.CLEAR_BUTTON, "Select Clear Button");

			// Select Communication
			click(Generic.SELECT_DROPDOWN, "Select Dropdown");
			click(Customer.DELIVERABLE_TYPE, "Select Delivery Type");
			click(Generic.DROPDOWN_COMMUNICATION, "Select Communication");
			click(Generic.GO_BUTTON, "Select Go Button");
			assertElementPresent(Customer.COMMUNICATION_TEXT, "Communication Text");
			click(Generic.CLEAR_BUTTON, "Select Clear Button");

			// Select Renewal
			click(Generic.SELECT_DROPDOWN, "Select Dropdown");
			click(Customer.DELIVERABLE_TYPE, "Select Delivery Type");
			click(Generic.DROPDOWN_RENEWAL, "Select Renewal");
			click(Generic.GO_BUTTON, "Select Go Button");
			assertElementPresent(Customer.RENEWAL_TEXT, "Renewal Text");
			click(Generic.CLEAR_BUTTON, "Select Clear Button");

			// Select XSOP
			click(Generic.SELECT_DROPDOWN, "Select Dropdown");
			click(Customer.DELIVERABLE_TYPE, "Select Delivery Type");
			click(Generic.DROPDOWN_XSOP, "Select XSOP");
			click(Generic.GO_BUTTON, "Select Go Button");
			assertElementPresent(Customer.XSOP_TEXT, "XSOP Text");
			click(Generic.CLEAR_BUTTON, "Select Clear Button");

			// Select SOP
			click(Generic.SELECT_DROPDOWN, "Select Dropdown");
			click(Customer.DELIVERABLE_TYPE, "Select Delivery Type");
			click(Generic.DROPDOWN_SOP, "Select SOP");
			click(Generic.GO_BUTTON, "Select Go Button");
			assertElementPresent(Customer.SOP_TEXT, "SOP Text");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ReplaceRecipient() Author : Pradyumna Description : This method
	 * will replace recipient in Participant Deliverables page Date of creation :
	 * 7/8/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ReplaceRecipient(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			String strComments = Excelobject.getCellData(ReportSheet, "Comments", count);
			String strParticipantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);
			// click on Customer Tab on Homepage
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer ID

			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Navigate to Participants Page
			click(Customer.PARTICIPANTS, "Participants Page");
			assertElementPresent(Customer.PARTICIPANTS_PAGE, "Participants Page");

			// Select one of the Active Participants
			click(Customer.ACTIVE_PARTICIPANT, "Active Participant");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");

			// Verify user is on Participant Deliverables page by clicking participant
			// deliverables
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
			// Replace Recipient and add Alternate Recipient
			click(Customer.REPLACE_RECIPIENT, "Replace Recipient");
			assertElementPresent(Customer.REPLACE_RECIPIENT_PAGE, "Replace Recipient Page");
			type(Generic.DI_HISTORY_COMMENT, strComments, "Comments");
			click(Customer.FIND_ALTERNATE_RECIPIENT, "Find Alternate Recipient");
			// Type Participant Name and Select Participant
			type(Customer.TEXT_PARTICIPANT_NAME, strParticipantName, "Participant Name");
			click(Generic.FIND_BUTTON, "Find Button");
			click(Generic.SELECT_BUTTON, "Select Button");

			// User should not be navigated to Confirm Recipient Replace
			assertElementPresent(Customer.CONFIRM_RECIPIENT_PAGE, "Confirm Recipient Replace Page");
			assertElementPresent(Customer.CHANGE_MESSAGE, "Recipient Change Message");

			click(Customer.RETURN_TO_PARTICIPANT_SEARCH, "Return to Participant Search Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ParticipantDeliverables() Author : Pradyumna Description : This
	 * method will verify Participant Search navigates to Participant Deliverables
	 * Date of creation : 7/10/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ParticipantDeliverables(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			String strComments = Excelobject.getCellData(ReportSheet, "Comments", count);

			// click on Participant Search on Homepage
			click(Customer.PARTICIPANT_SEARCH, "Particpant Search on Homepage");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Customer ID

			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");

			// Navigate to Participants Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			assertElementPresent(Customer.PARTICIPANT_DELIVERABLE_LIST, "Participant Deliverables List");
			assertElementPresent(Customer.SORT_DELIVERABLE_TYPE, "Deliverable Type");
			assertElementPresent(Customer.SORT_DI_SOURCE, "DI Source");
			assertElementPresent(Customer.SORT_AFFILIATION, "Affiliation");
			assertElementPresent(Customer.SORT_ENTITY_STATUS, "Entity Status");
			assertElementPresent(Customer.SORT_GENERIC_CD_ENTITY, "Generic CD Entity");
			assertElementPresent(Customer.SORT_BRANCH_PLANT, "Branch Plant");
			click(Customer.SORT_BRANCH_PLANT, "Branch Plant Clicked");
			assertElementPresent(Customer.SORT_BRANCH_PLANT_CLICKED, "Clicked Branch Plant");

			// ICOMM related verification
			click(Customer.SAVE_ICOMM, "Save ICOMM Button");
			assertElementPresent(Customer.COMMENT_ERROR, "Comment Error Message is displayed");
			type(Generic.COMMENTS, strComments, "Comment Entered");
			click(Customer.SAVE_ICOMM, "Save ICOMM Button");
			assertElementPresent(Customer.COMMENT_SUCCESS, "Comment Success Message is displayed");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ParticipantDeliverables() Author : Pradyumna Description : This
	 * method will verify if DI can be selected and unselected Date of creation :
	 * 7/11/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String SelectUnselectDI(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);

			// click on Participant Search on Homepage
			click(Customer.PARTICIPANT_SEARCH, "Particpant Search on Homepage");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Customer ID

			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");

			// Navigate to Participant Deliverables Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			// Checkbox with verification of Auto Renew Option
			click(Customer.ICOMM_CHECKBOX, "ICOMM Checkbox");
			assertElementPresent(Customer.AUTO_RENEW_DISABLED, "Auto Renew Disabled");
			// Need to check when its disabled

			click(Customer.REPLACE_RECIPIENT, "Replace Recipient");
			assertElementPresent(Customer.REPLACE_RECIPIENT_PAGE, "Replace Recipient Page");

			// Check all Select and Unselect Checkbox Options for DI
			assertElementPresent(Customer.CHECKBOX_CHECKED, "Checkbox is checked By Default");
			click(Customer.SELECT_NONE, "Select None");
			click(Customer.FIRST_CHECKBOX, "Select First Checkbox");
			// assertElementPresent(Customer.CHECKBOX_CHECKED, "Checkbox is checked Again");
			click(Customer.UNSELECT_PAGE, "Unselect Page");
			click(Customer.SELECT_ALL, "Select All");
			assertElementPresent(Customer.CHECKBOX_CHECKED, "Checkbox is checked Again");
			click(Customer.UNSELECT_PAGE, "Unselect Page");
			click(Customer.SELECT_PAGE, "Select Page");

			// Go back to Participant Deliverables Page
			click(Customer.BACK_TO_PARTICIPANT_DELIVERABLES, "Back to Participant Deliverables Page");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			// Click on Entity Link displayed on Page
			click(Customer.FIRST_LINK, "Entity Name");
			assertElementPresent(Generic.ENTITY_PROFILE, "Entity Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ParticipantReplaceRecipient() Author : Pradyumna Description :
	 * This method will replace recipient in Participant Deliverables page via
	 * Participant Search Date of creation : 7/12/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ParticipantReplaceRecipient(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			String strComments = Excelobject.getCellData(ReportSheet, "Comments", count);
			String strParticipantName = Excelobject.getCellData(ReportSheet, "ParticipantName", count);

			// click on Participant Search on Homepage
			click(Customer.PARTICIPANT_SEARCH, "Particpant Search on Homepage");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Customer ID

			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");

			// Navigate to Participant Deliverables Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			// Replace Recipient and add Alternate Recipient
			click(Customer.REPLACE_RECIPIENT, "Replace Recipient");
			assertElementPresent(Customer.REPLACE_RECIPIENT_PAGE, "Replace Recipient Page");
			type(Generic.DI_HISTORY_COMMENT, strComments, "Comments");
			click(Customer.FIND_ALTERNATE_RECIPIENT, "Find Alternate Recipient");
			// Type Participant Name and Select Participant
			type(Customer.TEXT_PARTICIPANT_NAME, strParticipantName, "Participant Name");
			click(Generic.FIND_BUTTON, "Find Button");
			click(Generic.SELECT_BUTTON, "Select Button");

			// User should not be navigated to Confirm Recipient Replace
			assertElementPresent(Customer.CONFIRM_RECIPIENT_PAGE, "Confirm Recipient Replace Page");
			assertElementPresent(Customer.CHANGE_MESSAGE, "Recipient Change Message");

			click(Customer.RETURN_TO_PARTICIPANT_SEARCH, "Return to Participant Search Button");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : ViewCustomerViaParticpant() Author : Pradyumna Description :
	 * This method will search for Customers via Participants Date of creation :
	 * 7/12/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String ViewCustomerViaParticpant(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			// click on Customer Tab on Homepage
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer ID

			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Navigate to Participant Page
			click(Customer.PARTICIPANTS, "Participants Tab");
			assertElementPresent(Customer.PARTICIPANTS_PAGE, "Participants Page");

			// Select First Participant and click on Customer Link Present in Participant
			// Profile
			click(Customer.FIRST_LINK, "Select First Participant");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile");
			assertElementPresent(Customer.CUSTOMER_NAME, "Customer Name");
			click(Customer.CUSTOMER_LINK, "Customer Link");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : sopViewingRights() Author : Pradyumna Description : This method
	 * will search for view rights of Participant Date of creation : 10/4/2019
	 * modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String sopViewingRights(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			// click on Customer Tab on Homepage
			click(HomePage.PARTICIPANT_SEARCH_LINK, "Participant Search Link");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Participant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile");

			click(Customer.VIEWING_RIGHTS, "Viewing Rights on Left Nav");
			assertElementPresent(Customer.SOP_VIEWING_RIGHTS_PAGE, "SOP Viewing Rights Page");
			click(Customer.ADD_PARTICIPANTS, "Add Participants");
			assertElementPresent(Customer.PICK_PARTICIPANTS_PAGE, "Pick Participants Page");
			click(Customer.SELECT_FIRST_PARTICIPANT, "Select First Participants");
			String parentWindow = driver.getWindowHandle();
			click(Customer.CRM_REQUESTID_SELECT, "Select CRM Request ID");
			handlePopUpWindwow();
			waitForElementPresent(Customer.CRM_REQUEST_SEARCH_PAGE, "CRM Request Search Page");
			assertElementPresent(Customer.CRM_REQUEST_SEARCH_PAGE, "CRM Request Search Page");
			type(Customer.CREATED_DATE, "01/01/2018", "Created Date entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			click(Customer.FIRSTID_SELECT, "First ID");
			// driver.close();
			driver.switchTo().window(parentWindow);
			click(Customer.ADD_SELECTED_PARTICIPANT, "Add Selected Participants");
			assertElementPresent(Customer.SOP_VIEWING_RIGHTS_PAGE, "SOP Viewing Rights Page");
			click(Customer.VIEW_HISTORY, "View History Button");
			assertElementPresent(Customer.VIEWING_RIGHTS_HISTORY_PAGE, "Viewing Rights History Page");
			click(Generic.CANCEL, "Go Back Button");
			assertElementPresent(Customer.SOP_VIEWING_RIGHTS_PAGE, "SOP Viewing Rights Page");
			click(Customer.CRM_REQUESTID_SELECT, "Select CRM Request ID");
			handlePopUpWindwow();
			assertElementPresent(Customer.CRM_REQUEST_SEARCH_PAGE, "CRM Request Search Page");
			type(Customer.CREATED_DATE, "01/01/2018", "Created Date entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			click(Customer.FIRSTID_SELECT, "First ID");
			driver.switchTo().window(parentWindow);
			click(Customer.SELECT_FIRST_PARTICIPANT, "Select First Participant");
			click(Customer.REMOVE_PARTICIPANT, "Remove Participant");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : cdsopViewingRights() Author : Pradyumna Description : This
	 * method will search for view rights of Participant in CDSOP Date of creation :
	 * 10/4/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String cdsopViewingRights(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantID", count);
			// click on Customer Tab on Homepage
			click(HomePage.PARTICIPANT_SEARCH_LINK, "Participant Search Link");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search by Participant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile");
			// Click on Viewing Rights Section
			click(Customer.VIEWING_RIGHTS, "Viewing Rights on Left Nav");
			click(Customer.CDSOP_LEFT_NAV, "CDSOP Left Nav");
			assertElementPresent(Customer.CDSOP_VIEWING_RIGHTS_PAGE, "CDSOP Viewing Rights Page");
			click(Customer.ADD_PARTICIPANTS, "Add Participants");
			assertElementPresent(Customer.PICK_PARTICIPANTS_PAGE, "Pick Participants Page");
			String parentWindow = driver.getWindowHandle();
			click(Customer.CRM_REQUESTID_SELECT, "Select CRM Request ID");
			handlePopUpWindwow();
			waitForElementPresent(Customer.CRM_REQUEST_SEARCH_PAGE, "CRM Request Search Page");
			assertElementPresent(Customer.CRM_REQUEST_SEARCH_PAGE, "CRM Request Search Page");
			type(Customer.CREATED_DATE, "01/01/2018", "Created Date entered");
			click(Generic.SEARCH_BUTTON, "Search Button");
			click(Customer.FIRSTID_SELECT, "First ID");
			// driver.close();
			driver.switchTo().window(parentWindow);
			// TODO
			// Uncomment and Validate Below Part once data is available
			/*
			 * click(Customer.SELECT_FIRST_PARTICIPANT, "Select First Participants");
			 * click(Customer.ADD_SELECTED_PARTICIPANT, "Add Selected Participants");
			 * assertElementPresent(Customer.CDSOP_VIEWING_RIGHTS_PAGE,
			 * "CDSOP Viewing Rights Page"); click(Customer.VIEW_HISTORY,
			 * "View History Button");
			 * assertElementPresent(Customer.VIEWING_RIGHTS_HISTORY_PAGE,
			 * "Viewing Rights History Page"); click(Generic.CANCEL, "Go Back Button");
			 * assertElementPresent(Customer.CDSOP_VIEWING_RIGHTS_PAGE,
			 * "CDSOP Viewing Rights Page"); click(Customer.CRM_REQUESTID_SELECT,
			 * "Select CRM Request ID"); handlePopUpWindwow();
			 * assertElementPresent(Customer.CRM_REQUEST_SEARCH_PAGE,
			 * "CRM Request Search Page"); type(Customer.CREATED_DATE, "01/01/2018",
			 * "Created Date entered"); click(Generic.SEARCH_BUTTON, "Search Button");
			 * click(Customer.FIRSTID_SELECT, "First ID");
			 * driver.switchTo().window(parentWindow);
			 * click(Customer.SELECT_FIRST_PARTICIPANT, "Select First Participant");
			 * click(Customer.REMOVE_PARTICIPANT, "Remove Participant");
			 */
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String customerRetriveStatus(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strCustomerId = Excelobject.getCellData(ReportSheet, "CustomerId", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer Name
			type(Customer.CUSTOMER_ID_SEARCH, strCustomerId, "Customer Name");
			click(Customer.SEARCH, "Search Button");
			// click(Customer.FIRST_CUSTOMER, "Select First Customer on the grid");
			assertTextMatching(Customer.PAGE_TITLE, "Customer Profile", "Page Title");
			click(Customer.RETRIVE_STATUS_BUTTON, "Retrive Status Btn");
			assertTextMatching(Customer.TNC_STATUS, "Accepted", "TnC Status");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String participantRetriveStatus(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Click on retrive status button and verify the status
			click(Customer.RETRIVE_STATUS_BUTTON, "Retrive Status Btn");
			assertTextMatching(Customer.TNC_STATUS, "Accepted", "TnC Status");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String entityBasedViewingRightsAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Click on Viewing Rights from left nav link
			click(Customer.VIEWING_RIGHTS, "Viewing Rights Link");
			assertTextMatching(Customer.PAGE_TITLE, "SOP History Viewing Rights", "Page Title");

			// Click on Add Entity Based Viewing Rights Btn
			click(Customer.ADD_ENTITY_BASED_VIEWING_RIGHTS_BTN, "Add Entity Based Viewing Rights Btn");
			assertTextMatching(Customer.PAGE_TITLE, "Affiliation/Sub Group/Entity Search Criteria", "Page Title");

			// Search affiliation
			type(Customer.NAME_SEARCH, "apple", "Affliation Name Text Box");
			click(Customer.SEARCH, "search button");

			// Select first affiliation
			click(Customer.FIRST_NAME_CHECKBOX, "First Checkbox");
			click(Customer.NEXT_BTN, "next btn");

			assertTextMatching(Customer.PAGE_TITLE, "Select SOP Viewing Limits", "Page Title");

			// Click on Specific Radio Btn of special Circumstances
			click(Customer.SPECIFIC_SPECIAL_CIRCUMSTANCES_RADIO_BTN, "Specific Radio Btn of special Circumstances");
			selectByIndex(Customer.SPECIAL_CIRCUMSTANCES_DROPDOWN, 1,
					"Select first value from special circumstances dropdown");
			click(Customer.RIGHT_ARROW, "Right Arrow Btn");

			// Click on Specific Radio Btn of Lawsuit Types
			click(Customer.SPECIFIC_LAWSUIT_TYPES_RADIO_BTN, "Specific Radio Btn of Lawsuit Types");
			selectByIndex(Customer.LAWSUIT_TYPE_DROPDOWN, 1, "Select first value from law suit type dropdown");
			click(Customer.LAWSUIT_RIGHT_ARROW, "Right Arrow Btn");

			// Click on CRM Request ID button
			click(Customer.CRM_REQUEST_ID_BTN, "CRM Request Id button");

			// Perform CRM Request Search
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			assertTextMatching(Customer.PAGE_TITLE, "CRM Request Search", "Page Title");
			type(Customer.CREATED_DATE, "03/17/2019", "Enter created date from");
			click(Customer.SEARCH, "search Button");
			click(Customer.FIRST_SELECT_BTN, "First Select Button");
			// driver.close();
			driver.switchTo().window(parentWindow);

			// Click on save button
			click(Customer.SAVE_BTN, "save button");
			assertTextMatching(Customer.PAGE_TITLE, "SOP History Viewing Rights", "Page Title");

			// Click on first CRM Request id
			click(Customer.FIRST_CRM_REQUEST_ID, "First CRM Request ID");
			assertTextMatching(Customer.PAGE_TITLE, "Edit Request", "Page Title");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String entityBasedViewingRightsEntity(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Click on Viewing Rights from left nav link
			click(Customer.VIEWING_RIGHTS, "Viewing Rights Link");
			assertTextMatching(Customer.PAGE_TITLE, "SOP History Viewing Rights", "Page Title");

			// Click on Add Entity Based Viewing Rights Btn
			click(Customer.ADD_ENTITY_BASED_VIEWING_RIGHTS_BTN, "Add Entity Based Viewing Rights Btn");
			assertTextMatching(Customer.PAGE_TITLE, "Affiliation/Sub Group/Entity Search Criteria", "Page Title");

			// Click on CTCORP Entity btn
			click(Customer.CTCORP_ENTITY_RADIO_BTN, "CTCORP Entity radio button");
			// Search affiliation
			type(Customer.NAME_SEARCH, "apple", "Entity Name Text Box");
			click(Customer.SEARCH, "search button");

			// Select first affiliation
			click(Customer.FIRST_NAME_CHECKBOX, "First Checkbox");
			click(Customer.NEXT_BTN, "next btn");

			assertTextMatching(Customer.PAGE_TITLE, "Select SOP Viewing Limits", "Page Title");

			// Click on Specific Radio Btn of special Circumstances
			click(Customer.SPECIFIC_SPECIAL_CIRCUMSTANCES_RADIO_BTN, "Specific Radio Btn of special Circumstances");
			selectByIndex(Customer.SPECIAL_CIRCUMSTANCES_DROPDOWN, 1,
					"Select first value from special circumstances dropdown");
			click(Customer.RIGHT_ARROW, "Right Arrow Btn");

			// Click on Specific Radio Btn of Lawsuit Types
			click(Customer.SPECIFIC_LAWSUIT_TYPES_RADIO_BTN, "Specific Radio Btn of Lawsuit Types");
			selectByIndex(Customer.LAWSUIT_TYPE_DROPDOWN, 1, "Select first value from law suit type dropdown");
			click(Customer.LAWSUIT_RIGHT_ARROW, "Right Arrow Btn");

			// Click on CRM Request ID button
			click(Customer.CRM_REQUEST_ID_BTN, "CRM Request Id button");

			// Perform CRM Request Search
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			assertTextMatching(Customer.PAGE_TITLE, "CRM Request Search", "Page Title");
			type(Customer.CREATED_DATE, "03/17/2019", "Enter created date from");
			click(Customer.SEARCH, "search Button");
			click(Customer.FIRST_SELECT_BTN, "First Select Button");
			// driver.close();
			driver.switchTo().window(parentWindow);

			// Click on save button
			click(Customer.SAVE_BTN, "save button");
			assertTextMatching(Customer.PAGE_TITLE, "SOP History Viewing Rights", "Page Title");

			// Click on first CRM Request id
			click(Customer.FIRST_CRM_REQUEST_ID, "First CRM Request ID");
			assertTextMatching(Customer.PAGE_TITLE, "Edit Request", "Page Title");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String entityBasedViewingRightsSubGroup(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Click on Viewing Rights from left nav link
			click(Customer.VIEWING_RIGHTS, "Viewing Rights Link");
			assertTextMatching(Customer.PAGE_TITLE, "SOP History Viewing Rights", "Page Title");

			// Click on Add Entity Based Viewing Rights Btn
			click(Customer.ADD_ENTITY_BASED_VIEWING_RIGHTS_BTN, "Add Entity Based Viewing Rights Btn");
			assertTextMatching(Customer.PAGE_TITLE, "Affiliation/Sub Group/Entity Search Criteria", "Page Title");

			// Click on CTCORP Sub Group btn
			click(Customer.CTCORP_SUBGROUP_RADIO_BTN, "CTCORP Sub Group radio button");
			// Search affiliation
			type(Customer.NAME_SEARCH, "apple", "Sub Group Name Text Box");
			click(Customer.SEARCH, "search button");

			// Select first affiliation
			click(Customer.FIRST_NAME_CHECKBOX, "First Checkbox");
			click(Customer.NEXT_BTN, "next btn");

			assertTextMatching(Customer.PAGE_TITLE, "Select SOP Viewing Limits", "Page Title");

			// Click on Specific Radio Btn of special Circumstances
			click(Customer.SPECIFIC_SPECIAL_CIRCUMSTANCES_RADIO_BTN, "Specific Radio Btn of special Circumstances");
			selectByIndex(Customer.SPECIAL_CIRCUMSTANCES_DROPDOWN, 1,
					"Select first value from special circumstances dropdown");
			click(Customer.RIGHT_ARROW, "Right Arrow Btn");

			// Click on Specific Radio Btn of Lawsuit Types
			click(Customer.SPECIFIC_LAWSUIT_TYPES_RADIO_BTN, "Specific Radio Btn of Lawsuit Types");
			selectByIndex(Customer.LAWSUIT_TYPE_DROPDOWN, 1, "Select first value from law suit type dropdown");
			click(Customer.LAWSUIT_RIGHT_ARROW, "Right Arrow Btn");

			// Click on CRM Request ID button
			click(Customer.CRM_REQUEST_ID_BTN, "CRM Request Id button");

			// Perform CRM Request Search
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			assertTextMatching(Customer.PAGE_TITLE, "CRM Request Search", "Page Title");
			type(Customer.CREATED_DATE, "03/17/2019", "Enter created date from");
			click(Customer.SEARCH, "search Button");
			click(Customer.FIRST_SELECT_BTN, "First Select Button");
			// driver.close();
			driver.switchTo().window(parentWindow);

			// Click on save button
			click(Customer.SAVE_BTN, "save button");
			assertTextMatching(Customer.PAGE_TITLE, "SOP History Viewing Rights", "Page Title");

			// Click on first CRM Request id
			click(Customer.FIRST_CRM_REQUEST_ID, "First CRM Request ID");
			assertTextMatching(Customer.PAGE_TITLE, "Edit Request", "Page Title");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String requestCompanyBookEntity(String ReportSheet, int count) throws Throwable {
		try {
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			// click on Customer Tab on Homepage
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer ID

			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on select button of affiliation
			click(Customer.SELECT_AFFILIATION_BTN, "select button of affiliation");
			assertTextMatching(Customer.PAGE_TITLE, "Find Entity / Affiliation", "Title of the page");

			// Click on CTCORP Entity btn
			click(Customer.CTCORP_ENTITY_RADIO_BTN, "CTCORP Entity radio button");
			// Search Entity
			type(Customer.NAME_SEARCH, "apple", "Entity Name Text Box");
			click(Customer.SEARCH, "search button");
			assertTextMatching(Customer.PAGE_TITLE, "Pick Entity", "Title of the page");

			// Click on first select entity on grid
			click(Customer.FIRST_SELECT_BTN_ON_GRID, "First select button on grid");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");
			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on select button of affiliation
			click(Customer.SELECT_AFFILIATION_BTN, "select button of affiliation");
			assertTextMatching(Customer.PAGE_TITLE, "Find Entity / Affiliation", "Title of the page");

			// Click on NRAI Entity btn
			click(Customer.NRAI_ENTITY_RADIO_BTN, "NRAI Entity radio button");
			// Search entity
			type(Customer.NAME_SEARCH, "apple", "Entity Name Text Box");
			click(Customer.SEARCH, "search button");
			assertTextMatching(Customer.PAGE_TITLE, "Pick Entity", "Title of the page");

			// Click on first select entity on grid
			click(Customer.FIRST_SELECT_BTN_ON_GRID, "First select button on grid");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String requestCompanyBookAffiliation(String ReportSheet, int count) throws Throwable {
		try {
			String strCustomerID = Excelobject.getCellData(ReportSheet, "CustomerID", count);
			// click on Customer Tab on Homepage
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Search by Customer ID

			type(Customer.CUSTOMER_ID_SEARCH, strCustomerID, "Customer ID");
			click(Customer.SEARCH, "Search Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on select button of affiliation
			click(Customer.SELECT_AFFILIATION_BTN, "select button of affiliation");
			assertTextMatching(Customer.PAGE_TITLE, "Find Entity / Affiliation", "Title of the page");

			// Search affiliation
			type(Customer.NAME_SEARCH, "apple", "Entity Name Text Box");
			click(Customer.SEARCH, "search button");
			assertTextMatching(Customer.PAGE_TITLE, "Pick Affiliation", "Title of the page");

			// Click on first select entity on grid
			click(Customer.FIRST_SELECT_BTN_ON_GRID, "First select button on grid");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");
			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on select button of affiliation
			click(Customer.SELECT_AFFILIATION_BTN, "select button of affiliation");
			assertTextMatching(Customer.PAGE_TITLE, "Find Entity / Affiliation", "Title of the page");

			// Click on NRAI Entity btn
			click(Customer.NRAI_AFFILIATION_RADIO_BTN, "NRAI Affiliation radio button");
			// Search affiliation
			type(Customer.NAME_SEARCH, "apple", "Entity Name Text Box");
			click(Customer.SEARCH, "search button");
			assertTextMatching(Customer.PAGE_TITLE, "Pick Affiliation", "Title of the page");

			// Click on first select entity on grid
			click(Customer.FIRST_SELECT_BTN_ON_GRID, "First select button on grid");
			assertTextMatching(Customer.PAGE_TITLE, "Request Company Book", "Title of the page");

			// Click on Request Company Book Button
			click(Customer.REQUEST_COMPANY_BOOK_BTN, "Request Company Book Button");
			assertElementPresent(Customer.CUSTOMER_PROFILE, "Customer Profile Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String regroupEntities(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "Participant Name", count);

			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Click on Regroup Entities Button
			click(Customer.REGROUP_ENTITIES_BTN, "Regroup Entities Button");
			assertTextMatching(Customer.PAGE_TITLE, "Regroup Entities", "Page Title");

			// Click on Check box for first entity
			click(Customer.FIRST_CHECKBOX_ENTITY, "First Checkbox for entity");

			// Verify for standalone
			getAttribute(Customer.STANDALONE_ENTITY_RADIO_BTN, "checked");
			// Add comments and click on regroup button
			type(Customer.COMMENTS_TEXTBOX, "Automation Testing", "Comments Textbox");
			click(Customer.REGROUP_BTN, "Regroup Button");
			handlepopup();

			// Click on Check box for first entity
			click(Customer.FIRST_CHECKBOX_ENTITY, "First Checkbox for entity");

			// Verify for Join Existing
			// Click on Join Existing Radio Button
			click(Customer.JOIN_EXISTING_RADIO_BTN, "Join Existing Radio Button");
			// Add comments and click on regroup button
			type(Customer.COMMENTS_TEXTBOX, "Automation Testing", "Comments Textbox");
			click(Customer.REGROUP_BTN, "Regroup Button");
			handlepopup();

			// Verify for join new
			// Click on Check box for first entity
			click(Customer.FIRST_CHECKBOX_ENTITY, "First Checkbox for entity");
			// Click on Join New Radio Button
			click(Customer.JOIN_NEW_RADIO_BTN, "Join New Radio Button");

			// Enter Affiliation Details
			type(Customer.AFFILIATION_NAME_TEXTBOX, "Automation test", "Affiliation Name Textbox");
			selectByIndex(Customer.COMMON_RENEWAL_DRPDWN, 1, "Common Renewal Dropdown");
			type(Customer.SUBGROUP_NAME_TEXTBOX, "Automation test1", "Subgroup Name Textbox");
			click(Customer.SELECT_RECIPIENT_BTN, "Select Recipient Button");
			waitForElementPresent(Entity.PARTICIPANTNAMEFIELD, "Participant Name Text Field");
			type(Entity.PARTICIPANTNAMEFIELD, strRecipient, "Participant Name field");
			click(Entity.FINDBTN, "Find button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			type(Customer.AFFILIATION_COMMENTS_TEXTBOX, "Automation Testing", "Affiliation Comments Textbox");
			type(Customer.COMMENTS_TEXTBOX, "Automation Testing", "Comments Textbox");
			handlepopup();
			assertTextMatching(Customer.PAGE_TITLE, "Regroup Entities", "Page Title");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyRenewalDIForValidPaymentProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "RecipientName", count);

			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Navigate to Participant Deliverables Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			// Select Deliverable Type from first filter and Select Renewal from RHS
			// Filter
			click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
			click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
			click(Customer.GO_BTN, "Go Button");

			if (isElementNotPresent(Customer.NO_RECORDS_DELIVERABLES, "No records found")) {
				isEnabled(Customer.AUTORENEW_CHECKBOX, "Enabled Auto Renew Checkbox");
				isEnabled(Customer.AUTO_RENEW, "Enabled Auto Renew Button");
				click(Customer.REPLACE_RECIPIENT, "Replace Recipient Btn");

				assertElementPresent(Customer.REPLACE_RECIPIENT_PAGE, "Replace Recipient Page");
				click(Customer.SELECT_NONE, "Select None Btn");
				click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
				click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
				click(Customer.GO_BTN, "Go Button");
				click(Customer.FIRST_CHECKBOX, "First DI Source");
				click(Customer.FORMER_RECIPIENT_COMMENT, "Comments Entered");
				click(Customer.FIND_ALTERNATE_RECIPIENT, "Alternate Recipient Btn");
				waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
				assertTextMatching(Customer.PAGE_TITLE, "Find DI Recipient", "Page Title");
				type(Customer.PARTICIPANT_NAME_TEXTFIELD, strRecipient, "Participant Name field");
				click(Customer.FIND_BTN, "FIND Button");
				assertTextMatching(Customer.PAGE_TITLE, "Pick DI Recipient", "Page Title");
				click(Customer.FIRST_SELECT_BTN_ON_GRID, "First Select Button");
				assertElementPresent(Customer.CONFIRM_RECIPIENT_PAGE, "Confirm Replace Recipient Page");
				click(Customer.PARTICIPANT_PROFILE_TAB, "Participant Profile Tab");
				assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
				if (verifyIfElementPresent(Customer.AUTO_RENEW_LINK, "View Auto-Renew Profile Details")) {
					String parentWindow = driver.getWindowHandle();
					click(Customer.AUTO_RENEW_LINK, "View Auto-Renew Profile Details");
					handlePopUpWindwow();
					isElementPresent(Customer.SERVER_ERROR, "Server Error Text");
					driver.close();
					driver.switchTo().window(parentWindow);
					assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
					click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
					assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
					click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
					click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
					click(Customer.GO_BTN, "Go Button");
					click(Customer.SELECT_IMG_NONE, "Select None Btn");
					click(Customer.AUTORENEW_CHECKBOX, "First Auto Renew Checkbox");
					type(Customer.COMMENT_TEXTBOX, "Add Comment to Auto Renew", "Comments");
					click(Customer.AUTO_RENEW, "Auto Renew Button");
					click(Customer.FIRST_CUSTOMER, "First Data");
					click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Tab");
					assertTextMatching(Entity.AUTO_RENEW_STATUS, "Active", "Auto Renew Status");
				} else {
					click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
					assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
					click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
					click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
					click(Customer.GO_BTN, "Go Button");
					click(Customer.SELECT_NONE, "Select None Btn");
					click(Customer.AUTORENEW_CHECKBOX, "First Auto Renew Checkbox");
					type(Customer.COMMENT_TEXTBOX, "Add Comment to Auto Renew", "Comments");
					click(Customer.AUTO_RENEW, "Auto Renew Button");
					click(Customer.FIRST_CUSTOMER, "First Data");
					click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Tab");
					assertTextMatching(Entity.AUTO_RENEW_STATUS, "Inactive", "Auto Renew Status");
				}
			} else {
				click(Customer.PARTICIPANT_PROFILE_TAB, "Participant Profile Tab");
				assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyRenewalDIForValidInvalidPaymentProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParicipantId", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "RecipientName", count);

			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Navigate to Participant Deliverables Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			// Select Deliverable Type from first filter and Select Renewal from RHS
			// Filter
			click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
			click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
			click(Customer.GO_BTN, "Go Button");

			if (isElementNotPresent(Customer.NO_RECORDS_DELIVERABLES, "No records found")) {
				isEnabled(Customer.AUTORENEW_CHECKBOX, "Enabled Auto Renew Checkbox");
				isEnabled(Customer.AUTO_RENEW, "Enabled Auto Renew Button");
				click(Customer.REPLACE_RECIPIENT, "Replace Recipient Btn");

				assertElementPresent(Customer.REPLACE_RECIPIENT_PAGE, "Replace Recipient Page");
				click(Customer.SELECT_NONE, "Select None Btn");
				click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
				click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
				click(Customer.GO_BTN, "Go Button");
				click(Customer.FIRST_CHECKBOX, "First DI Source");
				click(Customer.FORMER_RECIPIENT_COMMENT, "Comments Entered");
				click(Customer.FIND_ALTERNATE_RECIPIENT, "Alternate Recipient Btn");
				waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
				assertTextMatching(Customer.PAGE_TITLE, "Find DI Recipient", "Page Title");
				type(Customer.PARTICIPANT_NAME_TEXTFIELD, strRecipient, "Participant Name field");
				click(Customer.FIND_BTN, "FIND Button");
				assertTextMatching(Customer.PAGE_TITLE, "Pick DI Recipient", "Page Title");
				click(Customer.FIRST_SELECT_BTN_ON_GRID, "First Select Button");
				assertElementPresent(Customer.CONFIRM_RECIPIENT_PAGE, "Confirm Replace Recipient Page");
				click(Customer.PARTICIPANT_PROFILE_TAB, "Participant Profile Tab");
				assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
				if (verifyIfElementPresent(Customer.AUTO_RENEW_LINK, "View Auto-Renew Profile Details")) {
					String parentWindow = driver.getWindowHandle();
					click(Customer.AUTO_RENEW_LINK, "View Auto-Renew Profile Details");
					handlePopUpWindwow();
					isElementPresent(Customer.SERVER_ERROR, "Server Error Text");
					driver.close();
					driver.switchTo().window(parentWindow);
					assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
					click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
					assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
					click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
					click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
					click(Customer.GO_BTN, "Go Button");
					click(Customer.SELECT_IMG_NONE, "Select None Btn");
					click(Customer.AUTORENEW_CHECKBOX, "First Auto Renew Checkbox");
					type(Customer.COMMENT_TEXTBOX, "Add Comment to Auto Renew", "Comments");
					click(Customer.AUTO_RENEW, "Auto Renew Button");
					click(Customer.FIRST_CUSTOMER, "First Data");
					click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Tab");
					assertTextMatching(Entity.AUTO_RENEW_STATUS, "Active", "Auto Renew Status");
				} else {
					click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
					assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
					click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
					click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
					click(Customer.GO_BTN, "Go Button");
					click(Customer.FIRST_CUSTOMER, "First Data");
					click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Tab");
					assertTextMatching(Entity.AUTO_RENEW_STATUS, "Inactive", "Auto Renew Status");
				}
			} else {
				click(Customer.PARTICIPANT_PROFILE_TAB, "Participant Profile Tab");
				assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyRenewalDIForInvalidPaymentProfile(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strParticipantID = Excelobject.getCellData(ReportSheet, "ParticipantId", count);
			String strRecipient = Excelobject.getCellData(ReportSheet, "RecipientName", count);

			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// Navigate to Participant Search section
			click(Customer.PARTICIPANT_SEARCH, "Participant Search");
			assertElementPresent(Customer.PARTICIPANT_SEARCH_PAGE, "Participant Search Page");
			// Search byParticipant ID
			type(Customer.PARTICIPANT_ID_SEARCH, strParticipantID, "Participant ID");
			click(Customer.SEARCH, "Search Button");
			waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
			assertTextMatching(Customer.PAGE_TITLE, "Participant Profile", "Page Title");

			// Navigate to Participant Deliverables Page
			click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
			assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");

			// Select Deliverable Type from first filter and Select Renewal from RHS
			// Filter
			click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
			click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
			click(Customer.GO_BTN, "Go Button");

			if (isElementNotPresent(Customer.NO_RECORDS_DELIVERABLES, "No records found")) {
				isDisabled(Customer.AUTORENEW_CHECKBOX, "Enabled Auto Renew Checkbox");
				isDisabled(Customer.AUTO_RENEW, "Enabled Auto Renew Button");
				click(Customer.REPLACE_RECIPIENT, "Replace Recipient Btn");

				assertElementPresent(Customer.REPLACE_RECIPIENT_PAGE, "Replace Recipient Page");
				click(Customer.SELECT_NONE, "Select None Btn");
				click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
				click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
				click(Customer.GO_BTN, "Go Button");
				click(Customer.FIRST_CHECKBOX, "First DI Source");
				click(Customer.FORMER_RECIPIENT_COMMENT, "Comments Entered");
				click(Customer.FIND_ALTERNATE_RECIPIENT, "Alternate Recipient Btn");
				waitForElementPresent(Customer.PAGE_TITLE, "Page Title");
				assertTextMatching(Customer.PAGE_TITLE, "Find DI Recipient", "Page Title");
				type(Customer.PARTICIPANT_NAME_TEXTFIELD, strRecipient, "Participant Name field");
				click(Customer.FIND_BTN, "FIND Button");
				assertTextMatching(Customer.PAGE_TITLE, "Pick DI Recipient", "Page Title");
				click(Customer.FIRST_SELECT_BTN_ON_GRID, "First Select Button");
				assertElementPresent(Customer.CONFIRM_RECIPIENT_PAGE, "Confirm Replace Recipient Page");
				click(Customer.PARTICIPANT_PROFILE_TAB, "Participant Profile Tab");
				assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
				if (verifyIfElementPresent(Customer.AUTO_RENEW_LINK, "View Auto-Renew Profile Details")) {
					String parentWindow = driver.getWindowHandle();
					click(Customer.AUTO_RENEW_LINK, "View Auto-Renew Profile Details");
					handlePopUpWindwow();
					isElementPresent(Customer.SERVER_ERROR, "Server Error Text");
					driver.close();
					driver.switchTo().window(parentWindow);
					assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
					click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
					assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
					click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
					click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
					click(Customer.GO_BTN, "Go Button");
					click(Customer.SELECT_IMG_NONE, "Select None Btn");
					click(Customer.AUTORENEW_CHECKBOX, "First Auto Renew Checkbox");
					type(Customer.COMMENT_TEXTBOX, "Add Comment to Auto Renew", "Comments");
					click(Customer.AUTO_RENEW, "Auto Renew Button");
					click(Customer.FIRST_CUSTOMER, "First Data");
					click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Tab");
					assertTextMatching(Entity.AUTO_RENEW_STATUS, "Active", "Auto Renew Status");
				} else {
					click(Customer.PARTICIPANT_DELIVERABLES, "Participant Deliverables Tab");
					assertElementPresent(Customer.PARTICIPANT_DELIVERABLES_PAGE, "Participant Deliverables Page");
					click(Customer.DELIVERABLETYPE_DRPDWN, "Select Deliverable Type from Drop Down");
					click(Customer.RENEWAL_RHS_FILTER, "RHS Filter");
					click(Customer.GO_BTN, "Go Button");
					click(Customer.FIRST_CUSTOMER, "First Data");
					click(Entity.DELIVERY_INSTRUCTIONS, "Delivery Instructions Tab");
					assertTextMatching(Entity.AUTO_RENEW_STATUS, "Inactive", "Auto Renew Status");
				}
			} else {
				click(Customer.PARTICIPANT_PROFILE_TAB, "Participant Profile Tab");
				assertElementPresent(Customer.PARTICIPANT_PROFILE, "Participant Profile Page");
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String emailVerificationStatus(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			// click on Customer Top Nav link
			click(HomePage.CUSTOMER_TOP_NAV, "Customer TAB");
			assertElementPresent(Customer.CUSTOMER_SEARCH_PAGE, "Customer Search Page");
			// click on Customer Email Verification Status Link
			click(Customer.EMAIL_VERIFICATION_LEFT_TAB, "Email Verification Status TAB");
			// select Name,Customer Name,Email Address, Owning Service Team,Source from drp dwn
			click(Customer.NAME_DRPDWN, "Select Name from drp dwn");
			click(Customer.CUSTOMER_NAME_DRPDWN, "Select Customer Name from drp dwn");
			click(Customer.EMAIL_ADDRESS_DRPDWN, "Select Email Address from drp dwn");
			click(Customer.OWNING_SERVICE_TEAM_DRPDWN, "Select Owning Service Team from drp dwn");
			click(Customer.SOURCE_DRPDWN, "Select Source from drp dwn");
			
			// For Pagination Check
			// Click on First,Previous,1-10,11-20.,...,Next,Last Links
			click(Entity.FIRST_PAGE_LINK, "Click on First Link to display 1st Page");
			click(Entity.PREVIOUS_PAGE_LINK, "Click on Previous Link to display Previous Page");
			click(Entity.PAGE_11__20_LINK, "Click on 11-20 link");
			click(Entity.NEXT_PAGE_LINK, "Click on Next Link to display Next Page");
			click(Entity.LAST_PAGE_LINK, "Click on Last Link to display Last Page");
			
			// Check whether All sorting links are present
			click(Customer.ACTIVE_NAME_SORT_LINK, "Active Sort By Name Link");
			//isElementPresent(Customer.ACTIVE_NAME_SORT_LINK, "Active Sort By Name Link");
			isElementPresent(Customer.CUSTOMER_NAME_SORT, "Inactive Sort By Customer Name Link");
			isElementPresent(Customer.EMAIL_ADDRESS_SORT, "Inactive Sort By Email Address Link");
			isElementPresent(Customer.OWNING_SERVICE_TEAM_SORT, "Inactive Sort By Owning Service Team Link");
			isElementPresent(Customer.SOURCE_SORT, "Inactive Sort By Source Link");
			
			click(Customer.CUSTOMER_NAME_SORT, "Inactive Sort By Customer Name Link");
			isElementPresent(Customer.ACTIVE_CUSTOMER_NAME_SORT_LINK, "Active Sort By Customer Name Link");
			click(Customer.EMAIL_ADDRESS_SORT, "Inactive Sort By Email Address Link");
			isElementPresent(Customer.ACTIVE_EMAIL_ADDRESS_SORT_LINK, "Active Sort By Email Address Link");
			click(Customer.OWNING_SERVICE_TEAM_SORT, "Inactive Sort By Owning Service Team Link");
			isElementPresent(Customer.ACTIVE_OWNING_SERVICE_TEAM_SORT_LINK, "Active Sort By Owning Service Team Link");
			click(Customer.SOURCE_SORT, "Inactive Sort By Source Link");
			isElementPresent(Customer.ACTIVE_SOURCE_SORT_LINK, "Active Sort By Source Link");
			
	        String parentWindow = driver.getWindowHandle();
			click(Customer.VIEW_RESULTS_BTN, "View Results Btn");
			handlePopUpWindwow();
			isElementNotPresent(Customer.SERVER_ERROR, "Server Error Text");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertTextMatching(Customer.PAGE_TITLE, "Email Verification Status", "Email Verification Status");
			

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}