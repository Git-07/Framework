package com.arrow.workflows;

import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.ActionItems_SOP;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.WorksheetCreate;

import net.sourceforge.htmlunit.corejs.javascript.regexp.SubString;

import com.arrow.objectrepo.PostLog;;

public class BusinessFunctions_SOP_UnPostLogs extends BusinessFunctions_SOP_CreateWorksheet{

	/********************************************************************************************************
	 * Method Name : attemptUnPostedLog() 
	 * Author : Pradyumna 
	 * Description : This method will verify UnPosted Logs with Attempted as Yes
	 * Date of creation : 8/12/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String attemptUnPostedLog(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			//createWorksheet(ReportSheet,count);
			viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			String worksheetId=getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id on context bar");
			String wokId=worksheetId.substring(7);
			// Click On Choose DI Button
			click(ActionItems_SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// Click on Actions List Btn and then click on Mangage Actions List Button
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			//Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");
			//Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(ActionItems_SOP.COURIER_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name
			type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Action List Btn");
			assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
			click(ActionItems_SOP.EXECUTE_BTN, "Action List Btn");

			//click on unposted link from left nav bar
			click(PostLog.UNPOSTED_LOG,"Unposted Log");
			assertElementPresent(PostLog.UNPOSTED_LOG_TITLE, "Un Posted Log Title");		
			//Select Worksheet from DropDown
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log Id");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Is equal to");
			type(Generic.DROP_DOWN_TEXT, wokId, "Entered Date");
			click(Generic.GO_BUTTON,"Go Button");		

			//Select the displayed Log and Edit the worksheet with Attempted as "Yes"
			click(PostLog.LOG_ID,"Select displayed Log ID");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.WORKSHEET_EDIT_BTN,"Edit Button");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");

			click(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Select Attempted as yes radio button");
			click(SOP.SAVE_BTN,"Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(PostLog.ATTEMPTED_DISPLAYED, "Attempted displayed as Yes");	

			//Navigate to Unposted Log and check log is now no more displayed
			click(PostLog.UNPOSTED_LOG, "Un-Posted Log");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log ID");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, wokId , "Entered Log ID");
			click(Generic.GO_BUTTON,"Go Button");
			assertElementPresent(Generic.NO_RECORDS_FOUND2, "No records found");


		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : rejectUnPostedLog() 
	 * Author : Pradyumna 
	 * Description : This method will verify UnPosted Logs with Attempted as Yes
	 * Date of creation : 8/12/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String rejectUnPostedLog(String ReportSheet, int count, String esopId) throws Throwable {
		
		try {
			blnEventReport = true;
			//createWorksheet(ReportSheet,count);
			
			viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			String worksheetId=getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id on context bar");
			String wokId=worksheetId.substring(7);
			// Click On Choose DI Button
			click(ActionItems_SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// Click on Actions List Btn and then click on Mangage Actions List Button
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			//Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");
			//Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(ActionItems_SOP.COURIER_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name
			type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Action List Btn");
			assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
			click(ActionItems_SOP.EXECUTE_BTN, "Action List Btn");

			//click on unposted link from left nav bar
			click(PostLog.UNPOSTED_LOG,"Unposted Log");
			assertElementPresent(PostLog.UNPOSTED_LOG_TITLE, "Un Posted Log Title");		
			//Select Worksheet from DropDown
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log Id");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Is equal to");
			type(Generic.DROP_DOWN_TEXT, wokId, "Entered Date");
			click(Generic.GO_BUTTON,"Go Button");		

			//Select the displayed Log and Edit the worksheet with Attempted as "Yes"
			click(PostLog.LOG_ID,"Select displayed Log ID");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.WORKSHEET_EDIT_BTN,"Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			click(WorksheetCreate.ASSIGNED_TO_GLYPHICON_WORKSHEET, "Glyphicon Click");
			click(WorksheetCreate.SELECT_GLOBAL_PROCESSING_CENTRE, "Global Processing Center");
			click(WorksheetCreate.ASSIGNED_TO_GLYPHICON_WORKSHEET, "Glyphicon Click");
			click(WorksheetCreate.EDITED_ASSIGNED_TO_TEAM, "SOP Support Team");
			click(WorksheetCreate.ASSIGNED_TO_GLYPHICON_WORKSHEET, "Glyphicon Click");
			click(WorksheetCreate.EDITED_ASSIGN_TO, "Amy McLaren");
			click(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Select Attempted as Yes");
			/*selectByIndex(WorksheetCreate.REJECT_REASON, 2, "Reject Reason from Drop Down");
			click(SOP.REJECT_DATE, "Reject Date");
			click(SOP.DATE_CALENDAR, "Date Calendar");
			click(SOP.TODAYSDATE, "Today's Date");*/
			//click(SOP.NEXT_BTN, "Next Button");
			selectByIndex(WorksheetCreate.REJECT_REASON, 2, "Reject Reason from Drop Down");
			waitForElementPresent(SOP.REJECT_DATE,"Reject Date text box");
			assertElementPresent(SOP.REJECT_DATE,"Reject Date text box");
			int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
			String lastYearDate = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
					+ String.valueOf(lastYear); 			
			type(SOP.REJECT_DATE, lastYearDate, "Reject Date text box");
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			/*System.out.println("***********************"+"Reject Reason entered"+"************");
			waitForElementPresent(WorksheetCreate.REJECT_DATE, "Reject Date");
			assertElementPresent(WorksheetCreate.REJECT_DATE, "Reject Date");
			Thread.sleep(2000);
			waitForElementToBeClickable(WorksheetCreate.REJECT_DATE, "Reject Date");
			click(WorksheetCreate.REJECT_DATE, "Reject Date");
			Thread.sleep(2000);
			System.out.println("***********************"+"Reject Date entered"+"************");
			waitForElementToBeClickable(Generic.TODAYSDATE, "Today's Date");
			click(Generic.TODAYSDATE, "Today's Date");
			Thread.sleep(2000);
			System.out.println("***********************"+"Today's Date entered"+"************");*/
			
			waitForElementPresent(Generic.SAVE,"Save Button");
			assertElementPresent(Generic.SAVE,"Save Button");
			click(Generic.SAVE,"Save Button");

			//REJECT_REASON_DATE_DROPDWN
			//here one check for if reject reason date is not selected	
			//Enter a value for Reject reason & date.
			try {
				WebElement rejectDtNotSelected = null;	
				rejectDtNotSelected = driver.findElement(WorksheetCreate.REJECT_REASON_DATE_NOT_SELECTED);
				if(rejectDtNotSelected != null) {	
					selectByIndex(WorksheetCreate.REJECT_REASON, 2, "Reject Reason from Drop Down");
					selectByIndex(WorksheetCreate.REJECT_REASON, 2, "Reject Reason from Drop Down");
					waitForElementPresent(SOP.REJECT_DATE,"Reject Date text box");
					assertElementPresent(SOP.REJECT_DATE,"Reject Date text box");
					int lastYearDt = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1; 
					String lastYearDateDt = getCurrentDate().split("\\/")[0]+"/" + getCurrentDate().split("\\/")[1]+"/"
							+ String.valueOf(lastYearDt); 			
					type(SOP.REJECT_DATE, lastYearDateDt, "Reject Date text box");
					waitForElementPresent(Generic.SAVE,"Save Button");
					assertElementPresent(Generic.SAVE,"Save Button");	
					click(Generic.SAVE,"Save Button");
				}
			}
			catch (NoSuchElementException e) {}

			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			//assertElementPresent(WorksheetCreate.REJECTED_REASON, "Rejected Reason");
			assertElementPresent(WorksheetCreate.REJECTION_PENDING, "Rejection Pending");			
			//Navigate to Unposted Log and check log is now no more displayed
			click(PostLog.UNPOSTED_LOG, "Un-Posted Log");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log ID");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, wokId , "Entered Log ID");
			click(Generic.GO_BUTTON,"Go Button");
			assertElementPresent(Generic.NO_RECORDS_FOUND2, "No records found");


		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}


	/********************************************************************************************************
	 * Method Name : postLog() 
	 * Author : Pradyumna 
	 * Description : This method will verify on clicking Post log that logs are no more displayed in unposted log
	 * Date of creation : 8/31/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String postLog(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;			
			//createWorksheet(ReportSheet,count);
			viewAndCreateTheWorkSheetUsingESOPId(ReportSheet, count, esopId);
			String worksheetId=getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id on context bar");
			String wokId=worksheetId.substring(7);
			// Click On Choose DI Button
			click(ActionItems_SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// Click on Actions List Btn and then click on Mangage Actions List Button
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Actions List Button");
			click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage Actions List Button");
			//Select Carrier_SOP Papers with Transmittal From Deliverable Drp Dwn
			click(ActionItems_SOP.SOP_PAPERS_WITH_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");
			//Select Fed Ex Priority Overnight from Delivery Method Drpdown
			click(ActionItems_SOP.COURIER_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");
			// Click On select Button of Recipient
			click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
			// Enter a participant name
			type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
			click(ActionItems_SOP.FINDBTN, "Find Button");
			waitForElementPresent(Entity.TABLEID, "Recipient Table");
			clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
			// Click On Add/Update Btn
			click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
			click(ActionItems_SOP.ACTIONS_LIST_BTN, "Action List Btn");
			assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
			click(ActionItems_SOP.EXECUTE_BTN, "Action List Btn");

			//click on unposted link from left nav bar
			click(PostLog.UNPOSTED_LOG,"Unposted Log");
			assertElementPresent(PostLog.UNPOSTED_LOG_TITLE, "Un Posted Log Title");		
			//Select Worksheet from DropDown
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log Id");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Is equal to");
			type(Generic.DROP_DOWN_TEXT, wokId, "Entered Date");
			click(Generic.GO_BUTTON,"Go Button");		
			//Select the displayed Log and Edit the worksheet with Attempted as "Yes"
			click(PostLog.LOG_ID,"Select displayed Log ID");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			//Check if DI button is displayed on Worksheet Profile
			if(verifyIfElementPresent(PostLog.CHOOSE_DI,"Choose DI")) {
				click(PostLog.CHOOSE_DI,"Choose DI");
				if(verifyIfElementPresent(ActionItems_SOP.ACTIONS_LIST_BTN,"Choose DI")) {
					click(ActionItems_SOP.ACTIONS_LIST_BTN,"Action List Button");
					click(ActionItems_SOP.MANAGE_ACTIONS_ITEM_BTN,"Manage Action Item Button");
					//Select Copy of Transmittal From Deliverable Drp Dwn
					click(ActionItems_SOP.COPY_OF_TRANSMITTAL_DELIVERABLE_DRPDWN,"Deliverable DropDown");
					//Select hand delivered by ct from Delivery Method Drpdown
					click(ActionItems_SOP.HAND_DELIVERED_BY_CT_DELIVERY_METHOD_DRPDWN,"Delivery Method Dropdown");
					// Click On select Button of Recipient
					click(ActionItems_SOP.RECIPIENT_SELECT_BTN, "Recipient Select Button");
					// Enter a participant name
					type(ActionItems_SOP.PARTICIPANTNAMEFIELD, "Chuck Meyer", "Participant Name Field");
					click(ActionItems_SOP.FINDBTN, "Find Button");
					waitForElementPresent(Entity.TABLEID, "Recipient Table");
					clickOnFirstElement(Entity.SELECTRECIPIENTBTN, "Click on 1st Select button in the grid");
					// Click On Add/Update Btn
					click(ActionItems_SOP.ADDUPDATE_BTN, "Add/Update Btn");
					click(ActionItems_SOP.ACTIONS_LIST_BTN, "Action List Btn");
					assertElementPresent(ActionItems_SOP.EXECUTE_ACTION_ITEMS_PAGE, "Execute Action Item Page");
					click(ActionItems_SOP.EXECUTE_BTN, "Action List Btn");
					//Click on Post Log button
					click(ActionItems_SOP.POST_LOG_BTN, "Post Log Btn");
					click(PostLog.WORKSHEET_PROFILE, "Worksheet Profile");
					assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
					assertElementPresent(PostLog.POSTED_DATE, "Posted Date has year 2021 text");
				}
			}
			//Navigate to Unposted Log and check log is now no more displayed
			click(PostLog.UNPOSTED_LOG, "Un-Posted Log");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log ID");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, wokId , "Entered Log ID");
			click(Generic.GO_BUTTON,"Go Button");
			assertElementPresent(Generic.NO_RECORDS_FOUND2, "No records found");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	/********************************************************************************************************
	 * Method Name : incompleteWorksheetUnpostedLog() 
	 * Author : Pradyumna 
	 * Description : This method will verify on Unposted Logs do not have incomplete worksheet logs
	 * Date of creation : 8/31/2019
	 * modifying person : 
	 * Date of modification :
	 * @throws Throwable :
	 ********************************************************************************************************/
	public String incompleteWorksheetUnpostedLog(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			String entityName=Excelobject.getCellData(ReportSheet, "EntityName", count);

			createWorksheetViaSOPList(ReportSheet, count, esopId);
			//viewAndCreateTheWorkSheetUsingESOPId(reportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			Thread.sleep(2000);
			click(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");

			/*// click on Create Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			click(WorksheetCreate.CREATE_WORKSHEET_BUTTON, "Create Worksheet Button");
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name Text Field");			
			//Enter an entity name and click on search btn
			type(SOP.ENTITY_NAME_TEXTFIELD,"bank","Entity Name Text Field");
			click(SOP.SEARCH_BTN,"Search Button");
			//Select entity from the grid
			click(SOP.SELECT_FIRST_ENTITY_ON_GRID,"Select First Entity On Grid");		
			//Click On Create Quicklog/Attempted/Rejection/Multiple Button
			click(SOP.CREATE_QUICKLOG_ATTEMPTED_REJECTION_MULTIPLE_BTN,"Create Quicklog/Attempted/Rejection/Multiple Button");*/

			if(verifyIfElementPresent(SOP.METHOD_OF_SERVICE, "Method of Service")) {
				selectBySendkeys(SOP.METHOD_OF_SERVICE, "U.S. Marshall", "Method Of Service as U.S. Marshall");
				waitForElementPresent(SOP.TIME_TEXTFIELD,"Text Field for Time");
				Thread.sleep(2000);
				type(SOP.TIME_TEXTFIELD,"12:00","Text Field for Time");
			}
			/*click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			click(WorksheetCreate.NO_CASE_RADIO_BUTTON, "No Case Radio Button");
			click(WorksheetCreate.NO_PLAINTIFF_RADIO_BUTTON, "No Plaintiff Radio Button");*/
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYFACILITY, "New York Facility 1 (LIS)");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYTEAM, "CT - New York SOP Team");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BYNY, "TEST New York SOP Team");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "123-234", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			//Select Un-identified Radio Button
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			Thread.sleep(2000);
			type(WorksheetCreate.ENTITY_NAME, "Entity Name for Testing", "Enter Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Select Alabama");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			click(WorksheetCreate.UNIDENTIFIED_JURIS_GLYPHICON, "Unidentified Juris Glyphicon Click");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Alabama", "Select Alabama");

			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			//selectBySendkeys(WorksheetCreate.COURT, "U.S. Marshall", "Court");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			//selectBySendkeys(WorksheetCreate.AGENCY, "U.S. Marshall", "Agency");
			click(WorksheetCreate.RADIO_BUTTON_SENDER, "Existing Attorney Radio Button");
			selectBySendkeys(WorksheetCreate.ATTORNEY_OR_SENDER, "Adam Cooper", "Attorney");
			click(WorksheetCreate.INTERNAL_COMMENTS_FIRST_OPTION, "Internal Comments First Option");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
			//click(Generic.SAVE, "Save Button");
			click(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Bottom");
			assertElementPresent(WorksheetCreate.INCOMPLETE_STATUS, "Incomplete Status");
			String logID = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Log ID").split("\\: ")[1];
			/*click(WorksheetCreate.MY_WORKSHEET, "My Worksheet");
			//Search for Incomplete Worksheet
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Status", "Status Dropdown");
			selectBySendkeys(Generic.SELECT_2ND_DROPDOWN, "Incomplete", "Incomplete Dropdown");
			click(Generic.GO_BUTTON, "Go Button");
			String logID=getText(WorksheetCreate.FIRST_SOP_DATA, "Log ID");*/
			//Navigate to Unposted Log and check if incomplete worksheet log is displayed
			click(PostLog.UNPOSTED_LOG, "Un-Posted Log");
			selectBySendkeys(Generic.SELECT_DROPDOWN, "Log #", "Log ID");
			selectBySendkeys(Generic.SELECT_SECOND_DROPDOWN, "=", "Equals");
			type(Generic.DROP_DOWN_TEXT, logID , "Entered Log ID");
			click(Generic.GO_BUTTON,"Go Button");
			assertElementPresent(Generic.NO_RECORDS_FOUND2, "No records found");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
	
	public String verifyPriorityColumnOnUnpostedLogsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			click(SOP.UNPOSTED_LOGS_NAV_LINK, "Unposted Logs Link");
			assertTextMatching(SOP.PAGE_TITLE, "Un-Posted Logs", "Title Of The Page");
			isElementNotPresent(SOP.PRIORITY_COLUMN, "Priority Column On Uposted Logs Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPrioritySortOnUnpostedLogsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			click(SOP.UNPOSTED_LOGS_NAV_LINK, "Unposted Logs Link");
			assertTextMatching(SOP.PAGE_TITLE, "Un-Posted Logs", "Title Of The Page");
			isElementNotPresent(SOP.PRIORITY_SORT_LINK, "Priority Sort Link On Uposted Logs Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyPriorityFilterOnUnpostedLogsPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			click(HomePage.SOPLINK, "SOP Link");
			assertElementPresent(SOP.SOPLIST_PAGE, "SOP List Page");
			click(SOP.UNPOSTED_LOGS_NAV_LINK, "Unposted Logs Link");
			assertTextMatching(SOP.PAGE_TITLE, "Un-Posted Logs", "Title Of The Page");
			isElementNotPresent(SOP.PRIORITY_FILTER, "Priority Field Dropdown On Uposted Logs Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedFieldOnDocketHistoryPopUpPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			click(SOP.MODIFY_DOCKET_HISTORY, "Modify Docket History Button");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Basic Search", "Title of the page");
			click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
			click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
			type(SOP.CASEID_TEXTBOX, "1234", "Case Id");
			click(SOP.SEARCH_BTN, "Search Btn");
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

			String parentWindow = driver.getWindowHandle();
			click(SOP.FIRST_WORKSHEET, "First Worksheet");
			handlePopUpWindwow();
			isElementNotPresent(SOP.CLONED_COPIED_FIELD, "Cloned/Copied Field");
			assertTextMatching(SOP.PAGE_TITLE, "SOP Worksheet Profile", "Title of the page");
			driver.close();
			driver.switchTo().window(parentWindow);
			assertTextMatching(SOP.PAGE_TITLE, "Related Worksheet Search Results", "Title of the page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyClonedCopiedColumnOnDocketHistoryPage(String ReportSheet, int count) throws Throwable {

		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			click(SOP.DOCKET_HISTORY_NAV_LINK, "Docket History Nav Link");
			assertTextMatching(SOP.PAGE_TITLE, "Docket History", "Title of the page");
			isElementNotPresent(SOP.CLONED_COPIED_COLUMN, "Cloned/Copied Field");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}
