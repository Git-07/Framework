package com.arrow.workflows;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.IAnnotationTransformer;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import org.testng.annotations.ITestAnnotation;

import com.arrow.accelerators.ActionEngine;
import com.arrow.objectrepo.ActionItemsFailure;
import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.DI;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Invoice;
import com.arrow.objectrepo.Login;
import com.arrow.objectrepo.RenewalInvoice;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.SopHub;
import com.arrow.objectrepo.TeamSOPDashboard;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_NPD extends BusinessFunctions_SOP {

	public void CreateEntity(String ReportSheet, int count) throws Throwable {
		try {

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : catchBlock() Author : Vrushali Kakade Description : This method
	 * will catch the Exception Date of creation : modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void catchBlock(Exception e) throws Throwable {
		if (e.getMessage() != null)
			parent.appendChild(child);
		gStrErrMsg = e.getMessage();
		closeSummaryReport(browsertype);
		driver.quit();
		openBrowser();
		Thread.sleep(lSleep_VLow);

	}

	/********************************************************************************************************
	 * Method Name : verifyDSOPInCES() Author : Vrushali Kakade Description : This
	 * method will verify that SOP uploaded from SOP Hub are present in CES screen
	 * Date of creation : 4/22/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyDSOPInCES(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strConfirmationNumber = Excelobject.getCellData(ReportSheet, "Confirmation Number", count);
			String strBatchNumber = Excelobject.getCellData(ReportSheet, "Batch Number", count);
			String strIntakeMethodValue = Excelobject.getCellData(ReportSheet, "Intake Method", count);

			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// click on Clear button of filter
			click(SOP.CLEARBTN, "Clear Button of filter");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// select value 'Confirmation Number' in filter dropdown 1 and '='
			// in dropdown 2
			if (strBatchNumber.trim().equalsIgnoreCase("NA")) {
				selectByVisibleText(SOP.FILTERDROPDOWN1, "Confirmation Number", "Filter Dropdown 1");
				selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter Dropdown 2");

				// Enter confirmation number in filter text box and hit Go
				// button
				type(SOP.FILTERTEXTFIELD, strConfirmationNumber, "Filter text field");
				click(SOP.FILTERGOBTN, "Go button of filter");
				Thread.sleep(lSleep_Medium);
				waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");
			} else if (strConfirmationNumber.trim().equalsIgnoreCase("NA")) {
				selectByVisibleText(SOP.FILTERDROPDOWN1, "Batch #", "Filter Dropdown 1");
				selectByVisibleText(SOP.FILTERDROPDOWN2, "equals", "Filter Dropdown 2");

				// Enter batch number in filter text box and hit Go button
				type(SOP.FILTERTEXTFIELD, strBatchNumber, "Filter text field");
				click(SOP.FILTERGOBTN, "Go button of filter");
				Thread.sleep(lSleep_Medium);
				waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");
			}

			// CES Select button is present for DSOP
			assertElementPresent(SOP.CESSELECTBTN, "CES Select button");

			// click on CES Select button
			click(SOP.CESSELECTBTN, "CES Select button");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.SUBMITBTN, "Submit Button");

			// verify Intake Method: CDSOP is displayed on CES page
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			assertTextMatching(SOP.INTAKEMETHODLABEL, "Intake Method :", "Intake Method :");
			assertTextMatching(SOP.INTAKEMETHODVALUE, strIntakeMethodValue, strIntakeMethodValue);

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyCESMLSlider() Author : Vrushali Kakade Description : This
	 * method will verify if ML Slider is displayed in CES screen Date of creation :
	 * 4/22/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyCESMLSliderWithData(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strConfirmationNumber = Excelobject.getCellData(ReportSheet, "Confirmation Number", count);
			String strCaseNumber = Excelobject.getCellData(ReportSheet, "Case Number", count);

			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// click on Clear button of filter
			click(SOP.CLEARBTN, "Clear Button of filter");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// select value 'Confirmation Number' in filter dropdown 1 and '='
			// in dropdown 2
			selectByVisibleText(SOP.FILTERDROPDOWN1, "Confirmation Number", "Filter Dropdown 1");
			selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter Dropdown 2");

			// Enter batch number in filter text box and hit Go button
			type(SOP.FILTERTEXTFIELD, strConfirmationNumber, "Filter text field");
			click(SOP.FILTERGOBTN, "Go button of filter");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// click on CES Select button
			click(SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(SOP.SUBMITBTN, "Submit Button");

			// Verify ML Slider on CES page is closed by default
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "ML Slider is closed by default on CES page");

			// click on arrow icon and verify the slider is opened
			click(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

			// verify ML Slider is opened
			assertElementPresent(SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			// verify Slider title is "ML Extracted Data"
			assertTextMatching(SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider");

			// verify eye icon is displayed next to "ML Extracted Data" title
			assertElementPresent(SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");

			// click on eye icon and verify slider is transparent
			click(SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");
			assertElementPresent(SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");
			String style = getAttribute(SOP.SLIDER_ID, "style");
			assertTextContains(style, "background-color: transparent");

			// click on eye icon again
			click(SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");

			// Verify 'CES ML Slider Fields' section is present and it opened by
			// default
			assertTextMatching(SOP.CES_SECTION_TITLE, "CES ML Slider Fields", "Title of CES Section on ML Slider");
			assertElementPresent(SOP.CES_SECTION_UP_ARROW, "'CES ML Slider Fields' is opened by default on ML Slider");

			// Verify Copy icon is displayed and click on it
			assertElementPresent(SOP.COPY_ICON, "Copy Icon on CES ML Slider");
			String text = getText(SOP.FIRST_ELEMENT_ON_ML_SLIDER, "Text in Case# field");
			click(SOP.COPY_ICON, "Copy Icon on CES ML Slider");

			// Verify CASE number is correct
			assertTextContains(strCaseNumber, text);

			// Click on UP arrow of 'CES ML Slider Fields' section and verify
			// section is
			// closed
			click(SOP.CES_SECTION_UP_ARROW, "Up arrow of 'CES ML Slider Fields' section");
			assertElementPresent(SOP.CES_SECTION_DOWN_ARROW, "'CES ML Slider Fields' section is closed on ML Slider");

			// close the slider
			click(SOP.SLIDER_OPENED_BTN, "Slider Opened button");
			assertElementPresent(SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : adminCESMLSliderPage() Author : Vrushali Kakade Description :
	 * This method will verify if ML Slider is displayed in CES screen Date of
	 * creation : 6/19/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void adminCESMLSliderPage(String ReportSheet, int count) throws Throwable {
		try {

			// Click on Admin Module
			click(HomePage.ADMINLINK, "Admin Link");

			// Verify Whether New section 'Manage CES ML Slider Fields' on the
			// left nav
			// And click on 'Manage CES ML Slider Fields' link
			assertElementPresent(Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			click(Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");

			// Verify Title of the page is Manage CES ML Slider Fields
			assertTextMatching(Admin.MANAGECESMLSLIDERFIELDSPAGE, "Manage CES ML Slider Fields", "Title of the page");

			// Verify the page has 2 blocks - CES ML Slider Fields and Maintain
			// CES ML
			// Slider Fields
			// and save & cancel buttons at the bottom
			isElementPresent(Admin.CESMLSLIDERFIELDSBLOCK, "CES ML Slider Fields Block");
			isElementPresent(Admin.MAINTAINCESMLSLIDERFIELDSBLOCK, "Maintain CES ML Slider Fields Block");
			isElementPresent(Admin.SAVEBTN, "Save Button");
			isElementPresent(Admin.CANCELBTN, "Cancel Button");

			// CES ML Slider Fields block has 3 fields- Case#,lawsuit type and
			// lawsuitsubtype
			assertElementPresent(Admin.CASEIDFIELD, "Case #");
			assertElementPresent(Admin.LAWSUITTYPEFIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(Admin.LAWSUITSUBTYPEFIELD, "LAWSUIT SUB TYPE FIELD");

			// Maintain CES ML Slider Fields block has 2 fields- Index and Name
			assertTextMatching(Admin.INDEXFIELD, "Index", "Verify 1st col is Index");
			assertTextMatching(Admin.NAMEFIELD, "Name", "Verify 2nd col is Name");

			// Verify Fields can be moved within CES ML Slider Fields block
			draggable(Admin.LAWSUITTYPEFIELD, 0, 150, "LAWSUIT TYPE FIELD DRAG AND DROP");
			click(Admin.SAVEBTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyAllIntakeMethodThroughCES() Author : Vrushali Kakade
	 * Description : This method will verify that SOP uploaded from different Intake
	 * Methods routes through CES screen Date of creation : 6/28/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyAllIntakeMethodThroughCES(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String strIntakeMethodValue = Excelobject.getCellData(ReportSheet, "Intake Method", count);

			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			searchSOPUsingFileName(strFileName, "equals");

			// CES Select button is present for DSOP
			assertElementPresent(SOP.CESSELECTBTN, "CES Select button");

			// click on CES Select button
			click(SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(SOP.SUBMITBTN, "Submit Button");

			// verify Intake Method: CDSOP is displayed on CES page
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			assertTextMatching(SOP.INTAKEMETHODLABEL, "Intake Method :", "Intake Method :");
			assertTextMatching(SOP.INTAKEMETHODVALUE, strIntakeMethodValue, strIntakeMethodValue);

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyCustomerComments() Author : Vrushali Kakade Description :
	 * This method will verify Customer Comments are displayed for CDSOP Intake
	 * Methods on CES and Worksheet pages Date of creation : 6/28/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyCustomerComments(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String strCustomerComments = Excelobject.getCellData(ReportSheet, "Customer Comment", count);

			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			searchSOPUsingFileName(strFileName, "equals");

			// click on CES Select button
			click(SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(SOP.SUBMITBTN, "Submit Button");

			// verify Intake Method: CDSOP is displayed on CES page
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			assertTextMatching(SOP.CUSTOMER_COMMENTS_LABEL, "Customer Comments (CDSOP Only) :",
					"Customer Comments (CDSOP Only) :");
			assertTextMatching(SOP.CUSTOMER_COMMENTS_VALUE, strCustomerComments, strCustomerComments);

			///////// This part is commented because unable to click on Home
			///////// icon in selenium.
			///////// In Test data, use SOP for which Entity is already selected
			/*
			 * //click on Select button of ARROW Entity box
			 * click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			 * waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");
			 * 
			 * //enter entity name in Entity Search page and click on Search button
			 * type(SOP.ENTITY_NAME_TEXTFIELD, "apple",
			 * "Entity Name textfield on Entity Search page"); click(SOP.SEARCH_BTN,
			 * "Search button"); waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN,
			 * "Unidentified Entity button");
			 * 
			 * //click on 1st entity of the search result, click on Home icon
			 * click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");
			 * waitForElementPresent(SOP.HOME_ICON, "Home icon"); scrollUp();
			 * focus(SOP.HOME_PDF_ICONS, "Home PDF icons"); click(SOP.HOME_PDF_ICONS,
			 * "Home PDF icons");
			 * 
			 * click(SOP.HOME_ICON, "Home icon");
			 */
			// select Lawsuite Type and click on Submit button
			selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(SOP.SUBMITBTN, "Submit Button");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// On SOP List page, search for this SOP
			searchSOPUsingFileName(strFileName, "equals");

			// Assign this ESOP to logged in user
			click(SOP.FIRST_SOP_CHECKBOX, "Checkbox of first SOP in SOP List");
			click(SOP.ASSIGN_BTN, "Assign button");
			waitForElementPresent(SOP.ASSIGN_BTN, "Assign button");
			click(SOP.ASSIGN_BTN, "Assign button");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			searchSOPUsingFileName(strFileName, "equals");
			click(SOP.VIEW_BTN, "View Button");
			switchAndCloseWindow();
			click(SOP.CREATE_WORKSHEET_BTN, "Create Worksheet button");
			waitForElementPresent(SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");
			Thread.sleep(lSleep_Medium);

			// On Create Worksheet Step 1
			selectByIndex(SOP.RECEIVED_BY_MEMBER_DPDOWN, 1, "Received By Memebr Dropdown");
			click(SOP.INITIAL_RADIOBTN, "Initiatl Radio Button");
			click(SOP.CASE_NUMBER_NONE_RADIOBTN, "Initial Radio Button");
			click(SOP.PLAINTIFF_NONE_RADIOBTN, "Plaintiff Radio Button");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", " Defendant/Creditor Name");
			assertTextMatching(SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);
			click(SOP.NEXT_BTN, "Next Button");
			waitForElementPresent(SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");

			// On Create Worksheet Step 2
			click(SOP.COURT_NONE_RADIOBTN, "Court Radio Button");
			assertTextMatching(SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);
			click(SOP.NEXT_BTN, "Next Button");
			waitForElementPresent(SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");

			// On Create Worksheet Step 3
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			if (strFileName == "NPDSeleniumCDSOP.pdf") {
				selectByVisibleText(SOP.SPECIAL_DROPDWN, "None", "Special Circumstances Dropdown");
			}

			click(SOP.ANSWER_NONE_RADIOBTN, "Answer Radio Button");
			assertTextMatching(SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);
			click(SOP.SAVE_BTN, "Save Button");
			Thread.sleep(2000);

			// On Worksheet profile page
			waitForElementPresent(SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");
			assertTextMatching(SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);

			Thread.sleep(2000);

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyGenericEntities() Author : Vrushali Kakade Description :
	 * This method will verify Generic entities are displayed for Intake Method
	 * CDSOP Only Date of creation : 7/13/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyGenericEntities(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String strIntakeMethod = Excelobject.getCellData(ReportSheet, "Intake Method", count);
			String searchMessage = "Entity search is limited to Customer level for DSOP";
			String noRecordMessage = "No records found.";

			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			searchSOPUsingFileName(strFileName, "equals");

			// click on CES Select button
			click(SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(SOP.SUBMITBTN, "Submit Button");

			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

			// Verify message is displayed for Intake Method CDSOP
			if (strIntakeMethod.trim().equalsIgnoreCase("CDSOP")) {
				assertTextMatching(SOP.ENTITY_SEARCH_MESSAGE, searchMessage, searchMessage);
			} else {
				elementIsNotPresent(SOP.ENTITY_SEARCH_MESSAGE, searchMessage);
			}

			// enter entity name in Entity Search page and click on Search
			// button
			type(SOP.ENTITY_NAME_TEXTFIELD, "Selenium Test Generic Entity",
					"Entity Name textfield on Entity Search page");
			click(SOP.SEARCH_BTN, "Search button");
			waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity button");

			// click on 1st entity of the search result, click on Home icon
			if (strIntakeMethod.trim().equalsIgnoreCase("CDSOP")) {
				assertTextMatching(SOP.ENTITY_DOM_JURISDICTION, "--", "Dom Juris is --");
				assertTextMatching(SOP.ENTITY_REP_JURISDICTION, "--", "Rep Juris is --");
				assertTextMatching(SOP.ENTITY_REP_STATUS, "--", "Rep Status is --");
				assertTextMatching(SOP.ENTITY_REP_SERVICE_TYPE, "--", "Rep Service Type is --");
				String value = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
				assertTextContains(value, "true");
			} else {
				assertTextMatching(SOP.ENTITY_RESULT_MESSAGE, noRecordMessage, noRecordMessage);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyCESEnabledRemoved() Author : Vrushali Kakade Description
	 * : This method will verify CES Enabled is removed from SOP List page and
	 * Manage Default Assignment page Date of creation : 7/14/2019 modifying person
	 * : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyCESEnabledRemoved(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on SOP List link on Home page
			click(HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// CES Enabled label is not present in grid on SOP List page
			elementIsNotPresent(SOP.CES_ENABLED_LABEL, "CES Enabled label in SOP List grid");

			// Select SOP>15 days page and verify CES Enabled label is not
			// present in grid
			click(SOP.SOP_15DAYS_TAB, "SOP>15 Days tab");
			waitForElementPresent(SOP.UPLOADIMAGEBTN, "Upload Image Button");
			elementIsNotPresent(SOP.CES_ENABLED_LABEL, "CES Enabled label in SOP>15 Days grid");

			// Navigate to Manage Default Assignment page
			click(SOP.MANAGE_DEFAULT_ASSIGNMENT_LINK, "Manage Default Assignment link");
			waitForElementPresent(SOP.ADD_NEW_BTN, "Add New Button");
			elementIsNotPresent(SOP.CES_ENABLED_LABEL, "CES Enabled label in grid on Manage Default Assignment page");
			elementIsNotPresent(SOP.CES_ENABLED_SORTBY_LINK,
					"CES Enabled sort by link on Manage Default Assignment page");
			elementIsNotPresent(SOP.CES_ENABLED_CHECKBOX, "CES Enabled checkbox on Manage Default Assignment page");

			// click on Add New button and verify CES Enabled is not displayed
			click(SOP.ADD_NEW_BTN, "Add New Button");
			Thread.sleep(lSleep_Medium);
			elementIsNotPresent(SOP.CES_ENABLED_CHECKBOX, "CES Enabled checkbox");

			// click on Edit button of existing configuration and verify CES
			// Enabled is not
			// displayed
			click(SOP.EDIT_BTN, "Edit Button of configuration");
			Thread.sleep(lSleep_Medium);
			elementIsNotPresent(SOP.CES_ENABLED_CHECKBOX, "CES Enabled checkbox");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expeditedSOPPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {

			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Update Entity on posted
			// Expedited SOP
			// Log is Present
			isElementPresent(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			assertTextMatching(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_LABEL,
					"Update Entity on posted Expedited SOP Log",
					"Label For Update Entity on posted Expedited SOP Log Field");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(Admin.EDIT_BTN, "Edit Button");

			// Click on Update Entity on posted Expedited SOP Log Checkbox and
			// click on save
			// button
			click(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			click(Admin.SAVEBTN, "Save Button");

			// Verify whether Update Entity on posted Expedited SOP Log is added
			// in
			// Expedited SOP Permission Field
			assertTextMatching(Admin.EXPEDITED_SOP_PERMISSION_FIELD, "Update Entity on posted Expedited SOP Log",
					"Update Entity on posted Expedited SOP Log on Expedited SOP Permission Field");

			// Click on Edit Button again and uncheck Update Entity on posted
			// Expedited SOP
			// Log
			click(Admin.EDIT_BTN, "Edit Button");
			click(Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");

			// Click on save btn
			click(Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Expedited SOP Permission
			// Field
			assertTextMatching(Admin.EXPEDITED_SOP_PERMISSION_FIELD, "No permissions",
					"No permissions Msg on Expedited SOP Permission Field");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void editEntityForVariousSOP(String ReportSheet, int count) throws Throwable {
		try {
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			editEntityOnWorksheetEditPage(ReportSheet, count);

		} catch (Exception e) {
			throw e;
		}
	}

	public void errorForExpeditedSOPLog(String ReportSheet, int count) throws Throwable {
		try {
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);

			click(HomePage.SOPLINK, "SOP Link");
			searchWorksheet(worksheetId);
			errorMessageOnEntityEdit();

		} catch (Exception e) {
			throw e;
		}
	}

	public void updatePlusDisbursementOnEntity(String BundleName, String plusDisbursement) throws Throwable {
		try {
			if (BundleName.equalsIgnoreCase("Reparms Bundle")) {
				// select Reparms bundle from bundle dropdown
				click(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Entity.EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// uncheck Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");
				}

			} else if (BundleName.equalsIgnoreCase("Rep and Annual Report")) {
				// select Rep and Annual Report from bundle dropdown
				click(Entity.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Entity.EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// uncheck Plus Disbursement checkbox
					click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Enter Comments
					type(Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(Entity.SAVE_BTN, "Save Button");

				}

			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void editEntityBundle(String ReportSheet, int count) throws Throwable {
		try {
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnEntity("Reparms Bundle", "Yes");

			// Verify Bundle Name on entity profile page
			assertTextMatching(Entity.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnEntity("Reparms Bundle", "No");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "No", "Verify  the value of Plus Disbursements label is No");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Rep and Annual Report Bundle
			updatePlusDisbursementOnEntity("Rep and Annual Report", "Yes");

			// Verify Bundle Name on entity profile page
			assertTextMatching(Entity.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// click on Edit Button on Entity Profile Page
			click(Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Rep and Annual Report Bundle
			updatePlusDisbursementOnEntity("Rep and Annual Report", "No");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Entity.PLUS_DISBURSEMENTS, "No", "Verify  the value of Plus Disbursements label is No");

		} catch (Exception e) {
			throw e;
		}
	}

	public void navigateToInactiveBundleSubGroupsPage() throws Throwable {
		try {
			// Navigate to Sub Group Bundle Maintainance Page
			click(Affiliation.SUB_GROUP_BUNDLE_MAINTAINANCE, "Sub Group Bundle Maintainance Left Nav link");

			// Click On Inactive Bundle Subgroups Tab
			click(Affiliation.INACTIVE_BUNDLE_SUBGROUPS_TAB, "Inactive Bundle Subgroups Tab");

		} catch (Exception e) {
			throw e;
		}
	}

	public void navigateToRenewalTypeSubGroup() throws Throwable {
		try {
			// Navigate to Affiliation Sub Groups Page
			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");

			// Select Sub group type from first filter and Renewal from second
			// filter and
			// click on go button
			click(Affiliation.SUB_GROUP_TYPE, "Select Sub group type from first filter");
			click(Affiliation.RENEWAL, "Select Renewal from second filter");
			click(Affiliation.GOBTN, "Go Button");

			// Select First Subgroup from grid
			click(Affiliation.FIRSTRESULTONSEARCHPAGE, "Select first Subgroup on grid");

		} catch (Exception e) {
			throw e;
		}
	}

	public void updatePlusDisbursementOnSubGroup(String BundleName, String plusDisbursement) throws Throwable {
		try {
			if (BundleName.equalsIgnoreCase("Reparms Bundle")) {
				// select Reparms bundle from bundle dropdown
				click(Affiliation.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Affiliation.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				}

			} else if (BundleName.equalsIgnoreCase("Rep and Annual Report")) {
				// select Rep and Annual Report from bundle dropdown
				click(Affiliation.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN,
						"Select Rep and Annual Report from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(Affiliation.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(Affiliation.ENABLE_BTN, "Enable Button");

				}

			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void editSubGroupBundle(String ReportSheet, int count) throws Throwable {
		try {
			String strId = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Navigate to Affiliation Sub Groups Page
			click(Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Reparms Bundle", "Yes");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on Sub Group profile View page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Reparms Bundle", "No");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on Sub Group profile View page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "No",
					"Verify  the value of Plus Disbursements label is No");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Rep and Annual Report", "Yes");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on entity profile page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Rep and Annual Report", "No");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on entity profile page
			assertTextMatching(Affiliation.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(Affiliation.PLUS_DISBURSEMENTS, "No",
					"Verify  the value of Plus Disbursements label is yes");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addBundleDisbursement(String ReportSheet, int count) throws Throwable {
		try {

			String dsItemNumber = Excelobject.getCellData(ReportSheet, "E1 DS Item Number", count);
			String dsDescription = Excelobject.getCellData(ReportSheet, "DS Description", count);
			String invalidDSItemNumber = Excelobject.getCellData(ReportSheet, "Invalid DS Item Number", count);
			String validDSItemNumber = Excelobject.getCellData(ReportSheet, "Valid DS Item Number", count);
			String editDSDescription = Excelobject.getCellData(ReportSheet, "Edit DS Description", count);
			List<String> originalrepAndAnnualReportServiceList = new ArrayList<String>();
			List<String> originalRepArmsBundleServiceList = new ArrayList<String>();
			List<String> repAndAnnualReportServiceList = Arrays.asList("-- Select One --",
					"Domestic Registered Agent Plus (RSLP)", "Domestic Registered Agent Plus (SBLP)",
					"Domestic Registered Agent Plus (SLP)", "Domestic Registered Agent Plus (ST)",
					"Domestic Registered Agent Plus Service (Business Corp)",
					"Domestic Registered Agent Plus Service (Gen. Ptnshp)",
					"Domestic Registered Agent Plus Service (LLC)", "Domestic Registered Agent Plus Service (LLP)",
					"Domestic Registered Agent Plus Service (LP)",
					"Domestic Registered Agent Plus Service (Non-Profit)",
					"Foreign Registered Agent Plus Service (Business Corp)",
					"Foreign Registered Agent Plus Service (Gen. Ptnshp)",
					"Foreign Registered Agent Plus Service (LLC)", "Foreign Registered Agent Plus Service (LLP)",
					"Foreign Registered Agent Plus Service (LP)", "Foreign Registered Agent Plus Service (Non-Profit)");
			List<String> repArmsBundleServiceList = Arrays.asList("-- Select One --",
					"Domestic Rep/ARMS (Business Corp)", "Domestic Rep/ARMS (Gen. Ptnshp)", "Domestic Rep/ARMS (LLC)",
					"Domestic Rep/ARMS (LLP)", "Domestic Rep/ARMS (LP)", "Domestic Rep/ARMS (Non-Profit)",
					"Domestic Rep/ARMS (RSLP)", "Domestic Rep/ARMS (SBLP)", "Domestic Rep/ARMS (SLP)",
					"Domestic Rep/ARMS (ST)", "Foreign Rep/ARMS (Business Corporation)",
					"Foreign Rep/ARMS (Gen. Ptnshp)", "Foreign Rep/ARMS (LLC)", "Foreign Rep/ARMS (LLP)",
					"Foreign Rep/ARMS (LP)", "Foreign Rep/ARMS (Non-Profit)");

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Click on Bundle Disbursements Maintainance left nav Link
			click(Admin.BUNDLE_DISBURSEMENTS_MAINTAINANCE_LEFT__NAV_LINK,
					"Bundle Disbursements Maintainance left nav Link");

			// Verify the page title is Bundles Disbursements Maintenance
			assertTextMatching(Admin.PAGE_TITLE, "Bundles Disbursements Maintenance", "Verify the page title");
			// Click on Add Button
			click(Admin.ADD_BTN, "Click On add button");

			// Verify Error Msgs
			assertTextMatching(Admin.BUNDLE_ERR_MSG, "Select a Bundle.", "Error Message when bundle is not selected");
			assertTextMatching(Admin.SERVICE_ERR_MSG, "Select a Service.",
					"Error Message when Service is not selected");
			assertTextMatching(Admin.JURISDICTION_ERR_MSG, "Select a Jurisdiction.",
					"Error Message when Jurisdiction is not selected");

			// Select Rep and Annual Report from dropdown
			click(Admin.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from bundle dropdown");

			List<WebElement> arr = getAllDropDownData(Admin.SERVICE_DROPDOWN);

			Iterator<WebElement> iter = arr.iterator();

			while (iter.hasNext()) {
				WebElement we = iter.next();

				originalrepAndAnnualReportServiceList.add(we.getText());
			}

			compareTwoArrayList(repAndAnnualReportServiceList, originalrepAndAnnualReportServiceList);

			// Select RepArms Bundle from bundle dropdown
			click(Admin.REPARMS_BUNDLE_DRPDWN, "Select REPARMS Bundle from bundle dropdown");

			List<WebElement> array = getAllDropDownData(Admin.SERVICE_DROPDOWN);

			Iterator<WebElement> itr = array.iterator();

			while (itr.hasNext()) {
				WebElement we = itr.next();

				originalRepArmsBundleServiceList.add(we.getText());
			}

			compareTwoArrayList(repArmsBundleServiceList, originalRepArmsBundleServiceList);

			// Select first value from sevice dropdown
			selectByIndex(Admin.SERVICE_DROPDOWN, 1, "Select first Value from Service DropDown");

			// Check Whether All radio buttons for jurisdiction are present
			isElementPresent(Admin.US_RADIO_BTN, "US Radio Button");
			isElementPresent(Admin.CANADA_RADIO_BTN, "Canada Radio Button");
			isElementPresent(Admin.INTERNATIONAL_RADIO_BTN, "International Radio Button");

			// Select first value from jurisdiction dropdown
			selectByIndex(Admin.JURIS_DRP_DWN, 1, "Select first Value from Jurisdiction DropDown");

			// Click on Add Button
			click(Admin.ADD_BTN, "Click On add button");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			// Verify Error Msgs
			assertTextMatching(Admin.DS_ITEM_NUMBER_ERR_MSG, "Enter a value for E1 DS Item Number.",
					"Error Message when E1 DS Item Number is not entered");
			assertTextMatching(Admin.DS_DESCRIPTION_ERR_MSG, "Enter a value for DS Service Description.",
					"Error Message when Service Description. is not entered");

			// Enter a DS Item Number and DS Service Description
			type(Admin.DS_ITEM_NUMBER_TEXTBOX, dsItemNumber, "DS Item Number TextBox");
			type(Admin.DS_DESCRIPTION_TEXTBOX, dsDescription, "DS Description TextBox");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			String substringDSItemNumber = dsItemNumber.substring(0, 9);
			String substringDSDescription = dsDescription.substring(0, 59);

			// Verify E1 DS Item Number and DS Description on grid
			assertTextMatching(Admin.E1_DS_ITEM_NUMBER_ON_GRID, substringDSItemNumber, "DS Item Number On Grid");
			assertTextMatching(Admin.DS_DESCRIPTION_ON_GRID, substringDSDescription, "DS Description On Grid");

			// Click On edit Button
			click(Admin.FIRST_EDIT_BUTTON_ON_GRID, "Edit Button");

			// Enter an invalid DS Item Number
			type(Admin.DS_ITEM_NUMBER_TEXTBOX, invalidDSItemNumber, "DS Item Number TextBox");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			// Verify Error Msg for entering invalid DS Item Number
			assertTextMatching(Admin.DS_INVALID_ITEM_NUMBER_ERR_MSG, "Enter a positive number for E1 DS Item Number.",
					"Error Message when invalid E1 DS Item Number is entered");

			// Enter an invalid DS Item Number
			type(Admin.DS_ITEM_NUMBER_TEXTBOX, validDSItemNumber, "DS Item Number TextBox");
			type(Admin.DS_DESCRIPTION_TEXTBOX, editDSDescription, "DS Description TextBox");

			// Click On Save Button
			click(Admin.SAVE_BUTTON, "Save Button");

			// Verify E1 DS Item Number and DS Description on grid
			assertTextMatching(Admin.E1_DS_ITEM_NUMBER_ON_GRID, validDSItemNumber, "DS Item Number On Grid");
			assertTextMatching(Admin.DS_DESCRIPTION_ON_GRID, editDSDescription, "DS Description On Grid");

			// Click On Delete Button
			click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");

			// Handle Popup
			handlepopup();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSForAllRenewalInvoicesTab() throws Throwable {
		try {
			// Verify the tab is current renewal invoices
			// commenting because no invoice with DS item in current renewal tab
			/*
			 * assertElementPresent(RenewalInvoice. CURRENT_RENEWAL_INVOICES_ACTIVE_TAB,
			 * "Verify Current Renewal Invoices Tab is Active");
			 * verifyCreditDSOnRenewalInvoicesPage();
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab"); verifyCreditDSOnRenewalInvoicesPage();
			 */
			// Click on All Renewal Invoices Tab
			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			verifyCreditDSOnRenewalInvoicesPage();

			// Click on All Invoice History Tab
			// click(RenewalInvoice.INVOICE_HISTORY_TAB, "Invoice History tab");
			// verifyCreditDSOnRenewalInvoicesPage();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSForAllRevisionsTab() throws Throwable {
		try {
			click(RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");

			// commenting because no invoice with DS item in current renewal tab
			/*
			 * // Verify the tab is current renewal invoices
			 * assertElementPresent(RenewalInvoice. CURRENT_REVISABLE_INVOICES_ACTIVE_TAB,
			 * "Verify Current Revisable Invoices Tab is Active");
			 * verifyCreditDSOnRenewalInvoicesPage();
			 */

			// Click on all revisable invoices tab
			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");
			verifyCreditDSOnRenewalInvoicesPage();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSOnRenewalInvoicesPage() throws Throwable {
		try {
			// Filter By Credit DS
			click(RenewalInvoice.CREDIT_DS_FIRST_FILTER, "Select Credit DS from first filter");
			click(RenewalInvoice.YES_SECOND_FILTER, "Select Yes from second filter");
			click(RenewalInvoice.GO_BTN, "Go Button");

			// Verify Credit DS Button
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			assertElementPresent(RenewalInvoice.ACTIVE_CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link is Active");

			// Verify Credit DS Button
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSOnRenewalInvoicesAndRevisionsPage(String ReportSheet, int count, String module)
			throws Throwable {
		try {

			if (module.equalsIgnoreCase("Invoice")) {

				String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

				click(HomePage.INVOICE_TAB, "Invoice Tab");
				// Search for an invoice ID
				type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
				click(RenewalInvoice.SEARCH_BTN, "Search Button");

				verifyCreditDSOnRenewalInvoicesPage();

			}

			else if (module.equalsIgnoreCase("Affiliation")) {

				String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);

				click(HomePage.AFFILIATION_TAB, "Affiliation Tab");
				// Enter an id to be searched and click on search button
				type(Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
				click(Affiliation.SEARCHBTN, "Search Button");

				// Click on Renewal Invoices from left nav bar
				click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");

				verifyCreditDSForAllRenewalInvoicesTab();
				verifyCreditDSForAllRevisionsTab();

			}

			else if (module.equalsIgnoreCase("Entity")) {

				String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);

				click(HomePage.ENTITY_TAB, "Entity Tab");

				// Enter Entity ID and click on search button
				type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
				click(Entity.SEARCH_BTN, "Search Button");

				// Click On Renewal Invoices from left nav links
				click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");

				verifyCreditDSForAllRenewalInvoicesTab();
				verifyCreditDSForAllRevisionsTab();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSButtonForInvoices(String ReportSheet, int count) throws Throwable {
		try {

			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Invoice");
			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Affiliation");
			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Entity");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String messageOfDisbursements1 = "You should verify with the ARMS Team that the Annual Report for the entity(s) have been filed before crediting the DS line.";
			String messageOfDisbursements2 = "If the Annual Report has been filed you should NOT issue a credit for the disbursement.";

			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			// Get invoice id
			String invoiceNumber = getText(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "Invoice name");

			// Click on Credit DS Button
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Verify context title,invoice id on context bar,page title
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Credit Disbursements", "Context Title");
			assertTextMatching(RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR, invoiceNumber, "Invoice Number");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Representation Units with Disbursements", "Page Title");

			String dsMessage = getText(RenewalInvoice.DISBURSEMENTS_MESSAGE, "Disbursements Message");
			System.out.println("dsMessage: " + dsMessage);
			assertTextContains(dsMessage, messageOfDisbursements1);
			assertTextContains(dsMessage, messageOfDisbursements2);

			// Verify invoice#, invoice date and reneal date are displayed
			assertElementPresent(RenewalInvoice.INVOICE_NUMBER, "Invoice id");
			assertElementPresent(RenewalInvoice.INVOICE_DATE, "Invoice Date");
			assertElementPresent(RenewalInvoice.RENEWAL_DATE, "Renewal Date");

			// verfiy Cancel, Revise and Revision Preview buttons are displayed
			// at top and bottom
			assertElementPresent(RenewalInvoice.REVISION_BTN_TOP, "Invoice Date");
			assertElementPresent(RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Invoice id");
			assertElementPresent(RenewalInvoice.REVISION_BTN_BOTTOM, "Invoice Date");
			assertElementPresent(RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Renewal Date");

			// Verify columns in the grid
			String entityName = getText(RenewalInvoice.ENTITY_NAME_COLUMN, "Entity Name column header");
			assertTextContains(entityName, "Entity Name");

			String dsServiceDescr = getText(RenewalInvoice.DS_SERVICE_DESCR_COLUMN,
					"DS Service Description column header");
			assertTextContains(dsServiceDescr, "Disbursements Service Description");

			String jurisdiction = getText(RenewalInvoice.JURISDICTION_COLUMN, "Jurisdiction column header");
			assertTextContains(jurisdiction, "Jurisdiction");

			String dsAmount = getText(RenewalInvoice.DS_AMOUNT_COLUMN, "DS Amount column header");
			assertTextContains(dsAmount, "DS Amount");

			String creditDS = getText(RenewalInvoice.CREDIT_DS_COLUMN, "Credit DS column header");
			assertTextContains(creditDS, "Credit DS");

			// verfiy Select All and Select None button
			assertElementPresent(RenewalInvoice.SELECT_ALL_BTN, "Select All button");
			assertElementPresent(RenewalInvoice.SELECT_NONE_BTN, "Select None button");

			// Sort By links
			assertElementPresent(RenewalInvoice.ENTITY_NAME_SORTING_LINK, "Entity Name sorting link");
			assertElementPresent(RenewalInvoice.DS_SERVICE_DESCR_SORTING_LINK,
					"Disbursements Service Description sorting link");
			assertElementPresent(RenewalInvoice.DS_AMOUNT_SORTING_LINK, "DS Amount sorting link");
			assertElementPresent(RenewalInvoice.JURISDICTION_SORTING_LINK, "Jurisdisction sorting link");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(HomePage.ADMINLINK, "Admin Link");

			// click on Create Role Button
			click(Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Delaware AR Admin is
			// Present
			isElementPresent(Admin.CREDIT_DS_LINES_CHECKBOX, "Credit DS Lines on Renewal Invoices Checkbox");
			assertTextMatching(Admin.CREDIT_DS_LINES_LABEL, "Credit DS Lines",
					"Label For Credit DS Lines on Renewal Invoices");

			// click on Save Button
			click(Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(Admin.EDIT_BTN, "Edit Button");

			// Click on Credit DS Lines on Renewal Invoices Checkbox and click
			// on save
			// button
			click(Admin.CREDIT_DS_LINES_CHECKBOX, "Credit DS Lines on Renewal Invoices Checkbox");
			click(Admin.SAVEBTN, "Save Button");

			// Verify Credit DS Lines on Renewal Invoices Checkbox is added
			// under Administrative Permissions on Role
			// Profile Page
			assertElementPresent(Admin.CREDIT_DS_LINES_ON_ROLE_PROFILE_PAGE,
					"Credit DS Lines on Renewal Invoices is added under Renewal Permissions on Role Profile Page");

			// Click on Edit Button again and uncheck Credit DS Lines on Renewal
			// Invoices Checkbox
			click(Admin.EDIT_BTN, "Edit Button");
			click(Admin.CREDIT_DS_LINES_CHECKBOX, "Credit DS Lines on Renewal Invoices Checkbox");

			// Click on save btn
			click(Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Administrative Permissions
			// Field
			assertTextMatching(Admin.RENEWAL_PERMISSIONS_FIELD, "No permissions",
					"No permissions Msg on Renewal Permissions Field");

			// Navigate to Roles Page
			click(Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void verifyCreditDSButtonDependingOnPermission(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {
			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);
			String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);

			// Invoice List verification
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			if (strTestCaseID.contains("Credit DS button is enabled for user having Credit DS permission")) {
				// Click On Credit DS Sorting Link
				click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
				isEnabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button on Invoice tab");
			} else if (strTestCaseID
					.contains("Credit DS button is disabled for user not having Credit DS permission")) {
				// Click On Credit DS Sorting Link
				click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
				isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on Invoice tab");
			}

			// Entity verification
			click(HomePage.ENTITY_TAB, "Entity Tab");

			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");

			if (strTestCaseID.contains("Credit DS button is enabled for user having Credit DS permission")) {
				userHasCreditDSPermissions();
			} else if (strTestCaseID
					.contains("Credit DS button is disabled for user not having Credit DS permission")) {
				userHasNOCreditDSPermissions();
			}

			// Affiliation verification
			click(HomePage.AFFILIATION_TAB, "Affiliation Tab");
			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			if (strTestCaseID.contains("Credit DS button is enabled for user having Credit DS permission")) {
				userHasCreditDSPermissions();
			} else if (strTestCaseID
					.contains("Credit DS button is disabled for user not having Credit DS permission")) {
				userHasNOCreditDSPermissions();
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void userHasCreditDSPermissions() throws Throwable {
		try {

			// Click on Renewal Invoices from left nav bar
			click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");

			// commented because invoice with DS item is not available in
			// current tab
			/*
			 * isEnabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS Button on Current Renewal Invoices tab");
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab");
			 * isEnabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS Button on Last 2 Year's Renewal Invoices tab");
			 */
			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isEnabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button on All renewal invoices tab");

			// Click on Revisions link from left nav
			click(RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");
			// commented because invoice with DS item is not available in
			// current tab
			// isEnabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS
			// Button on Current Revisable Invoices tab");

			// Click on all revisable invoices tab
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");

			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isEnabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button on All Revisable Invoices tab");

		} catch (Exception e) {
			throw e;
		}

	}

	public void userHasNOCreditDSPermissions() throws Throwable {
		try {

			// Click on Renewal Invoices from left nav bar
			click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			// commented because invoice with DS item is not available in
			// current tab
			/*
			 * isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS button on Current Renewal Invoices tab");
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab");
			 * isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS button Last 2 Year's Renewal Invoices tab");
			 */
			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on All renewal invoices tab");

			// Click on Revisions link from left nav
			click(RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");
			// commented because invoice with DS item is not available in
			// current tab
			// isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS
			// button on Current Revisable Invoices yab");

			// Click on all revisable invoices tab
			click(RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");

			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on All Revisable Invoices tab");

		} catch (Exception e) {
			throw e;
		}

	}

	public void buttonFunctionalityOfCreditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String errorMessage = "At least one DS line must be selected to credit.";

			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			// Get invoice id
			String invoiceNumber = getText(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "Invoice name");

			// Click on Credit DS Button
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Click on Revise button and verify message is displayed
			click(RenewalInvoice.REVISION_BTN_TOP, "Revise Button at the top");
			assertTextMatching(RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);
			click(RenewalInvoice.REVISION_BTN_BOTTOM, "Revise Button at the bottom");
			assertTextMatching(RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);

			// Click on Revision Preview button and verify message is displayed
			click(RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Revision Preview Button at the top");
			assertTextMatching(RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);
			click(RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Revision Preview at the bottom");
			assertTextMatching(RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);

			// Back to Invoice List button is displayed if invoice is accessed
			// from Invoice tab
			assertElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
					"Back to Invoice List button at the bottom");

			// Functionality of Back to Invoice List
			click(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Page Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Renewal Invoice Search", "Context Title");
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button");

			// Functionality of Revise button at the top
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			click(RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(RenewalInvoice.REVISION_BTN_TOP, "Revise Button at the top");
			verifyReviseInvoicePageIsDisplayed(invoiceNumber);
			click(RenewalInvoice.CANCEL_BTN, "Cancel Button");
			verifyInvoiceProfilePageIsDisplayed(invoiceNumber);
			click(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// Functionality of Revise button at the bottom
			click(RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(RenewalInvoice.REVISION_BTN_BOTTOM, "Revise Button at the bottom");
			verifyReviseInvoicePageIsDisplayed(invoiceNumber);
			click(RenewalInvoice.CANCEL_BTN, "Cancel Button");
			verifyInvoiceProfilePageIsDisplayed(invoiceNumber);
			click(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// Functionality of Revision Preview button at the top
			click(RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Revise Button at the top");
			waitForElementToBeClickable(RenewalInvoice.REVISE_BTN, "Revise Button on Revision Preview page");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Affected Invoices", "Page Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Invoice Preview", "Context Title");
			click(RenewalInvoice.REVISE_BTN, "Revise Button on Revision Preview page");
			verifyReviseInvoicePageIsDisplayed(invoiceNumber);
			click(RenewalInvoice.CANCEL_BTN, "Cancel Button");
			verifyInvoiceProfilePageIsDisplayed(invoiceNumber);
			click(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// Functionality of Revision Preview button at the bottom
			click(RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Revise Button at the bottom");
			waitForElementToBeClickable(RenewalInvoice.REVISE_BTN, "Revise Button on Revision Preview page");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Affected Invoices", "Page Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Invoice Preview", "Context Title");

			/*
			 * //Verify Back to Invoice List button is not displayed on Credit DS page if
			 * invoice is accessed from Affiliatoin tab String affId =
			 * Excelobject.getCellData(ReportSheet, "Affiliation ID", count);
			 * click(HomePage.AFFILIATION_TAB, "Affiliation Tab"); // Enter an id to be
			 * searched and click on search button type(Affiliation.AFFILIATIONID, affId,
			 * "Affiliation ID Text box"); click(Affiliation.SEARCHBTN, "Search Button"); //
			 * Click on Renewal Invoices from left nav bar
			 * click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK,
			 * "Renewal Invoices left nav link");
			 * click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			 * elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP,
			 * "Back to Invoice List button at the top");
			 * elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
			 * "Back to Invoice List button at the bottom");
			 * 
			 * //Verify Back to Invoice List button is not displayed on Credit DS page if
			 * invoice is accessed from Entity tab String entityId =
			 * Excelobject.getCellData(ReportSheet, "Entity ID", count);
			 * click(HomePage.ENTITY_TAB, "Entity Tab"); // Enter Entity ID and click on
			 * search button type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			 * click(Entity.SEARCH_BTN, "Search Button"); // Click On Renewal Invoices from
			 * left nav links click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
			 * "Renewal Invoice Left Nav Link");
			 * click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			 * elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP,
			 * "Back to Invoice List button at the top");
			 * elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
			 * "Back to Invoice List button at the bottom");
			 */

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyReviseInvoicePageIsDisplayed(String invoiceNumber) throws Throwable {
		try {
			// Verify Revise Invoice page is displayed of respective invoice
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Revise Invoice", "Page Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Revise Invoice", "Context Title");
			String invoiceIDOnReviseInvoice = getText(RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR,
					"Invoice Number on context bar");
			assertTextContains(invoiceIDOnReviseInvoice, invoiceNumber);
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyInvoiceProfilePageIsDisplayed(String invoiceNumber) throws Throwable {
		try {
			// Verfiy user is navigated to Invoice Profile page
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Page Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Invoice Profile", "Context Title");
			String invoiceIDOnInvoiceProfile = getText(RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR,
					"Invoice Number on context bar");
			assertTextContains(invoiceIDOnInvoiceProfile, invoiceNumber);
		} catch (Exception e) {
			throw e;
		}
	}

	public void backToInvoiceListButtonOnCreditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			// Click on Credit DS Button
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Back to Invoice List button is displayed if invoice is accessed
			// from Invoice tab
			assertElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertElementPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
					"Back to Invoice List button at the bottom");

			// Functionality of Back to Invoice List
			click(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertTextMatching(RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Page Title");
			assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Renewal Invoice Search", "Context Title");
			assertElementPresent(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button");

			// Verify Back to Invoice List button is not displayed on Credit DS
			// page if invoice is accessed from Affiliatoin tab
			String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);
			click(HomePage.AFFILIATION_TAB, "Affiliation Tab");
			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");

			// Click on Renewal Invoices from left nav bar
			click(Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM, "Back to Invoice List button at the bottom");

			// Verify Back to Invoice List button is not displayed on Credit DS
			// page if invoice is accessed from Entity tab
			String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);
			click(HomePage.ENTITY_TAB, "Entity Tab");
			// Enter Entity ID and click on search button
			type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(Entity.SEARCH_BTN, "Search Button");
			// Click On Renewal Invoices from left nav links
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Click on All Renewal Invoices Tab
			click(RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			// Click On Credit DS Sorting Link
			click(RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			elementIsNotPresent(RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM, "Back to Invoice List button at the bottom");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSButtonOnInvoiceProfilePage(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(RenewalInvoice.SEARCH_BTN, "Search Button");

			click(RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice in the grid");

			// verify Credit DS button is displayed on Invoice Profile page
			assertElementPresent(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// verify Credit DS button is disabled for revised invoice
			isDisabled(RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on Invoice tab");

			if (strTestCaseID.contains("'Credit DS' buton is enabled on Invoice Profile page for Issued invoice")) {
				// click on Credit DS button and verify Credit DS page is
				// displayed
				click(RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");
				assertTextMatching(RenewalInvoice.CONTEXT_TITLE, "Credit Disbursements", "Context Title");
			} else if (strTestCaseID
					.contains("'Credit DS' buton is disabled on Invoice Profile page for Revised Invoice")) {
				isDisabled(RenewalInvoice.CREDIT_DS_BTN, "Credit DS button on Invoice tab");
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void enableOrDisablePSOPFlag(String enableOrDisable) throws Throwable {
		click(Affiliation.MAINTAIN_PAPER_SURCHARGE_BILLING_BTN, "Maintain Paper Surcharge Billing Button");

		if (enableOrDisable.equalsIgnoreCase("Enable")) {
			click(Affiliation.ENABLE_RADIO_BTN, "Enable Radio Button");
			click(Affiliation.SAVEBTN, "Save Button");
			assertTextMatching(Affiliation.PAPER_SURCHARGE_BILLING, "Enabled", "Paper Surchase Billing Value");
		} else if (enableOrDisable.equalsIgnoreCase("Disable")) {
			click(Affiliation.DISABLE_RADIO_BTN, "Disable Radio Button");
			click(Affiliation.SAVEBTN, "Save Button");
			assertTextMatching(Affiliation.PAPER_SURCHARGE_BILLING, "Disabled", "Paper Surchase Billing Value");
		}
	}

	public void paperSurchargeBillingFlag(String ReportSheet, int count) throws Throwable {
		try {

			// create Entity
			String entity_id = createEntity(ReportSheet, count);

			/*
			 * String entity_id = "9401966156"; // click on Entity Search link
			 * click(HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			 * waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box"); // Enter
			 * Entity ID and click on search button type(Entity., , "Entity Id Text box");
			 * click(Entity.SEARCH_BTN, "Search Button");
			 */

			// Default value of paper surcharge billing is disabled
			assertTextMatching(Affiliation.PAPER_SURCHARGE_BILLING, "Disabled", "Paper Surchase Billing Value");
			// Enable paper surcharge billing
			enableOrDisablePSOPFlag("Enable");

			ArrayList<String> resultEntity = SQL_Queries.getPSOPBillingFlagForEntity(entity_id);
			System.out.println(resultEntity.size());
			String expectedEntityId = null;
			for (int i = 0; i < resultEntity.size(); i++) {
				System.out.println(resultEntity.get(i));
				if (resultEntity.get(i).equals(entity_id)) {
					expectedEntityId = resultEntity.get(i);
					printMessageInReport(
							"Entity \"" + expectedEntityId + "\" is inserted in table when PSOP flag is enabled");
					break;
				}
			}

			// Disable paper surcharge billing
			enableOrDisablePSOPFlag("Disable");

			ArrayList<String> resultEntity1 = SQL_Queries.getPSOPBillingFlagForEntity(entity_id);
			if (resultEntity1.size() == 0) {
				printMessageInReport(
						"Entity \"" + expectedEntityId + "\" is deleted from table when PSOP flag is disabled");
			}

			// create Affiliation
			String affl_id = CreateAffiliation(ReportSheet, count);

			/*
			 * // click on Affiliation Search link click(HomePage.AFFILIATIONSEARCHLINK,
			 * "Affiliation Search"); waitForElementPresent(Affiliation.AFFILIATIONID,
			 * "Affiliation ID Text box");
			 * 
			 * String affl_id = "310469246"; // Enter an id to be searched and click on
			 * search button type(Affiliation.AFFILIATIONID, affl_id,
			 * "Affiliation ID Text box"); click(Affiliation.SEARCHBTN, "Search Button");
			 */

			// Default value of paper surcharge billing is disabled
			assertTextMatching(Affiliation.PAPER_SURCHARGE_BILLING, "Disabled", "Paper Surchase Billing Value");
			// Enable paper surcharge billing
			enableOrDisablePSOPFlag("Enable");

			ArrayList<String> result = SQL_Queries.getPSOPBillingFlagForAffiliation(affl_id);
			String expectedAffiliationId = null;
			for (int i = 0; i < result.size(); i++) {
				if (result.get(i).equals(affl_id)) {
					expectedAffiliationId = result.get(i);
					printMessageInReport("Affiliation \"" + expectedAffiliationId
							+ "\" is inserted in table when PSOP flag is enabled");
					break;
				}
			}

			// Disable paper surcharge billing
			enableOrDisablePSOPFlag("Disable");

			ArrayList<String> result1 = SQL_Queries.getPSOPBillingFlagForAffiliation(affl_id);
			if (result1.size() == 0) {
				printMessageInReport("Affiliation \"" + expectedAffiliationId
						+ "\" is deleted from table when PSOP flag is disabled");
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyPSOPFlagOnAffiliationJoin(String ReportSheet, int count) throws Throwable {
		try {
			String affl_id = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);

			// click on Affiliation Search link
			click(HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(Affiliation.AFFILIATIONID, affl_id, "Affiliation ID Text box");
			click(Affiliation.SEARCHBTN, "Search Button");
			enableOrDisablePSOPFlag("Enable");

			joinAffiliation(ReportSheet, count);

			// Default value of paper surcharge billing is enabled
			assertTextMatching(Affiliation.PAPER_SURCHARGE_BILLING, "Enabled", "Paper Surchase Billing Value");

			quitAffiliation(ReportSheet, count);

			enableOrDisablePSOPFlag("Disable");

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchForTheEntity(String ReportSheet, int count) throws Throwable {
		try {
			waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
			click(HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, Excelobject.getCellData(ReportSheet, "Entity Id", count), "Entity Id text box");
			assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(Entity.SEARCH_BTN, "Search Button");
			// compareStrings(Excelobject.getCellData(ReportSheet, "Entity Id",
			// count),getText(Entity.ENTITY_ID_ON_ENTITY_PROFILE,"Entity Id on
			// Entity Profile Page"));
			// assertElementPresent(Entity.ENTITY_WITH_AFFILIATION_NAME,"Affiliated
			// name section");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchForTheAffiliation(String reportSheet, int count) throws Throwable {
		try {
			waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			click(HomePage.AFFILIATION_TAB, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(Affiliation.AFFILIATIONID, Excelobject.getCellData(reportSheet, "Affiliation Id", count),
					"Affiliation Id text box");
			assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(Affiliation.SEARCHBTN, "Search Button");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void maintainPaperSurchargeBilling() throws Throwable {
		try {
			waitForElementPresent(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button");
			assertElementPresent(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button");
			moveToElement(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button");
			String attribute = getAttribute(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "disabled");
			if (attribute == null) {
				isEnabled(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button enabled");
			} else if (attribute.equalsIgnoreCase("disabled")) {
				isDisabled(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button disabled");

			}
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// return getText(Entity.PAPER_SURCHARGE_BILLING, "Paper Surcharge
		// billing status");
	}

	/*
	 * if(getAttribute(Entity.ENTITY_WITH_AFFILIATION_NAME,"disabled").equals(
	 * "disabled")){ assertElementPresent(Entity.
	 * FIRST_ENTITY_IN_GRID,"Entity name in the Grid");
	 * click(Entity.FIRST_ENTITY_IN_GRID,"Click Entity in the Grid"); }
	 * assertElementPresent(Entity. JOIN_AFFILIATION_BTN,"join Affiliation button");
	 * click(Entity.JOIN_AFFILIATION_BTN,"Button Join Affiliation");
	 * waitForElementPresent(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX,
	 * "Affiliation name search box"); assertElementPresent(Entity.
	 * AFFILIATION_NAME_SEARCH_TEXTBOX,"Affiliation name search box");
	 * type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX,Excelobject.getCellData(
	 * ReportSheet, "Affiliation Name", count),"Affiliation name search box");
	 * assertElementPresent(Entity.FINDBTN,"Find Button");
	 * click(Entity.FINDBTN,"Find Button"); }
	 * 
	 * }
	 */
	public void intialiseTheReport(String testCaseID, String description, int iLoop) throws Throwable {
		child = extent.startTest(testCaseID, description);
		iterationReport(iLoop, testCaseID + " Started");

	}

	public void endTheReport(String testCaseID, int iLoop) throws Throwable {
		parent.appendChild(child);
		// This will mark end of the one row in data sheet
		iterationReport(iLoop, testCaseID + " Completed");
	}

	public void psopInvoiceUnderHomePage(String ReportSheet, int count, String expectedValue) throws Throwable {
		waitForElementPresent(HomePage.RENEWAL_XSOP_PSOP_INVOICE, "Renewal/XSOP/PSOP Invoice Search");
		assertElementPresent(HomePage.RENEWAL_XSOP_PSOP_INVOICE, "Renewal/XSOP/PSOP Invoice Serach is present");
		compareStrings(expectedValue, getText(HomePage.RENEWAL_XSOP_PSOP_INVOICE, "RENEWAL_XSOP_PSOP_INVOICE"));
	}

	public void psopInoviceSearch(String ReportSheet, int count, String leftNavBarVal) throws Throwable {
		click(HomePage.RENEWAL_XSOP_PSOP_INVOICE, "Renewal/XSOP/PSOP Invoice Serach link");
		assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
		compareStrings(leftNavBarVal, getText(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link"));

	}

	public void psopInvoiceSearchCriteriaUI() throws Throwable {

		try {
			waitForElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Criteria UI");
			compareStrings("PSOP Invoice Search Criteria",
					getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Criteria UI"));
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search Header");
			compareStrings("PSOP Invoice Search",
					getText(Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search Header"));
			assertElementPresent(Invoice.SEARCH_BY, "Search By Label");
			compareStrings("Search by", getText(Invoice.SEARCH_BY, "Search By Label"));
			assertElementPresent(Invoice.INVOICE_RADIO_BUTTON_LABEL, "Invoice Radio Button");
			compareStrings(" Invoice ", getText(Invoice.INVOICE_RADIO_BUTTON_LABEL, "Invoice Radio Button"));
			assertElementPresent(Invoice.CUSTOMER_RADIO_BUTTON_LABEL, "Customer Radio Button");
			compareStrings(" Customer ", getText(Invoice.CUSTOMER_RADIO_BUTTON_LABEL, "Invoice Radio Button"));
			assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, "Search text box");
			assertElementPresent(Invoice.INVOICE_STATUS_DROP_DOWN, "Inoice Status Label");
			compareStrings("Invoice Status", getText(Invoice.INVOICE_STATUS_DROP_DOWN, "Inoice Status Label"));
			assertElementPresent(Invoice.SERVICE_CENTER_DROP_DOWN, "Service Center Laebl");
			compareStrings("Service Center", getText(Invoice.SERVICE_CENTER_DROP_DOWN, "Service Center Laebl"));
			assertElementPresent(Invoice.SERVICE_TEAM_DROP_DOWN, "Service Team Label");
			compareStrings("Service Team", getText(Invoice.SERVICE_TEAM_DROP_DOWN, "Service Team Label"));
			assertElementPresent(Invoice.INVOICE_DATE_LABEL, "Invoice Date Label");
			compareStrings("* Invoice Date", getText(Invoice.INVOICE_DATE_LABEL, "Invoice Date Label"));
			assertElementPresent(Invoice.FROM_LABEL, "From Label");
			compareStrings("From", getText(Invoice.FROM_LABEL, "From Label"));
			assertElementPresent(Invoice.To_LABEL, "To Label");
			compareStrings("To", getText(Invoice.To_LABEL, "To Label"));
			assertElementPresent(Invoice.DATE_IN_FROM_LABEL, "Date in From Label");
			// compareStrings(getCurrentDate(),
			// getAttribute(Invoice.DATE_IN_FROM_LABEL, "value"));
			assertElementPresent(Invoice.DATE_IN_TO_LABEL, "Date in To Label");
			// compareStrings(getCurrentDate(),
			// getAttribute(Invoice.DATE_IN_TO_LABEL, "value"));
			assertElementPresent(Invoice.FROM_LABEL_CALENDAR_ICON, "From Date Calendar for date selection");
			assertElementPresent(Invoice.TO_LABEL_CALENDAR_ICON, "To date Calendar for date selection");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void paperSurchargeBillingStatus(String reportSheet, int count, String profile) throws Throwable {
		String paperSurchargeBillingStatus = null;
		String entity_id = Excelobject.getCellData(reportSheet, "Entity Id", count);
		String affl_id = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		try {

			if (profile.equals("Affiliation Profile")) {
				waitForElementPresent(Entity.AFFILIATION_NAME, "Affiliation link");
				assertElementPresent(Entity.AFFILIATION_NAME, "Affiliation link");
				click(Entity.AFFILIATION_NAME, "Affiliation link");
			}
			waitForElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
			assertElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
			assertElementPresent(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
			String billingStatus = getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
			click(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
			if (billingStatus.contains("Disabled")) {
				paperSurchargeBillingStatus = "Enabled";
				click(Entity.PAPER_SURCHARGE_BILLING_ENABLE, "Paper surchage billing enable radio button");
			} else if (billingStatus.equals("Enabled")) {
				paperSurchargeBillingStatus = "Disabled";
				click(Entity.PAPER_SURCHARGE_BILLING_DISABLE, "Paper Surcharge billing disable radio button");
			}
			assertElementPresent(Entity.SAVE_BTN, "Save button");
			click(Entity.SAVE_BTN, "Save button");
			if (profile.equals("Entity Profile")) {
				assertElementPresent(Entity.PAGE_TITLE, "Entity Profile Page");
				paperSurchargeBillingValueStored(entity_id, profile,
						getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status post updating"));
			} else if (profile.equals("Affiliation Profile")) {
				assertElementPresent(Affiliation.SUBGROUPPROFILETITLE, "Affiliation Profile Page");
				paperSurchargeBillingValueStored(affl_id, profile,
						getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status post updating"));
			}
			assertElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surchaarge billing status");
			compareStrings(paperSurchargeBillingStatus,
					getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status post updating"));

		} catch (Exception e) {
			e.printStackTrace();

		} catch (Throwable t) {
			t.printStackTrace();
		}
		// return getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge
		// billing status post updating");
	}

	public void paperSurchageBillingStatusPostQuitAffiliation() throws Throwable {
		maintainPaperSurchargeBilling();
		waitForElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		assertElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		compareStrings("Disabled", getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status"));

	}

	public void paperSurchargeBillingValueStored(String id, String profile, String status) throws Throwable {
		if (status.equals("Enabled")) {
			if (profile.equals("Entity Profile")) {
				ArrayList<String> resultEntity = SQL_Queries.getPSOPBillingFlagForEntity(id);
				for (int i = 0; i < resultEntity.size(); i++) {
					System.out.println(resultEntity.get(i));
					if (resultEntity.get(i).equals(id)) {
						try {
							printMessageInReport(
									"Entity \"" + id + "\" is inserted in table when PSOP flag is enabled");
						} catch (Throwable e) {
							e.printStackTrace();
						}
						break;
					}
				}
			} else if (profile.equals("Affiliation Profile")) {
				ArrayList<String> result = SQL_Queries.getPSOPBillingFlagForAffiliation(id);
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).toString().equals(id)) {

						printMessageInReport(
								"Affiliation \"" + id + "\" is inserted in table when PSOP flag is enabled");
						break;
					}
				}
			}
		} else if (status.equals("Disabled") && profile.equals("Affiliation Profile")) {
			ArrayList<String> result1 = SQL_Queries.getPSOPBillingFlagForAffiliation(id);
			if (result1.size() == 0) {
				printMessageInReport("Affiliation \"" + id + "\" is deleted from table when PSOP flag is disabled");
			}
		} else if (status.equals("Disabled") && profile.equals("Entity Profile")) {
			ArrayList<String> result1 = SQL_Queries.getPSOPBillingFlagForEntity(id);
			if (result1.size() == 0) {
				printMessageInReport("Entity \"" + id + "\" is deleted from table when PSOP flag is disabled");
			}
		}
	}

	// Sprint 25 functions
	public void searchTheDocumentUploadedRBCOld(String filename) throws Throwable {

		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "File Name", "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "equals", "Filter drop down2");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, filename, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}

	public void selectAndAssignTheFileToTeam() throws Throwable {
		waitForElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		assertElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		click(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign button");
		click(SOP.ASSIGN_BTN, "Assign button");
		Thread.sleep(1000);
		waitForElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		assertElementPresent(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		click(SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		Thread.sleep(1000);
	}

	public String completeTheCESESOP(String reportSheet, int count, String filename) throws Throwable {
		String esopId = null;
		try {
			String entity_name = Excelobject.getCellData(reportSheet, "Entity Name", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "Lawsuit Type", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			searchTheDocumentUploadedRBCOld(filename);
			assertElementPresent(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
			click(SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
			// CESSELECTBTN
			waitForElementPresent(SOP.CESSELECTBTN, "CES button");
			assertElementPresent(SOP.CESSELECTBTN, "CES button");
			click(SOP.CESSELECTBTN, "CES button in SOP List Items Page button");
			// SELECT_ARROW_ENTITY_BTN
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, entity_name, "Entity search text box on ESOP");
			// INCLUDE_ALL_REPRESENTATION_JURISDICTION
			waitForElementPresent(SOP.INCLUDE_ALL_REPRESENTATION_JURISDICTION, "inclue all rep jurisdiction");
			assertElementPresent(SOP.INCLUDE_ALL_REPRESENTATION_JURISDICTION, "inclue all rep jurisdiction");
			click(SOP.INCLUDE_ALL_REPRESENTATION_JURISDICTION, "inclue all rep jurisdiction");
			// INCLUDE_STAFFING_ENTITIES
			waitForElementPresent(SOP.INCLUDE_STAFFING_ENTITIES, "inclue all staffing entities");
			assertElementPresent(SOP.INCLUDE_STAFFING_ENTITIES, "inclue all staffing entities");
			click(SOP.INCLUDE_STAFFING_ENTITIES, "inclue all staffing entities");
			// SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			// FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			// GLYPHICON_HOME
			driver.switchTo().defaultContent();
			assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
			click(SOP.GLYPHICON_HOME, "glyphicon button");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			// ARROW_REPRESENTATION
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
			assertElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
			click(SOP.ARROW_REPRESENTATION, "Arrow representation button");
			// CLEARBTN
			waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
			assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
			click(SOP.CLEARBTN, "Clear Button of filter");
			// Select REp Status Active
			selectByVisibleText(SOP.DROP_DOWN_LIST_LEFT, "Rep. Status",
					"Select the Representation status from drop down in CES Page");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "Active", "Select Active from the drop down in CES Page");
			// assert
			waitForElementPresent(SOP.REPRESENTATION_STATUS, "Rep Status in the Grid");
			assertElementPresent(SOP.REPRESENTATION_STATUS, "Rep Status in the Grid");
			click(SOP.FILTERGOBTN, "click on go button in CES Page");
			int index = returnIndexOfMatchedTextvalue(SOP.REPRESENTATION_STATUS, "Active");
			//
			waitForElementPresent(SOP.SELECT_BUTTON, "Select Button in Grid");
			assertElementPresent(SOP.SELECT_BUTTON, "Select Button in Grid");
			clickOnAParticularIndexOfAnElement(SOP.SELECT_BUTTON, "Select button in Grid", index);
			// LAWSUITTYPE_DROPDOWN
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			// WORKSHEET_ID_ON_CONTEXT_BAR
			/*
			 * assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID"); esopId =
			 * getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			 */
			// SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
			click(SOP.SUBMIT_CES, "Submit button in CES");
			driver.switchTo().defaultContent();
			if (esopId.equals(null)) {
				throw new NullPointerException();
			}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return esopId.split("\\: ")[1];
	}

	public void teamSOPDashboard(String reportSheet, int count) throws Throwable {
		String dashboard = Excelobject.getCellData(reportSheet, "Team Dashboard", count);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		// TEAM_SOP_DASHBOARD
		waitForElementPresent(SOP.TEAM_SOP_DASHBOARD, "Team SOP Dashboard link in left nav SOP List Page");
		assertElementPresent(SOP.TEAM_SOP_DASHBOARD, "assert Team SOP Dashboard link in left nav SOP List Page");
		click(SOP.TEAM_SOP_DASHBOARD, "click Team SOP Dashboard link in left nav SOP List Page");
		// REJECTED_HARD_COPY_REQUIRED
		assertElementPresent(SOP.REJECTED_HARD_COPY_REQUIRED,
				"Rejected and hard copy required status assert Team SOP Dashboard Page");
		// PHONE_CALL_REQUIRED
		assertElementPresent(SOP.PHONE_CALL_REQUIRED, "Phone Call Required status assert Team SOP Dashboard Page");
		// INCOMPLETE_WORKSHEETS
		assertElementPresent(SOP.INCOMPLETE_WORKSHEETS, "Incomplete Worksheet status assert Team SOP Dashboard Page");
		// PENDING_ACTION_ITEMS
		assertElementPresent(SOP.PENDING_ACTION_ITEMS, "Pending Action Items status assert Team SOP Dashboard Page");
		if (!dashboard.equals("")) {
			// TEAM_DROP_DOWN
			waitForElementPresent(SOP.TEAM_DROP_DOWN, "Team drop down fields in Team SOP Dashboard Page");
			assertElementPresent(SOP.TEAM_DROP_DOWN, "assert Team drop down fields in Team SOP Dashboard Page");
			click(SOP.TEAM_DROP_DOWN, "click Team drop down fields in Team SOP Dashboard Page");
			selectByVisibleText(SOP.TEAM_DROP_DOWN, dashboard, "select the text in Team drop down");
			// REJECTION_FOR_REVIEW
			if (dashboard.equals("SOP Support Team") && dashboard.equals("SOP Dallas Processing Team")) {
				waitForElementPresent(SOP.REJECTION_FOR_REVIEW,
						"Rejection for review status assert Team SOP Dashboard Page");
				assertElementPresent(SOP.REJECTION_FOR_REVIEW,
						"Rejection for review status assert Team SOP Dashboard Page");
			}
		}
	}

	public void rejectedLogFieldValidation(String esopId) throws Throwable {
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		// WOKSHEET_SEARCH_LEFT_NAV_LINK
		waitForElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "worksheet search link in left nav");
		assertElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "assert worksheet search link in left nav");
		click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "click on worksheet search link in left nav");
		// CLASSIC_SEARCH_BTN
		waitForElementPresent(SOP.CLASSIC_SEARCH_BTN, "Classic search button in Worksheet Search Criteria Page");
		assertElementPresent(SOP.CLASSIC_SEARCH_BTN, "assert Classic search button in Worksheet Search Criteria Page");
		click(SOP.CLASSIC_SEARCH_BTN, "click on Classic search button in Worksheet Search Criteria Page");
		String worskheetId = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
		// WORKSHEET_ID_TEXTBOX
		waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Id text box in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "assert Id text box in Classic Worksheet Search Criteria Page");
		type(SOP.WORKSHEET_ID_TEXTBOX, worskheetId, "type Id in text box in Classic Worksheet Search Criteria Page");
		// WORKSHEET_SEARCH_BTN
		waitForElementPresent(SOP.WORKSHEET_SEARCH_BTN, "Search button in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_SEARCH_BTN,
				"assert Search button in Classic Worksheet Search Criteria Page");
		click(SOP.WORKSHEET_SEARCH_BTN, "click Search button in Classic Worksheet Search Criteria Page");
		// BAD_LOG
		assertElementPresent(SearchWorksheet.BAD_LOG, "Bad log in Worksheet Profile Page");
		String isBadLog = getText(SearchWorksheet.BAD_LOG, "Bad log in Worksheet Profile Page");
		compareStrings(isBadLog, "No");
		// WORKSHEET_TYPE
		assertElementPresent(SearchWorksheet.WORKSHEET_TYPE, "Worksheet Type in Worksheet Profile Page");
		String worksheetType = getText(SearchWorksheet.WORKSHEET_TYPE, "Worksheet Type in Worksheet Profile Page");
		compareStrings(worksheetType, "Standard SOP");
		// CONFIRMATION_NUMBER
		assertElementPresent(SearchWorksheet.CONFIRMATION_NUMBER, "Confirmation Number in Worksheet Profile Page");
		String confNum = getText(SearchWorksheet.CONFIRMATION_NUMBER, "Confirmation Number in Worksheet Profile Page");
		compareStrings(confNum, "--");
		// CUSTOMER
		assertElementPresent(SearchWorksheet.CUSTOMER, "Customer in Worksheet Profile Page");
		String customer = getText(SearchWorksheet.CUSTOMER, "Customer in Worksheet Profile Page");
		compareStrings(customer, "--");
		// INDIVIDUAL
		assertElementPresent(SearchWorksheet.INDIVIDUAL, "Individual in Worksheet Profile Page");
		String individual = getText(SearchWorksheet.INDIVIDUAL, "Individual in Worksheet Profile Page");
		compareStrings(individual, "--");
		// REJECTION_APPROVED
		assertElementPresent(SearchWorksheet.REJECTION_APPROVED, "Rejection Approved in Worksheet Profile Page");
		String rejectionApproved = getText(SearchWorksheet.REJECTION_APPROVED,
				"Rejection Approved in Worksheet Profile Page");
		compareStrings(rejectionApproved, "Yes");
		// ATTEMPTED
		assertElementPresent(SearchWorksheet.ATTEMPTED, "ATTEMPTED in Worksheet Profile Page");
		String attempted = getText(SearchWorksheet.ATTEMPTED, "ATTEMPTED in Worksheet Profile Page");
		compareStrings(attempted, "No");
		// INITIAL_SUBSEQUENT
		assertElementPresent(SearchWorksheet.INITIAL_SUBSEQUENT, "Initial/Subsequent in Worksheet Profile Page");
		String intialSubsequent = getText(SearchWorksheet.INITIAL_SUBSEQUENT,
				"Initial/Subsequent in Worksheet Profile Page");
		compareStrings(intialSubsequent, "Initial");
		// CONSOLIDATED
		assertElementPresent(SearchWorksheet.CONSOLIDATED, "Consolidated in Worksheet Profile Page");
		String consolidated = getText(SearchWorksheet.CONSOLIDATED, "Consolidated in Worksheet Profile Page");
		compareStrings(consolidated, "No");
		// MULTIPLE
		assertElementPresent(SearchWorksheet.MULTIPLE, "MULTIPLE in Worksheet Profile Page");
		String multiple = getText(SearchWorksheet.MULTIPLE, "MULTIPLE in Worksheet Profile Page");
		compareStrings(multiple, "No");
		// LETTER
		assertElementPresent(SearchWorksheet.LETTER, "Letter in Worksheet Profile Page");
		String letter = getText(SearchWorksheet.LETTER, "Letter in Worksheet Profile Page");
		compareStrings(letter, "No");
		// POST_STATUS
		assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus, "UnPosted");
		ArrayList<String> cesFields = SQL_Queries.getTheFieldsForTheESOPs(esopId);
		for (int i = 0; i < cesFields.size(); i++) {
			if (cesFields.get(i) == null) {
				cesFields.set(i, "--");
			}
		}
		// DEFENDANT_NAME
		assertElementPresent(SearchWorksheet.DEFENDANT_NAME, "Defendant in Worksheet Profile Page");
		String defendant = getText(SearchWorksheet.DEFENDANT_NAME, "Defendant in Worksheet Profile Page");
		compareStrings(defendant, cesFields.get(2));
		// AGENCY_TITLE
		assertElementPresent(SearchWorksheet.AGENCY_TITLE, "Agency in Worksheet Profile Page");
		String agencyTitle = getText(SearchWorksheet.AGENCY_TITLE, "Agency in Worksheet Profile Page");
		compareStrings(agencyTitle, "None Specified");
		// CASE_NUMBER
		assertElementPresent(SearchWorksheet.CASE_NUMBER, "case number in Worksheet Profile Page");
		String caseNumber = getText(SearchWorksheet.CASE_NUMBER, "case number in Worksheet Profile Page");
		compareStrings(caseNumber, cesFields.get(0));
		// PLAINTIFF
		assertElementPresent(SearchWorksheet.PLAINTIFF, "Plaintiff in Worksheet Profile Page");
		String plaintiff = getText(SearchWorksheet.PLAINTIFF, "Plaintiff in Worksheet Profile Page");
		compareStrings(plaintiff, cesFields.get(1));

	}

	/*public String viewAndCreateTheWorkSheetUsingESOPId(String reportSheet, int count, String esopId) throws Throwable {
		String worksheetId = null;
		try {
			String defendentName = Excelobject.getCellData(reportSheet, "WS Defendent Name", count);
			String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
			String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);
			String attorney = Excelobject.getCellData(reportSheet, "WS Attorney", count);
			String court = Excelobject.getCellData(reportSheet, "WS Court", count);
			String documentServed = Excelobject.getCellData(reportSheet, "Document Served", count);
			String caseNum = Excelobject.getCellData(reportSheet, "WS Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "WS Plaintiff", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
			try {
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);

			} catch (NoSuchElementException e) {
			}
			Thread.sleep(5000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(5000);
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");
			click(SOP.VIEW_BTN, "View button");
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(3000);
			WebElement createWs = null;
			try {
				createWs = driver.findElement(SOP.CREATE_WORKSHEET);
				waitForElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			} catch (NoSuchElementException e) {
			}
			if (createWs == null) {
				Thread.sleep(4000);
				selectAndAssignTheFileToTeam();
				Thread.sleep(4000);
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				Thread.sleep(2000);
				String parentWin = driver.getWindowHandle();
				waitForElementPresent(SOP.VIEW_BTN, "View button");
				assertElementPresent(SOP.VIEW_BTN, "View button");
				click(SOP.VIEW_BTN, "View button");
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}

			Thread.sleep(2000);
			WebElement initalRadioButton = null;
			try {

				initalRadioButton = driver.findElement(SOP.INITIAL_RADIOBTN);

			} catch (NoSuchElementException e) {
			}
			if (initalRadioButton == null) {
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}
			if (isAttempted.equalsIgnoreCase("Yes")) {
				// ATTEMPTED_YES_RADIO_BUTTON
				waitForElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Radio button");
				assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Radio button");
				click(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Radio button");
			}
			// INITIAL_RADIOBTN
			waitForElementPresent(SOP.INITIAL_RADIOBTN, "Initial Radio button");
			assertElementPresent(SOP.INITIAL_RADIOBTN, "Initial Radio button");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio button");
			if (!caseNum.equals("")) {
				// CASEID_TEXTBOX
				waitForElementPresent(SOP.CASEID_TEXTBOX, "Case Id text box");
				assertElementPresent(SOP.CASEID_TEXTBOX, "Case Id text box");
				type(SOP.CASEID_TEXTBOX, caseNum, "Case Id text box");
			}
			if (!plaintiff.equals("")) {
				// PLAINTIFF_TEXT_BOX
				waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
				assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plantiff text box");
				type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plantiff text box");
			}
			if (!defendentName.equals("")) {
				// DEFENDANT_TEXTFIELD
				waitForElementPresent(SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
				assertElementPresent(SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
				type(SOP.DEFENDANT_TEXTFIELD, defendentName, "Defendent text box");
			}
			
			 * //REJECT_REASON if(!rejectedReason.equals("")){
			 * assertElementPresent(WorksheetCreate.
			 * REJECTED_REASON,"Rejected Reason wroksheet step 1 page");
			 * selectByVisibleText(WorksheetCreate.REJECTED_REASON,
			 * rejectedReason,"Rejected Reason wroksheet step 1 page");
			 * assertElementPresent(SOP.DATE_CALENDAR, "Calendar Icon");
			 * click(SOP.DATE_CALENDAR, "Calendar Icon"); click(Entity.TODAYSDATE,
			 * "Todays Date");
			 * assertElementPresent(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
			 * click(SOP.NEXT_BTN,"next button in wroksheet step 1 page");
			 * Thread.sleep(1000); //COURT //below will be used to edit the court which will
			 * validate the story 1283
			 * assertElementPresent(WorksheetCreate.COURT,"Court in wroksheet step 2 page");
			 * selectByVisibleText(WorksheetCreate.COURT,
			 * court,"Court in wroksheet step 2 page"); }
			 
			// else if(rejectedReason.equals("")){
			// For Certified mail below one check need to be added
			// POST_MARKED_DATE
			try {
				driver.findElement(WorksheetCreate.METHOD_OF_SERVICE);
				String methodOfService = getText(WorksheetCreate.METHOD_OF_SERVICE, "Method of Service");
				if (methodOfService.contains("Mail") && !methodOfService.equals("Express Mail")) {
					waitForElementPresent(WorksheetCreate.POST_MARKED_DATE, "Post marked Date text box");
					assertElementPresent(WorksheetCreate.POST_MARKED_DATE, "Post marked Date text box");
					int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1;
					String lastYearDate = getCurrentDate().split("\\/")[0] + "/" + getCurrentDate().split("\\/")[1]
							+ "/" + String.valueOf(lastYear);
					type(WorksheetCreate.POST_MARKED_DATE, lastYearDate, "Post marked Date text box");
				}
			} catch (NoSuchElementException e) {
			}
			// EDIT_RECEIVED_BY
			selectByIndex(WorksheetCreate.EDIT_RECEIVED_BY, 1, "Received By drop downs in wroksheet step 1 page");
			// WORKSHEET_TYPE
			waitForElementPresent(WorksheetCreate.WORKSHEET_TYPE, "worksheet type in wroksheet step 1 page");
			String worksheetType = getText(WorksheetCreate.WORKSHEET_TYPE, "worksheet type in wroksheet step 1 page");
			// ENTITY_IN_WORKSHEET_PROFILE
			waitForElementPresent(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,
					"Entity in wroksheet profile step 1 page");
			String entityInWorksheet = getAttribute(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE, "value");
			// NEXT_BTN
			waitForElementPresent(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
			assertElementPresent(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
			click(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
			Thread.sleep(1200);
			// below check for if error- > 'Enter a value for Other Mehod of Serivce.
			try {

				driver.findElement(SOP.OTHER_METHOD_OF_SERVICE);
				Thread.sleep(2000);
				type(SOP.OTHER_METHOD_OF_SERVICE_TEXT_BOX, "Other", "Type the Text for other Method of Service");
				click(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
				Thread.sleep(700);
			} catch (NoSuchElementException e) {
			}
			// below check for if Error -> Enter a valid value for Case#.
			try {
				// Below code is modified on 12/23
				driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
				Thread.sleep(1000);
				boolean caseTextPsNum = false;
				// Below try block is added as some method of srvice has different way of
				// SElecting the CASe# in worksheet page 1
				try {
					driver.findElement(SOP.CASE_TEXT_PS_CASENUM);
					Thread.sleep(500);
					type(SOP.CASE_TEXT_PS_CASENUM, "CNInWorksheet", "Type the Text for other Method of Service");
					click(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
					caseTextPsNum = true;
				} catch (NoSuchElementException e) {
				}
				if (caseTextPsNum == false) {
					type(WorksheetCreate.CASE_TEXT, "CNInWorksheet", "Type the Text for other Method of Service");
					click(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
					Thread.sleep(700);
				}
			} catch (NoSuchElementException e) {
			}
			// This try block is added on 12/23
			try {
				driver.findElement(SOP.CASE_NUMBER_BLANK);
				type(WorksheetCreate.CASE_TEXT, "CNInWorksheet", "Type the Text for other Method of Service");
				click(SOP.NEXT_BTN, "next button in wroksheet step 1 page");
				Thread.sleep(700);
			} catch (NoSuchElementException e) {
			}

			// COURT_NAME_TEXT_BOX
			String attorneyNoneAttribute = "";
			String courtNameInWorksheet = "";

			try {
				attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
			} catch (NoSuchElementException e) {
			}
			try {
				driver.findElement(SOP.EXISTING_COURTNAME);
				courtNameInWorksheet = getText(SOP.TEXT_BOX_COURTNAME, "value");
			} catch (NoSuchElementException e) {
			}
			try {
				driver.findElement(SOP.COURT_NAME_TEXT_BOX);
				courtNameInWorksheet = getAttribute(SOP.COURT_NAME_TEXT_BOX, "value");
			} catch (NoSuchElementException e) {
			}
			if (courtNameInWorksheet.equals("")) {
				courtNameInWorksheet = null;
			}
			String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
			compareStrings(courtNameInWorksheet, courtNameInCES);
			// TEXT_BOX_ATTORNEYNAME
			if (attorneyNoneAttribute == null) {
				waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME, "Attorney name text box in wroksheet step 2 page");
				assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME, "Attorney name text box in wroksheet step 2 page");
				String attorneyNameInWorksheet = getAttribute(SOP.TEXT_BOX_ATTORNEYNAME, "value");
				if (attorneyNameInWorksheet.equals("")) {
					attorneyNameInWorksheet = null;
				}
				String attorneyNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(0);
				compareStrings(attorneyNameInWorksheet, attorneyNameInCES);
			}
			if (courtNameInWorksheet == null) {
				waitForElementPresent(SOP.COURT_NONE_RADIOBTN, "court none radio button in wroksheet step 2 page");
				assertElementPresent(SOP.COURT_NONE_RADIOBTN, "court none radio button in wroksheet step 2 page");
				click(SOP.COURT_NONE_RADIOBTN, "court none radio button in wroksheet step 2 page");
			}
			if (!court.equals("")) {
				// RADIO_BUTTON_EXISTING_COURT
				waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,
						"existing court radio button in wroksheet step 2 page");
				assertElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,
						"existing court radio button in wroksheet step 2 page");
				click(SOP.RADIO_BUTTON_EXISTING_COURT, "existing court radio button in wroksheet step 2 page");
				// DROP_DOWN_COURT_NAME
				assertElementPresent(SOP.DROP_DOWN_COURT_NAME, "existing court drop down in wroksheet step 2 page");
				selectByIndex(SOP.DROP_DOWN_COURT_NAME, 1, "existing court drop down in wroksheet step 2 page");
				Thread.sleep(1000);
			}
			if (!attorney.equals("")) {
				// RADIO_BUTTON_EXISTING_ATTORNEYSENDER
				waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
						"existing Attorney radio button in wroksheet step 2 page");
				assertElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
						"existing Attorney radio button in wroksheet step 2 page");
				click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
						"existing Attorney radio button in wroksheet step 2 page");
				// DROP_DOWN_ATTORNEY_SENDER_NAME
				assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,
						"existing Attorney drop down in wroksheet step 2 page");
				selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1,
						"existing Attorney drop down in wroksheet step 2 page");
			}
			waitForElementPresent(SOP.NEXT_BTN, "next button in wroksheet step 2 page");
			assertElementPresent(SOP.NEXT_BTN, "next button in wroksheet step 2 page");
			click(SOP.NEXT_BTN, "next button in wroksheet step 2 page");

			WebElement docServed = null;
			try {
				docServed = driver.findElement(SOP.DOCUMENT_SERVED);
				if (docServed != null) {
					click(SOP.FIRST_DOCUMENT_SERVED, "document Type drop down  in wroksheet step 3 page");
					Thread.sleep(2000);
					// DOCUMENT_SERVED_MOVE_RIGHT
					assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT, "Move Right Arrow in wroksheet step 3 page");
					click(SOP.DOCUMENT_SERVED_MOVE_RIGHT, "Move Right Arrow in wroksheet step 3 page");
					Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
			}
			
			 * if(!lawSuitSubtype.equals("")){ //LAWSUITE_SUBTYPE
			 * assertElementPresent(WorksheetCreate.
			 * LAWSUITE_SUBTYPE,"law suit sub type in wroksheet step 3 page");
			 * selectByVisibleText(WorksheetCreate.LAWSUITE_SUBTYPE,
			 * lawSuitSubtype,"law suit sub type in wroksheet step 3 page"); }
			 

			WebElement specialCircumStances = null;
			try {
				specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);
				if (specialCircumStances != null) {
					selectByIndex(WorksheetCreate.SPECIAL_CIRCUMSTANCES, 1,
							" Special Cicumstances drop down  in wroksheet step 3 page");
					Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
			}
			
			 * else if(branchPlant.equals("NRAI")) {
			 * selectByVisibleText(SOP.DOCUMENT_SERVED,
			 * documentServed,"document Type drop down  in wroksheet step 3 page");
			 * //DOCUMENT_SERVED_MOVE_RIGHT assertElementPresent(SOP.
			 * DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
			 * click(SOP.
			 * DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page"); }
			 
			// ANSWER_DATE_NONE
			waitForElementPresent(WorksheetCreate.ANSWER_DATE_NONE, "Anser date radio button in wroksheet step 3 page");
			assertElementPresent(WorksheetCreate.ANSWER_DATE_NONE, "Anser date radio button in wroksheet step 3 page");
			click(WorksheetCreate.ANSWER_DATE_NONE, "Anser date radio button in wroksheet step 3 page");
			if (saveIncomplete.equalsIgnoreCase("Yes")) {
				// SAVE_INCOMPLETE_BUTTON
				waitForElementPresent(SOP.SAVE_INCOMPLETE_BUTTON, "Anser date radio button in wroksheet step 3 page");
				assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON, "Anser date radio button in wroksheet step 3 page");
				click(SOP.SAVE_INCOMPLETE_BUTTON, "Anser date radio button in wroksheet step 3 page");
			}
			// SAVE_BTN
			else if (saveIncomplete.equalsIgnoreCase("No")) {
				waitForElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
				assertElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
				click(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
				Thread.sleep(2000);
				// DOCUMENT_TYPE_DROPDWN
				// here one check for if doc type is not selected
				// Enter a value for Document Type.
				try {
					WebElement docNotSelected = null;
					docNotSelected = driver.findElement(WorksheetCreate.DOCUMENT_TYPE_NOT_SELECTED);
					if (docNotSelected != null) {
						selectByIndex(SOP.DOCUMENT_TYPE_DROPDWN, 3,
								"document Type drop down  in wroksheet step 3 page");
						waitForElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
						assertElementPresent(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
						click(Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
					}
				} catch (NoSuchElementException e) {

				}
			}
			// WORKSHEET_ID_ON_CONTEXT_BAR
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id created");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id created");
			// click(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
			worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id created");
			if (worksheetId.equals(null)) {
				throw new NullPointerException();
			}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		System.out.println("Worksheet id : " + worksheetId);
		Thread.sleep(3000);
		return worksheetId.split("\\: ")[1];
	}
*/
	public String viewAndCreateTheWorkSheetUsingESOPId(String reportSheet, int count,String esopId) throws Throwable{
		String worksheetId = null;
		try{				
		String defendentName = Excelobject.getCellData(reportSheet, "WS Defendent Name", count);
		String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
		String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);
		String attorney = Excelobject.getCellData(reportSheet, "WS Attorney", count);
		String court = Excelobject.getCellData(reportSheet, "WS Court", count);
		String documentServed = Excelobject.getCellData(reportSheet, "Document Served", count);
		String caseNum = Excelobject.getCellData(reportSheet, "WS Case Number", count);
		String plaintiff = Excelobject.getCellData(reportSheet, "WS Plaintiff", count);
		//below parameter is added as part of devOPs Sprint 7
		String bankruptcy = Excelobject.getCellData(reportSheet, "Bankruptcy", count);
		String consolidated = Excelobject.getCellData(reportSheet, "Consolidated", count);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
	    searchForESOP(esopId);		
		try {		 
			WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
			waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
		    searchForESOP(esopId);			
			
		}catch(NoSuchElementException e) {}
				
		for(int i=0 ;i<10; i++) {			
		String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
		if(isHandlerProcessed.equals("N")) {
		Thread.sleep(5000);
		}
		else {
			break;
		}		
		}
		selectAndAssignTheFileToTeam();
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		Thread.sleep(1000);
		searchForESOP(esopId);		
		
		String parentWindow= driver.getWindowHandle();		
		waitForElementPresent(SOP.VIEW_BTN, "View button");
		assertElementPresent(SOP.VIEW_BTN, "View button");		
		click(SOP.VIEW_BTN, "View button");		
		handlePopUpWindwow();
		driver.close();
		driver.switchTo().window(parentWindow);
		Thread.sleep(1000);
		WebElement createWs = null;
		try {
		createWs = driver.findElement(SOP.CREATE_WORKSHEET);
		waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		}catch(NoSuchElementException e) {			
		}
		if(createWs == null) {
			Thread.sleep(10000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(10000);
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
			Thread.sleep(2000);
			String parentWin= driver.getWindowHandle();		
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");		
			click(SOP.VIEW_BTN, "View button");		
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWin);
			waitForElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			assertElementPresent(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
		}

		//this needs to be commented as the below is creating ambiguity
/*		WebElement initalRadioButton = null;
		try {			
			
			initalRadioButton = driver.findElement(SOP.INITIAL_RADIOBTN);	
			
		}catch(NoSuchElementException e) {}
		if(initalRadioButton == null) {
			 click(SOP.CREATE_WORKSHEET,"Create Worksheet button");
			   Thread.sleep(2000);
		      driver.switchTo().frame("frame1");
		}*/
		
	    Thread.sleep(1000);
		driver.switchTo().frame("frame1");
		
		waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		
		if(isAttempted.equalsIgnoreCase("Yes")){
			//ATTEMPTED_YES_RADIO_BUTTON
			waitForElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
			assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");	
			click(SOP.ATTEMPTED_YES_RADIO_BUTTON,"Attempted Radio button");
		}
		if(workflowInWorksheet.equals("Full")){
		//INITIAL_RADIOBTN
		waitForElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");
		assertElementPresent(SOP.INITIAL_RADIOBTN,"Initial Radio button");	
		click(SOP.INITIAL_RADIOBTN,"Initial Radio button");
		}
		if(!caseNum.equals("")) {
		//CASEID_TEXTBOX
		waitForElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");
		assertElementPresent(SOP.CASEID_TEXTBOX,"Case Id text box");	
		type(SOP.CASEID_TEXTBOX,caseNum,"Case Id text box");
		}
		//Below check is added as part of Sprint 7 changes for bankruptcy radio button
		if(bankruptcy.equals("Yes")) {
	
			//BANKRUPTCY_RADIO_BUTTON_YES
			waitForElementPresent(WorksheetCreate.BANKRUPTCY_RADIO_BUTTON_YES,"Bankruptcy radio button for Yes");
			assertElementPresent(WorksheetCreate.BANKRUPTCY_RADIO_BUTTON_YES,"Bankruptcy radio button for Yes");
			click(WorksheetCreate.BANKRUPTCY_RADIO_BUTTON_YES,"Click on Bankruptcy radio button for Yes");
			
		}
		if(consolidated.equals("Yes")) {
			
			waitForElementPresent(WorksheetCreate.CONSOLIDATED_RADIO_BUTTON_YES,"Consolidated radio button for Yes");
			assertElementPresent(WorksheetCreate.CONSOLIDATED_RADIO_BUTTON_YES,"Consolidated radio button for Yes");
			click(WorksheetCreate.CONSOLIDATED_RADIO_BUTTON_YES,"Click on Consolidated radio button for Yes");
			Thread.sleep(1000);
			/*//CONSOLIDATED_DEFENDANT_TEXTBOX
			waitForElementToBePresent(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX,"Consolidated defendant text box");
			assertElementPresent(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX,"Consolidated defendant text box");
			type(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX,"Sel-Automated dft in consolidated","Consolidated defendant text box");
			//CONSOLIDATED_PLAINTIFF_TEXTBOX
			waitForElementPresent(SOP.CONSOLIDATED_PLAINTIFF_TEXTBOX,"Consolidated plaintiff text box");
			assertElementPresent(SOP.CONSOLIDATED_PLAINTIFF_TEXTBOX,"Consolidated plaintiff text box");
			type(SOP.CONSOLIDATED_PLAINTIFF_TEXTBOX,"Sel-Automated pltf in consolidated","Consolidated plaintiff text box");*/									
		}
		
		/*if (!plaintiff.equals("") && consolidated.equals("No")) {
		//PLAINTIFF_TEXT_BOX
		waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plaintiff text box");
		assertElementPresent(SOP.PLAINTIFF_TEXT_BOX,"Plantiff text box");	
		type(SOP.PLAINTIFF_TEXT_BOX,plaintiff,"Plantiff text box");
		}
		if(!defendentName.equals("") && consolidated.equals("No")) {
		//DEFENDANT_TEXTFIELD
		waitForElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");	
		assertElementPresent(SOP.DEFENDANT_TEXTFIELD,"Defendent text box");
		type(SOP.DEFENDANT_TEXTFIELD,defendentName,"Defendent text box");
		}
*/
		//Here one function will webelement needs to be added as part of CIOX change that will expand the glyphicon icon
		//$x("//tr[@id='trReceivedBy']//following-sibling::td//span[@class='glyphicon glyphicon-triangle-right']")
		//RECEIVED_BY_GLYPHICON_WORKSHEET
		waitForElementPresent(WorksheetCreate.RECEIVED_BY_GLYPHICON_WORKSHEET,"glyphicon icon during worksheet creation");
		assertElementPresent(WorksheetCreate.RECEIVED_BY_GLYPHICON_WORKSHEET,"glyphicon icon during worksheet creation");
		click(WorksheetCreate.RECEIVED_BY_GLYPHICON_WORKSHEET,"glyphicon icon during worksheet creation");
		//EDIT_RECEIVED_BY
		waitForElementPresent(WorksheetCreate.EDIT_RECEIVED_BY,"Received By drop downs in create wroksheet page");
		assertElementPresent(WorksheetCreate.EDIT_RECEIVED_BY,"Received By drop downs in create wroksheet page");
		selectByIndex(WorksheetCreate.EDIT_RECEIVED_BY,1,"Received By drop downs in create wroksheet page");
		//WORKSHEET_TYPE
		waitForElementPresent(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in create wroksheet page");
		String worksheetType = getText(WorksheetCreate.WORKSHEET_TYPE,"worksheet type in create wroksheet page");
		//ENTITY_IN_WORKSHEET_PROFILE
		waitForElementPresent(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"Entity in wroksheet profile step 1 page");
		String entityInWorksheet = getAttribute(WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,"value");
		
		//Removing below Next btn functionality	
		Thread.sleep(1200);
					
		
		//COURT_NAME_TEXT_BOX
		String attorneyNoneAttribute = "";
		String courtNameInWorksheet = "";

		try {
			attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");  
		}catch (NoSuchElementException e) {}
		try {	
			driver.findElement(SOP.EXISTING_COURTNAME);
			courtNameInWorksheet = getText(SOP.TEXT_BOX_COURTNAME,"value");
		}catch (NoSuchElementException e) {} 
		try {
			driver.findElement(SOP.COURT_NAME_TEXT_BOX);
			courtNameInWorksheet = getAttribute(SOP.COURT_NAME_TEXT_BOX,"value");
		}catch (NoSuchElementException e) {}
			if (courtNameInWorksheet.equals("")) {
				courtNameInWorksheet = null;				
			}			
			String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);		
			compareStrings(courtNameInWorksheet,courtNameInCES);
		//TEXT_BOX_ATTORNEYNAME
		if(attorneyNoneAttribute == null) {
		waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in create wroksheet page");
		assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Attorney name text box in create wroksheet page");	
		String attorneyNameInWorksheet = getAttribute(SOP.TEXT_BOX_ATTORNEYNAME,"value");
		if(attorneyNameInWorksheet.equals("")) {
			attorneyNameInWorksheet = null;
		}		
		String attorneyNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(0);
		compareStrings(attorneyNameInWorksheet,attorneyNameInCES);
		}
		if(courtNameInWorksheet == null) {
		waitForElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in create wroksheet page");
		assertElementPresent(SOP.COURT_NONE_RADIOBTN,"court none radio button in create wroksheet page");
		click(SOP.COURT_NONE_RADIOBTN,"court none radio button in create wroksheet page");
		}
		if(!court.equals("")) {
							
		//USE_THIS_COURT
		waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
		assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
		click(SOP.USE_THIS_COURT,"Use this court radio button");
		//COURT_NAME_TEXT_BOX
		waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
		assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
		type(SOP.COURT_NAME_TEXT_BOX,court,"Court NAme");
		//ADDRESS_LINE_ONE
		waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
		assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
		type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
		//CITY_NAME
		waitForElementPresent(SOP.CITY_NAME,"City Name text box");
		assertElementPresent(SOP.CITY_NAME,"City Name text box");
		type(SOP.CITY_NAME,"Houston","City Name text box");
		//STATE_NAME
		waitForElementPresent(SOP.STATE_NAME,"State Name text box");
		assertElementPresent(SOP.STATE_NAME,"State Name text box");
		type(SOP.STATE_NAME,"TX","State Name text box");
		//ZIP_CODE
		waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
		assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
		type(SOP.ZIP_CODE,"77550","Zip code text box");

		Thread.sleep(1000);
		}
		if(!attorney.equals("")) {
			//USE_THIS_ATTORNEY
			waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
			assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
			click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
									
			//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
							type(SOP.TEXT_BOX_ATTORNEYNAME,"Alan H. Weinreb","Text box to enter attorney name");
							
							//ATTORNEY_ADDRESS_LINE_ONE
						    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
						    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
							
							//CITY_NAME
							waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
							type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
							
							//ATTORNEY_STATE_NAME
							waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
							type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
							
							//ATTORNEY_ZIP_CODE
							waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
							type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");
		}

		WebElement specialCircumStances = null;
		try {
			specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);					
				if (specialCircumStances != null) {
						selectByIndex(WorksheetCreate.SPECIAL_CIRCUMSTANCES,1," Special Cicumstances drop down  in create wroksheet page");
					    Thread.sleep(2000);
					}
				} catch (NoSuchElementException e) {
			}						
		/*else if(branchPlant.equals("NRAI")) {
			selectByVisibleText(SOP.DOCUMENT_SERVED,documentServed,"document Type drop down  in create wroksheet page");
			//DOCUMENT_SERVED_MOVE_RIGHT
			assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in create wroksheet page");
			click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in create wroksheet page");
		}*/
		//ANSWER_DATE_NONE
		waitForElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in create wroksheet page");
		assertElementPresent(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in create wroksheet page");	
		click(WorksheetCreate.ANSWER_DATE_NONE,"Anser date radio button in create wroksheet page");
		if(saveIncomplete.equalsIgnoreCase("Yes")){
			//SAVE_INCOMPLETE_BUTTON
			waitForElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in create wroksheet page");
			assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in create wroksheet page");	
			click(SOP.SAVE_INCOMPLETE_BUTTON,"Anser date radio button in create wroksheet page");
		}
		//SAVE_BTN
		else if(saveIncomplete.equalsIgnoreCase("No")){		
		waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		assertElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		click(Entity.SAVE_BTN, "Save button in create wroksheet page");
		Thread.sleep(2000);
		//DOCUMENT_TYPE_DROPDWN
		//here one check for if doc type is not selected	
		//Enter a value for Document Type.
	try {
	 WebElement docNotSelected = null;	
	 docNotSelected = driver.findElement(WorksheetCreate.DOCUMENT_TYPE_NOT_SELECTED);
	 if(docNotSelected != null) {	
		//commented below code on 6/3/21 to enter the document type values
		 //selectByIndex(SOP.DOCUMENT_TYPE_DROPDWN,3,"document Type drop down  in create wroksheet page");
		// DOCUMENT_TYPE_TEXTFIELD
	    //added below code on 6/3/21 to enter the document type values
		 type(SOP.DOCUMENT_TYPE_TEXTFIELD,"Document Type value entered in Selenium Automation","Document Type text box");
		 waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		 assertElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		 click(Entity.SAVE_BTN, "Save button in create wroksheet page");
	 }
	}
	 catch (NoSuchElementException e) {}
		}
		
		//below all errors are validated after click on Save
		
		
		//below check for if error- > 'Enter a value for Other Mehod of Serivce.		
		try {
		 
			driver.findElement(SOP.OTHER_METHOD_OF_SERVICE);
			type(SOP.OTHER_METHOD_OF_SERVICE_TEXT_BOX,"Other", "Type the Text for other Method of Service");
			waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			click(Entity.SAVE_BTN, "Save button in create wroksheet page");
			//click(SOP.NEXT_BTN,"next button in create wroksheet page");	
			Thread.sleep(700);
		}catch (NoSuchElementException e) {}	

		//below check for if error- > 'Select a Post Marked reason.'
		
		try {
		driver .findElement(SOP.POST_MARKED_REASON_ERROR);
		waitForElementPresent(WorksheetCreate.POST_MARKED_REASON,"Post Marked Reason");
		selectByVisibleText(WorksheetCreate.POST_MARKED_REASON,"Not Post Marked","Post Marked Reason");
		waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		click(Entity.SAVE_BTN, "Save button in create wroksheet page");
		Thread.sleep(700);
		}catch(NoSuchElementException e) {}
		
		//below check for if error -> Enter a value for Post Marked date in mm/dd/yyyy format.

		try {
		driver.findElement(WorksheetCreate.POST_MARKED_DATE_ERROR);
		waitForElementPresent(WorksheetCreate.POST_MARKED_DATE,"Post Marked Date Text box");		
			int currentYear = Integer.valueOf(getCurrentDate().split("\\/")[2]); 
			String date = "01"+"/" + "01"+"/" + String.valueOf(currentYear); 			
			type(WorksheetCreate.POST_MARKED_DATE,date,"Post marked Date text box");
			waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			click(Entity.SAVE_BTN, "Save button in create wroksheet page");
			Thread.sleep(700);
		}catch(NoSuchElementException e) {}
		//below check for if Error -> Enter a valid value for Case#.
		try {
			//Below code is modified on 12/23 
			driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
			Thread.sleep(1000);
			boolean caseTextPsNum = false;
			//Below try block is added as some method of srvice has different way of SElecting the CASe# in worksheet page 1
			  try {				
					driver.findElement(SOP.CASE_TEXT_PS_CASENUM);
					Thread.sleep(500);
					type(SOP.CASE_TEXT_PS_CASENUM,"CNInWorksheet", "Type the Text for the Case#");
					//Below save button functionality needs to be added after removing click next functionality
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			        click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					caseTextPsNum = true;
				}catch(NoSuchElementException e) {}
				
					if(caseTextPsNum == false) {
					Thread.sleep(2000);
					type(SOP.CASE_TEXT_PS_CASENUM,"CNInWorksheet", "Type the Text for the Case#");
					//Below save button functionality needs to be added after removing click next functionality
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			        click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					Thread.sleep(700);
					}
				}catch (NoSuchElementException e) {}
				
			  //This try block is added on 12/23 to validate and enter the blank case number during worksheet creation if not filled during CES
				try {
					driver.findElement(SOP.CASE_NUMBER_BLANK);
					Thread.sleep(2000);
					type(WorksheetCreate.CASE_TEXT,"CNInWorksheet", "Type the Text for the Case#");
					//Below save button functionality needs to be added after removing click next functionality
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			        click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					Thread.sleep(700);
				}catch (NoSuchElementException e) {}	

     if(workflowInWorksheet.equals("Full")){ 
    	    WebElement docServed = null;
			try {
					docServed = driver.findElement(SOP.DOCUMENT_SERVED);					
					if (docServed != null) {
						waitForElementPresent(SOP.FIRST_DOCUMENT_SERVED,"document Type drop down  in wroksheet step 3 page");
						click(SOP.FIRST_DOCUMENT_SERVED,"document Type drop down  in wroksheet step 3 page");
						Thread.sleep(2000);
						//DOCUMENT_SERVED_MOVE_RIGHT
						assertElementPresent(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in create wroksheet page");
						click(SOP.DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
						waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
			            click(Entity.SAVE_BTN, "Save button in create wroksheet page");
					    Thread.sleep(2000);
					}
				} catch (NoSuchElementException e) {}	
     }
		
			//OTHER_DOC_SERVED_WORKSHEET
			WebElement otherDocServed = null;
			try {
				otherDocServed = driver.findElement(WorksheetCreate.ENTER_VALUE_FOR_OTHER_MESSAGE);
				if (otherDocServed != null) {
					waitForElementPresent(WorksheetCreate.OTHER_DOC_SERVED_WORKSHEET,"Other doc served text box in create worksheet page");
					assertElementPresent(WorksheetCreate.OTHER_DOC_SERVED_WORKSHEET,"Assert Other doc served text box in create worksheet page");
					type(WorksheetCreate.OTHER_DOC_SERVED_WORKSHEET,"Other Doc served entered with Selecnium automation","Enter Other doc served text box in create worksheet page");
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		            click(Entity.SAVE_BTN, "Save button in create wroksheet page");
				}
				
			} catch (NoSuchElementException e) {}
			
		//ENTER_VALUE_CONSOLIDATED_DEFENDANT
			WebElement consolidatedDefendant = null;
			try {
				consolidatedDefendant = driver.findElement(WorksheetCreate.ENTER_VALUE_CONSOLIDATED_DEFENDANT);
				if (consolidatedDefendant != null) {					
					waitForElementToBePresent(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX,"Consolidated defendant text box");
					assertElementPresent(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX,"Consolidated defendant text box");
					type(SOP.CONSOLIDATED_DEFENDANT_TEXTBOX,"Sel-Automated dft in consolidated","Consolidated defendant text box");
					waitForElementPresent(Entity.SAVE_BTN, "Save button in create wroksheet page");
		            click(Entity.SAVE_BTN, "Save button in create wroksheet page");
				}
				
			} catch (NoSuchElementException e) {}
			
			
		//WORKSHEET_ID_ON_CONTEXT_BAR
		waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
		assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");	
		//click(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
		worksheetId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
		if(worksheetId.equals(null)){
			throw new NullPointerException();
		}
		}catch(NullPointerException e){
			e.printStackTrace();
		}
		System.out.println("Worksheet id : " + worksheetId);
		Thread.sleep(3000);
		
		return worksheetId.split("\\: ")[1];
	}

	public void manageActionItemPSOPAndExecuteCentralized(String reportSheet, int count) throws Throwable {

		String deliverable = Excelobject.getCellData(reportSheet, "Deliverable", count);
		String deliveryMethod = Excelobject.getCellData(reportSheet, "Delivery Method", count);
		String participant = Excelobject.getCellData(reportSheet, "Participant Name", count);
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
		String rejectedReason = Excelobject.getCellData(reportSheet, "Rejected Reason", count);
		String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);

		if (isAttempted.equals("No") && rejectedReason.equals("") && saveIncomplete.equals("No")) {
			// CHOOSE_DI_BTN
			assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
			click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// ACTIONS_LIST_BTN
			assertElementPresent(SOP.ACTIONS_LIST_BTN, "Action List Button");
			click(SOP.ACTIONS_LIST_BTN, "Action List Button");
			if (branchPlant.equals("CTCORP")) {
				// MANAGE_ACTIONS_ITEM_BTN
				assertElementPresent(SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage action item Button");
				click(SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage action item Button");
				// DELIVERABLE
				assertElementPresent(SOP.DELIVERABLE, "Deliverable drop down element");
				click(SOP.DELIVERABLE, "Deliverable drop down element");
				selectByVisibleText(SOP.DELIVERABLE, deliverable, "Deliverable drop down element");
				// DELIVERY_METHOD
				assertElementPresent(SOP.DELIVERY_METHOD, "Delivery drop down element");
				click(SOP.DELIVERY_METHOD, "Delivery drop down element");
				selectByVisibleText(SOP.DELIVERY_METHOD, deliveryMethod, "Delivery drop down element");
				// EXISTING_RECIPIENT
				assertElementPresent(SOP.EXISTING_RECIPIENT, "existing recipient element");
				click(SOP.EXISTING_RECIPIENT, "existing recipient element");
				// RECIPIENT_SELECT_BTN
				assertElementPresent(SOP.RECIPIENT_SELECT_BTN, "Recipient select Button");
				click(SOP.RECIPIENT_SELECT_BTN, "Recipient select Button");
				// PARTICIPANTNAMEFIELD
				assertElementPresent(SOP.PARTICIPANTNAMEFIELD, "Participant search text box");
				selectBySendkeys(SOP.PARTICIPANTNAMEFIELD, participant, "Participant search text box");
				// FINDBTN
				assertElementPresent(SOP.FINDBTN, "Find Button");
				click(SOP.FINDBTN, "Find Button");
				// PARTICIPANT_NAME
				assertElementPresent(SOP.PARTICIPANT_NAME, "Participant name element");
				int index = returnIndexOfMatchedTextvalue(SOP.PARTICIPANT_NAME, participant);
				assertElementPresent(SOP.SELECT_BUTTON_SELECT_RECIPIENT, "Select Button in Grid");
				clickOnAParticularIndexOfAnElement(SOP.SELECT_BUTTON_SELECT_RECIPIENT, "Select button in Grid", index);
				// ADDUPDATE_BTN
				assertElementPresent(SOP.ADDUPDATE_BTN, "Recipient select Button");
				click(SOP.ADDUPDATE_BTN, "Recipient select Button");
				// ACTIONS_LIST_BTN
				assertElementPresent(SOP.ACTIONS_LIST_BTN, "Action List Button");
				click(SOP.ACTIONS_LIST_BTN, "Action List Button");
				// EXECUTE_CENTRALIZED
				assertElementPresent(SOP.EXECUTE_CENTRALIZED, "Execute Centralized Button");
			}
			isEnabled(SOP.EXECUTE_CENTRALIZED, "Execute Centralized Button");
			click(SOP.EXECUTE_CENTRALIZED, "Execute Centralized Button");
		} else {
			// CHOOSE_DI_BTN
			assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button in worksheet Profile Page");
			isDisabled(SOP.CHOOSE_DI_BTN, "Choose DI Button in Worksheet Profile Page");
		}
	}

	/*
	 * public void updateTheXML(String fileSourcePath , String valueToUpdate, String
	 * powershellFilePath){ String command = "powershell.exe -file "+
	 * powershellFilePath + " "+ fileSourcePath +" " + valueToUpdate; // in above +
	 * " " + hardCopy //"C:\\Users\\M1052416\\Desktop\\changeSOPXML.ps1 "+ arg1 +" "
	 * + arg2; //C:\\Users\\M1052416\\Desktop\\TestDataNoHardCopy19.XML 2/27/2020";
	 * getTheCommandToRunThePowerShell(command);
	 * 
	 * }
	 */
	public void updateTheXML(String fileSourcePath, String date, String hardCopy, String powershellFilePath) {

		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " " + date + " "
				+ hardCopy;
		getTheCommandToRunThePowerShell(command);

	}

	public void copyTheFile(String fileSourcePath, String fileDestinationPath, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " "
				+ fileDestinationPath;
		// "C:\\Users\\M1052416\\Desktop\\fileCopy.ps1
		// C:\\Users\\M1052416\\workspace\\ArrowNPD\\TestData\\TestDataNoHardCopy.XML
		// C:\\Users\\M1052416\\Desktop";
		getTheCommandToRunThePowerShell(command);
	}

	public void deleteTheFile(String fileSourcePath, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath;
		// "C:\\Users\\M1052416\\Desktop\\fileCopy.ps1
		// C:\\Users\\M1052416\\workspace\\ArrowNPD\\TestData\\TestDataNoHardCopy.XML
		// C:\\Users\\M1052416\\Desktop";
		getTheCommandToRunThePowerShell(command);
	}

	public void uploadTheFiles(String fileSourcePath, String fileDestinationPath, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " "
				+ fileDestinationPath;
		// C:\\Users\\M1052416\\Desktop\\fileupload.ps1
		// C:\\Users\\M1052416\\Desktop\\TestScanner.XML
		// \\\\nastnri95001.na.wkglobal.com\\SopPassInterim\\PTRP\\TemporaryIsopImages\\AutoUploadSource\\ScanFirst\\ScanFirst";
		getTheCommandToRunThePowerShell(command);
	}

	public void renameTheFiles(String fileSourcePath, String fileRename, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " " + fileRename;
		// C:\\Users\\M1052416\\Desktop\\fileRename.ps1
		// C:\\Users\\M1052416\\Desktop\\TestScanner.XML"+ " TestScanner"+1+".XML";
		getTheCommandToRunThePowerShell(command);
		/*
		 * if(i == 1){ command2 =
		 * "powershell.exe -file C:\\Users\\M1052416\\Desktop\\fileRename.ps1 C:\\Users\\M1052416\\Desktop\\TestScanner.XML"
		 * + " TestScanner"+i+".XML"; } else if(i!=1) { int presentFile = i - 1;
		 * command2 =
		 * "powershell.exe -file C:\\Users\\M1052416\\Desktop\\fileRename.ps1 C:\\Users\\M1052416\\Desktop\\TestScanner"
		 * +presentFile+".XML"+ " TestScanner"+i+".XML"; }
		 */
	}

	public void getTheCommandToRunThePowerShell(String command) {
		try {
			Process powerShellProcess = Runtime.getRuntime().exec(command);
			powerShellProcess.getOutputStream().close();
			String line;
			BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
			while ((line = stdout.readLine()) != null) {
				System.out.println(line);
			}
			stdout.close();
			BufferedReader stderr = new BufferedReader(new InputStreamReader(powerShellProcess.getErrorStream()));
			while ((line = stderr.readLine()) != null) {
				System.out.println(line);
			}
			stderr.close();
			System.out.println("Done");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void psopInvoicesList(String reportSheet, int count, String profile) throws Throwable {
		String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
		String entityId = Excelobject.getCellData(reportSheet, "Entity Id", count);
		String affiliationName = Excelobject.getCellData(reportSheet, "Affiliation Name", count);
		String affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		// PSOP_INVOICES_LEFT_NAV_BAR
		waitForElementPresent(Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
		assertElementPresent(Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
		click(Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
		// PSOP_INVOICES_PROFILE_LEFT_NAV_BAR
		assertElementPresent(Entity.PSOP_INVOICES_PROFILE_LEFT_NAV_BAR, "Psop Invoices profile link");
		// PSOP_INVOICES_CONTEXTTILE
		if (profile.equalsIgnoreCase("Standalone Entity")) {
			assertElementPresent(Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices conetxt");
			compareStrings(entityName, getText(Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices context"));
			// ENTITY_ID_ON_ENTITY_PROFILE
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page");
			compareStrings(entityId, getText(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page").split("\\: ")[1]);
		} else if (profile.equalsIgnoreCase("Affiliation")) {
			// PSOP_INVOICES_CONTEXTTILE
			assertElementPresent(Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices conetxt");
			compareStrings(affiliationName, getText(Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices context"));
			// ENTITY_ID_ON_ENTITY_PROFILE
			assertElementPresent(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page");
			compareStrings(affiliationId,
					getText(Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page").split("\\: ")[1]);
		}

		// PAGE_TITLE
		assertElementPresent(Entity.PAGE_TITLE, "Page Title");
		compareStrings("PSOP Invoices", getText(Entity.PAGE_TITLE, "Page Title"));
		// PSOP_INVOICES_DROP_DOWN
		assertElementPresent(Entity.PSOP_INVOICES_DROP_DOWN, "Psop Invoices drop down");
		// PSOP_INVOICES_IS
		assertElementPresent(Entity.PSOP_INVOICES_IS, "Psop Invoices is text");
		// PSOP_INVOICES_TEXT_SEARCH
		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Psop Invoices text box");
		// PSOP_INVOICES_HELP_ICON
		assertElementPresent(Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		String parentWindow = driver.getWindowHandle();
		isEnabled(Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		click(Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		handlePopUpWindwow();
		driver.close();
		driver.switchTo().window(parentWindow);
		// GO_BTN
		assertElementPresent(Entity.GO_BTN, "Psop Invoices Go Button");
		isEnabled(Entity.GO_BTN, "Psop Invoices Go Button");
		// PSOP_INVOICES_SORT_BY
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY, "Psop Invoices Sort by");
		// PSOP_INVOICES_SORT_BY_INDEX
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		// PSOP_INVOICES_SORT_BY_OW_ORDER
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		// PSOP_INVOICES_SORT_BY_PRINT_DATE
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		// PSOP_INVOICES_SORT_BY_INVOICE_DATE
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		// PSOP_INVOICES_SORT_BY_INVOICE_AMOUNT
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		// PSOP_INVOICES_SORT_BY_OPEN_AMOUNT
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		// PSOP_INVOICES_GRID_HEADER_INVOICE
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_INVOICE, "Psop Invoices Grid header invoice");
		compareStrings("Invoice #", //
				getText(Entity.PSOP_INVOICES_GRID_HEADER_INVOICE, "Psop Invoices Grid header invoice"));
		// PSOP_INVOICES_GRID_HEADER_OW_ORDER
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_OW_ORDER, "Psop Invoices Grid header ow order");
		compareStrings("OW Order #",
				getText(Entity.PSOP_INVOICES_GRID_HEADER_OW_ORDER, "Psop Invoices Grid header ow order"));
		// PSOP_INVOICES_GRID_HEADER_PRINT_DATE
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_PRINT_DATE, "Psop Invoices Grid header Print Date");
		compareStrings("Print Date",
				getText(Entity.PSOP_INVOICES_GRID_HEADER_PRINT_DATE, "Psop Invoices Grid header Print Date"));
		// PSOP_INVOICES_GRID_HEADER_INVOICE_DATE
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_INVOICE_DATE, "Psop Invoices Grid header Invoice Date");
		compareStrings("Invoice Date",
				getText(Entity.PSOP_INVOICES_GRID_HEADER_INVOICE_DATE, "Psop Invoices Grid header Invoice Date"));
		// PSOP_INVOICES_GRID_HEADER_INV_AMOUNT
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_INV_AMOUNT, "Psop Invoices Grid header Invoice Amount");
		compareStrings("Inv. Amount",
				getText(Entity.PSOP_INVOICES_GRID_HEADER_INV_AMOUNT, "Psop Invoices Grid header Invoice Amount"));
		// PSOP_INVOICES_GRID_HEADER_PSOP_COUNT
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_PSOP_COUNT, "Psop Invoices Grid header PSOP Count");
		compareStrings("PSOP Count",
				getText(Entity.PSOP_INVOICES_GRID_HEADER_PSOP_COUNT, "Psop Invoices Grid header PSOP count"));
		// PSOP_INVOICES_GRID_HEADER_ACTION
		assertElementPresent(Entity.PSOP_INVOICES_GRID_HEADER_ACTION, "Psop Invoices Grid header Action");
		compareStrings("Action", getText(Entity.PSOP_INVOICES_GRID_HEADER_ACTION, "Psop Invoices Grid header Action"));
		// PSOP_INVOICES_CURRENT_FILTER
		assertElementPresent(Entity.PSOP_INVOICES_CURRENT_FILTER, "Psop Invoices Grid header current filter");
		compareStrings("Current filter:",
				getText(Entity.PSOP_INVOICES_CURRENT_FILTER, "Psop Invoices Grid header current filter"));
		assertElementPresent(Entity.FIRST_PAGE_LINK, "First Page Lnk");
		assertElementPresent(Entity.PREVIOUS_PAGE_LINK, "Previous Page Lnk");
		assertElementPresent(Entity.NEXT_PAGE_LINK, "Next Page Lnk");
		assertElementPresent(Entity.LAST_PAGE_LINK, "Last Page Lnk");

	}

	public void psopInvoiceSearch(String reportSheet, int count) throws Throwable {

		try {

			String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
			String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
			String entityType = Excelobject.getCellData(reportSheet, "Entity Type", count);
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId, "Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			// PSOP_INVOICE_SEARCH_HEADER
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search header");
			compareStrings("Invoice Profile",
					getText(Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search header"));
			// INVOICE_ID
			assertElementPresent(Invoice.INVOICE_ID, "Invoice id");
			compareStrings(invoiceId, getText(Invoice.INVOICE_ID, "Invoice id").split("\\: ")[1]);
			// PSOP_INVOICE_SEARCH_CRITERIA
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
			compareStrings("PSOP Invoice Profile",
					getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title"));
			// GENERATE_DETAIL_REPORT_BUTTON
			assertElementPresent(Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			isEnabled(Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			// PRINT_BUTTON
			assertElementPresent(Invoice.PRINT_BUTTON, "Print Button");
			isEnabled(Invoice.PRINT_BUTTON, "Print Button");
			// INVOICE_DATA_LABEL
			waitForElementPresent(Invoice.INVOICE_DATA_LABEL, "Invoice data label");
			assertElementPresent(Invoice.INVOICE_DATA_LABEL, "Invoice data label");
			// INVOICE_DATA_TEXT
			assertElementPresent(Invoice.INVOICE_DATA_TEXT, "Invoice data text");
			compareStrings(invoiceId, getText(Invoice.INVOICE_DATA_TEXT, "Invoice data text"));
			// ENTITY_DATA_LABEL
			assertElementPresent(Invoice.ENTITY_DATA_LABEL, "Entity data label");
			// ENTITY_LINK_TEXT
			compareStrings(entityName, getText(Invoice.ENTITY_LINK_TEXT, "Entity link text"));
			// OW_ORDER_DATA_LABEL
			assertElementPresent(Invoice.OW_ORDER_DATA_LABEL, "OW order data label");
			// INVOICE_STATUS_LABEL
			assertElementPresent(Invoice.INVOICE_STATUS_LABEL, "Invoice status label");
			// RECIPIENT_LABEL
			assertElementPresent(Invoice.RECIPIENT_LABEL, "Recipient label");
			// TITLE_LABEL
			assertElementPresent(Invoice.TITLE_LABEL, "TITLE label");
			assertElementPresent(Invoice.CUSTOMER_LABEL, "Customer label");
			assertElementPresent(Invoice.ADDRESS_LABEL, "Address label");
			assertElementPresent(Invoice.PHONE_LABEL, "Phone label");
			assertElementPresent(Invoice.FAX_LABEL, "Fax label");
			assertElementPresent(Invoice.PERIOD_COVERED_LABEL, "Period covered label");
			assertElementPresent(Invoice.RENEWAL_MONTH_LABEL, "Renewal month label");
			assertElementPresent(Invoice.INVOICE_SUMMARY_SECTION, "Invoice summary section");
			assertElementPresent(Invoice.TOTAL_PAPER_SOP_LABEL, "Toatl Paper SOP label");
			assertElementPresent(Invoice.PSOP_AMOUNT_LABEL, "Psop Amount label");
			assertElementPresent(Invoice.OPEN_AMOUNT_LABEL, "Open amount label");
			assertElementPresent(Invoice.PREVIOUS_INVOICE_LABEL, "Previous invoice label");
			assertElementPresent(Invoice.PREVIOUS_BILLED_LABEL, "Previous billed label");
			assertElementPresent(Invoice.INVOICE_CONTENT_SECTION, "Invoice Content section");
			assertElementPresent(Invoice.EXPORT_BUTTON, "export button");
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "drop down under invoice content");
			assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Text Box for search");
			assertElementPresent(Invoice.GO_BUTTON, "Go Button");
			isEnabled(Invoice.GO_BUTTON, "Go Button");
			assertElementPresent(Invoice.SORT_BY_LABEL, "Sort By label");
			assertElementPresent(Invoice.SORT_BY_LABEL_ENTITY_NAME, "Entity name sort by label");
			assertElementPresent(Invoice.SORT_BY_LABEL_ENTITY_NUMBER, "Entity number sort by label");
			assertElementPresent(Invoice.SORT_BY_LABEL_JURIS, "Juris label");
			assertElementPresent(Invoice.SORT_BY_LABEL_SOP_COUNT, "SOP count label");
			if (entityType.equals("CTCORP")) {
				assertElementPresent(Invoice.SORT_BY_LABEL_SUIT_TYPE, "Suit type label");
				assertElementPresent(Invoice.SORT_BY_LABEL_SUIT_SUB_TYPE, "Suit Sub type label");
			}
			if (entityType.equals("NRAI")) {
				assertElementPresent(Invoice.NRAI_DOC_TYPE_COLUMN_NAME, "NRAI Doc Type column");
			}
			assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
			assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
			assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
			assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
			assertElementPresent(Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
			assertElementPresent(Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
			assertElementPresent(Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
			assertElementPresent(Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
			assertElementPresent(Invoice.BACK_BUTTON, "Back button");
			assertElementPresent(Invoice.REVISE_BUTTON, "Revise button");
			assertElementPresent(Invoice.RECIPIENT_NAME, "Recipient name");
			String recipientNamePSOPInvoiceProfile = getText(Invoice.RECIPIENT_NAME, "Recipient name");
			assertElementPresent(Invoice.PARTICIPANT_TITLE, "Participant title");
			String titlePSOPInvoiceProfile = getText(Invoice.PARTICIPANT_TITLE, "Participant title");
			assertElementPresent(Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			String recipientCustomerPSOPInvoiceProfile = getText(Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			assertElementPresent(Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			String recipientAddressPSOPInvoiceProfile = getText(Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			assertElementPresent(Invoice.RECIPIENT_EMAIL, "Recipient Email");
			String recipientEmailPSOPInvoiceProfile = getText(Invoice.RECIPIENT_EMAIL, "Recipient Email");
			assertElementPresent(Invoice.RECIPIENT_PHONE, "Recipient Phone");
			String recipientPhonePSOPInvoiceProfile = getText(Invoice.RECIPIENT_PHONE, "Recipient Phone");
			assertElementPresent(Invoice.RECIPIENT_FAX, "Recipient Fax");
			String recipientFaxPSOPInvoiceProfile = getText(Invoice.RECIPIENT_FAX, "Recipient Fax");
			searchForTheEntity(reportSheet, count);
			// DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE
			assertElementPresent(DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			click(DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			// XSOP_RECIPIENT_NAME
			focus(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			assertElementPresent(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			String recipientNameXSOP = getText(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			// PARTICIPANT_TITLE
			assertElementPresent(DI.PARTICIPANT_TITLE, "Participant title xsop");
			String titleXSOP = getText(DI.PARTICIPANT_TITLE, "Participant title xsop");
			// RECIPIENT_CUSTOMER
			assertElementPresent(DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			String recipientCustomerXSOP = getText(DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			// RECIPIENT_ADDRESS
			assertElementPresent(DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			String recipientAddressXSOP = getText(DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			// RECIPIENT_EMAIL
			assertElementPresent(DI.RECIPIENT_EMAIL, "Recepient email xsop");
			String recipientEmailXSOP = getText(DI.RECIPIENT_EMAIL, "Recepient email xsop");
			// RECIPIENT_PHONE
			assertElementPresent(DI.RECIPIENT_PHONE, "Recepient phone xsop");
			String recipientPhoneXSOP = getText(DI.RECIPIENT_PHONE, "Recepient phone xsop");
			// RECIPIENT_FAX
			assertElementPresent(DI.RECIPIENT_FAX, "Recepient fax xsop");
			String recipientFaxXSOP = getText(DI.RECIPIENT_FAX, "Recepient fax xsop");
			compareStrings(recipientNamePSOPInvoiceProfile, recipientNameXSOP);
			compareStrings(titlePSOPInvoiceProfile, titleXSOP);
			compareStrings(recipientCustomerPSOPInvoiceProfile, recipientCustomerXSOP);
			compareStrings(recipientAddressPSOPInvoiceProfile, recipientAddressXSOP);
			compareStrings(recipientEmailPSOPInvoiceProfile, recipientEmailXSOP);
			compareStrings(recipientPhonePSOPInvoiceProfile, recipientPhoneXSOP);
			compareStrings(recipientFaxPSOPInvoiceProfile, recipientFaxXSOP);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void psopInvoiceSearchCriteriaFilter(String reportSheet, int count, String status) throws Throwable {

		String monthFrom = Excelobject.getCellData(reportSheet, "Month From", count);
		String monthTo = Excelobject.getCellData(reportSheet, "Month To", count);
		assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
		click(HomePage.INVOICE_TAB, "Invoice Tab");
		psopInvoiceSearchCriteriaUI();

		if (status.equalsIgnoreCase("Open")) {
			selectByVisibleText(Invoice.INVOICE_STATUS_VALUE, status, "Invoice drop down");
		} else if (status.equalsIgnoreCase("Closed")) {
			selectByVisibleText(Invoice.INVOICE_STATUS_VALUE, status, "Invoice drop down");
		}
		// FROM_LABEL_CALENDAR_ICON
		click(Invoice.FROM_LABEL_CALENDAR_ICON, "From calendar icon in Psop search criteria page");
		// MONTH_TITLE
		assertElementPresent(Invoice.MONTH_TITLE, "Month title in Psop search criteria page");
		String fromMonth = getText(Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		while (!fromMonth.equalsIgnoreCase(monthFrom)) {
			// GO_BACK_IN_MONTH
			click(Invoice.GO_BACK_IN_MONTH, "back < icon");
			fromMonth = getText(Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		}
		//
		waitForElementPresent(Invoice.TO_LABEL_CALENDAR_ICON, "To Calendar icon");
		click(Invoice.TO_LABEL_CALENDAR_ICON, "To Calendar icon");
		assertElementPresent(Invoice.MONTH_TITLE, "Month title in Psop search criteria page");
		String toMonth = getText(Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		while (!toMonth.equalsIgnoreCase(monthTo)) {
			// GO_BACK_IN_MONTH
			click(Invoice.GO_FORWARD_IN_MONTH, "forward > icon");
			toMonth = getText(Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		}
		// SEARCH_BUTTON
		assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in Psop search criteria page");
		click(Invoice.SEARCH_BUTTON, "Search button in Psop search criteria page");
	}

	public void psopInvoiceSearchResults(String reportSheet, int count) throws Throwable {
		// PSOP_INVOICE_SEARCH_HEADER
		assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_HEADER, "Header Psop search results");
		compareStrings("PSOP Invoice Search", getText(Invoice.PSOP_INVOICE_SEARCH_HEADER, "Page Title"));
		// PSOP_INVOICE_RESULTS_EXPORT_BUTTON
		assertElementPresent(Invoice.PSOP_INVOICE_RESULTS_EXPORT_BUTTON, "export button Psop search results");
		assertElementPresent(Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
		compareStrings("PSOP Invoice Search Results",
				getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search"));
		String parentWindow = driver.getWindowHandle();
		isEnabled(Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		click(Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		handlePopUpWindwow();
		driver.close();
		driver.switchTo().window(parentWindow);
		assertElementPresent(Entity.GO_BTN, "Psop Invoices Go Button");
		isEnabled(Entity.GO_BTN, "Psop Invoices Go Button");
		// PSOP_INVOICES_SORT_BY
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY, "Psop Invoices Sort by");
		// PSOP_INVOICES_SORT_BY_INDEX
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		// PSOP_INVOICES_SORT_BY_OW_ORDER
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		// PSOP_INVOICES_SORT_BY_PRINT_DATE
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		// PSOP_INVOICES_SORT_BY_INVOICE_DATE
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		// PSOP_INVOICES_SORT_BY_INVOICE_AMOUNT
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		// PSOP_INVOICES_SORT_BY_OPEN_AMOUNT
		assertElementPresent(Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		isEnabled(Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		// DROP_DOWN_INVOICE_CONTENT
		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop down option");
		// TEXT_BOX_IN_RHS
		assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Text box in RHS");
		assertElementPresent(Invoice.OW_ORDER_DATA_HEADER, "OW order column in data grid");
		assertElementPresent(Invoice.PRINT_DATE_DATA_HEADER, "Print date in data heade");
		assertElementPresent(Invoice.INVOICE_DATE_DATA_HEADER, "Invoice date in data header");
		assertElementPresent(Invoice.INV_AMOUNT_DATA_HEADER, "Invoice Amount in data header");
		assertElementPresent(Invoice.PSOP_COUNT_DATA_HEADER, "Psop count in data header");
		assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
		assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
		assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
		assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
		assertElementPresent(Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
		assertElementPresent(Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
		assertElementPresent(Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
		assertElementPresent(Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
		assertElementPresent(Invoice.SEARCH_AGAIN, "Search Again button");
		// assertElementPresent(Invoice.,"");
	}

	public void psopInvoiceRevisionPage(String reportSheet, int count) throws Throwable {

		String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
		// String entityName = Excelobject.getCellData(reportSheet, "Entity Name",
		// count);
		assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
		click(HomePage.INVOICE_TAB, "Invoice Tab");
		assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
		click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
		// SEARCH_TEXT_UNDER_SEARCH_BY
		assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, "Search text");
		type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId, "Search text");
		// SEARCH_BUTTON
		assertElementPresent(Invoice.SEARCH_BUTTON, "Search button");
		click(Invoice.SEARCH_BUTTON, "Search button");
		// REVISE_BUTTON
		assertElementPresent(Invoice.REVISE_BUTTON, "Revise button");
		click(Invoice.REVISE_BUTTON, "Revise button");
		// PSOP_INVOICE_SEARCH_HEADER
		assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_HEADER, "Psop Invoice Revision");
		compareStrings("PSOP Invoice Revision", getText(Invoice.PSOP_INVOICE_SEARCH_HEADER, "Psop Invoice Revision"));
		// PSOP_INVOICE_SEARCH_CRITERIA
		assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Psop Invoice Revision");
		compareStrings("PSOP Invoice Revision", getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Psop Invoice Revision"));
		// INVOICE_BELOW_PSOP_INVOICE_REVISION
		assertElementPresent(Invoice.INVOICE_BELOW_PSOP_INVOICE_REVISION, "Invoice # : label");
		// OW_ORDER_DATA_LABEL
		assertElementPresent(Invoice.OW_ORDER_DATA_LABEL, "OW Order # : label");
		// INVOICE_STATUS_LABEL
		assertElementPresent(Invoice.INVOICE_STATUS_LABEL, "Invoice status label");
		// ENTITY_DATA_LABEL
		assertElementPresent(Invoice.ENTITY_DATA_LABEL, "Entity data Label");
		// RECIPIENT_LABEL
		assertElementPresent(Invoice.RECIPIENT_LABEL, "Recipient Label");
		assertElementPresent(Invoice.TITLE_LABEL, "TITLE label");
		assertElementPresent(Invoice.CUSTOMER_LABEL, "Customer label");
		assertElementPresent(Invoice.ADDRESS_LABEL, "Address label");
		assertElementPresent(Invoice.PHONE_LABEL, "Phone label");
		assertElementPresent(Invoice.FAX_LABEL, "Fax label");
		assertElementPresent(Invoice.PERIOD_COVERED_LABEL, "Period covered label");
		assertElementPresent(Invoice.RENEWAL_MONTH_LABEL, "Renewal month label");
		assertElementPresent(Invoice.INVOICE_SUMMARY_SECTION, "Invoice summary section");
		assertElementPresent(Invoice.TOTAL_PAPER_SOP_LABEL, "Toatl Paper SOP label");
		assertElementPresent(Invoice.PSOP_AMOUNT_LABEL, "Psop Amount label");
		assertElementPresent(Invoice.OPEN_AMOUNT_LABEL, "Open amount label");
		assertElementPresent(Invoice.PREVIOUS_INVOICE_LABEL, "Previous invoice label");
		assertElementPresent(Invoice.PREVIOUS_BILLED_LABEL, "Previous billed label");
		assertElementPresent(Invoice.INVOICE_CONTENT_SECTION, "Invoice Content section");
		assertElementPresent(Invoice.EXPORT_BUTTON, "export button");
		assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "drop down under invoice content");
		assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Text Box for search");
		assertElementPresent(Invoice.GO_BUTTON, "Go Button");
		isEnabled(Invoice.GO_BUTTON, "Go Button");
		assertElementPresent(Invoice.SORT_BY_LABEL, "Sort By label");
		assertElementPresent(Invoice.SORT_BY_LABEL_ENTITY_NAME, "Entity name sort by label");
		assertElementPresent(Invoice.SORT_BY_LABEL_ENTITY_NUMBER, "Entity number sort by label");
		assertElementPresent(Invoice.SORT_BY_LABEL_JURIS, "Juris label");
		assertElementPresent(Invoice.SORT_BY_LABEL_SOP_COUNT, "SOP count label");
		assertElementPresent(Invoice.SORT_BY_LABEL_SUIT_TYPE, "Suit type label");
		assertElementPresent(Invoice.SORT_BY_LABEL_SUIT_SUB_TYPE, "Suit Sub type label");
		assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
		assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
		assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
		assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
		assertElementPresent(Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
		assertElementPresent(Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
		assertElementPresent(Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
		assertElementPresent(Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
		focus(Invoice.BACK_BUTTON_REVISION_PAGE, "Back button");
		assertElementPresent(Invoice.BACK_BUTTON_REVISION_PAGE, "Back button");
		assertElementPresent(Invoice.SUBMIT_BUTTON, "Submit button");
		assertElementPresent(Invoice.ENTITY_NAME_GRID_HEADER, "Entity name label in grid");
		assertElementPresent(Invoice.ENTITY_NUMBER_GRID_HEADER, "Entity # label in grid");
		assertElementPresent(Invoice.ENTITY_STATUS_GRID_HEADER, "Entity status label in grid");
		assertElementPresent(Invoice.JURIS_GRID_HEADER, "Juris label in grid");
		assertElementPresent(Invoice.SUIT_TYPE_GRID_HEADER, "Suit Type label in grid");
		assertElementPresent(Invoice.SUIT_SUB_TYPE_GRID_HEADER, "Sub Suit Type label in grid");
		assertElementPresent(Invoice.PSOP_COUNT_GRID_HEADER, "PSOP count label in grid");
		assertElementPresent(Invoice.REMOVE_CREDIT_DATA_HEADER, "Remove/Credit label in grid");
		assertElementPresent(Invoice.SELECT_ALL_BUTTON, "Select All Button");
		assertElementPresent(Invoice.SELECT_NONE_BUTTON, "Select none button");
		assertElementPresent(Invoice.INVOICE_DELIVERY_OPTIONS_SECTION, "invoice delivery options section");
		assertElementPresent(Invoice.DELIVERY_METHOD_LABEL, "Delivery method label");
		assertElementPresent(Invoice.REVISION_REASON_LABEL, "Revision Reason label");
		assertElementPresent(Invoice.DELIVERY_METHOD_DROP_DOWN, "Delivery method drop down");
		assertElementPresent(Invoice.REVISION_REASON_DROP_DOWN, "Revision Reason drop down");
	}

	public void enableThePS() throws Throwable {
		waitForElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		assertElementPresent(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		assertElementPresent(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
		focus(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		String billingStatus = getText(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		if (billingStatus.equals("Disabled")) {
			click(Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
			click(Entity.PAPER_SURCHARGE_BILLING_ENABLE, "Paper surchage billing enable radio button");
			assertElementPresent(Entity.SAVE_BTN, "Save button");
			click(Entity.SAVE_BTN, "Save button");
		}
	}

	public void psopInvoiceSearchByCustomer(String reportSheet, int count) throws Throwable {

		try {

			String customerId = Excelobject.getCellData(reportSheet, "Customer Id", count);
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			assertElementPresent(Invoice.CUSTOMER_RADIO_BUTTON,
					"Customer radio button in PSOP Invoice Search Criteria page");
			click(Invoice.CUSTOMER_RADIO_BUTTON, "click on Customer radio button in PSOP Invoice Search Criteria page");
			type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, customerId,
					"Search text box in PSop Invoice Search Criteria page");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Results page Title");
			compareStrings("PSOP Invoice Search Results", getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
					"Get text of PSOP Invoice Search Results page Title"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchByAndSearchCriteriaFiltersApplied(String searchBy, String reportSheet, int count)
			throws Throwable {

		try {

			String customerId = Excelobject.getCellData(reportSheet, "Customer Id", count);
			String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
			String serviceCenter = Excelobject.getCellData(reportSheet, "Service Center", count);
			String serviceTeam = Excelobject.getCellData(reportSheet, "Service Team", count);
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");

			// CUSTOMER_RADIO_BUTTON
			if (searchBy.equals("Customer")) {
				assertElementPresent(Invoice.CUSTOMER_RADIO_BUTTON,
						"Customer radio button in PSOP Invoice Search Criteria page");
				click(Invoice.CUSTOMER_RADIO_BUTTON,
						"click on Customer radio button in PSOP Invoice Search Criteria page");
				type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, customerId,
						"Search text box in PSop Invoice Search Criteria page");
			}
			// INVOICE_RADIO_BUTTON
			else if (searchBy.equals("Invoice")) {
				type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId,
						"Search text box in PSop Invoice Search Criteria page");
			}
			// SERVICE_CENTER_DROP_DOWN_VALUES
			assertElementPresent(Invoice.SERVICE_CENTER_DROP_DOWN_VALUES,
					"Service Center drop down in PSOP Invoice Search Criteria page");
			selectByVisibleText(Invoice.SERVICE_CENTER_DROP_DOWN_VALUES, serviceCenter,
					"Service Center drop down in PSOP Invoice Search Criteria page");
			// SERVICE_TEAM_DROP_DOWN_VALUES
			assertElementPresent(Invoice.SERVICE_TEAM_DROP_DOWN_VALUES,
					"Service team drop down in PSOP Invoice Search Criteria page");
			selectByVisibleText(Invoice.SERVICE_TEAM_DROP_DOWN_VALUES, serviceTeam,
					"Service team drop down in PSOP Invoice Search Criteria page");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			// PSOP_INVOICE_SEARCH_CRITERIA
			if (searchBy.contentEquals("Customer")) {
				assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Results page Title");
				compareStrings("PSOP Invoice Search Results", getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
						"Get text of PSOP Invoice Search Results page Title"));
			} else if (searchBy.contentEquals("Invoice")) {
				assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
				compareStrings("PSOP Invoice Profile",
						getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void countTotalPaperSOP(String reportSheet, int count) {
		try {
			int totalPsopCount = 0;
			String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId, "Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");

			assertElementPresent(Invoice.TOTAL_PAPER_SOP_COUNT, "PSOP count in PSOP Invoice Profile page");
			// Invoice.PSOP_COUNT
			assertElementPresent(Invoice.PSOP_COUNT, "PSOP count in PSOP Invoice Profile page under data grid");
			List<String> texts = getListText(Invoice.PSOP_COUNT,
					"PSOP count in PSOP Invoice Profile page under data grid");
			for (int i = 0; i < texts.size(); i++) {
				totalPsopCount = totalPsopCount + Integer.parseInt(texts.get(i));
			}
			// TOTAL_PAPER_SOP_COUNT
			assertElementPresent(Invoice.TOTAL_PAPER_SOP_COUNT, "Total paper SOP count in PSOP Invoice Profile page");
			compareStrings(String.valueOf(totalPsopCount),
					getText(Invoice.TOTAL_PAPER_SOP_COUNT, "Total paper SOP count in PSOP Invoice Profile page"));
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void searchForOWNumber(String reportSheet, int count) {

		try {
			String owOrder = Excelobject.getCellData(reportSheet, "OW Order", count);
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop down in PSOP Invoice List page");
			selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT, "OW Order #",
					"Search text in PSOP Invoice List page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(Invoice.DROP_DOWN_FISRT_OP, "First op drop down in PSOP Invoice List page");
			selectByVisibleText(Invoice.DROP_DOWN_FISRT_OP, "=", "Search text in PSOP Invoice List page");

			type(Invoice.TEXT_BOX_IN_RHS, owOrder, "Search text box in PSop Invoice list page");
			// GO_BUTTON
			assertElementPresent(Invoice.GO_BUTTON, " in PSOP Invoice List page");
			click(Invoice.GO_BUTTON, " in PSOP Invoice List page");
			// GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST
			assertElementPresent(Invoice.GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST,
					"Generate detail Report button in PSOP Invoice List Page");
			// isEnabled(Invoice.GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST,"Generate detail
			// Report button in PSOP Invoice List Page");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void invoiceProfileFromInvoiceList(String reportSheet, int count) {

		try {
			// INVOICE_PROFILING_LINK_PSOP_LIST
			assertElementPresent(Invoice.INVOICE_PROFILING_LINK_PSOP_LIST, "Invoice profiling link");
			click(Invoice.INVOICE_PROFILING_LINK_PSOP_LIST, "Invoice profiling link");
			// GENERATE_DETAIL_REPORT_BUTTON
			assertElementPresent(Invoice.GENERATE_DETAIL_REPORT_BUTTON,
					"Generate detail report button in PSOP Invoice Profile");
			isEnabled(Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate detail report button in PSOP Invoice Profile");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void verifyPSOPInvoicesLinkFunctionality(String reportSheet, int count, String testcase) throws Throwable {
		try {
			String affName = Excelobject.getCellData(reportSheet, "Affiliation Name", count);
			String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
			String agentType = Excelobject.getCellData(reportSheet, "Branch Plant", count);

			if (testcase.equalsIgnoreCase("Entity")) {
				// Search for the entity
				searchForTheEntity(reportSheet, count);
			} else if (testcase.equalsIgnoreCase("Affiliation")) {
				// Search for an affiliation
				searchForTheAffiliation(reportSheet, count);
			}
			// PSOP Invoice List for the entity/affiliation
			if (affName.isEmpty()) {
				psopInvoicesList(reportSheet, count, "Standalone Entity");
			} else {
				psopInvoicesList(reportSheet, count, "Affiliated Entity");
			}

			// Search for the OW number
			searchForOWNumber(reportSheet, count);
			// To Invoice Profile page
			invoiceProfileFromInvoiceList(reportSheet, count);
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_HEADER,
					"PSOP Invoice header is present in PSOP Invoice Profile page");
			String text = getText(Invoice.AGENT_NAME, "Entity Agent Type");
			// Verify Agent Type is correct
			assertTextContains(agentType, text);
			// verify invoice profile and SOP count
			// INVOICE_ID
			assertElementPresent(Invoice.INVOICE_ID, "Invoice id");
			// PSOP_INVOICE_SEARCH_CRITERIA
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
			compareStrings("PSOP Invoice Profile",
					getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title"));
			// GENERATE_DETAIL_REPORT_BUTTON
			assertElementPresent(Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			isEnabled(Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			// PRINT_BUTTON
			assertElementPresent(Invoice.PRINT_BUTTON, "Print Button");
			isEnabled(Invoice.PRINT_BUTTON, "Print Button");
			// INVOICE_DATA_TEXT
			assertElementPresent(Invoice.INVOICE_DATA_TEXT, "Invoice data text");
			if (affName.isEmpty()) {
				// INVOICE_DATA_LABEL
				assertElementPresent(Invoice.INVOICE_DATA_LABEL, "Invoice data label");
				// ENTITY LINK
				compareStrings(entityName, getText(Invoice.ENTITY_LINK_TEXT, "Entity link text"));
			} else {
				// INVOICE_DATA_LABEL
				assertElementPresent(Invoice.INVOICE_DATA_LABEL_AFFI, "Invoice data label");
				// AFFILIATION_LINK_TEXT
				compareStrings(affName, getText(Invoice.AFFILIATION_LINK_TEXT, "Affiliation link text"));
			}
			// OW_ORDER_DATA_LABEL
			assertElementPresent(Invoice.OW_ORDER_DATA_LABEL, "OW order data label");
			// INVOICE_STATUS_LABEL
			assertElementPresent(Invoice.INVOICE_STATUS_LABEL, "Invoice status label");
			// RECIPIENT_LABEL
			assertElementPresent(Invoice.RECIPIENT_LABEL, "Recipient label");
			// TITLE_LABEL
			assertElementPresent(Invoice.TITLE_LABEL, "TITLE label");
			assertElementPresent(Invoice.CUSTOMER_LABEL, "Customer label");
			assertElementPresent(Invoice.ADDRESS_LABEL, "Address label");
			assertElementPresent(Invoice.PHONE_LABEL, "Phone label");
			assertElementPresent(Invoice.FAX_LABEL, "Fax label");
			assertElementPresent(Invoice.PERIOD_COVERED_LABEL, "Period covered label");
			assertElementPresent(Invoice.RENEWAL_MONTH_LABEL, "Renewal month label");
			assertElementPresent(Invoice.INVOICE_SUMMARY_SECTION, "Invoice summary section");
			assertElementPresent(Invoice.TOTAL_PAPER_SOP_LABEL, "Toatl Paper SOP label");
			assertElementPresent(Invoice.PSOP_AMOUNT_LABEL, "Psop Amount label");
			assertElementPresent(Invoice.OPEN_AMOUNT_LABEL, "Open amount label");
			assertElementPresent(Invoice.PREVIOUS_INVOICE_LABEL, "Previous invoice label");
			assertElementPresent(Invoice.PREVIOUS_BILLED_LABEL, "Previous billed label");
			assertElementPresent(Invoice.INVOICE_CONTENT_SECTION, "Invoice Content section");
			assertElementPresent(Invoice.EXPORT_BUTTON, "export button");
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "drop down under invoice content");
			assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Text Box for search");
			assertElementPresent(Invoice.GO_BUTTON, "Go Button");
			isEnabled(Invoice.GO_BUTTON, "Go Button");
			assertElementPresent(Invoice.SORT_BY_LABEL, "Sort By label");
			assertElementPresent(Invoice.SORT_BY_LABEL_ENTITY_NAME, "Entity name sort by label");
			assertElementPresent(Invoice.SORT_BY_LABEL_ENTITY_NUMBER, "Entity number sort by label");
			assertElementPresent(Invoice.SORT_BY_LABEL_JURIS, "Juris label");
			assertElementPresent(Invoice.SORT_BY_LABEL_SOP_COUNT, "SOP count label");
			assertElementPresent(Invoice.SORT_BY_LABEL_SUIT_TYPE, "Suit type label");
			assertElementPresent(Invoice.SORT_BY_LABEL_SUIT_SUB_TYPE, "Suit Sub type label");
			assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
			assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
			assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
			assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
			assertElementPresent(Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
			assertElementPresent(Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
			assertElementPresent(Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
			assertElementPresent(Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
			assertElementPresent(Invoice.BACK_BUTTON, "Back button");
			assertElementPresent(Invoice.REVISE_BUTTON, "Revise button");
			assertElementPresent(Invoice.RECIPIENT_NAME, "Recipient name");
			String recipientNamePSOPInvoiceProfile = getText(Invoice.RECIPIENT_NAME, "Recipient name");
			assertElementPresent(Invoice.PARTICIPANT_TITLE, "Participant title");
			String titlePSOPInvoiceProfile = getText(Invoice.PARTICIPANT_TITLE, "Participant title");
			assertElementPresent(Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			String recipientCustomerPSOPInvoiceProfile = getText(Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			assertElementPresent(Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			String recipientAddressPSOPInvoiceProfile = getText(Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			assertElementPresent(Invoice.RECIPIENT_EMAIL, "Recipient Email");
			String recipientEmailPSOPInvoiceProfile = getText(Invoice.RECIPIENT_EMAIL, "Recipient Email");
			assertElementPresent(Invoice.RECIPIENT_PHONE, "Recipient Phone");
			String recipientPhonePSOPInvoiceProfile = getText(Invoice.RECIPIENT_PHONE, "Recipient Phone");
			assertElementPresent(Invoice.RECIPIENT_FAX, "Recipient Fax");
			String recipientFaxPSOPInvoiceProfile = getText(Invoice.RECIPIENT_FAX, "Recipient Fax");
			searchForTheEntity(reportSheet, count);
			// DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE
			assertElementPresent(DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			click(DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			// XSOP_RECIPIENT_NAME
			focus(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			assertElementPresent(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			String recipientNameXSOP = getText(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			// PARTICIPANT_TITLE
			assertElementPresent(DI.PARTICIPANT_TITLE, "Participant title xsop");
			String titleXSOP = getText(DI.PARTICIPANT_TITLE, "Participant title xsop");
			// RECIPIENT_CUSTOMER
			assertElementPresent(DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			String recipientCustomerXSOP = getText(DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			// RECIPIENT_ADDRESS
			assertElementPresent(DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			String recipientAddressXSOP = getText(DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			// RECIPIENT_EMAIL
			assertElementPresent(DI.RECIPIENT_EMAIL, "Recepient email xsop");
			String recipientEmailXSOP = getText(DI.RECIPIENT_EMAIL, "Recepient email xsop");
			// RECIPIENT_PHONE
			assertElementPresent(DI.RECIPIENT_PHONE, "Recepient phone xsop");
			String recipientPhoneXSOP = getText(DI.RECIPIENT_PHONE, "Recepient phone xsop");
			// RECIPIENT_FAX
			assertElementPresent(DI.RECIPIENT_FAX, "Recepient fax xsop");
			String recipientFaxXSOP = getText(DI.RECIPIENT_FAX, "Recepient fax xsop");
			compareStrings(recipientNamePSOPInvoiceProfile, recipientNameXSOP);
			compareStrings(titlePSOPInvoiceProfile, titleXSOP);
			compareStrings(recipientCustomerPSOPInvoiceProfile, recipientCustomerXSOP);
			compareStrings(recipientAddressPSOPInvoiceProfile, recipientAddressXSOP);
			compareStrings(recipientEmailPSOPInvoiceProfile, recipientEmailXSOP);
			compareStrings(recipientPhonePSOPInvoiceProfile, recipientPhoneXSOP);
			compareStrings(recipientFaxPSOPInvoiceProfile, recipientFaxXSOP);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyReviseButtonFunctionality(String reportSheet, int count) throws Throwable {
		String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
		try {
			searchForTheEntity(reportSheet, count);
			psopInvoicesList(reportSheet, count, "Affiliated Entity");

			// Search for the OW number
			searchForOWNumber(reportSheet, count);

			// To Invoice Profile page
			invoiceProfileFromInvoiceList(reportSheet, count);
			// To PSOP Invoice Revision Page
			click(Invoice.REVISE_BUTTON, "Revise Button");
			// Verify the PSOP Invoice Revision title
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Revision Page");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void editThePSOPPermissionToRole(String reportSheet, int count) {

		try {
			String roleName = Excelobject.getCellData(reportSheet, "Role", count);
			// ADMIN_TAB
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			click(Admin.ADMIN_TAB, "Admin Tab in the header");
			// FIRST_FILTER_DRPDWN
			assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "Filter drop down in Role Page");
			selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "Filter Dropdown 1");
			// SECOND_FILTER_DRPDWN
			assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Filter drop down in Role Page");
			selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "equals", "Filter Dropdown 2");
			// FILTER_TEXT_FILED
			assertElementPresent(Admin.FILTER_TEXT_FILED, "Filter text feild in Role Page");
			selectBySendkeys(Admin.FILTER_TEXT_FILED, roleName, "Filter text feild in Role Page");
			// GO_BTN
			assertElementPresent(Admin.GO_BTN, "GO Button in the Role Page");
			click(Admin.GO_BTN, "GO Button in the Role Page");
			// FIRST_ROLE_ON_THE_GRID
			assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "Role Name in the Role Page");
			click(Admin.FIRST_ROLE_ON_THE_GRID, "Role Name in the Role Page");
			// EDIT_BTN
			assertElementPresent(Admin.EDIT_BTN, "Edit Button in the Role Page");
			click(Admin.EDIT_BTN, "Edit Button in the Role Page");
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}

	public void removeThePSOPPermissionFromRole(String reportSheet, int count) {
		editThePSOPPermissionToRole(reportSheet, count);
		try {
			// PSOP_PERMISSION_SECTION
			assertElementPresent(Admin.PSOP_PERMISSION_SECTION, "Edit Button in the Edit Role Page");
			// PSOP_BILLING_CHECK_BOX
			assertElementPresent(Admin.PSOP_BILLING_CHECK_BOX, "PSOP Billing check box in the Edit Role Page");
			String psopBillingAttribute = getAttribute(Admin.PSOP_BILLING_CHECK_BOX, "checked");
			// System.out.println("jdbcjwbbkljfhfhfhfj "+ psopBillingAttribute);
			if (psopBillingAttribute != null) {
				click(Admin.PSOP_BILLING_CHECK_BOX, "Maintain Paper Surcharge billing button is unchecked");
			}
			// PSOP_REVISION_CHECK_BOX
			assertElementPresent(Admin.PSOP_REVISION_CHECK_BOX, "PSOP Revision check box in the Edit Role Page");
			String psopRevisionAttribute = getAttribute(Admin.PSOP_REVISION_CHECK_BOX, "checked");
			// System.out.println("jdbcjwbbkljfhfhfhfj "+ psopRevisionAttribute);
			if (psopRevisionAttribute != null) {
				click(Admin.PSOP_REVISION_CHECK_BOX, "PSOP revision checkbox button is unchecked");
			}
			// SAVEBTN
			assertElementPresent(Admin.SAVEBTN, "Save Button in the Edit Role Page");
			click(Admin.SAVEBTN, "Save Button in the Edit Role Page");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addThePSOPPermissionToRole(String reportSheet, int count) {
		editThePSOPPermissionToRole(reportSheet, count);
		try {
			// PSOP_PERMISSION_SECTION
			assertElementPresent(Admin.PSOP_PERMISSION_SECTION, "Edit Button in the Edit Role Page");
			// PSOP_BILLING_CHECK_BOX
			assertElementPresent(Admin.PSOP_BILLING_CHECK_BOX, "PSOP Billing check box in the Edit Role Page");
			String psopBillingAttribute = getAttribute(Admin.PSOP_BILLING_CHECK_BOX, "checked");
			if (psopBillingAttribute == null) {
				click(Admin.PSOP_BILLING_CHECK_BOX, "Maintain Paper Surcharge billing button is unchecked");
			}
			// PSOP_REVISION_CHECK_BOX
			assertElementPresent(Admin.PSOP_REVISION_CHECK_BOX, "PSOP Revision check box in the Edit Role Page");
			String psopRevisionAttribute = getAttribute(Admin.PSOP_REVISION_CHECK_BOX, "checked");
			if (psopRevisionAttribute == null) {
				click(Admin.PSOP_REVISION_CHECK_BOX, "PSOP revision checkbox button is unchecked");
			}
			// SAVEBTN
			assertElementPresent(Admin.SAVEBTN, "Save Button in the Edit Role Page");
			click(Admin.SAVEBTN, "Save Button in the Edit Role Page");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getTheEntityIDForTheInvoicePeriod(String reportSheet, int count) {
		String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
		ArrayList<String> resultEntity = new ArrayList<String>();
		if (invoicePeriod.equals("less than 2 years older")) {
			try {
				resultEntity = SQL_Queries.getEntityIDForLessThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else if (invoicePeriod.equals("older than 2 years")) {
			try {
				resultEntity = SQL_Queries.getEntityIDForMoreThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		return resultEntity.get(0);
	}

	public String getTheOrderNumberForTheInvoicePeriod(String reportSheet, int count) {
		String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
		ArrayList<String> resultOrder = new ArrayList<String>();
		if (invoicePeriod.equals("less than 2 years older")) {
			try {
				resultOrder = SQL_Queries.getOrderNumberForLessThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else if (invoicePeriod.equals("older than 2 years")) {
			try {
				resultOrder = SQL_Queries.getOrderNumberForMoreThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		return resultOrder.get(0);
	}

	public String getTheInvoiceNumberForTheInvoicePeriod(String reportSheet, int count) {
		String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
		ArrayList<String> resultInvoice = new ArrayList<String>();
		if (invoicePeriod.equals("less than 2 years older")) {
			try {
				resultInvoice = SQL_Queries.getInvoiceIDForLessThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else if (invoicePeriod.equals("older than 2 years")) {
			try {
				resultInvoice = SQL_Queries.getInvoiceIDForMoreThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		return resultInvoice.get(0);
	}

	public void searchForTheInvoiceFromPSOPInvoiceSearch(String reportSheet, int count) {
		try {

			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, getTheInvoiceNumberForTheInvoicePeriod(reportSheet, count),
					"Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void selectInvoiceFromTheInvoiceList(String reportSheet, int count) {
		try {
			waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
			click(HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, getTheEntityIDForTheInvoicePeriod(reportSheet, count), "Entity Id text box");
			assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(Entity.SEARCH_BTN, "Search Button");
			// PSOP_INVOICES_LEFT_NAV_BAR
			waitForElementPresent(Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link in Entity Profile page");
			assertElementPresent(Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link in Entity Profile Page");
			click(Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop down in PSOP Invoice List page");
			selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT, "OW Order #",
					"Search text in PSOP Invoice List page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(Invoice.DROP_DOWN_FISRT_OP, "First op drop down in PSOP Invoice List page");
			selectByVisibleText(Invoice.DROP_DOWN_FISRT_OP, "=", "Search text in PSOP Invoice List page");
			type(Invoice.TEXT_BOX_IN_RHS, getTheOrderNumberForTheInvoicePeriod(reportSheet, count),
					"Search text box in PSop Invoice list page");
			// GO_BUTTON
			assertElementPresent(Invoice.GO_BUTTON, " in PSOP Invoice List page");
			click(Invoice.GO_BUTTON, " in PSOP Invoice List page");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopRevisionPermissionFromInvoiceProfile(String reportSheet, int count, String permissionStatus) {
		try {
			String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
			String privilegeError = Excelobject.getCellData(reportSheet, "Privilege Error", count);
			Thread.sleep(3000);
			if (invoicePeriod.equals("less than 2 years older")) {
				// REVISE_BUTTON_IN_PSOP_INVOICES
				assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
				click(Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
				assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
				compareStrings("PSOP Invoice Revision",
						getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
			} else if (invoicePeriod.equals("older than 2 years")) {

				if (permissionStatus.equals("Permitted")) {
					assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					click(Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
					compareStrings("PSOP Invoice Revision",
							getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
				} else if (permissionStatus.equals("Not Permitted")) {
					assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					click(Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					// ERROR_PSOP_PERMISSION
					waitForVisibilityOfElementWithoutReport(Invoice.ERROR_PSOP_PERMISSION,
							"Error description in PSOP Error page");
					assertElementPresent(Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page");
					compareStrings(privilegeError,
							getText(Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page"));
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopRevisionPermissionFromInvoiceList(String reportSheet, int count, String permissionStatus) {
		try {

			String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
			String privilegeError = Excelobject.getCellData(reportSheet, "Privilege Error", count);
			Thread.sleep(3000);
			if (invoicePeriod.equals("less than 2 years older")) {
				// REVISE_BUTTON_IN_PSOP_INVOICES
				assertElementPresent(Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
				click(Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
				// PSOP_INVOICE_SEARCH_CRITERIA
				assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
				compareStrings("PSOP Invoice Revision",
						getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
			} else if (invoicePeriod.equals("older than 2 years")) {
				if (permissionStatus.equals("Permitted")) {
					assertElementPresent(Invoice.REVISE_BUTTON_IN_PSOP_INVOICES,
							"Revise Button in PSOP Invoice List page");
					click(Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
					assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
					compareStrings("PSOP Invoice Revision",
							getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
				} else if (permissionStatus.equals("Not Permitted")) {
					assertElementPresent(Invoice.REVISE_BUTTON_IN_PSOP_INVOICES,
							"Revise Button in PSOP Invoice List page");
					click(Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
					// ERROR_PSOP_PERMISSION
					waitForVisibilityOfElementWithoutReport(Invoice.ERROR_PSOP_PERMISSION,
							"Error description in PSOP Error page");
					assertElementPresent(Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page");
					compareStrings(privilegeError,
							getText(Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page"));
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopInvoiceExceptionSearch(String reportSheet, int count) {

		try {
			String serviceCenter = Excelobject.getCellData(reportSheet, "Service Center", count);
			String entityId = Excelobject.getCellData(reportSheet, "Entity Id", count);
			String affiliateId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// INVOICE_EXCEPTION_SEARCH
			assertElementPresent(Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			click(Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			if (!entityId.equals("")) {
				// RADIO_BUTTON_FOR_ENTITY
				assertElementPresent(Invoice.RADIO_BUTTON_FOR_ENTITY,
						"Radio Button for Entity in Invoice Exception Search Page");
				click(Invoice.RADIO_BUTTON_FOR_ENTITY, "Radio Button for Entity in Invoice Exception Search Page");
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, entityId,
						"Search Text for Entity in Invoice Exception Search Page");
			}
			if (!affiliateId.equals("")) {
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, affiliateId,
						"Search Text for Entity in Invoice Exception Search Page");
			}
			// SERVICE_CENTER_DROP_DOWN
			assertElementPresent(Invoice.SERVICE_CENTER, "Service Center drop down in Invoice Exception search Page");
			selectByVisibleText(Invoice.SERVICE_CENTER, serviceCenter, "Filter Dropdown 1");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
			click(Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopExceptionTab(String reportSheet, int count) {
		try {
			// PSOP_EXCEPTIONS_TAB
			assertElementPresent(Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Exceptions Tab in Invoice Exception Page");
			click(Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Execptions Tab in Invoice Exception Page");
			// PSOP_INVOICE_SEARCH_CRITERIA
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
					"Invoice Exceptions Title in Invoice Exception Page");
			compareStrings("Invoice Exceptions", getText(Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
					"Invoice Exceptions Title in Invoice Exception Page"));
			// PSOP_INVOICE_RESULTS_EXPORT_BUTTON
			assertElementPresent(Invoice.PSOP_INVOICE_RESULTS_EXPORT_BUTTON, "Export button in Invoice Exception Page");
			isEnabled(Invoice.PSOP_INVOICE_RESULTS_EXPORT_BUTTON, "Export button in Invoice Exception Page");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop Down in Invoice Exception Page");
			assertElementPresent(Invoice.IS_NEXT_TO_DROP_DOWN,
					"is displayed next to Drop Down in Invoice Exception Page");
			assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Search text box in Invoice Exception Page");
			assertElementPresent(Invoice.GO_BUTTON, "Go Button in Invoice Exceptions Page");
			isEnabled(Invoice.GO_BUTTON, "Go Button in Invoice Exceptions Page");
			assertElementPresent(Invoice.SORT_BY_LABEL, "Sort By label in PSOP Exceptions Page");
			assertElementPresent(Invoice.REASON_SORT_LABEL, "Reason Sort label in PSOP Exceptions Page");
			assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID,
					"First navigation link above grid in PSOP Exceptions Page");
			assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID,
					"Previous navigation link above grid PSOP Exceptions Page");
			assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID,
					"Next navigation link above grid PSOP Exceptions Page");
			assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID,
					"Last navigation link above grid PSOP Exceptions Page");
			assertElementPresent(Invoice.FIRST_NAVIGATION_BELOW_GRID,
					"First navigation link below grid PSOP Exceptions Page");
			assertElementPresent(Invoice.PREVIOUS_NAVIGATION_BELOW_GRID,
					"Previous navigation link below grid PSOP Exceptions Page");
			assertElementPresent(Invoice.NEXT_NAVIGATION_BELOW_GRID,
					"Next navigation link below grid PSOP Exceptions Page");
			assertElementPresent(Invoice.LAST_NAVIGATION_BELOW_GRID,
					"Last navigation link below grid PSOP Exceptions Page");
			assertElementPresent(Invoice.SEARCH_AGAIN, "Search Again Button in PSOP Exceptions Page");
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public String getTheEntityOrAffiliationForErrorCodes(String reportSheet, int count) {
		ArrayList<String> entityOrAffl = new ArrayList<String>();
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			switch (errorCode) {
			case "69001":
				entityOrAffl = SQL_Queries.getAffiliationMissingXSOPGroup();
				break;
			case "69002":
				entityOrAffl = SQL_Queries.getAffiliationContainMoreXSOPGroup();
				break;
			case "69004":
				entityOrAffl = SQL_Queries.getEntityMissingXSOPDI();
				break;
			case "69005":
				entityOrAffl = SQL_Queries.getAffiliationForXSOPContainInvalidRecipient();
				break;
			case "69006":
				entityOrAffl = SQL_Queries.getEntityForDIContainInvalidRecipient();
				break;
			case "69008":
				entityOrAffl = SQL_Queries.getEntityForInvalidBusinessUnit();
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityOrAffl.get(0);
	}

	public String getTheServiceCenterForTheEntityOrAffiliation(String reportSheet, int count) {

		String serviceCenter = "";
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			if (errorCode.equals("69001") || errorCode.equals("69002") || errorCode.equals("69005")) {
				waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
				click(HomePage.AFFILIATION_TAB, "Affiliation Search");
				waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
				type(Affiliation.AFFILIATIONID, getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Affiliation Id text box");
				assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
				click(Affiliation.SEARCHBTN, "Search Button");
				// MEMBERSBTN
				assertElementPresent(Affiliation.MEMBERSBTN,
						"Members Button in left nav bar in Affiliation profile Page");
				click(Affiliation.MEMBERSBTN, "Members Button in left nav bar in Affiliation profile Page");
				// FIRSTFILTER
				assertElementPresent(Affiliation.FIRSTFILTER, "Drop down in Affiliation members Page");
				selectByVisibleText(Affiliation.FIRSTFILTER, "Entity Name", "select entity name from the drop down");
				// SECONDFILTER
				assertElementPresent(Affiliation.SECONDFILTER, "Drop down in Affiliation members Page");
				selectByVisibleText(Affiliation.SECONDFILTER, "contains", "select contains from the drop down");
				// FILTERTEXTBOX
				assertElementPresent(Affiliation.FILTERTEXTBOX, "Text box in Affiliation members Page");
				type(Affiliation.FILTERTEXTBOX, getTheEntityOfAffiliationForErrorCodes(reportSheet, count),
						"Filter text field");
				// GOBTN
				assertElementPresent(Affiliation.GOBTN, "Go Button in Affiliation search Page");
				click(Affiliation.GOBTN, "Go Button in Affiliation members Page");
				// CORPORATEENTITYNAME
				assertElementPresent(Affiliation.CORPORATEENTITYNAME, "entity link in Affiliation search Page");
				click(Affiliation.CORPORATEENTITYNAME, "entity link in Affiliation members Page");
			} else if (errorCode.equals("69004") || errorCode.equals("69006")) {
				waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
				click(HomePage.ENTITY_TAB, "Entity Search");
				waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
				type(Entity.ENTITY_ID, getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Entity Id text box");
				assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				click(Entity.SEARCH_BTN, "Search Button");
			}
			// change the Business unit
			else if (errorCode.equals("69008")) {
				waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
				click(HomePage.ENTITY_TAB, "Entity Search");
				waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
				type(Entity.ENTITY_ID, getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Entity Id text box");
				assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				click(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				// ENTITY_EDIT
				assertElementPresent(Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
				click(Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
				// CHECK_BOX_SERVICE_CENTER
				waitForElementToBeClickable(Entity.CHECK_BOX_SERVICE_CENTER,
						"check box service center Edit Entity Profile Page");
				assertElementPresent(Entity.CHECK_BOX_SERVICE_CENTER,
						"check box service center Edit Entity Profile Page");
				click(Entity.CHECK_BOX_SERVICE_CENTER, "check box service center Edit Entity Profile Page");
				// DROP_DOWN_LIST_SERVICE_CENTER
				waitForElementPresent(Entity.DROP_DOWN_LIST_SERVICE_CENTER, "service center from the drop down");
				assertElementPresent(Entity.DROP_DOWN_LIST_SERVICE_CENTER, "service center from the drop down");
				selectByVisibleText(Entity.DROP_DOWN_LIST_SERVICE_CENTER, "CT UCC Demo Service Center",
						"select service center from the drop down");
				// DROP_DOWN_LIST_SERVICE_TEAM
				waitForElementPresent(Entity.DROP_DOWN_LIST_SERVICE_TEAM, "service team drop down");
				assertElementPresent(Entity.DROP_DOWN_LIST_SERVICE_TEAM, "service center from the drop down");
				selectByVisibleText(Entity.DROP_DOWN_LIST_SERVICE_TEAM, "CT UCC Demo Team",
						"select service team from the drop down");
				// SAVE_BTN
				waitForElementPresent(Entity.SAVE_BTN, "Save button in edit Entity profile page");
				assertElementPresent(Entity.SAVE_BTN, "Save button in edit Entity profile page");
				click(Entity.SAVE_BTN, "click on Save button in edit Entity profile page");

			}
			// method which fetch service team
			// SERVICE_CENTER
			assertElementPresent(Entity.SERVICE_CENTER, "service center in Entity profile Page");
			serviceCenter = getText(Entity.SERVICE_CENTER, "Text in the Service Center field");

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return serviceCenter;
	}

	public String getTheEntityOfAffiliationForErrorCodes(String reportSheet, int count) {
		ArrayList<String> entityOfAffl = new ArrayList<String>();
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			switch (errorCode) {
			case "69001":
				entityOfAffl = SQL_Queries.getBusNameAffiliationMissingXSOPGroup();
				break;
			case "69002":
				entityOfAffl = SQL_Queries.getBusNameAffiliationContainMoreXSOPGroup();
				break;
			case "69005":
				entityOfAffl = SQL_Queries.getBusNameAffiliationForXSOPContainInvalidRecipient();
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityOfAffl.get(0);
	}

	public void selectEntityOrAffAndServiceCenterSearch(String reportSheet, int count, String serviceCenter) {
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			if (errorCode.equals("69004") || errorCode.equals("69006") || errorCode.equals("69008")) {
				// RADIO_BUTTON_FOR_ENTITY
				assertElementPresent(Invoice.RADIO_BUTTON_FOR_ENTITY,
						"Radio Button for Entity in Invoice Exception Search Page");
				click(Invoice.RADIO_BUTTON_FOR_ENTITY, "Radio Button for Entity in Invoice Exception Search Page");
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Search Text for Entity in Invoice Exception Search Page");
			} else if (errorCode.equals("69001") || errorCode.equals("69002") || errorCode.equals("69005")) {
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Search Text for Entity in Invoice Exception Search Page");
			}
			// SERVICE_CENTER_DROP_DOWN
			assertElementPresent(Invoice.SERVICE_CENTER, "Service Center drop down in Invoice Exception search Page");
			selectByVisibleText(Invoice.SERVICE_CENTER, serviceCenter, "Filter Dropdown 1");

		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void validateThePSOPExceptionsInUI(String reportSheet, int count, String serviceCenter) {
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			String errorDescription = Excelobject.getCellData(reportSheet, "Error Description", count);
			String exceptionDescription = "";
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			// INVOICE_EXCEPTION_SEARCH
			assertElementPresent(Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			click(Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			selectEntityOrAffAndServiceCenterSearch(reportSheet, count, serviceCenter);
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
			click(Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
			// PSOP_EXCEPTIONS_TAB
			assertElementPresent(Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Exceptions Tab in Invoice Exception Page");
			click(Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Execptions Tab in Invoice Exception Page");
			// FIRST_SUBMIT_ORDER_BUTTON
			assertElementPresent(Invoice.FIRST_SUBMIT_ORDER_BUTTON, "Submit Order button in Invoice Exception Page");
			click(Invoice.FIRST_SUBMIT_ORDER_BUTTON, "Submit Order button in Invoice Exception Page");
			// ERROR_BOX_VAL_SUMMARY
			assertElementPresent(Invoice.ERROR_BOX_VAL_SUMMARY, "Error description in Invoice Exception Page");
			exceptionDescription = getText(Invoice.ERROR_BOX_VAL_SUMMARY,
					"Error description in Invoice Exception Page");
			compareStrings(errorDescription, exceptionDescription);
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void searchForThePSOPInvoiceAndCreditSOP(String reportSheet, int count) throws Throwable {

		try {

			String psopCount = Excelobject.getCellData(reportSheet, "PSOP Count", count);
			String sopLines = Excelobject.getCellData(reportSheet, "SOP Lines", count);
			String deliveryMethod = Excelobject.getCellData(reportSheet, "Delivery Method", count);
			String revisionReason = Excelobject.getCellData(reportSheet, "Revision Reason", count);
			String orginalOrderId = SQL_Queries.getOriginalOrderId(psopCount).get(0);
			String originalInvoiceId = SQL_Queries.getOriginalInvoiceId(orginalOrderId).get(0);
			String orderContentOriginalOrder = SQL_Queries.getCountOfNonCreditedOriginalPSOPOrderContent(orginalOrderId)
					.get(0);
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, originalInvoiceId,
					"Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			// REVISE_BUTTON
			assertElementPresent(Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			click(Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			selectTheSOPLinesAndReviseTheInvoice(reportSheet, count, orderContentOriginalOrder, "");
			// DELIVERY_METHOD_DROP_DOWN
			assertElementPresent(Invoice.DELIVERY_METHOD_DROP_DOWN, "Delivery method in PSOP Invoice revision page");
			selectByVisibleText(Invoice.DELIVERY_METHOD_DROP_DOWN, deliveryMethod,
					"Delivery method in PSOP Invoice revision page");
			// REVISION_REASON_DROP_DOWN
			assertElementPresent(Invoice.REVISION_REASON_DROP_DOWN, "Revision Reason in PSOP Invoice revision page");
			selectByVisibleText(Invoice.REVISION_REASON_DROP_DOWN, revisionReason,
					"Revision Reason in PSOP Invoice revision page");
			// SUBMIT_BUTTON
			assertElementPresent(Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			click(Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			Thread.sleep(5000);
			String originalOrderCreditedCount = SQL_Queries
					.getCountOfPSOPOrderContentAfterCreditForOriginalOrderId(orginalOrderId).get(0);
			printMessageInReport("Count of SOP Lines in Original Order: " + orderContentOriginalOrder);
			Thread.sleep(5000);
			printMessageInReport("Count of SOP Lines Credited in Original Order: " + originalOrderCreditedCount);
			// getNewOrderId
			Thread.sleep(5000);
			if (!sopLines.equals("ALL")) {
				String newOrderId = SQL_Queries.getNewOrderId(orginalOrderId).get(0);
				printMessageInReport("New Order id created: " + newOrderId);
				// getCountOfPSOPOrderContentForNewOrderId
				Thread.sleep(5000);
				String newOrderContentCount = SQL_Queries.getCountOfPSOPOrderContentForNewOrderId(newOrderId).get(0);
				printMessageInReport("Count of Order content in the New Order created: " + newOrderContentCount);
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void selectTheSOPLinesAndReviseTheInvoice(String reportSheet, int count, String orderContentOriginalOrder,
			String entityQuitOrAdd) {

		try {

			String sopLines = Excelobject.getCellData(reportSheet, "SOP Lines", count);
			String entityQuit = Excelobject.getCellData(reportSheet, "Entity Quit", count);
			switch (sopLines) {
			case "1":
				if (entityQuit.equals("Y")) {
					try {
						Thread.sleep(2000);
						By ENTITY_QUIT_FROM_AFFILIATION = By.xpath("//td[contains(text(),'" + entityQuitOrAdd
								+ "')]//parent::tr[starts-with(@id,'SelectedRow')]//td[starts-with(@id,'grdData_ctl')]");
						waitForElementPresent(ENTITY_QUIT_FROM_AFFILIATION, "Check box for the Entity");
						assertElementPresent(ENTITY_QUIT_FROM_AFFILIATION, "Check box for the Entity");
						click(ENTITY_QUIT_FROM_AFFILIATION, "Click on the check box for the Entity Quit");

					} catch (NoSuchElementException e) {
					}
				} else {
					waitForElementPresent(Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page");
					assertElementPresent(Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page");
					for (int s = 0; s < Integer.valueOf(sopLines); s++) {
						clickOnAParticularIndexOfAnElement(Invoice.REMOVE_CREDIT_CHECK_BOX,
								"Credit/remove check box in PSOP Invoice revision page", s);
						Thread.sleep(1000);
					}
				}
				break;
			case "2":
				waitForElementPresent(Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				assertElementPresent(Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				for (int s = 0; s < Integer.valueOf(sopLines); s++) {
					clickOnAParticularIndexOfAnElement(Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page", s);
					Thread.sleep(1000);
				}
				break;
			case "ALL":
				waitForElementPresent(Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				assertElementPresent(Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				for (int s = 0; s < Integer.valueOf(orderContentOriginalOrder); s++) {
					clickOnAParticularIndexOfAnElement(Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page", s);
					Thread.sleep(1000);
				}
				break;
			case "None":

			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public String getTheEntityWithoutDSEnabled() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityHaveDERepLLCORDELP().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String getEntityNotHavingDERepLLCORDELP() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityNotHavingDERepLLCORDELP().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(String subgroupId) {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(subgroupId).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String getEntityHavingMoreThanOneRepIncludingREPLLC() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityHavingMoreThanOneRepIncludingREPLLC().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(String entity) {
		String subgroupInfo = "";
		try {

			subgroupInfo = SQL_Queries.subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(entity).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}

	public ArrayList<String> getTheSubgroupWhichAlreadyHavingDSPresent(String renewalMonth) {
		ArrayList<String> subgroupInfo = new ArrayList<String>();
		try {

			subgroupInfo = SQL_Queries.getTheSubgroupWhichAlreadyHavingDSPresent(renewalMonth);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}

	public String getTheSubgroupWithoutDSEnabled(String renewalMonth) {
		String subgroupInfo = "";
		try {

			subgroupInfo = SQL_Queries.getRenewalSubgroupHaveDERepLLCORDELP(renewalMonth).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}

	public void bundleDSEffectiveStartDateEntityLevel(String reportSheet, int count,
			String getTheEntityWithoutDSEnabled) {
		try {

			String backDateOrForwardDate = Excelobject.getCellData(reportSheet, "BackOrForward Date", count);
			String EntityOrSubgroupLevel = Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
			String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet, "Discontinue Rep", count);
			waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
			click(HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			// type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
			// count), "Entity Id text box");
			type(Entity.ENTITY_ID, getTheEntityWithoutDSEnabled, "Entity Id text box");
			assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(Entity.SEARCH_BTN, "Search Button");
			// RENEWAL_INVOICE_LEFT_NAV_LINK
			assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
					"Renewal Invoices in left nav of entity profile page");
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
			// ALL_RENEWAL_INVOICES_TAB
			assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
			click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY,
					"All Renewal Invoices Tab in Renewal Invoices page");
			click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			waitForElementPresent(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String renewalDate = getText(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String effectiveStartDate = "";
			String dseffectiveStartDate = "";
			effectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(0);
			dseffectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(1);
			// ENTITY_PROFILE
			assertElementPresent(Entity.ENTITY_PROFILE, "Entity profile link in left nav bar");
			click(Entity.ENTITY_PROFILE, "Click on Entity profile link in left nav bar");
			// ENTITY_EDIT
			assertElementPresent(Entity.ENTITY_EDIT, "Edit button on Entity profile page");
			click(Entity.ENTITY_EDIT, "Click on Edit button on Entity profile page");
			// REPARMS_BUNDLE_BUNDLE_DRPDWN
			assertElementPresent(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			click(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			// EFFECTIVE_START_DATE
			assertElementPresent(Entity.EFFECTIVE_START_DATE, "Effective start Date text field");
			type(Entity.EFFECTIVE_START_DATE, effectiveStartDate, "Effective start Date text field");
			// DISBURSEMENT_EFFECTIVE_START_DATE
			assertElementPresent(Entity.DISBURSEMENT_EFFECTIVE_START_DATE, "DS Effective start Date text field");
			type(Entity.DISBURSEMENT_EFFECTIVE_START_DATE, dseffectiveStartDate, "DS Effective start Date text field");
			// PLUS_DISBURSEMENTS_CHECKBOX
			assertElementPresent(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus disbursement check box");
			click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Click on Plus disbursement check box");
			// COMMENTS
			assertElementPresent(Entity.COMMENTS, "Comments box in Edit Entity Profile page");
			type(Entity.COMMENTS, "Test", "type test in Comments box in Edit Entity Profile page");
			// SAVE_BTN
			assertElementPresent(Entity.SAVE_BTN, "Save Button on edit entity Profile Page");
			click(Entity.SAVE_BTN, "Click on Save Button on edit entity profile page");
			reviseTheInvoice(EntityOrSubgroupLevel, "", "", discontinueDERepLLCorLP, getTheEntityWithoutDSEnabled);

		} catch (Throwable e) {

			// e.printStackTrace();
		}
	}

	public void bundleDSEffectiveStartDateSubgroupLevel(String reportSheet, int count, String entity,
			String getTheSubgroupWithoutDSEnabled) throws Throwable {
		try {
			String backDateOrForwardDate = Excelobject.getCellData(reportSheet, "BackOrForward Date", count);
			String subgroupId = getTheSubgroupWithoutDSEnabled;
			String affiliationId = SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(subgroupId).get(0);
			String subGroupName = SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(subgroupId).get(1);
			String EntityOrSubgroupLevel = Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
			String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet, "Discontinue Rep", count);
			waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			click(HomePage.AFFILIATION_TAB, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
			assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(Affiliation.SEARCHBTN, "Search Button");
			// RENEWAL_INVOICE_LEFT_NAV_LINK
			assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
					"Renewal Invoices in left nav of entity profile page");
			click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
			// ALL_RENEWAL_INVOICES_TAB
			assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
			click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			// NAME_DRPDWN
			assertElementPresent(Entity.NAME_DRPDWN, "Name Drop down");
			click(Entity.NAME_DRPDWN, "Click on Name Drop down");
			// SECOND_FILTER_DROP_DOWN
			assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
			selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN, "contains", "Second Filter Drop down");
			// PSOP_INVOICES_TEXT_SEARCH
			assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
			type(Entity.PSOP_INVOICES_TEXT_SEARCH, subGroupName, "Search Box in top right of renewal Invoices page");
			// GO_BTN
			assertElementPresent(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
			click(Entity.GO_BTN, "Click on Go Button");
			// ARROW_INVOICE_STATUS_SORT_BY
			assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY,
					"All Renewal Invoices Tab in Renewal Invoices page");
			click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			waitForElementPresent(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String renewalDate = getText(Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String effectiveStartDate = "";
			String dseffectiveStartDate = "";
			effectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(0);
			dseffectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(1);
			// SUB_GROUPS_LEFT_NAV_BAR
			assertElementPresent(Entity.SUB_GROUPS_LEFT_NAV_BAR,
					"Sub Group link in left nav bar of renewal Invoices page");
			click(Entity.SUB_GROUPS_LEFT_NAV_BAR, "Click on Sub Group link");
			// SUB_GROUP_BUNDLE_MAINTENANCE
			assertElementPresent(Entity.SUB_GROUP_BUNDLE_MAINTENANCE,
					"Sub Group bundle maintenance link in left nav bar of renewal Invoices page");
			click(Entity.SUB_GROUP_BUNDLE_MAINTENANCE,
					"Click on Sub Group bundle maintenance link in left nav bar of renewal Invoices page");

			// below is the fxn to validate if bundle is already enable
			// REPARMS_BUNDLE_BUNDLE_DRPDWN
			assertElementPresent(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			click(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			// EFFECTIVE_END_DATE
			assertElementPresent(Invoice.EFFECTIVE_END_DATE, "Effective end Date text field");
			type(Invoice.EFFECTIVE_END_DATE, effectiveStartDate, "Effective end Date text field");
			// COMMENTS
			assertElementPresent(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,
					"Comments box in sub group bundle maintenance page");
			type(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE, "Test",
					"type test in Comments box in sub group bundle maintenance page");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT,
					"First Drop down sub group bundle maintenance page");
			selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT, "Sub Group Name",
					"First Drop down sub group bundle maintenance page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(Invoice.DROP_DOWN_FISRT_OP, "Second Drop down sub group bundle maintenance page");
			selectByVisibleText(Invoice.DROP_DOWN_FISRT_OP, "contains",
					"Second Drop down sub group bundle maintenance page");
			// TEXT_BOX_IN_RHS
			assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Text box in sub group bundle maintenance page");
			type(Invoice.TEXT_BOX_IN_RHS, subGroupName,
					"type subgroup name in text box of sub group bundle maintenance page");
			assertElementPresent(Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
			Thread.sleep(1000);
			click(Invoice.GO_BUTTON, "Click on Go Button in sub group bundle maintenance page");
			List<WebElement> gridCheckBox = null;

			try {
				// GRID_CHECK_BOX_SELECTOR
				gridCheckBox = driver.findElements(Invoice.GRID_CHECK_BOX_SELECTOR);
				if (gridCheckBox.size() > 0) {
					assertElementPresent(Invoice.GRID_CHECK_BOX_SELECTOR,
							"select the subgroup check box in sub group bundle maintenance page");
					click(Invoice.GRID_CHECK_BOX_SELECTOR, "Click on check box in sub group bundle maintenance page");
					// BUTTON_DISABLE
					assertElementPresent(Invoice.BUTTON_DISABLE, "disable button in sub group bundle maintenance page");
					click(Invoice.BUTTON_DISABLE, "Click on disable button in sub group bundle maintenance page");
				}
			} catch (Exception e) {

			}
			// INACTIVE_BUNDLE_SUB_GROUPS
			assertElementPresent(Entity.INACTIVE_BUNDLE_SUB_GROUPS,
					"Inactive bundle sub groups tab sub group bundle maintenance page");
			click(Entity.INACTIVE_BUNDLE_SUB_GROUPS,
					"Click on Inactive bundle sub groups tab sub group bundle maintenance page");
			// REPARMS_BUNDLE_BUNDLE_DRPDWN
			assertElementPresent(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			click(Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			// EFFECTIVE_START_DATE
			assertElementPresent(Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL, "Effective start Date text field");
			type(Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL, effectiveStartDate, "Effective start Date text field");
			// DISBURSEMENT_EFFECTIVE_START_DATE
			assertElementPresent(Entity.DISBURSEMENT_EFFECTIVE_START_DATE, "DS Effective start Date text field");
			type(Entity.DISBURSEMENT_EFFECTIVE_START_DATE, dseffectiveStartDate, "DS Effective start Date text field");
			// PLUS_DISBURSEMENTS_CHECKBOX
			assertElementPresent(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus disbursement check box");
			click(Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Click on Plus disbursement check box");
			// COMMENTS
			assertElementPresent(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,
					"Comments box in sub group bundle maintenance page");
			type(Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE, "Test",
					"type test in Comments box in sub group bundle maintenance page");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(Invoice.DROP_DOWN_INVOICE_CONTENT,
					"First Drop down sub group bundle maintenance page");
			selectByVisibleText(Invoice.DROP_DOWN_INVOICE_CONTENT, "Sub Group Name",
					"First Drop down sub group bundle maintenance page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(Invoice.DROP_DOWN_FISRT_OP, "Second Drop down sub group bundle maintenance page");
			selectByVisibleText(Invoice.DROP_DOWN_FISRT_OP, "contains",
					"Second Drop down sub group bundle maintenance page");
			// TEXT_BOX_IN_RHS
			assertElementPresent(Invoice.TEXT_BOX_IN_RHS, "Text box in sub group bundle maintenance page");
			type(Invoice.TEXT_BOX_IN_RHS, subGroupName,
					"type subgroup name in text box of sub group bundle maintenance page");
			assertElementPresent(Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
			click(Invoice.GO_BUTTON, "Click on Go Button in sub group bundle maintenance page");
			// GRID_CHECK_BOX_SELECTOR
			assertElementPresent(Invoice.GRID_CHECK_BOX_SELECTOR,
					"select the subgroup check box in sub group bundle maintenance page");
			click(Invoice.GRID_CHECK_BOX_SELECTOR, "Click on check box in sub group bundle maintenance page");
			// ENABLE_BUTTON
			assertElementPresent(Invoice.ENABLE_BUTTON, "enable Button in sub group bundle maintenance page");
			click(Invoice.ENABLE_BUTTON, "click on enable button in sub group bundle maintenance page");
			reviseTheInvoice(EntityOrSubgroupLevel, subGroupName, subgroupId, discontinueDERepLLCorLP, entity);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void discontinueDomesticREPLLCorLP(String getTheEntityWithoutDSEnabled) throws Throwable {

		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
		// count), "Entity Id text box");
		type(Entity.ENTITY_ID, getTheEntityWithoutDSEnabled, "Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");
		// REPRESENATION_LEFT_NAV_LINK
		assertElementPresent(Entity.REPRESENATION_LEFT_NAV_LINK, "Representation link in Entity Profile Page");
		click(Entity.REPRESENATION_LEFT_NAV_LINK, "Click on Representation link");
		// FIRST_DROP_DOWN
		assertElementPresent(Entity.FIRST_DROP_DOWN, "First drop down in represenation units Page");
		selectByVisibleText(Entity.FIRST_DROP_DOWN, "Service Type", "First drop down in represenation units Page");
		// SECOND_FILTER_DROP_DOWN
		assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second drop down in represenation units Page");
		selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN, "contains", "Second drop down in represenation units Page");
		// PSOP_INVOICES_TEXT_SEARCH
		assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Text box Represenation units Page");
		type(Entity.PSOP_INVOICES_TEXT_SEARCH, "Domestic Representation (Limited", "Text box Represenation units Page");
		// GO_BTN
		assertElementPresent(Entity.GO_BTN, "Go Button in Represenation units Page");
		click(Entity.GO_BTN, "Click on Go Button in Represenation units Page");
		// FIRST_ENTITY_IN_GRID
		assertElementPresent(Entity.FIRST_ENTITY_IN_GRID, "First Representation link in Represenation units Page");
		click(Entity.FIRST_ENTITY_IN_GRID, "Click on First Representation link in Represenation units Page");
		// here pick filing date logic should come from the rep profile
		// REP_FILING_DATE
		assertElementPresent(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repFilingDate = getText(Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repDiscontinueDate = setTheDateForDS("forwardDate", repFilingDate).get(1);
		// DISCONTINUE_BUTTON
		assertElementPresent(Entity.DISCONTINUE_BUTTON, "Discontinue Button in Represenation units Page");
		click(Entity.DISCONTINUE_BUTTON, "Click on Discontinue Button in Represenation units Page");
		// FILING_DATE_FOR_DISCONTINUE
		assertElementPresent(Entity.FILING_DATE_FOR_DISCONTINUE, "Filing text box in Represenation units Page");
		type(Entity.FILING_DATE_FOR_DISCONTINUE, repDiscontinueDate, "Filing text box in Represenation units Page");
		// DISCONTINUE_REASON_DROP_DOWN
		assertElementPresent(Entity.DISCONTINUE_REASON_DROP_DOWN,
				"First drop down in discontinue represenation units Page");
		selectByVisibleText(Entity.DISCONTINUE_REASON_DROP_DOWN, "1 Year Suspension",
				"First drop down in discontinue represenation units Page");
		// DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT
		assertElementPresent(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT,
				"Discontinue Button in Represenation units Page");
		click(Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT,
				"Click on Discontinue Button in Represenation units Page");
	}

	public ArrayList<String> setTheDateForDS(String backDateOrForwardDate, String renewalDate) {
		ArrayList<String> dates = new ArrayList<String>();
		String month = renewalDate.split("\\/")[0];
		String date = renewalDate.split("\\/")[1];
		String year = renewalDate.split("\\/")[2];
		String effectiveStartDate = "";
		String dseffectiveStartDate = "";
		if (backDateOrForwardDate.equals("backDate")) {
			if (Integer.valueOf(month) >= 3) {
				effectiveStartDate = String.valueOf(Integer.valueOf(month) - 2) + "/" + date + "/" + year;
				dseffectiveStartDate = String.valueOf(Integer.valueOf(month) - 1) + "/" + date + "/" + year;
			} else if (Integer.valueOf(month) < 3) {
				effectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 2);
				dseffectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 1);
			}
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);
		} else if (backDateOrForwardDate.equals("forwardDate")) {
			if (Integer.valueOf(month) <= 10) {
				effectiveStartDate = String.valueOf(Integer.valueOf(month) - 1) + "/" + date + "/" + year;
				dseffectiveStartDate = String.valueOf(Integer.valueOf(month) + 1) + "/" + date + "/" + year;
			} else if (Integer.valueOf(month) > 10) {
				effectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 1);
				dseffectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) + 1);
			}
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);
		} else if (backDateOrForwardDate.equals("")) {
			effectiveStartDate = month + "/" + date + "/" + year;
			dseffectiveStartDate = month + "/" + date + "/" + year;
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);
		}
		return dates;
	}

	public void reviseTheInvoice(String entityOrSubgroupLevel, String subGroupName, String SubgroupOrEntityId,
			String discontinueDERepLLCorLP, String entity) throws Throwable {

		// RENEWAL_INVOICE_LEFT_NAV_LINK
		assertElementPresent(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
				"Renewal Invoices in left nav of entity profile page");
		click(Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
		// ALL_RENEWAL_INVOICES_TAB
		assertElementPresent(Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		click(Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");

		if (entityOrSubgroupLevel.equals("EntityLevel")) {
			try {
				assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY,
						"All Renewal Invoices Tab in Renewal Invoices page");
				click(Invoice.ARROW_INVOICE_STATUS_SORT_BY,
						"Click on All Renewal Invoices Tab in Renewal Invoices page");
				// GET_FIRST_INVOICE_LINK
				assertElementPresent(Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
				click(Entity.GET_FIRST_INVOICE_LINK, "Click on First Invoice link in Renewal Invoices page");
				// get the name of Entity from here ENTITY_NAME_LINK_INVOICE_PROFILE
				assertElementPresent(Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity link in Renewal Invoices page");
				String entityName = getText(Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity name");
				String parentWindow = null;
				parentWindow = doARevisionPreviewOfTheInvoice(entityName);
				// move to new window
				handlePopUpWindwow();
				// String parentWindow = doARevisionPreviewOfTheInvoice();
				// move to new window
				// handlePopUpWindwow();
				if (discontinueDERepLLCorLP.equals("Y")) {
					// By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = null;
					List<WebElement> annualReport = null;
					// ("//td[contains(text(),'9400574631')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual
					// Report Renewal Disbursements')]")
					try {
						By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
								+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
						annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
						}
					} catch (NoSuchElementException e) {
						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ " as the DS criteria does not met");
					}
				} else {
					// ANNUAL_REPORT_RENEWAL_DISBURSEMENT
					By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = null;
					List<WebElement> annualReport = null;
					try {
						ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entityName
								+ "')]/following-sibling::td[contains(text(),'Annual Report Renewal Disbursements')]");
						annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport(
									"Disbursement Added for the eligible Rep for the Entity : " + entityName);
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ " as the DS criteria does not met");

					}
				}

				driver.close();
				driver.switchTo().window(parentWindow);
				assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
				click(Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
				// DO_NOT_PRINT_RADIO_BUTTON
				assertElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Do not Print Radio Button in Affected Invoices page");
				click(Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Click on Do not Print Radio Button in Affected Invoices page");
				// REVISE_REASON_DROP_DOWN
				assertElementPresent(Invoice.REVISE_REASON_DROP_DOWN,
						"Revision Reason drop down in Revise Invoice page");
				selectByVisibleText(Invoice.REVISE_REASON_DROP_DOWN, "CT Assurance",
						"Revision Reason drop down in Revise Invoice page");
				// REVISE_BUTTON_REPRINT
				assertElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
				click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
			}

			catch (Exception e) {

			}
		}

		else if (entityOrSubgroupLevel.equals("SubgroupLevel")) {
			// NAME_DRPDWN
			waitForElementPresent(Entity.NAME_DRPDWN, "Name Drop down");
			assertElementPresent(Entity.NAME_DRPDWN, "Name Drop down");
			click(Entity.NAME_DRPDWN, "Click on Name Drop down");
			/// SECOND_FILTER_DROP_DOWN
			waitForElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
			assertElementPresent(Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
			selectByVisibleText(Entity.SECOND_FILTER_DROP_DOWN, "contains", "Second Filter Drop down");
			// PSOP_INVOICES_TEXT_SEARCH
			assertElementPresent(Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
			type(Entity.PSOP_INVOICES_TEXT_SEARCH, subGroupName, "Search text box");
			// GO_BTN
			assertElementPresent(Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
			click(Entity.GO_BTN, "Click on Go Button");
			// ARROW_INVOICE_STATUS_SORT_BY
			assertElementPresent(Invoice.ARROW_INVOICE_STATUS_SORT_BY,
					"All Renewal Invoices Tab in Renewal Invoices page");
			click(Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			// GET_FIRST_INVOICE_LINK
			assertElementPresent(Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
			click(Entity.GET_FIRST_INVOICE_LINK, "Click on First Invoice link in Renewal Invoices page");
			String parentWindowSubGroup = null;
			assertElementPresent(Entity.SUBGROUP_NAME_LINK_INVOICE_PROFILE, "subgroup link in Renewal Invoices page");
			String subgroupName = getText(Entity.SUBGROUP_NAME_LINK_INVOICE_PROFILE, "subgroup name");
			try {
				// here first identity the subgroup name

				parentWindowSubGroup = doARevisionPreviewOfTheInvoice(subgroupName);

				// move to new window
				handlePopUpWindwow();
				// ANNUAL_REPORT_RENEWAL_DISBURSEMENT
				if (discontinueDERepLLCorLP.equals("Y")) {

					try {
						List<WebElement> annualReport = null;
						By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
								+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
						annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ "as the DS criteria does not met");
						printMessageInReport("No Disbursement are added for the discontinued Rep");

					}
					try {

						List<WebElement> totalDisbursement = null;
						totalDisbursement = driver.findElements(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (totalDisbursement.size() > 0) {
							printMessageInReport("Disbursement are added for the subgroup : " + subgroupName
									+ " and count is : " + totalDisbursement.size());
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the subgroup");

					}
				} else {
					// assertElementPresent(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT, "Disbursement
					// present");
					try {
						By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
								+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
						List<WebElement> annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ " as the DS criteria does not met");

					}
					try {

						List<WebElement> totalDisbursement = null;
						totalDisbursement = driver.findElements(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (totalDisbursement.size() > 0) {
							printMessageInReport("Disbursement are added for the subgroup and count is : "
									+ totalDisbursement.size());
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the subgroup");

					}
				}

				driver.close();
				driver.switchTo().window(parentWindowSubGroup);
				// REVISE_BUTTON
				assertElementPresent(Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
				click(Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
				// DO_NOT_PRINT_RADIO_BUTTON
				assertElementPresent(Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Do not Print Radio Button in Affected Invoices page");
				click(Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Click on Do not Print Radio Button in Affected Invoices page");
				// REVISE_REASON_DROP_DOWN
				assertElementPresent(Invoice.REVISE_REASON_DROP_DOWN,
						"Revision Reason drop down in Revise Invoice page");
				selectByVisibleText(Invoice.REVISE_REASON_DROP_DOWN, "CT Assurance",
						"Revision Reason drop down in Revise Invoice page");
				// REVISE_BUTTON_REPRINT
				assertElementPresent(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
				click(Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
			}

			catch (Exception e) {

			}
		}

	}

	public String doARevisionPreviewOfTheInvoice(String entityOrSubgroupName) throws Throwable {
		// REVISION_PREVIEW_BUTTON
		waitForElementPresent(Entity.REVISION_PREVIEW_BUTTON, "Revision Preview Button on Invoice Profile");
		assertElementPresent(Entity.REVISION_PREVIEW_BUTTON, "Revision Preview button in Renewal Invoices page");
		click(Entity.REVISION_PREVIEW_BUTTON, "Click on Revision Preview button in Renewal Invoices page");
		//// Here first the next button check should be done
		try {
			List<WebElement> action = driver.findElements(Invoice.NEXT_BUTTON_RELATED_INVOICE);
			if (action.size() > 0) {

				click(Invoice.NEXT_BUTTON_RELATED_INVOICE,
						"Click on Next button in Related Invoices Needing Revision page");
			}
		} catch (NoSuchElementException e) {

		}
		String parentWindow = "";
		try {
			parentWindow = driver.getWindowHandle();
			By INVOICE_SUBGROUP_OR_ENTITY_LEVEL = By.xpath("//a[contains(text(),'" + entityOrSubgroupName + "')]");
			List<WebElement> entOrSubgroup = driver.findElements(INVOICE_SUBGROUP_OR_ENTITY_LEVEL);
			if (entOrSubgroup.size() > 0) {
				waitForElementToBeClickable(INVOICE_SUBGROUP_OR_ENTITY_LEVEL,
						"Entity or subgroup present in revision preview");
				// waitForElementPresent(Entity.FIRST_INVOICE_IN_NEW_INVOICES_GRID, "First
				// invoice in new Invoice grid");
				assertElementPresent(INVOICE_SUBGROUP_OR_ENTITY_LEVEL,
						"Entity or subgroup present in revision preview");
				click(INVOICE_SUBGROUP_OR_ENTITY_LEVEL, "Entity or subgroup present in revision preview");
			}
		} catch (NoSuchElementException e) {

		}
		return parentWindow;
	}

	public void addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice(String reportSheet, int count,
			ArrayList<String> subgroupInfo, String entity) throws Throwable {

		String affiliationId = subgroupInfo.get(0);
		String subgroupId = subgroupInfo.get(1);
		String subGroupName = subgroupInfo.get(2);
		String EntityOrSubgroupLevel = Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
		// String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet,
		// "Discontinue Rep", count);
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
		// AFFILIATION_NAME
		assertElementPresent(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		String affName = getText(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
		// count), "Entity Id text box");
		type(Entity.ENTITY_ID, entity, "Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");
		click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		click(Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
		// BULLETINRETAINCURRENTDI
		assertElementPresent(Affiliation.BULLETINRETAINCURRENTDI,
				" Bulletin Radio button in confirm joining affiliation Page");
		click(Affiliation.BULLETINRETAINCURRENTDI, " Bulletin Radio button in confirm joining affiliation Page");
		// COMMRETAINCURRENTDI
		assertElementPresent(Affiliation.COMMRETAINCURRENTDI,
				" Communication Radio button in confirm joining affiliation Page");
		click(Affiliation.COMMRETAINCURRENTDI, " Communication Radio button in confirm joining affiliation Page");
		// RENEWALINVOICESUBGROUPDROPDWN
		assertElementPresent(Affiliation.RENEWALINVOICESUBGROUPDROPDWN,
				" REnewal Invoice drop down in confirm joining affiliation Page");
		selectByVisibleText(Affiliation.RENEWALINVOICESUBGROUPDROPDWN, subGroupName,
				"REnewal Invoice drop down in confirm joining affiliation Page");
		// SOPRETAINCURRENTDI
		assertElementPresent(Affiliation.SOPRETAINCURRENTDI, " SOP Radio button in confirm joining affiliation Page");
		click(Affiliation.SOPRETAINCURRENTDI, " SOP Radio button in confirm joining affiliation Page");
		// XSOPSUBGROUPDROPDWN
		assertElementPresent(Affiliation.XSOPSUBGROUPDROPDWN, "XSOP drop down in confirm joining affiliation Page");
		selectByIndex(Affiliation.XSOPSUBGROUPDROPDWN, 1, "XSOP drop down in confirm joining affiliation Page");
		// COMMENTS
		assertElementPresent(Affiliation.COMMENTS, "Comments text box in confirm joining affiliation Page");
		type(Affiliation.COMMENTS, "Test", "Comments text box in confirm joining affiliation Page");
		// JOINBTN
		assertElementPresent(Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
		click(Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
		// Add bundle thing here
		if (EntityOrSubgroupLevel.equals("EntityLevel")) {
			bundleDSEffectiveStartDateEntityLevel(reportSheet, count, entity);
		} else if (EntityOrSubgroupLevel.equals("SubgroupLevel")) {
			bundleDSEffectiveStartDateSubgroupLevel(reportSheet, count, entity, subgroupId);
		}
		// reviseTheInvoice(EntityOrSubgroupLevel,subGroupName,subgroupId,discontinueDERepLLCorLP,entity);

	}

	public void validateTheInvoiceChangesPostRevision(String orderId) throws Throwable {
		//
		assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
		click(HomePage.INVOICE_TAB, "Invoice Tab");
		// SEARCH_TEXT_UNDER_SEARCH_BY
		assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, "Invoice search text box");
		type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, orderId, "Invoice search text box");
		// SEARCH_BUTTON
		assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in the renewal search Page");
		click(Invoice.SEARCH_BUTTON, "Search button in the renewal search Page");
		List<WebElement> disableInvoiceLink = null;
		try {
			// NO_INVOICE_CHANGES_LINK
			disableInvoiceLink = driver.findElements(Invoice.NO_INVOICE_CHANGES_LINK);
		} catch (NoSuchElementException e) {

		}
		if (disableInvoiceLink == null) {

			// INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE
			assertElementPresent(Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE,
					"Invoice changes link for the first invoice");
			click(Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE, "Invoice changes link for the first invoice");
			// DS_ADDED
			try {
				List<WebElement> ds = driver.findElements(Invoice.DS_ADDED);
				printMessageInReport("Total DS Added = " + ds.size());
			} catch (NoSuchElementException e) {
			}
		} else {
			printMessageInReport("No DS is Added as the DS Criteria does not met");

		}
	}

	public void revisePSOPInvoiceAndCreditSOP(String reportSheet, int count,
			ArrayList<String> originalInvoiceAndOrderId, String entityQuitOrAdd) throws Throwable {

		try {

			String entityQuit = Excelobject.getCellData(reportSheet, "Entity Quit", count);
			String sopLines = Excelobject.getCellData(reportSheet, "SOP Lines", count);
			String deliveryMethod = Excelobject.getCellData(reportSheet, "Delivery Method", count);
			String revisionReason = Excelobject.getCellData(reportSheet, "Revision Reason", count);
			String orginalOrderId = originalInvoiceAndOrderId.get(1);
			String originalInvoiceId = originalInvoiceAndOrderId.get(0);
			String orderContentOriginalOrder = SQL_Queries.getCountOfNonCreditedOriginalPSOPOrderContent(orginalOrderId)
					.get(0);
			waitForElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(HomePage.INVOICE_TAB, "Invoice Tab");
			click(HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			waitForElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			assertElementPresent(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, originalInvoiceId,
					"Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			waitForElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			assertElementPresent(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			// REVISE_BUTTON
			waitForElementPresent(Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			assertElementPresent(Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			click(Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			// if(!entityQuit.equals("Y")) {
			selectTheSOPLinesAndReviseTheInvoice(reportSheet, count, orderContentOriginalOrder, entityQuitOrAdd);
			try {
				// DELIVERY_METHOD_DROP_DOWN
				List<WebElement> delMethod = driver.findElements(Invoice.DELIVERY_METHOD_DROP_DOWN);
				if (delMethod.size() > 0) {
					// waitForElementPresent(Invoice.DELIVERY_METHOD_DROP_DOWN,"Delivery method in
					// PSOP Invoice revision page");
					assertElementPresent(Invoice.DELIVERY_METHOD_DROP_DOWN,
							"Delivery method in PSOP Invoice revision page");
					selectByVisibleText(Invoice.DELIVERY_METHOD_DROP_DOWN, deliveryMethod,
							"Delivery method in PSOP Invoice revision page");
					// REVISION_REASON_DROP_DOWN
					// waitForElementPresent(Invoice.REVISION_REASON_DROP_DOWN,"Revision Reason in
					// PSOP Invoice revision page");
					assertElementPresent(Invoice.REVISION_REASON_DROP_DOWN,
							"Revision Reason in PSOP Invoice revision page");
					selectByVisibleText(Invoice.REVISION_REASON_DROP_DOWN, revisionReason,
							"Revision Reason in PSOP Invoice revision page");
				}
			} catch (NoSuchElementException e) {
			}
			// SUBMIT_BUTTON
			waitForElementPresent(Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			assertElementPresent(Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			click(Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			Thread.sleep(5000);
			String originalOrderCreditedCount = SQL_Queries
					.getCountOfPSOPOrderContentAfterCreditForOriginalOrderId(orginalOrderId).get(0);
			printMessageInReport("Count of SOP Lines in Original Order: " + orderContentOriginalOrder);
			Thread.sleep(3000);
			printMessageInReport("Count of SOP Lines Credited in Original Order: " + originalOrderCreditedCount);
			// getNewOrderId
			Thread.sleep(3000);
			if (!sopLines.equals("ALL")) {
				String newOrderId = "";
				try {
					newOrderId = getNewOrderId(orginalOrderId).get(0);
					if (!newOrderId.equals("")) {
						System.out.println("The new Order Id is : " + newOrderId);
						if (entityQuit.equals("Y")) {
							String countOfSopLinesBeforeCreditForEntity = SQL_Queries
									.getTheCountOfEntityQuitFromAffiliationForThePSOPOrderId(orginalOrderId).get(0);
							String countOfSopLinesAfterCreditForEntity = getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(
									entityQuitOrAdd, newOrderId).get(0);
							printMessageInReport("Count Of SOPs for the entity before Quit : "
									+ countOfSopLinesBeforeCreditForEntity);
							printMessageInReport(
									"Count Of SOPs for the entity After Quit : " + countOfSopLinesAfterCreditForEntity);
						}
						printMessageInReport("New Order id created: " + newOrderId);
						// getCountOfPSOPOrderContentForNewOrderId
						Thread.sleep(3000);
						String newOrderContentCount = SQL_Queries.getCountOfPSOPOrderContentForNewOrderId(newOrderId)
								.get(0);
						printMessageInReport(
								"Count of Order content in the New Order created: " + newOrderContentCount);
						verifyTheNewOrderRefersToTheOriginalOrder(orginalOrderId, newOrderId);
					}
				} catch (IndexOutOfBoundsException e) {
				}
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void verifyTheNewOrderRefersToTheOriginalOrder(String originalOrderId, String newOrderId) throws Throwable {

		ArrayList<String> originalOrderContent = new ArrayList<String>();
		ArrayList<String> newOrderContent = new ArrayList<String>();
		try {
			originalOrderContent = SQL_Queries.getTheOriginalOrderContent(originalOrderId);
		} catch (IndexOutOfBoundsException e) {
		}
		Thread.sleep(2000);
		try {
			newOrderContent = SQL_Queries.getTheNewOrderContent(newOrderId);
		} catch (IndexOutOfBoundsException e) {
		}
		Thread.sleep(2000);
		boolean bool = originalOrderContent.equals(newOrderContent);
		if (bool == true) {
			printMessageInReport("New Order refers to the original Order, Original Order : " + originalOrderContent
					+ "New Order : " + newOrderContent);
		}
	}

	public ArrayList<String> getTheOriginalEntityLevelPSOPInvoice() {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getTheOriginalEntityLevelPSOPInvoice();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return originalInvoieAndOrderId;
	}

	public ArrayList<String> getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(String entityId, String newOrderId)
			throws Throwable {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(entityId,
					newOrderId);

		} catch (IndexOutOfBoundsException e) {

		}
		return originalInvoieAndOrderId;
	}

	public ArrayList<String> getNewOrderId(String oldOrderId) throws Throwable {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getNewOrderId(oldOrderId);

		} catch (IndexOutOfBoundsException e) {

		}
		return originalInvoieAndOrderId;
	}

	public ArrayList<String> getTheOriginalAffiliationLevelPSOPInvoice() {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getTheOriginalAffiliationLevelPSOPInvoice();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return originalInvoieAndOrderId;
	}

	public String getTheEntityIdToQuitFromAffiliationForThePSOPOrderId(String orderId) {
		ArrayList<String> entity = new ArrayList<String>();
		try {

			entity = SQL_Queries.getTheEntityIdToQuitFromAffiliationForThePSOPOrderId(orderId);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity.get(0);
	}

	public String getTheEntityIdForThePSOPOrderId(String orderId) {
		ArrayList<String> entityId = new ArrayList<String>();
		try {

			entityId = SQL_Queries.getTheEntityIdForThePSOPOrderId(orderId);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityId.get(0);
	}

	public String getTheAffiliationIdForThePSOPOrderId(String orderId) {
		ArrayList<String> affiliationId = new ArrayList<String>();
		try {

			affiliationId = SQL_Queries.getTheAffiliationIdForThePSOPOrderId(orderId);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return affiliationId.get(0);
	}

	public void searchForTheEntityAndChangeRenewalMonth(String entityId) throws Throwable {
		try {
			waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
			click(HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
			type(Entity.ENTITY_ID, entityId, "Entity Id text box");
			assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(Entity.SEARCH_BTN, "Search Button");
			// ENTITY_EDIT
			waitForElementPresent(Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
			assertElementPresent(Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
			click(Entity.ENTITY_EDIT, "Click on Edit Button");
			// SELECTED_RENEWAL_MONTH
			waitForElementPresent(Entity.SELECTED_RENEWAL_MONTH, "value");
			String month = getAttribute(Entity.SELECTED_RENEWAL_MONTH, "value");
			// RENEWAL_MONTH_EDIT_ENTITY
			try {
				if (Integer.valueOf(month) < 12) {
					waitForElementPresent(Entity.RENEWAL_MONTH_EDIT_ENTITY, "Renewal Month Edit Entity");
					selectByIndex(Entity.RENEWAL_MONTH_EDIT_ENTITY, Integer.valueOf(month), "month select drop down");

				} else if (Integer.valueOf(month) == 12) {
					waitForElementPresent(Entity.RENEWAL_MONTH_EDIT_ENTITY, "Renewal Month Edit Entity");
					selectByIndex(Entity.RENEWAL_MONTH_EDIT_ENTITY, Integer.valueOf(month) - 4,
							"month select drop down");
				}
			} catch (NoSuchElementException e) {
			}
			// COMMENTS
			assertElementPresent(Entity.COMMENTS, "Comment text box in Edit Entity Information Page");
			type(Entity.COMMENTS,
					"Change RM from : " + month + " to " + getAttribute(Entity.SELECTED_RENEWAL_MONTH, "value"),
					"Comment text box in Edit Entity Information Page");
			// SAVE_BTN
			assertElementPresent(Entity.SAVE_BTN, "Save button in Edit Entity Information Page");
			click(Entity.SAVE_BTN, "Save button in Edit Entity Information Page");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchForTheAffiliationAndChangeRenewalMonth(String affiliationId) throws Throwable {
		try {
			waitForElementPresent(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			click(HomePage.AFFILIATION_TAB, "Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
			assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(Affiliation.SEARCHBTN, "Search Button");
			// EDITBTN
			waitForElementPresent(Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			assertElementPresent(Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			click(Affiliation.EDITBTN, "Click on Edit Button");
			// SELECTED_RENEWAL_MONTH
			waitForElementPresent(Affiliation.SELECTED_RENEWAL_MONTH, "value");
			String month = getAttribute(Affiliation.SELECTED_RENEWAL_MONTH, "value");
			// RENEWAL_MONTH_EDIT_ENTITY
			if (Integer.valueOf(month) < 12) {

				waitForElementPresent(Affiliation.SELECTED_RENEWAL_MONTH, "value");
				selectByIndex(Affiliation.COMMONRENEWALDRPDWN, Integer.valueOf(month) + 1, "month select drop down");
			} else if (Integer.valueOf(month) == 12) {
				waitForElementPresent(Affiliation.SELECTED_RENEWAL_MONTH, "value");
				selectByIndex(Affiliation.COMMONRENEWALDRPDWN, Integer.valueOf(month) - 1, "month select drop down");
			}
			// COMMENTFIELD
			assertElementPresent(Affiliation.COMMENTFIELD, "Comment text box in Edit Affiliation Information Page");
			type(Affiliation.COMMENTFIELD, "Changed renewal Month", "Comment text box in Edit Entity Information Page");
			// SAVE_BTN
			assertElementPresent(Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");
			click(Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void quitEntityFromAffiliation(String entityId) throws Throwable {

		// click on Entity Search link
		waitForElementPresent(Entity.ENTITY_LINK_TOPNAV, "Entity Search");
		click(Entity.ENTITY_LINK_TOPNAV, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(Entity.SEARCH_BTN, "Search Button");
		waitForElementPresent(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
		String quitAffiliationDisabled = getAttribute(Entity.QUIT_AFFILIATION_BTN, "disabled");

		if (quitAffiliationDisabled == null) {
			assertElementPresent(Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
			click(Entity.QUIT_AFFILIATION_BTN, "Click on Quit Affiliaton Button");
			// RETAIN_CURRENT_DI_RADIO_BUTTON
			waitForElementPresent(Affiliation.RETAIN_CURRENT_DI_RADIO_BUTTON,
					"Retain current DI radio Button confirming quitting the affiliation");
			assertElementPresent(Affiliation.RETAIN_CURRENT_DI_RADIO_BUTTON,
					"Retain current DI radio Button confirming quitting the affiliation");
			click(Affiliation.RETAIN_CURRENT_DI_RADIO_BUTTON, "Click on Retain current DI Radio Button");
			try {
				// QUITAFFILIATIONCOMMENTSECTTION
				// waitForElementPresent(Affiliation.QUITAFFILIATIONCOMMENTSECTTION, "Comments
				// text box in confirming quitting the affiliation");
				assertElementPresent(Affiliation.QUITAFFILIATIONCOMMENTSECTTION,
						"Comments text box in confirming quitting the affiliation");
				type(Affiliation.QUITAFFILIATIONCOMMENTSECTTION, "quit affiliation",
						"Comments text box in confirming quitting the affiliation");
				// QUIT_THE_AFFILIATION_BTN
				waitForElementPresent(Entity.QUIT_THE_AFFILIATION_BTN,
						"Quit the Affiliation Button confirming quitting the affiliation");
				assertElementPresent(Entity.QUIT_THE_AFFILIATION_BTN,
						"Quit the Affiliation Button confirming quitting the affiliation");
				click(Entity.QUIT_THE_AFFILIATION_BTN,
						"Click on Quit the Affiliation Button confirming quitting the affiliation");
				handlepopup();
			} catch (NoSuchElementException e) {
			}
			Thread.sleep(1000);
		}
	}

	public void joinEntityToAffiliation(String entityId, String affiliationId) throws Throwable {

		waitForElementToBeClickable(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(Affiliation.SEARCHBTN, "Search Button");
		// AFFILIATION_NAME
		waitForElementPresent(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		assertElementPresent(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		String affName = getText(Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		waitForElementToBeClickable(HomePage.ENTITY_TAB, "Entity Search Link");
		click(HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(Entity.ENTITY_ID, "Entity ID Text box");
		// type(Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
		// count), "Entity Id text box");
		type(Entity.ENTITY_ID, entityId, "Entity Id text box");
		assertElementPresent(Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(Entity.SEARCH_BTN, "Search Button");

		waitForElementToBeClickable(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		click(Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		waitForElementToBeClickable(Entity.FINDBTN, "Find Btn");
		click(Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		try {
			List<WebElement> affiliation = driver.findElements(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE);
			if (affiliation.size() > 0) {
				waitForElementToBeClickable(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
				click(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
				// BULLETINRETAINCURRENTDI
				waitForElementPresent(Affiliation.BULLETINRETAINCURRENTDI,
						" Bulletin Radio button in confirm joining affiliation Page");
				assertElementPresent(Affiliation.BULLETINRETAINCURRENTDI,
						" Bulletin Radio button in confirm joining affiliation Page");
				click(Affiliation.BULLETINRETAINCURRENTDI,
						" Bulletin Radio button in confirm joining affiliation Page");
				// COMMRETAINCURRENTDI
				assertElementPresent(Affiliation.COMMRETAINCURRENTDI,
						" Communication Radio button in confirm joining affiliation Page");
				click(Affiliation.COMMRETAINCURRENTDI,
						" Communication Radio button in confirm joining affiliation Page");
				// RENEWALINVOICERETAINCURRENTDI
				assertElementPresent(Affiliation.RENEWALINVOICERETAINCURRENTDI,
						" REnewal Invoice radio button in confirm joining affiliation Page");
				click(Affiliation.RENEWALINVOICERETAINCURRENTDI,
						"REnewal Invoice radio button in confirm joining affiliation Page");
				// SOPRETAINCURRENTDI
				assertElementPresent(Affiliation.SOPRETAINCURRENTDI,
						" SOP Radio button in confirm joining affiliation Page");
				click(Affiliation.SOPRETAINCURRENTDI, " SOP Radio button in confirm joining affiliation Page");
				// XSOPSUBGROUPDROPDWN
				assertElementPresent(Affiliation.XSOPSUBGROUPDROPDWN,
						"XSOP drop down in confirm joining affiliation Page");
				selectByIndex(Affiliation.XSOPSUBGROUPDROPDWN, 1, "XSOP drop down in confirm joining affiliation Page");
				// COMMENTS
				assertElementPresent(Affiliation.COMMENTS, "Comments text box in confirm joining affiliation Page");
				type(Affiliation.COMMENTS, "Test", "Comments text box in confirm joining affiliation Page");
				// JOINBTN
				assertElementPresent(Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
				click(Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
				Thread.sleep(2000);
			}
		} catch (NoSuchElementException e) {

		}
	}

	// public ArrayList<String> uploadTheFilesToScannerRBCPath(int totalRows) throws
	// Throwable{
	public ArrayList<String> uploadTheFilesToScannerRBCPath(int totalRows, String hardCopy, String environment)
			throws Throwable {
		String NasScanFirstPath = "";

		if (environment.equals("Stage")) {

			NasScanFirstPath = NasScanFirstPathStg;

		} else if (environment.equals("QA")) {

			NasScanFirstPath = NasScanFirstPathQA;
		}
		ArrayList<String> fileNames = new ArrayList<String>();
		String fileName = "Test" + getCurrentDate().split("\\/")[0] + getCurrentDate().split("\\/")[1];
		String currentFileName = null;
		String fileNameWithHardCopy = "";
		String desktopPath = System.getProperty("user.home") + "//Desktop";
		copyTheFile(TestFileXMLToUploadScanRBCOld, desktopPath, PowerShellToCopy);
		copyTheFile(TestFilePDFToUploadScanRBCOld, desktopPath, PowerShellToCopy);
		if (hardCopy.equals("Yes")) {
			fileNameWithHardCopy = fileName + "HCY";
			renameTheFiles(desktopPath + "\\SOPTest.XML", fileNameWithHardCopy + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\SOPTest.PDF", fileNameWithHardCopy + ".PDF", PowerShellToRename);
		} else if (hardCopy.equals("No")) {
			fileNameWithHardCopy = fileName + "HCN";
			renameTheFiles(desktopPath + "\\SOPTest.XML", fileNameWithHardCopy + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\SOPTest.PDF", fileNameWithHardCopy + ".PDF", PowerShellToRename);
		}
		// updateTheXML(desktopPath + "\\" + fileName + ".XML", getCurrentDate(),
		// PowerShellToUpdate);
		updateTheXML(desktopPath + "\\" + fileNameWithHardCopy + ".XML", getCurrentDate(), hardCopy,
				PowerShellToUpdate);
		// in above updateTheXML function needs to pass arg for Hard copy Yes or No
		int j = 0;

		for (int iLoop = 1; iLoop < totalRows; iLoop++) {
			/*
			 * String runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop); if
			 * (runStatus.trim().equalsIgnoreCase("Y")) {
			 */
			if (j == 1) {
				j++;
			}
			if (j == 0) {
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + ".XML", NasScanFirstPath, PowerShellToCopy);
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + ".PDF", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(15000);
				currentFileName = fileName + ".PDF";
				fileNames.add(currentFileName);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + ".XML", fileNameWithHardCopy + ++j + ".XML",
						PowerShellToRename);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + ".PDF", fileNameWithHardCopy + j + ".PDF",
						PowerShellToRename);
			} else if (j > 1) {
				int i = j - 1;
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + i + ".XML", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(10000);
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + i + ".PDF", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(10000);
				currentFileName = fileName + i + ".PDF";
				fileNames.add(currentFileName);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + i + ".XML",
						fileNameWithHardCopy + j + ".XML", PowerShellToRename);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + i + ".PDF",
						fileNameWithHardCopy + j + ".PDF", PowerShellToRename);
				j++;

			}
		}

		if (j == 1) {
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".PDF", PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".XML", PowerShellToDelete);
		} else {
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + --j + ".PDF", PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".XML", PowerShellToDelete);
		}
		Thread.sleep(140000);
		return fileNames;
	}

	// under this fxn one new fxn should be created wihch is forsearching
	// escalatedOr On hold esops
	// and run all the scenarios through that
	public String esopEscalatedOrOnHold(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			String escalated = Excelobject.getCellData(reportSheet, "Escalate", count);
			String onHold = Excelobject.getCellData(reportSheet, "Hold", count);
			String unidentifiedEntity = Excelobject.getCellData(reportSheet, "Unidentified Entity", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");

			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			// To run Sprint 33 and 34 us we need this to be uncommented
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			// CESSELECTBTN
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(2000);
			// CLOSE_THE_ML_SLIDER
			/*
			 * try { //waitForElementToBeClickable(SOP.
			 * CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * }catch(NoSuchElementException e) {} catch(WebDriverException e) {}
			 */
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if (!arrowEntity.equals("")) {
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				if (branchPlant.equals("CTCORP")) {
					// CTCORP_RADIO_BUTTON
					assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
					click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

				} else if (branchPlant.equals("NRAI")) {
					// NRAI_RADIO_BUTTON
					assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
					click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");

				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
				selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				// SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				// FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				driver.switchTo().defaultContent();
				assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
				click(SOP.GLYPHICON_HOME, "glyphicon button");
				driver.switchTo().frame("frame1");
				Thread.sleep(2000);

			} else if (!unidentifiedEntity.equals("")) {
				// UNIDENTIFIED_ENTITY_RADIO_BUTTON
				waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
				click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Click on Unidentified entity radio button");
				if (branchPlant.equals("CTCORP")) {
					// BRANCH_PLANT_UNIDENTIFIED_ENTITY
					waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "CTCORP", "Branch Plant drop down");

				} else if (branchPlant.equals("NRAI")) {
					// Select the drop down for NRAI
					waitForElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "NRAI", "Branch Plant drop down");
				}
				// ENTITY_TEXT_BOX
				waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
				type(SOP.ENTITY_TEXT_BOX, unidentifiedEntity, "Entity search text box on ESOP");
				// DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
				assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
				selectByVisibleText(SOP.DOMESTIC_JURISDICTION_SELECTION, "Arizona",
						"Domestic Jurisdiction in CES Page");
				// REP_JURISDICTION_SELECTION
				waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
				assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
				selectByVisibleText(SOP.REP_JURISDICTION_SELECTION, "Arizona", "Rep Jurisdiction in CES Page");
			}
			// CASE_ID_TEXTBOX
			waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(SOP.CASE_ID_TEXTBOX, caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text box");
			// DEFENDANT_TEXT_BOX
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text box");

			waitForElementPresent(SOP.ESOPID, "ESOP ID");
			assertElementPresent(SOP.ESOPID, "ESOP ID");
			esopId = getText(SOP.ESOPID, "ESOP ID");

			if (!escalated.equals("")) {
				// ESCALATION_DETAILS
				waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				// REASON_DRPDWN
				waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(SOP.REASON_DRPDWN, escalationReason, "Escalation reason text box");//
				// ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(SOP.ESCALATION_COMMENTS_TEXTBOX, "Entity escalated", "Escalation text box");
				// ESCALATE_BTN
				waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				click(SOP.ESCALATE_BTN, "Escalate button");
			} else if (!onHold.equals("")) {
				// REASON_FOR_HOLD_TEXTBOX
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On hold text box in CES Page");
				type(SOP.REASON_FOR_HOLD_TEXTBOX, "On hold for verification",
						"Reason for On hold text box in CES Page");
				// ONHOLD_BTN
				waitForElementToBeClickable(SOP.ONHOLD_BTN, "OnHold Button in CES Page");
				assertElementPresent(SOP.ONHOLD_BTN, "OnHold Button in CES Page");
				click(SOP.ONHOLD_BTN, "OnHold Button in CES Page");
			}

		} catch (Exception e) {
		}
		return esopId;
	}

	public void processEscalatedOrOnHoldESOP(String reportSheet, int count, String esopId) throws Throwable {

		try {
			String checkedArrowEntity = "";
			String caseNumber = "";
			String lawSuitType = "";
			String docType = "";
			String plaintiff = "";
			String defendant = "";
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "New Entity Searched", count);
			String relatedLog = Excelobject.getCellData(reportSheet, "Related Log", count);
			String hold = Excelobject.getCellData(reportSheet, "Hold", count);
			// CES_LEFT_NAV_LINK
			waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			click(SOP.CES_LEFT_NAV_LINK, "Click on CES Link in SOP List Page");
			if (!hold.equals("")) {
				// ON_HOLD_LIST_TAB
				waitForElementToBeClickable(SOP.ON_HOLD_LIST_TAB, "OnHoldList button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHoldList button in CES Page");
				click(SOP.ON_HOLD_LIST_TAB, "OnHoldList button in CES Page");
			}
			// FILTERDROPDOWN1
			waitForElementPresent(SOP.FILTERDROPDOWN1, "First Filter in CES Page");
			assertElementPresent(SOP.FILTERDROPDOWN1, "First Filter in CES Page");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "ESOP Id", "First Filter in CES Page");
			// FILTERDROPDOWN2
			waitForElementPresent(SOP.FILTERDROPDOWN2, "Second Filter in CES Page");
			assertElementPresent(SOP.FILTERDROPDOWN2, "Second Filter in CES Page");
			selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Second Filter in CES Page");
			// FILTERTEXTFIELD
			assertElementPresent(SOP.FILTERTEXTFIELD, "Text box in CES Page");
			type(SOP.FILTERTEXTFIELD, esopId, "Text box in CES Page");
			// FILTERGOBTN
			assertElementPresent(SOP.FILTERGOBTN, "Go Button in CES Page");
			click(SOP.FILTERGOBTN, "Go Button in CES Page");
			if (hold.equals("")) {
				// FIRST_CES_SELECT_BUTTON
				waitForElementToBeClickable(SOP.FIRST_CES_SELECT_BUTTON, "First CES select button in CES Page");
				assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES select button in CES Page");
				click(SOP.FIRST_CES_SELECT_BUTTON, "First CES select button in CES Page");
			} else if (!hold.equals("")) {
				waitForElementToBeClickable(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES select button in CES Page");
				assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES select button in CES Page");
				click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES select button in CES Page");
			}
			Thread.sleep(1000);
			// CLOSE_THE_ML_SLIDER
			/*
			 * try { //waitForElementPresent(SOP.
			 * CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * }catch(NoSuchElementException e) {} catch(WebDriverException e) {}
			 */
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if (branchPlant.contains("NRAI")) {

				docType = getText(SOP.SELECTED_DOC_TYPE, "Document Type drop down in CES Page");
			} else if (branchPlant.contains("CTCORP")) {
				lawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
			}
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			// TRACEABLE_MAIL_FIELD
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}
			plaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
			defendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
			caseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			try {
				checkedArrowEntity = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
			} catch (NullPointerException e) {
			}
			if (checkedArrowEntity == null) {
				assertElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Arrow Entity Radio button");
				click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Click on Arrow Entity Radio button");
			}

			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

			if (branchPlant.equals("CTCORP")) {
				// CTCORP_RADIO_BUTTON
				assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
				click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

			} else if (branchPlant.equals("NRAI")) {
				// NRAI_RADIO_BUTTON
				assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
				click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");

			}

			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");

			// SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
			assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
			click(SOP.SEARCH_BTN, "Search button in CES Page");
			Thread.sleep(2000);
			// UNIDENTIFIED_ENTITY_BTN
			List<WebElement> entityNotFound = null;
			try {
				entityNotFound = driver.findElements(SOP.FIRST_ENTITY_IN_SEARCH_RESULT);
			} catch (NoSuchElementException e) {
			}
			if (entityNotFound == null) {
				assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "unidentified Entity button in CES Page");
				click(SOP.UNIDENTIFIED_ENTITY_BTN, "click on unidentified Entity button in CES Page");
				Thread.sleep(2000);

				if (branchPlant.contains("NRAI")) {
					waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					Thread.sleep(1000);
					String newDocType = getText(SOP.SELECTED_DOC_TYPE, "selected Doc type value");
					printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
				} else if (branchPlant.contains("CTCORP")) {
					waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
					Thread.sleep(1000);
					String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
					printMessageInReport(
							"Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);
				}
			} else if (entityNotFound != null) {
				// REP_STATUS_SORT
				waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				// FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
				assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
				click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "click on First entity link in CES Page");
				if (relatedLog.equals("")) {
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(1000);
					driver.switchTo().frame("frame1");
					Thread.sleep(1000);

				} else if (!relatedLog.equals("")) {
					// WORKSHEET_ID_TEXTBOX
					waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					type(SOP.WORKSHEET_ID_TEXTBOX, relatedLog, "Worksheet id text box in CES Page");
					// SEARCH_BTN
					assertElementPresent(SOP.SEARCH_BTN, "Search button in CES Page");
					click(SOP.SEARCH_BTN, "Click on Search button in CES Page");
					// FIRST_WORKSHEET_RADIO_BTN
					waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN,
							"First Worksheet id radio button in Related Worksheet Page");
					assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN,
							"First Worksheet id radio button in Related Worksheet Page");
					click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					// ADD_MANIFEST_BTN
					assertElementPresent(SOP.ADD_MANIFEST_BTN,
							"Add to docket history button in Related Worksheet Page");
					click(SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
					Thread.sleep(1000);
				}
			}
			if (branchPlant.contains("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				Thread.sleep(1000);
				String newDocType = getText(SOP.SELECTED_DOC_TYPE, "selected Doc type value");
				printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
			} else if (branchPlant.contains("CTCORP")) {
				waitForElementPresent(SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
				Thread.sleep(1000);
				String newLawSuitType = getText(SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
				printMessageInReport(
						"Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);
			}
			String newPlaintiff = getText(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
			Thread.sleep(1000);
			String newDefendant = getText(SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
			Thread.sleep(1000);
			String newCaseNumber = getText(SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			// SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			click(SOP.SUBMIT_CES, "Submit button in CES Page");
			printMessageInReport("Previous plaintiff : " + plaintiff + " and new plaintiff : " + newPlaintiff);
			printMessageInReport("Previous defendant : " + defendant + " and new defendant : " + newDefendant);
			printMessageInReport("Previous case number : " + caseNumber + " and new case Number : " + newCaseNumber);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String validatePlaintiffAndDefendantFieldsAreMandatory(String reportSheet, int count) throws Throwable {

		String esopId = null;
		try {

			String plaintiffError = Excelobject.getCellData(reportSheet, "Plaintiff Error", count);
			String defendantError = Excelobject.getCellData(reportSheet, "Defendant Error", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			// CESSELECTBTN
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(3000);
			// CLOSE_THE_ML_SLIDER
			/*
			 * try { //waitForElementToBeClickable(SOP.
			 * CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * click(SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * }catch(NoSuchElementException e) {} catch(WebDriverException e) {}
			 */
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			if (branchPlant.equals("CTCORP")) {
				// CTCORP_RADIO_BUTTON
				assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
				click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

			} else if (branchPlant.equals("NRAI")) {
				// NRAI_RADIO_BUTTON
				assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
				click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");

			}
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
			// SEARCH_BTN
			waitForElementPresent(SOP.SEARCH_BTN, "Search button");
			assertElementPresent(SOP.SEARCH_BTN, "Search button");
			click(SOP.SEARCH_BTN, "Search button");
			// REP_STATUS_SORT
			waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			// FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			driver.switchTo().defaultContent();
			assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
			click(SOP.GLYPHICON_HOME, "glyphicon button");
			waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			List<WebElement> traceableMail = null;
			// TRACEABLE_MAIL_FIELD
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}

			// CASE_ID_TEXTBOX
			waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(SOP.CASE_ID_TEXTBOX, caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text box");
			// DEFENDANT_TEXT_BOX
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text box");

			// SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			click(SOP.SUBMIT_CES, "Click on Submit button in CES Page");
			if (plaintiff.equals("")) {
				waitForElementPresent(SOP.PLAINTIFF_EMPTY_ERROR, "Enter Plaintiff value in CES Page");
				assertElementPresent(SOP.PLAINTIFF_EMPTY_ERROR, "Enter Plaintiff value in CES Page");
				compareStrings(plaintiffError, getText(SOP.PLAINTIFF_EMPTY_ERROR, "Enter Plaintiff value in CES Page"));
			}
			if (defendant.equals("")) {
				// DEFENDANT_EMPTY_ERROR
				waitForElementPresent(SOP.DEFENDANT_EMPTY_ERROR, "Enter Defendant value in CES Page");
				assertElementPresent(SOP.DEFENDANT_EMPTY_ERROR, "Enter Defendant value in CES Page");
				compareStrings(defendantError, getText(SOP.DEFENDANT_EMPTY_ERROR, "Enter Defendant value in CES Page"));
			}

		} catch (Exception e) {
		}
		return esopId.split("\\: ")[1];

	}

	public void changeTheCESFieldOrder() throws Throwable {
		try {
			// ADMIN_TAB
			waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab");
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab");
			click(Admin.ADMIN_TAB, "Click on Admin Tab");
			// MANAGECESMLSLIDERFIELDSLINK
			waitForElementPresent(Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			assertElementPresent(Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			click(Admin.MANAGECESMLSLIDERFIELDSLINK, "Click on Manage CES ML Slider Fields Link");
			// before moving
			// changing DEFENDANT_INDEX -> Law Suit Type
			// String dftIndex = getText(Admin.DEFENDANT_INDEX,"Defendant Index value before
			// moving");
			String dftIndex = getText(Admin.LAWSUIT_SUBTYPE_INDEX, "Defendant Index value before moving");
			// below is used for Law Suit Type
			By newPlaintiff = By.xpath("//ul[@id='sortable3']//li[" + dftIndex + "]");
			// hard codeing the index below
			// PLAINTIFF_CES_ML_SLIDER_FIELD
			// changing PLAINTIFF_CES_ML_SLIDER_FIELD -> LAW_SUIT_TYPE(which is actually
			// Case#
			// waitForElementPresent(Admin.PLAINTIFF_CES_ML_SLIDER_FIELD,"Plaintiff field in
			// CES ML Slider Fields");
			waitForElementPresent(Admin.LAW_SUIT_TYPE, "Plaintiff field in CES ML Slider Fields");
			// DEFENDANT_CES_ML_SLIDER_FIELD
			// waitForElementPresent(Admin.DEFENDANT_CES_ML_SLIDER_FIELD,"Defendant field in
			// CES ML Slider Fields");
			// commenting below
			// draganddrop(Admin.PLAINTIFF_CES_ML_SLIDER_FIELD,newPlaintiff,"Move source to
			// Target");
			draganddrop(Admin.LAW_SUIT_TYPE, newPlaintiff, "Move source to Target");
			Thread.sleep(5000);
			// Below code is committed
			/*
			 * Thread.sleep(2000); String plaintiffIndex =
			 * getText(Admin.PLAINTIFF_INDEX,"Plaintiff Index value after moving"); String
			 * defendantIndex =
			 * getText(Admin.DEFENDANT_INDEX,"Defendant Index value after moving");
			 * waitForElementPresent(Admin.SAVEBTN, "save button");
			 * assertElementPresent(Admin.SAVEBTN, "save button"); click(Admin.SAVEBTN,
			 * "Save Button"); waitForElementPresent(SOP.SOP_LINK_HEADER,
			 * "SOP Link in Header"); assertElementPresent(SOP.SOP_LINK_HEADER,
			 * "SOP Link in Header"); click(SOP.SOP_LINK_HEADER, "SOP link in header");
			 * //CES_LEFT_NAV_LINK
			 * waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page"
			 * ); assertElementPresent(SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			 * click(SOP.CES_LEFT_NAV_LINK,"Click on CES Link in SOP List Page");
			 * waitForElementPresent(SOP.
			 * FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			 * assertElementPresent(SOP.
			 * FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			 * click(SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			 * //ML_SLIDER_FIELDS_CES_PAGE String plaintiffIndexInCESPage =
			 * String.valueOf(returnIndexOfMatchedTextvalue(SOP.ML_SLIDER_FIELDS_CES_PAGE,
			 * "Plaintiff") + 1); String defendantIndexInCESPage =
			 * String.valueOf(returnIndexOfMatchedTextvalue(SOP.ML_SLIDER_FIELDS_CES_PAGE,
			 * "Defendant") + 1); compareStrings(plaintiffIndex,plaintiffIndexInCESPage);
			 * compareStrings(defendantIndex,defendantIndexInCESPage);
			 * driver.switchTo().frame("frame1"); Thread.sleep(2000);
			 */
		} catch (Exception e) {
		}
	}

	public void workSheetContainsPlaintiffAndDefendantValuesAsESOP(String reportSheet, int count, String esopId)
			throws Throwable {
		try {

			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			// FIRST_SOP_CHECKBOX
			searchForESOP(esopId);
			try {
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);

			} catch (NoSuchElementException e) {
			}
			Thread.sleep(5000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(5000);
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			waitForElementPresent(SOP.VIEW_BTN, "View button");
			assertElementPresent(SOP.VIEW_BTN, "View button");
			click(SOP.VIEW_BTN, "View button");
			handlePopUpWindwow();
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(3000);
			WebElement createWs = null;
			try {
				createWs = driver.findElement(SOP.CREATE_WORKSHEET);
				waitForElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			} catch (NoSuchElementException e) {
			}
			if (createWs == null) {
				Thread.sleep(4000);
				selectAndAssignTheFileToTeam();
				Thread.sleep(4000);
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				Thread.sleep(2000);
				String parentWin = driver.getWindowHandle();
				waitForElementPresent(SOP.VIEW_BTN, "View button");
				assertElementPresent(SOP.VIEW_BTN, "View button");
				click(SOP.VIEW_BTN, "View button");
				handlePopUpWindwow();
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}

			Thread.sleep(2000);
			// CERTIFIED_MAIL_NUMBER
			waitForElementPresent(SOP.CERTIFIED_MAIL_NUMBER, "certified mail number text box");
			assertElementPresent(SOP.CERTIFIED_MAIL_NUMBER, "certified mail number text box");
			String traceableMail = getText(SOP.CERTIFIED_MAIL_NUMBER, "certified mail number text box");
			printMessageInReport("Value of Traceable Mail Field : " + traceableMail);
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plantiff text field");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plantiff text field");
			String worksheetPltf = getAttribute(SOP.PLAINTIFF_TEXT_BOX, "value");
			compareStrings(plaintiff, worksheetPltf);
			// DEFENDANT_TEXTFIELD
			waitForElementPresent(SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
			assertElementPresent(SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
			String worksheetDft = getText(SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
			compareStrings(defendant, worksheetDft);
		} catch (Exception e) {
		}
	}

	public void rejectionListForPosssibleRejection(String reportSheet, int count) throws Throwable {
		try {
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// CES_LEFT_NAV_LINK
			waitForElementToBeClickable(SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			click(SOP.CES_LEFT_NAV_LINK, "Click on CES Link in SOP List Page");
			Thread.sleep(1500);
			// REJECTION_LIST_TAB
			List<WebElement> rejectionListTab = null;
			try {
				rejectionListTab = driver.findElements(SOP.REJECTION_LIST_TAB);
				if (rejectionListTab != null) {
					click(SOP.REJECTION_LIST_TAB, "Click on REjection List Tab in CES Page");
					// CREATED_ON_SORTING_LINK
					waitForElementPresent(SOP.CREATED_ON_SORTING_LINK, "Created On link in Rejection List Tab");
					assertElementPresent(SOP.CREATED_ON_SORTING_LINK, "Created On link in Rejection List Tab");
					assertElementPresent(SOP.FILE_NAME_SORTING_LINK, "File Name link in Rejection List Tab");
					assertElementPresent(SOP.ESOP_ID_SORTING_LINK, "File Name link in Rejection List Tab");
					assertElementPresent(SOP.ESCALATED_ON_SORTING_LINK, "File Name link in Rejection List Tab");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down in Rejection List Tab");
					assertElementPresent(SOP.FILTERTEXTFIELD, "Second Filter drop down in Rejection List Tab");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button in Rejection List Tab");
					assertElementPresent(Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First link in Rejection List Tab");
					assertElementPresent(Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous link in Rejection List Tab");
					assertElementPresent(Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next link in Rejection List Tab");
					assertElementPresent(Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last link in Rejection List Tab");
					assertElementPresent(Entity.PSOP_INVOICES_CURRENT_FILTER,
							"Current Filter label in Rejection List Tab");
				}
			} catch (NoSuchElementException e) {
			}
			if (rejectionListTab == null) {

				printMessageInReport("For the Logged in Member there are no permission to Rejection List");
			}
		} catch (Exception e) {
		}

	}

	public void rejectionRulesMaintenanceApplication(String reportSheet, int count) throws Throwable {
		try {

			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			click(SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			// PAGE_TITLE
			waitForElementPresent(SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			assertElementPresent(SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			String pageTitle = getText(SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			// US_RADIO_BTN
			waitForElementPresent(SOP.US_RADIO_BTN, "US Radio button");
			assertElementPresent(SOP.US_RADIO_BTN, "US Radio button");
			waitForElementPresent(SOP.US_LABEL, "US label");
			assertElementPresent(SOP.US_LABEL, "US label");
			// CANADA_RADIO_BTN
			waitForElementPresent(SOP.CANADA_RADIO_BTN, "Canada Radio button");
			assertElementPresent(SOP.CANADA_RADIO_BTN, "canada Radio button");
			waitForElementPresent(SOP.CANADA_LABEL, "Canada label");
			assertElementPresent(SOP.CANADA_LABEL, "canada label");
			waitForElementPresent(SOP.INTERNATIONAL_RADIO_BTN, "International Radio button");
			assertElementPresent(SOP.INTERNATIONAL_RADIO_BTN, "International Radio button");
			waitForElementPresent(SOP.INTERNATIONAL_LABEL, "International label");
			assertElementPresent(SOP.INTERNATIONAL_LABEL, "International label");
			// JURIS_DRP_DWN
			waitForElementPresent(SOP.JURIS_DRP_DWN, "Jurisdiction drop down");
			assertElementPresent(SOP.JURIS_DRP_DWN, "Jurisdiction drop down");
			// ADD_BUTTON
			waitForElementPresent(SOP.ADD_BUTTON, "Add button in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.ADD_BUTTON, "Add button in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.SORT_BY_JURISDICTION_LABEL,
					"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.SORT_BY_JURISDICTION_LABEL,
					"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.SORT_BY_MODIFIED_BY_LABEL,
					"Sort by Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.SORT_BY_MODIFIED_BY_LABEL,
					"Sort by Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.SORT_BY_MODIFIED_DATE_LABEL,
					"Sort by Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.SORT_BY_MODIFIED_DATE_LABEL,
					"Sort by Modified Date in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.TABLE_HEADER_JURISDICTION,
					"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.TABLE_HEADER_JURISDICTION,
					"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.TABLE_HEADER_MODIFIED_BY,
					"Table header Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.TABLE_HEADER_MODIFIED_BY,
					"Table header Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.TABLE_HEADER_MODIFIED_DATE,
					"Table header Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.TABLE_HEADER_MODIFIED_DATE,
					"Table header Modified Date in SOP Rejection Rules Maintenance");
			// FIRST_EDIT_BUTTON
			waitForElementPresent(SOP.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			click(SOP.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			// REJECTION_RULE_DROP_DOWN
			waitForElementPresent(SOP.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(SOP.REJECTION_RULE_DROP_DOWN, "Rejection Rule in SOP Rejection Rules by Jurisdiction");

			if (addEditOrDel.equals("Add")) {
				selectByVisibleText(SOP.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			} else if (addEditOrDel.equals("Edit")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(SOP.REJECTION_RULE1_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(SOP.REJECTION_RULE2_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}
			} else if (addEditOrDel.equals("Delete")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(SOP.REJECTION_RULE1_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
					Thread.sleep(1000);
					handlepopup();
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(SOP.REJECTION_RULE2_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
					Thread.sleep(1000);
					handlepopup();
				}

			}
			// STATUS_TEXT_FIELD
			waitForElementPresent(SOP.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			type(SOP.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
			waitForElementPresent(SOP.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(SOP.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			type(SOP.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
			if (addEditOrDel.equals("Add")) {
				click(SOP.ADD_BTN, "Add button in SOP Rejection Rules by Jurisdiction");
			} else if (addEditOrDel.equals("Edit")) {
				click(SOP.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
			}

		} catch (Exception e) {
		}
	}

	public void selectTheJurisdictionAndEdit(String reportSheet, int count) throws Throwable {
		try {

			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);
			String state = Excelobject.getCellData(reportSheet, "State", count);
			String jurisId = Excelobject.getCellData(reportSheet, "Juris Id", count);
			String ruleType = Excelobject.getCellData(reportSheet, "Rule Type", count);
			String selectJurisdiction = Excelobject.getCellData(reportSheet, "Select Jurisdiction", count);
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			click(SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			// PAGE_TITLE
			waitForElementPresent(SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			assertElementPresent(SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			String pageTitle = getText(SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			if (selectJurisdiction.equals("US")) {
				// US_RADIO_BTN
				waitForElementPresent(Admin.US_RADIO_BTN, "US Radio button");
				assertElementPresent(Admin.US_RADIO_BTN, "US Radio button");
				click(Admin.US_RADIO_BTN, "US Radio button");
			}
			// CANADA_RADIO_BTN
			else if (selectJurisdiction.equals("Canada")) {
				waitForElementPresent(Admin.CANADA_RADIO_BTN, "Canada Radio button");
				assertElementPresent(Admin.CANADA_RADIO_BTN, "canada Radio button");
				click(Admin.CANADA_RADIO_BTN, "canada Radio button");
			} else if (selectJurisdiction.equals("International")) {
				waitForElementPresent(Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
				assertElementPresent(Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
				click(Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
			}
			// ("//span[contains(text(),'Quebec')]/parent::td/following-sibling::td/a/img")
			By editButton = By.xpath("//span[contains(text(),'" + state + "')]/parent::td/following-sibling::td/a/img");
			waitForElementPresent(editButton, "Edit button for the selected State in SOP Rejection Rules Maintenance");
			assertElementPresent(editButton, "Edit button for the selected state in SOP Rejection Rules Maintenance");
			click(editButton, "Edit button for the selected state in SOP Rejection Rules Maintenance");
			// REJECTION_RULE_DROP_DOWN
			waitForElementPresent(Admin.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(Admin.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			if (addEditOrDel.equals("Add")) {
				selectByVisibleText(Admin.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
				waitForElementPresent(Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(Admin.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(Admin.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
				// ADD_BTN
				waitForElementPresent(Admin.ADD_BTN, "Add button in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.ADD_BTN, "Add button in SOP Rejection Rules Maintenance");
				click(Admin.ADD_BTN, "Add button in SOP Rejection Rules Maintenance");
				Thread.sleep(1000);
				ArrayList<String> actionStatus = SQL_Queries.getTheStatusAndActionForRejectionRule(jurisId, ruleType);
				compareStrings(status, actionStatus.get(0));
				compareStrings(action, actionStatus.get(1));
			} else if (addEditOrDel.equals("Edit")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(Admin.REJECTION_RULE1_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(Admin.REJECTION_RULE2_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}
				selectByVisibleText(Admin.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
				waitForElementPresent(Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(Admin.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(Admin.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
				assertElementPresent(Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
				click(Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
				ArrayList<String> actionStatus = SQL_Queries.getTheStatusAndActionForRejectionRule(jurisId, ruleType);
				compareStrings(status, actionStatus.get(0));
				compareStrings(action, actionStatus.get(1));
			} else if (addEditOrDel.equals("Delete")) {

				ArrayList<String> countBeforeDeletingTheRule = SQL_Queries.countBeforeDeletingTheRule(jurisId,
						ruleType);
				if (ruleText.equals("SOS/Arrow Entity Statuses")) {
					click(Admin.REJECTION_RULE1_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
				} else if (ruleText.equals("Post Descriptive - Take or Reject")) {
					click(Admin.REJECTION_RULE2_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
				}
				Thread.sleep(1000);
				handlepopup();
				Thread.sleep(1000);
				printMessageInReport("The count of Rule before deleting : " + countBeforeDeletingTheRule);
				printMessageInReport("The count of Rule after deleting : "
						+ SQL_Queries.countAfterDeletingTheRule(jurisId, ruleType));

			}
		} catch (Exception e) {
		}
	}

	public void rejectionRulesMaintenanceRole(String reportSheet, int count) throws Throwable {
		try {
			String role = Excelobject.getCellData(reportSheet, "Role", count);

			// ADMIN_TAB
			waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			click(Admin.ADMIN_TAB, "Admin Tab in the header");
			// FIRST_FILTER_DRPDWN
			waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
			assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
			selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
			// SECOND_FILTER_DRPDWN
			waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
			assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
			selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
			// FILTER_TEXT_FILED
			waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
			assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
			type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
			// GO_BTN
			waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
			assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
			click(Admin.GO_BTN, "Go Button in Roles Page");
			// FIRST_ROLE_ON_THE_GRID
			waitForElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			click(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			// EDIT_BTN
			waitForElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
			assertElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
			click(Admin.EDIT_BTN, "Edit button link in Roles Page");
			Thread.sleep(1000);
			// need to pass arg for check and un check
			String checkedRjectionRuleMaintenance = null;
			try {

				checkedRjectionRuleMaintenance = getAttribute(Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX, "checked");

			} catch (NoSuchElementException e) {
			}
			// REJECTION_RULE_MAINTENANCE_CHECK_BOX
			assertElementPresent(Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX,
					"Rejection Rules Maintenance check box in Roles Page");
			click(Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX, "Rejection Rules Maintenance check box in Roles Page");
			// SAVEBTN
			waitForElementPresent(Admin.SAVEBTN, "save button link in Roles Page");
			assertElementPresent(Admin.SAVEBTN, "save button link in Roles Page");
			click(Admin.SAVEBTN, "save button link in Roles Page");
			Thread.sleep(1000);
			if (checkedRjectionRuleMaintenance != null) {
				waitForElementPresent(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin");
				assertElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
				compareStrings("No permissions",
						getText(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin"));
			} else if (checkedRjectionRuleMaintenance == null) {
				waitForElementPresent(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin");
				assertElementPresent(Admin.EDIT_BTN, "Edit button link in Roles Page");
				compareStrings("Rejection Rules Maintenance",
						getText(Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin"));
			}
			Thread.sleep(5000);

		} catch (Exception e) {
		}
	}

	public void rejectionRulesMaintenanceAccess(String reportSheet, int count) throws Throwable {
		try {
			String permission = Excelobject.getCellData(reportSheet, "Permission", count);
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			click(Admin.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			Thread.sleep(1000);
			driver.navigate().back();
			Thread.sleep(3000);
			driver.navigate().forward();
			if (permission.equals("Y")) {
				// PAGE_TITLE
				waitForElementPresent(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				assertElementPresent(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				String pageTitle = getText(Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			} else if (permission.equals("N")) {
				// SECURITY_ERROR
				waitForElementPresent(Admin.SECURITY_ERROR, "Rejection Rule Maintenance Page Title");
				// assertElementPresent(Admin.SECURITY_ERROR,"Rejection Rule Maintenance Page
				// Title");
				compareStrings("Security Error Occurred",
						getText(Admin.SECURITY_ERROR, "Rejection Rule Maintenance Page Title"));
			}
		} catch (Exception e) {
		}
	}

	public void helpPageInCESQueue(String reportSheet, int count) throws Throwable {

		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
			if (cesQueue.equals("New")) {
				// UNPROCESSED_COUNT
				waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");

			} else if (cesQueue.equals("Escalated List")) {
				// ESCALATED_LIST_TAB
				waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
				// FIRST_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			}

			else if (cesQueue.equals("OnHold List")) {
				// ON_HOLD_LIST_TAB
				waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// FIRST_ONHOLD_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				// create on filter search for New York SOP Team
			}

			else if (cesQueue.equals("Rejections List")) {
				// REJECTION_LIST_TAB
				waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// REJECTIONS_LIST_FIRST_CES_SELECT
				waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");

			}
			// HELP_PAGE_ICON
			waitForElementPresent(SOP.HELP_PAGE_ICON, "Help Page icon");
			assertElementPresent(SOP.HELP_PAGE_ICON, "Help Page icon");
			click(SOP.HELP_PAGE_ICON, "Help Page icon");
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow();
			// TITLE_CES_HELP_PAGE
			waitForElementPresent(SOP.TITLE_CES_HELP_PAGE, "Help Page Title");
			assertElementPresent(SOP.TITLE_CES_HELP_PAGE, "Help Page Title");
			String helpPageTitle = getText(SOP.TITLE_CES_HELP_PAGE, "Help Page Title");
			compareStrings("Centralized Entity Selection - CES Processing Item tab", helpPageTitle);
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
		}
	}

	public String entitySectionDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			String caseNumber = "";
			int relatedWorksheet = 0;
			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String caseNum2 = Excelobject.getCellData(reportSheet, "New Case Number", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
			String rejectionReason = Excelobject.getCellData(reportSheet, "Rejection Reason", count);
			String notRejecting = Excelobject.getCellData(reportSheet, "Reason for Not Rejecting", count);
			String error = Excelobject.getCellData(reportSheet, "Error Message", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String reject = Excelobject.getCellData(reportSheet, "Reject", count);
			String onHold = Excelobject.getCellData(reportSheet, "On Hold", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			// String worksheetType = Excelobject.getCellData(reportSheet, "WorkSheet Type",
			// count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			if (levelOfUser.equals("Level1")) {
				// CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
				// UNPROCESSED_COUNT
				waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				Thread.sleep(2000);
				driver.switchTo().frame("frame1");
				Thread.sleep(3000);
			}

			else if (!levelOfUser.equals("Level1")) {
				if (cesQueue.equals("New")) {
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");
					click(SOP.FILTERGOBTN, "Go Button");
					Thread.sleep(1000);
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
					//the below change needs to be commented before any push
					//Optimized flow testing
					//selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "DSSOP", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");
					click(SOP.FILTERGOBTN, "Go Button");

					try {
						WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
						waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(SOP.CLEARBTN, "Clear Button");
						click(SOP.CLEARBTN, "Clear Button");
						waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
						assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
						selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
						waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
						waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
						assertElementPresent(SOP.FILTERGOBTN, "Go Button");
						click(SOP.FILTERGOBTN, "Go Button");
						Thread.sleep(1000);
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					Thread.sleep(1000);

					waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				} else if (!cesQueue.equals("New")) {
					// CES_LEFT_NAV_LINK
					waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
					assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
					click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
					// CES_PRODUCTIVITY_TAB
					waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

					if (cesQueue.equals("Escalated List")) {
						// ESCALATED_LIST_TAB
						waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
						assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
						click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
						// FIRST_CES_SELECT_BUTTON
						waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					}

					else if (cesQueue.equals("OnHold List")) {
						// ON_HOLD_LIST_TAB
						waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
						assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
						click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
						// FIRST_ONHOLD_CES_SELECT_BUTTON
						waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,
								"First CES Select Button in CES Page");
						assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
						// create on filter search for New York SOP Team
					}

					else if (cesQueue.equals("Rejections List")) {
						// REJECTION_LIST_TAB
						waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
						assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
						click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
						// REJECTIONS_LIST_FIRST_CES_SELECT
						waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT,
								"First CES Select Button in CES Page");
						assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT,
								"First CES Select Button in CES Page");
						click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
					}
				}
				Thread.sleep(2000);
				// System.out.println("Reached Here ewjdjkjlkwdlkjw");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				driver.switchTo().frame("frame1");
				System.out.println("Switched to Frame 1");
				Thread.sleep(3000);
				// TRAINGLE_ICON_ARROW_ENTITY
				// waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
				// Expaned");
				assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				// INTAKEMETHODVALUE
				waitForElementPresent(SOP.INTAKEMETHODVALUE, "intake method value");
				String cdsop = getText(SOP.INTAKEMETHODVALUE, "intake method value");
				if (!arrowEntity.equals("")) {
					waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
					if (arrowEntityCheckedAttribute == null) {
						click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					}
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

					if (!cdsop.equals("CDSOP")) {
						if (branchPlant.equals("CTCORP")) {
							// CTCORP_RADIO_BUTTON
							waitForElementPresent(SOP.CTCORP_RADIO_BUTTON,
									"CTCORP Radio Button on search Entity criteria page");
							assertElementPresent(SOP.CTCORP_RADIO_BUTTON,
									"CTCORP Radio Button on search Entity criteria page");
							click(SOP.CTCORP_RADIO_BUTTON,
									"click on CTCORP Radio Button on search Entity criteria page");

						} else if (branchPlant.equals("NRAI")) {
							// NRAI_RADIO_BUTTON
							waitForElementPresent(SOP.NRAI_RADIO_BUTTON,
									"NRAI Radio Button on search Entity criteria page");
							assertElementPresent(SOP.NRAI_RADIO_BUTTON,
									"NRAI Radio Button on search Entity criteria page");
							click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
						}
					}
					// ENTITY_NAME_TEXTFIELD
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					if (cdsop.equals("CDSOP")) {
						selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "Bank of America", "Entity search text box on ESOP");
					} else if (!cdsop.equals("CDSOP")) {
						selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
					}
					// SEARCH_BTN
					waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					assertElementPresent(SOP.SEARCH_BTN, "Search button");
					click(SOP.SEARCH_BTN, "Search button");
					int entitySearchCount = 0;
					// ENTITY_SEARCH_RESULT_COUNT
					waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
					entitySearchCount = Integer
							.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
					if (entitySearchCount == 0) {
						// Click on unidentified entity
						waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						String disabledUnEntity = "";
						try {
							disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
							System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
						} catch (NullPointerException e) {
						}
						if (disabledUnEntity == null) {
							click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						}
						Thread.sleep(1500);
						System.out.println("REached here in line 6420");
						try {
							if (disabledUnEntity.equals("true")) {
								// SEARCH_AGAIN_BUTTON
								waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								// CANCEL_BUTTON
								waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
								assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
								click(SOP.CANCEL_BUTTON, "Cancel Button");
							}
						} catch (NullPointerException e) {
						}
						System.out.println("REached here in line 6431");
						Thread.sleep(2000);
						// below will be a go ahead when the value for unidentified Entity above is
						// selected
						String unEntityRadioSelected = "";
						try {
							unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
						} catch (NoSuchElementException e) {
						} catch (NullPointerException e) {
						}
						Thread.sleep(1000);
						try {
							if (unEntityRadioSelected == null) {
								click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
							}
						} catch (NullPointerException e) {
						}
						// ENTITY_TEXT_BOX
						waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
						assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
						type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
						// DOMESTIC_JURISDICTION_SELECTION
						waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
						assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
						selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
						// REP_JURISDICTION_SELECTION
						waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
						try {
							// waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
							// assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
							driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
							Thread.sleep(1500);
							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						} catch (NoSuchElementException e) {
						}
						// DOCUMENT_TYPE_DROPDWN
						try {
							// waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
							// assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
							driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
							selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
						} catch (NoSuchElementException e) {
						}
						// PLAINTIFF_TEXT_BOX
						waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
						// DEFENDANT_TEXT_BOX
						waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

						waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
						assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
						type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					} else if (entitySearchCount != 0) {
						// REP_STATUS_SORT
						waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
						assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
						click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
						// FIRST_ENTITY_IN_SEARCH_RESULT
						waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						// CONTINUE_BUTTON
						try {
							List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
							if (action.size() > 0) {

								click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
							}
						} catch (NoSuchElementException e) {

						}
						if (!caseNum1.equals("")) {
							// CASEID_TEXTBOX
							waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							if (cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX, "19342919", "Case number Search text box");
							} else if (!cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX, caseNum1, "Case number Search text box");
							}
							// SEARCH_BTN
							waitForElementPresent(SOP.SEARCH_BTN, "Search button");
							assertElementPresent(SOP.SEARCH_BTN, "Search button");
							click(SOP.SEARCH_BTN, "Search button");
							// TOTAL_RECORDS_RELATED_WORKSHEET
							waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,
									"Related worksheet search results");
							relatedWorksheet = Integer.parseInt(
									getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET, "Related worksheet search results"));
							Thread.sleep(1000);
							if (relatedWorksheet == 0) {

								click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
								Thread.sleep(2000);
								// RADIO_PRESENTATION_BUTTON
								String repChecked = "";
								try {
									repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked");
								} catch (NoSuchElementException e) {
								}
								if (repChecked == null) {
									// REP_JURISDICTION_SELECTION
									waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
									assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
									selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
								}
								Thread.sleep(2000);
								try {

									driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
									selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law suit type in CES Page");

								} catch (NoSuchElementException e) {
								}
								Thread.sleep(2000);
								try {
									driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
									selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
								} catch (NoSuchElementException e) {
								}
								Thread.sleep(3000);
								waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
								assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
								type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text box in CES Page");

								waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
								assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
								type(SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text box CES Page");

								waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
								assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
								type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");

							} else if (relatedWorksheet != 0) {
								// FIRST_WORKSHEET_RADIO_BTN
								waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN,
										"First Worksheet id radio button in Related Worksheet Page");
								assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN,
										"First Worksheet id radio button in Related Worksheet Page");
								click(SOP.FIRST_WORKSHEET_RADIO_BTN,
										"First Worksheet id radio button in Related Worksheet Page");
								// ADD_TO_DOCKET_HISTORY_BUTTON
								waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
								assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
								click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
								Thread.sleep(2000);
								waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
								caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");
								if (cdsop.equals("CDSOP")) {
									compareStrings(caseNumber, "19342919");
								}

								else if (!cdsop.equals("CDSOP")) {

									compareStrings(caseNumber, caseNum1);
								}
							}
						}
						if (!caseNum2.equals("")) {
							// SELECT_BUTTON_IN_RELATED_LOG
							waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG,
									"Select button in Related Log section");
							assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG,
									"Select button in Related Log section");
							click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
							// CASEID_TEXTBOX
							waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							if (cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX, "19342919", "Case number Search text box");
							} else if (!cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX, caseNum2, "Case number Search text box");
							}

							// SEARCH_BTN
							waitForElementPresent(SOP.SEARCH_BTN, "Search button");
							assertElementPresent(SOP.SEARCH_BTN, "Search button");
							click(SOP.SEARCH_BTN, "Search button");
							// FIRST_WORKSHEET_RADIO_BTN
							waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN,
									"First Worksheet id radio button in Related Worksheet Page");
							assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN,
									"First Worksheet id radio button in Related Worksheet Page");
							click(SOP.FIRST_WORKSHEET_RADIO_BTN,
									"First Worksheet id radio button in Related Worksheet Page");
							// ADD_TO_DOCKET_HISTORY_BUTTON
							waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
							Thread.sleep(2000);
							waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
							caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");
							if (cdsop.equals("CDSOP")) {
								compareStrings(caseNumber, "19342919");
							} else if (!cdsop.equals("CDSOP")) {

								compareStrings(caseNumber, caseNum2);
							}
						}

						if (caseNum1.equals("")) {
							Thread.sleep(1000);
							driver.switchTo().defaultContent();
							assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
							click(SOP.GLYPHICON_HOME, "glyphicon button");
							Thread.sleep(3000);
							driver.switchTo().frame("frame1");
							// PLAINTIFF_TEXT_BOX
							waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
							assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
							type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
							// DEFENDANT_TEXT_BOX
							waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
							assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
							type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
							try {
								driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
								selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
							} catch (NoSuchElementException e) {
							}
							// DOCUMENT_TYPE_DROPDWN
							try {
								driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
								selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
							} catch (NoSuchElementException e) {
							}
						}
					}
				}
			}
			Thread.sleep(3000);
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			// Below one check can be applied if attorney and court modification needs to be
			// done - 1476
			if (!attorneyName.equals("")) {
				// RADIO_BUTTON_ATTORNEYNONE
				String attorneyNoneAttribute = "";

				try {
					attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
							"Radio button for Existing Attorney Sender in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
							"Radio button for Existing Attorney Sender in CES Page");
					// DROP_DOWN_ATTORNEY_SENDER_NAME
					waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
					assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
					selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
				} catch (NoSuchElementException e) {
				}
			}

			if (!courtName.equals("")) {
				try {
					String courtNoneAttribute = "";
					courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,
							"Radio button for Existing Court in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					// DROP_DOWN_COURT_NAME
					waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
					assertElementPresent(SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
					selectByIndex(SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
				} catch (NoSuchElementException e) {
				}
				/*
				 * if(attorneyNoneAttribute == null) { //TEXT_BOX_ATTORNEYNAME
				 * waitForElementPresent(SOP.
				 * TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
				 * assertElementPresent(SOP.
				 * TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
				 * type(SOP.TEXT_BOX_ATTORNEYNAME,
				 * attorneyName,"text field for Attorney Sender Name"); } if(courtNoneAttribute
				 * == null) { //TEXT_BOX_COURTNAME
				 * waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
				 * assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
				 * type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");
				 * 
				 * }
				 */
			}

			// Below one code is to escalate as Possible REjection
			if (!escalationReason.equals("")) {
				// Below one condition needs to be set if the L2 user processing CES from
				// Escalated List
				// then update to possible rejection click can be done from here.
				if ((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List"))
						&& escalationReason.equals("Update to Possible Rejection")) {
					// UPDATE_TO_POSSIBLE_REJECTION
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION, "Update to Possible Rejection button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION, "Update to Possible Rejection button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION, "Update to Possible Rejection button");

				}
				if (cesQueue.equals("Escalated List")
						&& escalationReason.equals("Update to Possible Rejection & GetNext")) {
					// UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,
							"Update to Possible Rejection & GetNext button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,
							"Update to Possible Rejection & GetNext button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,
							"Update to Possible Rejection & GetNext button");
					Thread.sleep(5000);
				}
				if (!escalationReason.equals("Update to Possible Rejection")
						&& !escalationReason.equals("Update to Possible Rejection & GetNext")) {
					// ESCALATION_DETAILS
					waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					// REASON_DRPDWN
					waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(SOP.REASON_DRPDWN, escalationReason, "Escalation reason text box");
					// ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(SOP.ESCALATION_COMMENTS_TEXTBOX, "Could be a Possible Rejection", "Escalation text box");
					// ESCALATE_BTN
					waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					click(SOP.ESCALATE_BTN, "Escalate button");
				}
			} else if (rejectionReason.equals("") && reject.equals("Y")) {
				// REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				// REJECT_REASON_EMPTY_ERROR
				waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR, "Error message in CES Page");
				assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR, "Error message in CES Page");
				String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR, "Error message in CES Page");
				compareStrings(error, errorMessage);

			} else if (!rejectionReason.equals("") && !reject.equals("")) {
				// REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
				if (!notRejecting.equals("")) {
					// REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING, notRejecting,
							"Reason for not Rejecting drop down");
					// REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					// ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED, "Error message in CES Page");
					assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED, "Error message in CES Page");
					String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,
							"Error message in CES Page");
					compareStrings(error, errorMessage);
				} else if (notRejecting.equals("")) {
					if (attorneyName.equals("")) {
						// ATTORNEY_SENDER_NONE_SPECIFIED
						waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					// commenting below as List of WebElemets not required
					// List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {
						traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
						if (traceableMail != null) {
							type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					// HARD_COPY_DELIVERY
					waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					// REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
					// REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);
					if (hardCopy.equals("No") && error.equals("")) {
						String parentWin = driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow();
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1])
								.get(0);
						assertTextContains(letterPopup, rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}
					// ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if (attorneyName.equals("")) {
						waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR, "Error message in CES Page");
						assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR, "Error message in CES Page");
						String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,
								"Error message in CES Page");
						compareStrings(error, errorMessage);
					}
				}
			} else if (escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
				if (!rejectionReason.equals("")) {
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
					// REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING, notRejecting, "Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					// TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if (traceableMail != null) {
							type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					// SUBMIT_CES
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");
					// SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED, "Error message in CES Page");
					assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED, "Error message in CES Page");
					String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED, "Error message in CES Page");
					compareStrings(error, errorMessage);
				} else if (rejectionReason.equals("")) {
					List<WebElement> traceableMail = null;
					// TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if (traceableMail != null) {

							type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					/*
					 * Below Code is addded on 1/21 as part of GCNBO-1740 To handle the onhold
					 * submit scenario when the Escalation Reason for the esop is Possible Rejection
					 */
					if (cesQueue.equals("OnHold List")) {
						// ESCALATION_DETAILS
						waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						// ESCALATION_REASON
						waitForElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						assertElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						String escalationReasonInOnHold = getText(SOP.ESCALATION_REASON, "Escalation Reason");

						if (escalationReasonInOnHold.equals("Possible Rejection")) {
							waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							selectByIndex(SOP.REASON_FOR_NOT_REJECTING, 1, "Reject Reason drop down");
							Thread.sleep(2000);

						}
					}
					/* Till here the code change made as on 1/21 */

					// REASON_FOR_NOT_REJECTING
					if (cesQueue.equals("Rejections List")) {
						waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING, notRejecting, "Reject Reason drop down");
						Thread.sleep(2000);
					}
					// SUBMIT_CES
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");
					Thread.sleep(4000);
				}
			} else if (!onHold.equals("")) {
				// REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
						"Reason for On Hold Text box");
				// ONHOLD_BTN
				waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				click(SOP.ONHOLD_BTN, "On Hold button");
			}

		} catch (Exception e) {
		}
		return esopId.split("\\: ")[1];
	}

	public String rejectESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);

			if (!cesQueue.equals("New")) {
				moveESOPFromNewQueueToDiffCESQueue(reportSheet, count);
			}

			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode))
					.get(0);
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			if (cesQueue.equals("New")) {
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					waitForElementPresent(SOP.CLEARBTN, "Clear Button");
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");
					searchForESOP(esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				// SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							click(SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");

				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					/*String attorneyNoneAttribute = "";

					try {
						attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
						waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						// DROP_DOWN_ATTORNEY_SENDER_NAME
						waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
						assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
						selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					} catch (NoSuchElementException e) {
					} */
					
					try {

						waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
						assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
						click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
						
						//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
					    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");
						
						//ATTORNEY_ADDRESS_LINE_ONE
					    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
						
						//CITY_NAME
						waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
						
						//ATTORNEY_STATE_NAME
						waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
						
						//ATTORNEY_ZIP_CODE
						waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");

					} catch (NoSuchElementException e) {
					}
					
				}

				if (!courtName.equals("")) {
					try {
						String courtNoneAttribute = "";
						courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");
						waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,
								"Radio button for Existing Court in CES Page");
						click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
						// DROP_DOWN_COURT_NAME
						waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
						assertElementPresent(SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
						selectByIndex(SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				// HARD_COPY_DELIVERY
				waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				compareStrings(hardCopyDeliveryFlag, getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value"));
				// REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
				// REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				Thread.sleep(5000);

			}
			if (hardCopyDeliveryFlag.equals("No")) {
				String parentWin = driver.getWindowHandle();
				Thread.sleep(2000);
				handlePopUpWindwow();
				String letterPopup = driver.getCurrentUrl();
				String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
				assertTextContains(letterPopup, rejectLog);
						
				//Below one more fxn will be added to validate the Format for both NRAI and CTCORP and as per LST and DocType
				String toaInWorksheet = SQL_Queries.toaInWorksheet(esopId).get(0);
				if(branchPlant.equals("CTCORP")) {
					//TITLE_OF_ACTION_CTCORP
					waitForElementPresent(SOP.TITLE_OF_ACTION_CTCORP, "Title of Action in Rejection Letter");
					assertElementPresent(SOP.TITLE_OF_ACTION_CTCORP, "Title of Action in Rejection Letter");
					String rejectionLetterTOA = getText(SOP.TITLE_OF_ACTION_CTCORP, "Title of Action in Rejection Letter");
					compareStrings(toaInWorksheet,rejectionLetterTOA);
				}
				else if(branchPlant.equals("NRAI")) {
					//TITLE_OF_ACTION_NRAI
					waitForElementPresent(SOP.TITLE_OF_ACTION_NRAI, "Title of Action in Rejection Letter");
					assertElementPresent(SOP.TITLE_OF_ACTION_NRAI, "Title of Action in Rejection Letter");
					String rejectionLetterTOA = getText(SOP.TITLE_OF_ACTION_NRAI, "Title of Action in Rejection Letter");
					compareStrings(toaInWorksheet,rejectionLetterTOA);
				}
				
				driver.close();
				driver.switchTo().window(parentWin);
			}
		} catch (Exception e) {
		}
		return esopId;
	}

	public void moveESOPFromNewQueueToDiffCESQueue(String reportSheet, int count) throws Throwable {

		String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
		String moveNewCES = Excelobject.getCellData(reportSheet, "Move New CES To", count);
		String esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], 157001)
				.get(0);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		waitForElementPresent(SOP.CLEARBTN, "Clear Button");
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOP(esopId);
		try {
			WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
			waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			searchForESOP(esopId);
		} catch (NoSuchElementException e) {
		}
		Thread.sleep(1000);
		waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		if (!moveNewCES.equals("OnHold")) {
			// ESCALATION_DETAILS
			waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			// REASON_DRPDWN
			waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
			assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
			//click(SOP.REASON_DRPDWN, "Escalation reason text box");
			System.out.println("fetched from the Test Data " + moveNewCES);
			//Thread.sleep(1000);			
			selectByVisibleText(SOP.REASON_DRPDWN, moveNewCES, "Escalation reason text box");
			// ESCALATION_COMMENTS_TEXTBOX
			waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			type(SOP.ESCALATION_COMMENTS_TEXTBOX, "Moving it to " + moveNewCES, "Escalation text box");
			// ESCALATE_BTN
			waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
			assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
			click(SOP.ESCALATE_BTN, "Escalate button");
		}

		else if (moveNewCES.equals("OnHold")) {
			// REASON_FOR_HOLD_TEXTBOX
			waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
			assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
			type(SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
					"Reason for On Hold Text box");
			// ONHOLD_BTN
			waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
			assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
			click(SOP.ONHOLD_BTN, "On Hold button");
		}
	}

	public void rejectedLogHardCopyRequiredSOPTeamDashboard(String reportSheet, int count, String esopId)
			throws Throwable {

		try {
			teamSOPDashboard(reportSheet, count);
			String branchPlant = SQL_Queries.getTheBranchPlantForTheESOPs(esopId).get(0);
			String rejectedLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
			if (branchPlant.equals("92001")) {
				//REJECT_AND_HARDCOPY_ASSIGNED_TO
				// REJECT_AND_HARDCOPY_LINK
				waitForElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO,
						"Reject and Hard Copy Required For CTCORP");
				assertElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO,
						"Reject and Hard Copy Required For CTCORP");
				click(TeamSOPDashboard.REJECT_AND_HARDCOPY_ASSIGNED_TO, "Reject and Hard Copy Required For CTCORP");
			} else if (branchPlant.equals("92003")) {
				// REJECT_AND_HARDCOPY_LINK_NRAI
				waitForElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI,
						"Reject and Hard Copy Required For NRAI");
				assertElementPresent(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI,
						"Reject and Hard Copy Required For NRAI");
				click(TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI, "Reject and Hard Copy Required For NRAI");
			}
			searchForLog(rejectedLog);
			// FIRST_SOP_ID
			waitForElementPresent(TeamSOPDashboard.FIRST_SOP_ID,
					"Reject Log with hard cop required is present in the Team SOP Dashboard");
			assertElementPresent(TeamSOPDashboard.FIRST_SOP_ID,
					"Reject Log with hard cop required is present in the Team SOP Dashboard");

		} catch (NoSuchElementException e) {
		} catch (Exception e) {
		}
	}

	public void searchForLog(String log) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "Log #", "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, log, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}

	public void compareTheCurrentStatus(String reportSheet, int count, String esopId) throws Throwable {
		String currentStatus = "";
		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		ArrayList<String> statusCode = new ArrayList<String>();
		try {
			Thread.sleep(5000);
			statusCode = SQL_Queries.getTheCurrentStatusCode(esopId);
			currentStatus = statusCode.get(0);
			compareStrings(currentStatus, status);
		} catch (IndexOutOfBoundsException e) {

		}
	}

	public void compareExpeditedWorkflow(String reportSheet, int count, String esopId) throws Throwable {

		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		String expeditedFlag = Excelobject.getCellData(reportSheet, "Expedited Flag", count);
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		ArrayList<String> expeditedLog = new ArrayList<String>();


			if (expeditedFlag.equals("")) {
				expeditedFlag = null;
			}
			if (workflow.equals("")) {

				workflow = null;
			}
//The below iteration is changed to 15
			for(int i =0 ; i < 15 ; i++) {
			expeditedFlag = SQL_Queries.expeditedLogWorkflow(esopId).get(1);
			if(expeditedFlag == null) {
			Thread.sleep(20000);
			}
			else {
				break;
			}
			}
			try {
			expeditedLog = SQL_Queries.expeditedLogWorkflow(esopId);
			compareStrings(status, expeditedLog.get(0));
			compareStrings(expeditedFlag, expeditedLog.get(1));
			compareStrings(workflow, expeditedLog.get(2));
		} catch (Exception e) {}
		
	}

	public void compareTheReasonForNotRejection(String reportSheet, int count, String esopId) throws Throwable {
		String currentStatus = "";
		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		ArrayList<String> statusCode = new ArrayList<String>();
		try {
			Thread.sleep(10000);
			statusCode = SQL_Queries.getTheReasonForNotRejection(esopId);
			currentStatus = statusCode.get(0);
			compareStrings(currentStatus, status);
		} catch (IndexOutOfBoundsException e) {

		}
	}

	public void cesProductivityGrandTotalAndTier3() throws Throwable {

		try {

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			// CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
			// CES_PRODUCTIVITY_TITLE
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title");
			compareStrings("CES Productivity", getText(SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title"));
			// TIER3_HEADER
			waitForElementPresent(SOP.TIER3_HEADER, "CES Productivity Tier 3");
			assertElementPresent(SOP.TIER3_HEADER, "CES Productivity Tier 3");
			compareStrings("Tier 3", getText(SOP.TIER3_HEADER, "CES Productivity Tier 3"));
			// GRAND_TOTALS_LABEL
			waitForElementPresent(SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals");
			assertElementPresent(SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals");
			compareStrings("Grand Totals", getText(SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals"));
			// TOTAL_COUNT_GRAND_TOTALS
			waitForElementPresent(SOP.TOTAL_COUNT_GRAND_TOTALS, "CES Productivity Total count");
			assertElementPresent(SOP.TOTAL_COUNT_GRAND_TOTALS, "CES Productivity Total Count");
			/*
			 * String total_Count = SQL_Queries.getTheTotalCountOfCompletedESOPs().get(0);
			 * compareStrings(total_Count,getText(SOP.TOTAL_COUNT_GRAND_TOTALS,
			 * "Total Count"));
			 */
		} catch (Exception e) {

		}
	}

	// Below one for GCNBO-1283
	public void assignmentHistoryAndAudtitTrail(String esopId, String worksheetId) throws Throwable {

		try {
			String parentWindow = driver.getWindowHandle();
			// WORKSHEET_PROFILE_ASSIGNMENTHISTORY
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,
					"Worksheet profile Assignment History link");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,
					"Worksheet profile Assignment History link");
			click(WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY, "Worksheet profile Assignment History link");
			// below all the scenarios will come which needs to be validated
			handlePopUpWindwow();
			// DOCKET_HISTORY_CES_AUDIT_TRAIL
			waitForElementPresent(WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL, " Docket History in Audit Trail");
			assertElementPresent(WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL, " Docket History in Audit Trail");
			String docketHistoryCES = getText(WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL,
					" Docket History in Audit Trail");
			String attorneyWorksheet = getText(WorksheetCreate.ATTORNEY_WORKSHEET_AUDIT_TRAIL,
					" Attorney in Audit Trail");
			String courtWorksheet = getText(WorksheetCreate.COURT_WORKSHEET_AUDIT_TRAIL, " Court in Audit Trail");
			String plaintiffWorksheet = getText(WorksheetCreate.PLAINTIFF_WORKSHEET_AUDIT_TRAIL,
					" Plaintiff in Audit Trail");
			String defendantWorksheet = getText(WorksheetCreate.DEFENDANT_WORKSHEET_AUDIT_TRAIL,
					" Defendant in Audit Trail");
			driver.close();
			driver.switchTo().window(parentWindow);
			if (attorneyWorksheet.equals("")) {
				attorneyWorksheet = null;
			}
			if (courtWorksheet.equals("")) {
				courtWorksheet = null;
			}
			if (plaintiffWorksheet.equals("")) {
				plaintiffWorksheet = null;
			}
			if (defendantWorksheet.equals("")) {
				defendantWorksheet = null;
			}
			if (docketHistoryCES.equals("")) {
				docketHistoryCES = null;
			}
			ArrayList<String> fieldsModifiedInWorksheet = SQL_Queries.fieldsModifiedInWorksheet(worksheetId);
			ArrayList<String> getTheRelatedLogForCompletedESOPs = SQL_Queries.getTheRelatedLogForCompletedESOPs(esopId);
			compareStrings(docketHistoryCES, getTheRelatedLogForCompletedESOPs.get(0));
			compareStrings(attorneyWorksheet, fieldsModifiedInWorksheet.get(0));
			compareStrings(courtWorksheet, fieldsModifiedInWorksheet.get(1));
			compareStrings(defendantWorksheet, fieldsModifiedInWorksheet.get(2));
			compareStrings(plaintiffWorksheet, fieldsModifiedInWorksheet.get(3));
			// Need to comment below
		} catch (Exception e) {

		}
	}

	public void searchForESOP(String esopId) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "ESOP Id", "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}
	
	public void searchForESOPWithHash(String esopId) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "ESOP #", "Filter drop down");
		waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}

	public void partialAndFullCaseSearch(String reportSheet, int count) throws Throwable {

		String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
		String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String caseNum = Excelobject.getCellData(reportSheet, "Case Number", count);

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		if (!cesQueue.equals("New")) {
			moveESOPFromNewQueueToDiffCESQueue(reportSheet, count);
		}
		if (cesQueue.equals("New")) {
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(1000);
		} else if (!cesQueue.equals("New")) {
			// CES_LEFT_NAV_LINK
			waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
			assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
//			click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

			if (cesQueue.equals("Escalated List")) {
				// ESCALATED_LIST_TAB
				waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
				// FIRST_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			}

			else if (cesQueue.equals("OnHold List")) {
				// ON_HOLD_LIST_TAB
				waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// FIRST_ONHOLD_CES_SELECT_BUTTON
				waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				// create on filter search for New York SOP Team
			}

			else if (cesQueue.equals("Rejections List")) {
				// REJECTION_LIST_TAB
				waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// REJECTIONS_LIST_FIRST_CES_SELECT
				waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
			}
		}
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		System.out.println("Switched to Frame 1");
		Thread.sleep(3000);
		waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
		String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
		if (arrowEntityCheckedAttribute == null) {
			click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
		}
		waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		if (branchPlant.equals("CTCORP")) {
			// CTCORP_RADIO_BUTTON
			waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
			assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
			click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

		} else if (branchPlant.equals("NRAI")) {
			// NRAI_RADIO_BUTTON
			waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
			assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
			click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
		}

		// ENTITY_NAME_TEXTFIELD
		waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
		assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
		click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
		selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
		// SEARCH_BTN
		waitForElementPresent(SOP.SEARCH_BTN, "Search button");
		assertElementPresent(SOP.SEARCH_BTN, "Search button");
		click(SOP.SEARCH_BTN, "Search button");

		// REP_STATUS_SORT
		waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
		assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
		click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
		// FIRST_ENTITY_IN_SEARCH_RESULT
		waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
		assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
		click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
		// CONTINUE_BUTTON
		try {
			List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
			if (action.size() > 0) {

				click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
			}
		} catch (NoSuchElementException e) {

		}
		// CASEID_TEXTBOX
		waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
		assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
		type(SOP.CASEID_TEXTBOX, caseNum, "Case number Search text box");
		// here we need to type case#
		// SEARCH_BTN
		waitForElementPresent(SOP.SEARCH_BTN, "Search button");
		assertElementPresent(SOP.SEARCH_BTN, "Search button");
		click(SOP.SEARCH_BTN, "Search button");
		Thread.sleep(1000);
		// CASE_NUMBER_RELATED_WORKSHEET
		waitForElementPresent(SOP.CASE_NUMBER_RELATED_WORKSHEET, "Related worksheet search results");
		String caseNumber = getText(SOP.CASE_NUMBER_RELATED_WORKSHEET, "Related worksheet search results");
		assertTextContains(caseNumber, caseNum);

	}

	public void submitTheDSSOPWithNewStatus(String reportSheet, int count) throws Throwable {

		String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
		for (int i = 0; i < count; i++) {
			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button"); 
			/*waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			click(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");*/
			
			/*String esopId = SQL_Queries.getTheNewStatusESOP(31008).get(0);
			searchForESOP(esopId);*/
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");

			//click(SOP.FILTERGOBTN, "Go Button");
			//if (levelOfUser.equals("Level1")) {
				// CES_LEFT_NAV_LINK
/*		    waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");*/
				// CES_PRODUCTIVITY_TAB
				
			/*	 waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				 assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				 click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");*/
		//	} 
					/*waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");*/
/*
				 waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");*/
			
				// REJECTION_LIST_TAB
				/*	waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");*/
				// UNPROCESSED_COUNT
		/*		waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");*/
				Thread.sleep(2000);
				//waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				//assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				// String esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				//Thread.sleep(500);
				//driver.switchTo().frame("frame1");
				//Thread.sleep(500);
			//}
			//Thread.sleep(1000); 
			//Thread.sleep(1000);
		/*	waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");*/
	/*		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "DSSOP", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);*/
			
			//driver.findElement(By.xpath("//a[contains(text(),'Last')]")).click();
			// Thread.sleep(2000);	
	/*		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "Received Juris", "Filter drop down");
			Thread.sleep(500);
			waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
			assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
			selectByVisibleText(SOP.FILTERDROPDOWN2, "contains", "Filter drop down2");
			Thread.sleep(550);
			waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
			assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
			selectBySendkeys(SOP.FILTERTEXTFIELD, "Alberta", "Filter text field");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");*/
			
			// REJECTIONS_LIST_FIRST_CES_SELECT
/*			waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
			assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
			click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");*/
						
			
			// FIRST_CES_SELECT_BUTTON
			/*waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");*/
			
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			/*waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			*/
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(1000);			
			click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");			
			selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "Bank of America", "Entity search text box on ESOP");
			click(SOP.SEARCH_BTN, "Search button");
			click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			Thread.sleep(1000);
			driver.switchTo().defaultContent();
			click(SOP.GLYPHICON_HOME, "glyphicon button");
			//waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			//assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			//click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			// REASON_DRPDWN
			//waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
			//assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
			//click(SOP.REASON_DRPDWN, "Escalation reason text box");
		     //System.out.println("fetched from the Test Data " + "Entity Issues-missing rep");
			//selectByVisibleText(SOP.REASON_DRPDWN, "Entity Issues-missing rep", "Escalation reason text box");
			//selectByVisibleText(SOP.REASON_DRPDWN, "Possible Rejection", "Escalation reason text box");
			// ESCALATION_COMMENTS_TEXTBOX
			//waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			//assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			//type(SOP.ESCALATION_COMMENTS_TEXTBOX, "Moving it to " + "Entity Issues-missing rep", "Escalation text box");
			// ESCALATE_BTN
		/*	waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
			assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
			click(SOP.ESCALATE_BTN, "Escalate button");*/
	/*		String unEntityRadioSelected = "";
			try {
				unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
			} catch (NoSuchElementException e) {
			} catch (NullPointerException e) {
			}
			Thread.sleep(1000);
			try {
				if (unEntityRadioSelected == null) {
					click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
				}
			} catch (NullPointerException e) {
			}*/
			// ENTITY_TEXT_BOX
	/*		waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
			// DOMESTIC_JURISDICTION_SELECTION
			waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
			// REP_JURISDICTION_SELECTION
			waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");*/
			
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			try {
				// waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				
				// assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
				Thread.sleep(500);
				selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 1, "Law Suit Type drop down");
			} catch (NoSuchElementException e) {
			}
			// DOCUMENT_TYPE_DROPDWN
			try {
				// waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				// assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
				selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
			} catch (NoSuchElementException e) {
			}
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(SOP.PLAINTIFF_TEXT_BOX, "pltf", "plaintiff text box");
			// DEFENDANT_TEXT_BOX
			waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(SOP.DEFENDANT_TEXT_BOX, "dft", "defendant text box");
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}
/*			waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
			assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
			selectByIndex(SOP.REASON_FOR_NOT_REJECTING, 1, "Reject Reason drop down");*/
			// SUBMIT_CES
			waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
			click(SOP.SUBMIT_CES, "Submit button in CES Page");
			// REASON_FOR_HOLD_TEXTBOX
			/*waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
			assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
			type(SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
					"Reason for On Hold Text box");*/
			// ONHOLD_BTN
			/*waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
			assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
			click(SOP.ONHOLD_BTN, "On Hold button");*/		
		}
	}

	// added on 12/28 to move CES for Performance test data preparation
	public void moveTheCES(String reportSheet, int count) throws Throwable {

		for (int i = 0; i < count; i++) {

			String moveNewCES = Excelobject.getCellData(reportSheet, "Move New CES To", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(SOP.CLEARBTN, "Clear Button");
			assertElementPresent(SOP.CLEARBTN, "Clear Button");
			click(SOP.CLEARBTN, "Clear Button");

			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(SOP.FILTERDROPDOWN1, "File Name", "Filter drop down");
			Thread.sleep(500);
			waitForElementToBeClickable(SOP.FILTERDROPDOWN2, "Filter drop down2");
			assertElementPresent(SOP.FILTERDROPDOWN2, "Filter drop down2");
			selectByVisibleText(SOP.FILTERDROPDOWN2, "contains", "Filter drop down2");
			Thread.sleep(550);
			waitForElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
			assertElementPresent(SOP.FILTERTEXTFIELD, "Filter text field");
			selectBySendkeys(SOP.FILTERTEXTFIELD, "PerfTestHCN", "Filter text field");
			waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(SOP.FILTERGOBTN, "Go Button");
			click(SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);

			Thread.sleep(1000);
			waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			if (!moveNewCES.equals("OnHold")) {
				// ESCALATION_DETAILS
				waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				// REASON_DRPDWN
				waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(SOP.REASON_DRPDWN, moveNewCES, "Escalation reason text box");
				// ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(SOP.ESCALATION_COMMENTS_TEXTBOX, "Moving it to " + moveNewCES, "Escalation text box");
				// ESCALATE_BTN
				waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
				click(SOP.ESCALATE_BTN, "Escalate button");
			}

			else if (moveNewCES.equals("OnHold")) {
				// REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
						"Reason for On Hold Text box");
				// ONHOLD_BTN
				waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				click(SOP.ONHOLD_BTN, "On Hold button");
			}
		}
	}

	public void qualityRandomiserSetup(String reportSheet, int count) throws Throwable {

		String qualityLimit = Excelobject.getCellData(reportSheet, "Quality Limit", count);
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		// QUALITY_MAINTENANCE
		waitForElementPresent(SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		assertElementPresent(SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		click(SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		// QUALITY_RANDOMISER_SETUP
		waitForElementPresent(SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		assertElementPresent(SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		click(SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		// QUALITY_LIMIT_PER_DAY
		waitForElementPresent(SOP.QUALITY_LIMIT_PER_DAY, "Quality limit per day in left nav bar");
		assertElementPresent(SOP.QUALITY_LIMIT_PER_DAY, "Quality limit per day in left nav bar");
		type(SOP.QUALITY_LIMIT_PER_DAY, qualityLimit, "Quality limit per day in left nav bar");
		// SAVE_BTN
		click(SOP.SAVE_BTN, "Quality limit per day in left nav bar");

		if (Integer.valueOf(qualityLimit) >= 0) {

			String qualityLimitCountSet = SQL_Queries.criteriaLimitCount().get(0);
			compareStrings(qualityLimit, qualityLimitCountSet);
		}
		try {
			driver.findElement(SOP.INVALID_LIMIT_ERROR);
			String error = getText(SOP.INVALID_LIMIT_ERROR, "Invalid Limit error message");
			compareStrings("Please provide valid Limit.", error);
		} catch (NoSuchElementException e) {
		}

	}

	public void deleteTheSOPs(String reportSheet, int count) throws Throwable {

		String sopFrom = Excelobject.getCellData(reportSheet, "SOP From", count);

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");

		if (sopFrom.equals("SOP > 15 days")) {
			// SOP_15DAYS_TAB
			waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			click(SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");

		}
		// FIRST_ESOP_ID_SELECTED
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		String firstESOPId = getText(SOP.FIRST_ESOP_ID_SELECTED, "First Esop Id selected");
		waitForElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		// DELETE_SOPS
		assertElementPresent(SOP.DELETE_SOPS, "Delete button is SOP List page");
		click(SOP.DELETE_SOPS, "Delete button in SOP List page");
		handlepopup();
		Thread.sleep(700);
		// Below validate the Data is not present in the tables for the esop
		String esopCountInCESInbox = SQL_Queries.getTheCountInSOPCesInbox(firstESOPId).get(0);
		String esopCountInESOPInbox = SQL_Queries.getTheCountInESOPInbox(firstESOPId).get(0);
		// getTheFieldsForTheESOPs
		compareStrings("0", esopCountInCESInbox);
		compareStrings("0", esopCountInESOPInbox);
	}

	public void metaDataInTheRejectedLog(String esopId) throws Throwable {

		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		// WOKSHEET_SEARCH_LEFT_NAV_LINK
		waitForElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "worksheet search link in left nav");
		assertElementPresent(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "assert worksheet search link in left nav");
		click(SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "click on worksheet search link in left nav");
		// CLASSIC_SEARCH_BTN
		waitForElementPresent(SOP.CLASSIC_SEARCH_BTN, "Classic search button in Worksheet Search Criteria Page");
		assertElementPresent(SOP.CLASSIC_SEARCH_BTN, "assert Classic search button in Worksheet Search Criteria Page");
		click(SOP.CLASSIC_SEARCH_BTN, "click on Classic search button in Worksheet Search Criteria Page");
		String worskheetId = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
		// WORKSHEET_ID_TEXTBOX
		waitForElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "Id text box in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_ID_TEXTBOX, "assert Id text box in Classic Worksheet Search Criteria Page");
		type(SOP.WORKSHEET_ID_TEXTBOX, worskheetId, "type Id in text box in Classic Worksheet Search Criteria Page");
		// WORKSHEET_SEARCH_BTN
		waitForElementPresent(SOP.WORKSHEET_SEARCH_BTN, "Search button in Classic Worksheet Search Criteria Page");
		assertElementPresent(SOP.WORKSHEET_SEARCH_BTN,
				"assert Search button in Classic Worksheet Search Criteria Page");
		click(SOP.WORKSHEET_SEARCH_BTN, "click Search button in Classic Worksheet Search Criteria Page");

		// METADATA
		waitForElementPresent(SearchWorksheet.METADATA, "Meta data in Worksheet profile Page");
		assertElementPresent(SearchWorksheet.METADATA, "assert Meta data in Worksheet profile Page");
		String metaData = getText(SearchWorksheet.METADATA, "get the text for Meta data in Worksheet profile Page");
		String damageAmount = metaData.split("\\ Damage Amount : ")[1].split("\\ ,")[0].split("")[0];
		String timeSensitive = metaData.split("\\ Time Sensitive : ")[1].split("\\,")[0].split("")[0];
		String secondReview = metaData.split("\\Second Review : ")[1].split("\\,")[0].split("")[0];
		String shortAnswerDate = metaData.split("\\Short Answer : ")[1].split("\\ ")[0].split("")[0];
		System.out.println(damageAmount);
		System.out.println(timeSensitive);
		System.out.println(secondReview);
		System.out.println(shortAnswerDate);
		if (shortAnswerDate.equals("-")) {
			shortAnswerDate = "N";
		}
		ArrayList<String> metaDataInRejectedLog = SQL_Queries.metaDataInRejectionLog(esopId);
		compareStrings(damageAmount, metaDataInRejectedLog.get(0));
		compareStrings(timeSensitive, metaDataInRejectedLog.get(1));
		compareStrings(secondReview, metaDataInRejectedLog.get(2));
		compareStrings(shortAnswerDate, metaDataInRejectedLog.get(3));
	}

	/*public String submitESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
					.get(0);
			if (!cesQueue.equals("New") && esopId == null) {
				moveESOPFromNewQueueToDiffCESQueue(reportSheet, count);
			}

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//Below change is Part of Sprint 53 changes
		      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
		     //Till here Sprint 53 changes
			if (cesQueue.equals("New")) {
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					//Below change is Part of Sprint 53 changes
				      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
				     //Till here Sprint 53 changes
					waitForElementPresent(SOP.CLEARBTN, "Clear Button");
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");
					searchForESOP(esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				
				//INCLUDE_ALL_REP_ASSUMED_BTN
				waitForElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				assertElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
								
				// SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							click(SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					
					 * waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					 * assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					 * click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");

					 Code changed during Accelerated Log Project 
					//Below try and catch block added as part of Sprint 53 scripting
					//from line 8891 to 9024
					String parentWindow = driver.getWindowHandle();
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow();
						driver.close();
						driver.switchTo().window(parentWindow);
						}
					}catch(NoSuchSessionException e ) {
						
					}
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					click(SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow();
						driver.close();
						driver.switchTo().window(parentWindow);
						Thread.sleep(1000);
						driver.switchTo().frame("frame1");
						}
					}catch(NoSuchSessionException e ) {
						
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					try {

						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						if (!lawSuit.equals("")) {
							System.out.println("Reached here with lawsuit value : " + lawSuit);
							selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");

						}

						else {

							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						}
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {
						attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
						waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						// DROP_DOWN_ATTORNEY_SENDER_NAME
						waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
						assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
						selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						String courtNoneAttribute = "";
						courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");
						waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT,
								"Radio button for Existing Court in CES Page");
						click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
						// DROP_DOWN_COURT_NAME
						waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
						assertElementPresent(SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
						selectByIndex(SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				
				 * //HARD_COPY_DELIVERY waitForElementPresent(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * assertElementPresent(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * compareStrings(hardCopyDeliveryFlag,getText(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value"));
				 
				List<WebElement> reasonForNotRejection = null;
				// REASON_FOR_NOT_REJECTING
				try {
					reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
					if (reasonForNotRejection != null) {
						selectByIndex(SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
					}
				} catch (NoSuchElementException e) {
				}
				// SUBMIT_CES
				waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
				assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
				click(SOP.SUBMIT_CES, "Submit button in CES");
				Thread.sleep(5000);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return esopId;
	}
*/
	
	public String submitESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
			try {
			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode))
					.get(0);
			}catch(Exception e) {}
			if (!cesQueue.equals("New") && esopId.equals("")) {
				moveESOPFromNewQueueToDiffCESQueue(reportSheet, count);
				esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode))
						.get(0);
			}

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			//Below change is Part of Sprint 53 changes
		      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
		     //Till here Sprint 53 changes
			if (cesQueue.equals("New")) {
				waitForElementPresent(SOP.CLEARBTN, "Clear Button");
				assertElementPresent(SOP.CLEARBTN, "Clear Button");
				click(SOP.CLEARBTN, "Clear Button");
				searchForESOP(esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					//Below change is Part of Sprint 53 changes
				      waitForElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  assertElementPresent(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  compareStrings(getText(SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
				     //Till here Sprint 53 changes
					waitForElementPresent(SOP.CLEARBTN, "Clear Button");
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");
					searchForESOP(esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				
				//INCLUDE_ALL_REP_ASSUMED_BTN
				waitForElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				assertElementPresent(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				click(SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
								
				// SEARCH_BTN
				waitForElementPresent(SOP.SEARCH_BTN, "Search button");
				assertElementPresent(SOP.SEARCH_BTN, "Search button");
				click(SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
							click(SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					/*
					 * waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					 * assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					 * click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 */
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
					click(SOP.GLYPHICON_HOME, "glyphicon button");

					/* Code changed during Accelerated Log Project */
					//Below try and catch block added as part of Sprint 53 scripting
					//from line 8891 to 9024
					String parentWindow = driver.getWindowHandle();
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow();
						driver.close();
						driver.switchTo().window(parentWindow);
						}
					}catch(NoSuchSessionException e ) {
						
					}
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
					click(SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow();
						driver.close();
						driver.switchTo().window(parentWindow);
						Thread.sleep(1000);
						driver.switchTo().frame("frame1");
						}
					}catch(NoSuchSessionException e ) {
						
					}


					waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					try {

						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						if (!lawSuit.equals("")) {
							System.out.println("Reached here with lawsuit value : " + lawSuit);
							selectByVisibleText(SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
                           
						}

						else {

							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						}
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
					// PLAINTIFF_TEXT_BOX
					Thread.sleep(700);
					waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					Thread.sleep(700);
					waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {

						waitForElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney radio button in wroksheet step 2 page");
						assertElementPresent(WorksheetCreate.USE_THIS_ATTORNEY,"eUse this Attorney radio button in wroksheet step 2 page");
						click(WorksheetCreate.USE_THIS_ATTORNEY,"Use this Attorney button in wroksheet step 2 page");
						
						//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
						assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"Text box to enter attorney name");
					    type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"Text box to enter attorney name");
						
						//ATTORNEY_ADDRESS_LINE_ONE
					    waitForElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    assertElementPresent(SOP.ATTORNEY_ADDRESS_LINE_ONE,"Address Line 1 text box");
					    type(SOP.ATTORNEY_ADDRESS_LINE_ONE,"700 Broadway, New York, NY, 10003","Address Line 1 text box");	
						
						//CITY_NAME
						waitForElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						assertElementPresent(SOP.ATTORNEY_CITY_NAME,"City Name text box");
						type(SOP.ATTORNEY_CITY_NAME,"New York","City Name text box");
						
						//ATTORNEY_STATE_NAME
						waitForElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						assertElementPresent(SOP.ATTORNEY_STATE_NAME,"State Name text box");
						type(SOP.ATTORNEY_STATE_NAME,"NY","State Name text box");
						
						//ATTORNEY_ZIP_CODE
						waitForElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ATTORNEY_ZIP_CODE,"Zip code text box");
						type(SOP.ATTORNEY_ZIP_CODE,"10003","Zip code text box");

					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						//USE_THIS_COURT
						waitForElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
						assertElementPresent(SOP.USE_THIS_COURT,"Use this court radio button");
						click(SOP.USE_THIS_COURT,"Use this court radio button");
						//COURT_NAME_TEXT_BOX
						waitForElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
						assertElementPresent(SOP.COURT_NAME_TEXT_BOX,"Court NAme");
						type(SOP.COURT_NAME_TEXT_BOX,courtName,"Court NAme");
						//ADDRESS_LINE_ONE
						waitForElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
						assertElementPresent(SOP.ADDRESS_LINE_ONE,"Address Line 1 text box");
						type(SOP.ADDRESS_LINE_ONE,"Harris County Courthouse, 301 Fannin St., Room 400","Address Line 1");
						//CITY_NAME
						waitForElementPresent(SOP.CITY_NAME,"City Name text box");
						assertElementPresent(SOP.CITY_NAME,"City Name text box");
						type(SOP.CITY_NAME,"Houston","City Name text box");
						//STATE_NAME
						waitForElementPresent(SOP.STATE_NAME,"State Name text box");
						assertElementPresent(SOP.STATE_NAME,"State Name text box");
						type(SOP.STATE_NAME,"TX","State Name text box");
						//ZIP_CODE
						waitForElementPresent(SOP.ZIP_CODE,"Zip code text box");
						assertElementPresent(SOP.ZIP_CODE,"Zip code text box");
						type(SOP.ZIP_CODE,"77550","Zip code text box");

					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				/*
				 * //HARD_COPY_DELIVERY waitForElementPresent(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * assertElementPresent(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * compareStrings(hardCopyDeliveryFlag,getText(SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value"));
				 */
				List<WebElement> reasonForNotRejection = null;
				// REASON_FOR_NOT_REJECTING
				try {
					reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
					if (reasonForNotRejection != null) {
						selectByIndex(SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
					}
				} catch (NoSuchElementException e) {
				}
				//CES_INTERNAL_COMMENTS
    			waitForElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
    			assertElementPresent(SOP.CES_INTERNAL_COMMENTS, "Ces internal comments ins CES page");
    			type(SOP.CES_INTERNAL_COMMENTS,"CES internal Comments added through Selenium Automation", "Ces internal comments ins CES page");
				// SUBMIT_CES
				waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
				assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES");
				click(SOP.SUBMIT_CES, "Submit button in CES");
				Thread.sleep(5000);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return esopId;
	}

	
	public String actionItemExecution(String esopId) throws Throwable {

		String expeditedLog = "";
		try {
			Thread.sleep(30000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(expeditedLog);

		// ACTION_ITEMS
		waitForElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		assertElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		click(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		// RETAIN_SOP_STATUS
		waitForElementPresent(SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		assertElementPresent(SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		String retainSOPStatus = getText(SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		compareStrings(retainSOPStatus, "Retained");
		// ISOP_STATUS
		waitForElementPresent(SearchWorksheet.ISOP_STATUS, "ISOP Status");
		assertElementPresent(SearchWorksheet.ISOP_STATUS, "ISOP Status");
		String isopStatus = getText(SearchWorksheet.ISOP_STATUS, "ISOP Status");
		compareStrings(isopStatus, "Executed");
		
		return expeditedLog;
	}

	public void logInActionItemFailure(String esopId) throws Throwable {

		String expeditedLog = "";
		try {
			Thread.sleep(2000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		// ACTION_ITEM_FAILURES
		waitForElementPresent(SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures link in left nav bar");
		assertElementPresent(SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures link in left nav bar");
		click(SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures in left nav bar");

		searchForLog(expeditedLog);
		// FIRST_WORKSHEET
		waitForElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		assertElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		click(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");

		// ACTION_ITEMS
		waitForElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		assertElementPresent(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		click(SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");

		// ACTION_ITEMS_NO_RECORDS
		waitForElementPresent(SearchWorksheet.ACTION_ITEMS_NO_RECORDS, "No Records found in Action Items Page");
		assertElementPresent(SearchWorksheet.ACTION_ITEMS_NO_RECORDS, "No Records found in Action Items Page");
		
		//WORKSHEET_PROFILE_LINK
		waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet Profile link");
		assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK, "workheet Profile link");
		click(SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet Profile link");
		
	}

	public void sopWorkflow(String reportSheet, int count, String esopId) throws Throwable {
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		String logNumber = "";
		
		//Below check is added as part of dev ops Sprint 3 changes and this should be merged post GM merge
		for(int i=0 ;i<10; i++) {			
		String isHandlerProcessed = SQL_Queries.handlerProcessedESOP(esopId).get(0);
		if(isHandlerProcessed.equals("N")) {
		Thread.sleep(10000);
		}
		else {
			break;
		}		
		}
		try {
			Thread.sleep(1000);
			logNumber = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(logNumber);

		// SOP_WORKFLOW
		waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");

		if (workflow.equals("151001")) {

			compareStrings("Advanced",workflowInWorksheet);

		}

		else if (workflow.equals("151002")) {

			compareStrings( "Accelerated",workflowInWorksheet);
		}
		
		//this function needs to be modify to accommodate the new SOP Workflow checks
		//below function is modified and added below checks as part of NPD devops Sprint 2 
		if (workflow.equals("151004")) {

			compareStrings("Optimized Manual",workflowInWorksheet);

		}

		else if (workflow.equals("151005")) {

			compareStrings("Optimized",workflowInWorksheet);
		}
		
	}

	public void actionItemFailuresUI() throws Throwable {
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
        //ACTION_ITEM_FAILURES
		waitForElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		assertElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		click(ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		//ACTION_ITEM_FAILURE_PAGE_TITLE
		waitForElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title");
		assertElementPresent(ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title");
		compareStrings("Action Item Failures", getText(ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title"));
		//SORT_BY
		waitForElementPresent(ActionItemsFailure.SORT_BY, "Sort By label");
		assertElementPresent(ActionItemsFailure.SORT_BY, "Sort By label");
		//RECEIVED_DATE_SORT
		waitForElementPresent(ActionItemsFailure.RECEIVED_DATE_SORT, "Received Date sort link");
		assertElementPresent(ActionItemsFailure.RECEIVED_DATE_SORT, "Received Date sort link");
		//ERROR_REASON_SORT
		waitForElementPresent(ActionItemsFailure.ERROR_REASON_SORT, "Error reason sort link");
		assertElementPresent(ActionItemsFailure.ERROR_REASON_SORT, "Error reason sort link");
		//ASSIGNED_TO_SORT
		waitForElementPresent(ActionItemsFailure.ASSIGNED_TO_SORT, "Assigned to sort link");
		assertElementPresent(ActionItemsFailure.ASSIGNED_TO_SORT, "Assigned to sort link");
		//BRANCH_PLANT_SORT
		waitForElementPresent(ActionItemsFailure.BRANCH_PLANT_SORT, "Branch Plant sort link");
		assertElementPresent(ActionItemsFailure.BRANCH_PLANT_SORT, "Branch Plant sort link");
		//EXPORT_BUTTON
		waitForElementPresent(ActionItemsFailure.EXPORT_BUTTON, "Export button in Action Items failure page");
		assertElementPresent(ActionItemsFailure.EXPORT_BUTTON, "Export button in Action Items failure page");
		//HELP_PAGE_ICON
		waitForElementPresent(ActionItemsFailure.HELP_PAGE_ICON, "Help Page icon in Action Item Failures page");
		assertElementPresent(ActionItemsFailure.HELP_PAGE_ICON, "Help Page icon in Action Item Failures page");
		//CURRENT_FILTER
		waitForElementPresent(ActionItemsFailure.CURRENT_FILTER, "Current filter label in Action Item Failures page");
		assertElementPresent(ActionItemsFailure.HELP_PAGE_ICON, "current filter label  in Action Item Failures page");
		//Below one more check needs to be added for 
		
		
	}

	public void bulkWorksheetInSOPHub(String reportSheet, int count) throws Throwable {
		
		
     String worksheetId = Excelobject.getCellData(reportSheet, "Accelerated Log", count);	
      
	//SELECT
	waitForElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
	assertElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
	click(SopHub.SELECT, "Select button in Customer Search Page");
	//SOP_HUB_LINK
	waitForElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	assertElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	click(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	for(int i = 0; i<10; i++) {
	//LOG_SEARCH_TEXT_FIELD
	waitForElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");
	assertElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");		
	type(SopHub.LOG_SEARCH_TEXT_FIELD,worksheetId, "Log Search test field in SOP Received Page");
	//SEARCH_BUTTON
	waitForElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
	assertElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
	click(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");	
	WebElement noSuchWorksheet = null;
	try {
		
		noSuchWorksheet = driver.findElement(By.xpath("//span[contains(text(),'There are no entries in this list.')]"));
		//HOME_BUTTON
		assertElementPresent(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
		click(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
		
	}catch(NoSuchElementException e) {
		
	}	
	if(noSuchWorksheet != null) {
	 
		Thread.sleep(12000);
	}
	else {
		break;
	}
   }
	//CT_LOG_NUMBER
	waitForElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
	assertElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
	compareStrings(worksheetId,getText(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub"));
}
	
	/*public void transmittalDataVerification(String reportSheet, int count, String esopId) throws Throwable{
		
		//As per the optimized Transmittal 1.2 , below Assertions:
		//compareStrings(plaintiff,plaintiffInTransmittal);
	    //compareStrings(defendant,defendantInTransmittal);
		//will be chaged to Title of Action Transmittal
		String recipientId = Excelobject.getCellData(reportSheet, "Recipient Id", count);
		String parentWindow = driver.getWindowHandle();
		//FIRST_TRANSMITTAL_BUTTON
		waitForElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		assertElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		click(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");		
		handlePopUpWindwow();
		String url = driver.getCurrentUrl(); 		
		String pdfData = getPDFContent(url);
	  // below querry the DB to get the below items
		String caseNumber = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(0);
		String plaintiff = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(1);
		String defendant = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(2);
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
		String lawSuitType = SQL_Queries.getTheLawSuitTypeInCESInbox(esopId).get(0);
		String recipientName = SQL_Queries.getTheRecipientName(recipientId).get(0);
		if(courtNameInCES == null) {
			courtNameInCES = "None Specified";
		}
	   String [] worksheetFields = {"TITLE OF ACTION:",			   			        
			        "COURT/AGENCY: "+courtNameInCES,
			        "Case # "+ caseNumber,
			        "NATURE OF ACTION: " + lawSuitType,
	                "ACTION ITEMS: CT has retained the current log, Retain Date:",
	                 };
	   
	    	   
	   for(String str : worksheetFields) {
	   if(pdfData.contains(str)){
	       flag =  true;                 
	       SuccessReport("Text : " , str + " is present in PDF");
	   }
	   else {
			failureReport("Text : " , str + " is not present in PDF");
	 }		
	}
	 
	    String plaintiffInTransmittal = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[0].replaceAll("[^\\x00-\\x7F]", "");
	    String defendantInTransmittal = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[1].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "");	    
	    //System.out.println(pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0]);
	    String recipientInTransmital = pdfData.split("TO: ")[1].split("\n")[0].split("\\R")[0].replace(" ", "");
	    //System.out.println(recipientInTransmital);	   
	    compareStrings(recipientInTransmital.toUpperCase(),recipientName.toUpperCase().replace(" ", ""));	    
	    compareStrings(plaintiff,plaintiffInTransmittal);
	    compareStrings(defendant,defendantInTransmittal);
		driver.close();
		driver.switchTo().window(parentWindow);
	}
*/
public void transmittalDataVerification(String reportSheet, int count, String esopId) throws Throwable{
		
		//As per the optimized Transmittal 1.2 , below Assertions:
		//compareStrings(plaintiff,plaintiffInTransmittal);
	    //compareStrings(defendant,defendantInTransmittal);
		//will be chaged to Title of Action Transmitta
		String branchPlant = Excelobject.getCellData(reportSheet,"Branch Plant", count);
		String consolidated = Excelobject.getCellData(reportSheet,"Consolidated", count);
		String parentWindow = driver.getWindowHandle();
		//FIRST_TRANSMITTAL_BUTTON
		waitForElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		assertElementPresent(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		click(WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");		
		handlePopUpWindwow();
		String url = driver.getCurrentUrl(); 		
		String pdfData = getPDFContent(url);
	  // below querry the DB to get the below items
		String caseNumber = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(0);
		String toaInWorksheet = SQL_Queries.toaInWorksheet(esopId).get(0);
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
		String lawSuitType = SQL_Queries.getTheLawSuitTypeInCESInbox(esopId).get(0);		
		if(courtNameInCES == null) {
			courtNameInCES = "None Specified";
		}
		if(caseNumber == null) {
			caseNumber = "None Specified";
		}
		String toaInTransmittal = "";
		String toaLabel = "";
		String court = "";
		String noaOrDoc = "";
		if(branchPlant.equals("CTCORP")){
		toaLabel = "TITLE OF ACTION: ";
		court = "COURT/AGENCY: "+courtNameInCES;
		noaOrDoc = "NATURE OF ACTION: ";
		
		}
		else if(branchPlant.equals("NRAI")){
		toaLabel = "Title of Action:";
		court = "Court of Jurisdiction/Case Number: "+courtNameInCES;
		noaOrDoc = "Document";
		}		
		
	   String [] worksheetFields = {toaLabel,			   			        
			        court,
			        noaOrDoc
	                 };
	   
	    	   
	   for(String str : worksheetFields) {
	   if(pdfData.contains(str)){
	       flag =  true;                 
	       SuccessReport("Text : " , str + " is present in PDF");
	   }
	   else {
			failureReport("Text : " , str + " is not present in PDF");
	 }		
	}
	
	    toaInTransmittal = pdfData.split(toaLabel)[1].split("\n")[0].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "");
	    if(consolidated.equals("Yes")) {
	    	
	    	toaInTransmittal = toaInTransmittal.split(" \\(0")[0];
	    }
	    compareStrings(toaInTransmittal,toaInWorksheet);
		driver.close();
		driver.switchTo().window(parentWindow);
	}

	
	public void expeditedTransmissionLog(String esopId) throws Throwable {
		
		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		//EXPEDITED_TRANSMISSIONS
		waitForElementPresent(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		assertElementPresent(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		click(SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		//CLEARBTN
		assertElementPresent(SOP.CLEARBTN, "Clear Button");
		click(SOP.CLEARBTN, "Clear Button");
		searchForESOPWithHash(esopId);
		
		//FIRST_ESOP_IN_EXPEDITED_TRANSMISSION
		waitForElementPresent(SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION, "First ESOP in Expedited Transmission Page");
		assertElementPresent(SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION, "First ESOP in Expedited Transmission Page");
		compareStrings(esopId, getText(SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION,"First ESOP in Expedited Transmission Page"));
		//FIRST_LOG_IN_EXPEDITED_TRANSMISSION
		waitForElementPresent(SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION, "First Log in Expedited Transmission Page");
		assertElementPresent(SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION, "First Log in Expedited Transmission Page");
		compareStrings(expeditedLog, getText(SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION,"First Log in Expedited Transmission Page"));
	}

	public void createAndExecuteActionItem(String reportSheet,int count,String esopId) throws Throwable {

		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
        String  lawsuitType = Excelobject.getCellData(reportSheet, "Law Suit", count);
		String  hardCopyRequired = Excelobject.getCellData(reportSheet, "Hard Copy DI", count);
		String  entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
		
		waitForElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		
		if(hardCopyRequired.equals("No")) {		
	   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
	   int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI,lawsuitType);
	   System.out.println("the index sent is : " + matchedIndexLawSuit);
	   //USE_BUTTON_IN_LAWSUIT
	   clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);	   
	   
	   //SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
	   waitForElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
	   assertElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
	   click(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");		
		
		}
		else if(hardCopyRequired.equals("Yes")) {
		//VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI
		int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI,lawsuitType);
		//USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES
		 clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
		 
		 //EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL
		 waitForElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 click(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 //COMMENTS_DRPDWN
		 waitForElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 selectByVisibleText(SOP.COMMENTS_DRPDWN,"Hard Copy Required","Execute Manual in SOP Papers with Transmittal");
		 //CONTINUE_BUTTON
		 waitForElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 assertElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 click(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 try {
			 WebElement createPackage = driver.findElement(By.id("btnCreatePackage"));
			 createPackage.click();
		 }catch(NoSuchElementException e) {}
		 //SAVE_BTN
		 assertElementPresent(Entity.SAVE_BTN, "Save button");
		 click(Entity.SAVE_BTN, "Save button");
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");		 				 
		}

	    //EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL
	   waitForElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   assertElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   click(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	
	   for(int i = 0 ; i<10; i++) {
	   ArrayList<String> executedBy = SQL_Queries.executedByInActionItem(expeditedLog);
	   if(!executedBy.get(0).equals("1166") || !executedBy.get(1).equals("1166")) {
		   Thread.sleep(10000);
	    }
	   else {
		   break;
	       }
	   }
	   //WORKSHEET_PROFILE_LINK
	   waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   click(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   
	   //POST_STATUS
	   assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
	   String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
	   compareStrings(postStatus, "Posted");
	   
	}

	public void unexecuteActionItems(String esopId) throws Throwable{
		
		String expeditedLog = "";
		try {
			Thread.sleep(30000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(expeditedLog);
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		
		//UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
		waitForElementPresent(SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		assertElementPresent(SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		click(SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		//UNEXECUTE_COMMENTS_TEXT_BOX
		waitForElementPresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		assertElementPresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		type(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Unexecute Retain SOP","Text box for unexecute comments");
		//UNEXECUTE_ACTION_ITEM_BUTTON
		waitForElementPresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		assertElementPresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		click(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		//UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL
		waitForElementPresent(SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");
		assertElementPresent(SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");
		click(SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");		
		waitForElementPresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		assertElementPresent(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		type(SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Unexecute ISOP","Text box for unexecute comments");
		waitForElementPresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		assertElementPresent(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		click(SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");

		   for(int i = 0 ; i<4; i++) {
		   ArrayList<String> executedBy = SQL_Queries.executedByInActionItem(expeditedLog);		   
		   if(executedBy.get(0) != null || executedBy.get(1) != null) {
			   Thread.sleep(10000);
		    }
		   else {
			   break;
		       }
		   }
		   //WORKSHEET_PROFILE_LINK
		   waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		   assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		   click(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		   
		   //POST_STATUS
		   assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		   String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		   compareStrings(postStatus, "UnPosted");
		   
		}

	public void createSOPIncidentReportOnTheCreatedWorksheet(String esopId) throws Throwable {
		
		String worksheetId = "";
	
	    for(int i =0 ; i < 10 ; i++) {
	    	worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		if(worksheetId == null) {
		Thread.sleep(10000);
		}
		else {
			break;
		}
		}
		
/*		try {
			worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}*/
		//CRM_LINK
		waitForElementPresent(HomePage.CRM_LINK,"CRM Link");
		assertElementPresent(HomePage.CRM_LINK,"CRM Link");
		click(HomePage.CRM_LINK,"CRM Link");
		
		assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
		assertElementPresent(CRM.CREATE_BUTTON, "Create Button");
		click(CRM.CREATE_BUTTON, "Create Button");
		
		waitForElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
		assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
				
		//click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
		waitForElementPresent(CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		assertElementPresent(CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		selectByVisibleText(CRM.SERVICE_TYPE_DROP_DOWN,"SOP Incident Report", "Select SOP Incident Report from Dropdown");
		
		String parentWindow = driver.getWindowHandle();
		assertElementPresent(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		click(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		handlePopUpWindwow();
		assertElementPresent(CRM.WORKSHEET_SEARCH_POPUP, "Worksheet Search Popup");
		type(CRM.ENTER_LOGID, worksheetId, "Log ID Entered");
		click(CRM.LOGID_SEARCH_BUTTON, "Log ID Search Button");
		click(Generic.SELECT, "Select Button");
		driver.switchTo().window(parentWindow);
		click(CRM.ERROR_TYPE, "Error Type");
		click(CRM.REQUESTED_VIA, "Requested Via");
		click(CRM.SERVICE_LEVEL, "Service Level");
		click(Generic.SAVE, "Save Button");
		assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
		assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");
	}
 
	public void worksheetInMyWorksheetsToReview(String esopId) throws Throwable{
	
		//MY_WORKSHEET
		waitForElementPresent(WorksheetCreate.MY_WORKSHEET,"My Worksheet link");
		assertElementPresent(WorksheetCreate.MY_WORKSHEET,"My Worksheet link");
		click(WorksheetCreate.MY_WORKSHEET,"My worksheet link");
	    //MY_WORKSHEETS_TO_REVIEW_TAB
		waitForElementPresent(CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		assertElementPresent(CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		click(CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		// CLEARBTN
		waitForElementPresent(SOP.CLEARBTN, "Clear Button of filter");
		assertElementPresent(SOP.CLEARBTN, "Clear Button of filter");
		click(SOP.CLEARBTN, "Clear Button of filter");
		String worksheetId = "";
		
		try {
			worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
			System.out.println("The values for WS is " + worksheetId);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchForLog(worksheetId);
		waitForElementPresent(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA,
				"Log is present in worksheets to review Tab");
		assertElementPresent(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA,
				"Log is present in worksheets to review Tab");
	}

	public void worksheetInMyWorksheetsAndMyTeamWorksheet(String reportSheet , int count) throws Throwable{
		
		String sopWorkFlow = Excelobject.getCellData(reportSheet, "SOP Workflow", count);
		String worksheetIn = Excelobject.getCellData(reportSheet, "Worksheet In", count);
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//MY_WORKSHEETS_NAV_LINK
		waitForElementPresent(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");
		assertElementPresent(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");
		click(SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");		
		
		if(!worksheetIn.equals("My Worksheet")) {
		 //MY_TEAMS_WORKSHEETS_LINK
		 waitForElementPresent(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");
		 assertElementPresent(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");
		 click(SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");	
			
		}
		
		searchForSOPWorkflow(sopWorkFlow);
		// FIRST_WORKSHEET
		waitForElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		assertElementPresent(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		click(SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
        //SOP_WORKFLOW
		waitForElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
        compareStrings(sopWorkFlow,workflowInWorksheet);
	}
	
	public void searchForSOPWorkflow(String workflow) throws Throwable {

		waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(SOP.FILTERDROPDOWN1, "SOP WorkFlow", "Filter drop down");
		waitForElementToBeClickable(SOP.DROP_DOWN_LIST_RIGHT, "Filter drop right");
		assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter drop right");
		selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT, workflow, "Filter drop right");
		waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
		assertElementPresent(SOP.FILTERGOBTN, "Go Button");
		click(SOP.FILTERGOBTN, "Go Button");
	}

	
	//Below Fxns are created as part of NPD dev ops sp2
	
	public void  createRoleForTransmittalType(String reportSheet, int count) throws Throwable {
		try {
			String role = Excelobject.getCellData(reportSheet, "Role Name", count);

			// ADMIN_TAB
			waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
			click(Admin.ADMIN_TAB, "Admin Tab in the header");
			
			//CREATE_ROLE_BTN
			waitForElementPresent(Admin.CREATE_ROLE_BTN, "Create Role button in Roles Page");
			assertElementPresent(Admin.CREATE_ROLE_BTN, "Create Role button in Roles Page");
			click(Admin.CREATE_ROLE_BTN, "Create Role button in Roles Page");
			
			//ROLE_NAME_TEXT_BOX
			waitForElementPresent(Admin.ROLE_NAME_TEXT_BOX, "Role name textbox in Create Role Page");
			assertElementPresent(Admin.ROLE_NAME_TEXT_BOX, "Role name textbox in Create Role Page");
			type(Admin.ROLE_NAME_TEXT_BOX,role, "Role name textbox in Create Role Page");
			
			//MAINTAIN_TRANSMITTAL_TYPE
			waitForElementPresent(Admin.MAINTAIN_TRANSMITTAL_TYPE, "Permission for Maintain Transmittal Type in Create Role Page");
			assertElementPresent(Admin.MAINTAIN_TRANSMITTAL_TYPE, "Permission for Maintain Transmittal Type in Create Role Page");
			click(Admin.MAINTAIN_TRANSMITTAL_TYPE, "Click on Permission for Maintain Transmittal Type in Create Role Page");
			
			// SAVEBTN
			waitForElementPresent(Admin.SAVEBTN, "wait for save button link in Roles Page");
			assertElementPresent(Admin.SAVEBTN, "assert save button link in Roles Page");
			click(Admin.SAVEBTN, "click on save button link in Roles Page");								

		} catch (Exception e) {
		}
	}
	
	public void assignTheRoleToTheUser(String reportSheet, int count) throws Throwable {
		
		try{	
		String role = Excelobject.getCellData(reportSheet, "Role Name", count);
        String user = Excelobject.getCellData(reportSheet, "User", count);
		// ADMIN_TAB
		waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
		assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
		click(Admin.ADMIN_TAB, "Admin Tab in the header");
		// FIRST_FILTER_DRPDWN
		waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
		assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
		selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
		// SECOND_FILTER_DRPDWN
		waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
		assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
		selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
		// FILTER_TEXT_FILED
		waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
		assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
		type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
		// GO_BTN
		waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
		assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
		click(Admin.GO_BTN, "Go Button in Roles Page");
		// FIRST_ROLE_ON_THE_GRID
		waitForElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
		assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
		click(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
		//MAINTAIN_BTN
		waitForElementPresent(Admin.MAINTAIN_BTN, "wait for Maintain button in Roles Page");
		assertElementPresent(Admin.MAINTAIN_BTN, "Assert Maintain button in Roles Page");
		click(Admin.MAINTAIN_BTN, "Click on Maintain button in Roles Page");
		//GRANT_ROLE_BTN
		waitForElementPresent(Admin.GRANT_ROLE_BTN, "wait for Grant role button in Role Users Page");
		assertElementPresent(Admin.GRANT_ROLE_BTN, "Assert Grant role button in Role Users Page");
		click(Admin.GRANT_ROLE_BTN, "Click Grant role button in Role Users Page");
		//EMPLOYEE_NAME_TEXTBOX
		waitForElementPresent(Admin.EMPLOYEE_NAME_TEXTBOX, "wait for Employee name text field in Find Users Page");
		assertElementPresent(Admin.EMPLOYEE_NAME_TEXTBOX, "ASsert Employee name text field in Find Users Page");
		type(Admin.EMPLOYEE_NAME_TEXTBOX,user, "wait for Employee name text field in Find Users Page");
		//FIND_BTN
		waitForElementPresent(Admin.FIND_BTN, "Find button in Find Users Page");
		assertElementPresent(Admin.FIND_BTN, "Asserty Find button in Find Users Page");
		click(Admin.FIND_BTN, "Click on Find button in Find Users Page");
		//FIRST_CHECKBOX_ON_EMPLOYEE_GRID
		waitForElementPresent(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "First check box in Pick Users Page");
		assertElementPresent(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "Assert First check box in Pick Users Page");
		click(Admin.FIRST_CHECKBOX_ON_EMPLOYEE_GRID, "Click on First check box in Pick Users Page");
		//GRANT_ROLE_BTN
		waitForElementPresent(Admin.GRANT_ROLE_BTN, "wait for Grant role button in Role Users Page");
		assertElementPresent(Admin.GRANT_ROLE_BTN, "Assert Grant role button in Role Users Page");
		click(Admin.GRANT_ROLE_BTN, "Click Grant role button in Role Users Page");			
		
	} catch (Exception e) {
	}
}
	
	public void editTheTransmittalTypeInAff(String reportSheet, int count) throws Throwable{
		
	try{
	  
	  String transmittalType = Excelobject.getCellData(reportSheet, "Transmittal Type Cd", count);
	  String transmittalValue = Excelobject.getCellData(reportSheet, "Transmittal Value", count);
	  String affiliationId = SQL_Queries.getTheAffIdForTheTransmittalType(transmittalType).get(0);
	  
	  	    waitForElementPresent(HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			assertElementPresent(HomePage.AFFILIATION_TAB, "Assert Affiliation Search Link");
			click(HomePage.AFFILIATION_TAB, "Click on AAffiliation Tab in Affiliation Search");
			waitForElementPresent(Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
			assertElementPresent(Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(Affiliation.SEARCHBTN, "Search Button");
			// EDITBTN
			waitForElementPresent(Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			assertElementPresent(Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			click(Affiliation.EDITBTN, "Click on Edit Button");
			
			//TRANSMITTAL_TYPE_DROP_DOWN
			waitForElementPresent(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, "Transmittal Type Drop down in Edit Affiliation Page");
			assertElementPresent(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, "assert Transmittal Type Drop down in Edit Affiliation Page");
			
			if(transmittalValue.equals("Full")){
			
			selectByVisibleText(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, transmittalValue , "select Full Transmittal Type Drop down in Edit Affiliation Page");
			}
			
			else if(transmittalValue.equals("--")){
			
			selectByVisibleText(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN, "-- Select One --" , "select Full Transmittal Type Drop down in Edit Affiliation Page");
			}
			
			else if(transmittalValue.equals("")){
			
			//TRANSMITTAL_TYPE_DROP_DOWN_DISABLED
			assertElementPresent(Affiliation.TRANSMITTAL_TYPE_DROP_DOWN_DISABLED, "assert disabled Transmittal Type Drop down in Edit Affiliation Page");
			
			}
			
			//COMMENTFIELD			
			assertElementPresent(Affiliation.COMMENTFIELD, "Comment text box in Edit Affiliation Information Page");
			type(Affiliation.COMMENTFIELD, "Comments entered with Selenium Automation", "Comment text box in Edit Entity Information Page");
			
			// SAVE_BTN
			assertElementPresent(Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");
			click(Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");
	
	}catch(NoSuchElementException e){
		e.printStackTrace();
	}
}	
	
public void revokeTheGrantFromTheUser(String reportSheet, int count) throws Throwable {
		
		try{	
		String role = Excelobject.getCellData(reportSheet, "Role Name", count);
        String user = Excelobject.getCellData(reportSheet, "User", count);
		// ADMIN_TAB
		waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
		assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
		click(Admin.ADMIN_TAB, "Admin Tab in the header");
		// FIRST_FILTER_DRPDWN
		waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
		assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
		selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
		// SECOND_FILTER_DRPDWN
		waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
		assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
		selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
		// FILTER_TEXT_FILED
		waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
		assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
		type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
		// GO_BTN
		waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
		assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
		click(Admin.GO_BTN, "Go Button in Roles Page");
		// FIRST_ROLE_ON_THE_GRID
		waitForElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
		assertElementPresent(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
		click(Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
		//MAINTAIN_BTN
		waitForElementPresent(Admin.MAINTAIN_BTN, "wait for Maintain button in Roles Page");
		assertElementPresent(Admin.MAINTAIN_BTN, "Assert Maintain button in Roles Page");
		click(Admin.MAINTAIN_BTN, "Click on Maintain button in Roles Page");
		//here search for the user
		//FIRST_FILTER_DRPDWN
		waitForElementToBePresent(Admin.FIRST_FILTER_DRPDWN,"First filter drop down in Role Page");
		assertElementPresent(Admin.FIRST_FILTER_DRPDWN,"First filter drop down in Role Page");
		selectByVisibleText(Admin.FIRST_FILTER_DRPDWN,"Name","First filter drop down in Role Page");
		//SECOND_FILTER_DRPDWN
		waitForElementToBePresent(Admin.SECOND_FILTER_DRPDWN,"Second filter drop down in Role Page");
		assertElementPresent(Admin.SECOND_FILTER_DRPDWN,"Second filter drop down in Role Page");
		selectByVisibleText(Admin.SECOND_FILTER_DRPDWN,"contains","Second filter drop down in Role Page");
		//FILTER_TEXT_BOX
		waitForElementToBePresent(Admin.FILTER_TEXT_BOX,"Text box top right in Role Page");
		assertElementPresent(Admin.FILTER_TEXT_BOX,"Text box top right in Role Page");
		type(Admin.FILTER_TEXT_BOX,user,"Text box top right in Role Page");
		//
		waitForElementToBePresent(Admin.GO_BTN, "GO Button in the Role Page");
		assertElementPresent(Admin.GO_BTN, "GO Button in the Role Page");
		click(Admin.GO_BTN, "GO Button in the Role Page");
		//FIRST_CHECKBOX_ON_GRANT_GRID
		waitForElementToBePresent(Admin.FIRST_CHECKBOX_ON_GRANT_GRID,"First check box in data grid");
		assertElementPresent(Admin.FIRST_CHECKBOX_ON_GRANT_GRID,"First check box in data grid");
		click(Admin.FIRST_CHECKBOX_ON_GRANT_GRID,"First check box in data grid");
		
		//REVOKE_GRANT_BTN
		waitForElementPresent(Admin.REVOKE_GRANT_BTN, "wait for revoke Grant role button in Role Users Page");
		assertElementPresent(Admin.REVOKE_GRANT_BTN, "Assert Revoke Grant role button in Role Users Page");
		click(Admin.REVOKE_GRANT_BTN, "Click Revoke Grant role button in Role Users Page");
		
		} catch (Exception e) {
	}
}
public void deleteTheRole(String reportSheet, int count) throws Throwable {
	
	try{	
	String role = Excelobject.getCellData(reportSheet, "Role Name", count);
	// ADMIN_TAB
	waitForElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	assertElementPresent(Admin.ADMIN_TAB, "Admin Tab in the header");
	click(Admin.ADMIN_TAB, "Admin Tab in the header");
	//FIRST_FILTER_DRPDWN
	waitForElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	assertElementPresent(Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
	selectByVisibleText(Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
	//SECOND_FILTER_DRPDWN
	waitForElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	assertElementPresent(Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
	selectByVisibleText(Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
	//FILTER_TEXT_FILED
	waitForElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	assertElementPresent(Admin.FILTER_TEXT_FILED, "text field in Roles Page");
	type(Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
	//GO_BTN
	waitForElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	assertElementPresent(Admin.GO_BTN, "Go Button in Roles Page");
	click(Admin.GO_BTN, "Go Button in Roles Page");
	//FIRST_DELETE_BUTTON_ON_GRID
	waitForElementToBePresent(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button in Roles Page");
	assertElementPresent(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button in Roles Page");
	click(Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button in Roles Page");
    
	handlepopup();

	}catch(Exception e) {}
}

public void executeActionItem(String reportSheet,int count,String esopId) throws Throwable {
	//uncomment below before completed implmentation of fxn
		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
	    String  lawsuitType = Excelobject.getCellData(reportSheet, "Law Suit Type", count);
		String  hardCopyRequired = Excelobject.getCellData(reportSheet, "Hard Copy DI", count);
		String  specialCircumstance = Excelobject.getCellData(reportSheet, "Special Circumstances", count);
		
		//String expeditedLog = "538121340";
		waitForElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
		
		if(hardCopyRequired.equals("No") && specialCircumstance.equals("Yes")) {		
			   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
			//VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES
				int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES,lawsuitType);		   
				System.out.println("the index sent is : " + matchedIndexLawSuit);
			   //USE_BUTTON_IN_LAWSUIT
				//USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES
			    clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
				
			}	
		else if(hardCopyRequired.equals("No") && specialCircumstance.equals("No")) {		
	   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
		int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_NO_SPECIAL_CIRCUMSTANCES,lawsuitType);
	   
		System.out.println("the index sent is : " + matchedIndexLawSuit);
	   //USE_BUTTON_IN_LAWSUIT
		//USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES
	    clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
		
		}
		else if(hardCopyRequired.equals("Yes")) {
		
			int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES,lawsuitType);
			clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
		}	
		//EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL
		Thread.sleep(500);
		try{
		WebElement executeManual = driver.findElement(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL);
		 //waitForElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 click(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 //COMMENTS_DRPDWN
		 waitForElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 selectByVisibleText(SOP.COMMENTS_DRPDWN,"Hard Copy Required","Execute Manual in SOP Papers with Transmittal");
		 //CONTINUE_BUTTON
		 waitForElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 assertElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 click(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 try {
			 WebElement createPackage = driver.findElement(By.id("btnCreatePackage"));
			 createPackage.click();
		 }catch(NoSuchElementException e) {}
		 //SAVE_BTN
		 assertElementPresent(Entity.SAVE_BTN, "Save button");
		 click(Entity.SAVE_BTN, "Save button");
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");	
		}catch(NoSuchElementException e){}
		
		
		//EXECUTE_SOP_PAPER_WITH_TRANSMITTAL
		Thread.sleep(500);
		try{
		WebElement execute = driver.findElement(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL);
		 //waitForElementPresent(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute in SOP Papers with Transmittal");
		 assertElementPresent(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute  in SOP Papers with Transmittal");
		 click(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute  in SOP Papers with Transmittal");

		}catch(NoSuchElementException e){}
	   //SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
	   Thread.sleep(500);
	   try{
	   WebElement retainButton = driver.findElement(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL);
	   //waitForElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
	   assertElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with ransmittal");
	   click(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");   

	   }catch(NoSuchElementException e){}
	   	
	    //EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL
	   Thread.sleep(500);
	   try{
	   WebElement isopButton = driver.findElement(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL);
	   //waitForElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   assertElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   click(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   }catch(NoSuchElementException e){}  
	} 


/*public void executeActionItem(String reportSheet,int count,String esopId) throws Throwable {
//uncomment below before completed implmentation of fxn
	String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
    String  lawsuitType = Excelobject.getCellData(reportSheet, "Law Suit Type", count);
	String  hardCopyRequired = Excelobject.getCellData(reportSheet, "Hard Copy DI", count);
	String  specialCircumstance = Excelobject.getCellData(reportSheet, "Special Circumstances", count);
	
	//String expeditedLog = "538121340";
	waitForElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
	assertElementPresent(SOP.CHOOSE_DI_BTN, "Choose DI Button");
	click(SOP.CHOOSE_DI_BTN, "Choose DI Button");
	
	if(hardCopyRequired.equals("No") && specialCircumstance.equals("Yes")) {		
		   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
		//VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES
			int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES,lawsuitType);		   
			System.out.println("the index sent is : " + matchedIndexLawSuit);
		   //USE_BUTTON_IN_LAWSUIT
			//USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES
		    clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
			
		}	
	else if(hardCopyRequired.equals("No") && specialCircumstance.equals("No")) {		
   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
	int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_NO_SPECIAL_CIRCUMSTANCES,lawsuitType);
   
	System.out.println("the index sent is : " + matchedIndexLawSuit);
   //USE_BUTTON_IN_LAWSUIT
	//USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES
    clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_NO_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
	
	}
	else if(hardCopyRequired.equals("Yes")) {
	
		int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI_WITH_SPECIAL_CIRCUMSTANCES,lawsuitType);
		clickOnAParticularIndexOfAnElement(SOP.USE_BUTTON_IN_LAWSUIT_WITH_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
	}	
	//EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL
	Thread.sleep(2000);
	try{
	WebElement executeManual = driver.findElement(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL);
	 //waitForElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
	 assertElementPresent(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
	 click(SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
	 //COMMENTS_DRPDWN
	 waitForElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
	 assertElementPresent(SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
	 selectByVisibleText(SOP.COMMENTS_DRPDWN,"Hard Copy Required","Execute Manual in SOP Papers with Transmittal");
	 //CONTINUE_BUTTON
	 waitForElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
	 assertElementPresent(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
	 click(SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
	 try {
		 WebElement createPackage = driver.findElement(By.id("btnCreatePackage"));
		 createPackage.click();
	 }catch(NoSuchElementException e) {}
	 //SAVE_BTN
	 assertElementPresent(Entity.SAVE_BTN, "Save button");
	 click(Entity.SAVE_BTN, "Save button");
	//ACTION_ITEMS_LEFT_NAV_LINK
	waitForElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
	assertElementPresent(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
	click(SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");	
	   for(int i = 0 ; i<3; i++) {	 
		   try {
		   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13023").get(0)	;	   
		   if(!executedBy.equals("")) {
			  Thread.sleep(5000);	
			   break;
		       }
		   }catch(IndexOutOfBoundsException e) {
			   Thread.sleep(5000);
			   }
	   }
	}catch(NoSuchElementException e){}
	
	
	//EXECUTE_SOP_PAPER_WITH_TRANSMITTAL
	Thread.sleep(2000);
	try{
	WebElement execute = driver.findElement(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL);
	 //waitForElementPresent(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute in SOP Papers with Transmittal");
	 assertElementPresent(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute  in SOP Papers with Transmittal");
	 click(SOP.EXECUTE_SOP_PAPER_WITH_TRANSMITTAL,"Execute  in SOP Papers with Transmittal");
	
	   for(int i = 0 ; i<3; i++) {	 
		   try {
		   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13010").get(0)	;	   
		   if(!executedBy.equals("")) {
			  Thread.sleep(5000);	
			   break;
		       }
		   }catch(IndexOutOfBoundsException e) {
			   Thread.sleep(5000);
			  }
	   }
	}catch(NoSuchElementException e){}
   //SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
   Thread.sleep(1000);
   try{
   WebElement retainButton = driver.findElement(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL);
   //waitForElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
   assertElementPresent(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with ransmittal");
   click(SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");   

	   for(int i = 0 ; i<10; i++) {	 
		   try {
		   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13021").get(0)	;	   
		   if(executedBy.equals("1166")) {
			  Thread.sleep(2000);	
			   break;
		       }
		   }catch(NullPointerException e) {
			   Thread.sleep(10000);
			   e.printStackTrace();}
	   }
   }catch(NoSuchElementException e){e.printStackTrace();}
   	
    //EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL
   Thread.sleep(1000);
   try{
   WebElement isopButton = driver.findElement(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL);
   //waitForElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
   assertElementPresent(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
   click(SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
  
  for(int i = 0 ; i<10; i++) {	 
	   try {
	   String executedBy = SQL_Queries.executedByInActionItemTable(expeditedLog,"13014").get(0)	;	   
	   if(executedBy.equals("1166")) {
			  Thread.sleep(2000);	
		   break;
	       }
	   }catch(NullPointerException e) {
		   Thread.sleep(10000);
		   e.printStackTrace();}
  }
   }catch(NoSuchElementException e){e.printStackTrace();}   
   //logPostedInWorksheet
     
   for(int i = 0 ; i<10; i++) {	
	   String isLogPosted = SQL_Queries.logPostedInWorksheet(expeditedLog).get(0)	;	   
	   if(isLogPosted.equals("N")) {			
		   Thread.sleep(10000);	
	   }
	   else {
		   break;
	       }
   }
   Thread.sleep(2000);
   //WORKSHEET_PROFILE_LINK
   waitForElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
   assertElementPresent(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
   click(SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
   
   //POST_STATUS
   assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
   String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
   compareStrings(postStatus, "Posted");
   
   
}
*/
	public void worksheetInSOPHub(String reportSheet, int count) throws Throwable {
		
	String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
	String worksheetId = null;
    
	if(workflow.equals("151004")) {
	
		worksheetId = Excelobject.getCellData(reportSheet, "OptimizedManual Log", count);
	}
	else if(workflow.equals("151001")) {
		
		worksheetId = Excelobject.getCellData(reportSheet, "Full Log", count);
		
	}
	//SELECT
	waitForElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
	assertElementPresent(SopHub.SELECT, "Select button in Customer Search Page");
	click(SopHub.SELECT, "Select button in Customer Search Page");
	//SOP_HUB_LINK
	waitForElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	assertElementPresent(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	click(SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	for(int i = 0; i<10; i++) {
	//LOG_SEARCH_TEXT_FIELD
	waitForElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");
	assertElementPresent(SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");		
	type(SopHub.LOG_SEARCH_TEXT_FIELD,worksheetId, "Log Search test field in SOP Received Page");
	//SEARCH_BUTTON
	waitForElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
	assertElementPresent(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
	click(SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");	
	WebElement noSuchWorksheet = null;
	
	try {
		
		noSuchWorksheet = driver.findElement(By.xpath("//span[contains(text(),'There are no entries in this list.')]"));
		//HOME_BUTTON
		assertElementPresent(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
		click(SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
		
	}catch(NoSuchElementException e) {
		
	}	
	if(noSuchWorksheet != null) {
	 
		Thread.sleep(12000);
	}
	else {
		break;
	}
  }
	//CT_LOG_NUMBER
	waitForElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
	assertElementPresent(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
	compareStrings(worksheetId,getText(SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub"));
}
	
	public void titleOfActionMaintenanceApp(String reportSheet, int count) throws Throwable {
		
		String toaTab = Excelobject.getCellData(reportSheet, "TOA Tab", count);
		String lawSuitType = Excelobject.getCellData(reportSheet, "Law Suit Type", count);
		String docType = Excelobject.getCellData(reportSheet, "Document Type", count);
		String action = Excelobject.getCellData(reportSheet, "Action", count);
		String textValue = Excelobject.getCellData(reportSheet, "Text Value", count);
		
		waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(SOP.SOP_LINK_HEADER, "SOP link in header");
		//TITLE_OF_ACTION_RULES_MAINTENANCE
		waitForElementPresent(SOP.TITLE_OF_ACTION_RULES_MAINTENANCE, "Title of Action rules maintenance link in left nav bar");
		assertElementPresent(SOP.TITLE_OF_ACTION_RULES_MAINTENANCE, "Title of Action rules maintenance link in left nav bar");
		click(SOP.TITLE_OF_ACTION_RULES_MAINTENANCE, "Title of Action rules maintenance link in left nav bar");
		//TITLE_TOA_APP
		assertElementPresent(SOP.TITLE_TOA_APP,"assert the title of maintenance app is present");		
		
		if(toaTab.equals("CTCORP") || toaTab.equals("NRAI")) {
		if(toaTab.equals("CTCORP")) {
		//LAW_SUIT_TYPE_DROP_DOWN
		waitForElementPresent(SOP.LAW_SUIT_TYPE_DROP_DOWN, "Law Suit type in CTCORP TOA in rules maintenance");
		selectByVisibleText(SOP.LAW_SUIT_TYPE_DROP_DOWN,lawSuitType, "Law Suit type in CTCORP TOA in rules maintenance");
		
		}
		else if(toaTab.equals("NRAI")) {
		//NRAI_TOA
		waitForElementPresent(SOP.NRAI_TOA,"NRAI TOA tab");
		assertElementPresent(SOP.NRAI_TOA,"NRAI TOA tab");
		click(SOP.NRAI_TOA,"NRAI TOA tab");		
		waitForElementPresent(SOP.LAW_SUIT_TYPE_DROP_DOWN, "Law Suit type in CTCORP TOA in rules maintenance");
		selectByVisibleText(SOP.LAW_SUIT_TYPE_DROP_DOWN,docType, "Law Suit type in CTCORP TOA in rules maintenance");		
		}
		
		assertElementPresent(SOP.TEXT1,"text 1 drop down field");
		assertElementPresent(SOP.TEXT2,"text 2 drop down field");
		assertElementPresent(SOP.TEXT3,"text 3 drop down field");
		assertElementPresent(SOP.TEXT4,"text 4 drop down field");
		assertElementPresent(SOP.TEXT5,"text 5 drop down field");
		assertElementPresent(SOP.TEXT6,"text 6 drop down field");				
		
		if(action.equals("Add")) {
		selectByVisibleText(SOP.TEXT1_DROP_DOWN,"Plaintiff","text 1 drop down field");		
		//ADDUPDATE_BTN
		assertElementPresent(SOP.ADDUPDATE_BTN, "Add/Update button in title of action maintenance app");
		click(SOP.ADDUPDATE_BTN, "Add/Update button in title of action maintenance app");
		//DUPLICATE_RECORDS_MESSAGE
		assertElementPresent(SOP.DUPLICATE_RECORDS_MESSAGE,"assert that Duplicate record not allowed message displayed");		
		}
		else if(action.equals("Edit")) {
		//EDIT_BTN
		assertElementPresent(SOP.EDIT_BTN, "First Edit button in the data grid of title of action maintenance app");
		click(SOP.EDIT_BTN, "First Edit button in the data grid of title of action maintenance app");		
		String lawSuitdisabled = getAttribute(SOP.LAW_SUIT_TYPE_DROP_DOWN, "disabled");
		System.out.println("value of attribute : " + lawSuitdisabled);
		compareStrings("true",lawSuitdisabled);
		
		}
	}
		else if(toaTab.equals("Look Up")) {
			//TOA_LOOK_UP			
			waitForElementPresent(SOP.TOA_LOOK_UP,"TOA Look up tab in title of action maintenance app");
			assertElementPresent(SOP.TOA_LOOK_UP,"TOA Look up tab in title of action maintenance app");
			click(SOP.TOA_LOOK_UP,"TOA Look up tab in title of action maintenance app");
			
			if(action.equals("Add")) {
			//TEXT_FIELD_TOA_LOOKUP
			assertElementPresent(SOP.TEXT_FIELD_TOA_LOOKUP,"Text field in TOA Look up tab in title of action maintenance app");
			type(SOP.TEXT_FIELD_TOA_LOOKUP,textValue,"Text field in TOA Look up tab in title of action maintenance app");
			click(SOP.ADDUPDATE_BTN, "Add/Update button in title of action maintenance app");			
			}
			else if(action.equals("Edit")) {
			//EDIT_TEST_TEXT_VALUE
			assertElementPresent(SOP.EDIT_TEST_TEXT_VALUE,"edit the Text field in TOA Look up tab in title of action maintenance app");
			click(SOP.EDIT_TEST_TEXT_VALUE,"edit the Text field in TOA Look up tab in title of action maintenance app");
			type(SOP.TEXT_FIELD_TOA_LOOKUP,textValue,"Text field in TOA Look up tab in title of action maintenance app");
			click(SOP.ADDUPDATE_BTN, "Add/Update button in title of action maintenance app");		
			}
			
			else if(action.equals("Delete")) {
			//DELETE_TEST_TEXT_VALUE			
			assertElementPresent(SOP.DELETE_TEST_TEXT_VALUE , "Delete the test text value added and then edited");
			click(SOP.DELETE_TEST_TEXT_VALUE , "Delete the test text value added and then edited");
			handlepopup();			
			}
			
			else if(action.equals("Delete In Use")) {
			//FIRST_DELETE_BTN_ON_GRID
			assertElementPresent(SOP.FIRST_DELETE_BTN_ON_GRID,"Delete the text value used in configuration format");
			click(SOP.FIRST_DELETE_BTN_ON_GRID,"Delete the text value used in configuration format");
			handlepopup();
			Thread.sleep(500);
			//ERROR_ON_DELETE_TEXT_IN_USE
			assertElementPresent(SOP.ERROR_ON_DELETE_TEXT_IN_USE,"Error messgae on deleting the text used in configuration format");

			}
		}		
		
	}
	
	public void validateWorksheetAndExecuteActionItems(int test,String reportSheet, String [] esops) throws Throwable{
			
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);
			viewAndCreateTheWorkSheetUsingESOPId(reportSheet,i+2,esops[i]);
			//String worksheetId = "538124038";
			//The below should be uncommented
			sopWorkflow(reportSheet,i+2,esops[i]);
			executeActionItem(reportSheet,i+2,esops[i]);
			//the below check is added as part of NPD Dev Ops sprint 7 changes to validate the transmittal for TOA
			transmittalDataVerification(reportSheet,i+2,esops[i]);
			driver.manage().deleteAllCookies();
			}
			//Excelobject.writeDataToExistingExcel(testDataSheet,optimizedManualLogKey - 1,reportSheet,optimizedManualWorksheet);		
	}

	public Map<Integer,String> executeActionItemAfterWorksheetCreation(int test,String reportSheet, String [] esops) throws Throwable{
		   
		Map<Integer,String> worksheets = new HashMap<Integer,String>();
		int logKey = 1;
		for(int i = 0 ;i <= test; i++ ){
			driver.get(URL);
			String member = Excelobject.getCellData(reportSheet, "Member", i+2);
			String team = Excelobject.getCellData(reportSheet, "Team", i+2);
			SignIn(team, member);						
			String worksheetId = viewAndCreateTheWorkSheetUsingESOPId(reportSheet, i+2,esops[i]);
			sopWorkflow(reportSheet, i+2,esops[i]);
			executeActionItem(reportSheet, i+2,esops[i]);					
			//executeActionItem("OptimizedManual Worksheet",iLoop,"");
			worksheets.put(logKey, worksheetId);
			logKey++;
			driver.manage().deleteAllCookies();
		}
		//Below one function to check if the log is posted
		driver.get(URL);
		String member = Excelobject.getCellData(reportSheet, "Member", 2);
		String team = Excelobject.getCellData(reportSheet, "Team", 2);
		SignIn(team, member);
		for(int i= 1; i<=worksheets.size() ; i++) {			
			searchWorksheet(worksheets.get(i));
			validateThePostStatusOfworksheet(worksheets.get(i));		
		}
		return worksheets;
	}
	
	public void validateThePostStatusOfworksheet(String worksheetId) throws Throwable {

		for (int i = 0; i < 10; i++) {
			String isLogPosted = SQL_Queries.logPostedInWorksheet(worksheetId).get(0);
			if (isLogPosted.equals("N")) {
				Thread.sleep(2000);
			} else {
				break;
			}
		}

//POST_STATUS
		assertElementPresent(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus, "Posted");
}     
	
	
}

	
