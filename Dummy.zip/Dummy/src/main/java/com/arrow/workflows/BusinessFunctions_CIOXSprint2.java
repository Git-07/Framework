package com.arrow.workflows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.RenewalInvoice;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;

public class BusinessFunctions_CIOXSprint2 extends BusinessFunctions_CommonCESAndWorksheet {

	public String createWorksheetMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String lawsuitType = Excelobject.getCellData(ReportSheet, "LawsuitType", count);

			// Create Worksheet Page
			if (verifyIfElementPresent(SOP.METHOD_OF_SERVICE, "Method of Service")) {
				selectBySendkeys(SOP.METHOD_OF_SERVICE, "Fax", "Method Of Service as Fax");
				waitForElementPresent(SOP.TIME_TEXTFIELD, "Text Field for Time");
				type(SOP.TIME_TEXTFIELD, "08:00", "Text Field for Time");
			}
			type(SOP.TIME_TEXTFIELD, "08:00", "Text Field for Time");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYFACILITY, "New York Facility 1 (LIS)");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BY_NYTEAM, "CT - New York SOP Team");
			click(WorksheetCreate.RECEIVED_BY_GLYPHICON, "Glyphicon Click");
			click(WorksheetCreate.EDIT_RECEIVED_BYNY, "TEST New York SOP Team");
			click(SOP.INITIAL_RADIOBTN, "Initial Radio Button");
			click(WorksheetCreate.RADIO_BUTTON_CASE, "Case Radio Button");
			type(WorksheetCreate.CASE_TEXT, "123-234", "Text Field for Case");
			click(WorksheetCreate.RADIO_BUTTON_PLAINTIFF, "Plaintiff Radio Button");
			type(WorksheetCreate.PLAINTIFF_TEXT, "Plaintiff / Debtor", "Text Field for Plaintiff / Debtor");
			type(SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", "Defendant/Creditor Name");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Entity Radio Button");
			click(WorksheetCreate.ENTITY_SELECT, "Select Entity Button");
			assertElementPresent(WorksheetCreate.ENTITY_NAME_SEARCH, "Entity Search Page");
			click(Generic.CANCEL, "Cancel Button");
			// Select Unidentified Radio Button
			click(WorksheetCreate.UNIDENTIFIED_ENTITY, "Unidentified Entity Radio Button");
			selectBySendkeys(WorksheetCreate.ENTITY_NAME, "Entity Name for Testing", "Enter Entity Name");
			selectBySendkeys(WorksheetCreate.DOMESTIC_JURISDICTION, "Alabama", "Select Alabama");
			click(WorksheetCreate.UNIDENTIFIED_REP, "Unidentified Rep Radio Button");
			click(WorksheetCreate.UNIDENTIFIED_JURIS_GLYPHICON, "Unidentified Juris Glyphicon Click");
			selectBySendkeys(WorksheetCreate.REP_JURISDICTION, "Alabama", "Select Alabama");

			// Create Worksheet Step 2
			click(SOP.RADIO_BUTTON_COURTNONE, "None Specified Court Radio Button");
			//selectBySendkeys(WorksheetCreate.COURT, "U.S. Marshall", "Court");
			click(SOP.AGENCY_NONE_RADIOBTN, "None Specified Agency Radio Button");
			//selectBySendkeys(WorksheetCreate.AGENCY, "U.S. Marshall", "Agency");
			click(SOP.ATTORNEY_NONE_RADIOBTN, "None Specified Attorney Radio Button");
			//selectBySendkeys(WorksheetCreate.ATTORNEY_OR_SENDER, "Adam Cooper", "Attorney");

			// Create Worksheet Step 3
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			selectBySendkeys(SOP.LAWSUITTYPE_DROPDOWN, lawsuitType, "LawSuitType Drpdwn");
			type(WorksheetCreate.AMOUNT_DUE, "200", "Amount Due");
			click(WorksheetCreate.RADIO_BUTTON_ANSWERDATE, "Answer Radio Button");
			click(WorksheetCreate.FIRST_ANSWER_DATE, "First Answer");
			selectBySendkeys(WorksheetCreate.ANSWER_DATE, "Immediately", "Answer Date Selected");
			click(WorksheetCreate.INTERNAL_COMMENTS_FIRST_OPTION, "Internal Comments First Option");
			click(WorksheetCreate.REMARKS_FIRST_OPTION, "Remarks first Option");
		}
		catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}



	public void createSOPIncidentReport(String worksheetId) throws Throwable {

		//Create SOPIncidentReport On The Created Worksheet
		//CRM_LINK
		waitForElementPresent(HomePage.CRM_LINK,"CRM Link");
		assertElementPresent(HomePage.CRM_LINK,"CRM Link");
		click(HomePage.CRM_LINK,"CRM Link");

		assertElementPresent(CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
		assertElementPresent(CRM.CREATE_BUTTON, "Create Button");
		click(CRM.CREATE_BUTTON, "Create Button");

		waitForElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");
		assertElementPresent(CRM.NEW_REQUEST_PAGE, "New Request Page");

		//click(CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
		waitForElementPresent(CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		assertElementPresent(CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		selectByVisibleText(CRM.SERVICE_TYPE_DROP_DOWN,"SOP Incident Report", "Select SOP Incident Report from Dropdown");

		String parentWindow = driver.getWindowHandle();
		assertElementPresent(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		click(CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		handlePopUpWindwow();
		assertElementPresent(CRM.WORKSHEET_SEARCH_POPUP, "Worksheet Search Popup");
		type(CRM.ENTER_LOGID, worksheetId, "Log ID Entered");
		click(CRM.LOGID_SEARCH_BUTTON, "Log ID Search Button");
		click(Generic.SELECT, "Select Button");
		driver.switchTo().window(parentWindow);
		click(CRM.ERROR_TYPE, "Error Type");
		click(CRM.REQUESTED_VIA, "Requested Via");
		click(CRM.SERVICE_LEVEL, "Service Level");
		click(Generic.SAVE, "Save Button");
		assertElementPresent(CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
		assertElementPresent(CRM.ASSIGNED_STATUS, "Assigned Status");
	}

	public String entityDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {			
			String caseNumber = "";
			int relatedWorksheet = 0;
			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);				
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String caseNum2 = Excelobject.getCellData(reportSheet, "New Case Number", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
			String rejectionReason = Excelobject.getCellData(reportSheet, "Rejection Reason", count);
			String notRejecting = Excelobject.getCellData(reportSheet, "Reason for Not Rejecting", count);
			String error = Excelobject.getCellData(reportSheet, "Error Message", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String reject = Excelobject.getCellData(reportSheet, "Reject", count);
			String onHold = Excelobject.getCellData(reportSheet, "On Hold", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);

			//Uncommented below line for change in CIOXSprint7-verifyEsopAlertsCommentsOnCreateWorksheetPage()
			String worksheetType = Excelobject.getCellData(reportSheet, "WorkSheet Type", count);

			waitForElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(SOP.SOP_LINK_HEADER, "SOP link in header");
			if(levelOfUser.equals("Level1")) {
				//CES_LEFT_NAV_LINK
				waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				click(SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
				//CES_PRODUCTIVITY_TAB
				waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
				click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
				//UNPROCESSED_COUNT
				waitForElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				Thread.sleep(2000);
				driver.switchTo().frame("frame1");
				Thread.sleep(3000);
			}

			else if(!levelOfUser.equals("Level1")) {
				if(cesQueue.equals("New")) {
					assertElementPresent(SOP.CLEARBTN, "Clear Button");
					click(SOP.CLEARBTN, "Clear Button");			
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
					click(SOP.FILTERGOBTN, "Go Button");
					Thread.sleep(1000);			
					waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(SOP.FILTERDROPDOWN1,"Worksheet Type","Filter drop down");
					waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");			
					selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,worksheetType, "Filter second drop down");			
					waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
					click(SOP.FILTERGOBTN, "Go Button");


					try {		 
						WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
						waitForElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						click(SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(SOP.CLEARBTN, "Clear Button");
						click(SOP.CLEARBTN, "Clear Button");			
						waitForElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
						assertElementPresent(SOP.FILTERDROPDOWN1, "Filter drop down");
						selectByVisibleText(SOP.FILTERDROPDOWN1,"CES Status","Filter drop down");
						waitForElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						assertElementPresent(SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						selectByVisibleText(SOP.DROP_DOWN_LIST_RIGHT,"New", "Filter second drop down");
						waitForElementPresent(SOP.FILTERGOBTN, "Go Button");
						assertElementPresent(SOP.FILTERGOBTN, "Go Button");			
						click(SOP.FILTERGOBTN, "Go Button");
						Thread.sleep(1000);	
					}catch(NoSuchElementException e) {}
					Thread.sleep(1000);
					waitForElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					assertElementPresent(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					click(SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					Thread.sleep(1000);

					waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
					esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				}
				else if(!cesQueue.equals("New")) {
					//CES_LEFT_NAV_LINK
					waitForElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
					assertElementPresent(SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");			
					click(SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
					//CES_PRODUCTIVITY_TAB
					waitForElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					assertElementPresent(SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");			
					click(SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

					if(cesQueue.equals("Escalated List")) {			
						//ESCALATED_LIST_TAB
						waitForElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
						assertElementPresent(SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");			
						click(SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");				    
						//FIRST_CES_SELECT_BUTTON
						waitForElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						assertElementPresent(SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
						click(SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					}

					else if(cesQueue.equals("OnHold List")) {			
						//ON_HOLD_LIST_TAB
						waitForElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
						assertElementPresent(SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");			
						click(SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
						//FIRST_ONHOLD_CES_SELECT_BUTTON
						waitForElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						assertElementPresent(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");			
						click(SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");	
						//create on filter search for New York SOP Team
					}

					else  if(cesQueue.equals("Rejections List")) {			
						//REJECTION_LIST_TAB
						waitForElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
						assertElementPresent(SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");			
						click(SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");	
						//REJECTIONS_LIST_FIRST_CES_SELECT
						waitForElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
						assertElementPresent(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");			
						click(SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");		
					}
				}
				Thread.sleep(2000);
				//System.out.println("Reached Here ewjdjkjlkwdlkjw");
				Thread.sleep(1000);
				waitForElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				assertElementPresent(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				esopId = getText(SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				driver.switchTo().frame("frame1");
				System.out.println("Switched to Frame 1");
				Thread.sleep(3000);
				//TRAINGLE_ICON_ARROW_ENTITY			
				//waitForElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				//INTAKEMETHODVALUE
				waitForElementPresent(SOP.INTAKEMETHODVALUE,"intake method value");
				String cdsop = getText(SOP.INTAKEMETHODVALUE,"intake method value");
				if(!arrowEntity.equals("")) {				
					waitForElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON,"Radio Button to Select Arrow Entity");
					String arrowEntityCheckedAttribute = getAttribute(SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
					if (arrowEntityCheckedAttribute == null) {			
						click(SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					}
					waitForElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP"); 

					if(!cdsop.equals("CDSOP")) {											
						if (branchPlant.equals("CTCORP")) {
							//CTCORP_RADIO_BUTTON
							waitForElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							assertElementPresent(SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
							click(SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");	

						}
						else if (branchPlant.equals("NRAI")) {
							//NRAI_RADIO_BUTTON
							waitForElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							assertElementPresent(SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
							click(SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");											
						}
					}
					//ENTITY_NAME_TEXTFIELD
					waitForElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP"); 
					if(cdsop.equals("CDSOP")) {
						selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,"BOM Generic","Entity search text box on ESOP");
					}
					else if(!cdsop.equals("CDSOP")) {
						selectBySendkeys(SOP.ENTITY_NAME_TEXTFIELD,arrowEntity,"Entity search text box on ESOP");
					}
					//SEARCH_BTN
					waitForElementPresent(SOP.SEARCH_BTN, "Search button");
					assertElementPresent(SOP.SEARCH_BTN, "Search button");
					click(SOP.SEARCH_BTN, "Search button");
					int entitySearchCount = 0;
					//ENTITY_SEARCH_RESULT_COUNT
					waitForElementPresent(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
					entitySearchCount = Integer.valueOf(getText(SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
					if(entitySearchCount == 0) {
						//Click on unidentified entity
						waitForElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");				
						assertElementPresent(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						String disabledUnEntity = "";
						try {				
							disabledUnEntity = getAttribute(SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
							System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
						}catch(NullPointerException e) {}
						if(disabledUnEntity == null) {
							click(SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");}
						Thread.sleep(1500);
						System.out.println("REached here in line 6420");
						try {
							if(disabledUnEntity.equals("true")) {					
								//SEARCH_AGAIN_BUTTON
								waitForElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");				
								assertElementPresent(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								//CANCEL_BUTTON
								waitForElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");				
								assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
								click(SOP.CANCEL_BUTTON, "Cancel Button");
							}}catch(NullPointerException e) {}				
						System.out.println("REached here in line 6431");
						Thread.sleep(2000);
						//below will be a go ahead when the value for unidentified Entity above is selected
						String unEntityRadioSelected = "";
						try {                	 
							unEntityRadioSelected = getAttribute(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");                	 
						}catch(NoSuchElementException e) {}
						catch(NullPointerException e) {}
						Thread.sleep(1000);
						try {
							if(unEntityRadioSelected == null) {
								click(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
							}}catch(NullPointerException e) {}
						//ENTITY_TEXT_BOX
						waitForElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
						assertElementPresent(SOP.ENTITY_TEXT_BOX, "Entity Name text box");
						type(SOP.ENTITY_TEXT_BOX,"Entity Under Test", "Entity Name text box");
						//DOMESTIC_JURISDICTION_SELECTION
						waitForElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
						assertElementPresent(SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
						selectByIndex(SOP.DOMESTIC_JURISDICTION_SELECTION,1, "Dom Jurisdiction drop down");
						//REP_JURISDICTION_SELECTION
						waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");               
						try {
							//waitForElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
							//assertElementPresent(SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
							driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
							Thread.sleep(1500);
							selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
						}catch(NoSuchElementException e) {}
						//DOCUMENT_TYPE_DROPDWN
						try {
							//waitForElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
							//assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
							driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
							selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
						}catch(NoSuchElementException e) {}
						//PLAINTIFF_TEXT_BOX			
						waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
						//DEFENDANT_TEXT_BOX				
						waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");

						waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
						assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
						type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");


					}
					else if(entitySearchCount != 0) {
						//REP_STATUS_SORT
						waitForElementPresent(SOP.REP_STATUS_SORT, "REp Status link in CES Page");
						assertElementPresent(SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
						click(SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
						//FIRST_ENTITY_IN_SEARCH_RESULT
						waitForElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						assertElementPresent(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						click(SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						//CONTINUE_BUTTON
						try {
							List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
							if(action.size()>0) {

								click(SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
							}
						}
						catch(NoSuchElementException e) {

						}
						if(!caseNum1.equals("")){					
							//CASEID_TEXTBOX
							waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							if(cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX,"19342919","Case number Search text box");
								//To-do if entity details selected Via CES Status "New" instead of Upload Img. while adding log to docket history via CES Process
								//click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
								//click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
							}
							else if(!cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX,caseNum1,"Case number Search text box");
								//To-do if entity details selected Via CES Status "New" instead of Upload Img. while adding log to docket history via CES Process
								//click(SOP.IGNORE_ENTITY, "Ignore Entity Checkbox");
								//click(SOP.IGNORE_REP_JURISDICTION, "Ignore Rep. Jurisdiction Checkbox");
							}
							//SEARCH_BTN
							waitForElementPresent(SOP.SEARCH_BTN, "Search button");
							assertElementPresent(SOP.SEARCH_BTN, "Search button");
							click(SOP.SEARCH_BTN, "Search button");
							//TOTAL_RECORDS_RELATED_WORKSHEET				 				 
							waitForElementPresent(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results");				 
							relatedWorksheet = Integer.parseInt(getText(SOP.TOTAL_RECORDS_RELATED_WORKSHEET,"Related worksheet search results"));
							Thread.sleep(1000);
							if(relatedWorksheet == 0) {

								click(SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
								Thread.sleep(2000);
								//RADIO_PRESENTATION_BUTTON
								String repChecked = "";
								try {
									repChecked = getAttribute(SOP.RADIO_PRESENTATION_BUTTON, "checked"); 
								}catch(NoSuchElementException e) {}
								if(repChecked == null) {
									//REP_JURISDICTION_SELECTION
									waitForElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
									assertElementPresent(SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
									selectByIndex(SOP.REP_JURISDICTION_SELECTION,1, "Rep Jurisdiction drop down");
								}
								Thread.sleep(2000);
								try {
									driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);					 
									selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law suit type in CES Page");
								}catch(NoSuchElementException e) {}
								Thread.sleep(2000);					 
								try {						 
									driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
									selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
								}catch(NoSuchElementException e) {}				
								Thread.sleep(3000);
								waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
								assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
								type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "Plaintiff text box in CES Page");

								waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
								assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
								type(SOP.DEFENDANT_TEXT_BOX,defendant, "Defendant text box CES Page");	

								waitForElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");
								assertElementPresent(SOP.CASE_ID_TEXTBOX,"Case Id text box");	
								type(SOP.CASE_ID_TEXTBOX,caseNum1,"Case Id text box");



							}
							else if (relatedWorksheet != 0) {
								//FIRST_WORKSHEET_RADIO_BTN
								waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
								assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
								click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
								//ADD_TO_DOCKET_HISTORY_BUTTON
								waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
								assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
								click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
								Thread.sleep(2000);
								waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
								caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 
								if(cdsop.equals("CDSOP")) {
									compareStrings(caseNumber,"19342919");
								}

								else if(!cdsop.equals("CDSOP")) {

									compareStrings(caseNumber,caseNum1);
								}				 
							}
						}
						if(!caseNum2.equals("")){
							//SELECT_BUTTON_IN_RELATED_LOG
							waitForElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
							assertElementPresent(SOP.SELECT_BUTTON_IN_RELATED_LOG, "Select button in Related Log section");
							click(SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
							//CASEID_TEXTBOX
							waitForElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							assertElementPresent(SOP.CASEID_TEXTBOX, "Case number Search text box");
							if(cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX,"19342919", "Case number Search text box");					 
							}
							else if(!cdsop.equals("CDSOP")) {
								type(SOP.CASEID_TEXTBOX,caseNum2, "Case number Search text box");					 
							}

							//SEARCH_BTN
							waitForElementPresent(SOP.SEARCH_BTN, "Search button");
							assertElementPresent(SOP.SEARCH_BTN, "Search button");
							click(SOP.SEARCH_BTN, "Search button");
							//FIRST_WORKSHEET_RADIO_BTN
							waitForElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							assertElementPresent(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							click(SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
							//ADD_TO_DOCKET_HISTORY_BUTTON
							waitForElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							assertElementPresent(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							click(SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
							Thread.sleep(2000);
							waitForElementPresent(SOP.CASE_ID_TEXTBOX, "Case number text field");
							caseNumber = getAttribute(SOP.CASE_ID_TEXTBOX, "value");				 	
							if(cdsop.equals("CDSOP")) {
								compareStrings(caseNumber,"19342919");
							}
							else if(!cdsop.equals("CDSOP")) {

								compareStrings(caseNumber,caseNum2);
							}
						}


						if(caseNum1.equals("")){
							Thread.sleep(1000);
							driver.switchTo().defaultContent();
							assertElementPresent(SOP.GLYPHICON_HOME, "glyphicon button");
							click(SOP.GLYPHICON_HOME, "glyphicon button");
							Thread.sleep(3000);
							driver.switchTo().frame("frame1");		
							//PLAINTIFF_TEXT_BOX			
							waitForElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
							assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
							type(SOP.PLAINTIFF_TEXT_BOX,plaintiff, "plaintiff text box");
							//DEFENDANT_TEXT_BOX				
							waitForElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
							assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "defendant text box");
							type(SOP.DEFENDANT_TEXT_BOX,defendant, "defendant text box");

							try {
								driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
								selectByIndex(SOP.LAWSUITTYPE_DROPDOWN,3, "Law Suit Type drop down");
							}catch(NoSuchElementException e) {}
							//DOCUMENT_TYPE_DROPDWN
							try {
								driver.findElement(SOP.NRAI_DOCUMENT_TYPE);	
								selectByIndex(SOP.NRAI_DOCUMENT_TYPE,3, "Document Type drop down");
							}catch(NoSuchElementException e) {}				
						}
					}
				}
			}
			Thread.sleep(3000);
			assertElementPresent(SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			//Below one check can be applied if attorney and court modification needs to be done - 1476
			if(!attorneyName.equals("")) {			 			
				//RADIO_BUTTON_ATTORNEYNONE					
				String attorneyNoneAttribute = "";

				try {
					attorneyNoneAttribute = getAttribute(SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");   			
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Radio button for Existing Attorney Sender in CES Page");
					//DROP_DOWN_ATTORNEY_SENDER_NAME
					waitForElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"Drop down for Attorney Sender Name");
					assertElementPresent(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,"DROP down for Attorney Sender Name");
					selectByIndex(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,1,"DROP down for Attorney Sender Name");
				} catch (NoSuchElementException e) {}}

			if(!courtName.equals("")) {					
				try {
					String courtNoneAttribute = "";
					courtNoneAttribute = getAttribute(SOP.RADIO_BUTTON_COURTNONE, "checked");   			
					waitForElementPresent(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					click(SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					//DROP_DOWN_COURT_NAME
					waitForElementPresent(SOP.DROP_DOWN_COURT_NAME,"Drop down for Court Name");
					assertElementPresent(SOP.DROP_DOWN_COURT_NAME,"DROP down for Court Name");
					selectByIndex(SOP.DROP_DOWN_COURT_NAME,1,"DROP down for Court Name");
				} catch (NoSuchElementException e) {}
				/*if(attorneyNoneAttribute == null) {						
						//TEXT_BOX_ATTORNEYNAME
						waitForElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
						assertElementPresent(SOP.TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
						type(SOP.TEXT_BOX_ATTORNEYNAME,attorneyName,"text field for Attorney Sender Name");	
					}
					if(courtNoneAttribute == null) {						
						//TEXT_BOX_COURTNAME
						waitForElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
						assertElementPresent(SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
						type(SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");	

					}	*/															
			}			 

			//Below one code is to escalate as Possible REjection
			if(!escalationReason.equals("")) {
				//Below one condition needs to be set if the L2 user processing CES from Escalated List
				//then update to possible rejection click can be done from here.		
				if((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List")) && escalationReason.equals("Update to Possible Rejection")) {
					//UPDATE_TO_POSSIBLE_REJECTION
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION,"Update to Possible Rejection button");

				}
				if(cesQueue.equals("Escalated List") && escalationReason.equals("Update to Possible Rejection & GetNext")) {
					//UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					assertElementPresent(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");
					click(SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,"Update to Possible Rejection & GetNext button");	
					Thread.sleep(5000);
				}				
				if(!escalationReason.equals("Update to Possible Rejection") && !escalationReason.equals("Update to Possible Rejection & GetNext")){								
					//ESCALATION_DETAILS
					waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");				
					//REASON_DRPDWN
					waitForElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(SOP.REASON_DRPDWN,escalationReason, "Escalation reason text box");
					//ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(SOP.ESCALATION_COMMENTS_TEXTBOX,"Could be a Possible Rejection", "Escalation text box");
					//ESCALATE_BTN
					waitForElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(SOP.ESCALATE_BTN, "Escalate button");
					click(SOP.ESCALATE_BTN, "Escalate button");
				}	
			}
			else if(rejectionReason.equals("") && reject.equals("Y")) {
				//REJECT_BUTTON_IN_CES
				waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(SOP.REJECT_BUTTON_IN_CES, "Reject button");	
				//REJECT_REASON_EMPTY_ERROR
				waitForElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				assertElementPresent(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				String errorMessage = getText(SOP.REJECT_REASON_EMPTY_ERROR,"Error message in CES Page");
				compareStrings(error,errorMessage);

			}
			else if(!rejectionReason.equals("") && !reject.equals("")) {
				//REJECT_REASON_DROP_DOWN
				waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
				if(!notRejecting.equals("")) {
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reason for not Rejecting drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");								
					//ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
				else if(notRejecting.equals("")) {
					if(attorneyName.equals("")) {
						//ATTORNEY_SENDER_NONE_SPECIFIED
						waitForElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						assertElementPresent(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						click(SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					//commenting below as List of WebElemets not required
					//List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {				
						traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}
					//HARD_COPY_DELIVERY
					waitForElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");			
					String hardCopy = getText(SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					//REJECT_REASON_DROP_DOWN
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REJECT_BUTTON_IN_CES
					waitForElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);												
					if(hardCopy.equals("No") && error.equals("")) {		
						String parentWin= driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow();
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1]).get(0);		
						assertTextContains(letterPopup,rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}				
					//ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if(attorneyName.equals("")) {
						waitForElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						assertElementPresent(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						String errorMessage = getText(SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,"Error message in CES Page");
						compareStrings(error,errorMessage);
					}
				}
			}			
			else if(escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
				if  (!rejectionReason.equals("")){
					waitForElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(SOP.REJECT_REASON_DROP_DOWN,1,"Reject Reason drop down");
					//REASON_FOR_NOT_REJECTING
					waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {				
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 
							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}

					//SUBMIT_CES				
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
					//SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					assertElementPresent(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					String errorMessage = getText(SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED,"Error message in CES Page");
					compareStrings(error,errorMessage);
				}
				else if  (rejectionReason.equals("")){
					List<WebElement> traceableMail = null;
					//TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if(traceableMail != null) { 

							type(SOP.TRACEABLE_MAIL_FIELD,"123456", "Traceable mail field in CES page");
						}
					}catch(NoSuchElementException e) {}	

					/* Below Code is addded on 1/21 as part of GCNBO-1740
    			  To handle the onhold submit scenario when the
    			  Escalation Reason for the esop is Possible Rejection    			  
					 */
					if(cesQueue.equals("OnHold List")) {
						//ESCALATION_DETAILS
						waitForElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						assertElementPresent(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						click(SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");	
						//ESCALATION_REASON
						waitForElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						assertElementPresent(SOP.ESCALATION_REASON, "Escalation Reason");
						String escalationReasonInOnHold = getText(SOP.ESCALATION_REASON, "Escalation Reason");	

						if(escalationReasonInOnHold.equals("Possible Rejection")) {
							waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							selectByIndex(SOP.REASON_FOR_NOT_REJECTING,1,"Reject Reason drop down");
							Thread.sleep(2000);	

						}
					}    			    			
					/* Till here the code change made as on 1/21 */






					//REASON_FOR_NOT_REJECTING
					if(cesQueue.equals("Rejections List")) {
						waitForElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						assertElementPresent(SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						selectByVisibleText(SOP.REASON_FOR_NOT_REJECTING,notRejecting,"Reject Reason drop down");
						Thread.sleep(2000);
					}
					//INTERNAL_COMMENTS_CES
					waitForElementPresent(SOP.CES_INTERNAL_COMMENTS, "CES Internal Comments");
					assertElementPresent(SOP.CES_INTERNAL_COMMENTS, "CES Internal Comments");
					type(SOP.CES_INTERNAL_COMMENTS, "Process Validated", "Internal Comments Text");
					Thread.sleep(2000);

					//SUBMIT_CES
					waitForElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(SOP.SUBMIT_CES, "Submit button in CES Page");
					click(SOP.SUBMIT_CES, "Submit button in CES Page");	
				}
			}
			else if(!onHold.equals("")) {
				//REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(SOP.REASON_FOR_HOLD_TEXTBOX,"Putting on On hold for further verification","Reason for On Hold Text box");
				//ONHOLD_BTN
				waitForElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(SOP.ONHOLD_BTN, "On Hold button");
				click(SOP.ONHOLD_BTN, "On Hold button");
			}

		}catch(Exception e) {}
		return esopId.split("\\: ")[1];	
	}

	public String verifyNOAfieldstMethod(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			List<String> originalNOAList = new ArrayList<String>();
			List<String> updatedNOAList = Arrays.asList("-- Select One --", "Amount $", "Breach of Contract",
					"Breach of Contract -", "Class Action -", "Continue withholding the nonexempt earnings of the...",
					"Continuing lien is extended until", "Default Judgment", "Hearing has been scheduled",
					"Lien - Amount $", "Motion for Summary Final Judgment of Foreclosure", "Notice of hearing",
					"Order of continuing lien", "Pertaining to", "Product Name: VIN:", "Release of Garnishment",
					"Request for status of Garnishment previously serve...",
					"Request for status of Subpoena previously served",
					"Second answer to writ of garnishment for continuin...", "Seeking $", "Subrogation",
					"Termination of Garnishment", "VIN:", "Violation -", "Wrongful Death");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {

				// Select Nature of Action from dropdown
				click(WorksheetCreate.NATURE_OF_ACTION, "Select Nature of Action from dropdown");

				List<WebElement> arr = getAllDropDownData(WorksheetCreate.NATURE_OF_ACTION);

				Iterator<WebElement> iter = arr.iterator();

				while (iter.hasNext()) {
					WebElement we = iter.next();

					originalNOAList.add(we.getText());
				}
				compareTwoArrayList(updatedNOAList, originalNOAList);
			}

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;

	}

	public String verifyNOAWorksheetCreate(String reportSheet, int count, String esopId) throws Throwable {

		try {
			createWorksheetViaSOPList(reportSheet, count, esopId);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			if (verifyIfElementPresent(WorksheetCreate.NATURE_OF_ACTION, "Nature of Action")) {
				verifyNOAfieldstMethod(reportSheet, count);
				click(Generic.CANCEL, "Cancel Button");
				assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination",
						"Service of Process Destination Page");
			} else {
				System.out.println("No Nature of Action Field present on Create Worksheet Page");
			}
		} catch (Exception e) {
			throw e;
		}
		return reportSheet;
	}

	public String verifyNOAWorksheetEdit(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAWorksheetReview(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void UICreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;
			assertElementPresent(SOP.CREATE_HELP_ICON, "Help Page Icon");
			assertElementPresent(SOP.CANCEL_BUTTON, "Cancel Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_INCOMPLETE_BUTTON, "Save Incomplete Button");
			assertElementPresent(SOP.BAD_LOG_FIELD, "Bad Log Field");
			assertElementPresent(SOP.BAD_LOG_CHECKBOX, "Bad Log Checkbox");
			assertElementPresent(SOP.WORKSHEET_TYPE_FIELD, "Worskheet Type Field");
			String WorksheetType = getText(SOP.WORKSHEET_TYPE, "WOrksheet Type");
			if (WorksheetType.equals("DSSOP")) {
				assertElementPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				assertElementPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				assertElementPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN, "Direct Served Process Method of Service Dropdown");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_DATE ,"Direct Served Process Received Date");
				assertElementPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_TIME, "Direct Served Process Received Time");
				assertElementPresent(SOP.CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION, "Customer Comments CDSOP Only Section");
				assertElementPresent(SOP.CUSTOMER_COMMENTS_BOX, "Customer Comments Box");



			} else {
				isElementNotPresent(SOP.CONFIRMATION_NUMBER_FIELD, "Confirmation Number Field");
				isElementNotPresent(SOP.CUSTOMER_FIELD, "Customer Field");
				isElementNotPresent(SOP.INDIVIDUAL_FIELD, "Individual Field");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_METHOD_OF_SERVICE_DRPDWN, "Direct Served Process Method of Service Dropdown");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_DATE ,"Direct Served Process Received Date");
				isElementNotPresent(SOP.DIRECT_SERVED_PROCESS_RECEIVED_TIME, "Direct Served Process Received Time");
				isElementNotPresent(SOP.CUSTOMER_COMMENTS_CDSOP_ONLY_SECTION, "Customer Comments CDSOP Only Section");
				isElementNotPresent(SOP.CUSTOMER_COMMENTS_BOX, "Customer Comments Box");

			}

			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_TEAM, "Received By Team Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_MEMBER_DPDOWN, "Received By Member Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_COLLAPSABLE_ARROW, "Received By Collapsable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_TEAM_DPDOWN, "Assigned To Team Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_MEMBER_DPDOWN, "Assigned To Member Dropdown");
			assertElementPresent(SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Yes Radio Button");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.INITIAL_RADIOBTN, "Inintial/Subsequent Field");
			assertElementPresent(SOP.CONSOLIDATED_YES_RADIO_BUTTON, "Consolidated Field");
			assertElementPresent(SOP.BANKRUPTCY_YES_RADIO_BUTTON, "Bankruptcy Field");
			assertElementPresent(SOP.LETTER_YES_RADIO_BUTTON, "Letter Field");
			assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			assertElementPresent(SOP.TARGET_DETAILS_SECTION, "Target details Section");
			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.REJECT_DETAILS_SECTION, "Reject details Section");
			assertElementPresent(SOP.REJECT_REASON_DROP_DOWN, "Reject Reason Dropdown");
			assertElementPresent(SOP.REJECT_DATE, "Reject Date");
			assertElementPresent(SOP.COURT_DETAILS_SECTION, "Court details Section");
			assertElementPresent(SOP.COURT_NONE_RADIOBTN, "Court None Specified Radio button");
			assertElementPresent(SOP.AGENCY_DETAILS_SECTION, "Agency details Section");
			assertElementPresent(SOP.AGENCY_NONE_RADIOBTN, "Agency None Specified Radio button");
			assertElementPresent(SOP.ATTORNEY_DETAILS_SECTION, "Attorney details Section");
			assertElementPresent(SOP.ATTORNEY_NONE_RADIOBTN, "Attorney None Specified Radio button");
			assertElementPresent(SOP.COURT_HELP_ICON, "Court Help Icon");
			assertElementPresent(SOP.CUSTOMER_PARTICIPANT_SEARCHBTN, "Customer/Participant Search Button");
			assertElementPresent(SOP.ATTORNEY_DETAILS_SECTION, "Attorney details Section");

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					assertElementPresent(SOP.LAWSUIT_TYPE_DROPDOWN,"Lawsuit Type Dropdown");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					//assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					assertElementPresent(SOP.LAWSUIT_TYPE_DROPDOWN,"Lawsuit Type Dropdown");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					assertElementPresent(SOP.LAW_SUIT_SUB_TYPE_DRPDWN, "Lawsuit Sub type dropdown");
					//assertElementPresent(SOP.NOA_DRPDWN, "Nature Of Action dropdown");
				}
			}

			assertElementPresent(SOP.AMOUNT_DUE_DRPDWN, "Amount Due Dropdown");
			assertElementPresent(SOP.ANSWER_NONE_RADIOBTN, "Answer Date Field");
			assertElementPresent(SOP.REMARKS_SECTION, "Remarks Section");
			assertElementPresent(SOP.REMARKS_DRPDWN, "Remarks dropdown");
			assertElementPresent(SOP.COMMENTS_SECTION, "Comments Section");
			assertElementPresent(SOP.INTERNAL_COMMENTS_DRPDWN, "Internal Comments Dropdown");

			assertElementPresent(SOP.BOTTOM_CANCELBTN, "Cancel Button at Buttom");
			assertElementPresent(SOP.BOTTOM_SAVEBTN, "Save Button at Buttom");
			assertElementPresent(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Buttom");
			//assertElementPresent(SOP.WIREFRAME_NUMBER, "Wireframe Number");
			//assertElementPresent(SOP.BOTTOM_MODULE_LINK, "Module links at bottom of the page");

			isElementNotPresent(SOP.SEND_MESSAGE_BTN, "Send Message Button");
			isElementNotPresent(SOP.NEXT_BTN, "Next Button");
			isElementNotPresent(SOP.PREV_BTN, "Previous Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public String verifyUIofCreateWorksheetPage(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			Thread.sleep(5000);
			UICreateEditReviewWorksheetPage();

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public void validateSaveCreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}

			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			waitForElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			click(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Criteria", "Page Title");
			selectBySendkeys(SOP.NAME_TEXTBOX, "ct", "Entering Entity Name");
			click(SOP.SEARCH_BTN, "Search Button");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Results", "Page Title");

			/*click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Btn");
			click(SOP.CANCEL_BUTTON, "Cancel Btn");*/
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			waitForElementToBePresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			waitForElementToBePresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Unidentified Entity Radio Button Selected");
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Unidentified Entity Radio Button Selected");
			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");

			waitForElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			assertElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementToBeClickable(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			click(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			waitForElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			selectBySendkeys(SOP.RECEIVED_BY_FACILITY, "-- Select One --", "Clear Received By Facility Dropdown");
			waitForElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			waitForElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			selectBySendkeys(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "-- Select One --", "Clear Assigned To Facility Dropdown");

			/*assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			click(SOP.CASE_NUMBER, "Case Number");
			type(SOP.CASE_TEXTFIELD, "", "Clear Case Id Textbox");

			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			selectByVisibleText(SOP.METHOD_OF_SERVICE, "Fax", "Method of service dropdown");*/

			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			/*selectByVisibleText(SOP.METHOD_OF_SERVICE, "Fax", "Clear Method of service dropdown");*/
			selectByVisibleText(SOP.METHOD_OF_SERVICE, "-- Select One --", "Clear Method of service dropdown");

			waitForElementToBePresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			assertElementPresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			click(SOP.CASE_RADIO_BTN, "Case Radio Button");
			waitForElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			assertElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			type(WorksheetCreate.CASE_TEXT, "", "Clear Text Field for Case");

			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			click(SOP.PLAINTIFF_RADIOBTN, "Plaintiff Radio Btn");
			type(SOP.PLAINTIFF_TEXT_BOX, "", "Clear Plaintiff Textbox");

			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			type(SOP.DEFENDANT_TEXTFIELD, "", "Clear Defendant Textbox");

			click(SOP.RADIO_BUTTON_EXISTING_COURT, "Court Existing Radio button");
			selectBySendkeys(SOP.STATE_OF_COURT_DRPDWN, "-- Select One --", "Clear State of Court Drpdown");
			//type(SOP.TEXT_BOX_COURTNAME, "", "Clear Court Textbox");
			//waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Court Drpdown");
			//selectBySendkeys(SOP.DROP_DOWN_COURT_NAME, "-- Select One --", "Clear Court Drpdown");
			click(SOP.EXISTING_AGENCY_RADIO_BTN, "Agency Existing Radio button");
			type(SOP.TEXT_BOX_AGENCY, "", "Clear Agency Textbox");
			selectBySendkeys(SOP.EXISTING_AGENCY_DRPDOWN, "-- Select One --", "Clear Existing Agency Drpdown");
			click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Attorney Existing Radio button");
			type(SOP.TEXTBOX_ATTORNEYNAME, "", "Clear Attorney Textbox");
			selectBySendkeys(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "-- Select One --", "Clear Existing Attorney Drpdown");

			assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
			selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Textbox");
			click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
			click(SOP.ANSWER_RADIOBTN, "Answer Date Field");
			click(SOP.ANSWER_SELECT_ONE_DRPDOWN, "Clear Answer Drpdown");
			type(SOP.ANSWER_DATE_TEXTFIELD, "", "Clear Answer Date Textbox");
			selectBySendkeys(SOP.REMARKS_DRPDWN, "-- Select One --", "Clear Remarks Drpdwn");
			type(SOP.REMARKS_TEXTBOX, "", "Clear Remarks Textbox");

			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			type(SOP.RECEIPT_DATE_FIELD, "", "Clear Receipt Date Textbox");

			click(SOP.BOTTOM_SAVEBTN, "Save Button at Bottom");

			isElementPresent(SOP.RECEIPT_DATE_ERRMSG, "Error Msg For Receipt Date");
			assertTextMatching(SOP.RECEIPT_DATE_ERRMSG, "Enter a value for Receipt Date.", "Error Msg For Receipt Date");

			isElementPresent(SOP.RECEIVED_BY_ERRMSG, "Error Msg For Received By Facility");
			assertTextMatching(SOP.RECEIVED_BY_ERRMSG, "Select a value for Received By Facility.", "Error Msg For Received By Facility");

			isElementPresent(SOP.ASSIGNED_TO_ERRMSG, "Error Msg For Assigned To Facility");
			assertTextMatching(SOP.ASSIGNED_TO_ERRMSG, "Select a value for Assigned To Facility.", "Error Msg For Assigned To Facility");

			isElementPresent(SOP.METHOD_OF_SERVICE_ERRMSG, "Error Msg For Method of Service.");
			assertTextMatching(SOP.METHOD_OF_SERVICE_ERRMSG, "Select a value for Method of Service.", "Error Msg For Method of Service.");

			if(verifyIfElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent")){

				isElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent");
				assertTextMatching(SOP.INITIAL_ERRMSG, "Choose Initial/Subsequent", "Error Msg For Initial/Subsequent");

			}

			if(verifyIfElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name")){
				isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG, "Enter a value for Plaintiff / Debtor.", "Error Msg For Plaintiff Name");

			}

			if(verifyIfElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor")){
				isElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor");
				assertTextMatching(SOP.CASEID_PLAINTIFF_ERRMSG, "Enter values for Case # and Plaintiff / Debtor.", "Error Msg For Case # and Plaintiff / Debtor");

			}
			isElementPresent(SOP.DEFENDANT_ERRMSG, "Error Msg For Defendant/Creditor Name");
			assertTextMatching(SOP.DEFENDANT_ERRMSG, "Enter a value for Defendant/Creditor Name.", "Error Msg For Defendant/Creditor Name");

			if(verifyIfElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity")){
				isElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity");
				assertTextMatching(SOP.CT_ENTITY_ERRMSG, "Select a value for CT Entity.", "Error Msg For CT Entity");
			}

			if(verifyIfElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation")){
				isElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation");
				assertTextMatching(SOP.REPRESENTATION_ERRMSG, "Select a value for Representation.", "Error Msg For Representation");
			}

			isElementPresent(SOP.COURT_ERRMSG, "Error Msg For Court");
			assertTextMatching(SOP.COURT_ERRMSG,
					"Court must be entered or 'None Specified' selected.",
					"Error Msg For Court");

			isElementPresent(SOP.AGENCY_ERRMSG, "Error Msg For Agency");
			assertTextMatching(SOP.AGENCY_ERRMSG,
					"Agency must be entered or 'None Specified' selected.",
					"Error Msg For Agency");

			isElementPresent(SOP.ATTORNEY_ERRMSG, "Error Msg For Attorney");
			assertTextMatching(SOP.ATTORNEY_ERRMSG,
					"Attorney must be entered or 'None Specified' selected.",
					"Error Msg For Attorney");

			isElementPresent(SOP.CT_DOCUMENT_TYPE_ERRMSG, "Error Msg For Document Type");
			assertTextMatching(SOP.CT_DOCUMENT_TYPE_ERRMSG,
					"Enter a value for Document Type.",
					"Error Msg For Document Type");

			if(verifyIfElementPresent(SOP.SPECIAL_CIRCUMSTANCES_ERRMSG, "Error Msg For Special Circumstances")){
				isElementPresent(SOP.SPECIAL_CIRCUMSTANCES_ERRMSG, "Error Msg For Special Circumstances");
				assertTextMatching(SOP.SPECIAL_CIRCUMSTANCES_ERRMSG,
						"Select a value for Special Circumstance.",
						"Error Msg For Special Circumstances");
			}

			isElementPresent(SOP.LAWSUIT_ERRMSG, "Error Msg For LawsuitType");
			assertTextMatching(SOP.LAWSUIT_ERRMSG,
					"Select a value for LawsuitType.",
					"Error Msg For LawsuitType");

			isElementPresent(SOP.ANSWER_DATE_ERRMSG, "Error Msg For Answer Date");
			assertTextMatching(SOP.ANSWER_DATE_ERRMSG,
					"Answer Date must be entered or 'None Specified' selected.",
					"Error Msg For Answer Date");	

			if(verifyIfElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks")){
				isElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks");
				assertTextMatching(SOP.REMARKS_ERRMSG,
						"Enter a value for valid Remarks.",
						"Error Msg For Remarks");
			}

			if(verifyIfElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype"))
			{
				/*isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG,
						"Enter a value for Plaintiff / Debtor.",
						"Error Msg For Plaintiff");*/

				assertElementPresent(SOP.REVIEW_SUB_TYPE, "Review Subtype dropdown");
				selectBySendkeys(SOP.REVIEW_SUB_TYPE, "-- Select One --", "Clear Method of service dropdown");

				isElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype");
				assertTextMatching(SOP.REVIEW_SUBTYPE_ERRMSG,
						"Select a value for Review sub type.",
						"Error Msg For Review Subtype");

			}

		} catch (Exception e) {
			throw e;
		}

	}

	public void validateSaveIncompleteCreateEditReviewWorksheetPage() throws Throwable {
		try {
			blnEventReport = true;

			//Verify fields for Arrow  Entity
			if(verifyIfElementPresent(SOP.ARROW_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {
				String BranchPlant=getText(SOP.ARROW_ENTITY_BRANCHPLANT,"Get the branchplant of the entity");
				if(BranchPlant.equalsIgnoreCase("CTCORP")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(BranchPlant.equalsIgnoreCase("NRAI")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}
			//Verify fields for Unidentified  Entity
			else if(verifyIfElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected")) {

				if(verifyIfElementPresent(SOP.CTCORP_ENTITY_SELECTED, "Branch Plant Selected as ctcorp")) {
					assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
					selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Text");
					click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
				}
				else if(verifyIfElementPresent(SOP.NRAI_ENTITY_SELECTED, "Branch Plant Selected as nrai")) {
					assertElementPresent(SOP.NRAI_DOCUMENT_TYPE_DROPDWN,"NRAI Document Type Drpdwn");
					selectBySendkeys(SOP.NRAI_DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
					assertElementPresent(SOP.DOCUMENT_SERVED,"Document Served");
					selectBySendkeys(SOP.DOCUMENT_SERVED, "-- Select One --", "Clear Document Served");
				}
			}

			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			waitForElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertElementPresent(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			click(SOP.SELECT_ENTITY_BTN, "Select Arrow Entity");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Criteria", "Page Title");
			selectBySendkeys(SOP.NAME_TEXTBOX, "ct", "Entering Entity Name");
			click(SOP.SEARCH_BTN, "Search Button");
			assertTextMatching(SOP.PAGE_TITLE, "Entity Name Search Results", "Page Title");

			/*click(SOP.SEARCH_AGAIN_BUTTON, "Search Again Btn");
			click(SOP.CANCEL_BUTTON, "Cancel Btn");*/
			click(SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity Btn");
			waitForElementToBePresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			assertElementPresent(SOP.ARROW_UNIDENTIFIED_ENTITY_FIELD, "Arrow Unidentified Entity Field");
			waitForElementToBePresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected");
			assertElementPresent(SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON_SELECTED, "Arrow Entity Radio Button Selected");
			waitForElementToBePresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			assertElementPresent(SOP.ARROW_ENTITY_FIELD, "Arrow Entity Field");
			waitForElementToBePresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			assertElementPresent(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");
			click(WorksheetCreate.RADIO_ENTITY_SELECT, "Arrow Entity Radio Button Selected");

			waitForElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			assertElementPresent(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementToBeClickable(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			click(SOP.RADIO_PRESENTATION_BUTTON, "Representation Radio Button");
			waitForElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			assertElementPresent(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			click(SOP.RECEIVED_BY_EXPANDABLE_ARROW, "Received By Expnadable Arrow");
			waitForElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			assertElementPresent(SOP.RECEIVED_BY_FACILITY, "Received By Facility Dropdown");
			selectBySendkeys(SOP.RECEIVED_BY_FACILITY, "-- Select One --", "Clear Received By Facility Dropdown");
			waitForElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			assertElementPresent(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			click(SOP.ASSIGNED_TO_EXPANDABLE_ARROW, "Assigned To Expnadable Arrow");
			waitForElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			assertElementPresent(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "Assigned To Facility Dropdown");
			selectBySendkeys(SOP.ASSIGNED_TO_FACILITY_DPDOWN, "-- Select One --", "Clear Assigned To Facility Dropdown");


			/*assertElementPresent(SOP.CASE_TEXT_PS_CASENUM, "Case Id Textbox");
			click(SOP.CASE_NUMBER, "Case Number");
			type(SOP.CASE_TEXTFIELD, "", "Clear Case Id Textbox");
			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			selectBySendkeys(SOP.METHOD_OF_SERVICE, "Fax", "Method of service dropdown");*/

			waitForElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			assertElementPresent(SOP.METHOD_OF_SERVICE, "Method of service dropdown");
			/*selectByVisibleText(SOP.METHOD_OF_SERVICE, "Fax", "Clear Method of service dropdown");*/
			selectByVisibleText(SOP.METHOD_OF_SERVICE, "-- Select One --", "Clear Method of service dropdown");

			waitForElementToBePresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			assertElementPresent(SOP.CASE_RADIO_BTN, "Case Radio Button");
			click(SOP.CASE_RADIO_BTN, "Case Radio Button");
			waitForElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			assertElementPresent(WorksheetCreate.CASE_TEXT, "Text Field for Case");
			type(WorksheetCreate.CASE_TEXT, "", "Clear Text Field for Case");

			assertElementPresent(SOP.PLAINTIFF_TEXT_BOX, "Plaintiff Textbox");
			click(SOP.PLAINTIFF_RADIOBTN, "Plaintiff Radio Btn");
			type(SOP.PLAINTIFF_TEXT_BOX, "", "Clear Plaintiff Textbox");

			assertElementPresent(SOP.DEFENDANT_TEXT_BOX, "Defendant Textbox");
			type(SOP.DEFENDANT_TEXTFIELD, "", "Clear Defendant Textbox");

			click(SOP.RADIO_BUTTON_EXISTING_COURT, "Court Existing Radio button");
			selectBySendkeys(SOP.STATE_OF_COURT_DRPDWN, "-- Select One --", "Clear State of Court Drpdown");
			//type(SOP.TEXT_BOX_COURTNAME, "", "Clear Court Textbox");
			//waitForElementPresent(SOP.DROP_DOWN_COURT_NAME, "Court Drpdown");
			//selectBySendkeys(SOP.DROP_DOWN_COURT_NAME, "-- Select One --", "Clear Court Drpdown");
			click(SOP.EXISTING_AGENCY_RADIO_BTN, "Agency Existing Radio button");
			type(SOP.TEXT_BOX_AGENCY, "", "Clear Agency Textbox");
			selectBySendkeys(SOP.EXISTING_AGENCY_DRPDOWN, "-- Select One --", "Clear Existing Agency Drpdown");
			click(SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER, "Attorney Existing Radio button");
			type(SOP.TEXTBOX_ATTORNEYNAME, "", "Clear Attorney Textbox");
			selectBySendkeys(SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "-- Select One --", "Clear Existing Attorney Drpdown");

			assertElementPresent(SOP.DOCUMENT_TYPE_DROPDWN,"Document Type Drpdwn");
			selectBySendkeys(SOP.DOCUMENT_TYPE_DROPDWN, "-- Select One --", "Clear Document Type Drpdwn");
			type(SOP.DOCUMENT_TYPE_TEXTFIELD, "", "Clear Document Type Textbox");
			click(SOP.LAWSUITTYPE_SELECT_ONE_DROPDOWN, "Clear Lawsuit Type Drpdown");
			click(SOP.ANSWER_RADIOBTN, "Answer Date Field");
			click(SOP.ANSWER_SELECT_ONE_DRPDOWN, "Clear Answer Drpdown");
			type(SOP.ANSWER_DATE_TEXTFIELD, "", "Clear Answer Date Textbox");

			selectBySendkeys(SOP.REMARKS_DRPDWN, "-- Select One --", "Clear Remarks Drpdwn");
			type(SOP.REMARKS_TEXTBOX, "", "Clear Remarks Textbox");

			assertElementPresent(SOP.RECEIPT_DATE_FIELD, "Receipt Field");
			type(SOP.RECEIPT_DATE_FIELD, "", "Clear Receipt Date Textbox");

			if(verifyIfElementPresent(SOP.SAVE_INCOMPLETE_REVIEW_BUTTON, "Save Incomplete Review Button at Bottom")) {
				click(SOP.SAVE_INCOMPLETE_REVIEW_BUTTON, "Save Incomplete Review Button at Bottom");
			}
			else
			{
				click(SOP.BOTTOM_SAVEINCOMPLETEBTN, "Save Incomplete Button at Bottom");
			}


			isElementPresent(SOP.RECEIPT_DATE_ERRMSG, "Error Msg For Receipt Date");
			assertTextMatching(SOP.RECEIPT_DATE_ERRMSG, "Enter a value for Receipt Date.", "Error Msg For Receipt Date");

			isElementPresent(SOP.RECEIVED_BY_ERRMSG, "Error Msg For Received By Facility");
			assertTextMatching(SOP.RECEIVED_BY_ERRMSG, "Select a value for Received By Facility.", "Error Msg For Received By Facility");

			isElementPresent(SOP.ASSIGNED_TO_ERRMSG, "Error Msg For Assigned To Facility");
			assertTextMatching(SOP.ASSIGNED_TO_ERRMSG, "Select a value for Assigned To Facility.", "Error Msg For Assigned To Facility");

			isElementPresent(SOP.METHOD_OF_SERVICE_ERRMSG, "Error Msg For Method of Service.");
			assertTextMatching(SOP.METHOD_OF_SERVICE_ERRMSG, "Select a value for Method of Service.", "Error Msg For Method of Service.");

			if(verifyIfElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent")){

				isElementPresent(SOP.INITIAL_ERRMSG, "Error Msg For Initial/Subsequent");
				assertTextMatching(SOP.INITIAL_ERRMSG, "Choose Initial/Subsequent", "Error Msg For Initial/Subsequent");

			}

			if(verifyIfElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name")){
				isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff Name");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG, "Enter a value for Plaintiff / Debtor.", "Error Msg For Plaintiff Name");

			}

			if(verifyIfElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor")){
				isElementPresent(SOP.CASEID_PLAINTIFF_ERRMSG, "Error Msg For Case # and Plaintiff / Debtor");
				assertTextMatching(SOP.CASEID_PLAINTIFF_ERRMSG, "Enter values for Case # and Plaintiff / Debtor.", "Error Msg For Case # and Plaintiff / Debtor");

			}

			isElementPresent(SOP.DEFENDANT_ERRMSG, "Error Msg For Defendant/Creditor Name");
			assertTextMatching(SOP.DEFENDANT_ERRMSG, "Enter a value for Defendant/Creditor Name.", "Error Msg For Defendant/Creditor Name");

			if(verifyIfElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity")){
				isElementPresent(SOP.CT_ENTITY_ERRMSG, "Error Msg For CT Entity");
				assertTextMatching(SOP.CT_ENTITY_ERRMSG, "Select a value for CT Entity.", "Error Msg For CT Entity");
			}

			if(verifyIfElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation")){
				isElementPresent(SOP.REPRESENTATION_ERRMSG, "Error Msg For Representation");
				assertTextMatching(SOP.REPRESENTATION_ERRMSG, "Select a value for Representation.", "Error Msg For Representation");
			}

			isElementPresent(SOP.COURT_ERRMSG, "Error Msg For Court");
			assertTextMatching(SOP.COURT_ERRMSG,
					"Court must be entered or 'None Specified' selected.",
					"Error Msg For Court");

			isElementPresent(SOP.AGENCY_ERRMSG, "Error Msg For Agency");
			assertTextMatching(SOP.AGENCY_ERRMSG,
					"Agency must be entered or 'None Specified' selected.",
					"Error Msg For Agency");

			if(verifyIfElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks"))
			{
				isElementPresent(SOP.REMARKS_ERRMSG, "Error Msg For Remarks");
				assertTextMatching(SOP.REMARKS_ERRMSG,
						"Enter a value for valid Remarks.",
						"Error Msg For Remarks");

			}

			if(verifyIfElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype"))
			{
				/*isElementPresent(SOP.PLAINTIFF_ERRMSG, "Error Msg For Plaintiff");
				assertTextMatching(SOP.PLAINTIFF_ERRMSG,
						"Enter a value for Plaintiff / Debtor.",
						"Error Msg For Plaintiff");*/

				assertElementPresent(SOP.REVIEW_SUB_TYPE, "Review Subtype dropdown");
				selectBySendkeys(SOP.REVIEW_SUB_TYPE, "-- Select One --", "Clear Method of service dropdown");

				isElementPresent(SOP.REVIEW_SUBTYPE_ERRMSG, "Error Msg For Review Subtype");
				assertTextMatching(SOP.REVIEW_SUBTYPE_ERRMSG,
						"Select a value for Review sub type.",
						"Error Msg For Review Subtype");

			}

			isElementNotPresent(SOP.CT_DOCUMENT_TYPE_ERRMSG, "Error Msg For Document Type");
			isElementNotPresent(SOP.LAWSUIT_ERRMSG, "Error Msg For LawsuitType");
			isElementNotPresent(SOP.ANSWER_DATE_ERRMSG, "Error Msg For Answer Date");

		} catch (Exception e) {
			throw e;
		}
	}

	public String validateErrMsgofCreateWorksheetPage(String ReportSheet, int count, String esopId) throws Throwable {
		try {
			blnEventReport = true;
			createWorksheetViaSOPList(ReportSheet, count, esopId);
			assertTextMatching(SOP.PAGE_TITLE, "Create Worksheet", "Title of the page");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			validateSaveCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

			String esop_Id = entitySectionDetailsOnProcessingCES(ReportSheet, count);
			createWorksheetViaSOPList(ReportSheet, count, esop_Id);
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Create Details iFrame");
			validateSaveIncompleteCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertTextMatching(SOP.CES_PRODUCTIVITY_TITLE, "Service of Process Destination", "Service of Process Destination Page");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String validateErrMsgofEditWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			/*// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");
			// Select first data on the page
			click(WorksheetCreate.FIRST_SOP_DATA, "First SOP Data");*/

			// click on WorkSheet Search link on Home page
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Worksheet Search Left Nav");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit Worksheet
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			validateSaveCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			// click on WorkSheet Search link on Home page
			click(SearchWorksheet.SEARCH_WORKSHEET_LEFT_NAV, "Worksheet Search Left Nav");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			validateSaveIncompleteCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String validateErrMsgofReviewWorksheetPage(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			//Verify Review Worksheet Page
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			validateSaveCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

			// click on My Worksheet link on Home page
			click(HomePage.MY_WORKSHEET_LINK, "My Worksheet Link");
			assertElementPresent(WorksheetCreate.SOP_DESTINATION, "SOP Destination Page");

			// click on My Worksheets to Review tab
			click(HomePage.MY_WORKSHEET_TO_REVIEW_LINK, "My Worksheets to Review Link");

			// Select first data on the page
			click(WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA, "First SOP Data");
			// Verify Review Worksheet Page
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			validateSaveIncompleteCreateEditReviewWorksheetPage();
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAExistingWorksheet(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_DATE_CALENDAR, "Date Calendar (Personal Injury)", "NOA Date Calendar");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			verifyNOAfieldstMethod(ReportSheet, count);
			click(Generic.CANCEL, "Cancel Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_DATE_CALENDAR, "Date Calendar (Personal Injury)", "NOA Date Calendar");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAExistingWorksheetEditedSaved(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			// Click on Edit WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			assertElementPresent(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			click(SOP.WORKSHEET_EDIT_BTN, "Edit Worksheet");
			waitForElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			assertElementPresent(WorksheetCreate.EDIT_WORKSHEET_SINGLE, "Edit Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Edit Details iFrame");
			//verifyNOAfieldstMethod(ReportSheet, count);
			selectByVisibleText(SOP.NOA_DRPDWN, "Termination of Garnishment", "NOA dropdown field");
			/*
			Thread.sleep(2000);
			type(SOP.REMARKS_TEXTBOX, "Remarks Entered:-Testing In Progress", "Clear Remarks Textbox");*/
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.WORKSHEET_REMARKS_TEXTBOX, "", "Clear Remarks Textbox");
			waitForElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
			assertElementPresent(SOP.INTERNAL_COMMENTS_TEXTBOX, "Internal Comments Text");
			type(SOP.INTERNAL_COMMENTS_TEXTBOX, "Worksheet Processed", "Internal Comments Text");
			/*waitForElementToBePresent(SOP.REMARKS_DRPDWN, "Remarks dropdown field");
			assertElementPresent(SOP.REMARKS_DRPDWN, "Remarks dropdown field");
			selectByVisibleText(SOP.REMARKS_DRPDWN, "Refer to previous log #___ forwarded on ___.", "Remarks dropdown field");
			selectByIndex(SOP.REMARKS_DRPDWN,2, "Remarks dropdown field");*/
			waitForElementToBePresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			assertElementPresent(SOP.WORKSHEET_REMARKS_TEXTBOX, "Remarks Textbox");
			type(SOP.REMARKS_TEXTBOX, "Worksheet Edited", "Remarks Text");
			waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
			assertElementPresent(SOP.SAVE_BTN, "Save Button");
			click(SOP.SAVE_BTN, "Save Button");
			//Enter a value for Remarks.
			try {
				WebElement remarksNotEntered = null;	
				remarksNotEntered = driver.findElement(SOP.REMARKS_ERRMSG);
				if(remarksNotEntered != null) {	
					type(SOP.REMARKS_TEXTBOX,"Remarks entered in Selenium Automation","Remarks text box");
					waitForElementToBePresent(SOP.SAVE_BTN, "Save Button");
					assertElementPresent(SOP.SAVE_BTN, "Save Button");
					click(SOP.SAVE_BTN, "Save Button");
				}
			}
			catch (NoSuchElementException e) {}

			waitForElementToBePresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_TERMINATIONOFGARNISHMENT, "Termination of Garnishment", "NOA Termination of Garnishment");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}

	public String verifyNOAExistingWorksheetReviewedSaved(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;

			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);
			// click on WorkSheet Search link on Home page
			click(HomePage.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
			assertElementPresent(SearchWorksheet.WORKSHEET_SEARCH_PAGE, "Worksheet Search Criteria Page");
			// click on Classic Search Button
			click(SearchWorksheet.CLASSIC_SEARCH_BUTTON, "Classic Search Button");
			assertElementPresent(SearchWorksheet.CLASSIC_SEARCH_PAGE, "Classic Worksheet Search Criteria Page");
			type(SearchWorksheet.LOG_ID_TEXT, worksheetId, "Enter Log#");
			click(Generic.SEARCH, "Search Button");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			//Click on Review WorkSheet Button
			waitForElementPresent(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			click(SOP.WORKSHEET_REVIEW_BTN, "Review Worksheet");
			waitForElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			assertElementPresent(WorksheetCreate.REVIEW_WORKSHEET_TITLE, "Review Worksheet Title");
			waitForFrameToLoadAndSwitchToIt(SOP.CREATE_EDIT_REVIEW_IFRAMEID, "Review Details iFrame");
			//verifyNOAfieldstMethod(ReportSheet, count);
			selectBySendkeys(SOP.NOA_DRPDWN, "Default Judgment", "NOA dropdown field");
			click(SOP.SAVE_BTN, "Save Button");
			waitForElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertElementPresent(WorksheetCreate.WORKSHEET_PROFILE, "Worksheet Profile");
			assertTextMatching(SOP.NOA_DEFAULTJUDGMENT, "Default Judgment", "NOA Default Judgment");

		} catch (Exception e) {
			throw e;
		}
		return ReportSheet;
	}
}
