package com.arrow.renewal.scripts;

import java.util.ArrayList;

import org.testng.annotations.Test;

import com.arrow.sqlqueries.SQL_Queries;
import com.arrow.workflows.BusinessFunctions_RenwalInvoice;

public class RenewalInvoice extends BusinessFunctions_RenwalInvoice {
	private ArrayList<String> entityNumber = new ArrayList<String>();
	private ArrayList<String> subgroupID = new ArrayList<String>();
	// Performs successful invoice search by entering invoice number.
    @Test
	public void searchInvoice() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SearchInvoice");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchInvoice";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchInvoice(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// Performs successful invoice search by entering invoice number under
	// Affiliation
	@Test
	public void searchInvoiceByAffiliation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SearchInvoiceByAffiliation");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchInvoiceByAffiliation";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchInvoiceByAffiliation(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// performs successful invoice search by entering invoice number under Entity
	// Context.
	@Test
	public void searchInvoiceByEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SearchInvoiceByEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchInvoiceByEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchInvoiceByEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// selects Invoices successfully by selecting tab option Place on Referral
	// selects Invoices successfully by selecting tab option Remove Referral under
	// Entity context
	@Test
	public void placeOnReferral() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "PlaceOnReferral");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "PlaceOnReferral";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					placeOnReferral(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User searches for a revised invoice by entity
	// context.
	@Test
	public void searchRevisedInvoiceByEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SearchRevisedInvoiceByEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchRevisedInvoiceByEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchRevisedInvoiceByEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// views the Invoice Profile for an Unaffiliated Entity Not Revised Not Placed
	// on Referral and No Discounts
	// onlynly uncomment if new test data included in sheet
	 //@Test
	public void invoiceForUnaffiliatedEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "InvoiceForUnaffiliatedEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "InvoiceForUnaffiliatedEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					invoiceForUnaffiliatedEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// views Invoice Profile for Affiliated Entity which is Discounted Not part of
	// Subgroup Not Revised or Referred
	@Test
	public void invoiceForAffiliatedEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "InvoiceForAffiliatedEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "InvoiceForAffiliatedEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					invoiceForAffiliatedEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// views Invoice Profile for Affil Ent in Subgroup which is Dscntd and Not
	// Consolidated Not Revised or Referred
	@Test/*(groups= {"newly"})*/
	public void invoiceForAffiliatedEntityWithSubgroup() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "InvoiceForAffEntityWithSubgrp");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "InvoiceForAffEntityWithSubgrp";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					invoiceForAffiliatedEntityWithSubgroup(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User selects single invoice successfully for Reprint option
	@Test
	public void selectSingleInvoiceToReprint() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SelectSingleInvoiceToReprint");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SelectSingleInvoiceToReprint";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					selectSingleInvoiceToReprint(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User selects multiple invoices successfully for Reprint option.
	@Test
	public void selectMultipleInvoiceToReprint() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SelectMultipleInvoiceToReprint");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SelectMultipleInvoiceToReprint";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					selectMultipleInvoiceToReprint(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User selects all invoices successfully for Reprint option.
	@Test
	public void selectAllInvoiceToReprint() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SelectAllInvoiceToReprint");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SelectAllInvoiceToReprint";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					selectAllInvoiceToReprint(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User selects single invoice successfully for Revise Option under Entity
	// context.
	// User verifies error displays when invoices are not selected. Then
	// successfully selects invoices to be revised
	// only uncomment if new test data included in sheet
	// @Test
	public void selectSingleInvoiceToRevise() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SelectSingleInvoiceToRevise");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SelectSingleInvoiceToRevise";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					selectSingleInvoiceToRevise(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User selects multiple invoices successfully for Revise option under Entity
	// context
	// only uncomment if new test data included in sheet...
	// @Test
	public void selectMultipleInvoiceToRevise() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "SelectMultipleInvoiceToRevise");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SelectMultipleInvoiceToRevise";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					selectMultipleInvoiceToRevise(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User searches an Invoice exception successfully by entering Affiliation ID
	// and selecting Service Center.
	@Test/*(groups= {"newly"})*/
	public void invoiceExceptionAffiliationID() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "InvoiceSearchByID");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "InvoiceSearchByID";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					invoiceExceptionAffiliationID(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User searches an Invoice exception successfully by entering Affiliation ID,
	// Service Center and Service Team.
	@Test/*(groups= {"newly"})*/
	public void invoiceExceptionWithServiceTeam() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "InvoiceSearchByTeam");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "InvoiceSearchByTeam";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					invoiceExceptionWithServiceTeam(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User searches an Invoice exception un-successfully by entering Affiliation ID
	@Test/*(groups= {"newly"})*/
	public void errorMsgForException() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "ErrorMsgForException");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ErrorMsgForException";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					errorMsgForException(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// NPD test case of sprint 15
	@Test/*(groups= {"newly"})*/
	public void creditDSButtonForInvoices() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "CreditDSButtonForInvoices");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreditDSButtonForInvoices";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					creditDSButtonForInvoices(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// NPD test case of sprint 15
	@Test/*(groups= {"newly"})*/
	public void creditDSPage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "CreditDSPage");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreditDSPage";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					creditDSPage(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// NPD Test case of sprint 17
	@Test/*(groups= {"newly"})*/
	public void backToInvoiceListButtonOnCreditDSPage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "BackToInvoiceListButton");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "BackToInvoiceListButton";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					backToInvoiceListButtonOnCreditDSPage(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// NPD Test case of sprint 17
	@Test/*(groups= {"newly"})*/
	public void creditDSOnInvoiceProfilePage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "CreditDSOnInvoicePage");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreditDSOnInvoicePage";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					creditDSButtonOnInvoiceProfilePage(SheetName, iLoop, strTestCaseID);

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
// Revision of MutlipleRenewal Invoice
	 @Test/*(groups= {"newly"})*/
	 public void revisingMultipleInvoicesUnderAfiiliation() throws Throwable {
				try {
					inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "MultipleInvoiceRevision");	
					for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
						String strTestCaseID = Excelobject.getCellData("MultipleInvoiceRevision", "TestCase-ID", iLoop);
						String strDesc = Excelobject.getCellData("MultipleInvoiceRevision", "Description", iLoop);
						String runStatus = Excelobject.getCellData("MultipleInvoiceRevision", "RunStatus", iLoop);
						String member = Excelobject.getCellData("MultipleInvoiceRevision", "Member", iLoop);
						String team = Excelobject.getCellData("MultipleInvoiceRevision", "Team", iLoop);					
						if (runStatus.trim().equalsIgnoreCase("Y")) {					
							if (strTestCaseID.contains("Revise multiple invoices")) {
								child = extent.startTest(strTestCaseID, strDesc);
								iterationReport(iLoop, strTestCaseID + " Started");							
								SignIn(team, member);
								searchForTheAffiliation("MultipleInvoiceRevision",iLoop);
								reviseTheMultipleRenewalInvoices();
								parent.appendChild(child);
								iterationReport(iLoop, strTestCaseID + " Completed");
								driver.get(URL);
							}
							else if (strTestCaseID.contains("Select the Reprint option")) {
								child = extent.startTest(strTestCaseID, strDesc);
								iterationReport(iLoop, strTestCaseID + " Started");							
								SignIn(team, member);
								searchForTheEntity("MultipleInvoiceRevision",iLoop);
								selectTheReprintAndReviseTheInvoice();
								parent.appendChild(child);
								iterationReport(iLoop, strTestCaseID + " Completed");
								driver.get(URL);
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
// Revision of Renewal Invoice FAI Bundle Phase 2 changes 
	 @Test/*(groups= {"newly"})*/
		public void checkDSEffectiveStartDateOriginalInvoiceWithoutDS() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "BackDateDSEffectiveDate");
				//int renewalMonth  = 10;
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("BackDateDSEffectiveDate", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("BackDateDSEffectiveDate", "Description", iLoop);
					String runStatus = Excelobject.getCellData("BackDateDSEffectiveDate", "RunStatus", iLoop);
					String member = Excelobject.getCellData("BackDateDSEffectiveDate", "Member", iLoop);
					String team = Excelobject.getCellData("BackDateDSEffectiveDate", "Team", iLoop);
					
					if (runStatus.trim().equalsIgnoreCase("Y")) {					
						if (testCaseID.contains("Entity Level Invoice")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//Commenting below methods as dynamic data is not being passed
							//String entity = getTheEntityWithoutDSEnabled();
							bundleDSEffectiveStartDateEntityLevel("BackDateDSEffectiveDate", iLoop);
							//bundleDSEffectiveStartDateEntityLevel("BackDateDSEffectiveDate", iLoop);
							//entityNumber.add(entity);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
						else if (testCaseID.contains("Subgroup Level Invoice")) {						
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//Commenting below methods as dynamic data is not being passed
							//String subgroupId = getTheSubgroupWithoutDSEnabled(String.valueOf(renewalMonth));							
							//bundleDSEffectiveStartDateSubgroupLevel("BackDateDSEffectiveDate", iLoop,"",subgroupId);
							bundleDSEffectiveStartDateSubgroupLevel("BackDateDSEffectiveDate", iLoop);
							//++renewalMonth;							
							//subgroupID.add(subgroupId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		@Test/*(groups= {"newly"})*/
		public void discontinueRepresentationBackDateDSEffectiveStartDate() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "BackDateDSEffectiveDate");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("BackDateDSEffectiveDate", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("BackDateDSEffectiveDate", "Description", iLoop);
					String runStatus = Excelobject.getCellData("BackDateDSEffectiveDate", "RunStatus", iLoop);
					String member = Excelobject.getCellData("BackDateDSEffectiveDate", "Member", iLoop);
					String team = Excelobject.getCellData("BackDateDSEffectiveDate", "Team", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Discontinue DE LLC Rep for Standalone Entity")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);								
							discontinueDomesticREPLLCorLP("BackDateDSEffectiveDate", iLoop);
					        bundleDSEffectiveStartDateEntityLevel("BackDateDSEffectiveDate", iLoop);
					        reinstateDomesticREPLLCorLP("BackDateDSEffectiveDate", iLoop);
					        parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
						else if (testCaseID.contains("Discontinue DE LLC Rep for Entity of a Subgroup")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//String subgroupId = getTheSubgroupWithoutDSEnabled(String.valueOf("7"));
							//String entity = getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(subgroupId);
							//System.out.println("Get the Subgroup id : " + getTheSubgroupWithoutDSEnabled(String.valueOf("8")));
							//System.out.println("Get the subgroup name : " + SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(getTheSubgroupWithoutDSEnabled(String.valueOf("8"))).get(1) );
							discontinueDomesticREPLLCorLP("BackDateDSEffectiveDate", iLoop);
							bundleDSEffectiveStartDateSubgroupLevel("BackDateDSEffectiveDate", iLoop);
							//below function for reinstate of the rep
							reinstateDomesticREPLLCorLP("BackDateDSEffectiveDate", iLoop);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		@Test
		public void getSubgroupLevelHaveDSAddStandaloneEntityToIt() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "BackDateDSEffectiveDate");				
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("BackDateDSEffectiveDate", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("BackDateDSEffectiveDate", "Description", iLoop);
					String runStatus = Excelobject.getCellData("BackDateDSEffectiveDate", "RunStatus", iLoop);
					String member = Excelobject.getCellData("BackDateDSEffectiveDate", "Member", iLoop);
					String team = Excelobject.getCellData("BackDateDSEffectiveDate", "Team", iLoop);
					
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Standalone Entity have Eligible DE LLC Rep")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//String entity = getTheEntityWithoutDSEnabled();
							addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice("BackDateDSEffectiveDate",iLoop);			
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
						else if (testCaseID.contains("Standalone Entity does not have Eligible DE LLC Rep")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//String entity = getEntityNotHavingDERepLLCORDELP();					
							addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice("BackDateDSEffectiveDate",
									iLoop);											
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		@Test(groups= {"newly"})
		public void validateTheInvoiceChangesPostrevision() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "InvoiceChanges");			
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("InvoiceChanges", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("InvoiceChanges", "Description", iLoop);
					String runStatus = Excelobject.getCellData("InvoiceChanges", "RunStatus", iLoop);
					String member = Excelobject.getCellData("InvoiceChanges", "Member", iLoop);
					String team = Excelobject.getCellData("InvoiceChanges", "Team", iLoop);							
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						
						if (testCaseID.contains("Entity Level Invoice")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);							
							validateTheInvoiceChangesPostRevision("InvoiceChanges",iLoop,"Entity");					
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
						else if (testCaseID.contains("Subgroup Level Invoice")) {						
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);						
							validateTheInvoiceChangesPostRevision("InvoiceChanges",iLoop,"Affiliation");						
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	// User views the Invoice Profile for an Affiliated Entity part of a Subgroup
	// which is Discounted(Entity) and Not Consolidated Not Revised or Referred
	@Test
	public void invoiceProfileOfDiscountedEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "DiscountedEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "DiscountedEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewInvoiceProfileOfDiscountedEntity(SheetName, iLoop, strTestCaseID);

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User views the Invoice Profile for an Affiliated Entity which is Discounted
	// Not part of a Subgroup Not Revised or Referred
	@Test
	public void viewInvoiceProfileOfEntityHavingNoSubGrp() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "EntityHavingNoSubGrp");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EntityHavingNoSubGrp";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewInvoiceProfileOfEntityHavingNoSubGrp(SheetName, iLoop, strTestCaseID);

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User views the Invoice Profile for an Unaffiliated Entity Not Revised Not
	// Placed on Referral and No Discounts
	@Test
	public void viewInvoiceProfileOfUnaffEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "UnaffiliatedEntityInvoice");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "UnaffiliatedEntityInvoice";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewInvoiceProfileOfUnaffEntity(SheetName, iLoop, strTestCaseID);

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User verifies that, reinstate or discontinue repunits for entity and Search
	// for an invoice and Click on Revision Preview button and verifies that updated
	// rep details s are displayed successfully on Revision Preview page.
	@Test/*(groups= {"newly"})*/
	public void verifyNewInvoicesErrorMessage() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "NewInvoicesErrorMessage");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "NewInvoicesErrorMessage";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					verifyNewInvoicesErrorMessage(SheetName, iLoop, strTestCaseID);

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User verifies that, Make a participant change in Renewal DI of entity and
	// Search for an invoice and Click on Revision Preview button and verifies that
	// updated participant details are displayed successfully on Revision Preview
	// page.
	// Change the recipient before uncommenting
	//@Test
	public void updateParticipantForRevisionPreview() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRenewalInvoice, "UpdateParticipantForRevPrev");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "UpdateParticipantForRevPrev";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					updateParticipantForRevisionPreview(SheetName, iLoop, strTestCaseID);

					driver.get(URL);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
}
