package com.arrow.reports.scripts;

import org.testng.annotations.Test;
import com.arrow.workflows.BusinessFunctions_Reports;

public class Reports extends BusinessFunctions_Reports {

	@Test
	// Verify if user is able to request SOPVolumesReport for an Affiliation
	public void RequestAffiSOPVolumesReport() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookReports, "RequestAffiSOPVolumesReport");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "RequestAffiSOPVolumesReport";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This method will reinstate the respective discontinued rep
					RequestForSOPVolumesReport(SheetName,iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
					}
			} 
			catch(Exception e){
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify if user is able to request SOPVolumesReport for an Entity
	public void RequestEntitySOPVolumesReport() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookReports, "RequestEntitySOPVolumesReport");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "RequestEntitySOPVolumesReport";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This method will reinstate the respective discontinued rep
					RequestForSOPVolumesReport(SheetName,iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
					}
			} 
			catch(Exception e){
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify if user is able to request SOPVolumesReport for an Entity
	public void RequestPaperlessSOPConversionReport() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookReports, "PaperlessSOPConversionReport");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "PaperlessSOPConversionReport";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This method will reinstate the respective discontinued rep
					RequestForPaperlessSOPConversionsReport(SheetName,iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
					}
			} 
			catch(Exception e){
				catchBlock(e);
			}
		}
	}
	
}
