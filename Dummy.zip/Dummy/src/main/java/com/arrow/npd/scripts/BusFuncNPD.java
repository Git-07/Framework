package com.arrow.npd.scripts;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.IAnnotationTransformer;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import org.testng.annotations.ITestAnnotation;

import com.arrow.accelerators.ActionEngine;
import com.arrow.objectrepo.ActionItemsFailure;
import com.arrow.objectrepo.Admin;
import com.arrow.objectrepo.Affiliation;
import com.arrow.objectrepo.CRM;
import com.arrow.objectrepo.DI;
import com.arrow.objectrepo.Entity;
import com.arrow.objectrepo.Generic;
import com.arrow.objectrepo.HomePage;
import com.arrow.objectrepo.Invoice;
import com.arrow.objectrepo.Login;
import com.arrow.objectrepo.RenewalInvoice;
import com.arrow.objectrepo.SOP;
import com.arrow.objectrepo.SearchWorksheet;
import com.arrow.objectrepo.SopHub;
import com.arrow.objectrepo.TeamSOPDashboard;
import com.arrow.objectrepo.WorksheetCreate;
import com.arrow.sqlqueries.SQL_Queries;
import com.arrow.workflows.BusinessFunctions_SOP;

public class BusFuncNPD extends Action {

	public void CreateEntity(String ReportSheet, int count) throws Throwable {
		try {

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : catchBlock() Author : Vrushali Kakade Description : This method
	 * will catch the Exception Date of creation : modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void catchBlock(Exception e) throws Throwable {
		if (e.getMessage() != null)
			parent.appendChild(child);
		gStrErrMsg = e.getMessage();
		closeSummaryReport(browsertype);
		driver.quit();
		openBrowser();
		Thread.sleep(lSleep_VLow);

	}

	/********************************************************************************************************
	 * Method Name : verifyDSOPInCES() Author : Vrushali Kakade Description : This
	 * method will verify that SOP uploaded from SOP Hub are present in CES screen
	 * Date of creation : 4/22/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyDSOPInCES(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strConfirmationNumber = Excelobject.getCellData(ReportSheet, "Confirmation Number", count);
			String strBatchNumber = Excelobject.getCellData(ReportSheet, "Batch Number", count);
			String strIntakeMethodValue = Excelobject.getCellData(ReportSheet, "Intake Method", count);

			// click on SOP List link on Home page
			click(driver,HomePage.SOPLISTLINK, "SOP List");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// click on Clear button of filter
			click(driver,SOP.CLEARBTN, "Clear Button of filter");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// select value 'Confirmation Number' in filter dropdown 1 and '='
			// in dropdown 2
			if (strBatchNumber.trim().equalsIgnoreCase("NA")) {
				selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Confirmation Number", "Filter Dropdown 1");
				selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "=", "Filter Dropdown 2");

				// Enter confirmation number in filter text box and hit Go
				// button
				type(driver,SOP.FILTERTEXTFIELD, strConfirmationNumber, "Filter text field");
				click(driver,SOP.FILTERGOBTN, "Go button of filter");
				Thread.sleep(lSleep_Medium);
				waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");
			} else if (strConfirmationNumber.trim().equalsIgnoreCase("NA")) {
				selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Batch #", "Filter Dropdown 1");
				selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "equals", "Filter Dropdown 2");

				// Enter batch number in filter text box and hit Go button
				type(driver,SOP.FILTERTEXTFIELD, strBatchNumber, "Filter text field");
				click(driver,SOP.FILTERGOBTN, "Go button of filter");
				Thread.sleep(lSleep_Medium);
				waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");
			}

			// CES Select button is present for DSOP
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select button");

			// click on CES Select button
			click(driver,SOP.CESSELECTBTN, "CES Select button");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(driver,SOP.SUBMITBTN, "Submit Button");

			// verify Intake Method: CDSOP is displayed on CES page
			waitForFrameToLoadAndSwitchToIt(driver,SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			assertTextMatching(driver,SOP.INTAKEMETHODLABEL, "Intake Method :", "Intake Method :");
			assertTextMatching(driver,SOP.INTAKEMETHODVALUE, strIntakeMethodValue, strIntakeMethodValue);

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyCESMLSlider() Author : Vrushali Kakade Description : This
	 * method will verify if ML Slider is displayed in CES screen Date of creation :
	 * 4/22/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyCESMLSliderWithData(String ReportSheet, int count) throws Throwable {
		try {
			blnEventReport = true;
			String strConfirmationNumber = Excelobject.getCellData(ReportSheet, "Confirmation Number", count);
			String strCaseNumber = Excelobject.getCellData(ReportSheet, "Case Number", count);

			// click on SOP List link on Home page
			click(driver,HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// click on Clear button of filter
			click(driver,SOP.CLEARBTN, "Clear Button of filter");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// select value 'Confirmation Number' in filter dropdown 1 and '='
			// in dropdown 2
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Confirmation Number", "Filter Dropdown 1");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "=", "Filter Dropdown 2");

			// Enter batch number in filter text box and hit Go button
			type(driver,SOP.FILTERTEXTFIELD, strConfirmationNumber, "Filter text field");
			click(driver,SOP.FILTERGOBTN, "Go button of filter");
			Thread.sleep(lSleep_Medium);
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// click on CES Select button
			click(driver,SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(driver,SOP.SUBMITBTN, "Submit Button");

			// Verify ML Slider on CES page is closed by default
			assertElementPresent(driver,SOP.SLIDER_CLOSED_BTN, "ML Slider is closed by default on CES page");

			// click on arrow icon and verify the slider is opened
			click(driver,SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

			// verify ML Slider is opened
			assertElementPresent(driver,SOP.SLIDER_OPENED_BTN, "ML Slider is opened");

			// verify Slider title is "ML Extracted Data"
			assertTextMatching(driver,SOP.SLIDER_TITLE, "ML Extracted Data", "Title of ML Slider");

			// verify eye icon is displayed next to "ML Extracted Data" title
			assertElementPresent(driver,SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");

			// click on eye icon and verify slider is transparent
			click(driver,SOP.SLIDER_EYE_OPEN_BTN, "Eye Open icon");
			assertElementPresent(driver,SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");
			String style = getAttribute(driver,SOP.SLIDER_ID, "style");
			assertTextContains(style, "background-color: transparent");

			// click on eye icon again
			click(driver,SOP.SLIDER_EYE_CLOSE_BTN, "Eye Close icon");

			// Verify 'CES ML Slider Fields' section is present and it opened by
			// default
			assertTextMatching(driver,SOP.CES_SECTION_TITLE, "CES ML Slider Fields", "Title of CES Section on ML Slider");
			assertElementPresent(driver,SOP.CES_SECTION_UP_ARROW, "'CES ML Slider Fields' is opened by default on ML Slider");

			// Verify Copy icon is displayed and click on it
			assertElementPresent(driver,SOP.COPY_ICON, "Copy Icon on CES ML Slider");
			String text = getText(driver,SOP.FIRST_ELEMENT_ON_ML_SLIDER, "Text in Case# field");
			click(driver,SOP.COPY_ICON, "Copy Icon on CES ML Slider");

			// Verify CASE number is correct
			assertTextContains(strCaseNumber, text);

			// Click on UP arrow of 'CES ML Slider Fields' section and verify
			// section is
			// closed
			click(driver,SOP.CES_SECTION_UP_ARROW, "Up arrow of 'CES ML Slider Fields' section");
			assertElementPresent(driver,SOP.CES_SECTION_DOWN_ARROW, "'CES ML Slider Fields' section is closed on ML Slider");

			// close the slider
			click(driver,SOP.SLIDER_OPENED_BTN, "Slider Opened button");
			assertElementPresent(driver,SOP.SLIDER_CLOSED_BTN, "Slider Closed button");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : adminCESMLSliderPage() Author : Vrushali Kakade Description :
	 * This method will verify if ML Slider is displayed in CES screen Date of
	 * creation : 6/19/2019 modifying person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void adminCESMLSliderPage(String ReportSheet, int count) throws Throwable {
		try {

			// Click on Admin Module
			click(driver,HomePage.ADMINLINK, "Admin Link");

			// Verify Whether New section 'Manage CES ML Slider Fields' on the
			// left nav
			// And click on 'Manage CES ML Slider Fields' link
			assertElementPresent(driver,Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			click(driver,Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");

			// Verify Title of the page is Manage CES ML Slider Fields
			assertTextMatching(driver,Admin.MANAGECESMLSLIDERFIELDSPAGE, "Manage CES ML Slider Fields", "Title of the page");

			// Verify the page has 2 blocks - CES ML Slider Fields and Maintain
			// CES ML
			// Slider Fields
			// and save & cancel buttons at the bottom
			isElementPresent(driver,Admin.CESMLSLIDERFIELDSBLOCK, "CES ML Slider Fields Block");
			isElementPresent(driver,Admin.MAINTAINCESMLSLIDERFIELDSBLOCK, "Maintain CES ML Slider Fields Block");
			isElementPresent(driver,Admin.SAVEBTN, "Save Button");
			isElementPresent(driver,Admin.CANCELBTN, "Cancel Button");

			// CES ML Slider Fields block has 3 fields- Case#,lawsuit type and
			// lawsuitsubtype
			assertElementPresent(driver,Admin.CASEIDFIELD, "Case #");
			assertElementPresent(driver,Admin.LAWSUITTYPEFIELD, "LAWSUIT TYPE FIELD");
			assertElementPresent(driver,Admin.LAWSUITSUBTYPEFIELD, "LAWSUIT SUB TYPE FIELD");

			// Maintain CES ML Slider Fields block has 2 fields- Index and Name
			assertTextMatching(driver,Admin.INDEXFIELD, "Index", "Verify 1st col is Index");
			assertTextMatching(driver,Admin.NAMEFIELD, "Name", "Verify 2nd col is Name");

			// Verify Fields can be moved within CES ML Slider Fields block
			draggable(Admin.LAWSUITTYPEFIELD, 0, 150, "LAWSUIT TYPE FIELD DRAG AND DROP");
			click(driver,Admin.SAVEBTN, "Save Button");

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyAllIntakeMethodThroughCES() Author : Vrushali Kakade
	 * Description : This method will verify that SOP uploaded from different Intake
	 * Methods routes through CES screen Date of creation : 6/28/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyAllIntakeMethodThroughCES(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String strIntakeMethodValue = Excelobject.getCellData(ReportSheet, "Intake Method", count);

			// click on SOP List link on Home page
			click(driver,HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			//searchSOPUsingFileName(strFileName, "equals");

			// CES Select button is present for DSOP
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select button");

			// click on CES Select button
			click(driver,SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(driver,SOP.SUBMITBTN, "Submit Button");

			// verify Intake Method: CDSOP is displayed on CES page
			waitForFrameToLoadAndSwitchToIt(driver,SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			assertTextMatching(driver,SOP.INTAKEMETHODLABEL, "Intake Method :", "Intake Method :");
			assertTextMatching(driver,SOP.INTAKEMETHODVALUE, strIntakeMethodValue, strIntakeMethodValue);

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyCustomerComments() Author : Vrushali Kakade Description :
	 * This method will verify Customer Comments are displayed for CDSOP Intake
	 * Methods on CES and Worksheet pages Date of creation : 6/28/2019 modifying
	 * person : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyCustomerComments(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String strCustomerComments = Excelobject.getCellData(ReportSheet, "Customer Comment", count);

			// click on SOP List link on Home page
			click(driver,HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			////searchSOPUsingFileName(strFileName, "equals");

			// click on CES Select button
			click(driver,SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(driver,SOP.SUBMITBTN, "Submit Button");

			// verify Intake Method: CDSOP is displayed on CES page
			waitForFrameToLoadAndSwitchToIt(driver,SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			assertTextMatching(driver,SOP.CUSTOMER_COMMENTS_LABEL, "Customer Comments (CDSOP Only) :",
					"Customer Comments (CDSOP Only) :");
			assertTextMatching(driver,SOP.CUSTOMER_COMMENTS_VALUE, strCustomerComments, strCustomerComments);

			///////// This part is commented because unable to click on Home
			///////// icon in selenium.
			///////// In Test data, use SOP for which Entity is already selected
			/*
			 * //click on Select button of ARROW Entity box
			 * click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			 * waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");
			 * 
			 * //enter entity name in Entity Search page and click on Search button
			 * type(driver,SOP.ENTITY_NAME_TEXTFIELD, "apple",
			 * "Entity Name textfield on Entity Search page"); click(driver,SOP.SEARCH_BTN,
			 * "Search button"); waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN,
			 * "Unidentified Entity button");
			 * 
			 * //click on 1st entity of the search result, click on Home icon
			 * click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "1st entity of search result");
			 * waitForElementPresent(driver,SOP.HOME_ICON, "Home icon"); scrollUp();
			 * focus(SOP.HOME_PDF_ICONS, "Home PDF icons"); click(driver,SOP.HOME_PDF_ICONS,
			 * "Home PDF icons");
			 * 
			 * click(driver,SOP.HOME_ICON, "Home icon");
			 */
			// select Lawsuite Type and click on Submit button
			selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, "Asbestos Litigation", "Lawsuit Type Dropdown");
			click(driver,SOP.SUBMITBTN, "Submit Button");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// On SOP List page, search for this SOP
			////searchSOPUsingFileName(strFileName, "equals");

			// Assign this ESOP to logged in user
			click(driver,SOP.FIRST_SOP_CHECKBOX, "Checkbox of first SOP in SOP List");
			click(driver,SOP.ASSIGN_BTN, "Assign button");
			waitForElementPresent(driver,SOP.ASSIGN_BTN, "Assign button");
			click(driver,SOP.ASSIGN_BTN, "Assign button");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			////searchSOPUsingFileName(strFileName, "equals");
			click(driver,SOP.VIEW_BTN, "View Button");
			switchAndCloseWindow(driver);
			click(driver,SOP.CREATE_WORKSHEET_BTN, "Create Worksheet button");
			waitForElementPresent(driver,SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");
			Thread.sleep(lSleep_Medium);

			// On Create Worksheet Step 1
			selectByIndex(driver,SOP.RECEIVED_BY_MEMBER_DPDOWN, 1, "Received By Memebr Dropdown");
			click(driver,SOP.INITIAL_RADIOBTN, "Initiatl Radio Button");
			click(driver,SOP.CASE_NUMBER_NONE_RADIOBTN, "Initial Radio Button");
			click(driver,SOP.PLAINTIFF_NONE_RADIOBTN, "Plaintiff Radio Button");
			type(driver,SOP.DEFENDANT_TEXTFIELD, "Test Defendant Name", " Defendant/Creditor Name");
			assertTextMatching(driver,SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);
			click(driver,SOP.NEXT_BTN, "Next Button");
			waitForElementPresent(driver,SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");

			// On Create Worksheet Step 2
			click(driver,SOP.COURT_NONE_RADIOBTN, "Court Radio Button");
			assertTextMatching(driver,SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);
			click(driver,SOP.NEXT_BTN, "Next Button");
			waitForElementPresent(driver,SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");

			// On Create Worksheet Step 3
			type(driver,SOP.DOCUMENT_TYPE_TEXTFIELD, "Test Document Type", "Document Type Textfield");
			if (strFileName == "NPDSeleniumCDSOP.pdf") {
				selectByVisibleText(driver,SOP.SPECIAL_DROPDWN, "None", "Special Circumstances Dropdown");
			}

			click(driver,SOP.ANSWER_NONE_RADIOBTN, "Answer Radio Button");
			assertTextMatching(driver,SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);
			click(driver,SOP.SAVE_BTN, "Save Button");
			Thread.sleep(2000);

			// On Worksheet profile page
			waitForElementPresent(driver,SOP.CUSTOMER_COMMENT_GRID, "Customer Comment Grid");
			assertTextMatching(driver,SOP.CUSTOMER_COMMENT_GRID, strCustomerComments, strCustomerComments);

			Thread.sleep(2000);

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyGenericEntities() Author : Vrushali Kakade Description :
	 * This method will verify Generic entities are displayed for Intake Method
	 * CDSOP Only Date of creation : 7/13/2019 modifying person : Date of
	 * modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyGenericEntities(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);
			String strIntakeMethod = Excelobject.getCellData(ReportSheet, "Intake Method", count);
			String searchMessage = "Entity search is limited to Customer level for DSOP";
			String noRecordMessage = "No records found.";

			// click on SOP List link on Home page
			click(driver,HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			////searchSOPUsingFileName(strFileName, "equals");

			// click on CES Select button
			click(driver,SOP.CESSELECTBTN, "CES Select button");
			waitForElementPresent(driver,SOP.SUBMITBTN, "Submit Button");

			// click on Select button of ARROW Entity box
			waitForFrameToLoadAndSwitchToIt(driver,SOP.ESOPIFRAMEID, "ESOP Details iFrame");
			click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select button of Arrow Entity box");
			waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity Name textfield");

			// Verify message is displayed for Intake Method CDSOP
			if (strIntakeMethod.trim().equalsIgnoreCase("CDSOP")) {
				assertTextMatching(driver,SOP.ENTITY_SEARCH_MESSAGE, searchMessage, searchMessage);
			} else {
				elementIsNotPresent(driver,SOP.ENTITY_SEARCH_MESSAGE, searchMessage);
			}

			// enter entity name in Entity Search page and click on Search
			// button
			type(driver,SOP.ENTITY_NAME_TEXTFIELD, "Selenium Test Generic Entity",
					"Entity Name textfield on Entity Search page");
			click(driver,SOP.SEARCH_BTN, "Search button");
			waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Unidentified Entity button");

			// click on 1st entity of the search result, click on Home icon
			if (strIntakeMethod.trim().equalsIgnoreCase("CDSOP")) {
				assertTextMatching(driver,SOP.ENTITY_DOM_JURISDICTION, "--", "Dom Juris is --");
				assertTextMatching(driver,SOP.ENTITY_REP_JURISDICTION, "--", "Rep Juris is --");
				assertTextMatching(driver,SOP.ENTITY_REP_STATUS, "--", "Rep Status is --");
				assertTextMatching(driver,SOP.ENTITY_REP_SERVICE_TYPE, "--", "Rep Service Type is --");
				String value = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
				assertTextContains(value, "true");
			} else {
				assertTextMatching(driver,SOP.ENTITY_RESULT_MESSAGE, noRecordMessage, noRecordMessage);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	/********************************************************************************************************
	 * Method Name : verifyCESEnabledRemoved() Author : Vrushali Kakade Description
	 * : This method will verify CES Enabled is removed from SOP List page and
	 * Manage Default Assignment page Date of creation : 7/14/2019 modifying person
	 * : Date of modification :
	 * 
	 * @throws Throwable :
	 ********************************************************************************************************/
	public void verifyCESEnabledRemoved(String ReportSheet, int count) throws Throwable {
		try {
			String strFileName = Excelobject.getCellData(ReportSheet, "File Name", count);

			// click on SOP List link on Home page
			click(driver,HomePage.SOPLISTLINK, "SOP List");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");

			// CES Enabled label is not present in grid on SOP List page
			elementIsNotPresent(driver,SOP.CES_ENABLED_LABEL, "CES Enabled label in SOP List grid");

			// Select SOP>15 days page and verify CES Enabled label is not
			// present in grid
			click(driver,SOP.SOP_15DAYS_TAB, "SOP>15 Days tab");
			waitForElementPresent(driver,SOP.UPLOADIMAGEBTN, "Upload Image Button");
			elementIsNotPresent(driver,SOP.CES_ENABLED_LABEL, "CES Enabled label in SOP>15 Days grid");

			// Navigate to Manage Default Assignment page
			click(driver,SOP.MANAGE_DEFAULT_ASSIGNMENT_LINK, "Manage Default Assignment link");
			waitForElementPresent(driver,SOP.ADD_NEW_BTN, "Add New Button");
			elementIsNotPresent(driver,SOP.CES_ENABLED_LABEL, "CES Enabled label in grid on Manage Default Assignment page");
			elementIsNotPresent(driver,SOP.CES_ENABLED_SORTBY_LINK,
					"CES Enabled sort by link on Manage Default Assignment page");
			elementIsNotPresent(driver,SOP.CES_ENABLED_CHECKBOX, "CES Enabled checkbox on Manage Default Assignment page");

			// click on Add New button and verify CES Enabled is not displayed
			click(driver,SOP.ADD_NEW_BTN, "Add New Button");
			Thread.sleep(lSleep_Medium);
			elementIsNotPresent(driver,SOP.CES_ENABLED_CHECKBOX, "CES Enabled checkbox");

			// click on Edit button of existing configuration and verify CES
			// Enabled is not
			// displayed
			click(driver,SOP.EDIT_BTN, "Edit Button of configuration");
			Thread.sleep(lSleep_Medium);
			elementIsNotPresent(driver,SOP.CES_ENABLED_CHECKBOX, "CES Enabled checkbox");

		} catch (Exception e) {
			throw e;
		}
	}

	public void expeditedSOPPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {

			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(driver,HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(driver,Admin.CREATE_ROLE_BTN, "Create Role Button");

			// click on Create Role Button
			click(driver,Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(driver,Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Update Entity on posted
			// Expedited SOP
			// Log is Present
			isElementPresent(driver,Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			assertTextMatching(driver,Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_LABEL,
					"Update Entity on posted Expedited SOP Log",
					"Label For Update Entity on posted Expedited SOP Log Field");

			// click on Save Button
			click(driver,Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(driver,Admin.EDIT_BTN, "Edit Button");

			// Click on Update Entity on posted Expedited SOP Log Checkbox and
			// click on save
			// button
			click(driver,Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");
			click(driver,Admin.SAVEBTN, "Save Button");

			// Verify whether Update Entity on posted Expedited SOP Log is added
			// in
			// Expedited SOP Permission Field
			assertTextMatching(driver,Admin.EXPEDITED_SOP_PERMISSION_FIELD, "Update Entity on posted Expedited SOP Log",
					"Update Entity on posted Expedited SOP Log on Expedited SOP Permission Field");

			// Click on Edit Button again and uncheck Update Entity on posted
			// Expedited SOP
			// Log
			click(driver,Admin.EDIT_BTN, "Edit Button");
			click(driver,Admin.UPADTE_ENTITY_ON_POSTED_EXPEDITED_SOP_LOG_CHECKBOX,
					"Update Entity on posted Expedited SOP Log Checkbox");

			// Click on save btn
			click(driver,Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Expedited SOP Permission
			// Field
			assertTextMatching(driver,Admin.EXPEDITED_SOP_PERMISSION_FIELD, "No permissions",
					"No permissions Msg on Expedited SOP Permission Field");

			// Navigate to Roles Page
			click(driver,Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(driver,Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(driver,Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(driver,Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(driver,Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(driver,Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(driver,Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}
	}

	public void editEntityForVariousSOP(String ReportSheet, int count) throws Throwable {
		try {
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);

			click(driver,HomePage.SOPLINK, "SOP Link");
			//searchWorksheet(worksheetId);
			//editEntityOnWorksheetEditPage(ReportSheet, count);

		} catch (Exception e) {
			throw e;
		}
	}

	public void errorForExpeditedSOPLog(String ReportSheet, int count) throws Throwable {
		try {
			String worksheetId = Excelobject.getCellData(ReportSheet, "Worksheet Id", count);

			click(driver,HomePage.SOPLINK, "SOP Link");
			//searchWorksheet(worksheetId);
			//errorMessageOnEntityEdit();

		} catch (Exception e) {
			throw e;
		}
	}

	public void updatePlusDisbursementOnEntity(String BundleName, String plusDisbursement) throws Throwable {
		try {
			if (BundleName.equalsIgnoreCase("Reparms Bundle")) {
				// select Reparms bundle from bundle dropdown
				click(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(driver,Entity.EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(driver,Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");
					// Enter Comments
					type(driver,Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(driver,Entity.SAVE_BTN, "Save Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// uncheck Plus Disbursement checkbox
					click(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Enter Comments
					type(driver,Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(driver,Entity.SAVE_BTN, "Save Button");
				}

			} else if (BundleName.equalsIgnoreCase("Rep and Annual Report")) {
				// select Rep and Annual Report from bundle dropdown
				click(driver,Entity.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(driver,Entity.EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(driver,Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");
					// Enter Comments
					type(driver,Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(driver,Entity.SAVE_BTN, "Save Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// uncheck Plus Disbursement checkbox
					click(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Enter Comments
					type(driver,Entity.COMMENTS, "Automation Testing", "Comments Text Box");
					// click on save button
					click(driver,Entity.SAVE_BTN, "Save Button");

				}

			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void editEntityBundle(String ReportSheet, int count) throws Throwable {
		try {
			String entityId = Excelobject.getCellData(ReportSheet, "Entity Id", count);

			// click on Entity Search link
			click(driver,HomePage.ENTITY_SEARCH_LINK, "Entity Search");
			waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");

			// Enter Entity ID and click on search button
			type(driver,Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(driver,Entity.SEARCH_BTN, "Search Button");

			// click on Edit Button on Entity Profile Page
			click(driver,Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnEntity("Reparms Bundle", "Yes");

			// Verify Bundle Name on entity profile page
			assertTextMatching(driver,Entity.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Entity.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// click on Edit Button on Entity Profile Page
			click(driver,Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnEntity("Reparms Bundle", "No");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Entity.PLUS_DISBURSEMENTS, "No", "Verify  the value of Plus Disbursements label is No");

			// click on Edit Button on Entity Profile Page
			click(driver,Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Rep and Annual Report Bundle
			updatePlusDisbursementOnEntity("Rep and Annual Report", "Yes");

			// Verify Bundle Name on entity profile page
			assertTextMatching(driver,Entity.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Entity.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// click on Edit Button on Entity Profile Page
			click(driver,Entity.ENTITY_EDIT, "Edit Button");

			// Update Plus Disbursement for Rep and Annual Report Bundle
			updatePlusDisbursementOnEntity("Rep and Annual Report", "No");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Entity.PLUS_DISBURSEMENTS, "No", "Verify  the value of Plus Disbursements label is No");

		} catch (Exception e) {
			throw e;
		}
	}

	public void navigateToInactiveBundleSubGroupsPage() throws Throwable {
		try {
			// Navigate to Sub Group Bundle Maintainance Page
			click(driver,Affiliation.SUB_GROUP_BUNDLE_MAINTAINANCE, "Sub Group Bundle Maintainance Left Nav link");

			// Click On Inactive Bundle Subgroups Tab
			click(driver,Affiliation.INACTIVE_BUNDLE_SUBGROUPS_TAB, "Inactive Bundle Subgroups Tab");

		} catch (Exception e) {
			throw e;
		}
	}

	public void navigateToRenewalTypeSubGroup() throws Throwable {
		try {
			// Navigate to Affiliation Sub Groups Page
			click(driver,Affiliation.SUBGROUPSBTN, "Sub Group Button");

			// Select Sub group type from first filter and Renewal from second
			// filter and
			// click on go button
			click(driver,Affiliation.SUB_GROUP_TYPE, "Select Sub group type from first filter");
			click(driver,Affiliation.RENEWAL, "Select Renewal from second filter");
			click(driver,Affiliation.GOBTN, "Go Button");

			// Select First Subgroup from grid
			click(driver,Affiliation.FIRSTRESULTONSEARCHPAGE, "Select first Subgroup on grid");

		} catch (Exception e) {
			throw e;
		}
	}

	public void updatePlusDisbursementOnSubGroup(String BundleName, String plusDisbursement) throws Throwable {
		try {
			if (BundleName.equalsIgnoreCase("Reparms Bundle")) {
				// select Reparms bundle from bundle dropdown
				click(driver,Affiliation.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(driver,Affiliation.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(driver,Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(driver,Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(driver,Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(driver,Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(driver,Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(driver,Affiliation.ENABLE_BTN, "Enable Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(driver,Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(driver,Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(driver,Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(driver,Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(driver,Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(driver,Affiliation.ENABLE_BTN, "Enable Button");

				}

			} else if (BundleName.equalsIgnoreCase("Rep and Annual Report")) {
				// select Rep and Annual Report from bundle dropdown
				click(driver,Affiliation.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN,
						"Select Rep and Annual Report from Bundle dropdown");
				if (plusDisbursement.equalsIgnoreCase("Yes")) {
					// check Plus Disbursement checkbox
					click(driver,Affiliation.PLUS_DISBURSEMENTS_CHECKBOX, "Plus Disbursement checkbox");
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(driver,Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(driver,Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(driver,Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(driver,Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(driver,Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(driver,Affiliation.ENABLE_BTN, "Enable Button");

				} else if (plusDisbursement.equalsIgnoreCase("No")) {
					// Click on Calendar icon of Effective Start Date and select
					// todays date
					click(driver,Affiliation.EFFECTIVE_START_DATE_CALENDAR, "Effective Start Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of End Date and select todays date
					click(driver,Affiliation.END_DATE_CALENDAR, "End Date Calendar Icon");
					click(driver,Affiliation.TODAYSDATE, "Todays Date");
					// Click on Calendar icon of Disbursements Effective Start
					// Date and select todays date
					click(driver,Entity.DS_EFFECTIVE_START_DATE_CALENDAR, "Calendar Icon");
					click(driver,Entity.TODAYSDATE, "Todays Date");

					// Enter Comments
					type(driver,Affiliation.COMMENT, "Automation Testing", "Comments Text Box");

					// Select a sub group and click on Enable button
					click(driver,Affiliation.FIRST_SUBGROUP_ON_GRID, "Select First SubGroup on grid");
					click(driver,Affiliation.ENABLE_BTN, "Enable Button");

				}

			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void editSubGroupBundle(String ReportSheet, int count) throws Throwable {
		try {
			String strId = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);

			// click on Affiliation Search link
			click(driver,HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(driver,Affiliation.AFFILIATIONID, strId, "Affiliation ID Text box");
			click(driver,Affiliation.SEARCHBTN, "Search Button");

			// Navigate to Affiliation Sub Groups Page
			click(driver,Affiliation.SUBGROUPSBTN, "Sub Group Button");
			waitForElementPresent(driver,Affiliation.CREATESUBGROUPBTN, "Create Sub Group Button");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Reparms Bundle", "Yes");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on Sub Group profile View page
			assertTextMatching(driver,Affiliation.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Affiliation.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Reparms Bundle", "No");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on Sub Group profile View page
			assertTextMatching(driver,Affiliation.BUNDLE_NAME, "REPARMS Bundle", "Verify Bundle Name is REPARMS Bundle");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Affiliation.PLUS_DISBURSEMENTS, "No",
					"Verify  the value of Plus Disbursements label is No");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Rep and Annual Report", "Yes");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on entity profile page
			assertTextMatching(driver,Affiliation.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Affiliation.PLUS_DISBURSEMENTS, "Yes",
					"Verify  the value of Plus Disbursements label is yes");

			// Navigate to Inactive Bundle Subgroups Page
			navigateToInactiveBundleSubGroupsPage();

			// Update Plus Disbursement for Reparms Bundle
			updatePlusDisbursementOnSubGroup("Rep and Annual Report", "No");

			// Navigate to Renewal Type Sub Group
			navigateToRenewalTypeSubGroup();

			// Verify Bundle Name on entity profile page
			assertTextMatching(driver,Affiliation.BUNDLE_NAME, "REP and Annual Report",
					"Verify Bundle Name is REP and Annual Report");

			// Verify the value of Plus Disbursements label is yes
			assertTextMatching(driver,Affiliation.PLUS_DISBURSEMENTS, "No",
					"Verify  the value of Plus Disbursements label is yes");

		} catch (Exception e) {
			throw e;
		}
	}

	public void addBundleDisbursement(String ReportSheet, int count) throws Throwable {
		try {

			String dsItemNumber = Excelobject.getCellData(ReportSheet, "E1 DS Item Number", count);
			String dsDescription = Excelobject.getCellData(ReportSheet, "DS Description", count);
			String invalidDSItemNumber = Excelobject.getCellData(ReportSheet, "Invalid DS Item Number", count);
			String validDSItemNumber = Excelobject.getCellData(ReportSheet, "Valid DS Item Number", count);
			String editDSDescription = Excelobject.getCellData(ReportSheet, "Edit DS Description", count);
			List<String> originalrepAndAnnualReportServiceList = new ArrayList<String>();
			List<String> originalRepArmsBundleServiceList = new ArrayList<String>();
			List<String> repAndAnnualReportServiceList = Arrays.asList("-- Select One --",
					"Domestic Registered Agent Plus (RSLP)", "Domestic Registered Agent Plus (SBLP)",
					"Domestic Registered Agent Plus (SLP)", "Domestic Registered Agent Plus (ST)",
					"Domestic Registered Agent Plus Service (Business Corp)",
					"Domestic Registered Agent Plus Service (Gen. Ptnshp)",
					"Domestic Registered Agent Plus Service (LLC)", "Domestic Registered Agent Plus Service (LLP)",
					"Domestic Registered Agent Plus Service (LP)",
					"Domestic Registered Agent Plus Service (Non-Profit)",
					"Foreign Registered Agent Plus Service (Business Corp)",
					"Foreign Registered Agent Plus Service (Gen. Ptnshp)",
					"Foreign Registered Agent Plus Service (LLC)", "Foreign Registered Agent Plus Service (LLP)",
					"Foreign Registered Agent Plus Service (LP)", "Foreign Registered Agent Plus Service (Non-Profit)");
			List<String> repArmsBundleServiceList = Arrays.asList("-- Select One --",
					"Domestic Rep/ARMS (Business Corp)", "Domestic Rep/ARMS (Gen. Ptnshp)", "Domestic Rep/ARMS (LLC)",
					"Domestic Rep/ARMS (LLP)", "Domestic Rep/ARMS (LP)", "Domestic Rep/ARMS (Non-Profit)",
					"Domestic Rep/ARMS (RSLP)", "Domestic Rep/ARMS (SBLP)", "Domestic Rep/ARMS (SLP)",
					"Domestic Rep/ARMS (ST)", "Foreign Rep/ARMS (Business Corporation)",
					"Foreign Rep/ARMS (Gen. Ptnshp)", "Foreign Rep/ARMS (LLC)", "Foreign Rep/ARMS (LLP)",
					"Foreign Rep/ARMS (LP)", "Foreign Rep/ARMS (Non-Profit)");

			// click on Admin link on Home page
			click(driver,HomePage.ADMINLINK, "Admin Link");
			waitForElementPresent(driver,Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Click on Bundle Disbursements Maintainance left nav Link
			click(driver,Admin.BUNDLE_DISBURSEMENTS_MAINTAINANCE_LEFT__NAV_LINK,
					"Bundle Disbursements Maintainance left nav Link");

			// Verify the page title is Bundles Disbursements Maintenance
			assertTextMatching(driver,Admin.PAGE_TITLE, "Bundles Disbursements Maintenance", "Verify the page title");
			// Click on Add Button
			click(driver,Admin.ADD_BTN, "Click On add button");

			// Verify Error Msgs
			assertTextMatching(driver,Admin.BUNDLE_ERR_MSG, "Select a Bundle.", "Error Message when bundle is not selected");
			assertTextMatching(driver,Admin.SERVICE_ERR_MSG, "Select a Service.",
					"Error Message when Service is not selected");
			assertTextMatching(driver,Admin.JURISDICTION_ERR_MSG, "Select a Jurisdiction.",
					"Error Message when Jurisdiction is not selected");

			// Select Rep and Annual Report from dropdown
			click(driver,Admin.REP_AND_ANNUAL_REPORT_BUNDLE_DRPDWN, "Select Rep and Annual Report from bundle dropdown");

			List<WebElement> arr = getAllDropDownData(Admin.SERVICE_DROPDOWN);

			Iterator<WebElement> iter = arr.iterator();

			while (iter.hasNext()) {
				WebElement we = iter.next();

				//originalrepAndAnnualReportServiceList.add(we.getText(driver,));
			}

			compareTwoArrayList(repAndAnnualReportServiceList, originalrepAndAnnualReportServiceList);

			// Select RepArms Bundle from bundle dropdown
			click(driver,Admin.REPARMS_BUNDLE_DRPDWN, "Select REPARMS Bundle from bundle dropdown");

			List<WebElement> array = getAllDropDownData(Admin.SERVICE_DROPDOWN);

			Iterator<WebElement> itr = array.iterator();

			while (itr.hasNext()) {
				WebElement we = itr.next();

				//originalRepArmsBundleServiceList.add(we.getText(driver));
			}

			compareTwoArrayList(repArmsBundleServiceList, originalRepArmsBundleServiceList);

			// Select first value from sevice dropdown
			selectByIndex(driver,Admin.SERVICE_DROPDOWN, 1, "Select first Value from Service DropDown");

			// Check Whether All radio buttons for jurisdiction are present
			isElementPresent(driver,Admin.US_RADIO_BTN, "US Radio Button");
			isElementPresent(driver,Admin.CANADA_RADIO_BTN, "Canada Radio Button");
			isElementPresent(driver,Admin.INTERNATIONAL_RADIO_BTN, "International Radio Button");

			// Select first value from jurisdiction dropdown
			selectByIndex(driver,Admin.JURIS_DRP_DWN, 1, "Select first Value from Jurisdiction DropDown");

			// Click on Add Button
			click(driver,Admin.ADD_BTN, "Click On add button");

			// Click On Save Button
			click(driver,Admin.SAVE_BUTTON, "Save Button");

			// Verify Error Msgs
			assertTextMatching(driver,Admin.DS_ITEM_NUMBER_ERR_MSG, "Enter a value for E1 DS Item Number.",
					"Error Message when E1 DS Item Number is not entered");
			assertTextMatching(driver,Admin.DS_DESCRIPTION_ERR_MSG, "Enter a value for DS Service Description.",
					"Error Message when Service Description. is not entered");

			// Enter a DS Item Number and DS Service Description
			type(driver,Admin.DS_ITEM_NUMBER_TEXTBOX, dsItemNumber, "DS Item Number TextBox");
			type(driver,Admin.DS_DESCRIPTION_TEXTBOX, dsDescription, "DS Description TextBox");

			// Click On Save Button
			click(driver,Admin.SAVE_BUTTON, "Save Button");

			String substringDSItemNumber = dsItemNumber.substring(0, 9);
			String substringDSDescription = dsDescription.substring(0, 59);

			// Verify E1 DS Item Number and DS Description on grid
			assertTextMatching(driver,Admin.E1_DS_ITEM_NUMBER_ON_GRID, substringDSItemNumber, "DS Item Number On Grid");
			assertTextMatching(driver,Admin.DS_DESCRIPTION_ON_GRID, substringDSDescription, "DS Description On Grid");

			// Click On edit Button
			click(driver,Admin.FIRST_EDIT_BUTTON_ON_GRID, "Edit Button");

			// Enter an invalid DS Item Number
			type(driver,Admin.DS_ITEM_NUMBER_TEXTBOX, invalidDSItemNumber, "DS Item Number TextBox");

			// Click On Save Button
			click(driver,Admin.SAVE_BUTTON, "Save Button");

			// Verify Error Msg for entering invalid DS Item Number
			assertTextMatching(driver,Admin.DS_INVALID_ITEM_NUMBER_ERR_MSG, "Enter a positive number for E1 DS Item Number.",
					"Error Message when invalid E1 DS Item Number is entered");

			// Enter an invalid DS Item Number
			type(driver,Admin.DS_ITEM_NUMBER_TEXTBOX, validDSItemNumber, "DS Item Number TextBox");
			type(driver,Admin.DS_DESCRIPTION_TEXTBOX, editDSDescription, "DS Description TextBox");

			// Click On Save Button
			click(driver,Admin.SAVE_BUTTON, "Save Button");

			// Verify E1 DS Item Number and DS Description on grid
			assertTextMatching(driver,Admin.E1_DS_ITEM_NUMBER_ON_GRID, validDSItemNumber, "DS Item Number On Grid");
			assertTextMatching(driver,Admin.DS_DESCRIPTION_ON_GRID, editDSDescription, "DS Description On Grid");

			// Click On Delete Button
			click(driver,Admin.FIRST_DELETE_BUTTON_ON_GRID, "Delete Button");

			// Handle Popup
			handlepopup();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSForAllRenewalInvoicesTab() throws Throwable {
		try {
			// Verify the tab is current renewal invoices
			// commenting because no invoice with DS item in current renewal tab
			/*
			 * assertElementPresent(driver,RenewalInvoice. CURRENT_RENEWAL_INVOICES_ACTIVE_TAB,
			 * "Verify Current Renewal Invoices Tab is Active");
			 * verifyCreditDSOnRenewalInvoicesPage();
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(driver,RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab"); verifyCreditDSOnRenewalInvoicesPage();
			 */
			// Click on All Renewal Invoices Tab
			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(driver,RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			verifyCreditDSOnRenewalInvoicesPage();

			// Click on All Invoice History Tab
			// click(driver,RenewalInvoice.INVOICE_HISTORY_TAB, "Invoice History tab");
			// verifyCreditDSOnRenewalInvoicesPage();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSForAllRevisionsTab() throws Throwable {
		try {
			click(driver,RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");

			// commenting because no invoice with DS item in current renewal tab
			/*
			 * // Verify the tab is current renewal invoices
			 * assertElementPresent(driver,RenewalInvoice. CURRENT_REVISABLE_INVOICES_ACTIVE_TAB,
			 * "Verify Current Revisable Invoices Tab is Active");
			 * verifyCreditDSOnRenewalInvoicesPage();
			 */

			// Click on all revisable invoices tab
			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(driver,RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");
			verifyCreditDSOnRenewalInvoicesPage();

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSOnRenewalInvoicesPage() throws Throwable {
		try {
			// Filter By Credit DS
			click(driver,RenewalInvoice.CREDIT_DS_FIRST_FILTER, "Select Credit DS from first filter");
			click(driver,RenewalInvoice.YES_SECOND_FILTER, "Select Yes from second filter");
			click(driver,RenewalInvoice.GO_BTN, "Go Button");

			// Verify Credit DS Button
			assertElementPresent(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			assertElementPresent(driver,RenewalInvoice.ACTIVE_CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link is Active");

			// Verify Credit DS Button
			assertElementPresent(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyCreditDSOnRenewalInvoicesAndRevisionsPage(String ReportSheet, int count, String module)
			throws Throwable {
		try {

			if (module.equalsIgnoreCase("Invoice")) {

				String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

				click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
				// Search for an invoice ID
				type(driver,RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
				click(driver,RenewalInvoice.SEARCH_BTN, "Search Button");

				verifyCreditDSOnRenewalInvoicesPage();

			}

			else if (module.equalsIgnoreCase("Affiliation")) {

				String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);

				click(driver,HomePage.AFFILIATION_TAB, "Affiliation Tab");
				// Enter an id to be searched and click on search button
				type(driver,Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
				click(driver,Affiliation.SEARCHBTN, "Search Button");

				// Click on Renewal Invoices from left nav bar
				click(driver,Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");

				verifyCreditDSForAllRenewalInvoicesTab();
				verifyCreditDSForAllRevisionsTab();

			}

			else if (module.equalsIgnoreCase("Entity")) {

				String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);

				click(driver,HomePage.ENTITY_TAB, "Entity Tab");

				// Enter Entity ID and click on search button
				type(driver,Entity.ENTITY_ID, entityId, "Entity Id Text box");
				click(driver,Entity.SEARCH_BTN, "Search Button");

				// Click On Renewal Invoices from left nav links
				click(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");

				verifyCreditDSForAllRenewalInvoicesTab();
				verifyCreditDSForAllRevisionsTab();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSButtonForInvoices(String ReportSheet, int count) throws Throwable {
		try {

			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Invoice");
			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Affiliation");
			verifyCreditDSOnRenewalInvoicesAndRevisionsPage(ReportSheet, count, "Entity");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String messageOfDisbursements1 = "You should verify with the ARMS Team that the Annual Report for the entity(s) have been filed before crediting the DS line.";
			String messageOfDisbursements2 = "If the Annual Report has been filed you should NOT issue a credit for the disbursement.";

			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(driver,RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(driver,RenewalInvoice.SEARCH_BTN, "Search Button");

			// Get invoice id
			String invoiceNumber = getText(driver,RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "Invoice name");

			// Click on Credit DS Button
			click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Verify context title,invoice id on context bar,page title
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Credit Disbursements", "Context Title");
			assertTextMatching(driver,RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR, invoiceNumber, "Invoice Number");
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Representation Units with Disbursements", "Page Title");

			String dsMessage = getText(driver,RenewalInvoice.DISBURSEMENTS_MESSAGE, "Disbursements Message");
			System.out.println("dsMessage: " + dsMessage);
			assertTextContains(dsMessage, messageOfDisbursements1);
			assertTextContains(dsMessage, messageOfDisbursements2);

			// Verify invoice#, invoice date and reneal date are displayed
			assertElementPresent(driver,RenewalInvoice.INVOICE_NUMBER, "Invoice id");
			assertElementPresent(driver,RenewalInvoice.INVOICE_DATE, "Invoice Date");
			assertElementPresent(driver,RenewalInvoice.RENEWAL_DATE, "Renewal Date");

			// verfiy Cancel, Revise and Revision Preview buttons are displayed
			// at top and bottom
			assertElementPresent(driver,RenewalInvoice.REVISION_BTN_TOP, "Invoice Date");
			assertElementPresent(driver,RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Invoice id");
			assertElementPresent(driver,RenewalInvoice.REVISION_BTN_BOTTOM, "Invoice Date");
			assertElementPresent(driver,RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Renewal Date");

			// Verify columns in the grid
			String entityName = getText(driver,RenewalInvoice.ENTITY_NAME_COLUMN, "Entity Name column header");
			assertTextContains(entityName, "Entity Name");

			String dsServiceDescr = getText(driver,RenewalInvoice.DS_SERVICE_DESCR_COLUMN,
					"DS Service Description column header");
			assertTextContains(dsServiceDescr, "Disbursements Service Description");

			String jurisdiction = getText(driver,RenewalInvoice.JURISDICTION_COLUMN, "Jurisdiction column header");
			assertTextContains(jurisdiction, "Jurisdiction");

			String dsAmount = getText(driver,RenewalInvoice.DS_AMOUNT_COLUMN, "DS Amount column header");
			assertTextContains(dsAmount, "DS Amount");

			String creditDS = getText(driver,RenewalInvoice.CREDIT_DS_COLUMN, "Credit DS column header");
			assertTextContains(creditDS, "Credit DS");

			// verfiy Select All and Select None button
			assertElementPresent(driver,RenewalInvoice.SELECT_ALL_BTN, "Select All button");
			assertElementPresent(driver,RenewalInvoice.SELECT_NONE_BTN, "Select None button");

			// Sort By links
			assertElementPresent(driver,RenewalInvoice.ENTITY_NAME_SORTING_LINK, "Entity Name sorting link");
			assertElementPresent(driver,RenewalInvoice.DS_SERVICE_DESCR_SORTING_LINK,
					"Disbursements Service Description sorting link");
			assertElementPresent(driver,RenewalInvoice.DS_AMOUNT_SORTING_LINK, "DS Amount sorting link");
			assertElementPresent(driver,RenewalInvoice.JURISDICTION_SORTING_LINK, "Jurisdisction sorting link");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSPermissionOnRolesPage(String ReportSheet, int count) throws Throwable {
		try {
			String roleName = Excelobject.getCellData(ReportSheet, "Role Name", count);

			// click on Admin link on Home page
			click(driver,HomePage.ADMINLINK, "Admin Link");

			// click on Create Role Button
			click(driver,Admin.CREATE_ROLE_BTN, "Create Role Button");

			// Enter Role Name
			type(driver,Admin.ROLE_NAME_TEXT_BOX, roleName, "Enter Role Name in Role Name Text Box");

			// Verify Whether Checkbox and label for Delaware AR Admin is
			// Present
			isElementPresent(driver,Admin.CREDIT_DS_LINES_CHECKBOX, "Credit DS Lines on Renewal Invoices Checkbox");
			assertTextMatching(driver,Admin.CREDIT_DS_LINES_LABEL, "Credit DS Lines",
					"Label For Credit DS Lines on Renewal Invoices");

			// click on Save Button
			click(driver,Admin.SAVEBTN, "Save Button");

			// Click On Edit Button
			click(driver,Admin.EDIT_BTN, "Edit Button");

			// Click on Credit DS Lines on Renewal Invoices Checkbox and click
			// on save
			// button
			click(driver,Admin.CREDIT_DS_LINES_CHECKBOX, "Credit DS Lines on Renewal Invoices Checkbox");
			click(driver,Admin.SAVEBTN, "Save Button");

			// Verify Credit DS Lines on Renewal Invoices Checkbox is added
			// under Administrative Permissions on Role
			// Profile Page
			assertElementPresent(driver,Admin.CREDIT_DS_LINES_ON_ROLE_PROFILE_PAGE,
					"Credit DS Lines on Renewal Invoices is added under Renewal Permissions on Role Profile Page");

			// Click on Edit Button again and uncheck Credit DS Lines on Renewal
			// Invoices Checkbox
			click(driver,Admin.EDIT_BTN, "Edit Button");
			click(driver,Admin.CREDIT_DS_LINES_CHECKBOX, "Credit DS Lines on Renewal Invoices Checkbox");

			// Click on save btn
			click(driver,Admin.SAVEBTN, "Save Button");

			// Verify No permissions is displayed on Administrative Permissions
			// Field
			assertTextMatching(driver,Admin.RENEWAL_PERMISSIONS_FIELD, "No permissions",
					"No permissions Msg on Renewal Permissions Field");

			// Navigate to Roles Page
			click(driver,Admin.ROLES_LEFT_NAV_LINK, "Roles left nav link");

			// Select Role Name from drop down
			selectBySendkeys(driver,Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filter drop down");
			selectBySendkeys(driver,Admin.SECOND_FILTER_DRPDWN, "equals", "Second filter drop down");

			// Enter above role name used and click on Go Btn
			type(driver,Admin.FILTER_TEXT_FILED, roleName, "Filter Text Field");
			click(driver,Admin.GO_BTN, "Go Btn");

			// Click on Delete Btn
			click(driver,Admin.ROLE_DELETE_BTN, "Role Delete Btn");

			// Handle Popup
			handlepopup();
			waitForElementPresent(driver,Admin.CREATE_ROLE_BTN, "Create Role Button");

		} catch (Exception e) {
			throw e;
		}

	}

	public void verifyCreditDSButtonDependingOnPermission(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {
			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);
			String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);

			// Invoice List verification
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(driver,RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(driver,RenewalInvoice.SEARCH_BTN, "Search Button");

			if (strTestCaseID.contains("Credit DS button is enabled for user having Credit DS permission")) {
				// Click On Credit DS Sorting Link
				click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
				isEnabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button on Invoice tab");
			} else if (strTestCaseID
					.contains("Credit DS button is disabled for user not having Credit DS permission")) {
				// Click On Credit DS Sorting Link
				click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
				isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on Invoice tab");
			}

			// Entity verification
			click(driver,HomePage.ENTITY_TAB, "Entity Tab");

			// Enter Entity ID and click on search button
			type(driver,Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(driver,Entity.SEARCH_BTN, "Search Button");

			if (strTestCaseID.contains("Credit DS button is enabled for user having Credit DS permission")) {
				userHasCreditDSPermissions();
			} else if (strTestCaseID
					.contains("Credit DS button is disabled for user not having Credit DS permission")) {
				userHasNOCreditDSPermissions();
			}

			// Affiliation verification
			click(driver,HomePage.AFFILIATION_TAB, "Affiliation Tab");
			// Enter an id to be searched and click on search button
			type(driver,Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
			click(driver,Affiliation.SEARCHBTN, "Search Button");

			if (strTestCaseID.contains("Credit DS button is enabled for user having Credit DS permission")) {
				userHasCreditDSPermissions();
			} else if (strTestCaseID
					.contains("Credit DS button is disabled for user not having Credit DS permission")) {
				userHasNOCreditDSPermissions();
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void userHasCreditDSPermissions() throws Throwable {
		try {

			// Click on Renewal Invoices from left nav bar
			click(driver,Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");

			// commented because invoice with DS item is not available in
			// current tab
			/*
			 * isEnabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS Button on Current Renewal Invoices tab");
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(driver,RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab");
			 * isEnabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS Button on Last 2 Year's Renewal Invoices tab");
			 */
			// Click on All Renewal Invoices Tab
			click(driver,RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isEnabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button on All renewal invoices tab");

			// Click on Revisions link from left nav
			click(driver,RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");
			// commented because invoice with DS item is not available in
			// current tab
			// isEnabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS
			// Button on Current Revisable Invoices tab");

			// Click on all revisable invoices tab
			click(driver,RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");

			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isEnabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button on All Revisable Invoices tab");

		} catch (Exception e) {
			throw e;
		}

	}

	public void userHasNOCreditDSPermissions() throws Throwable {
		try {

			// Click on Renewal Invoices from left nav bar
			click(driver,Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			// commented because invoice with DS item is not available in
			// current tab
			/*
			 * isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS button on Current Renewal Invoices tab");
			 * 
			 * // Click on Last 2 years renewal invoices tab
			 * click(driver,RenewalInvoice.LAST_TWO_YEARS_REMEWAL_INVOICES_TAB,
			 * "Last 2 years renewal invoice tab");
			 * isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID,
			 * "Credit DS button Last 2 Year's Renewal Invoices tab");
			 */
			// Click on All Renewal Invoices Tab
			click(driver,RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");

			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on All renewal invoices tab");

			// Click on Revisions link from left nav
			click(driver,RenewalInvoice.REVISIONS_LEFT_NAV_LINK, "Revions Left Nav Link");
			// commented because invoice with DS item is not available in
			// current tab
			// isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS
			// button on Current Revisable Invoices yab");

			// Click on all revisable invoices tab
			click(driver,RenewalInvoice.ALL_REVISABLE_INVOICES_TAB, "All Revisable Invoices tab");

			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on All Revisable Invoices tab");

		} catch (Exception e) {
			throw e;
		}

	}

	public void buttonFunctionalityOfCreditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);
			String errorMessage = "At least one DS line must be selected to credit.";

			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(driver,RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(driver,RenewalInvoice.SEARCH_BTN, "Search Button");

			// Get invoice id
			String invoiceNumber = getText(driver,RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "Invoice name");

			// Click on Credit DS Button
			click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Click on Revise button and verify message is displayed
			click(driver,RenewalInvoice.REVISION_BTN_TOP, "Revise Button at the top");
			assertTextMatching(driver,RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);
			click(driver,RenewalInvoice.REVISION_BTN_BOTTOM, "Revise Button at the bottom");
			assertTextMatching(driver,RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);

			// Click on Revision Preview button and verify message is displayed
			click(driver,RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Revision Preview Button at the top");
			assertTextMatching(driver,RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);
			click(driver,RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Revision Preview at the bottom");
			assertTextMatching(driver,RenewalInvoice.ERROR_MESSAGE, errorMessage, errorMessage);

			// Back to Invoice List button is displayed if invoice is accessed
			// from Invoice tab
			assertElementPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertElementPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
					"Back to Invoice List button at the bottom");

			// Functionality of Back to Invoice List
			click(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Page Title");
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Renewal Invoice Search", "Context Title");
			assertElementPresent(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button");

			// Functionality of Revise button at the top
			click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			click(driver,RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(driver,RenewalInvoice.REVISION_BTN_TOP, "Revise Button at the top");
			verifyReviseInvoicePageIsDisplayed(invoiceNumber);
			click(driver,RenewalInvoice.CANCEL_BTN, "Cancel Button");
			verifyInvoiceProfilePageIsDisplayed(invoiceNumber);
			click(driver,RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// Functionality of Revise button at the bottom
			click(driver,RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(driver,RenewalInvoice.REVISION_BTN_BOTTOM, "Revise Button at the bottom");
			verifyReviseInvoicePageIsDisplayed(invoiceNumber);
			click(driver,RenewalInvoice.CANCEL_BTN, "Cancel Button");
			verifyInvoiceProfilePageIsDisplayed(invoiceNumber);
			click(driver,RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// Functionality of Revision Preview button at the top
			click(driver,RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(driver,RenewalInvoice.REVISION_PREVIEW_BTN_TOP, "Revise Button at the top");
			waitForElementToBeClickable(driver,RenewalInvoice.REVISE_BTN, "Revise Button on Revision Preview page");
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Affected Invoices", "Page Title");
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Invoice Preview", "Context Title");
			click(driver,RenewalInvoice.REVISE_BTN, "Revise Button on Revision Preview page");
			verifyReviseInvoicePageIsDisplayed(invoiceNumber);
			click(driver,RenewalInvoice.CANCEL_BTN, "Cancel Button");
			verifyInvoiceProfilePageIsDisplayed(invoiceNumber);
			click(driver,RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// Functionality of Revision Preview button at the bottom
			click(driver,RenewalInvoice.INVOICE_CHECKBOX, "Credit DS checkbox");
			click(driver,RenewalInvoice.REVISION_PREVIEW_BTN_BOTTOM, "Revise Button at the bottom");
			waitForElementToBeClickable(driver,RenewalInvoice.REVISE_BTN, "Revise Button on Revision Preview page");
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Affected Invoices", "Page Title");
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Invoice Preview", "Context Title");

			/*
			 * //Verify Back to Invoice List button is not displayed on Credit DS page if
			 * invoice is accessed from Affiliatoin tab String affId =
			 * Excelobject.getCellData(ReportSheet, "Affiliation ID", count);
			 * click(driver,HomePage.AFFILIATION_TAB, "Affiliation Tab"); // Enter an id to be
			 * searched and click on search button type(driver,Affiliation.AFFILIATIONID, affId,
			 * "Affiliation ID Text box"); click(driver,Affiliation.SEARCHBTN, "Search Button"); //
			 * Click on Renewal Invoices from left nav bar
			 * click(driver,Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK,
			 * "Renewal Invoices left nav link");
			 * click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			 * elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP,
			 * "Back to Invoice List button at the top");
			 * elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
			 * "Back to Invoice List button at the bottom");
			 * 
			 * //Verify Back to Invoice List button is not displayed on Credit DS page if
			 * invoice is accessed from Entity tab String entityId =
			 * Excelobject.getCellData(ReportSheet, "Entity ID", count);
			 * click(driver,HomePage.ENTITY_TAB, "Entity Tab"); // Enter Entity ID and click on
			 * search button type(driver,Entity.ENTITY_ID, entityId, "Entity Id Text box");
			 * click(driver,Entity.SEARCH_BTN, "Search Button"); // Click On Renewal Invoices from
			 * left nav links click(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
			 * "Renewal Invoice Left Nav Link");
			 * click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			 * elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP,
			 * "Back to Invoice List button at the top");
			 * elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
			 * "Back to Invoice List button at the bottom");
			 */

		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyReviseInvoicePageIsDisplayed(String invoiceNumber) throws Throwable {
		try {
			// Verify Revise Invoice page is displayed of respective invoice
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Revise Invoice", "Page Title");
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Revise Invoice", "Context Title");
			String invoiceIDOnReviseInvoice = getText(driver,RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR,
					"Invoice Number on context bar");
			assertTextContains(invoiceIDOnReviseInvoice, invoiceNumber);
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyInvoiceProfilePageIsDisplayed(String invoiceNumber) throws Throwable {
		try {
			// Verfiy user is navigated to Invoice Profile page
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Invoice Profile", "Page Title");
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Invoice Profile", "Context Title");
			String invoiceIDOnInvoiceProfile = getText(driver,RenewalInvoice.INVOICE_ID_ON_CONTEXT_BAR,
					"Invoice Number on context bar");
			assertTextContains(invoiceIDOnInvoiceProfile, invoiceNumber);
		} catch (Exception e) {
			throw e;
		}
	}

	public void backToInvoiceListButtonOnCreditDSPage(String ReportSheet, int count) throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(driver,RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(driver,RenewalInvoice.SEARCH_BTN, "Search Button");

			// Click on Credit DS Button
			click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");

			// Back to Invoice List button is displayed if invoice is accessed
			// from Invoice tab
			assertElementPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertElementPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM,
					"Back to Invoice List button at the bottom");

			// Functionality of Back to Invoice List
			click(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			assertTextMatching(driver,RenewalInvoice.PAGE_TITLE, "Renewal Invoices", "Page Title");
			assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Renewal Invoice Search", "Context Title");
			assertElementPresent(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button");

			// Verify Back to Invoice List button is not displayed on Credit DS
			// page if invoice is accessed from Affiliatoin tab
			String affId = Excelobject.getCellData(ReportSheet, "Affiliation ID", count);
			click(driver,HomePage.AFFILIATION_TAB, "Affiliation Tab");
			// Enter an id to be searched and click on search button
			type(driver,Affiliation.AFFILIATIONID, affId, "Affiliation ID Text box");
			click(driver,Affiliation.SEARCHBTN, "Search Button");

			// Click on Renewal Invoices from left nav bar
			click(driver,Affiliation.RENEWAL_INVOICES_LEFT_NAV_LINK, "Renewal Invoices left nav link");
			// Click on All Renewal Invoices Tab
			click(driver,RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM, "Back to Invoice List button at the bottom");

			// Verify Back to Invoice List button is not displayed on Credit DS
			// page if invoice is accessed from Entity tab
			String entityId = Excelobject.getCellData(ReportSheet, "Entity ID", count);
			click(driver,HomePage.ENTITY_TAB, "Entity Tab");
			// Enter Entity ID and click on search button
			type(driver,Entity.ENTITY_ID, entityId, "Entity Id Text box");
			click(driver,Entity.SEARCH_BTN, "Search Button");
			// Click On Renewal Invoices from left nav links
			click(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Renewal Invoice Left Nav Link");
			// Click on All Renewal Invoices Tab
			click(driver,RenewalInvoice.ALL_REMEWAL_INVOICES_TAB, "All renewal invoices tab");
			// Click On Credit DS Sorting Link
			click(driver,RenewalInvoice.CREDIT_DS_SORTING_LINK, "Credit DS Sorting Link");
			click(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS Button");
			elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_TOP, "Back to Invoice List button at the top");
			elementIsNotPresent(driver,RenewalInvoice.BACK_TO_INVOICE_BTN_BOTTOM, "Back to Invoice List button at the bottom");

		} catch (Exception e) {
			throw e;
		}
	}

	public void creditDSButtonOnInvoiceProfilePage(String ReportSheet, int count, String strTestCaseID)
			throws Throwable {
		try {

			String invoiceID = Excelobject.getCellData(ReportSheet, "Invoice ID", count);

			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// Search for an invoice ID
			type(driver,RenewalInvoice.INVOICE_ID_TEXT_BOX, invoiceID, "Invoice Id Text Box");
			click(driver,RenewalInvoice.SEARCH_BTN, "Search Button");

			click(driver,RenewalInvoice.FIRST_INVOICE_ON_THE_GRID, "First Invoice in the grid");

			// verify Credit DS button is displayed on Invoice Profile page
			assertElementPresent(driver,RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");

			// verify Credit DS button is disabled for revised invoice
			isDisabled(driver,RenewalInvoice.FIRST_CREDIT_DS_BTN_ON_GRID, "Credit DS button on Invoice tab");

			if (strTestCaseID.contains("'Credit DS' buton is enabled on Invoice Profile page for Issued invoice")) {
				// click on Credit DS button and verify Credit DS page is
				// displayed
				click(driver,RenewalInvoice.CREDIT_DS_BTN, "Credit DS Button");
				assertTextMatching(driver,RenewalInvoice.CONTEXT_TITLE, "Credit Disbursements", "Context Title");
			} else if (strTestCaseID
					.contains("'Credit DS' buton is disabled on Invoice Profile page for Revised Invoice")) {
				isDisabled(driver,RenewalInvoice.CREDIT_DS_BTN, "Credit DS button on Invoice tab");
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public void enableOrDisablePSOPFlag(String enableOrDisable) throws Throwable {
		click(driver,Affiliation.MAINTAIN_PAPER_SURCHARGE_BILLING_BTN, "Maintain Paper Surcharge Billing Button");

		if (enableOrDisable.equalsIgnoreCase("Enable")) {
			click(driver,Affiliation.ENABLE_RADIO_BTN, "Enable Radio Button");
			click(driver,Affiliation.SAVEBTN, "Save Button");
			assertTextMatching(driver,Affiliation.PAPER_SURCHARGE_BILLING, "Enabled", "Paper Surchase Billing Value");
		} else if (enableOrDisable.equalsIgnoreCase("Disable")) {
			click(driver,Affiliation.DISABLE_RADIO_BTN, "Disable Radio Button");
			click(driver,Affiliation.SAVEBTN, "Save Button");
			assertTextMatching(driver,Affiliation.PAPER_SURCHARGE_BILLING, "Disabled", "Paper Surchase Billing Value");
		}
	}

	public void verifyPSOPFlagOnAffiliationJoin(String ReportSheet, int count) throws Throwable {
		try {
			String affl_id = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);

			// click on Affiliation Search link
			click(driver,HomePage.AFFILIATIONSEARCHLINK, "Affiliation Search");
			waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");

			// Enter an id to be searched and click on search button
			type(driver,Affiliation.AFFILIATIONID, affl_id, "Affiliation ID Text box");
			click(driver,Affiliation.SEARCHBTN, "Search Button");
			enableOrDisablePSOPFlag("Enable");

			//joinAffiliation(ReportSheet, count);

			// Default value of paper surcharge billing is enabled
			assertTextMatching(driver,Affiliation.PAPER_SURCHARGE_BILLING, "Enabled", "Paper Surchase Billing Value");

			//quitAffiliation(ReportSheet, count);

			enableOrDisablePSOPFlag("Disable");

		} catch (Exception e) {
			throw e;
		}
	}

	public void searchForTheEntity(String ReportSheet, int count) throws Throwable {
		try {
			waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
			click(driver,HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
			type(driver,Entity.ENTITY_ID, Excelobject.getCellData(ReportSheet, "Entity Id", count), "Entity Id text box");
			assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(driver,Entity.SEARCH_BTN, "Search Button");
			// compareStrings(Excelobject.getCellData(ReportSheet, "Entity Id",
			// count),getText(driver,Entity.ENTITY_ID_ON_ENTITY_PROFILE,"Entity Id on
			// Entity Profile Page"));
			// assertElementPresent(driver,Entity.ENTITY_WITH_AFFILIATION_NAME,"Affiliated
			// name section");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchForTheAffiliation(String reportSheet, int count) throws Throwable {
		try {
			waitForElementToBeClickable(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
			waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(driver,Affiliation.AFFILIATIONID, Excelobject.getCellData(reportSheet, "Affiliation Id", count),
					"Affiliation Id text box");
			assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(driver,Affiliation.SEARCHBTN, "Search Button");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void maintainPaperSurchargeBilling() throws Throwable {
		try {
			waitForElementPresent(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button");
			assertElementPresent(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button");
			moveToElement(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button");
			String attribute = getAttribute(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "disabled");
			if (attribute == null) {
				isEnabled(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button enabled");
			} else if (attribute.equalsIgnoreCase("disabled")) {
				isDisabled(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper Surcharge billing button disabled");

			}
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// return getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper Surcharge
		// billing status");
	}

	/*
	 * if(getAttribute(driver,Entity.ENTITY_WITH_AFFILIATION_NAME,"disabled").equals(
	 * "disabled")){ assertElementPresent(driver,Entity.
	 * FIRST_ENTITY_IN_GRID,"Entity name in the Grid");
	 * click(driver,Entity.FIRST_ENTITY_IN_GRID,"Click Entity in the Grid"); }
	 * assertElementPresent(driver,Entity. JOIN_AFFILIATION_BTN,"join Affiliation button");
	 * click(driver,Entity.JOIN_AFFILIATION_BTN,"Button Join Affiliation");
	 * waitForElementPresent(driver,Entity.AFFILIATION_NAME_SEARCH_TEXTBOX,
	 * "Affiliation name search box"); assertElementPresent(driver,Entity.
	 * AFFILIATION_NAME_SEARCH_TEXTBOX,"Affiliation name search box");
	 * type(driver,Entity.AFFILIATION_NAME_SEARCH_TEXTBOX,Excelobject.getCellData(
	 * ReportSheet, "Affiliation Name", count),"Affiliation name search box");
	 * assertElementPresent(driver,Entity.FINDBTN,"Find Button");
	 * click(driver,Entity.FINDBTN,"Find Button"); }
	 * 
	 * }
	 */
	public void intialiseTheReport(String testCaseID, String description, int iLoop) throws Throwable {
		child = extent.startTest(testCaseID, description);
		iterationReport(iLoop, testCaseID + " Started");

	}

	public void endTheReport(String testCaseID, int iLoop) throws Throwable {
		parent.appendChild(child);
		// This will mark end of the one row in data sheet
		iterationReport(iLoop, testCaseID + " Completed");
	}

	public void psopInvoiceUnderHomePage(String ReportSheet, int count, String expectedValue) throws Throwable {
		waitForElementPresent(driver,HomePage.RENEWAL_XSOP_PSOP_INVOICE, "Renewal/XSOP/PSOP Invoice Search");
		assertElementPresent(driver,HomePage.RENEWAL_XSOP_PSOP_INVOICE, "Renewal/XSOP/PSOP Invoice Serach is present");
		compareStrings(expectedValue, getText(driver,HomePage.RENEWAL_XSOP_PSOP_INVOICE, "RENEWAL_XSOP_PSOP_INVOICE"));
	}

	public void psopInoviceSearch(String ReportSheet, int count, String leftNavBarVal) throws Throwable {
		click(driver,HomePage.RENEWAL_XSOP_PSOP_INVOICE, "Renewal/XSOP/PSOP Invoice Serach link");
		assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
		compareStrings(leftNavBarVal, getText(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link"));

	}

	public void psopInvoiceSearchCriteriaUI() throws Throwable {

		try {
			waitForElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Criteria UI");
			compareStrings("PSOP Invoice Search Criteria",
					getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Criteria UI"));
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search Header");
			compareStrings("PSOP Invoice Search",
					getText(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search Header"));
			assertElementPresent(driver,Invoice.SEARCH_BY, "Search By Label");
			compareStrings("Search by", getText(driver,Invoice.SEARCH_BY, "Search By Label"));
			assertElementPresent(driver,Invoice.INVOICE_RADIO_BUTTON_LABEL, "Invoice Radio Button");
			compareStrings(" Invoice ", getText(driver,Invoice.INVOICE_RADIO_BUTTON_LABEL, "Invoice Radio Button"));
			assertElementPresent(driver,Invoice.CUSTOMER_RADIO_BUTTON_LABEL, "Customer Radio Button");
			compareStrings(" Customer ", getText(driver,Invoice.CUSTOMER_RADIO_BUTTON_LABEL, "Invoice Radio Button"));
			assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, "Search text box");
			assertElementPresent(driver,Invoice.INVOICE_STATUS_DROP_DOWN, "Inoice Status Label");
			compareStrings("Invoice Status", getText(driver,Invoice.INVOICE_STATUS_DROP_DOWN, "Inoice Status Label"));
			assertElementPresent(driver,Invoice.SERVICE_CENTER_DROP_DOWN, "Service Center Laebl");
			compareStrings("Service Center", getText(driver,Invoice.SERVICE_CENTER_DROP_DOWN, "Service Center Laebl"));
			assertElementPresent(driver,Invoice.SERVICE_TEAM_DROP_DOWN, "Service Team Label");
			compareStrings("Service Team", getText(driver,Invoice.SERVICE_TEAM_DROP_DOWN, "Service Team Label"));
			assertElementPresent(driver,Invoice.INVOICE_DATE_LABEL, "Invoice Date Label");
			compareStrings("* Invoice Date", getText(driver,Invoice.INVOICE_DATE_LABEL, "Invoice Date Label"));
			assertElementPresent(driver,Invoice.FROM_LABEL, "From Label");
			compareStrings("From", getText(driver,Invoice.FROM_LABEL, "From Label"));
			assertElementPresent(driver,Invoice.To_LABEL, "To Label");
			compareStrings("To", getText(driver,Invoice.To_LABEL, "To Label"));
			assertElementPresent(driver,Invoice.DATE_IN_FROM_LABEL, "Date in From Label");
			// compareStrings(getCurrentDate(),
			// getAttribute(driver,Invoice.DATE_IN_FROM_LABEL, "value"));
			assertElementPresent(driver,Invoice.DATE_IN_TO_LABEL, "Date in To Label");
			// compareStrings(getCurrentDate(),
			// getAttribute(driver,Invoice.DATE_IN_TO_LABEL, "value"));
			assertElementPresent(driver,Invoice.FROM_LABEL_CALENDAR_ICON, "From Date Calendar for date selection");
			assertElementPresent(driver,Invoice.TO_LABEL_CALENDAR_ICON, "To date Calendar for date selection");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void paperSurchargeBillingStatus(String reportSheet, int count, String profile) throws Throwable {
		String paperSurchargeBillingStatus = null;
		String entity_id = Excelobject.getCellData(reportSheet, "Entity Id", count);
		String affl_id = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		try {

			if (profile.equals("Affiliation Profile")) {
				waitForElementPresent(driver,Entity.AFFILIATION_NAME, "Affiliation link");
				assertElementPresent(driver,Entity.AFFILIATION_NAME, "Affiliation link");
				click(driver,Entity.AFFILIATION_NAME, "Affiliation link");
			}
			waitForElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
			assertElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
			assertElementPresent(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
			String billingStatus = getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
			click(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
			if (billingStatus.contains("Disabled")) {
				paperSurchargeBillingStatus = "Enabled";
				click(driver,Entity.PAPER_SURCHARGE_BILLING_ENABLE, "Paper surchage billing enable radio button");
			} else if (billingStatus.equals("Enabled")) {
				paperSurchargeBillingStatus = "Disabled";
				click(driver,Entity.PAPER_SURCHARGE_BILLING_DISABLE, "Paper Surcharge billing disable radio button");
			}
			assertElementPresent(driver,Entity.SAVE_BTN, "Save button");
			click(driver,Entity.SAVE_BTN, "Save button");
			if (profile.equals("Entity Profile")) {
				assertElementPresent(driver,Entity.PAGE_TITLE, "Entity Profile Page");
				paperSurchargeBillingValueStored(entity_id, profile,
						getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status post updating"));
			} else if (profile.equals("Affiliation Profile")) {
				assertElementPresent(driver,Affiliation.SUBGROUPPROFILETITLE, "Affiliation Profile Page");
				paperSurchargeBillingValueStored(affl_id, profile,
						getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status post updating"));
			}
			assertElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surchaarge billing status");
			compareStrings(paperSurchargeBillingStatus,
					getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status post updating"));

		} catch (Exception e) {
			e.printStackTrace();

		} catch (Throwable t) {
			t.printStackTrace();
		}
		// return getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge
		// billing status post updating");
	}

	public void paperSurchageBillingStatusPostQuitAffiliation() throws Throwable {
		maintainPaperSurchargeBilling();
		waitForElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		assertElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		compareStrings("Disabled", getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status"));

	}

	public void paperSurchargeBillingValueStored(String id, String profile, String status) throws Throwable {
		if (status.equals("Enabled")) {
			if (profile.equals("Entity Profile")) {
				ArrayList<String> resultEntity = SQL_Queries.getPSOPBillingFlagForEntity(id);
				for (int i = 0; i < resultEntity.size(); i++) {
					System.out.println(resultEntity.get(i));
					if (resultEntity.get(i).equals(id)) {
						try {
							printMessageInReport(
									"Entity \"" + id + "\" is inserted in table when PSOP flag is enabled");
						} catch (Throwable e) {
							e.printStackTrace();
						}
						break;
					}
				}
			} else if (profile.equals("Affiliation Profile")) {
				ArrayList<String> result = SQL_Queries.getPSOPBillingFlagForAffiliation(id);
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).toString().equals(id)) {

						printMessageInReport(
								"Affiliation \"" + id + "\" is inserted in table when PSOP flag is enabled");
						break;
					}
				}
			}
		} else if (status.equals("Disabled") && profile.equals("Affiliation Profile")) {
			ArrayList<String> result1 = SQL_Queries.getPSOPBillingFlagForAffiliation(id);
			if (result1.size() == 0) {
				printMessageInReport("Affiliation \"" + id + "\" is deleted from table when PSOP flag is disabled");
			}
		} else if (status.equals("Disabled") && profile.equals("Entity Profile")) {
			ArrayList<String> result1 = SQL_Queries.getPSOPBillingFlagForEntity(id);
			if (result1.size() == 0) {
				printMessageInReport("Entity \"" + id + "\" is deleted from table when PSOP flag is disabled");
			}
		}
	}

	// Sprint 25 functions
	public void searchTheDocumentUploadedRBCOld(String filename) throws Throwable {

		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
		click(driver,SOP.CLEARBTN, "Clear Button");
		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "File Name", "Filter drop down");
		waitForElementToBeClickable(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "equals", "Filter drop down2");
		assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(driver,SOP.FILTERTEXTFIELD, filename, "Filter text field");
		assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
		click(driver,SOP.FILTERGOBTN, "Go Button");
	}

	public void selectAndAssignTheFileToTeam() throws Throwable {
		waitForElementPresent(driver,SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		assertElementPresent(driver,SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		click(driver,SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
		waitForElementPresent(driver,SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(driver,SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(driver,SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		waitForElementPresent(driver,SOP.ASSIGN_BTN, "Assign button");
		assertElementPresent(driver,SOP.ASSIGN_BTN, "Assign button");
		click(driver,SOP.ASSIGN_BTN, "Assign button");
		Thread.sleep(1000);
		waitForElementPresent(driver,SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		assertElementPresent(driver,SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		click(driver,SOP.ASSIGN_BTN, "Assign SOP List Items Page button");
		Thread.sleep(1000);
	}

	public String completeTheCESESOP(String reportSheet, int count, String filename) throws Throwable {
		String esopId = null;
		try {
			String entity_name = Excelobject.getCellData(reportSheet, "Entity Name", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "Lawsuit Type", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			searchTheDocumentUploadedRBCOld(filename);
			assertElementPresent(driver,SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
			click(driver,SOP.SORT_BY_RECEIVEDDATE_CST, "Sort by received date");
			// CESSELECTBTN
			waitForElementPresent(driver,SOP.CESSELECTBTN, "CES button");
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES button");
			click(driver,SOP.CESSELECTBTN, "CES button in SOP List Items Page button");
			// SELECT_ARROW_ENTITY_BTN
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, entity_name, "Entity search text box on ESOP");
			// INCLUDE_ALL_REPRESENTATION_JURISDICTION
			waitForElementPresent(driver,SOP.INCLUDE_ALL_REPRESENTATION_JURISDICTION, "inclue all rep jurisdiction");
			assertElementPresent(driver,SOP.INCLUDE_ALL_REPRESENTATION_JURISDICTION, "inclue all rep jurisdiction");
			click(driver,SOP.INCLUDE_ALL_REPRESENTATION_JURISDICTION, "inclue all rep jurisdiction");
			// INCLUDE_STAFFING_ENTITIES
			waitForElementPresent(driver,SOP.INCLUDE_STAFFING_ENTITIES, "inclue all staffing entities");
			assertElementPresent(driver,SOP.INCLUDE_STAFFING_ENTITIES, "inclue all staffing entities");
			click(driver,SOP.INCLUDE_STAFFING_ENTITIES, "inclue all staffing entities");
			// SEARCH_BTN
			waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
			assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
			click(driver,SOP.SEARCH_BTN, "Search button");
			// FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			// GLYPHICON_HOME
			driver.switchTo().defaultContent();
			assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
			click(driver,SOP.GLYPHICON_HOME, "glyphicon button");
			waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			esopId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			// ARROW_REPRESENTATION
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
			assertElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
			click(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
			// CLEARBTN
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
			click(driver,SOP.CLEARBTN, "Clear Button of filter");
			// Select REp Status Active
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_LEFT, "Rep. Status",
					"Select the Representation status from drop down in CES Page");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "Active", "Select Active from the drop down in CES Page");
			// assert
			waitForElementPresent(driver,SOP.REPRESENTATION_STATUS, "Rep Status in the Grid");
			assertElementPresent(driver,SOP.REPRESENTATION_STATUS, "Rep Status in the Grid");
			click(driver,SOP.FILTERGOBTN, "click on go button in CES Page");
			int index = returnIndexOfMatchedTextvalue(driver,SOP.REPRESENTATION_STATUS, "Active");
			//
			waitForElementPresent(driver,SOP.SELECT_BUTTON, "Select Button in Grid");
			assertElementPresent(driver,SOP.SELECT_BUTTON, "Select Button in Grid");
			clickOnAParticularIndexOfAnElement(driver,SOP.SELECT_BUTTON, "Select button in Grid", index);
			// LAWSUITTYPE_DROPDOWN
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(driver,SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			// WORKSHEET_ID_ON_CONTEXT_BAR
			/*
			 * assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID"); esopId =
			 * getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
			 */
			// SUBMIT_CES
			waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
			assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
			click(driver,SOP.SUBMIT_CES, "Submit button in CES");
			driver.switchTo().defaultContent();
			if (esopId.equals(null)) {
				throw new NullPointerException();
			}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return esopId.split("\\: ")[1];
	}

	public void teamSOPDashboard(String reportSheet, int count) throws Throwable {
		String dashboard = Excelobject.getCellData(reportSheet, "Team Dashboard", count);
		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		// TEAM_SOP_DASHBOARD
		waitForElementPresent(driver,SOP.TEAM_SOP_DASHBOARD, "Team SOP Dashboard link in left nav SOP List Page");
		assertElementPresent(driver,SOP.TEAM_SOP_DASHBOARD, "assert Team SOP Dashboard link in left nav SOP List Page");
		click(driver,SOP.TEAM_SOP_DASHBOARD, "click Team SOP Dashboard link in left nav SOP List Page");
		// REJECTED_HARD_COPY_REQUIRED
		assertElementPresent(driver,SOP.REJECTED_HARD_COPY_REQUIRED,
				"Rejected and hard copy required status assert Team SOP Dashboard Page");
		// PHONE_CALL_REQUIRED
		assertElementPresent(driver,SOP.PHONE_CALL_REQUIRED, "Phone Call Required status assert Team SOP Dashboard Page");
		// INCOMPLETE_WORKSHEETS
		assertElementPresent(driver,SOP.INCOMPLETE_WORKSHEETS, "Incomplete Worksheet status assert Team SOP Dashboard Page");
		// PENDING_ACTION_ITEMS
		assertElementPresent(driver,SOP.PENDING_ACTION_ITEMS, "Pending Action Items status assert Team SOP Dashboard Page");
		if (!dashboard.equals("")) {
			// TEAM_DROP_DOWN
			waitForElementPresent(driver,SOP.TEAM_DROP_DOWN, "Team drop down fields in Team SOP Dashboard Page");
			assertElementPresent(driver,SOP.TEAM_DROP_DOWN, "assert Team drop down fields in Team SOP Dashboard Page");
			click(driver,SOP.TEAM_DROP_DOWN, "click Team drop down fields in Team SOP Dashboard Page");
			selectByVisibleText(driver,SOP.TEAM_DROP_DOWN, dashboard, "select the text in Team drop down");
			// REJECTION_FOR_REVIEW
			if (dashboard.equals("SOP Support Team") && dashboard.equals("SOP Dallas Processing Team")) {
				waitForElementPresent(driver,SOP.REJECTION_FOR_REVIEW,
						"Rejection for review status assert Team SOP Dashboard Page");
				assertElementPresent(driver,SOP.REJECTION_FOR_REVIEW,
						"Rejection for review status assert Team SOP Dashboard Page");
			}
		}
	}

	public void rejectedLogFieldValidation(String esopId) throws Throwable {
		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		// WOKSHEET_SEARCH_LEFT_NAV_LINK
		waitForElementPresent(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "worksheet search link in left nav");
		assertElementPresent(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "assert worksheet search link in left nav");
		click(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "click on worksheet search link in left nav");
		// CLASSIC_SEARCH_BTN
		waitForElementPresent(driver,SOP.CLASSIC_SEARCH_BTN, "Classic search button in Worksheet Search Criteria Page");
		assertElementPresent(driver,SOP.CLASSIC_SEARCH_BTN, "assert Classic search button in Worksheet Search Criteria Page");
		click(driver,SOP.CLASSIC_SEARCH_BTN, "click on Classic search button in Worksheet Search Criteria Page");
		String worskheetId = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
		// WORKSHEET_ID_TEXTBOX
		waitForElementPresent(driver,SOP.WORKSHEET_ID_TEXTBOX, "Id text box in Classic Worksheet Search Criteria Page");
		assertElementPresent(driver,SOP.WORKSHEET_ID_TEXTBOX, "assert Id text box in Classic Worksheet Search Criteria Page");
		type(driver,SOP.WORKSHEET_ID_TEXTBOX, worskheetId, "type Id in text box in Classic Worksheet Search Criteria Page");
		// WORKSHEET_SEARCH_BTN
		waitForElementPresent(driver,SOP.WORKSHEET_SEARCH_BTN, "Search button in Classic Worksheet Search Criteria Page");
		assertElementPresent(driver,SOP.WORKSHEET_SEARCH_BTN,
				"assert Search button in Classic Worksheet Search Criteria Page");
		click(driver,SOP.WORKSHEET_SEARCH_BTN, "click Search button in Classic Worksheet Search Criteria Page");
		// BAD_LOG
		assertElementPresent(driver,SearchWorksheet.BAD_LOG, "Bad log in Worksheet Profile Page");
		String isBadLog = getText(driver,SearchWorksheet.BAD_LOG, "Bad log in Worksheet Profile Page");
		compareStrings(isBadLog, "No");
		// WORKSHEET_TYPE
		assertElementPresent(driver,SearchWorksheet.WORKSHEET_TYPE, "Worksheet Type in Worksheet Profile Page");
		String worksheetType = getText(driver,SearchWorksheet.WORKSHEET_TYPE, "Worksheet Type in Worksheet Profile Page");
		compareStrings(worksheetType, "Standard SOP");
		// CONFIRMATION_NUMBER
		assertElementPresent(driver,SearchWorksheet.CONFIRMATION_NUMBER, "Confirmation Number in Worksheet Profile Page");
		String confNum = getText(driver,SearchWorksheet.CONFIRMATION_NUMBER, "Confirmation Number in Worksheet Profile Page");
		compareStrings(confNum, "--");
		// CUSTOMER
		assertElementPresent(driver,SearchWorksheet.CUSTOMER, "Customer in Worksheet Profile Page");
		String customer = getText(driver,SearchWorksheet.CUSTOMER, "Customer in Worksheet Profile Page");
		compareStrings(customer, "--");
		// INDIVIDUAL
		assertElementPresent(driver,SearchWorksheet.INDIVIDUAL, "Individual in Worksheet Profile Page");
		String individual = getText(driver,SearchWorksheet.INDIVIDUAL, "Individual in Worksheet Profile Page");
		compareStrings(individual, "--");
		// REJECTION_APPROVED
		assertElementPresent(driver,SearchWorksheet.REJECTION_APPROVED, "Rejection Approved in Worksheet Profile Page");
		String rejectionApproved = getText(driver,SearchWorksheet.REJECTION_APPROVED,
				"Rejection Approved in Worksheet Profile Page");
		compareStrings(rejectionApproved, "Yes");
		// ATTEMPTED
		assertElementPresent(driver,SearchWorksheet.ATTEMPTED, "ATTEMPTED in Worksheet Profile Page");
		String attempted = getText(driver,SearchWorksheet.ATTEMPTED, "ATTEMPTED in Worksheet Profile Page");
		compareStrings(attempted, "No");
		// INITIAL_SUBSEQUENT
		assertElementPresent(driver,SearchWorksheet.INITIAL_SUBSEQUENT, "Initial/Subsequent in Worksheet Profile Page");
		String intialSubsequent = getText(driver,SearchWorksheet.INITIAL_SUBSEQUENT,
				"Initial/Subsequent in Worksheet Profile Page");
		compareStrings(intialSubsequent, "Initial");
		// CONSOLIDATED
		assertElementPresent(driver,SearchWorksheet.CONSOLIDATED, "Consolidated in Worksheet Profile Page");
		String consolidated = getText(driver,SearchWorksheet.CONSOLIDATED, "Consolidated in Worksheet Profile Page");
		compareStrings(consolidated, "No");
		// MULTIPLE
		assertElementPresent(driver,SearchWorksheet.MULTIPLE, "MULTIPLE in Worksheet Profile Page");
		String multiple = getText(driver,SearchWorksheet.MULTIPLE, "MULTIPLE in Worksheet Profile Page");
		compareStrings(multiple, "No");
		// LETTER
		assertElementPresent(driver,SearchWorksheet.LETTER, "Letter in Worksheet Profile Page");
		String letter = getText(driver,SearchWorksheet.LETTER, "Letter in Worksheet Profile Page");
		compareStrings(letter, "No");
		// POST_STATUS
		assertElementPresent(driver,SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		String postStatus = getText(driver,SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		compareStrings(postStatus, "UnPosted");
		ArrayList<String> cesFields = SQL_Queries.getTheFieldsForTheESOPs(esopId);
		for (int i = 0; i < cesFields.size(); i++) {
			if (cesFields.get(i) == null) {
				cesFields.set(i, "--");
			}
		}
		// DEFENDANT_NAME
		assertElementPresent(driver,SearchWorksheet.DEFENDANT_NAME, "Defendant in Worksheet Profile Page");
		String defendant = getText(driver,SearchWorksheet.DEFENDANT_NAME, "Defendant in Worksheet Profile Page");
		compareStrings(defendant, cesFields.get(2));
		// AGENCY_TITLE
		assertElementPresent(driver,SearchWorksheet.AGENCY_TITLE, "Agency in Worksheet Profile Page");
		String agencyTitle = getText(driver,SearchWorksheet.AGENCY_TITLE, "Agency in Worksheet Profile Page");
		compareStrings(agencyTitle, "None Specified");
		// CASE_NUMBER
		assertElementPresent(driver,SearchWorksheet.CASE_NUMBER, "case number in Worksheet Profile Page");
		String caseNumber = getText(driver,SearchWorksheet.CASE_NUMBER, "case number in Worksheet Profile Page");
		compareStrings(caseNumber, cesFields.get(0));
		// PLAINTIFF
		assertElementPresent(driver,SearchWorksheet.PLAINTIFF, "Plaintiff in Worksheet Profile Page");
		String plaintiff = getText(driver,SearchWorksheet.PLAINTIFF, "Plaintiff in Worksheet Profile Page");
		compareStrings(plaintiff, cesFields.get(1));

	}

	public String viewAndCreateTheWorkSheetUsingESOPId(String reportSheet, int count, String esopId) throws Throwable {
		String worksheetId = null;
		try {
			String defendentName = Excelobject.getCellData(reportSheet, "WS Defendent Name", count);
			String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
			String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);
			String attorney = Excelobject.getCellData(reportSheet, "WS Attorney", count);
			String court = Excelobject.getCellData(reportSheet, "WS Court", count);
			String documentServed = Excelobject.getCellData(reportSheet, "Document Served", count);
			String caseNum = Excelobject.getCellData(reportSheet, "WS Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "WS Plaintiff", count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			searchForESOP(driver,esopId);
			try {
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);

			} catch (NoSuchElementException e) {
			}
			Thread.sleep(5000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(5000);
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			searchForESOP(driver,esopId);
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			waitForElementPresent(driver,SOP.VIEW_BTN, "View button");
			assertElementPresent(driver,SOP.VIEW_BTN, "View button");
			click(driver,SOP.VIEW_BTN, "View button");
			handlePopUpWindwow(driver);
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(3000);
			WebElement createWs = null;
			try {
				createWs = driver.findElement(SOP.CREATE_WORKSHEET);
				waitForElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
			} catch (NoSuchElementException e) {
			}
			if (createWs == null) {
				Thread.sleep(4000);
				selectAndAssignTheFileToTeam();
				Thread.sleep(4000);
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);
				Thread.sleep(2000);
				String parentWin = driver.getWindowHandle();
				waitForElementPresent(driver,SOP.VIEW_BTN, "View button");
				assertElementPresent(driver,SOP.VIEW_BTN, "View button");
				click(driver,SOP.VIEW_BTN, "View button");
				handlePopUpWindwow(driver);
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}

			Thread.sleep(2000);
			WebElement initalRadioButton = null;
			try {

				initalRadioButton = driver.findElement(SOP.INITIAL_RADIOBTN);

			} catch (NoSuchElementException e) {
			}
			if (initalRadioButton == null) {
				click(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}
			if (isAttempted.equalsIgnoreCase("Yes")) {
				// ATTEMPTED_YES_RADIO_BUTTON
				waitForElementPresent(driver,SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Radio button");
				assertElementPresent(driver,SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Radio button");
				click(driver,SOP.ATTEMPTED_YES_RADIO_BUTTON, "Attempted Radio button");
			}
			// INITIAL_RADIOBTN
			waitForElementPresent(driver,SOP.INITIAL_RADIOBTN, "Initial Radio button");
			assertElementPresent(driver,SOP.INITIAL_RADIOBTN, "Initial Radio button");
			click(driver,SOP.INITIAL_RADIOBTN, "Initial Radio button");
			if (!caseNum.equals("")) {
				// CASEID_TEXTBOX
				waitForElementPresent(driver,SOP.CASEID_TEXTBOX, "Case Id text box");
				assertElementPresent(driver,SOP.CASEID_TEXTBOX, "Case Id text box");
				type(driver,SOP.CASEID_TEXTBOX, caseNum, "Case Id text box");
			}
			if (!plaintiff.equals("")) {
				// PLAINTIFF_TEXT_BOX
				waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
				assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plantiff text box");
				type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plantiff text box");
			}
			if (!defendentName.equals("")) {
				// DEFENDANT_TEXTFIELD
				waitForElementPresent(driver,SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
				assertElementPresent(driver,SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
				type(driver,SOP.DEFENDANT_TEXTFIELD, defendentName, "Defendent text box");
			}
			/*
			 * //REJECT_REASON if(!rejectedReason.equals("")){
			 * assertElementPresent(driver,WorksheetCreate.
			 * REJECTED_REASON,"Rejected Reason wroksheet step 1 page");
			 * selectByVisibleText(driver,WorksheetCreate.REJECTED_REASON,
			 * rejectedReason,"Rejected Reason wroksheet step 1 page");
			 * assertElementPresent(driver,SOP.DATE_CALENDAR, "Calendar Icon");
			 * click(driver,SOP.DATE_CALENDAR, "Calendar Icon"); click(driver,Entity.TODAYSDATE,
			 * "Todays Date");
			 * assertElementPresent(driver,SOP.NEXT_BTN,"next button in wroksheet step 1 page");
			 * click(driver,SOP.NEXT_BTN,"next button in wroksheet step 1 page");
			 * Thread.sleep(1000); //COURT //below will be used to edit the court which will
			 * validate the story 1283
			 * assertElementPresent(driver,WorksheetCreate.COURT,"Court in wroksheet step 2 page");
			 * selectByVisibleText(driver,WorksheetCreate.COURT,
			 * court,"Court in wroksheet step 2 page"); }
			 */
			// else if(rejectedReason.equals("")){
			// For Certified mail below one check need to be added
			// POST_MARKED_DATE
			try {
				driver.findElement(WorksheetCreate.METHOD_OF_SERVICE);
				String methodOfService = getText(driver,WorksheetCreate.METHOD_OF_SERVICE, "Method of Service");
				if (methodOfService.contains("Mail") && !methodOfService.equals("Express Mail")) {
					waitForElementPresent(driver,WorksheetCreate.POST_MARKED_DATE, "Post marked Date text box");
					assertElementPresent(driver,WorksheetCreate.POST_MARKED_DATE, "Post marked Date text box");
					int lastYear = Integer.valueOf(getCurrentDate().split("\\/")[2]) - 1;
					String lastYearDate = getCurrentDate().split("\\/")[0] + "/" + getCurrentDate().split("\\/")[1]
							+ "/" + String.valueOf(lastYear);
					type(driver,WorksheetCreate.POST_MARKED_DATE, lastYearDate, "Post marked Date text box");
				}
			} catch (NoSuchElementException e) {
			}
			// EDIT_RECEIVED_BY
			selectByIndex(driver,WorksheetCreate.EDIT_RECEIVED_BY, 1, "Received By drop downs in wroksheet step 1 page");
			// WORKSHEET_TYPE
			waitForElementPresent(driver,WorksheetCreate.WORKSHEET_TYPE, "worksheet type in wroksheet step 1 page");
			String worksheetType = getText(driver,WorksheetCreate.WORKSHEET_TYPE, "worksheet type in wroksheet step 1 page");
			// ENTITY_IN_WORKSHEET_PROFILE
			waitForElementPresent(driver,WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE,
					"Entity in wroksheet profile step 1 page");
			String entityInWorksheet = getAttribute(driver,WorksheetCreate.ENTITY_IN_WORKSHEET_PROFILE, "value");
			// NEXT_BTN
			waitForElementPresent(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
			assertElementPresent(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
			click(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
			Thread.sleep(1200);
			// below check for if error- > 'Enter a value for Other Mehod of Serivce.
			try {

				driver.findElement(SOP.OTHER_METHOD_OF_SERVICE);
				Thread.sleep(2000);
				type(driver,SOP.OTHER_METHOD_OF_SERVICE_TEXT_BOX, "Other", "Type the Text for other Method of Service");
				click(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
				Thread.sleep(700);
			} catch (NoSuchElementException e) {
			}
			// below check for if Error -> Enter a valid value for Case#.
			try {
				// Below code is modified on 12/23
				driver.findElement(SOP.CASE_NUMBER_IN_WORKSHEET_ERROR);
				Thread.sleep(1000);
				boolean caseTextPsNum = false;
				// Below try block is added as some method of srvice has different way of
				// SElecting the CASe# in worksheet page 1
				try {
					driver.findElement(SOP.CASE_TEXT_PS_CASENUM);
					Thread.sleep(500);
					type(driver,SOP.CASE_TEXT_PS_CASENUM, "CNInWorksheet", "Type the Text for other Method of Service");
					click(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
					caseTextPsNum = true;
				} catch (NoSuchElementException e) {
				}
				if (caseTextPsNum == false) {
					type(driver,WorksheetCreate.CASE_TEXT, "CNInWorksheet", "Type the Text for other Method of Service");
					click(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
					Thread.sleep(700);
				}
			} catch (NoSuchElementException e) {
			}
			// This try block is added on 12/23
			try {
				driver.findElement(SOP.CASE_NUMBER_BLANK);
				type(driver,WorksheetCreate.CASE_TEXT, "CNInWorksheet", "Type the Text for other Method of Service");
				click(driver,SOP.NEXT_BTN, "next button in wroksheet step 1 page");
				Thread.sleep(700);
			} catch (NoSuchElementException e) {
			}

			// COURT_NAME_TEXT_BOX
			String attorneyNoneAttribute = "";
			String courtNameInWorksheet = "";

			try {
				attorneyNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
			} catch (NoSuchElementException e) {
			}
			try {
				driver.findElement(SOP.EXISTING_COURTNAME);
				courtNameInWorksheet = getText(driver,SOP.TEXT_BOX_COURTNAME, "value");
			} catch (NoSuchElementException e) {
			}
			try {
				driver.findElement(SOP.COURT_NAME_TEXT_BOX);
				courtNameInWorksheet = getAttribute(driver,SOP.COURT_NAME_TEXT_BOX, "value");
			} catch (NoSuchElementException e) {
			}
			if (courtNameInWorksheet.equals("")) {
				courtNameInWorksheet = null;
			}
			String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
			compareStrings(courtNameInWorksheet, courtNameInCES);
			// TEXT_BOX_ATTORNEYNAME
			if (attorneyNoneAttribute == null) {
				waitForElementPresent(driver,SOP.TEXT_BOX_ATTORNEYNAME, "Attorney name text box in wroksheet step 2 page");
				assertElementPresent(driver,SOP.TEXT_BOX_ATTORNEYNAME, "Attorney name text box in wroksheet step 2 page");
				String attorneyNameInWorksheet = getAttribute(driver,SOP.TEXT_BOX_ATTORNEYNAME, "value");
				if (attorneyNameInWorksheet.equals("")) {
					attorneyNameInWorksheet = null;
				}
				String attorneyNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(0);
				compareStrings(attorneyNameInWorksheet, attorneyNameInCES);
			}
			if (courtNameInWorksheet == null) {
				waitForElementPresent(driver,SOP.COURT_NONE_RADIOBTN, "court none radio button in wroksheet step 2 page");
				assertElementPresent(driver,SOP.COURT_NONE_RADIOBTN, "court none radio button in wroksheet step 2 page");
				click(driver,SOP.COURT_NONE_RADIOBTN, "court none radio button in wroksheet step 2 page");
			}
			if (!court.equals("")) {
				// RADIO_BUTTON_EXISTING_COURT
				waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
						"existing court radio button in wroksheet step 2 page");
				assertElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
						"existing court radio button in wroksheet step 2 page");
				click(driver,SOP.RADIO_BUTTON_EXISTING_COURT, "existing court radio button in wroksheet step 2 page");
				// DROP_DOWN_COURT_NAME
				assertElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "existing court drop down in wroksheet step 2 page");
				selectByIndex(driver,SOP.DROP_DOWN_COURT_NAME, 1, "existing court drop down in wroksheet step 2 page");
				Thread.sleep(1000);
			}
			if (!attorney.equals("")) {
				// RADIO_BUTTON_EXISTING_ATTORNEYSENDER
				waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
						"existing Attorney radio button in wroksheet step 2 page");
				assertElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
						"existing Attorney radio button in wroksheet step 2 page");
				click(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
						"existing Attorney radio button in wroksheet step 2 page");
				// DROP_DOWN_ATTORNEY_SENDER_NAME
				assertElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME,
						"existing Attorney drop down in wroksheet step 2 page");
				selectByIndex(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1,
						"existing Attorney drop down in wroksheet step 2 page");
			}
			waitForElementPresent(driver,SOP.NEXT_BTN, "next button in wroksheet step 2 page");
			assertElementPresent(driver,SOP.NEXT_BTN, "next button in wroksheet step 2 page");
			click(driver,SOP.NEXT_BTN, "next button in wroksheet step 2 page");

			WebElement docServed = null;
			try {
				docServed = driver.findElement(SOP.DOCUMENT_SERVED);
				if (docServed != null) {
					click(driver,SOP.FIRST_DOCUMENT_SERVED, "document Type drop down  in wroksheet step 3 page");
					Thread.sleep(2000);
					// DOCUMENT_SERVED_MOVE_RIGHT
					assertElementPresent(driver,SOP.DOCUMENT_SERVED_MOVE_RIGHT, "Move Right Arrow in wroksheet step 3 page");
					click(driver,SOP.DOCUMENT_SERVED_MOVE_RIGHT, "Move Right Arrow in wroksheet step 3 page");
					Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
			}
			/*
			 * if(!lawSuitSubtype.equals("")){ //LAWSUITE_SUBTYPE
			 * assertElementPresent(driver,WorksheetCreate.
			 * LAWSUITE_SUBTYPE,"law suit sub type in wroksheet step 3 page");
			 * selectByVisibleText(driver,WorksheetCreate.LAWSUITE_SUBTYPE,
			 * lawSuitSubtype,"law suit sub type in wroksheet step 3 page"); }
			 */

			WebElement specialCircumStances = null;
			try {
				specialCircumStances = driver.findElement(WorksheetCreate.SPECIAL_CIRCUMSTANCES);
				if (specialCircumStances != null) {
					selectByIndex(driver,WorksheetCreate.SPECIAL_CIRCUMSTANCES, 1,
							" Special Cicumstances drop down  in wroksheet step 3 page");
					Thread.sleep(2000);
				}
			} catch (NoSuchElementException e) {
			}
			/*
			 * else if(branchPlant.equals("NRAI")) {
			 * selectByVisibleText(driver,SOP.DOCUMENT_SERVED,
			 * documentServed,"document Type drop down  in wroksheet step 3 page");
			 * //DOCUMENT_SERVED_MOVE_RIGHT assertElementPresent(driver,SOP.
			 * DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page");
			 * click(driver,SOP.
			 * DOCUMENT_SERVED_MOVE_RIGHT,"Move Right Arrow in wroksheet step 3 page"); }
			 */
			// ANSWER_DATE_NONE
			waitForElementPresent(driver,WorksheetCreate.ANSWER_DATE_NONE, "Anser date radio button in wroksheet step 3 page");
			assertElementPresent(driver,WorksheetCreate.ANSWER_DATE_NONE, "Anser date radio button in wroksheet step 3 page");
			click(driver,WorksheetCreate.ANSWER_DATE_NONE, "Anser date radio button in wroksheet step 3 page");
			if (saveIncomplete.equalsIgnoreCase("Yes")) {
				// SAVE_INCOMPLETE_BUTTON
				waitForElementPresent(driver,SOP.SAVE_INCOMPLETE_BUTTON, "Anser date radio button in wroksheet step 3 page");
				assertElementPresent(driver,SOP.SAVE_INCOMPLETE_BUTTON, "Anser date radio button in wroksheet step 3 page");
				click(driver,SOP.SAVE_INCOMPLETE_BUTTON, "Anser date radio button in wroksheet step 3 page");
			}
			// SAVE_BTN
			else if (saveIncomplete.equalsIgnoreCase("No")) {
				waitForElementPresent(driver,Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
				assertElementPresent(driver,Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
				click(driver,Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
				Thread.sleep(2000);
				// DOCUMENT_TYPE_DROPDWN
				// here one check for if doc type is not selected
				// Enter a value for Document Type.
				try {
					WebElement docNotSelected = null;
					docNotSelected = driver.findElement(WorksheetCreate.DOCUMENT_TYPE_NOT_SELECTED);
					if (docNotSelected != null) {
						selectByIndex(driver,SOP.DOCUMENT_TYPE_DROPDWN, 3,
								"document Type drop down  in wroksheet step 3 page");
						waitForElementPresent(driver,Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
						assertElementPresent(driver,Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
						click(driver,Entity.SAVE_BTN, "Save button in wroksheet step 3 page");
					}
				} catch (NoSuchElementException e) {

				}
			}
			// WORKSHEET_ID_ON_CONTEXT_BAR
			waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id created");
			assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id created");
			// click(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"Worksheet id created");
			worksheetId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "Worksheet id created");
			if (worksheetId.equals(null)) {
				throw new NullPointerException();
			}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		System.out.println("Worksheet id : " + worksheetId);
		Thread.sleep(3000);
		return worksheetId.split("\\: ")[1];
	}

	public void manageActionItemPSOPAndExecuteCentralized(String reportSheet, int count) throws Throwable {

		String deliverable = Excelobject.getCellData(reportSheet, "Deliverable", count);
		String deliveryMethod = Excelobject.getCellData(reportSheet, "Delivery Method", count);
		String participant = Excelobject.getCellData(reportSheet, "Participant Name", count);
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String isAttempted = Excelobject.getCellData(reportSheet, "Is Attempted", count);
		String rejectedReason = Excelobject.getCellData(reportSheet, "Rejected Reason", count);
		String saveIncomplete = Excelobject.getCellData(reportSheet, "Save Incomplete", count);

		if (isAttempted.equals("No") && rejectedReason.equals("") && saveIncomplete.equals("No")) {
			// CHOOSE_DI_BTN
			assertElementPresent(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button");
			click(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button");
			// ACTIONS_LIST_BTN
			assertElementPresent(driver,SOP.ACTIONS_LIST_BTN, "Action List Button");
			click(driver,SOP.ACTIONS_LIST_BTN, "Action List Button");
			if (branchPlant.equals("CTCORP")) {
				// MANAGE_ACTIONS_ITEM_BTN
				assertElementPresent(driver,SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage action item Button");
				click(driver,SOP.MANAGE_ACTIONS_ITEM_BTN, "Manage action item Button");
				// DELIVERABLE
				assertElementPresent(driver,SOP.DELIVERABLE, "Deliverable drop down element");
				click(driver,SOP.DELIVERABLE, "Deliverable drop down element");
				selectByVisibleText(driver,SOP.DELIVERABLE, deliverable, "Deliverable drop down element");
				// DELIVERY_METHOD
				assertElementPresent(driver,SOP.DELIVERY_METHOD, "Delivery drop down element");
				click(driver,SOP.DELIVERY_METHOD, "Delivery drop down element");
				selectByVisibleText(driver,SOP.DELIVERY_METHOD, deliveryMethod, "Delivery drop down element");
				// EXISTING_RECIPIENT
				assertElementPresent(driver,SOP.EXISTING_RECIPIENT, "existing recipient element");
				click(driver,SOP.EXISTING_RECIPIENT, "existing recipient element");
				// RECIPIENT_SELECT_BTN
				assertElementPresent(driver,SOP.RECIPIENT_SELECT_BTN, "Recipient select Button");
				click(driver,SOP.RECIPIENT_SELECT_BTN, "Recipient select Button");
				// PARTICIPANTNAMEFIELD
				assertElementPresent(driver,SOP.PARTICIPANTNAMEFIELD, "Participant search text box");
				selectBySendkeys(driver,SOP.PARTICIPANTNAMEFIELD, participant, "Participant search text box");
				// FINDBTN
				assertElementPresent(driver,SOP.FINDBTN, "Find Button");
				click(driver,SOP.FINDBTN, "Find Button");
				// PARTICIPANT_NAME
				assertElementPresent(driver,SOP.PARTICIPANT_NAME, "Participant name element");
				int index = returnIndexOfMatchedTextvalue(driver,SOP.PARTICIPANT_NAME, participant);
				assertElementPresent(driver,SOP.SELECT_BUTTON_SELECT_RECIPIENT, "Select Button in Grid");
				clickOnAParticularIndexOfAnElement(driver,SOP.SELECT_BUTTON_SELECT_RECIPIENT, "Select button in Grid", index);
				// ADDUPDATE_BTN
				assertElementPresent(driver,SOP.ADDUPDATE_BTN, "Recipient select Button");
				click(driver,SOP.ADDUPDATE_BTN, "Recipient select Button");
				// ACTIONS_LIST_BTN
				assertElementPresent(driver,SOP.ACTIONS_LIST_BTN, "Action List Button");
				click(driver,SOP.ACTIONS_LIST_BTN, "Action List Button");
				// EXECUTE_CENTRALIZED
				assertElementPresent(driver,SOP.EXECUTE_CENTRALIZED, "Execute Centralized Button");
			}
			isEnabled(driver,SOP.EXECUTE_CENTRALIZED, "Execute Centralized Button");
			click(driver,SOP.EXECUTE_CENTRALIZED, "Execute Centralized Button");
		} else {
			// CHOOSE_DI_BTN
			assertElementPresent(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button in worksheet Profile Page");
			isDisabled(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button in Worksheet Profile Page");
		}
	}

	/*
	 * public void updateTheXML(String fileSourcePath , String valueToUpdate, String
	 * powershellFilePath){ String command = "powershell.exe -file "+
	 * powershellFilePath + " "+ fileSourcePath +" " + valueToUpdate; // in above +
	 * " " + hardCopy //"C:\\Users\\M1052416\\Desktop\\changeSOPXML.ps1 "+ arg1 +" "
	 * + arg2; //C:\\Users\\M1052416\\Desktop\\TestDataNoHardCopy19.XML 2/27/2020";
	 * getTheCommandToRunThePowerShell(command);
	 * 
	 * }
	 */
	public void updateTheXML(String fileSourcePath, String date, String hardCopy, String powershellFilePath) {

		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " " + date + " "
				+ hardCopy;
		getTheCommandToRunThePowerShell(command);

	}

	public void copyTheFile(String fileSourcePath, String fileDestinationPath, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " "
				+ fileDestinationPath;
		// "C:\\Users\\M1052416\\Desktop\\fileCopy.ps1
		// C:\\Users\\M1052416\\workspace\\ArrowNPD\\TestData\\TestDataNoHardCopy.XML
		// C:\\Users\\M1052416\\Desktop";
		getTheCommandToRunThePowerShell(command);
	}

	public void deleteTheFile(String fileSourcePath, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath;
		// "C:\\Users\\M1052416\\Desktop\\fileCopy.ps1
		// C:\\Users\\M1052416\\workspace\\ArrowNPD\\TestData\\TestDataNoHardCopy.XML
		// C:\\Users\\M1052416\\Desktop";
		getTheCommandToRunThePowerShell(command);
	}

	public void uploadTheFiles(String fileSourcePath, String fileDestinationPath, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " "
				+ fileDestinationPath;
		// C:\\Users\\M1052416\\Desktop\\fileupload.ps1
		// C:\\Users\\M1052416\\Desktop\\TestScanner.XML
		// \\\\nastnri95001.na.wkglobal.com\\SopPassInterim\\PTRP\\TemporaryIsopImages\\AutoUploadSource\\ScanFirst\\ScanFirst";
		getTheCommandToRunThePowerShell(command);
	}

	public void renameTheFiles(String fileSourcePath, String fileRename, String powershellFilePath) {
		String command = "powershell.exe -file " + powershellFilePath + " " + fileSourcePath + " " + fileRename;
		// C:\\Users\\M1052416\\Desktop\\fileRename.ps1
		// C:\\Users\\M1052416\\Desktop\\TestScanner.XML"+ " TestScanner"+1+".XML";
		getTheCommandToRunThePowerShell(command);
		/*
		 * if(i == 1){ command2 =
		 * "powershell.exe -file C:\\Users\\M1052416\\Desktop\\fileRename.ps1 C:\\Users\\M1052416\\Desktop\\TestScanner.XML"
		 * + " TestScanner"+i+".XML"; } else if(i!=1) { int presentFile = i - 1;
		 * command2 =
		 * "powershell.exe -file C:\\Users\\M1052416\\Desktop\\fileRename.ps1 C:\\Users\\M1052416\\Desktop\\TestScanner"
		 * +presentFile+".XML"+ " TestScanner"+i+".XML"; }
		 */
	}

	public void getTheCommandToRunThePowerShell(String command) {
		try {
			Process powerShellProcess = Runtime.getRuntime().exec(command);
			powerShellProcess.getOutputStream().close();
			String line;
			BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
			while ((line = stdout.readLine()) != null) {
				System.out.println(line);
			}
			stdout.close();
			BufferedReader stderr = new BufferedReader(new InputStreamReader(powerShellProcess.getErrorStream()));
			while ((line = stderr.readLine()) != null) {
				System.out.println(line);
			}
			stderr.close();
			System.out.println("Done");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void psopInvoicesList(String reportSheet, int count, String profile) throws Throwable {
		String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
		String entityId = Excelobject.getCellData(reportSheet, "Entity Id", count);
		String affiliationName = Excelobject.getCellData(reportSheet, "Affiliation Name", count);
		String affiliationId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
		// PSOP_INVOICES_LEFT_NAV_BAR
		waitForElementPresent(driver,Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
		assertElementPresent(driver,Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
		click(driver,Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
		// PSOP_INVOICES_PROFILE_LEFT_NAV_BAR
		assertElementPresent(driver,Entity.PSOP_INVOICES_PROFILE_LEFT_NAV_BAR, "Psop Invoices profile link");
		// PSOP_INVOICES_CONTEXTTILE
		if (profile.equalsIgnoreCase("Standalone Entity")) {
			assertElementPresent(driver,Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices conetxt");
			compareStrings(entityName, getText(driver,Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices context"));
			// ENTITY_ID_ON_ENTITY_PROFILE
			assertElementPresent(driver,Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page");
			compareStrings(entityId, getText(driver,Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page").split("\\: ")[1]);
		} else if (profile.equalsIgnoreCase("Affiliation")) {
			// PSOP_INVOICES_CONTEXTTILE
			assertElementPresent(driver,Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices conetxt");
			compareStrings(affiliationName, getText(driver,Entity.PSOP_INVOICES_CONTEXTTILE, "Psop Invoices context"));
			// ENTITY_ID_ON_ENTITY_PROFILE
			assertElementPresent(driver,Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page");
			compareStrings(affiliationId,
					getText(driver,Entity.ENTITY_ID_ON_ENTITY_PROFILE, "Entity id on Page").split("\\: ")[1]);
		}

		// PAGE_TITLE
		assertElementPresent(driver,Entity.PAGE_TITLE, "Page Title");
		compareStrings("PSOP Invoices", getText(driver,Entity.PAGE_TITLE, "Page Title"));
		// PSOP_INVOICES_DROP_DOWN
		assertElementPresent(driver,Entity.PSOP_INVOICES_DROP_DOWN, "Psop Invoices drop down");
		// PSOP_INVOICES_IS
		assertElementPresent(driver,Entity.PSOP_INVOICES_IS, "Psop Invoices is text");
		// PSOP_INVOICES_TEXT_SEARCH
		assertElementPresent(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, "Psop Invoices text box");
		// PSOP_INVOICES_HELP_ICON
		assertElementPresent(driver,Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		String parentWindow = driver.getWindowHandle();
		isEnabled(driver,Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		click(driver,Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		handlePopUpWindwow(driver);
		driver.close();
		driver.switchTo().window(parentWindow);
		// GO_BTN
		assertElementPresent(driver,Entity.GO_BTN, "Psop Invoices Go Button");
		isEnabled(driver,Entity.GO_BTN, "Psop Invoices Go Button");
		// PSOP_INVOICES_SORT_BY
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY, "Psop Invoices Sort by");
		// PSOP_INVOICES_SORT_BY_INDEX
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		// PSOP_INVOICES_SORT_BY_OW_ORDER
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		// PSOP_INVOICES_SORT_BY_PRINT_DATE
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		// PSOP_INVOICES_SORT_BY_INVOICE_DATE
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		// PSOP_INVOICES_SORT_BY_INVOICE_AMOUNT
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		// PSOP_INVOICES_SORT_BY_OPEN_AMOUNT
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		// PSOP_INVOICES_GRID_HEADER_INVOICE
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_INVOICE, "Psop Invoices Grid header invoice");
		compareStrings("Invoice #", //
				getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_INVOICE, "Psop Invoices Grid header invoice"));
		// PSOP_INVOICES_GRID_HEADER_OW_ORDER
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_OW_ORDER, "Psop Invoices Grid header ow order");
		compareStrings("OW Order #",
				getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_OW_ORDER, "Psop Invoices Grid header ow order"));
		// PSOP_INVOICES_GRID_HEADER_PRINT_DATE
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_PRINT_DATE, "Psop Invoices Grid header Print Date");
		compareStrings("Print Date",
				getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_PRINT_DATE, "Psop Invoices Grid header Print Date"));
		// PSOP_INVOICES_GRID_HEADER_INVOICE_DATE
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_INVOICE_DATE, "Psop Invoices Grid header Invoice Date");
		compareStrings("Invoice Date",
				getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_INVOICE_DATE, "Psop Invoices Grid header Invoice Date"));
		// PSOP_INVOICES_GRID_HEADER_INV_AMOUNT
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_INV_AMOUNT, "Psop Invoices Grid header Invoice Amount");
		compareStrings("Inv. Amount",
				getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_INV_AMOUNT, "Psop Invoices Grid header Invoice Amount"));
		// PSOP_INVOICES_GRID_HEADER_PSOP_COUNT
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_PSOP_COUNT, "Psop Invoices Grid header PSOP Count");
		compareStrings("PSOP Count",
				getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_PSOP_COUNT, "Psop Invoices Grid header PSOP count"));
		// PSOP_INVOICES_GRID_HEADER_ACTION
		assertElementPresent(driver,Entity.PSOP_INVOICES_GRID_HEADER_ACTION, "Psop Invoices Grid header Action");
		compareStrings("Action", getText(driver,Entity.PSOP_INVOICES_GRID_HEADER_ACTION, "Psop Invoices Grid header Action"));
		// PSOP_INVOICES_CURRENT_FILTER
		assertElementPresent(driver,Entity.PSOP_INVOICES_CURRENT_FILTER, "Psop Invoices Grid header current filter");
		compareStrings("Current filter:",
				getText(driver,Entity.PSOP_INVOICES_CURRENT_FILTER, "Psop Invoices Grid header current filter"));
		assertElementPresent(driver,Entity.FIRST_PAGE_LINK, "First Page Lnk");
		assertElementPresent(driver,Entity.PREVIOUS_PAGE_LINK, "Previous Page Lnk");
		assertElementPresent(driver,Entity.NEXT_PAGE_LINK, "Next Page Lnk");
		assertElementPresent(driver,Entity.LAST_PAGE_LINK, "Last Page Lnk");

	}

	public void psopInvoiceSearch(String reportSheet, int count) throws Throwable {

		try {

			String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
			String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
			String entityType = Excelobject.getCellData(reportSheet, "Entity Type", count);
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId, "Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			// PSOP_INVOICE_SEARCH_HEADER
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search header");
			compareStrings("Invoice Profile",
					getText(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Search header"));
			// INVOICE_ID
			assertElementPresent(driver,Invoice.INVOICE_ID, "Invoice id");
			compareStrings(invoiceId, getText(driver,Invoice.INVOICE_ID, "Invoice id").split("\\: ")[1]);
			// PSOP_INVOICE_SEARCH_CRITERIA
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
			compareStrings("PSOP Invoice Profile",
					getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title"));
			// GENERATE_DETAIL_REPORT_BUTTON
			assertElementPresent(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			isEnabled(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			// PRINT_BUTTON
			assertElementPresent(driver,Invoice.PRINT_BUTTON, "Print Button");
			isEnabled(driver,Invoice.PRINT_BUTTON, "Print Button");
			// INVOICE_DATA_LABEL
			waitForElementPresent(driver,Invoice.INVOICE_DATA_LABEL, "Invoice data label");
			assertElementPresent(driver,Invoice.INVOICE_DATA_LABEL, "Invoice data label");
			// INVOICE_DATA_TEXT
			assertElementPresent(driver,Invoice.INVOICE_DATA_TEXT, "Invoice data text");
			compareStrings(invoiceId, getText(driver,Invoice.INVOICE_DATA_TEXT, "Invoice data text"));
			// ENTITY_DATA_LABEL
			assertElementPresent(driver,Invoice.ENTITY_DATA_LABEL, "Entity data label");
			// ENTITY_LINK_TEXT
			compareStrings(entityName, getText(driver,Invoice.ENTITY_LINK_TEXT, "Entity link text"));
			// OW_ORDER_DATA_LABEL
			assertElementPresent(driver,Invoice.OW_ORDER_DATA_LABEL, "OW order data label");
			// INVOICE_STATUS_LABEL
			assertElementPresent(driver,Invoice.INVOICE_STATUS_LABEL, "Invoice status label");
			// RECIPIENT_LABEL
			assertElementPresent(driver,Invoice.RECIPIENT_LABEL, "Recipient label");
			// TITLE_LABEL
			assertElementPresent(driver,Invoice.TITLE_LABEL, "TITLE label");
			assertElementPresent(driver,Invoice.CUSTOMER_LABEL, "Customer label");
			assertElementPresent(driver,Invoice.ADDRESS_LABEL, "Address label");
			assertElementPresent(driver,Invoice.PHONE_LABEL, "Phone label");
			assertElementPresent(driver,Invoice.FAX_LABEL, "Fax label");
			assertElementPresent(driver,Invoice.PERIOD_COVERED_LABEL, "Period covered label");
			assertElementPresent(driver,Invoice.RENEWAL_MONTH_LABEL, "Renewal month label");
			assertElementPresent(driver,Invoice.INVOICE_SUMMARY_SECTION, "Invoice summary section");
			assertElementPresent(driver,Invoice.TOTAL_PAPER_SOP_LABEL, "Toatl Paper SOP label");
			assertElementPresent(driver,Invoice.PSOP_AMOUNT_LABEL, "Psop Amount label");
			assertElementPresent(driver,Invoice.OPEN_AMOUNT_LABEL, "Open amount label");
			assertElementPresent(driver,Invoice.PREVIOUS_INVOICE_LABEL, "Previous invoice label");
			assertElementPresent(driver,Invoice.PREVIOUS_BILLED_LABEL, "Previous billed label");
			assertElementPresent(driver,Invoice.INVOICE_CONTENT_SECTION, "Invoice Content section");
			assertElementPresent(driver,Invoice.EXPORT_BUTTON, "export button");
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "drop down under invoice content");
			assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Text Box for search");
			assertElementPresent(driver,Invoice.GO_BUTTON, "Go Button");
			isEnabled(driver,Invoice.GO_BUTTON, "Go Button");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL, "Sort By label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_ENTITY_NAME, "Entity name sort by label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_ENTITY_NUMBER, "Entity number sort by label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_JURIS, "Juris label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_SOP_COUNT, "SOP count label");
			if (entityType.equals("CTCORP")) {
				assertElementPresent(driver,Invoice.SORT_BY_LABEL_SUIT_TYPE, "Suit type label");
				assertElementPresent(driver,Invoice.SORT_BY_LABEL_SUIT_SUB_TYPE, "Suit Sub type label");
			}
			if (entityType.equals("NRAI")) {
				assertElementPresent(driver,Invoice.NRAI_DOC_TYPE_COLUMN_NAME, "NRAI Doc Type column");
			}
			assertElementPresent(driver,Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
			assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
			assertElementPresent(driver,Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
			assertElementPresent(driver,Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
			assertElementPresent(driver,Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
			assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
			assertElementPresent(driver,Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
			assertElementPresent(driver,Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
			assertElementPresent(driver,Invoice.BACK_BUTTON, "Back button");
			assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise button");
			assertElementPresent(driver,Invoice.RECIPIENT_NAME, "Recipient name");
			String recipientNamePSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_NAME, "Recipient name");
			assertElementPresent(driver,Invoice.PARTICIPANT_TITLE, "Participant title");
			String titlePSOPInvoiceProfile = getText(driver,Invoice.PARTICIPANT_TITLE, "Participant title");
			assertElementPresent(driver,Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			String recipientCustomerPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			assertElementPresent(driver,Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			String recipientAddressPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			assertElementPresent(driver,Invoice.RECIPIENT_EMAIL, "Recipient Email");
			String recipientEmailPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_EMAIL, "Recipient Email");
			assertElementPresent(driver,Invoice.RECIPIENT_PHONE, "Recipient Phone");
			String recipientPhonePSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_PHONE, "Recipient Phone");
			assertElementPresent(driver,Invoice.RECIPIENT_FAX, "Recipient Fax");
			String recipientFaxPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_FAX, "Recipient Fax");
			searchForTheEntity(reportSheet, count);
			// DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE
			assertElementPresent(driver,DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			click(driver,DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			// XSOP_RECIPIENT_NAME
			focus(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			assertElementPresent(driver,DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			String recipientNameXSOP = getText(driver,DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			// PARTICIPANT_TITLE
			assertElementPresent(driver,DI.PARTICIPANT_TITLE, "Participant title xsop");
			String titleXSOP = getText(driver,DI.PARTICIPANT_TITLE, "Participant title xsop");
			// RECIPIENT_CUSTOMER
			assertElementPresent(driver,DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			String recipientCustomerXSOP = getText(driver,DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			// RECIPIENT_ADDRESS
			assertElementPresent(driver,DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			String recipientAddressXSOP = getText(driver,DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			// RECIPIENT_EMAIL
			assertElementPresent(driver,DI.RECIPIENT_EMAIL, "Recepient email xsop");
			String recipientEmailXSOP = getText(driver,DI.RECIPIENT_EMAIL, "Recepient email xsop");
			// RECIPIENT_PHONE
			assertElementPresent(driver,DI.RECIPIENT_PHONE, "Recepient phone xsop");
			String recipientPhoneXSOP = getText(driver,DI.RECIPIENT_PHONE, "Recepient phone xsop");
			// RECIPIENT_FAX
			assertElementPresent(driver,DI.RECIPIENT_FAX, "Recepient fax xsop");
			String recipientFaxXSOP = getText(driver,DI.RECIPIENT_FAX, "Recepient fax xsop");
			compareStrings(recipientNamePSOPInvoiceProfile, recipientNameXSOP);
			compareStrings(titlePSOPInvoiceProfile, titleXSOP);
			compareStrings(recipientCustomerPSOPInvoiceProfile, recipientCustomerXSOP);
			compareStrings(recipientAddressPSOPInvoiceProfile, recipientAddressXSOP);
			compareStrings(recipientEmailPSOPInvoiceProfile, recipientEmailXSOP);
			compareStrings(recipientPhonePSOPInvoiceProfile, recipientPhoneXSOP);
			compareStrings(recipientFaxPSOPInvoiceProfile, recipientFaxXSOP);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void psopInvoiceSearchCriteriaFilter(String reportSheet, int count, String status) throws Throwable {

		String monthFrom = Excelobject.getCellData(reportSheet, "Month From", count);
		String monthTo = Excelobject.getCellData(reportSheet, "Month To", count);
		assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
		click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
		psopInvoiceSearchCriteriaUI();

		if (status.equalsIgnoreCase("Open")) {
			selectByVisibleText(driver,Invoice.INVOICE_STATUS_VALUE, status, "Invoice drop down");
		} else if (status.equalsIgnoreCase("Closed")) {
			selectByVisibleText(driver,Invoice.INVOICE_STATUS_VALUE, status, "Invoice drop down");
		}
		// FROM_LABEL_CALENDAR_ICON
		click(driver,Invoice.FROM_LABEL_CALENDAR_ICON, "From calendar icon in Psop search criteria page");
		// MONTH_TITLE
		assertElementPresent(driver,Invoice.MONTH_TITLE, "Month title in Psop search criteria page");
		String fromMonth = getText(driver,Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		while (!fromMonth.equalsIgnoreCase(monthFrom)) {
			// GO_BACK_IN_MONTH
			click(driver,Invoice.GO_BACK_IN_MONTH, "back < icon");
			fromMonth = getText(driver,Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		}
		//
		waitForElementPresent(driver,Invoice.TO_LABEL_CALENDAR_ICON, "To Calendar icon");
		click(driver,Invoice.TO_LABEL_CALENDAR_ICON, "To Calendar icon");
		assertElementPresent(driver,Invoice.MONTH_TITLE, "Month title in Psop search criteria page");
		String toMonth = getText(driver,Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		while (!toMonth.equalsIgnoreCase(monthTo)) {
			// GO_BACK_IN_MONTH
			click(driver,Invoice.GO_FORWARD_IN_MONTH, "forward > icon");
			toMonth = getText(driver,Invoice.MONTH_TITLE, "Month title in Psop search criteria page").split(",")[0];
		}
		// SEARCH_BUTTON
		assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in Psop search criteria page");
		click(driver,Invoice.SEARCH_BUTTON, "Search button in Psop search criteria page");
	}

	public void psopInvoiceSearchResults(String reportSheet, int count) throws Throwable {
		// PSOP_INVOICE_SEARCH_HEADER
		assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "Header Psop search results");
		compareStrings("PSOP Invoice Search", getText(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "Page Title"));
		// PSOP_INVOICE_RESULTS_EXPORT_BUTTON
		assertElementPresent(driver,Invoice.PSOP_INVOICE_RESULTS_EXPORT_BUTTON, "export button Psop search results");
		assertElementPresent(driver,Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
		compareStrings("PSOP Invoice Search Results",
				getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search"));
		String parentWindow = driver.getWindowHandle();
		isEnabled(driver,Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		click(driver,Entity.PSOP_INVOICES_HELP_ICON, "Psop Invoices help icon");
		handlePopUpWindwow(driver);
		driver.close();
		driver.switchTo().window(parentWindow);
		assertElementPresent(driver,Entity.GO_BTN, "Psop Invoices Go Button");
		isEnabled(driver,Entity.GO_BTN, "Psop Invoices Go Button");
		// PSOP_INVOICES_SORT_BY
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY, "Psop Invoices Sort by");
		// PSOP_INVOICES_SORT_BY_INDEX
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_INDEX, "Psop Invoices Sort by index");
		// PSOP_INVOICES_SORT_BY_OW_ORDER
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_OW_ORDER, "Psop Invoices Sort by order");
		// PSOP_INVOICES_SORT_BY_PRINT_DATE
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_PRINT_DATE, "Psop Invoices Sort by print date");
		// PSOP_INVOICES_SORT_BY_INVOICE_DATE
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice date");
		// PSOP_INVOICES_SORT_BY_INVOICE_AMOUNT
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_INVOICE_DATE, "Psop Invoices Sort by invoice amount");
		// PSOP_INVOICES_SORT_BY_OPEN_AMOUNT
		assertElementPresent(driver,Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		isEnabled(driver,Entity.PSOP_INVOICES_SORT_BY_OPEN_AMOUNT, "Psop Invoices Sort by open amount");
		// DROP_DOWN_INVOICE_CONTENT
		assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop down option");
		// TEXT_BOX_IN_RHS
		assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Text box in RHS");
		assertElementPresent(driver,Invoice.OW_ORDER_DATA_HEADER, "OW order column in data grid");
		assertElementPresent(driver,Invoice.PRINT_DATE_DATA_HEADER, "Print date in data heade");
		assertElementPresent(driver,Invoice.INVOICE_DATE_DATA_HEADER, "Invoice date in data header");
		assertElementPresent(driver,Invoice.INV_AMOUNT_DATA_HEADER, "Invoice Amount in data header");
		assertElementPresent(driver,Invoice.PSOP_COUNT_DATA_HEADER, "Psop count in data header");
		assertElementPresent(driver,Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
		assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
		assertElementPresent(driver,Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
		assertElementPresent(driver,Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
		assertElementPresent(driver,Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
		assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
		assertElementPresent(driver,Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
		assertElementPresent(driver,Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
		assertElementPresent(driver,Invoice.SEARCH_AGAIN, "Search Again button");
		// assertElementPresent(driver,Invoice.,"");
	}

	public void psopInvoiceRevisionPage(String reportSheet, int count) throws Throwable {

		String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
		// String entityName = Excelobject.getCellData(reportSheet, "Entity Name",
		// count);
		assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
		click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
		assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
		click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
		// SEARCH_TEXT_UNDER_SEARCH_BY
		assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, "Search text");
		type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId, "Search text");
		// SEARCH_BUTTON
		assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button");
		click(driver,Invoice.SEARCH_BUTTON, "Search button");
		// REVISE_BUTTON
		assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise button");
		click(driver,Invoice.REVISE_BUTTON, "Revise button");
		// PSOP_INVOICE_SEARCH_HEADER
		assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "Psop Invoice Revision");
		compareStrings("PSOP Invoice Revision", getText(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "Psop Invoice Revision"));
		// PSOP_INVOICE_SEARCH_CRITERIA
		assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Psop Invoice Revision");
		compareStrings("PSOP Invoice Revision", getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Psop Invoice Revision"));
		// INVOICE_BELOW_PSOP_INVOICE_REVISION
		assertElementPresent(driver,Invoice.INVOICE_BELOW_PSOP_INVOICE_REVISION, "Invoice # : label");
		// OW_ORDER_DATA_LABEL
		assertElementPresent(driver,Invoice.OW_ORDER_DATA_LABEL, "OW Order # : label");
		// INVOICE_STATUS_LABEL
		assertElementPresent(driver,Invoice.INVOICE_STATUS_LABEL, "Invoice status label");
		// ENTITY_DATA_LABEL
		assertElementPresent(driver,Invoice.ENTITY_DATA_LABEL, "Entity data Label");
		// RECIPIENT_LABEL
		assertElementPresent(driver,Invoice.RECIPIENT_LABEL, "Recipient Label");
		assertElementPresent(driver,Invoice.TITLE_LABEL, "TITLE label");
		assertElementPresent(driver,Invoice.CUSTOMER_LABEL, "Customer label");
		assertElementPresent(driver,Invoice.ADDRESS_LABEL, "Address label");
		assertElementPresent(driver,Invoice.PHONE_LABEL, "Phone label");
		assertElementPresent(driver,Invoice.FAX_LABEL, "Fax label");
		assertElementPresent(driver,Invoice.PERIOD_COVERED_LABEL, "Period covered label");
		assertElementPresent(driver,Invoice.RENEWAL_MONTH_LABEL, "Renewal month label");
		assertElementPresent(driver,Invoice.INVOICE_SUMMARY_SECTION, "Invoice summary section");
		assertElementPresent(driver,Invoice.TOTAL_PAPER_SOP_LABEL, "Toatl Paper SOP label");
		assertElementPresent(driver,Invoice.PSOP_AMOUNT_LABEL, "Psop Amount label");
		assertElementPresent(driver,Invoice.OPEN_AMOUNT_LABEL, "Open amount label");
		assertElementPresent(driver,Invoice.PREVIOUS_INVOICE_LABEL, "Previous invoice label");
		assertElementPresent(driver,Invoice.PREVIOUS_BILLED_LABEL, "Previous billed label");
		assertElementPresent(driver,Invoice.INVOICE_CONTENT_SECTION, "Invoice Content section");
		assertElementPresent(driver,Invoice.EXPORT_BUTTON, "export button");
		assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "drop down under invoice content");
		assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Text Box for search");
		assertElementPresent(driver,Invoice.GO_BUTTON, "Go Button");
		isEnabled(driver,Invoice.GO_BUTTON, "Go Button");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL, "Sort By label");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL_ENTITY_NAME, "Entity name sort by label");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL_ENTITY_NUMBER, "Entity number sort by label");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL_JURIS, "Juris label");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL_SOP_COUNT, "SOP count label");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL_SUIT_TYPE, "Suit type label");
		assertElementPresent(driver,Invoice.SORT_BY_LABEL_SUIT_SUB_TYPE, "Suit Sub type label");
		assertElementPresent(driver,Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
		assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
		assertElementPresent(driver,Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
		assertElementPresent(driver,Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
		assertElementPresent(driver,Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
		assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
		assertElementPresent(driver,Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
		assertElementPresent(driver,Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
		focus(Invoice.BACK_BUTTON_REVISION_PAGE, "Back button");
		assertElementPresent(driver,Invoice.BACK_BUTTON_REVISION_PAGE, "Back button");
		assertElementPresent(driver,Invoice.SUBMIT_BUTTON, "Submit button");
		assertElementPresent(driver,Invoice.ENTITY_NAME_GRID_HEADER, "Entity name label in grid");
		assertElementPresent(driver,Invoice.ENTITY_NUMBER_GRID_HEADER, "Entity # label in grid");
		assertElementPresent(driver,Invoice.ENTITY_STATUS_GRID_HEADER, "Entity status label in grid");
		assertElementPresent(driver,Invoice.JURIS_GRID_HEADER, "Juris label in grid");
		assertElementPresent(driver,Invoice.SUIT_TYPE_GRID_HEADER, "Suit Type label in grid");
		assertElementPresent(driver,Invoice.SUIT_SUB_TYPE_GRID_HEADER, "Sub Suit Type label in grid");
		assertElementPresent(driver,Invoice.PSOP_COUNT_GRID_HEADER, "PSOP count label in grid");
		assertElementPresent(driver,Invoice.REMOVE_CREDIT_DATA_HEADER, "Remove/Credit label in grid");
		assertElementPresent(driver,Invoice.SELECT_ALL_BUTTON, "Select All Button");
		assertElementPresent(driver,Invoice.SELECT_NONE_BUTTON, "Select none button");
		assertElementPresent(driver,Invoice.INVOICE_DELIVERY_OPTIONS_SECTION, "invoice delivery options section");
		assertElementPresent(driver,Invoice.DELIVERY_METHOD_LABEL, "Delivery method label");
		assertElementPresent(driver,Invoice.REVISION_REASON_LABEL, "Revision Reason label");
		assertElementPresent(driver,Invoice.DELIVERY_METHOD_DROP_DOWN, "Delivery method drop down");
		assertElementPresent(driver,Invoice.REVISION_REASON_DROP_DOWN, "Revision Reason drop down");
	}

	public void enableThePS() throws Throwable {
		waitForElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		assertElementPresent(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		assertElementPresent(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
		focus(Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		String billingStatus = getText(driver,Entity.PAPER_SURCHARGE_BILLING, "Paper surcharge billing status");
		if (billingStatus.equals("Disabled")) {
			click(driver,Entity.MAINTAIN_PAPER_SURCHAGE_BILLING, "Maintain Paper surcharge Billing button");
			click(driver,Entity.PAPER_SURCHARGE_BILLING_ENABLE, "Paper surchage billing enable radio button");
			assertElementPresent(driver,Entity.SAVE_BTN, "Save button");
			click(driver,Entity.SAVE_BTN, "Save button");
		}
	}

	public void psopInvoiceSearchByCustomer(String reportSheet, int count) throws Throwable {

		try {

			String customerId = Excelobject.getCellData(reportSheet, "Customer Id", count);
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			assertElementPresent(driver,Invoice.CUSTOMER_RADIO_BUTTON,
					"Customer radio button in PSOP Invoice Search Criteria page");
			click(driver,Invoice.CUSTOMER_RADIO_BUTTON, "click on Customer radio button in PSOP Invoice Search Criteria page");
			type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, customerId,
					"Search text box in PSop Invoice Search Criteria page");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Results page Title");
			compareStrings("PSOP Invoice Search Results", getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
					"Get text of PSOP Invoice Search Results page Title"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchByAndSearchCriteriaFiltersApplied(String searchBy, String reportSheet, int count)
			throws Throwable {

		try {

			String customerId = Excelobject.getCellData(reportSheet, "Customer Id", count);
			String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
			String serviceCenter = Excelobject.getCellData(reportSheet, "Service Center", count);
			String serviceTeam = Excelobject.getCellData(reportSheet, "Service Team", count);
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");

			// CUSTOMER_RADIO_BUTTON
			if (searchBy.equals("Customer")) {
				assertElementPresent(driver,Invoice.CUSTOMER_RADIO_BUTTON,
						"Customer radio button in PSOP Invoice Search Criteria page");
				click(driver,Invoice.CUSTOMER_RADIO_BUTTON,
						"click on Customer radio button in PSOP Invoice Search Criteria page");
				type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, customerId,
						"Search text box in PSop Invoice Search Criteria page");
			}
			// INVOICE_RADIO_BUTTON
			else if (searchBy.equals("Invoice")) {
				type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId,
						"Search text box in PSop Invoice Search Criteria page");
			}
			// SERVICE_CENTER_DROP_DOWN_VALUES
			assertElementPresent(driver,Invoice.SERVICE_CENTER_DROP_DOWN_VALUES,
					"Service Center drop down in PSOP Invoice Search Criteria page");
			selectByVisibleText(driver,Invoice.SERVICE_CENTER_DROP_DOWN_VALUES, serviceCenter,
					"Service Center drop down in PSOP Invoice Search Criteria page");
			// SERVICE_TEAM_DROP_DOWN_VALUES
			assertElementPresent(driver,Invoice.SERVICE_TEAM_DROP_DOWN_VALUES,
					"Service team drop down in PSOP Invoice Search Criteria page");
			selectByVisibleText(driver,Invoice.SERVICE_TEAM_DROP_DOWN_VALUES, serviceTeam,
					"Service team drop down in PSOP Invoice Search Criteria page");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSop Invoice Search Criteria page");
			// PSOP_INVOICE_SEARCH_CRITERIA
			if (searchBy.contentEquals("Customer")) {
				assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Search Results page Title");
				compareStrings("PSOP Invoice Search Results", getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
						"Get text of PSOP Invoice Search Results page Title"));
			} else if (searchBy.contentEquals("Invoice")) {
				assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
				compareStrings("PSOP Invoice Profile",
						getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void countTotalPaperSOP(String reportSheet, int count) {
		try {
			int totalPsopCount = 0;
			String invoiceId = Excelobject.getCellData(reportSheet, "Invoice Id", count);
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, invoiceId, "Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");

			assertElementPresent(driver,Invoice.TOTAL_PAPER_SOP_COUNT, "PSOP count in PSOP Invoice Profile page");
			// Invoice.PSOP_COUNT
			assertElementPresent(driver,Invoice.PSOP_COUNT, "PSOP count in PSOP Invoice Profile page under data grid");
			List<String> texts = getListText(driver,Invoice.PSOP_COUNT,
					"PSOP count in PSOP Invoice Profile page under data grid");
			for (int i = 0; i < texts.size(); i++) {
				totalPsopCount = totalPsopCount + Integer.parseInt(texts.get(i));
			}
			// TOTAL_PAPER_SOP_COUNT
			assertElementPresent(driver,Invoice.TOTAL_PAPER_SOP_COUNT, "Total paper SOP count in PSOP Invoice Profile page");
			compareStrings(String.valueOf(totalPsopCount),
					getText(driver,Invoice.TOTAL_PAPER_SOP_COUNT, "Total paper SOP count in PSOP Invoice Profile page"));
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void searchForOWNumber(String reportSheet, int count) {

		try {
			String owOrder = Excelobject.getCellData(reportSheet, "OW Order", count);
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop down in PSOP Invoice List page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "OW Order #",
					"Search text in PSOP Invoice List page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(driver,Invoice.DROP_DOWN_FISRT_OP, "First op drop down in PSOP Invoice List page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_FISRT_OP, "=", "Search text in PSOP Invoice List page");

			type(driver,Invoice.TEXT_BOX_IN_RHS, owOrder, "Search text box in PSop Invoice list page");
			// GO_BUTTON
			assertElementPresent(driver,Invoice.GO_BUTTON, " in PSOP Invoice List page");
			click(driver,Invoice.GO_BUTTON, " in PSOP Invoice List page");
			// GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST
			assertElementPresent(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST,
					"Generate detail Report button in PSOP Invoice List Page");
			// isEnabled(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON_PSOP_LIST,"Generate detail
			// Report button in PSOP Invoice List Page");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void invoiceProfileFromInvoiceList(String reportSheet, int count) {

		try {
			// INVOICE_PROFILING_LINK_PSOP_LIST
			assertElementPresent(driver,Invoice.INVOICE_PROFILING_LINK_PSOP_LIST, "Invoice profiling link");
			click(driver,Invoice.INVOICE_PROFILING_LINK_PSOP_LIST, "Invoice profiling link");
			// GENERATE_DETAIL_REPORT_BUTTON
			assertElementPresent(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON,
					"Generate detail report button in PSOP Invoice Profile");
			isEnabled(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate detail report button in PSOP Invoice Profile");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void verifyPSOPInvoicesLinkFunctionality(String reportSheet, int count, String testcase) throws Throwable {
		try {
			String affName = Excelobject.getCellData(reportSheet, "Affiliation Name", count);
			String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
			String agentType = Excelobject.getCellData(reportSheet, "Branch Plant", count);

			if (testcase.equalsIgnoreCase("Entity")) {
				// Search for the entity
				searchForTheEntity(reportSheet, count);
			} else if (testcase.equalsIgnoreCase("Affiliation")) {
				// Search for an affiliation
				searchForTheAffiliation(reportSheet, count);
			}
			// PSOP Invoice List for the entity/affiliation
			if (affName.isEmpty()) {
				psopInvoicesList(reportSheet, count, "Standalone Entity");
			} else {
				psopInvoicesList(reportSheet, count, "Affiliated Entity");
			}

			// Search for the OW number
			searchForOWNumber(reportSheet, count);
			// To Invoice Profile page
			invoiceProfileFromInvoiceList(reportSheet, count);
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER,
					"PSOP Invoice header is present in PSOP Invoice Profile page");
			String text = getText(driver,Invoice.AGENT_NAME, "Entity Agent Type");
			// Verify Agent Type is correct
			assertTextContains(agentType, text);
			// verify invoice profile and SOP count
			// INVOICE_ID
			assertElementPresent(driver,Invoice.INVOICE_ID, "Invoice id");
			// PSOP_INVOICE_SEARCH_CRITERIA
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title");
			compareStrings("PSOP Invoice Profile",
					getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "PSOP Invoice Page Title"));
			// GENERATE_DETAIL_REPORT_BUTTON
			assertElementPresent(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			isEnabled(driver,Invoice.GENERATE_DETAIL_REPORT_BUTTON, "Generate Detail Report Button");
			// PRINT_BUTTON
			assertElementPresent(driver,Invoice.PRINT_BUTTON, "Print Button");
			isEnabled(driver,Invoice.PRINT_BUTTON, "Print Button");
			// INVOICE_DATA_TEXT
			assertElementPresent(driver,Invoice.INVOICE_DATA_TEXT, "Invoice data text");
			if (affName.isEmpty()) {
				// INVOICE_DATA_LABEL
				assertElementPresent(driver,Invoice.INVOICE_DATA_LABEL, "Invoice data label");
				// ENTITY LINK
				compareStrings(entityName, getText(driver,Invoice.ENTITY_LINK_TEXT, "Entity link text"));
			} else {
				// INVOICE_DATA_LABEL
				assertElementPresent(driver,Invoice.INVOICE_DATA_LABEL_AFFI, "Invoice data label");
				// AFFILIATION_LINK_TEXT
				compareStrings(affName, getText(driver,Invoice.AFFILIATION_LINK_TEXT, "Affiliation link text"));
			}
			// OW_ORDER_DATA_LABEL
			assertElementPresent(driver,Invoice.OW_ORDER_DATA_LABEL, "OW order data label");
			// INVOICE_STATUS_LABEL
			assertElementPresent(driver,Invoice.INVOICE_STATUS_LABEL, "Invoice status label");
			// RECIPIENT_LABEL
			assertElementPresent(driver,Invoice.RECIPIENT_LABEL, "Recipient label");
			// TITLE_LABEL
			assertElementPresent(driver,Invoice.TITLE_LABEL, "TITLE label");
			assertElementPresent(driver,Invoice.CUSTOMER_LABEL, "Customer label");
			assertElementPresent(driver,Invoice.ADDRESS_LABEL, "Address label");
			assertElementPresent(driver,Invoice.PHONE_LABEL, "Phone label");
			assertElementPresent(driver,Invoice.FAX_LABEL, "Fax label");
			assertElementPresent(driver,Invoice.PERIOD_COVERED_LABEL, "Period covered label");
			assertElementPresent(driver,Invoice.RENEWAL_MONTH_LABEL, "Renewal month label");
			assertElementPresent(driver,Invoice.INVOICE_SUMMARY_SECTION, "Invoice summary section");
			assertElementPresent(driver,Invoice.TOTAL_PAPER_SOP_LABEL, "Toatl Paper SOP label");
			assertElementPresent(driver,Invoice.PSOP_AMOUNT_LABEL, "Psop Amount label");
			assertElementPresent(driver,Invoice.OPEN_AMOUNT_LABEL, "Open amount label");
			assertElementPresent(driver,Invoice.PREVIOUS_INVOICE_LABEL, "Previous invoice label");
			assertElementPresent(driver,Invoice.PREVIOUS_BILLED_LABEL, "Previous billed label");
			assertElementPresent(driver,Invoice.INVOICE_CONTENT_SECTION, "Invoice Content section");
			assertElementPresent(driver,Invoice.EXPORT_BUTTON, "export button");
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "drop down under invoice content");
			assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Text Box for search");
			assertElementPresent(driver,Invoice.GO_BUTTON, "Go Button");
			isEnabled(driver,Invoice.GO_BUTTON, "Go Button");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL, "Sort By label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_ENTITY_NAME, "Entity name sort by label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_ENTITY_NUMBER, "Entity number sort by label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_JURIS, "Juris label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_SOP_COUNT, "SOP count label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_SUIT_TYPE, "Suit type label");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL_SUIT_SUB_TYPE, "Suit Sub type label");
			assertElementPresent(driver,Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First navigation link above grid");
			assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous navigation link above grid");
			assertElementPresent(driver,Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next navigation link above grid");
			assertElementPresent(driver,Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last navigation link above grid");
			assertElementPresent(driver,Invoice.FIRST_NAVIGATION_BELOW_GRID, "First navigation link below grid");
			assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_BELOW_GRID, "Previous navigation link below grid");
			assertElementPresent(driver,Invoice.NEXT_NAVIGATION_BELOW_GRID, "Next navigation link below grid");
			assertElementPresent(driver,Invoice.LAST_NAVIGATION_BELOW_GRID, "Last navigation link below grid");
			assertElementPresent(driver,Invoice.BACK_BUTTON, "Back button");
			assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise button");
			assertElementPresent(driver,Invoice.RECIPIENT_NAME, "Recipient name");
			String recipientNamePSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_NAME, "Recipient name");
			assertElementPresent(driver,Invoice.PARTICIPANT_TITLE, "Participant title");
			String titlePSOPInvoiceProfile = getText(driver,Invoice.PARTICIPANT_TITLE, "Participant title");
			assertElementPresent(driver,Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			String recipientCustomerPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_CUSTOMER, "Recipient customer");
			assertElementPresent(driver,Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			String recipientAddressPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_ADDRESS, "Recipient Address");
			assertElementPresent(driver,Invoice.RECIPIENT_EMAIL, "Recipient Email");
			String recipientEmailPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_EMAIL, "Recipient Email");
			assertElementPresent(driver,Invoice.RECIPIENT_PHONE, "Recipient Phone");
			String recipientPhonePSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_PHONE, "Recipient Phone");
			assertElementPresent(driver,Invoice.RECIPIENT_FAX, "Recipient Fax");
			String recipientFaxPSOPInvoiceProfile = getText(driver,Invoice.RECIPIENT_FAX, "Recipient Fax");
			searchForTheEntity(reportSheet, count);
			// DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE
			assertElementPresent(driver,DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			click(driver,DI.DELIVERY_INSTRUCTION_LINK_ENTITY_PROFILE, "Delivery instruction link");
			// XSOP_RECIPIENT_NAME
			focus(DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			assertElementPresent(driver,DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			String recipientNameXSOP = getText(driver,DI.XSOP_RECIPIENT_NAME, "Participant name xsop");
			// PARTICIPANT_TITLE
			assertElementPresent(driver,DI.PARTICIPANT_TITLE, "Participant title xsop");
			String titleXSOP = getText(driver,DI.PARTICIPANT_TITLE, "Participant title xsop");
			// RECIPIENT_CUSTOMER
			assertElementPresent(driver,DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			String recipientCustomerXSOP = getText(driver,DI.RECIPIENT_CUSTOMER, "Recepient customer xsop");
			// RECIPIENT_ADDRESS
			assertElementPresent(driver,DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			String recipientAddressXSOP = getText(driver,DI.RECIPIENT_ADDRESS, "Recepient address xsop");
			// RECIPIENT_EMAIL
			assertElementPresent(driver,DI.RECIPIENT_EMAIL, "Recepient email xsop");
			String recipientEmailXSOP = getText(driver,DI.RECIPIENT_EMAIL, "Recepient email xsop");
			// RECIPIENT_PHONE
			assertElementPresent(driver,DI.RECIPIENT_PHONE, "Recepient phone xsop");
			String recipientPhoneXSOP = getText(driver,DI.RECIPIENT_PHONE, "Recepient phone xsop");
			// RECIPIENT_FAX
			assertElementPresent(driver,DI.RECIPIENT_FAX, "Recepient fax xsop");
			String recipientFaxXSOP = getText(driver,DI.RECIPIENT_FAX, "Recepient fax xsop");
			compareStrings(recipientNamePSOPInvoiceProfile, recipientNameXSOP);
			compareStrings(titlePSOPInvoiceProfile, titleXSOP);
			compareStrings(recipientCustomerPSOPInvoiceProfile, recipientCustomerXSOP);
			compareStrings(recipientAddressPSOPInvoiceProfile, recipientAddressXSOP);
			compareStrings(recipientEmailPSOPInvoiceProfile, recipientEmailXSOP);
			compareStrings(recipientPhonePSOPInvoiceProfile, recipientPhoneXSOP);
			compareStrings(recipientFaxPSOPInvoiceProfile, recipientFaxXSOP);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyReviseButtonFunctionality(String reportSheet, int count) throws Throwable {
		String entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
		try {
			searchForTheEntity(reportSheet, count);
			psopInvoicesList(reportSheet, count, "Affiliated Entity");

			// Search for the OW number
			searchForOWNumber(reportSheet, count);

			// To Invoice Profile page
			invoiceProfileFromInvoiceList(reportSheet, count);
			// To PSOP Invoice Revision Page
			click(driver,Invoice.REVISE_BUTTON, "Revise Button");
			// Verify the PSOP Invoice Revision title
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_HEADER, "PSOP Invoice Revision Page");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void editThePSOPPermissionToRole(String reportSheet, int count) {

		try {
			String roleName = Excelobject.getCellData(reportSheet, "Role", count);
			// ADMIN_TAB
			assertElementPresent(driver,Admin.ADMIN_TAB, "Admin Tab in the header");
			click(driver,Admin.ADMIN_TAB, "Admin Tab in the header");
			// FIRST_FILTER_DRPDWN
			assertElementPresent(driver,Admin.FIRST_FILTER_DRPDWN, "Filter drop down in Role Page");
			selectByVisibleText(driver,Admin.FIRST_FILTER_DRPDWN, "Role Name", "Filter Dropdown 1");
			// SECOND_FILTER_DRPDWN
			assertElementPresent(driver,Admin.SECOND_FILTER_DRPDWN, "Filter drop down in Role Page");
			selectByVisibleText(driver,Admin.SECOND_FILTER_DRPDWN, "equals", "Filter Dropdown 2");
			// FILTER_TEXT_FILED
			assertElementPresent(driver,Admin.FILTER_TEXT_FILED, "Filter text feild in Role Page");
			selectBySendkeys(driver,Admin.FILTER_TEXT_FILED, roleName, "Filter text feild in Role Page");
			// GO_BTN
			assertElementPresent(driver,Admin.GO_BTN, "GO Button in the Role Page");
			click(driver,Admin.GO_BTN, "GO Button in the Role Page");
			// FIRST_ROLE_ON_THE_GRID
			assertElementPresent(driver,Admin.FIRST_ROLE_ON_THE_GRID, "Role Name in the Role Page");
			click(driver,Admin.FIRST_ROLE_ON_THE_GRID, "Role Name in the Role Page");
			// EDIT_BTN
			assertElementPresent(driver,Admin.EDIT_BTN, "Edit Button in the Role Page");
			click(driver,Admin.EDIT_BTN, "Edit Button in the Role Page");
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}

	public void removeThePSOPPermissionFromRole(String reportSheet, int count) {
		editThePSOPPermissionToRole(reportSheet, count);
		try {
			// PSOP_PERMISSION_SECTION
			assertElementPresent(driver,Admin.PSOP_PERMISSION_SECTION, "Edit Button in the Edit Role Page");
			// PSOP_BILLING_CHECK_BOX
			assertElementPresent(driver,Admin.PSOP_BILLING_CHECK_BOX, "PSOP Billing check box in the Edit Role Page");
			String psopBillingAttribute = getAttribute(driver,Admin.PSOP_BILLING_CHECK_BOX, "checked");
			// System.out.println("jdbcjwbbkljfhfhfhfj "+ psopBillingAttribute);
			if (psopBillingAttribute != null) {
				click(driver,Admin.PSOP_BILLING_CHECK_BOX, "Maintain Paper Surcharge billing button is unchecked");
			}
			// PSOP_REVISION_CHECK_BOX
			assertElementPresent(driver,Admin.PSOP_REVISION_CHECK_BOX, "PSOP Revision check box in the Edit Role Page");
			String psopRevisionAttribute = getAttribute(driver,Admin.PSOP_REVISION_CHECK_BOX, "checked");
			// System.out.println("jdbcjwbbkljfhfhfhfj "+ psopRevisionAttribute);
			if (psopRevisionAttribute != null) {
				click(driver,Admin.PSOP_REVISION_CHECK_BOX, "PSOP revision checkbox button is unchecked");
			}
			// SAVEBTN
			assertElementPresent(driver,Admin.SAVEBTN, "Save Button in the Edit Role Page");
			click(driver,Admin.SAVEBTN, "Save Button in the Edit Role Page");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addThePSOPPermissionToRole(String reportSheet, int count) {
		editThePSOPPermissionToRole(reportSheet, count);
		try {
			// PSOP_PERMISSION_SECTION
			assertElementPresent(driver,Admin.PSOP_PERMISSION_SECTION, "Edit Button in the Edit Role Page");
			// PSOP_BILLING_CHECK_BOX
			assertElementPresent(driver,Admin.PSOP_BILLING_CHECK_BOX, "PSOP Billing check box in the Edit Role Page");
			String psopBillingAttribute = getAttribute(driver,Admin.PSOP_BILLING_CHECK_BOX, "checked");
			if (psopBillingAttribute == null) {
				click(driver,Admin.PSOP_BILLING_CHECK_BOX, "Maintain Paper Surcharge billing button is unchecked");
			}
			// PSOP_REVISION_CHECK_BOX
			assertElementPresent(driver,Admin.PSOP_REVISION_CHECK_BOX, "PSOP Revision check box in the Edit Role Page");
			String psopRevisionAttribute = getAttribute(driver,Admin.PSOP_REVISION_CHECK_BOX, "checked");
			if (psopRevisionAttribute == null) {
				click(driver,Admin.PSOP_REVISION_CHECK_BOX, "PSOP revision checkbox button is unchecked");
			}
			// SAVEBTN
			assertElementPresent(driver,Admin.SAVEBTN, "Save Button in the Edit Role Page");
			click(driver,Admin.SAVEBTN, "Save Button in the Edit Role Page");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getTheEntityIDForTheInvoicePeriod(String reportSheet, int count) {
		String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
		ArrayList<String> resultEntity = new ArrayList<String>();
		if (invoicePeriod.equals("less than 2 years older")) {
			try {
				resultEntity = SQL_Queries.getEntityIDForLessThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else if (invoicePeriod.equals("older than 2 years")) {
			try {
				resultEntity = SQL_Queries.getEntityIDForMoreThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		return resultEntity.get(0);
	}

	public String getTheOrderNumberForTheInvoicePeriod(String reportSheet, int count) {
		String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
		ArrayList<String> resultOrder = new ArrayList<String>();
		if (invoicePeriod.equals("less than 2 years older")) {
			try {
				resultOrder = SQL_Queries.getOrderNumberForLessThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else if (invoicePeriod.equals("older than 2 years")) {
			try {
				resultOrder = SQL_Queries.getOrderNumberForMoreThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		return resultOrder.get(0);
	}

	public String getTheInvoiceNumberForTheInvoicePeriod(String reportSheet, int count) {
		String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
		ArrayList<String> resultInvoice = new ArrayList<String>();
		if (invoicePeriod.equals("less than 2 years older")) {
			try {
				resultInvoice = SQL_Queries.getInvoiceIDForLessThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else if (invoicePeriod.equals("older than 2 years")) {
			try {
				resultInvoice = SQL_Queries.getInvoiceIDForMoreThanTwoYearsOlderInvoice();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		return resultInvoice.get(0);
	}

	public void searchForTheInvoiceFromPSOPInvoiceSearch(String reportSheet, int count) {
		try {

			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, getTheInvoiceNumberForTheInvoicePeriod(reportSheet, count),
					"Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void selectInvoiceFromTheInvoiceList(String reportSheet, int count) {
		try {
			waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
			click(driver,HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
			type(driver,Entity.ENTITY_ID, getTheEntityIDForTheInvoicePeriod(reportSheet, count), "Entity Id text box");
			assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(driver,Entity.SEARCH_BTN, "Search Button");
			// PSOP_INVOICES_LEFT_NAV_BAR
			waitForElementPresent(driver,Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link in Entity Profile page");
			assertElementPresent(driver,Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link in Entity Profile Page");
			click(driver,Entity.PSOP_INVOICES_LEFT_NAV_BAR, "Psop Invoices link");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop down in PSOP Invoice List page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "OW Order #",
					"Search text in PSOP Invoice List page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(driver,Invoice.DROP_DOWN_FISRT_OP, "First op drop down in PSOP Invoice List page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_FISRT_OP, "=", "Search text in PSOP Invoice List page");
			type(driver,Invoice.TEXT_BOX_IN_RHS, getTheOrderNumberForTheInvoicePeriod(reportSheet, count),
					"Search text box in PSop Invoice list page");
			// GO_BUTTON
			assertElementPresent(driver,Invoice.GO_BUTTON, " in PSOP Invoice List page");
			click(driver,Invoice.GO_BUTTON, " in PSOP Invoice List page");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopRevisionPermissionFromInvoiceProfile(String reportSheet, int count, String permissionStatus) {
		try {
			String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
			String privilegeError = Excelobject.getCellData(reportSheet, "Privilege Error", count);
			Thread.sleep(3000);
			if (invoicePeriod.equals("less than 2 years older")) {
				// REVISE_BUTTON_IN_PSOP_INVOICES
				assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
				click(driver,Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
				assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
				compareStrings("PSOP Invoice Revision",
						getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
			} else if (invoicePeriod.equals("older than 2 years")) {

				if (permissionStatus.equals("Permitted")) {
					assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					click(driver,Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
					compareStrings("PSOP Invoice Revision",
							getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
				} else if (permissionStatus.equals("Not Permitted")) {
					assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					click(driver,Invoice.REVISE_BUTTON, "Revise Button in PSOP Invoice Profile Page");
					// ERROR_PSOP_PERMISSION
					waitForVisibilityOfElementWithoutReport(driver,Invoice.ERROR_PSOP_PERMISSION,
							"Error description in PSOP Error page");
					assertElementPresent(driver,Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page");
					compareStrings(privilegeError,
							getText(driver,Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page"));
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopRevisionPermissionFromInvoiceList(String reportSheet, int count, String permissionStatus) {
		try {

			String invoicePeriod = Excelobject.getCellData(reportSheet, "Invoice Period", count);
			String privilegeError = Excelobject.getCellData(reportSheet, "Privilege Error", count);
			Thread.sleep(3000);
			if (invoicePeriod.equals("less than 2 years older")) {
				// REVISE_BUTTON_IN_PSOP_INVOICES
				assertElementPresent(driver,Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
				click(driver,Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
				// PSOP_INVOICE_SEARCH_CRITERIA
				assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
				compareStrings("PSOP Invoice Revision",
						getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
			} else if (invoicePeriod.equals("older than 2 years")) {
				if (permissionStatus.equals("Permitted")) {
					assertElementPresent(driver,Invoice.REVISE_BUTTON_IN_PSOP_INVOICES,
							"Revise Button in PSOP Invoice List page");
					click(driver,Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
					assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page");
					compareStrings("PSOP Invoice Revision",
							getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA, "Title in PSOP Invoice Revision page"));
				} else if (permissionStatus.equals("Not Permitted")) {
					assertElementPresent(driver,Invoice.REVISE_BUTTON_IN_PSOP_INVOICES,
							"Revise Button in PSOP Invoice List page");
					click(driver,Invoice.REVISE_BUTTON_IN_PSOP_INVOICES, "Revise Button in PSOP Invoice List page");
					// ERROR_PSOP_PERMISSION
					waitForVisibilityOfElementWithoutReport(driver,Invoice.ERROR_PSOP_PERMISSION,
							"Error description in PSOP Error page");
					assertElementPresent(driver,Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page");
					compareStrings(privilegeError,
							getText(driver,Invoice.ERROR_PSOP_PERMISSION, "Error description in PSOP Error page"));
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopInvoiceExceptionSearch(String reportSheet, int count) {

		try {
			String serviceCenter = Excelobject.getCellData(reportSheet, "Service Center", count);
			String entityId = Excelobject.getCellData(reportSheet, "Entity Id", count);
			String affiliateId = Excelobject.getCellData(reportSheet, "Affiliation Id", count);
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// INVOICE_EXCEPTION_SEARCH
			assertElementPresent(driver,Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			click(driver,Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			if (!entityId.equals("")) {
				// RADIO_BUTTON_FOR_ENTITY
				assertElementPresent(driver,Invoice.RADIO_BUTTON_FOR_ENTITY,
						"Radio Button for Entity in Invoice Exception Search Page");
				click(driver,Invoice.RADIO_BUTTON_FOR_ENTITY, "Radio Button for Entity in Invoice Exception Search Page");
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, entityId,
						"Search Text for Entity in Invoice Exception Search Page");
			}
			if (!affiliateId.equals("")) {
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, affiliateId,
						"Search Text for Entity in Invoice Exception Search Page");
			}
			// SERVICE_CENTER_DROP_DOWN
			assertElementPresent(driver,Invoice.SERVICE_CENTER, "Service Center drop down in Invoice Exception search Page");
			selectByVisibleText(driver,Invoice.SERVICE_CENTER, serviceCenter, "Filter Dropdown 1");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
			click(driver,Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void psopExceptionTab(String reportSheet, int count) {
		try {
			// PSOP_EXCEPTIONS_TAB
			assertElementPresent(driver,Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Exceptions Tab in Invoice Exception Page");
			click(driver,Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Execptions Tab in Invoice Exception Page");
			// PSOP_INVOICE_SEARCH_CRITERIA
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
					"Invoice Exceptions Title in Invoice Exception Page");
			compareStrings("Invoice Exceptions", getText(driver,Invoice.PSOP_INVOICE_SEARCH_CRITERIA,
					"Invoice Exceptions Title in Invoice Exception Page"));
			// PSOP_INVOICE_RESULTS_EXPORT_BUTTON
			assertElementPresent(driver,Invoice.PSOP_INVOICE_RESULTS_EXPORT_BUTTON, "Export button in Invoice Exception Page");
			isEnabled(driver,Invoice.PSOP_INVOICE_RESULTS_EXPORT_BUTTON, "Export button in Invoice Exception Page");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "Drop Down in Invoice Exception Page");
			assertElementPresent(driver,Invoice.IS_NEXT_TO_DROP_DOWN,
					"is displayed next to Drop Down in Invoice Exception Page");
			assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Search text box in Invoice Exception Page");
			assertElementPresent(driver,Invoice.GO_BUTTON, "Go Button in Invoice Exceptions Page");
			isEnabled(driver,Invoice.GO_BUTTON, "Go Button in Invoice Exceptions Page");
			assertElementPresent(driver,Invoice.SORT_BY_LABEL, "Sort By label in PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.REASON_SORT_LABEL, "Reason Sort label in PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.FIRST_NAVIGATION_ABOVE_GRID,
					"First navigation link above grid in PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID,
					"Previous navigation link above grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.NEXT_NAVIGATION_ABOVE_GRID,
					"Next navigation link above grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.LAST_NAVIGATION_ABOVE_GRID,
					"Last navigation link above grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.FIRST_NAVIGATION_BELOW_GRID,
					"First navigation link below grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_BELOW_GRID,
					"Previous navigation link below grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.NEXT_NAVIGATION_BELOW_GRID,
					"Next navigation link below grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.LAST_NAVIGATION_BELOW_GRID,
					"Last navigation link below grid PSOP Exceptions Page");
			assertElementPresent(driver,Invoice.SEARCH_AGAIN, "Search Again Button in PSOP Exceptions Page");
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public String getTheEntityOrAffiliationForErrorCodes(String reportSheet, int count) {
		ArrayList<String> entityOrAffl = new ArrayList<String>();
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			switch (errorCode) {
			case "69001":
				entityOrAffl = SQL_Queries.getAffiliationMissingXSOPGroup();
				break;
			case "69002":
				entityOrAffl = SQL_Queries.getAffiliationContainMoreXSOPGroup();
				break;
			case "69004":
				entityOrAffl = SQL_Queries.getEntityMissingXSOPDI();
				break;
			case "69005":
				entityOrAffl = SQL_Queries.getAffiliationForXSOPContainInvalidRecipient();
				break;
			case "69006":
				entityOrAffl = SQL_Queries.getEntityForDIContainInvalidRecipient();
				break;
			case "69008":
				entityOrAffl = SQL_Queries.getEntityForInvalidBusinessUnit();
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityOrAffl.get(0);
	}

	public String getTheServiceCenterForTheEntityOrAffiliation(String reportSheet, int count) {

		String serviceCenter = "";
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			if (errorCode.equals("69001") || errorCode.equals("69002") || errorCode.equals("69005")) {
				waitForElementToBeClickable(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
				click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
				waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
				type(driver,Affiliation.AFFILIATIONID, getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Affiliation Id text box");
				assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
				click(driver,Affiliation.SEARCHBTN, "Search Button");
				// MEMBERSBTN
				assertElementPresent(driver,Affiliation.MEMBERSBTN,
						"Members Button in left nav bar in Affiliation profile Page");
				click(driver,Affiliation.MEMBERSBTN, "Members Button in left nav bar in Affiliation profile Page");
				// FIRSTFILTER
				assertElementPresent(driver,Affiliation.FIRSTFILTER, "Drop down in Affiliation members Page");
				selectByVisibleText(driver,Affiliation.FIRSTFILTER, "Entity Name", "select entity name from the drop down");
				// SECONDFILTER
				assertElementPresent(driver,Affiliation.SECONDFILTER, "Drop down in Affiliation members Page");
				selectByVisibleText(driver,Affiliation.SECONDFILTER, "contains", "select contains from the drop down");
				// FILTERTEXTBOX
				assertElementPresent(driver,Affiliation.FILTERTEXTBOX, "Text box in Affiliation members Page");
				type(driver,Affiliation.FILTERTEXTBOX, getTheEntityOfAffiliationForErrorCodes(reportSheet, count),
						"Filter text field");
				// GOBTN
				assertElementPresent(driver,Affiliation.GOBTN, "Go Button in Affiliation search Page");
				click(driver,Affiliation.GOBTN, "Go Button in Affiliation members Page");
				// CORPORATEENTITYNAME
				assertElementPresent(driver,Affiliation.CORPORATEENTITYNAME, "entity link in Affiliation search Page");
				click(driver,Affiliation.CORPORATEENTITYNAME, "entity link in Affiliation members Page");
			} else if (errorCode.equals("69004") || errorCode.equals("69006")) {
				waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
				click(driver,HomePage.ENTITY_TAB, "Entity Search");
				waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
				type(driver,Entity.ENTITY_ID, getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Entity Id text box");
				assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				click(driver,Entity.SEARCH_BTN, "Search Button");
			}
			// change the Business unit
			else if (errorCode.equals("69008")) {
				waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
				click(driver,HomePage.ENTITY_TAB, "Entity Search");
				waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
				type(driver,Entity.ENTITY_ID, getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Entity Id text box");
				assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				click(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
				// ENTITY_EDIT
				assertElementPresent(driver,Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
				click(driver,Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
				// CHECK_BOX_SERVICE_CENTER
				waitForElementToBeClickable(driver,Entity.CHECK_BOX_SERVICE_CENTER,
						"check box service center Edit Entity Profile Page");
				assertElementPresent(driver,Entity.CHECK_BOX_SERVICE_CENTER,
						"check box service center Edit Entity Profile Page");
				click(driver,Entity.CHECK_BOX_SERVICE_CENTER, "check box service center Edit Entity Profile Page");
				// DROP_DOWN_LIST_SERVICE_CENTER
				waitForElementPresent(driver,Entity.DROP_DOWN_LIST_SERVICE_CENTER, "service center from the drop down");
				assertElementPresent(driver,Entity.DROP_DOWN_LIST_SERVICE_CENTER, "service center from the drop down");
				selectByVisibleText(driver,Entity.DROP_DOWN_LIST_SERVICE_CENTER, "CT UCC Demo Service Center",
						"select service center from the drop down");
				// DROP_DOWN_LIST_SERVICE_TEAM
				waitForElementPresent(driver,Entity.DROP_DOWN_LIST_SERVICE_TEAM, "service team drop down");
				assertElementPresent(driver,Entity.DROP_DOWN_LIST_SERVICE_TEAM, "service center from the drop down");
				selectByVisibleText(driver,Entity.DROP_DOWN_LIST_SERVICE_TEAM, "CT UCC Demo Team",
						"select service team from the drop down");
				// SAVE_BTN
				waitForElementPresent(driver,Entity.SAVE_BTN, "Save button in edit Entity profile page");
				assertElementPresent(driver,Entity.SAVE_BTN, "Save button in edit Entity profile page");
				click(driver,Entity.SAVE_BTN, "click on Save button in edit Entity profile page");

			}
			// method which fetch service team
			// SERVICE_CENTER
			assertElementPresent(driver,Entity.SERVICE_CENTER, "service center in Entity profile Page");
			serviceCenter = getText(driver,Entity.SERVICE_CENTER, "Text in the Service Center field");

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return serviceCenter;
	}

	public String getTheEntityOfAffiliationForErrorCodes(String reportSheet, int count) {
		ArrayList<String> entityOfAffl = new ArrayList<String>();
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			switch (errorCode) {
			case "69001":
				entityOfAffl = SQL_Queries.getBusNameAffiliationMissingXSOPGroup();
				break;
			case "69002":
				entityOfAffl = SQL_Queries.getBusNameAffiliationContainMoreXSOPGroup();
				break;
			case "69005":
				entityOfAffl = SQL_Queries.getBusNameAffiliationForXSOPContainInvalidRecipient();
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityOfAffl.get(0);
	}

	public void selectEntityOrAffAndServiceCenterSearch(String reportSheet, int count, String serviceCenter) {
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			if (errorCode.equals("69004") || errorCode.equals("69006") || errorCode.equals("69008")) {
				// RADIO_BUTTON_FOR_ENTITY
				assertElementPresent(driver,Invoice.RADIO_BUTTON_FOR_ENTITY,
						"Radio Button for Entity in Invoice Exception Search Page");
				click(driver,Invoice.RADIO_BUTTON_FOR_ENTITY, "Radio Button for Entity in Invoice Exception Search Page");
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Search Text for Entity in Invoice Exception Search Page");
			} else if (errorCode.equals("69001") || errorCode.equals("69002") || errorCode.equals("69005")) {
				// SEARCH_TEXT_UNDER_SEARCH_BY
				assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						"Search Text for Entity in Invoice Exception Search Page");
				selectBySendkeys(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
						getTheEntityOrAffiliationForErrorCodes(reportSheet, count),
						"Search Text for Entity in Invoice Exception Search Page");
			}
			// SERVICE_CENTER_DROP_DOWN
			assertElementPresent(driver,Invoice.SERVICE_CENTER, "Service Center drop down in Invoice Exception search Page");
			selectByVisibleText(driver,Invoice.SERVICE_CENTER, serviceCenter, "Filter Dropdown 1");

		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void validateThePSOPExceptionsInUI(String reportSheet, int count, String serviceCenter) {
		try {
			String errorCode = Excelobject.getCellData(reportSheet, "Error Code", count);
			String errorDescription = Excelobject.getCellData(reportSheet, "Error Description", count);
			String exceptionDescription = "";
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			// INVOICE_EXCEPTION_SEARCH
			assertElementPresent(driver,Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			click(driver,Invoice.INVOICE_EXCEPTION_SEARCH, "Left navigation bar after clicking on Invoice tab");
			selectEntityOrAffAndServiceCenterSearch(reportSheet, count, serviceCenter);
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
			click(driver,Invoice.SEARCH_BUTTON, "Search Button in Invoice Exception Search Page");
			// PSOP_EXCEPTIONS_TAB
			assertElementPresent(driver,Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Exceptions Tab in Invoice Exception Page");
			click(driver,Invoice.PSOP_EXCEPTIONS_TAB, "PSOP Execptions Tab in Invoice Exception Page");
			// FIRST_SUBMIT_ORDER_BUTTON
			assertElementPresent(driver,Invoice.FIRST_SUBMIT_ORDER_BUTTON, "Submit Order button in Invoice Exception Page");
			click(driver,Invoice.FIRST_SUBMIT_ORDER_BUTTON, "Submit Order button in Invoice Exception Page");
			// ERROR_BOX_VAL_SUMMARY
			assertElementPresent(driver,Invoice.ERROR_BOX_VAL_SUMMARY, "Error description in Invoice Exception Page");
			exceptionDescription = getText(driver,Invoice.ERROR_BOX_VAL_SUMMARY,
					"Error description in Invoice Exception Page");
			compareStrings(errorDescription, exceptionDescription);
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void searchForThePSOPInvoiceAndCreditSOP(String reportSheet, int count) throws Throwable {

		try {

			String psopCount = Excelobject.getCellData(reportSheet, "PSOP Count", count);
			String sopLines = Excelobject.getCellData(reportSheet, "SOP Lines", count);
			String deliveryMethod = Excelobject.getCellData(reportSheet, "Delivery Method", count);
			String revisionReason = Excelobject.getCellData(reportSheet, "Revision Reason", count);
			String orginalOrderId = SQL_Queries.getOriginalOrderId(psopCount).get(0);
			String originalInvoiceId = SQL_Queries.getOriginalInvoiceId(orginalOrderId).get(0);
			String orderContentOriginalOrder = SQL_Queries.getCountOfNonCreditedOriginalPSOPOrderContent(orginalOrderId)
					.get(0);
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, originalInvoiceId,
					"Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			// REVISE_BUTTON
			assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			click(driver,Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			selectTheSOPLinesAndReviseTheInvoice(reportSheet, count, orderContentOriginalOrder, "");
			// DELIVERY_METHOD_DROP_DOWN
			assertElementPresent(driver,Invoice.DELIVERY_METHOD_DROP_DOWN, "Delivery method in PSOP Invoice revision page");
			selectByVisibleText(driver,Invoice.DELIVERY_METHOD_DROP_DOWN, deliveryMethod,
					"Delivery method in PSOP Invoice revision page");
			// REVISION_REASON_DROP_DOWN
			assertElementPresent(driver,Invoice.REVISION_REASON_DROP_DOWN, "Revision Reason in PSOP Invoice revision page");
			selectByVisibleText(driver,Invoice.REVISION_REASON_DROP_DOWN, revisionReason,
					"Revision Reason in PSOP Invoice revision page");
			// SUBMIT_BUTTON
			assertElementPresent(driver,Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			click(driver,Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			Thread.sleep(5000);
			String originalOrderCreditedCount = SQL_Queries
					.getCountOfPSOPOrderContentAfterCreditForOriginalOrderId(orginalOrderId).get(0);
			printMessageInReport("Count of SOP Lines in Original Order: " + orderContentOriginalOrder);
			Thread.sleep(5000);
			printMessageInReport("Count of SOP Lines Credited in Original Order: " + originalOrderCreditedCount);
			// getNewOrderId
			Thread.sleep(5000);
			if (!sopLines.equals("ALL")) {
				String newOrderId = SQL_Queries.getNewOrderId(orginalOrderId).get(0);
				printMessageInReport("New Order id created: " + newOrderId);
				// getCountOfPSOPOrderContentForNewOrderId
				Thread.sleep(5000);
				String newOrderContentCount = SQL_Queries.getCountOfPSOPOrderContentForNewOrderId(newOrderId).get(0);
				printMessageInReport("Count of Order content in the New Order created: " + newOrderContentCount);
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void selectTheSOPLinesAndReviseTheInvoice(String reportSheet, int count, String orderContentOriginalOrder,
			String entityQuitOrAdd) {

		try {

			String sopLines = Excelobject.getCellData(reportSheet, "SOP Lines", count);
			String entityQuit = Excelobject.getCellData(reportSheet, "Entity Quit", count);
			switch (sopLines) {
			case "1":
				if (entityQuit.equals("Y")) {
					try {
						Thread.sleep(2000);
						By ENTITY_QUIT_FROM_AFFILIATION = By.xpath("//td[contains(text(),'" + entityQuitOrAdd
								+ "')]//parent::tr[starts-with(@id,'SelectedRow')]//td[starts-with(@id,'grdData_ctl')]");
						waitForElementPresent(driver,ENTITY_QUIT_FROM_AFFILIATION, "Check box for the Entity");
						assertElementPresent(driver,ENTITY_QUIT_FROM_AFFILIATION, "Check box for the Entity");
						click(driver,ENTITY_QUIT_FROM_AFFILIATION, "Click on the check box for the Entity Quit");

					} catch (NoSuchElementException e) {
					}
				} else {
					waitForElementPresent(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page");
					assertElementPresent(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page");
					for (int s = 0; s < Integer.valueOf(sopLines); s++) {
						clickOnAParticularIndexOfAnElement(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
								"Credit/remove check box in PSOP Invoice revision page", s);
						Thread.sleep(1000);
					}
				}
				break;
			case "2":
				waitForElementPresent(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				assertElementPresent(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				for (int s = 0; s < Integer.valueOf(sopLines); s++) {
					clickOnAParticularIndexOfAnElement(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page", s);
					Thread.sleep(1000);
				}
				break;
			case "ALL":
				waitForElementPresent(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				assertElementPresent(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
						"Credit/remove check box in PSOP Invoice revision page");
				for (int s = 0; s < Integer.valueOf(orderContentOriginalOrder); s++) {
					clickOnAParticularIndexOfAnElement(driver,Invoice.REMOVE_CREDIT_CHECK_BOX,
							"Credit/remove check box in PSOP Invoice revision page", s);
					Thread.sleep(1000);
				}
				break;
			case "None":

			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public String getTheEntityWithoutDSEnabled() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityHaveDERepLLCORDELP().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String getEntityNotHavingDERepLLCORDELP() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityNotHavingDERepLLCORDELP().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(String subgroupId) {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(subgroupId).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String getEntityHavingMoreThanOneRepIncludingREPLLC() {
		String entity = "";
		try {
			entity = SQL_Queries.getEntityHavingMoreThanOneRepIncludingREPLLC().get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity;
	}

	public String subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(String entity) {
		String subgroupInfo = "";
		try {

			subgroupInfo = SQL_Queries.subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(entity).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}

	public ArrayList<String> getTheSubgroupWhichAlreadyHavingDSPresent(String renewalMonth) {
		ArrayList<String> subgroupInfo = new ArrayList<String>();
		try {

			subgroupInfo = SQL_Queries.getTheSubgroupWhichAlreadyHavingDSPresent(renewalMonth);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}

	public String getTheSubgroupWithoutDSEnabled(String renewalMonth) {
		String subgroupInfo = "";
		try {

			subgroupInfo = SQL_Queries.getRenewalSubgroupHaveDERepLLCORDELP(renewalMonth).get(0);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return subgroupInfo;
	}

	public void bundleDSEffectiveStartDateEntityLevel(String reportSheet, int count,
			String getTheEntityWithoutDSEnabled) {
		try {

			String backDateOrForwardDate = Excelobject.getCellData(reportSheet, "BackOrForward Date", count);
			String EntityOrSubgroupLevel = Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
			String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet, "Discontinue Rep", count);
			waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
			click(driver,HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
			// type(driver,Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
			// count), "Entity Id text box");
			type(driver,Entity.ENTITY_ID, getTheEntityWithoutDSEnabled, "Entity Id text box");
			assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(driver,Entity.SEARCH_BTN, "Search Button");
			// RENEWAL_INVOICE_LEFT_NAV_LINK
			assertElementPresent(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
					"Renewal Invoices in left nav of entity profile page");
			click(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
			// ALL_RENEWAL_INVOICES_TAB
			assertElementPresent(driver,Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
			click(driver,Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			assertElementPresent(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY,
					"All Renewal Invoices Tab in Renewal Invoices page");
			click(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			waitForElementPresent(driver,Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String renewalDate = getText(driver,Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String effectiveStartDate = "";
			String dseffectiveStartDate = "";
			effectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(0);
			dseffectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(1);
			// ENTITY_PROFILE
			assertElementPresent(driver,Entity.ENTITY_PROFILE, "Entity profile link in left nav bar");
			click(driver,Entity.ENTITY_PROFILE, "Click on Entity profile link in left nav bar");
			// ENTITY_EDIT
			assertElementPresent(driver,Entity.ENTITY_EDIT, "Edit button on Entity profile page");
			click(driver,Entity.ENTITY_EDIT, "Click on Edit button on Entity profile page");
			// REPARMS_BUNDLE_BUNDLE_DRPDWN
			assertElementPresent(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			click(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			// EFFECTIVE_START_DATE
			assertElementPresent(driver,Entity.EFFECTIVE_START_DATE, "Effective start Date text field");
			type(driver,Entity.EFFECTIVE_START_DATE, effectiveStartDate, "Effective start Date text field");
			// DISBURSEMENT_EFFECTIVE_START_DATE
			assertElementPresent(driver,Entity.DISBURSEMENT_EFFECTIVE_START_DATE, "DS Effective start Date text field");
			type(driver,Entity.DISBURSEMENT_EFFECTIVE_START_DATE, dseffectiveStartDate, "DS Effective start Date text field");
			// PLUS_DISBURSEMENTS_CHECKBOX
			assertElementPresent(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus disbursement check box");
			click(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Click on Plus disbursement check box");
			// COMMENTS
			assertElementPresent(driver,Entity.COMMENTS, "Comments box in Edit Entity Profile page");
			type(driver,Entity.COMMENTS, "Test", "type test in Comments box in Edit Entity Profile page");
			// SAVE_BTN
			assertElementPresent(driver,Entity.SAVE_BTN, "Save Button on edit entity Profile Page");
			click(driver,Entity.SAVE_BTN, "Click on Save Button on edit entity profile page");
			reviseTheInvoice(EntityOrSubgroupLevel, "", "", discontinueDERepLLCorLP, getTheEntityWithoutDSEnabled);

		} catch (Throwable e) {

			// e.printStackTrace();
		}
	}

	public void bundleDSEffectiveStartDateSubgroupLevel(String reportSheet, int count, String entity,
			String getTheSubgroupWithoutDSEnabled) throws Throwable {
		try {
			String backDateOrForwardDate = Excelobject.getCellData(reportSheet, "BackOrForward Date", count);
			String subgroupId = getTheSubgroupWithoutDSEnabled;
			String affiliationId = SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(subgroupId).get(0);
			String subGroupName = SQL_Queries.getRenewalSubgroupNameHavingDERepLLCORDELP(subgroupId).get(1);
			String EntityOrSubgroupLevel = Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
			String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet, "Discontinue Rep", count);
			waitForElementToBeClickable(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
			waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(driver,Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
			assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(driver,Affiliation.SEARCHBTN, "Search Button");
			// RENEWAL_INVOICE_LEFT_NAV_LINK
			assertElementPresent(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
					"Renewal Invoices in left nav of entity profile page");
			click(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
			// ALL_RENEWAL_INVOICES_TAB
			assertElementPresent(driver,Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
			click(driver,Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			// NAME_DRPDWN
			assertElementPresent(driver,Entity.NAME_DRPDWN, "Name Drop down");
			click(driver,Entity.NAME_DRPDWN, "Click on Name Drop down");
			// SECOND_FILTER_DROP_DOWN
			assertElementPresent(driver,Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
			selectByVisibleText(driver,Entity.SECOND_FILTER_DROP_DOWN, "contains", "Second Filter Drop down");
			// PSOP_INVOICES_TEXT_SEARCH
			assertElementPresent(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
			type(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, subGroupName, "Search Box in top right of renewal Invoices page");
			// GO_BTN
			assertElementPresent(driver,Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
			click(driver,Entity.GO_BTN, "Click on Go Button");
			// ARROW_INVOICE_STATUS_SORT_BY
			assertElementPresent(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY,
					"All Renewal Invoices Tab in Renewal Invoices page");
			click(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			waitForElementPresent(driver,Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String renewalDate = getText(driver,Entity.GET_FIRST_INVOICE_RENEWAL_DATE,
					"First Renewal invoices in Renewal Invoices Page");
			String effectiveStartDate = "";
			String dseffectiveStartDate = "";
			effectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(0);
			dseffectiveStartDate = setTheDateForDS(backDateOrForwardDate, renewalDate).get(1);
			// SUB_GROUPS_LEFT_NAV_BAR
			assertElementPresent(driver,Entity.SUB_GROUPS_LEFT_NAV_BAR,
					"Sub Group link in left nav bar of renewal Invoices page");
			click(driver,Entity.SUB_GROUPS_LEFT_NAV_BAR, "Click on Sub Group link");
			// SUB_GROUP_BUNDLE_MAINTENANCE
			assertElementPresent(driver,Entity.SUB_GROUP_BUNDLE_MAINTENANCE,
					"Sub Group bundle maintenance link in left nav bar of renewal Invoices page");
			click(driver,Entity.SUB_GROUP_BUNDLE_MAINTENANCE,
					"Click on Sub Group bundle maintenance link in left nav bar of renewal Invoices page");

			// below is the fxn to validate if bundle is already enable
			// REPARMS_BUNDLE_BUNDLE_DRPDWN
			assertElementPresent(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			click(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			// EFFECTIVE_END_DATE
			assertElementPresent(driver,Invoice.EFFECTIVE_END_DATE, "Effective end Date text field");
			type(driver,Invoice.EFFECTIVE_END_DATE, effectiveStartDate, "Effective end Date text field");
			// COMMENTS
			assertElementPresent(driver,Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,
					"Comments box in sub group bundle maintenance page");
			type(driver,Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE, "Test",
					"type test in Comments box in sub group bundle maintenance page");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT,
					"First Drop down sub group bundle maintenance page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "Sub Group Name",
					"First Drop down sub group bundle maintenance page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(driver,Invoice.DROP_DOWN_FISRT_OP, "Second Drop down sub group bundle maintenance page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_FISRT_OP, "contains",
					"Second Drop down sub group bundle maintenance page");
			// TEXT_BOX_IN_RHS
			assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Text box in sub group bundle maintenance page");
			type(driver,Invoice.TEXT_BOX_IN_RHS, subGroupName,
					"type subgroup name in text box of sub group bundle maintenance page");
			assertElementPresent(driver,Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
			Thread.sleep(1000);
			click(driver,Invoice.GO_BUTTON, "Click on Go Button in sub group bundle maintenance page");
			List<WebElement> gridCheckBox = null;

			try {
				// GRID_CHECK_BOX_SELECTOR
				gridCheckBox = driver.findElements(Invoice.GRID_CHECK_BOX_SELECTOR);
				if (gridCheckBox.size() > 0) {
					assertElementPresent(driver,Invoice.GRID_CHECK_BOX_SELECTOR,
							"select the subgroup check box in sub group bundle maintenance page");
					click(driver,Invoice.GRID_CHECK_BOX_SELECTOR, "Click on check box in sub group bundle maintenance page");
					// BUTTON_DISABLE
					assertElementPresent(driver,Invoice.BUTTON_DISABLE, "disable button in sub group bundle maintenance page");
					click(driver,Invoice.BUTTON_DISABLE, "Click on disable button in sub group bundle maintenance page");
				}
			} catch (Exception e) {

			}
			// INACTIVE_BUNDLE_SUB_GROUPS
			assertElementPresent(driver,Entity.INACTIVE_BUNDLE_SUB_GROUPS,
					"Inactive bundle sub groups tab sub group bundle maintenance page");
			click(driver,Entity.INACTIVE_BUNDLE_SUB_GROUPS,
					"Click on Inactive bundle sub groups tab sub group bundle maintenance page");
			// REPARMS_BUNDLE_BUNDLE_DRPDWN
			assertElementPresent(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			click(driver,Entity.REPARMS_BUNDLE_BUNDLE_DRPDWN, "Select Reparms Bundle from Bundle dropdown");
			// EFFECTIVE_START_DATE
			assertElementPresent(driver,Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL, "Effective start Date text field");
			type(driver,Entity.EFFECTIVE_START_DATE_SUBGROUP_LEVEL, effectiveStartDate, "Effective start Date text field");
			// DISBURSEMENT_EFFECTIVE_START_DATE
			assertElementPresent(driver,Entity.DISBURSEMENT_EFFECTIVE_START_DATE, "DS Effective start Date text field");
			type(driver,Entity.DISBURSEMENT_EFFECTIVE_START_DATE, dseffectiveStartDate, "DS Effective start Date text field");
			// PLUS_DISBURSEMENTS_CHECKBOX
			assertElementPresent(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Plus disbursement check box");
			click(driver,Entity.PLUS_DISBURSEMENTS_CHECKBOX, "Click on Plus disbursement check box");
			// COMMENTS
			assertElementPresent(driver,Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE,
					"Comments box in sub group bundle maintenance page");
			type(driver,Invoice.COMMENT_BOX_SUB_GROUP_BUNDLE_MAINTENANCE, "Test",
					"type test in Comments box in sub group bundle maintenance page");
			// DROP_DOWN_INVOICE_CONTENT
			assertElementPresent(driver,Invoice.DROP_DOWN_INVOICE_CONTENT,
					"First Drop down sub group bundle maintenance page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_INVOICE_CONTENT, "Sub Group Name",
					"First Drop down sub group bundle maintenance page");
			// DROP_DOWN_FISRT_OP
			assertElementPresent(driver,Invoice.DROP_DOWN_FISRT_OP, "Second Drop down sub group bundle maintenance page");
			selectByVisibleText(driver,Invoice.DROP_DOWN_FISRT_OP, "contains",
					"Second Drop down sub group bundle maintenance page");
			// TEXT_BOX_IN_RHS
			assertElementPresent(driver,Invoice.TEXT_BOX_IN_RHS, "Text box in sub group bundle maintenance page");
			type(driver,Invoice.TEXT_BOX_IN_RHS, subGroupName,
					"type subgroup name in text box of sub group bundle maintenance page");
			assertElementPresent(driver,Invoice.GO_BUTTON, "Go Button sub group bundle maintenance page");
			click(driver,Invoice.GO_BUTTON, "Click on Go Button in sub group bundle maintenance page");
			// GRID_CHECK_BOX_SELECTOR
			assertElementPresent(driver,Invoice.GRID_CHECK_BOX_SELECTOR,
					"select the subgroup check box in sub group bundle maintenance page");
			click(driver,Invoice.GRID_CHECK_BOX_SELECTOR, "Click on check box in sub group bundle maintenance page");
			// ENABLE_BUTTON
			assertElementPresent(driver,Invoice.ENABLE_BUTTON, "enable Button in sub group bundle maintenance page");
			click(driver,Invoice.ENABLE_BUTTON, "click on enable button in sub group bundle maintenance page");
			reviseTheInvoice(EntityOrSubgroupLevel, subGroupName, subgroupId, discontinueDERepLLCorLP, entity);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void discontinueDomesticREPLLCorLP(String getTheEntityWithoutDSEnabled) throws Throwable {

		waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
		click(driver,HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
		// type(driver,Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
		// count), "Entity Id text box");
		type(driver,Entity.ENTITY_ID, getTheEntityWithoutDSEnabled, "Entity Id text box");
		assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(driver,Entity.SEARCH_BTN, "Search Button");
		// REPRESENATION_LEFT_NAV_LINK
		assertElementPresent(driver,Entity.REPRESENATION_LEFT_NAV_LINK, "Representation link in Entity Profile Page");
		click(driver,Entity.REPRESENATION_LEFT_NAV_LINK, "Click on Representation link");
		// FIRST_DROP_DOWN
		assertElementPresent(driver,Entity.FIRST_DROP_DOWN, "First drop down in represenation units Page");
		selectByVisibleText(driver,Entity.FIRST_DROP_DOWN, "Service Type", "First drop down in represenation units Page");
		// SECOND_FILTER_DROP_DOWN
		assertElementPresent(driver,Entity.SECOND_FILTER_DROP_DOWN, "Second drop down in represenation units Page");
		selectByVisibleText(driver,Entity.SECOND_FILTER_DROP_DOWN, "contains", "Second drop down in represenation units Page");
		// PSOP_INVOICES_TEXT_SEARCH
		assertElementPresent(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, "Text box Represenation units Page");
		type(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, "Domestic Representation (Limited", "Text box Represenation units Page");
		// GO_BTN
		assertElementPresent(driver,Entity.GO_BTN, "Go Button in Represenation units Page");
		click(driver,Entity.GO_BTN, "Click on Go Button in Represenation units Page");
		// FIRST_ENTITY_IN_GRID
		assertElementPresent(driver,Entity.FIRST_ENTITY_IN_GRID, "First Representation link in Represenation units Page");
		click(driver,Entity.FIRST_ENTITY_IN_GRID, "Click on First Representation link in Represenation units Page");
		// here pick filing date logic should come from the rep profile
		// REP_FILING_DATE
		assertElementPresent(driver,Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repFilingDate = getText(driver,Entity.REP_FILING_DATE, "Rep filing date in Represenation units Page");
		String repDiscontinueDate = setTheDateForDS("forwardDate", repFilingDate).get(1);
		// DISCONTINUE_BUTTON
		assertElementPresent(driver,Entity.DISCONTINUE_BUTTON, "Discontinue Button in Represenation units Page");
		click(driver,Entity.DISCONTINUE_BUTTON, "Click on Discontinue Button in Represenation units Page");
		// FILING_DATE_FOR_DISCONTINUE
		assertElementPresent(driver,Entity.FILING_DATE_FOR_DISCONTINUE, "Filing text box in Represenation units Page");
		type(driver,Entity.FILING_DATE_FOR_DISCONTINUE, repDiscontinueDate, "Filing text box in Represenation units Page");
		// DISCONTINUE_REASON_DROP_DOWN
		assertElementPresent(driver,Entity.DISCONTINUE_REASON_DROP_DOWN,
				"First drop down in discontinue represenation units Page");
		selectByVisibleText(driver,Entity.DISCONTINUE_REASON_DROP_DOWN, "1 Year Suspension",
				"First drop down in discontinue represenation units Page");
		// DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT
		assertElementPresent(driver,Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT,
				"Discontinue Button in Represenation units Page");
		click(driver,Entity.DISCONTINUE_BUTTON_DISCONTINUE_REPRESENTATION_UNIT,
				"Click on Discontinue Button in Represenation units Page");
	}

	public ArrayList<String> setTheDateForDS(String backDateOrForwardDate, String renewalDate) {
		ArrayList<String> dates = new ArrayList<String>();
		String month = renewalDate.split("\\/")[0];
		String date = renewalDate.split("\\/")[1];
		String year = renewalDate.split("\\/")[2];
		String effectiveStartDate = "";
		String dseffectiveStartDate = "";
		if (backDateOrForwardDate.equals("backDate")) {
			if (Integer.valueOf(month) >= 3) {
				effectiveStartDate = String.valueOf(Integer.valueOf(month) - 2) + "/" + date + "/" + year;
				dseffectiveStartDate = String.valueOf(Integer.valueOf(month) - 1) + "/" + date + "/" + year;
			} else if (Integer.valueOf(month) < 3) {
				effectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 2);
				dseffectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 1);
			}
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);
		} else if (backDateOrForwardDate.equals("forwardDate")) {
			if (Integer.valueOf(month) <= 10) {
				effectiveStartDate = String.valueOf(Integer.valueOf(month) - 1) + "/" + date + "/" + year;
				dseffectiveStartDate = String.valueOf(Integer.valueOf(month) + 1) + "/" + date + "/" + year;
			} else if (Integer.valueOf(month) > 10) {
				effectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) - 1);
				dseffectiveStartDate = month + "/" + date + "/" + String.valueOf(Integer.valueOf(year) + 1);
			}
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);
		} else if (backDateOrForwardDate.equals("")) {
			effectiveStartDate = month + "/" + date + "/" + year;
			dseffectiveStartDate = month + "/" + date + "/" + year;
			dates.add(effectiveStartDate);
			dates.add(dseffectiveStartDate);
		}
		return dates;
	}

	public void reviseTheInvoice(String entityOrSubgroupLevel, String subGroupName, String SubgroupOrEntityId,
			String discontinueDERepLLCorLP, String entity) throws Throwable {

		// RENEWAL_INVOICE_LEFT_NAV_LINK
		assertElementPresent(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK,
				"Renewal Invoices in left nav of entity profile page");
		click(driver,Entity.RENEWAL_INVOICE_LEFT_NAV_LINK, "Click on Renewal Invoices in left nav of entity profile page");
		// ALL_RENEWAL_INVOICES_TAB
		assertElementPresent(driver,Entity.ALL_RENEWAL_INVOICES_TAB, "All Renewal Invoices Tab in Renewal Invoices page");
		click(driver,Entity.ALL_RENEWAL_INVOICES_TAB, "Click on All Renewal Invoices Tab in Renewal Invoices page");

		if (entityOrSubgroupLevel.equals("EntityLevel")) {
			try {
				assertElementPresent(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY,
						"All Renewal Invoices Tab in Renewal Invoices page");
				click(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY,
						"Click on All Renewal Invoices Tab in Renewal Invoices page");
				// GET_FIRST_INVOICE_LINK
				assertElementPresent(driver,Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
				click(driver,Entity.GET_FIRST_INVOICE_LINK, "Click on First Invoice link in Renewal Invoices page");
				// get the name of Entity from here ENTITY_NAME_LINK_INVOICE_PROFILE
				assertElementPresent(driver,Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity link in Renewal Invoices page");
				String entityName = getText(driver,Entity.ENTITY_NAME_LINK_INVOICE_PROFILE, "Entity name");
				String parentWindow = null;
				parentWindow = doARevisionPreviewOfTheInvoice(entityName);
				// move to new window
				handlePopUpWindwow(driver);
				// String parentWindow = doARevisionPreviewOfTheInvoice();
				// move to new window
				// handlePopUpWindwow(driver);
				if (discontinueDERepLLCorLP.equals("Y")) {
					// By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = null;
					List<WebElement> annualReport = null;
					// ("//td[contains(text(),'9400574631')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual
					// Report Renewal Disbursements')]")
					try {
						By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
								+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
						annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
						}
					} catch (NoSuchElementException e) {
						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ " as the DS criteria does not met");
					}
				} else {
					// ANNUAL_REPORT_RENEWAL_DISBURSEMENT
					By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = null;
					List<WebElement> annualReport = null;
					try {
						ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entityName
								+ "')]/following-sibling::td[contains(text(),'Annual Report Renewal Disbursements')]");
						annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport(
									"Disbursement Added for the eligible Rep for the Entity : " + entityName);
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ " as the DS criteria does not met");

					}
				}

				driver.close();
				driver.switchTo().window(parentWindow);
				assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
				click(driver,Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
				// DO_NOT_PRINT_RADIO_BUTTON
				assertElementPresent(driver,Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Do not Print Radio Button in Affected Invoices page");
				click(driver,Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Click on Do not Print Radio Button in Affected Invoices page");
				// REVISE_REASON_DROP_DOWN
				assertElementPresent(driver,Invoice.REVISE_REASON_DROP_DOWN,
						"Revision Reason drop down in Revise Invoice page");
				selectByVisibleText(driver,Invoice.REVISE_REASON_DROP_DOWN, "CT Assurance",
						"Revision Reason drop down in Revise Invoice page");
				// REVISE_BUTTON_REPRINT
				assertElementPresent(driver,Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
				click(driver,Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
			}

			catch (Exception e) {

			}
		}

		else if (entityOrSubgroupLevel.equals("SubgroupLevel")) {
			// NAME_DRPDWN
			waitForElementPresent(driver,Entity.NAME_DRPDWN, "Name Drop down");
			assertElementPresent(driver,Entity.NAME_DRPDWN, "Name Drop down");
			click(driver,Entity.NAME_DRPDWN, "Click on Name Drop down");
			/// SECOND_FILTER_DROP_DOWN
			waitForElementPresent(driver,Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
			assertElementPresent(driver,Entity.SECOND_FILTER_DROP_DOWN, "Second Filter Drop down");
			selectByVisibleText(driver,Entity.SECOND_FILTER_DROP_DOWN, "contains", "Second Filter Drop down");
			// PSOP_INVOICES_TEXT_SEARCH
			assertElementPresent(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, "Search Box in top right of renewal Invoices page");
			type(driver,Entity.PSOP_INVOICES_TEXT_SEARCH, subGroupName, "Search text box");
			// GO_BTN
			assertElementPresent(driver,Entity.GO_BTN, "Go Button in top right of renewal Invoices page");
			click(driver,Entity.GO_BTN, "Click on Go Button");
			// ARROW_INVOICE_STATUS_SORT_BY
			assertElementPresent(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY,
					"All Renewal Invoices Tab in Renewal Invoices page");
			click(driver,Invoice.ARROW_INVOICE_STATUS_SORT_BY, "Click on All Renewal Invoices Tab in Renewal Invoices page");
			// GET_FIRST_INVOICE_LINK
			assertElementPresent(driver,Entity.GET_FIRST_INVOICE_LINK, "Get first Invoice link in Renewal Invoices page");
			click(driver,Entity.GET_FIRST_INVOICE_LINK, "Click on First Invoice link in Renewal Invoices page");
			String parentWindowSubGroup = null;
			assertElementPresent(driver,Entity.SUBGROUP_NAME_LINK_INVOICE_PROFILE, "subgroup link in Renewal Invoices page");
			String subgroupName = getText(driver,Entity.SUBGROUP_NAME_LINK_INVOICE_PROFILE, "subgroup name");
			try {
				// here first identity the subgroup name

				parentWindowSubGroup = doARevisionPreviewOfTheInvoice(subgroupName);

				// move to new window
				handlePopUpWindwow(driver);
				// ANNUAL_REPORT_RENEWAL_DISBURSEMENT
				if (discontinueDERepLLCorLP.equals("Y")) {

					try {
						List<WebElement> annualReport = null;
						By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
								+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
						annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ "as the DS criteria does not met");
						printMessageInReport("No Disbursement are added for the discontinued Rep");

					}
					try {

						List<WebElement> totalDisbursement = null;
						totalDisbursement = driver.findElements(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (totalDisbursement.size() > 0) {
							printMessageInReport("Disbursement are added for the subgroup : " + subgroupName
									+ " and count is : " + totalDisbursement.size());
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the subgroup");

					}
				} else {
					// assertElementPresent(driver,Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT, "Disbursement
					// present");
					try {
						By ANNUAL_REPORT_RENEWAL_DISBURSEMENT = By.xpath("//td[contains(text(),'" + entity
								+ "')]/parent::tr/parent::tbody/tr[1]/td[contains(text(),'Annual Report Renewal Disbursements')]");
						List<WebElement> annualReport = driver.findElements(ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (annualReport.size() > 0) {
							printMessageInReport("Disbursement Added for the eligible Rep for the Entity : " + entity);
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the Entity ID : " + entity
								+ " as the DS criteria does not met");

					}
					try {

						List<WebElement> totalDisbursement = null;
						totalDisbursement = driver.findElements(Entity.ANNUAL_REPORT_RENEWAL_DISBURSEMENT);
						if (totalDisbursement.size() > 0) {
							printMessageInReport("Disbursement are added for the subgroup and count is : "
									+ totalDisbursement.size());
						}
					} catch (NoSuchElementException e) {

						printMessageInReport("No Disbursement are added for the subgroup");

					}
				}

				driver.close();
				driver.switchTo().window(parentWindowSubGroup);
				// REVISE_BUTTON
				assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise Button in Affected Invoices page");
				click(driver,Invoice.REVISE_BUTTON, "Click on Revise Button in Affected Invoices page");
				// DO_NOT_PRINT_RADIO_BUTTON
				assertElementPresent(driver,Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Do not Print Radio Button in Affected Invoices page");
				click(driver,Invoice.DO_NOT_PRINT_RADIO_BUTTON,
						"Click on Do not Print Radio Button in Affected Invoices page");
				// REVISE_REASON_DROP_DOWN
				assertElementPresent(driver,Invoice.REVISE_REASON_DROP_DOWN,
						"Revision Reason drop down in Revise Invoice page");
				selectByVisibleText(driver,Invoice.REVISE_REASON_DROP_DOWN, "CT Assurance",
						"Revision Reason drop down in Revise Invoice page");
				// REVISE_BUTTON_REPRINT
				assertElementPresent(driver,Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
				click(driver,Invoice.REVISE_BUTTON_REPRINT, "Revise button in Revise Invoice page");
			}

			catch (Exception e) {

			}
		}

	}

	public String doARevisionPreviewOfTheInvoice(String entityOrSubgroupName) throws Throwable {
		// REVISION_PREVIEW_BUTTON
		waitForElementPresent(driver,Entity.REVISION_PREVIEW_BUTTON, "Revision Preview Button on Invoice Profile");
		assertElementPresent(driver,Entity.REVISION_PREVIEW_BUTTON, "Revision Preview button in Renewal Invoices page");
		click(driver,Entity.REVISION_PREVIEW_BUTTON, "Click on Revision Preview button in Renewal Invoices page");
		//// Here first the next button check should be done
		try {
			List<WebElement> action = driver.findElements(Invoice.NEXT_BUTTON_RELATED_INVOICE);
			if (action.size() > 0) {

				click(driver,Invoice.NEXT_BUTTON_RELATED_INVOICE,
						"Click on Next button in Related Invoices Needing Revision page");
			}
		} catch (NoSuchElementException e) {

		}
		String parentWindow = "";
		try {
			parentWindow = driver.getWindowHandle();
			By INVOICE_SUBGROUP_OR_ENTITY_LEVEL = By.xpath("//a[contains(text(),'" + entityOrSubgroupName + "')]");
			List<WebElement> entOrSubgroup = driver.findElements(INVOICE_SUBGROUP_OR_ENTITY_LEVEL);
			if (entOrSubgroup.size() > 0) {
				waitForElementToBeClickable(driver,INVOICE_SUBGROUP_OR_ENTITY_LEVEL,
						"Entity or subgroup present in revision preview");
				// waitForElementPresent(driver,Entity.FIRST_INVOICE_IN_NEW_INVOICES_GRID, "First
				// invoice in new Invoice grid");
				assertElementPresent(driver,INVOICE_SUBGROUP_OR_ENTITY_LEVEL,
						"Entity or subgroup present in revision preview");
				click(driver,INVOICE_SUBGROUP_OR_ENTITY_LEVEL, "Entity or subgroup present in revision preview");
			}
		} catch (NoSuchElementException e) {

		}
		return parentWindow;
	}

	public void addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice(String reportSheet, int count,
			ArrayList<String> subgroupInfo, String entity) throws Throwable {

		String affiliationId = subgroupInfo.get(0);
		String subgroupId = subgroupInfo.get(1);
		String subGroupName = subgroupInfo.get(2);
		String EntityOrSubgroupLevel = Excelobject.getCellData(reportSheet, "EntityOrSubgroup Level", count);
		// String discontinueDERepLLCorLP = Excelobject.getCellData(reportSheet,
		// "Discontinue Rep", count);
		waitForElementToBeClickable(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(driver,Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(driver,Affiliation.SEARCHBTN, "Search Button");
		// AFFILIATION_NAME
		assertElementPresent(driver,Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		String affName = getText(driver,Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
		click(driver,HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
		// type(driver,Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
		// count), "Entity Id text box");
		type(driver,Entity.ENTITY_ID, entity, "Entity Id text box");
		assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(driver,Entity.SEARCH_BTN, "Search Button");
		click(driver,Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(driver,Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		click(driver,Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		click(driver,Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
		// BULLETINRETAINCURRENTDI
		assertElementPresent(driver,Affiliation.BULLETINRETAINCURRENTDI,
				" Bulletin Radio button in confirm joining affiliation Page");
		click(driver,Affiliation.BULLETINRETAINCURRENTDI, " Bulletin Radio button in confirm joining affiliation Page");
		// COMMRETAINCURRENTDI
		assertElementPresent(driver,Affiliation.COMMRETAINCURRENTDI,
				" Communication Radio button in confirm joining affiliation Page");
		click(driver,Affiliation.COMMRETAINCURRENTDI, " Communication Radio button in confirm joining affiliation Page");
		// RENEWALINVOICESUBGROUPDROPDWN
		assertElementPresent(driver,Affiliation.RENEWALINVOICESUBGROUPDROPDWN,
				" REnewal Invoice drop down in confirm joining affiliation Page");
		selectByVisibleText(driver,Affiliation.RENEWALINVOICESUBGROUPDROPDWN, subGroupName,
				"REnewal Invoice drop down in confirm joining affiliation Page");
		// SOPRETAINCURRENTDI
		assertElementPresent(driver,Affiliation.SOPRETAINCURRENTDI, " SOP Radio button in confirm joining affiliation Page");
		click(driver,Affiliation.SOPRETAINCURRENTDI, " SOP Radio button in confirm joining affiliation Page");
		// XSOPSUBGROUPDROPDWN
		assertElementPresent(driver,Affiliation.XSOPSUBGROUPDROPDWN, "XSOP drop down in confirm joining affiliation Page");
		selectByIndex(driver,Affiliation.XSOPSUBGROUPDROPDWN, 1, "XSOP drop down in confirm joining affiliation Page");
		// COMMENTS
		assertElementPresent(driver,Affiliation.COMMENTS, "Comments text box in confirm joining affiliation Page");
		type(driver,Affiliation.COMMENTS, "Test", "Comments text box in confirm joining affiliation Page");
		// JOINBTN
		assertElementPresent(driver,Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
		click(driver,Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
		waitForElementToBeClickable(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(driver,Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(driver,Affiliation.SEARCHBTN, "Search Button");
		// Add bundle thing here
		if (EntityOrSubgroupLevel.equals("EntityLevel")) {
			bundleDSEffectiveStartDateEntityLevel(reportSheet, count, entity);
		} else if (EntityOrSubgroupLevel.equals("SubgroupLevel")) {
			bundleDSEffectiveStartDateSubgroupLevel(reportSheet, count, entity, subgroupId);
		}
		// reviseTheInvoice(EntityOrSubgroupLevel,subGroupName,subgroupId,discontinueDERepLLCorLP,entity);

	}

	public void validateTheInvoiceChangesPostRevision(String orderId) throws Throwable {
		//
		assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
		click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
		// SEARCH_TEXT_UNDER_SEARCH_BY
		assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, "Invoice search text box");
		type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, orderId, "Invoice search text box");
		// SEARCH_BUTTON
		assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in the renewal search Page");
		click(driver,Invoice.SEARCH_BUTTON, "Search button in the renewal search Page");
		List<WebElement> disableInvoiceLink = null;
		try {
			// NO_INVOICE_CHANGES_LINK
			disableInvoiceLink = driver.findElements(Invoice.NO_INVOICE_CHANGES_LINK);
		} catch (NoSuchElementException e) {

		}
		if (disableInvoiceLink == null) {

			// INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE
			assertElementPresent(driver,Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE,
					"Invoice changes link for the first invoice");
			click(driver,Invoice.INVOICE_CHANGES_LINK_FOR_FIRST_INVOICE, "Invoice changes link for the first invoice");
			// DS_ADDED
			try {
				List<WebElement> ds = driver.findElements(Invoice.DS_ADDED);
				printMessageInReport("Total DS Added = " + ds.size());
			} catch (NoSuchElementException e) {
			}
		} else {
			printMessageInReport("No DS is Added as the DS Criteria does not met");

		}
	}

	public void revisePSOPInvoiceAndCreditSOP(String reportSheet, int count,
			ArrayList<String> originalInvoiceAndOrderId, String entityQuitOrAdd) throws Throwable {

		try {

			String entityQuit = Excelobject.getCellData(reportSheet, "Entity Quit", count);
			String sopLines = Excelobject.getCellData(reportSheet, "SOP Lines", count);
			String deliveryMethod = Excelobject.getCellData(reportSheet, "Delivery Method", count);
			String revisionReason = Excelobject.getCellData(reportSheet, "Revision Reason", count);
			String orginalOrderId = originalInvoiceAndOrderId.get(1);
			String originalInvoiceId = originalInvoiceAndOrderId.get(0);
			String orderContentOriginalOrder = SQL_Queries.getCountOfNonCreditedOriginalPSOPOrderContent(orginalOrderId)
					.get(0);
			waitForElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			click(driver,HomePage.INVOICE_TAB, "Invoice Tab");
			assertElementPresent(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			click(driver,Invoice.PSOP_INVOICE_SEARCH, "PSOP_INVOICE_SEARCH Left Nav link");
			// SEARCH_TEXT_UNDER_SEARCH_BY
			waitForElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			assertElementPresent(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY,
					"Search text in PSOP Invoice search criteria page");
			type(driver,Invoice.SEARCH_TEXT_UNDER_SEARCH_BY, originalInvoiceId,
					"Search text in PSOP Invoice search criteria page");
			// SEARCH_BUTTON
			waitForElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			assertElementPresent(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			click(driver,Invoice.SEARCH_BUTTON, "Search button in PSOP Invoice search criteria page");
			// REVISE_BUTTON
			waitForElementPresent(driver,Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			assertElementPresent(driver,Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			click(driver,Invoice.REVISE_BUTTON, "Revise button in PSOP Invoice profile page");
			// if(!entityQuit.equals("Y")) {
			selectTheSOPLinesAndReviseTheInvoice(reportSheet, count, orderContentOriginalOrder, entityQuitOrAdd);
			try {
				// DELIVERY_METHOD_DROP_DOWN
				List<WebElement> delMethod = driver.findElements(Invoice.DELIVERY_METHOD_DROP_DOWN);
				if (delMethod.size() > 0) {
					// waitForElementPresent(driver,Invoice.DELIVERY_METHOD_DROP_DOWN,"Delivery method in
					// PSOP Invoice revision page");
					assertElementPresent(driver,Invoice.DELIVERY_METHOD_DROP_DOWN,
							"Delivery method in PSOP Invoice revision page");
					selectByVisibleText(driver,Invoice.DELIVERY_METHOD_DROP_DOWN, deliveryMethod,
							"Delivery method in PSOP Invoice revision page");
					// REVISION_REASON_DROP_DOWN
					// waitForElementPresent(driver,Invoice.REVISION_REASON_DROP_DOWN,"Revision Reason in
					// PSOP Invoice revision page");
					assertElementPresent(driver,Invoice.REVISION_REASON_DROP_DOWN,
							"Revision Reason in PSOP Invoice revision page");
					selectByVisibleText(driver,Invoice.REVISION_REASON_DROP_DOWN, revisionReason,
							"Revision Reason in PSOP Invoice revision page");
				}
			} catch (NoSuchElementException e) {
			}
			// SUBMIT_BUTTON
			waitForElementPresent(driver,Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			assertElementPresent(driver,Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			click(driver,Invoice.SUBMIT_BUTTON, "Submit button in PSOP Invoice revision page");
			Thread.sleep(5000);
			String originalOrderCreditedCount = SQL_Queries
					.getCountOfPSOPOrderContentAfterCreditForOriginalOrderId(orginalOrderId).get(0);
			printMessageInReport("Count of SOP Lines in Original Order: " + orderContentOriginalOrder);
			Thread.sleep(3000);
			printMessageInReport("Count of SOP Lines Credited in Original Order: " + originalOrderCreditedCount);
			// getNewOrderId
			Thread.sleep(3000);
			if (!sopLines.equals("ALL")) {
				String newOrderId = "";
				try {
					newOrderId = getNewOrderId(orginalOrderId).get(0);
					if (!newOrderId.equals("")) {
						System.out.println("The new Order Id is : " + newOrderId);
						if (entityQuit.equals("Y")) {
							String countOfSopLinesBeforeCreditForEntity = SQL_Queries
									.getTheCountOfEntityQuitFromAffiliationForThePSOPOrderId(orginalOrderId).get(0);
							String countOfSopLinesAfterCreditForEntity = getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(
									entityQuitOrAdd, newOrderId).get(0);
							printMessageInReport("Count Of SOPs for the entity before Quit : "
									+ countOfSopLinesBeforeCreditForEntity);
							printMessageInReport(
									"Count Of SOPs for the entity After Quit : " + countOfSopLinesAfterCreditForEntity);
						}
						printMessageInReport("New Order id created: " + newOrderId);
						// getCountOfPSOPOrderContentForNewOrderId
						Thread.sleep(3000);
						String newOrderContentCount = SQL_Queries.getCountOfPSOPOrderContentForNewOrderId(newOrderId)
								.get(0);
						printMessageInReport(
								"Count of Order content in the New Order created: " + newOrderContentCount);
						verifyTheNewOrderRefersToTheOriginalOrder(orginalOrderId, newOrderId);
					}
				} catch (IndexOutOfBoundsException e) {
				}
			}
		} catch (Throwable e) {

			e.printStackTrace();
		}
	}

	public void verifyTheNewOrderRefersToTheOriginalOrder(String originalOrderId, String newOrderId) throws Throwable {

		ArrayList<String> originalOrderContent = new ArrayList<String>();
		ArrayList<String> newOrderContent = new ArrayList<String>();
		try {
			originalOrderContent = SQL_Queries.getTheOriginalOrderContent(originalOrderId);
		} catch (IndexOutOfBoundsException e) {
		}
		Thread.sleep(2000);
		try {
			newOrderContent = SQL_Queries.getTheNewOrderContent(newOrderId);
		} catch (IndexOutOfBoundsException e) {
		}
		Thread.sleep(2000);
		boolean bool = originalOrderContent.equals(newOrderContent);
		if (bool == true) {
			printMessageInReport("New Order refers to the original Order, Original Order : " + originalOrderContent
					+ "New Order : " + newOrderContent);
		}
	}

	public ArrayList<String> getTheOriginalEntityLevelPSOPInvoice() {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getTheOriginalEntityLevelPSOPInvoice();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return originalInvoieAndOrderId;
	}

	public ArrayList<String> getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(String entityId, String newOrderId)
			throws Throwable {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getTheCountOfEntityIdToQuitFromAffiliationInNewOrder(entityId,
					newOrderId);

		} catch (IndexOutOfBoundsException e) {

		}
		return originalInvoieAndOrderId;
	}

	public ArrayList<String> getNewOrderId(String oldOrderId) throws Throwable {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getNewOrderId(oldOrderId);

		} catch (IndexOutOfBoundsException e) {

		}
		return originalInvoieAndOrderId;
	}

	public ArrayList<String> getTheOriginalAffiliationLevelPSOPInvoice() {
		ArrayList<String> originalInvoieAndOrderId = new ArrayList<String>();
		try {

			originalInvoieAndOrderId = SQL_Queries.getTheOriginalAffiliationLevelPSOPInvoice();

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return originalInvoieAndOrderId;
	}

	public String getTheEntityIdToQuitFromAffiliationForThePSOPOrderId(String orderId) {
		ArrayList<String> entity = new ArrayList<String>();
		try {

			entity = SQL_Queries.getTheEntityIdToQuitFromAffiliationForThePSOPOrderId(orderId);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entity.get(0);
	}

	public String getTheEntityIdForThePSOPOrderId(String orderId) {
		ArrayList<String> entityId = new ArrayList<String>();
		try {

			entityId = SQL_Queries.getTheEntityIdForThePSOPOrderId(orderId);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return entityId.get(0);
	}

	public String getTheAffiliationIdForThePSOPOrderId(String orderId) {
		ArrayList<String> affiliationId = new ArrayList<String>();
		try {

			affiliationId = SQL_Queries.getTheAffiliationIdForThePSOPOrderId(orderId);

		} catch (Throwable e) {

			e.printStackTrace();
		}
		return affiliationId.get(0);
	}

	public void searchForTheEntityAndChangeRenewalMonth(String entityId) throws Throwable {
		try {
			waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
			click(driver,HomePage.ENTITY_TAB, "Entity Search");
			waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
			type(driver,Entity.ENTITY_ID, entityId, "Entity Id text box");
			assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
			click(driver,Entity.SEARCH_BTN, "Search Button");
			// ENTITY_EDIT
			waitForElementPresent(driver,Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
			assertElementPresent(driver,Entity.ENTITY_EDIT, "Edit Button in Entity Profile Page");
			click(driver,Entity.ENTITY_EDIT, "Click on Edit Button");
			// SELECTED_RENEWAL_MONTH
			waitForElementPresent(driver,Entity.SELECTED_RENEWAL_MONTH, "value");
			String month = getAttribute(driver,Entity.SELECTED_RENEWAL_MONTH, "value");
			// RENEWAL_MONTH_EDIT_ENTITY
			try {
				if (Integer.valueOf(month) < 12) {
					waitForElementPresent(driver,Entity.RENEWAL_MONTH_EDIT_ENTITY, "Renewal Month Edit Entity");
					selectByIndex(driver,Entity.RENEWAL_MONTH_EDIT_ENTITY, Integer.valueOf(month), "month select drop down");

				} else if (Integer.valueOf(month) == 12) {
					waitForElementPresent(driver,Entity.RENEWAL_MONTH_EDIT_ENTITY, "Renewal Month Edit Entity");
					selectByIndex(driver,Entity.RENEWAL_MONTH_EDIT_ENTITY, Integer.valueOf(month) - 4,
							"month select drop down");
				}
			} catch (NoSuchElementException e) {
			}
			// COMMENTS
			assertElementPresent(driver,Entity.COMMENTS, "Comment text box in Edit Entity Information Page");
			type(driver,Entity.COMMENTS,
					"Change RM from : " + month + " to " + getAttribute(driver,Entity.SELECTED_RENEWAL_MONTH, "value"),
					"Comment text box in Edit Entity Information Page");
			// SAVE_BTN
			assertElementPresent(driver,Entity.SAVE_BTN, "Save button in Edit Entity Information Page");
			click(driver,Entity.SAVE_BTN, "Save button in Edit Entity Information Page");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchForTheAffiliationAndChangeRenewalMonth(String affiliationId) throws Throwable {
		try {
			waitForElementPresent(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
			click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
			waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
			type(driver,Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
			assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
			click(driver,Affiliation.SEARCHBTN, "Search Button");
			// EDITBTN
			waitForElementPresent(driver,Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			assertElementPresent(driver,Affiliation.EDITBTN, "Edit Button in Affiliation search Page");
			click(driver,Affiliation.EDITBTN, "Click on Edit Button");
			// SELECTED_RENEWAL_MONTH
			waitForElementPresent(driver,Affiliation.SELECTED_RENEWAL_MONTH, "value");
			String month = getAttribute(driver,Affiliation.SELECTED_RENEWAL_MONTH, "value");
			// RENEWAL_MONTH_EDIT_ENTITY
			if (Integer.valueOf(month) < 12) {

				waitForElementPresent(driver,Affiliation.SELECTED_RENEWAL_MONTH, "value");
				selectByIndex(driver,Affiliation.COMMONRENEWALDRPDWN, Integer.valueOf(month) + 1, "month select drop down");
			} else if (Integer.valueOf(month) == 12) {
				waitForElementPresent(driver,Affiliation.SELECTED_RENEWAL_MONTH, "value");
				selectByIndex(driver,Affiliation.COMMONRENEWALDRPDWN, Integer.valueOf(month) - 1, "month select drop down");
			}
			// COMMENTFIELD
			assertElementPresent(driver,Affiliation.COMMENTFIELD, "Comment text box in Edit Affiliation Information Page");
			type(driver,Affiliation.COMMENTFIELD, "Changed renewal Month", "Comment text box in Edit Entity Information Page");
			// SAVE_BTN
			assertElementPresent(driver,Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");
			click(driver,Affiliation.SAVEBTN, "Save button in Edit Affiliation Information Page");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void quitEntityFromAffiliation(String entityId) throws Throwable {

		// click on Entity Search link
		waitForElementPresent(driver,Entity.ENTITY_LINK_TOPNAV, "Entity Search");
		click(driver,Entity.ENTITY_LINK_TOPNAV, "Entity Search");
		waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
		// Enter Entity ID and click on search button
		type(driver,Entity.ENTITY_ID, entityId, "Entity Id Text box");
		click(driver,Entity.SEARCH_BTN, "Search Button");
		waitForElementPresent(driver,Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
		String quitAffiliationDisabled = getAttribute(driver,Entity.QUIT_AFFILIATION_BTN, "disabled");

		if (quitAffiliationDisabled == null) {
			assertElementPresent(driver,Entity.QUIT_AFFILIATION_BTN, "Quit Affiliaton Button");
			click(driver,Entity.QUIT_AFFILIATION_BTN, "Click on Quit Affiliaton Button");
			// RETAIN_CURRENT_DI_RADIO_BUTTON
			waitForElementPresent(driver,Affiliation.RETAIN_CURRENT_DI_RADIO_BUTTON,
					"Retain current DI radio Button confirming quitting the affiliation");
			assertElementPresent(driver,Affiliation.RETAIN_CURRENT_DI_RADIO_BUTTON,
					"Retain current DI radio Button confirming quitting the affiliation");
			click(driver,Affiliation.RETAIN_CURRENT_DI_RADIO_BUTTON, "Click on Retain current DI Radio Button");
			try {
				// QUITAFFILIATIONCOMMENTSECTTION
				// waitForElementPresent(driver,Affiliation.QUITAFFILIATIONCOMMENTSECTTION, "Comments
				// text box in confirming quitting the affiliation");
				assertElementPresent(driver,Affiliation.QUITAFFILIATIONCOMMENTSECTTION,
						"Comments text box in confirming quitting the affiliation");
				type(driver,Affiliation.QUITAFFILIATIONCOMMENTSECTTION, "quit affiliation",
						"Comments text box in confirming quitting the affiliation");
				// QUIT_THE_AFFILIATION_BTN
				waitForElementPresent(driver,Entity.QUIT_THE_AFFILIATION_BTN,
						"Quit the Affiliation Button confirming quitting the affiliation");
				assertElementPresent(driver,Entity.QUIT_THE_AFFILIATION_BTN,
						"Quit the Affiliation Button confirming quitting the affiliation");
				click(driver,Entity.QUIT_THE_AFFILIATION_BTN,
						"Click on Quit the Affiliation Button confirming quitting the affiliation");
				handlepopup();
			} catch (NoSuchElementException e) {
			}
			Thread.sleep(1000);
		}
	}

	public void joinEntityToAffiliation(String entityId, String affiliationId) throws Throwable {

		waitForElementToBeClickable(driver,HomePage.AFFILIATION_TAB, "Affiliation Search Link");
		click(driver,HomePage.AFFILIATION_TAB, "Affiliation Search");
		waitForElementPresent(driver,Affiliation.AFFILIATIONID, "Affiliation ID Text box");
		type(driver,Affiliation.AFFILIATIONID, affiliationId, "Affiliation Id text box");
		assertElementPresent(driver,Affiliation.SEARCHBTN, "Search Button in Affiliation search Page");
		click(driver,Affiliation.SEARCHBTN, "Search Button");
		// AFFILIATION_NAME
		waitForElementPresent(driver,Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		assertElementPresent(driver,Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		String affName = getText(driver,Affiliation.AFFILIATION_NAME, "Affiliation name in  Affiliation Profile Page");
		waitForElementToBeClickable(driver,HomePage.ENTITY_TAB, "Entity Search Link");
		click(driver,HomePage.ENTITY_TAB, "Entity Search");
		waitForElementPresent(driver,Entity.ENTITY_ID, "Entity ID Text box");
		// type(driver,Entity.ENTITY_ID, Excelobject.getCellData(reportSheet, "Entity Id",
		// count), "Entity Id text box");
		type(driver,Entity.ENTITY_ID, entityId, "Entity Id text box");
		assertElementPresent(driver,Entity.SEARCH_BTN, "Search Button in Entity Profile Page");
		click(driver,Entity.SEARCH_BTN, "Search Button");

		waitForElementToBeClickable(driver,Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		click(driver,Entity.JOIN_AFFILIATION_BTN, "Join Affiliation Button");
		// Enter an Affiliation Name and click on Find Button
		type(driver,Entity.AFFILIATION_NAME_SEARCH_TEXTBOX, affName, "Affiliation Name Search Text Box");
		waitForElementToBeClickable(driver,Entity.FINDBTN, "Find Btn");
		click(driver,Entity.FINDBTN, "Find Btn");
		// Click on First result from the grid
		try {
			List<WebElement> affiliation = driver.findElements(Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE);
			if (affiliation.size() > 0) {
				waitForElementToBeClickable(driver,Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
				click(driver,Entity.FIRST_RESULT_ON_PICK_AFFILAITION_PAGE, "First Result on Grid");
				// BULLETINRETAINCURRENTDI
				waitForElementPresent(driver,Affiliation.BULLETINRETAINCURRENTDI,
						" Bulletin Radio button in confirm joining affiliation Page");
				assertElementPresent(driver,Affiliation.BULLETINRETAINCURRENTDI,
						" Bulletin Radio button in confirm joining affiliation Page");
				click(driver,Affiliation.BULLETINRETAINCURRENTDI,
						" Bulletin Radio button in confirm joining affiliation Page");
				// COMMRETAINCURRENTDI
				assertElementPresent(driver,Affiliation.COMMRETAINCURRENTDI,
						" Communication Radio button in confirm joining affiliation Page");
				click(driver,Affiliation.COMMRETAINCURRENTDI,
						" Communication Radio button in confirm joining affiliation Page");
				// RENEWALINVOICERETAINCURRENTDI
				assertElementPresent(driver,Affiliation.RENEWALINVOICERETAINCURRENTDI,
						" REnewal Invoice radio button in confirm joining affiliation Page");
				click(driver,Affiliation.RENEWALINVOICERETAINCURRENTDI,
						"REnewal Invoice radio button in confirm joining affiliation Page");
				// SOPRETAINCURRENTDI
				assertElementPresent(driver,Affiliation.SOPRETAINCURRENTDI,
						" SOP Radio button in confirm joining affiliation Page");
				click(driver,Affiliation.SOPRETAINCURRENTDI, " SOP Radio button in confirm joining affiliation Page");
				// XSOPSUBGROUPDROPDWN
				assertElementPresent(driver,Affiliation.XSOPSUBGROUPDROPDWN,
						"XSOP drop down in confirm joining affiliation Page");
				selectByIndex(driver,Affiliation.XSOPSUBGROUPDROPDWN, 1, "XSOP drop down in confirm joining affiliation Page");
				// COMMENTS
				assertElementPresent(driver,Affiliation.COMMENTS, "Comments text box in confirm joining affiliation Page");
				type(driver,Affiliation.COMMENTS, "Test", "Comments text box in confirm joining affiliation Page");
				// JOINBTN
				assertElementPresent(driver,Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
				click(driver,Affiliation.JOINBTN, "Join button in confirm joining affiliation Page");
				Thread.sleep(2000);
			}
		} catch (NoSuchElementException e) {

		}
	}

	// public ArrayList<String> uploadTheFilesToScannerRBCPath(int totalRows) throws
	// Throwable{
	public ArrayList<String> uploadTheFilesToScannerRBCPath(int totalRows, String hardCopy, String environment)
			throws Throwable {
		String NasScanFirstPath = "";

		if (environment.equals("Stage")) {

			NasScanFirstPath = NasScanFirstPathStg;

		} else if (environment.equals("QA")) {

			NasScanFirstPath = NasScanFirstPathQA;
		}
		ArrayList<String> fileNames = new ArrayList<String>();
		String fileName = "Test" + getCurrentDate().split("\\/")[0] + getCurrentDate().split("\\/")[1];
		String currentFileName = null;
		String fileNameWithHardCopy = "";
		String desktopPath = System.getProperty("user.home") + "//Desktop";
		copyTheFile(TestFileXMLToUploadScanRBCOld, desktopPath, PowerShellToCopy);
		copyTheFile(TestFilePDFToUploadScanRBCOld, desktopPath, PowerShellToCopy);
		if (hardCopy.equals("Yes")) {
			fileNameWithHardCopy = fileName + "HCY";
			renameTheFiles(desktopPath + "\\SOPTest.XML", fileNameWithHardCopy + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\SOPTest.PDF", fileNameWithHardCopy + ".PDF", PowerShellToRename);
		} else if (hardCopy.equals("No")) {
			fileNameWithHardCopy = fileName + "HCN";
			renameTheFiles(desktopPath + "\\SOPTest.XML", fileNameWithHardCopy + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\SOPTest.PDF", fileNameWithHardCopy + ".PDF", PowerShellToRename);
		}
		// updateTheXML(desktopPath + "\\" + fileName + ".XML", getCurrentDate(),
		// PowerShellToUpdate);
		updateTheXML(desktopPath + "\\" + fileNameWithHardCopy + ".XML", getCurrentDate(), hardCopy,
				PowerShellToUpdate);
		// in above updateTheXML function needs to pass arg for Hard copy Yes or No
		int j = 0;

		for (int iLoop = 1; iLoop < totalRows; iLoop++) {
			/*
			 * String runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop); if
			 * (runStatus.trim().equalsIgnoreCase("Y")) {
			 */
			if (j == 1) {
				j++;
			}
			if (j == 0) {
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + ".XML", NasScanFirstPath, PowerShellToCopy);
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + ".PDF", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(15000);
				currentFileName = fileName + ".PDF";
				fileNames.add(currentFileName);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + ".XML", fileNameWithHardCopy + ++j + ".XML",
						PowerShellToRename);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + ".PDF", fileNameWithHardCopy + j + ".PDF",
						PowerShellToRename);
			} else if (j > 1) {
				int i = j - 1;
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + i + ".XML", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(10000);
				copyTheFile(desktopPath + "\\" + fileNameWithHardCopy + i + ".PDF", NasScanFirstPath, PowerShellToCopy);
				Thread.sleep(10000);
				currentFileName = fileName + i + ".PDF";
				fileNames.add(currentFileName);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + i + ".XML",
						fileNameWithHardCopy + j + ".XML", PowerShellToRename);
				renameTheFiles(desktopPath + "\\" + fileNameWithHardCopy + i + ".PDF",
						fileNameWithHardCopy + j + ".PDF", PowerShellToRename);
				j++;

			}
		}

		if (j == 1) {
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".PDF", PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".XML", PowerShellToDelete);
		} else {
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + --j + ".PDF", PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileNameWithHardCopy + j + ".XML", PowerShellToDelete);
		}
		Thread.sleep(140000);
		return fileNames;
	}

	// under this fxn one new fxn should be created wihch is forsearching
	// escalatedOr On hold esops
	// and run all the scenarios through that
	public String esopEscalatedOrOnHold(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			String escalated = Excelobject.getCellData(reportSheet, "Escalate", count);
			String onHold = Excelobject.getCellData(reportSheet, "Hold", count);
			String unidentifiedEntity = Excelobject.getCellData(reportSheet, "Unidentified Entity", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");

			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			// To run Sprint 33 and 34 us we need this to be uncommented
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			// CESSELECTBTN
			waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(2000);
			// CLOSE_THE_ML_SLIDER
			/*
			 * try { //waitForElementToBeClickable(driver,SOP.
			 * CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * click(driver,SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * }catch(NoSuchElementException e) {} catch(WebDriverException e) {}
			 */
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if (!arrowEntity.equals("")) {
				waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				if (branchPlant.equals("CTCORP")) {
					// CTCORP_RADIO_BUTTON
					assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
					click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

				} else if (branchPlant.equals("NRAI")) {
					// NRAI_RADIO_BUTTON
					assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
					click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");

				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
				selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				// SEARCH_BTN
				waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				click(driver,SOP.SEARCH_BTN, "Search button");
				// FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
				driver.switchTo().defaultContent();
				assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
				click(driver,SOP.GLYPHICON_HOME, "glyphicon button");
				driver.switchTo().frame("frame1");
				Thread.sleep(2000);

			} else if (!unidentifiedEntity.equals("")) {
				// UNIDENTIFIED_ENTITY_RADIO_BUTTON
				waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
				assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Unidentified entity radio button");
				click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "Click on Unidentified entity radio button");
				if (branchPlant.equals("CTCORP")) {
					// BRANCH_PLANT_UNIDENTIFIED_ENTITY
					waitForElementPresent(driver,SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(driver,SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(driver,SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "CTCORP", "Branch Plant drop down");

				} else if (branchPlant.equals("NRAI")) {
					// Select the drop down for NRAI
					waitForElementPresent(driver,SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					assertElementPresent(driver,SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "Branch Plant drop down");
					selectByVisibleText(driver,SOP.BRANCH_PLANT_UNIDENTIFIED_ENTITY, "NRAI", "Branch Plant drop down");
				}
				// ENTITY_TEXT_BOX
				waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
				assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity search text box on ESOP");
				type(driver,SOP.ENTITY_TEXT_BOX, unidentifiedEntity, "Entity search text box on ESOP");
				// DOMESTIC_JURISDICTION_SELECTION
				waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
				assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Domestic Jurisdiction in CES Page");
				selectByVisibleText(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Arizona",
						"Domestic Jurisdiction in CES Page");
				// REP_JURISDICTION_SELECTION
				waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
				assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction in CES Page");
				selectByVisibleText(driver,SOP.REP_JURISDICTION_SELECTION, "Arizona", "Rep Jurisdiction in CES Page");
			}
			// CASE_ID_TEXTBOX
			waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(driver,SOP.CASE_ID_TEXTBOX, caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(driver,SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text box");
			// DEFENDANT_TEXT_BOX
			waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text box");

			waitForElementPresent(driver,SOP.ESOPID, "ESOP ID");
			assertElementPresent(driver,SOP.ESOPID, "ESOP ID");
			esopId = getText(driver,SOP.ESOPID, "ESOP ID");

			if (!escalated.equals("")) {
				// ESCALATION_DETAILS
				waitForElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				// REASON_DRPDWN
				waitForElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(driver,SOP.REASON_DRPDWN, escalationReason, "Escalation reason text box");//
				// ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Entity escalated", "Escalation text box");
				// ESCALATE_BTN
				waitForElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
				click(driver,SOP.ESCALATE_BTN, "Escalate button");
			} else if (!onHold.equals("")) {
				// REASON_FOR_HOLD_TEXTBOX
				assertElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On hold text box in CES Page");
				type(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "On hold for verification",
						"Reason for On hold text box in CES Page");
				// ONHOLD_BTN
				waitForElementToBeClickable(driver,SOP.ONHOLD_BTN, "OnHold Button in CES Page");
				assertElementPresent(driver,SOP.ONHOLD_BTN, "OnHold Button in CES Page");
				click(driver,SOP.ONHOLD_BTN, "OnHold Button in CES Page");
			}

		} catch (Exception e) {
		}
		return esopId;
	}

	public void processEscalatedOrOnHoldESOP(String reportSheet, int count, String esopId) throws Throwable {

		try {
			String checkedArrowEntity = "";
			String caseNumber = "";
			String lawSuitType = "";
			String docType = "";
			String plaintiff = "";
			String defendant = "";
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "New Entity Searched", count);
			String relatedLog = Excelobject.getCellData(reportSheet, "Related Log", count);
			String hold = Excelobject.getCellData(reportSheet, "Hold", count);
			// CES_LEFT_NAV_LINK
			waitForElementToBeClickable(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Link in SOP List Page");
			if (!hold.equals("")) {
				// ON_HOLD_LIST_TAB
				waitForElementToBeClickable(driver,SOP.ON_HOLD_LIST_TAB, "OnHoldList button in CES Page");
				assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHoldList button in CES Page");
				click(driver,SOP.ON_HOLD_LIST_TAB, "OnHoldList button in CES Page");
			}
			// FILTERDROPDOWN1
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "First Filter in CES Page");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "First Filter in CES Page");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "ESOP Id", "First Filter in CES Page");
			// FILTERDROPDOWN2
			waitForElementPresent(driver,SOP.FILTERDROPDOWN2, "Second Filter in CES Page");
			assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Second Filter in CES Page");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "=", "Second Filter in CES Page");
			// FILTERTEXTFIELD
			assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Text box in CES Page");
			type(driver,SOP.FILTERTEXTFIELD, esopId, "Text box in CES Page");
			// FILTERGOBTN
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button in CES Page");
			click(driver,SOP.FILTERGOBTN, "Go Button in CES Page");
			if (hold.equals("")) {
				// FIRST_CES_SELECT_BUTTON
				waitForElementToBeClickable(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES select button in CES Page");
				assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES select button in CES Page");
				click(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES select button in CES Page");
			} else if (!hold.equals("")) {
				waitForElementToBeClickable(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES select button in CES Page");
				assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES select button in CES Page");
				click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES select button in CES Page");
			}
			Thread.sleep(1000);
			// CLOSE_THE_ML_SLIDER
			/*
			 * try { //waitForElementPresent(driver,SOP.
			 * CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * click(driver,SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * }catch(NoSuchElementException e) {} catch(WebDriverException e) {}
			 */
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			if (branchPlant.contains("NRAI")) {

				docType = getText(driver,SOP.SELECTED_DOC_TYPE, "Document Type drop down in CES Page");
			} else if (branchPlant.contains("CTCORP")) {
				lawSuitType = getText(driver,SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
			}
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			// TRACEABLE_MAIL_FIELD
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}
			plaintiff = getText(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
			defendant = getText(driver,SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
			caseNumber = getText(driver,SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			try {
				checkedArrowEntity = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
			} catch (NullPointerException e) {
			}
			if (checkedArrowEntity == null) {
				assertElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Arrow Entity Radio button");
				click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Click on Arrow Entity Radio button");
			}

			waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

			if (branchPlant.equals("CTCORP")) {
				// CTCORP_RADIO_BUTTON
				assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
				click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

			} else if (branchPlant.equals("NRAI")) {
				// NRAI_RADIO_BUTTON
				assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
				click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");

			}

			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");

			// SEARCH_BTN
			waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button in CES Page");
			assertElementPresent(driver,SOP.SEARCH_BTN, "Search button in CES Page");
			click(driver,SOP.SEARCH_BTN, "Search button in CES Page");
			Thread.sleep(2000);
			// UNIDENTIFIED_ENTITY_BTN
			List<WebElement> entityNotFound = null;
			try {
				entityNotFound = driver.findElements(SOP.FIRST_ENTITY_IN_SEARCH_RESULT);
			} catch (NoSuchElementException e) {
			}
			if (entityNotFound == null) {
				assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "unidentified Entity button in CES Page");
				click(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "click on unidentified Entity button in CES Page");
				Thread.sleep(2000);

				if (branchPlant.contains("NRAI")) {
					waitForElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
					Thread.sleep(1000);
					String newDocType = getText(driver,SOP.SELECTED_DOC_TYPE, "selected Doc type value");
					printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
				} else if (branchPlant.contains("CTCORP")) {
					waitForElementPresent(driver,SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
					Thread.sleep(1000);
					String newLawSuitType = getText(driver,SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
					printMessageInReport(
							"Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);
				}
			} else if (entityNotFound != null) {
				// REP_STATUS_SORT
				waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
				assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
				click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
				// FIRST_ENTITY_IN_SEARCH_RESULT
				waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
				assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First entity link in CES Page");
				click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "click on First entity link in CES Page");
				if (relatedLog.equals("")) {
					driver.switchTo().defaultContent();
					assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					click(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(1000);
					driver.switchTo().frame("frame1");
					Thread.sleep(1000);

				} else if (!relatedLog.equals("")) {
					// WORKSHEET_ID_TEXTBOX
					waitForElementPresent(driver,SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					assertElementPresent(driver,SOP.WORKSHEET_ID_TEXTBOX, "Worksheet id text box in CES Page");
					type(driver,SOP.WORKSHEET_ID_TEXTBOX, relatedLog, "Worksheet id text box in CES Page");
					// SEARCH_BTN
					assertElementPresent(driver,SOP.SEARCH_BTN, "Search button in CES Page");
					click(driver,SOP.SEARCH_BTN, "Click on Search button in CES Page");
					// FIRST_WORKSHEET_RADIO_BTN
					waitForElementPresent(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
							"First Worksheet id radio button in Related Worksheet Page");
					assertElementPresent(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
							"First Worksheet id radio button in Related Worksheet Page");
					click(driver,SOP.FIRST_WORKSHEET_RADIO_BTN, "First Worksheet id radio button in Related Worksheet Page");
					// ADD_MANIFEST_BTN
					assertElementPresent(driver,SOP.ADD_MANIFEST_BTN,
							"Add to docket history button in Related Worksheet Page");
					click(driver,SOP.ADD_MANIFEST_BTN, "Add to docket history button in Related Worksheet Page");
					Thread.sleep(1000);
				}
			}
			if (branchPlant.contains("NRAI")) {
				waitForElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				Thread.sleep(1000);
				String newDocType = getText(driver,SOP.SELECTED_DOC_TYPE, "selected Doc type value");
				printMessageInReport("Previous docType : " + docType + " and new docType : " + newDocType);
			} else if (branchPlant.contains("CTCORP")) {
				waitForElementPresent(driver,SOP.SELECTED_LAWSUIT_TYPE, "Law Suit Type Type drop down in CES Page");
				Thread.sleep(1000);
				String newLawSuitType = getText(driver,SOP.SELECTED_LAWSUIT_TYPE, "selected Law Suit type value");
				printMessageInReport(
						"Previous lawsuitType : " + lawSuitType + " and new lawSuitType : " + newLawSuitType);
			}
			String newPlaintiff = getText(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff value in CES Page");
			Thread.sleep(1000);
			String newDefendant = getText(driver,SOP.DEFENDANT_TEXT_BOX, "defendant value in CES Page");
			Thread.sleep(1000);
			String newCaseNumber = getText(driver,SOP.CASE_ID_TEXTBOX, "case number value in CES Page");
			// SUBMIT_CES
			waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			click(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			printMessageInReport("Previous plaintiff : " + plaintiff + " and new plaintiff : " + newPlaintiff);
			printMessageInReport("Previous defendant : " + defendant + " and new defendant : " + newDefendant);
			printMessageInReport("Previous case number : " + caseNumber + " and new case Number : " + newCaseNumber);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String validatePlaintiffAndDefendantFieldsAreMandatory(String reportSheet, int count) throws Throwable {

		String esopId = null;
		try {

			String plaintiffError = Excelobject.getCellData(reportSheet, "Plaintiff Error", count);
			String defendantError = Excelobject.getCellData(reportSheet, "Defendant Error", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String caseNumber = Excelobject.getCellData(reportSheet, "Case Number", count);
			String lawSuitType = Excelobject.getCellData(reportSheet, "LawSuit Type", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			// CESSELECTBTN
			waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(3000);
			// CLOSE_THE_ML_SLIDER
			/*
			 * try { //waitForElementToBeClickable(driver,SOP.
			 * CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * click(driver,SOP.CLOSE_THE_ML_SLIDER,"Close the ML Slider CES Page");
			 * }catch(NoSuchElementException e) {} catch(WebDriverException e) {}
			 */
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
			if (branchPlant.equals("CTCORP")) {
				// CTCORP_RADIO_BUTTON
				assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
				click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

			} else if (branchPlant.equals("NRAI")) {
				// NRAI_RADIO_BUTTON
				assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
				click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");

			}
			// ENTITY_NAME_TEXTFIELD
			waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
			// (SOP.FILTERTEXTFIELD, filename, "Filter text field");
			selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
			// SEARCH_BTN
			waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
			assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
			click(driver,SOP.SEARCH_BTN, "Search button");
			// REP_STATUS_SORT
			waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
			assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
			click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
			// FIRST_ENTITY_IN_SEARCH_RESULT
			waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
			driver.switchTo().defaultContent();
			assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
			click(driver,SOP.GLYPHICON_HOME, "glyphicon button");
			waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			esopId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
			driver.switchTo().frame("frame1");
			Thread.sleep(2000);
			List<WebElement> traceableMail = null;
			// TRACEABLE_MAIL_FIELD
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}

			// CASE_ID_TEXTBOX
			waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Number text box");
			assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Number text box");
			type(driver,SOP.CASE_ID_TEXTBOX, caseNumber, "Case Number text box");
			if (branchPlant.equals("CTCORP")) {
				waitForElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law suit Type drop down");
				assertElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuitType, "Law Suit Type drop down");
			} else if (branchPlant.equals("NRAI")) {
				waitForElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				assertElementPresent(driver,SOP.NRAI_DOCUMENT_TYPE, "Document Type drop down in CES Page");
				selectByVisibleText(driver,SOP.NRAI_DOCUMENT_TYPE, lawSuitType, "Document Type drop down in CES Page");

			}
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box");
			type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text box");
			// DEFENDANT_TEXT_BOX
			waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "Defendant text box");
			type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text box");

			// SUBMIT_CES
			waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			click(driver,SOP.SUBMIT_CES, "Click on Submit button in CES Page");
			if (plaintiff.equals("")) {
				waitForElementPresent(driver,SOP.PLAINTIFF_EMPTY_ERROR, "Enter Plaintiff value in CES Page");
				assertElementPresent(driver,SOP.PLAINTIFF_EMPTY_ERROR, "Enter Plaintiff value in CES Page");
				compareStrings(plaintiffError, getText(driver,SOP.PLAINTIFF_EMPTY_ERROR, "Enter Plaintiff value in CES Page"));
			}
			if (defendant.equals("")) {
				// DEFENDANT_EMPTY_ERROR
				waitForElementPresent(driver,SOP.DEFENDANT_EMPTY_ERROR, "Enter Defendant value in CES Page");
				assertElementPresent(driver,SOP.DEFENDANT_EMPTY_ERROR, "Enter Defendant value in CES Page");
				compareStrings(defendantError, getText(driver,SOP.DEFENDANT_EMPTY_ERROR, "Enter Defendant value in CES Page"));
			}

		} catch (Exception e) {
		}
		return esopId.split("\\: ")[1];

	}

	public void changeTheCESFieldOrder() throws Throwable {
		try {
			// ADMIN_TAB
			waitForElementPresent(driver,Admin.ADMIN_TAB, "Admin Tab");
			assertElementPresent(driver,Admin.ADMIN_TAB, "Admin Tab");
			click(driver,Admin.ADMIN_TAB, "Click on Admin Tab");
			// MANAGECESMLSLIDERFIELDSLINK
			waitForElementPresent(driver,Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			assertElementPresent(driver,Admin.MANAGECESMLSLIDERFIELDSLINK, "Manage CES ML Slider Fields Link");
			click(driver,Admin.MANAGECESMLSLIDERFIELDSLINK, "Click on Manage CES ML Slider Fields Link");
			// before moving
			// changing DEFENDANT_INDEX -> Law Suit Type
			// String dftIndex = getText(driver,Admin.DEFENDANT_INDEX,"Defendant Index value before
			// moving");
			String dftIndex = getText(driver,Admin.LAWSUIT_SUBTYPE_INDEX, "Defendant Index value before moving");
			// below is used for Law Suit Type
			By newPlaintiff = By.xpath("//ul[@id='sortable3']//li[" + dftIndex + "]");
			// hard codeing the index below
			// PLAINTIFF_CES_ML_SLIDER_FIELD
			// changing PLAINTIFF_CES_ML_SLIDER_FIELD -> LAW_SUIT_type(driver,which is actually
			// Case#
			// waitForElementPresent(driver,Admin.PLAINTIFF_CES_ML_SLIDER_FIELD,"Plaintiff field in
			// CES ML Slider Fields");
			waitForElementPresent(driver,Admin.LAW_SUIT_TYPE, "Plaintiff field in CES ML Slider Fields");
			// DEFENDANT_CES_ML_SLIDER_FIELD
			// waitForElementPresent(driver,Admin.DEFENDANT_CES_ML_SLIDER_FIELD,"Defendant field in
			// CES ML Slider Fields");
			// commenting below
			// draganddrop(Admin.PLAINTIFF_CES_ML_SLIDER_FIELD,newPlaintiff,"Move source to
			// Target");
			draganddrop(Admin.LAW_SUIT_TYPE, newPlaintiff, "Move source to Target");
			Thread.sleep(5000);
			// Below code is committed
			/*
			 * Thread.sleep(2000); String plaintiffIndex =
			 * getText(driver,Admin.PLAINTIFF_INDEX,"Plaintiff Index value after moving"); String
			 * defendantIndex =
			 * getText(driver,Admin.DEFENDANT_INDEX,"Defendant Index value after moving");
			 * waitForElementPresent(driver,Admin.SAVEBTN, "save button");
			 * assertElementPresent(driver,Admin.SAVEBTN, "save button"); click(driver,Admin.SAVEBTN,
			 * "Save Button"); waitForElementPresent(driver,SOP.SOP_LINK_HEADER,
			 * "SOP Link in Header"); assertElementPresent(driver,SOP.SOP_LINK_HEADER,
			 * "SOP Link in Header"); click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			 * //CES_LEFT_NAV_LINK
			 * waitForElementToBeClickable(driver,SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page"
			 * ); assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK,"CES Link in SOP List Page");
			 * click(driver,SOP.CES_LEFT_NAV_LINK,"Click on CES Link in SOP List Page");
			 * waitForElementPresent(driver,SOP.
			 * FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			 * assertElementPresent(driver,SOP.
			 * FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			 * click(driver,SOP.FIRST_CES_SELECT_BUTTON,"First CES select button in CES Page");
			 * //ML_SLIDER_FIELDS_CES_PAGE String plaintiffIndexInCESPage =
			 * String.valueOf(returnIndexOfMatchedTextvalue(driver,SOP.ML_SLIDER_FIELDS_CES_PAGE,
			 * "Plaintiff") + 1); String defendantIndexInCESPage =
			 * String.valueOf(returnIndexOfMatchedTextvalue(driver,SOP.ML_SLIDER_FIELDS_CES_PAGE,
			 * "Defendant") + 1); compareStrings(plaintiffIndex,plaintiffIndexInCESPage);
			 * compareStrings(defendantIndex,defendantIndexInCESPage);
			 * driver.switchTo().frame("frame1"); Thread.sleep(2000);
			 */
		} catch (Exception e) {
		}
	}

	public void workSheetContainsPlaintiffAndDefendantValuesAsESOP(String reportSheet, int count, String esopId)
			throws Throwable {
		try {

			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			// FIRST_SOP_CHECKBOX
			searchForESOP(driver,esopId);
			try {
				WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
				waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);

			} catch (NoSuchElementException e) {
			}
			Thread.sleep(5000);
			selectAndAssignTheFileToTeam();
			Thread.sleep(5000);
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			searchForESOP(driver,esopId);
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			waitForElementPresent(driver,SOP.VIEW_BTN, "View button");
			assertElementPresent(driver,SOP.VIEW_BTN, "View button");
			click(driver,SOP.VIEW_BTN, "View button");
			handlePopUpWindwow(driver);
			driver.close();
			driver.switchTo().window(parentWindow);
			Thread.sleep(3000);
			WebElement createWs = null;
			try {
				createWs = driver.findElement(SOP.CREATE_WORKSHEET);
				waitForElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
			} catch (NoSuchElementException e) {
			}
			if (createWs == null) {
				Thread.sleep(4000);
				selectAndAssignTheFileToTeam();
				Thread.sleep(4000);
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);
				Thread.sleep(2000);
				String parentWin = driver.getWindowHandle();
				waitForElementPresent(driver,SOP.VIEW_BTN, "View button");
				assertElementPresent(driver,SOP.VIEW_BTN, "View button");
				click(driver,SOP.VIEW_BTN, "View button");
				handlePopUpWindwow(driver);
				driver.close();
				driver.switchTo().window(parentWin);
				waitForElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				assertElementPresent(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
				click(driver,SOP.CREATE_WORKSHEET, "Create Worksheet button");
			}

			Thread.sleep(2000);
			// CERTIFIED_MAIL_NUMBER
			waitForElementPresent(driver,SOP.CERTIFIED_MAIL_NUMBER, "certified mail number text box");
			assertElementPresent(driver,SOP.CERTIFIED_MAIL_NUMBER, "certified mail number text box");
			String traceableMail = getText(driver,SOP.CERTIFIED_MAIL_NUMBER, "certified mail number text box");
			printMessageInReport("Value of Traceable Mail Field : " + traceableMail);
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plantiff text field");
			assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plantiff text field");
			String worksheetPltf = getAttribute(driver,SOP.PLAINTIFF_TEXT_BOX, "value");
			compareStrings(plaintiff, worksheetPltf);
			// DEFENDANT_TEXTFIELD
			waitForElementPresent(driver,SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
			assertElementPresent(driver,SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
			String worksheetDft = getText(driver,SOP.DEFENDANT_TEXTFIELD, "Defendent text box");
			compareStrings(defendant, worksheetDft);
		} catch (Exception e) {
		}
	}

	public void rejectionListForPosssibleRejection(String reportSheet, int count) throws Throwable {
		try {
			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			// CES_LEFT_NAV_LINK
			waitForElementToBeClickable(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in SOP List Page");
			click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Link in SOP List Page");
			Thread.sleep(1500);
			// REJECTION_LIST_TAB
			List<WebElement> rejectionListTab = null;
			try {
				rejectionListTab = driver.findElements(SOP.REJECTION_LIST_TAB);
				if (rejectionListTab != null) {
					click(driver,SOP.REJECTION_LIST_TAB, "Click on REjection List Tab in CES Page");
					// CREATED_ON_SORTING_LINK
					waitForElementPresent(driver,SOP.CREATED_ON_SORTING_LINK, "Created On link in Rejection List Tab");
					assertElementPresent(driver,SOP.CREATED_ON_SORTING_LINK, "Created On link in Rejection List Tab");
					assertElementPresent(driver,SOP.FILE_NAME_SORTING_LINK, "File Name link in Rejection List Tab");
					assertElementPresent(driver,SOP.ESOP_ID_SORTING_LINK, "File Name link in Rejection List Tab");
					assertElementPresent(driver,SOP.ESCALATED_ON_SORTING_LINK, "File Name link in Rejection List Tab");
					assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down in Rejection List Tab");
					assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Second Filter drop down in Rejection List Tab");
					assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button in Rejection List Tab");
					assertElementPresent(driver,Invoice.FIRST_NAVIGATION_ABOVE_GRID, "First link in Rejection List Tab");
					assertElementPresent(driver,Invoice.PREVIOUS_NAVIGATION_ABOVE_GRID, "Previous link in Rejection List Tab");
					assertElementPresent(driver,Invoice.NEXT_NAVIGATION_ABOVE_GRID, "Next link in Rejection List Tab");
					assertElementPresent(driver,Invoice.LAST_NAVIGATION_ABOVE_GRID, "Last link in Rejection List Tab");
					assertElementPresent(driver,Entity.PSOP_INVOICES_CURRENT_FILTER,
							"Current Filter label in Rejection List Tab");
				}
			} catch (NoSuchElementException e) {
			}
			if (rejectionListTab == null) {

				printMessageInReport("For the Logged in Member there are no permission to Rejection List");
			}
		} catch (Exception e) {
		}

	}

	public void rejectionRulesMaintenanceApplication(String reportSheet, int count) throws Throwable {
		try {

			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(driver,SOP.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(driver,SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			click(driver,SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			// PAGE_TITLE
			waitForElementPresent(driver,SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			assertElementPresent(driver,SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			String pageTitle = getText(driver,SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			// US_RADIO_BTN
			waitForElementPresent(driver,SOP.US_RADIO_BTN, "US Radio button");
			assertElementPresent(driver,SOP.US_RADIO_BTN, "US Radio button");
			waitForElementPresent(driver,SOP.US_LABEL, "US label");
			assertElementPresent(driver,SOP.US_LABEL, "US label");
			// CANADA_RADIO_BTN
			waitForElementPresent(driver,SOP.CANADA_RADIO_BTN, "Canada Radio button");
			assertElementPresent(driver,SOP.CANADA_RADIO_BTN, "canada Radio button");
			waitForElementPresent(driver,SOP.CANADA_LABEL, "Canada label");
			assertElementPresent(driver,SOP.CANADA_LABEL, "canada label");
			waitForElementPresent(driver,SOP.INTERNATIONAL_RADIO_BTN, "International Radio button");
			assertElementPresent(driver,SOP.INTERNATIONAL_RADIO_BTN, "International Radio button");
			waitForElementPresent(driver,SOP.INTERNATIONAL_LABEL, "International label");
			assertElementPresent(driver,SOP.INTERNATIONAL_LABEL, "International label");
			// JURIS_DRP_DWN
			waitForElementPresent(driver,SOP.JURIS_DRP_DWN, "Jurisdiction drop down");
			assertElementPresent(driver,SOP.JURIS_DRP_DWN, "Jurisdiction drop down");
			// ADD_BUTTON
			waitForElementPresent(driver,SOP.ADD_BUTTON, "Add button in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.ADD_BUTTON, "Add button in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.SORT_BY_JURISDICTION_LABEL,
					"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.SORT_BY_JURISDICTION_LABEL,
					"Sort by Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.SORT_BY_MODIFIED_BY_LABEL,
					"Sort by Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.SORT_BY_MODIFIED_BY_LABEL,
					"Sort by Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.SORT_BY_MODIFIED_DATE_LABEL,
					"Sort by Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.SORT_BY_MODIFIED_DATE_LABEL,
					"Sort by Modified Date in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.TABLE_HEADER_JURISDICTION,
					"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.TABLE_HEADER_JURISDICTION,
					"Table header Jurisdiction in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.TABLE_HEADER_MODIFIED_BY,
					"Table header Modified By in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.TABLE_HEADER_MODIFIED_BY,
					"Table header Modified By in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.TABLE_HEADER_MODIFIED_DATE,
					"Table header Modified Date in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.TABLE_HEADER_MODIFIED_DATE,
					"Table header Modified Date in SOP Rejection Rules Maintenance");
			// FIRST_EDIT_BUTTON
			waitForElementPresent(driver,SOP.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			click(driver,SOP.FIRST_EDIT_BUTTON, "First Edit button in SOP Rejection Rules Maintenance");
			// REJECTION_RULE_DROP_DOWN
			waitForElementPresent(driver,SOP.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(driver,SOP.REJECTION_RULE_DROP_DOWN, "Rejection Rule in SOP Rejection Rules by Jurisdiction");

			if (addEditOrDel.equals("Add")) {
				selectByVisibleText(driver,SOP.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			} else if (addEditOrDel.equals("Edit")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(driver,SOP.REJECTION_RULE1_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(driver,SOP.REJECTION_RULE2_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}
			} else if (addEditOrDel.equals("Delete")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(driver,SOP.REJECTION_RULE1_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
					Thread.sleep(1000);
					handlepopup();
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(driver,SOP.REJECTION_RULE2_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
					Thread.sleep(1000);
					handlepopup();
				}

			}
			// STATUS_TEXT_FIELD
			waitForElementPresent(driver,SOP.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			type(driver,SOP.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
			waitForElementPresent(driver,SOP.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,SOP.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
			type(driver,SOP.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
			if (addEditOrDel.equals("Add")) {
				click(driver,SOP.ADD_BTN, "Add button in SOP Rejection Rules by Jurisdiction");
			} else if (addEditOrDel.equals("Edit")) {
				click(driver,SOP.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
			}

		} catch (Exception e) {
		}
	}

	public void selectTheJurisdictionAndEdit(String reportSheet, int count) throws Throwable {
		try {

			String addEditOrDel = Excelobject.getCellData(reportSheet, "Rule", count);
			String ruleText = Excelobject.getCellData(reportSheet, "Rule Text", count);
			String status = Excelobject.getCellData(reportSheet, "Status", count);
			String action = Excelobject.getCellData(reportSheet, "Action", count);
			String state = Excelobject.getCellData(reportSheet, "State", count);
			String jurisId = Excelobject.getCellData(reportSheet, "Juris Id", count);
			String ruleType = Excelobject.getCellData(reportSheet, "Rule Type", count);
			String selectJurisdiction = Excelobject.getCellData(reportSheet, "Select Jurisdiction", count);
			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(driver,SOP.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(driver,SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			click(driver,SOP.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			// PAGE_TITLE
			waitForElementPresent(driver,SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			assertElementPresent(driver,SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			String pageTitle = getText(driver,SOP.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
			compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			if (selectJurisdiction.equals("US")) {
				// US_RADIO_BTN
				waitForElementPresent(driver,Admin.US_RADIO_BTN, "US Radio button");
				assertElementPresent(driver,Admin.US_RADIO_BTN, "US Radio button");
				click(driver,Admin.US_RADIO_BTN, "US Radio button");
			}
			// CANADA_RADIO_BTN
			else if (selectJurisdiction.equals("Canada")) {
				waitForElementPresent(driver,Admin.CANADA_RADIO_BTN, "Canada Radio button");
				assertElementPresent(driver,Admin.CANADA_RADIO_BTN, "canada Radio button");
				click(driver,Admin.CANADA_RADIO_BTN, "canada Radio button");
			} else if (selectJurisdiction.equals("International")) {
				waitForElementPresent(driver,Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
				assertElementPresent(driver,Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
				click(driver,Admin.INTERNATIONAL_RADIO_BTN, "International Radio button");
			}
			// ("//span[contains(text(),'Quebec')]/parent::td/following-sibling::td/a/img")
			By editButton = By.xpath("//span[contains(text(),'" + state + "')]/parent::td/following-sibling::td/a/img");
			waitForElementPresent(driver,editButton, "Edit button for the selected State in SOP Rejection Rules Maintenance");
			assertElementPresent(driver,editButton, "Edit button for the selected state in SOP Rejection Rules Maintenance");
			click(driver,editButton, "Edit button for the selected state in SOP Rejection Rules Maintenance");
			// REJECTION_RULE_DROP_DOWN
			waitForElementPresent(driver,Admin.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			assertElementPresent(driver,Admin.REJECTION_RULE_DROP_DOWN,
					"Rejection Rule in SOP Rejection Rules by Jurisdiction");
			if (addEditOrDel.equals("Add")) {
				selectByVisibleText(driver,Admin.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
				waitForElementPresent(driver,Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(driver,Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(driver,Admin.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(driver,Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(driver,Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(driver,Admin.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
				// ADD_BTN
				waitForElementPresent(driver,Admin.ADD_BTN, "Add button in SOP Rejection Rules Maintenance");
				assertElementPresent(driver,Admin.ADD_BTN, "Add button in SOP Rejection Rules Maintenance");
				click(driver,Admin.ADD_BTN, "Add button in SOP Rejection Rules Maintenance");
				Thread.sleep(1000);
				ArrayList<String> actionStatus = SQL_Queries.getTheStatusAndActionForRejectionRule(jurisId, ruleType);
				compareStrings(status, actionStatus.get(0));
				compareStrings(action, actionStatus.get(1));
			} else if (addEditOrDel.equals("Edit")) {

				if (ruleText.equals("SOS/Arrow Entity Statuses")) {

					click(driver,Admin.REJECTION_RULE1_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}

				else if (ruleText.equals("Post Descriptive - Take or Reject")) {

					click(driver,Admin.REJECTION_RULE2_FIRST_EDIT, "First Edit button in SOP Rejection Rules Maintenance");
				}
				selectByVisibleText(driver,Admin.REJECTION_RULE_DROP_DOWN, ruleText,
						"Rejection Rule in SOP Rejection Rules by Jurisdiction");
				waitForElementPresent(driver,Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(driver,Admin.STATUS_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(driver,Admin.STATUS_TEXT_FIELD, status, "Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(driver,Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				assertElementPresent(driver,Admin.ACTION_TEXT_FIELD, "Status text field in SOP Rejection Rules Maintenance");
				type(driver,Admin.ACTION_TEXT_FIELD, action, "Status text field in SOP Rejection Rules Maintenance");
				waitForElementPresent(driver,Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
				assertElementPresent(driver,Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
				click(driver,Admin.SAVE_BUTTON, "Save button in SOP Rejection Rules by Jurisdiction");
				ArrayList<String> actionStatus = SQL_Queries.getTheStatusAndActionForRejectionRule(jurisId, ruleType);
				compareStrings(status, actionStatus.get(0));
				compareStrings(action, actionStatus.get(1));
			} else if (addEditOrDel.equals("Delete")) {

				ArrayList<String> countBeforeDeletingTheRule = SQL_Queries.countBeforeDeletingTheRule(jurisId,
						ruleType);
				if (ruleText.equals("SOS/Arrow Entity Statuses")) {
					click(driver,Admin.REJECTION_RULE1_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
				} else if (ruleText.equals("Post Descriptive - Take or Reject")) {
					click(driver,Admin.REJECTION_RULE2_FIRST_DELETE, "First Delete button in SOP Rejection Rules Maintenance");
				}
				Thread.sleep(1000);
				handlepopup();
				Thread.sleep(1000);
				printMessageInReport("The count of Rule before deleting : " + countBeforeDeletingTheRule);
				printMessageInReport("The count of Rule after deleting : "
						+ SQL_Queries.countAfterDeletingTheRule(jurisId, ruleType));

			}
		} catch (Exception e) {
		}
	}

	public void rejectionRulesMaintenanceRole(String reportSheet, int count) throws Throwable {
		try {
			String role = Excelobject.getCellData(reportSheet, "Role", count);

			// ADMIN_TAB
			waitForElementPresent(driver,Admin.ADMIN_TAB, "Admin Tab in the header");
			assertElementPresent(driver,Admin.ADMIN_TAB, "Admin Tab in the header");
			click(driver,Admin.ADMIN_TAB, "Admin Tab in the header");
			// FIRST_FILTER_DRPDWN
			waitForElementPresent(driver,Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
			assertElementPresent(driver,Admin.FIRST_FILTER_DRPDWN, "First filer in Roles Page");
			selectByVisibleText(driver,Admin.FIRST_FILTER_DRPDWN, "Role Name", "First filer in Roles Page");
			// SECOND_FILTER_DRPDWN
			waitForElementPresent(driver,Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
			assertElementPresent(driver,Admin.SECOND_FILTER_DRPDWN, "Second filer in Roles Page");
			selectByVisibleText(driver,Admin.SECOND_FILTER_DRPDWN, "contains", "Second filer in Roles Page");
			// FILTER_TEXT_FILED
			waitForElementPresent(driver,Admin.FILTER_TEXT_FILED, "text field in Roles Page");
			assertElementPresent(driver,Admin.FILTER_TEXT_FILED, "text field in Roles Page");
			type(driver,Admin.FILTER_TEXT_FILED, role, "text field in Roles Page");
			// GO_BTN
			waitForElementPresent(driver,Admin.GO_BTN, "Go Button in Roles Page");
			assertElementPresent(driver,Admin.GO_BTN, "Go Button in Roles Page");
			click(driver,Admin.GO_BTN, "Go Button in Roles Page");
			// FIRST_ROLE_ON_THE_GRID
			waitForElementPresent(driver,Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			assertElementPresent(driver,Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			click(driver,Admin.FIRST_ROLE_ON_THE_GRID, "First role link in Roles Page");
			// EDIT_BTN
			waitForElementPresent(driver,Admin.EDIT_BTN, "Edit button link in Roles Page");
			assertElementPresent(driver,Admin.EDIT_BTN, "Edit button link in Roles Page");
			click(driver,Admin.EDIT_BTN, "Edit button link in Roles Page");
			Thread.sleep(1000);
			// need to pass arg for check and un check
			String checkedRjectionRuleMaintenance = null;
			try {

				checkedRjectionRuleMaintenance = getAttribute(driver,Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX, "checked");

			} catch (NoSuchElementException e) {
			}
			// REJECTION_RULE_MAINTENANCE_CHECK_BOX
			assertElementPresent(driver,Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX,
					"Rejection Rules Maintenance check box in Roles Page");
			click(driver,Admin.REJECTION_RULE_MAINTENANCE_CHECK_BOX, "Rejection Rules Maintenance check box in Roles Page");
			// SAVEBTN
			waitForElementPresent(driver,Admin.SAVEBTN, "save button link in Roles Page");
			assertElementPresent(driver,Admin.SAVEBTN, "save button link in Roles Page");
			click(driver,Admin.SAVEBTN, "save button link in Roles Page");
			Thread.sleep(1000);
			if (checkedRjectionRuleMaintenance != null) {
				waitForElementPresent(driver,Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin");
				assertElementPresent(driver,Admin.EDIT_BTN, "Edit button link in Roles Page");
				compareStrings("No permissions",
						getText(driver,Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin"));
			} else if (checkedRjectionRuleMaintenance == null) {
				waitForElementPresent(driver,Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin");
				assertElementPresent(driver,Admin.EDIT_BTN, "Edit button link in Roles Page");
				compareStrings("Rejection Rules Maintenance",
						getText(driver,Admin.PERMISSIONS_UNDER_ADMIN_PERMISSION, "Permissions under Admin"));
			}
			Thread.sleep(5000);

		} catch (Exception e) {
		}
	}

	public void rejectionRulesMaintenanceAccess(String reportSheet, int count) throws Throwable {
		try {
			String permission = Excelobject.getCellData(reportSheet, "Permission", count);
			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			// REJECTION_RULE_MAINTENANCE_LINK
			waitForElementPresent(driver,Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			assertElementPresent(driver,Admin.REJECTION_RULE_MAINTENANCE_LINK,
					"Rejection Rule Maintenance link in lft nav bar");
			click(driver,Admin.REJECTION_RULE_MAINTENANCE_LINK, "Rejection Rule Maintenance link in lft nav bar");
			Thread.sleep(1000);
			driver.navigate().back();
			Thread.sleep(3000);
			driver.navigate().forward();
			if (permission.equals("Y")) {
				// PAGE_TITLE
				waitForElementPresent(driver,Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				assertElementPresent(driver,Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				String pageTitle = getText(driver,Admin.PAGE_TITLE, "Rejection Rule Maintenance Page Title");
				compareStrings("SOP Rejection Rules Maintenance", pageTitle);
			} else if (permission.equals("N")) {
				// SECURITY_ERROR
				waitForElementPresent(driver,Admin.SECURITY_ERROR, "Rejection Rule Maintenance Page Title");
				// assertElementPresent(driver,Admin.SECURITY_ERROR,"Rejection Rule Maintenance Page
				// Title");
				compareStrings("Security Error Occurred",
						getText(driver,Admin.SECURITY_ERROR, "Rejection Rule Maintenance Page Title"));
			}
		} catch (Exception e) {
		}
	}

	public void helpPageInCESQueue(String reportSheet, int count) throws Throwable {

		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			// CES_LEFT_NAV_LINK
			waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			click(driver,SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
			if (cesQueue.equals("New")) {
				// UNPROCESSED_COUNT
				waitForElementPresent(driver,SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(driver,SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(driver,SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");

			} else if (cesQueue.equals("Escalated List")) {
				// ESCALATED_LIST_TAB
				waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
				// FIRST_CES_SELECT_BUTTON
				waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			}

			else if (cesQueue.equals("OnHold List")) {
				// ON_HOLD_LIST_TAB
				waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// FIRST_ONHOLD_CES_SELECT_BUTTON
				waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				// create on filter search for New York SOP Team
			}

			else if (cesQueue.equals("Rejections List")) {
				// REJECTION_LIST_TAB
				waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// REJECTIONS_LIST_FIRST_CES_SELECT
				waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");

			}
			// HELP_PAGE_ICON
			waitForElementPresent(driver,SOP.HELP_PAGE_ICON, "Help Page icon");
			assertElementPresent(driver,SOP.HELP_PAGE_ICON, "Help Page icon");
			click(driver,SOP.HELP_PAGE_ICON, "Help Page icon");
			Thread.sleep(2000);
			String parentWindow = driver.getWindowHandle();
			handlePopUpWindwow(driver);
			// TITLE_CES_HELP_PAGE
			waitForElementPresent(driver,SOP.TITLE_CES_HELP_PAGE, "Help Page Title");
			assertElementPresent(driver,SOP.TITLE_CES_HELP_PAGE, "Help Page Title");
			String helpPageTitle = getText(driver,SOP.TITLE_CES_HELP_PAGE, "Help Page Title");
			compareStrings("Centralized Entity Selection - CES Processing Item tab", helpPageTitle);
			driver.close();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
		}
	}

	public String entitySectionDetailsOnProcessingCES(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {
			String caseNumber = "";
			int relatedWorksheet = 0;
			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String caseNum2 = Excelobject.getCellData(reportSheet, "New Case Number", count);
			String escalationReason = Excelobject.getCellData(reportSheet, "Escalation Reason", count);
			String rejectionReason = Excelobject.getCellData(reportSheet, "Rejection Reason", count);
			String notRejecting = Excelobject.getCellData(reportSheet, "Reason for Not Rejecting", count);
			String error = Excelobject.getCellData(reportSheet, "Error Message", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String reject = Excelobject.getCellData(reportSheet, "Reject", count);
			String onHold = Excelobject.getCellData(reportSheet, "On Hold", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			// String worksheetType = Excelobject.getCellData(reportSheet, "WorkSheet Type",
			// count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			if (levelOfUser.equals("Level1")) {
				// CES_LEFT_NAV_LINK
				waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				click(driver,SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
				// UNPROCESSED_COUNT
				waitForElementPresent(driver,SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(driver,SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(driver,SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
				Thread.sleep(1000);
				waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				esopId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				Thread.sleep(2000);
				driver.switchTo().frame("frame1");
				Thread.sleep(3000);
			}

			else if (!levelOfUser.equals("Level1")) {
				if (cesQueue.equals("New")) {
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					click(driver,SOP.CLEARBTN, "Clear Button");
					waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
					waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
					waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
					click(driver,SOP.FILTERGOBTN, "Go Button");
					Thread.sleep(1000);
					waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
					assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
					selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
					waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
					selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
					waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
					assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
					click(driver,SOP.FILTERGOBTN, "Go Button");

					try {
						WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
						waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
						assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
						click(driver,SOP.CLEARBTN, "Clear Button");
						waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
						assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
						selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
						waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
						selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
						waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
						assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
						click(driver,SOP.FILTERGOBTN, "Go Button");
						Thread.sleep(1000);
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
					Thread.sleep(1000);

					waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
					esopId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				} else if (!cesQueue.equals("New")) {
					// CES_LEFT_NAV_LINK
					waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
					assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
					click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
					// CES_PRODUCTIVITY_TAB
					waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
					click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

					if (cesQueue.equals("Escalated List")) {
						// ESCALATED_LIST_TAB
						waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
						assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
						click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
						// FIRST_CES_SELECT_BUTTON
						waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					}

					else if (cesQueue.equals("OnHold List")) {
						// ON_HOLD_LIST_TAB
						waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
						assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
						click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
						// FIRST_ONHOLD_CES_SELECT_BUTTON
						waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON,
								"First CES Select Button in CES Page");
						assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
						click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
						// create on filter search for New York SOP Team
					}

					else if (cesQueue.equals("Rejections List")) {
						// REJECTION_LIST_TAB
						waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
						assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
						click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
						// REJECTIONS_LIST_FIRST_CES_SELECT
						waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT,
								"First CES Select Button in CES Page");
						assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT,
								"First CES Select Button in CES Page");
						click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
					}
				}
				Thread.sleep(2000);
				// System.out.println("Reached Here ewjdjkjlkwdlkjw");
				Thread.sleep(1000);
				waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				esopId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				driver.switchTo().frame("frame1");
				System.out.println("Switched to Frame 1");
				Thread.sleep(3000);
				// TRAINGLE_ICON_ARROW_ENTITY
				// waitForElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
				// Expaned");
				assertElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
				// INTAKEMETHODVALUE
				waitForElementPresent(driver,SOP.INTAKEMETHODVALUE, "intake method value");
				String cdsop = getText(driver,SOP.INTAKEMETHODVALUE, "intake method value");
				if (!arrowEntity.equals("")) {
					waitForElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					String arrowEntityCheckedAttribute = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
					if (arrowEntityCheckedAttribute == null) {
						click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
					}
					waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
					click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

					if (!cdsop.equals("CDSOP")) {
						if (branchPlant.equals("CTCORP")) {
							// CTCORP_RADIO_BUTTON
							waitForElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
									"CTCORP Radio Button on search Entity criteria page");
							assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
									"CTCORP Radio Button on search Entity criteria page");
							click(driver,SOP.CTCORP_RADIO_BUTTON,
									"click on CTCORP Radio Button on search Entity criteria page");

						} else if (branchPlant.equals("NRAI")) {
							// NRAI_RADIO_BUTTON
							waitForElementPresent(driver,SOP.NRAI_RADIO_BUTTON,
									"NRAI Radio Button on search Entity criteria page");
							assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON,
									"NRAI Radio Button on search Entity criteria page");
							click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
						}
					}
					// ENTITY_NAME_TEXTFIELD
					waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
					if (cdsop.equals("CDSOP")) {
						selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
					} else if (!cdsop.equals("CDSOP")) {
						selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
					}
					// SEARCH_BTN
					waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
					assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
					click(driver,SOP.SEARCH_BTN, "Search button");
					int entitySearchCount = 0;
					// ENTITY_SEARCH_RESULT_COUNT
					waitForElementPresent(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
					entitySearchCount = Integer
							.valueOf(getText(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
					if (entitySearchCount == 0) {
						// Click on unidentified entity
						waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						String disabledUnEntity = "";
						try {
							disabledUnEntity = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
							System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
						} catch (NullPointerException e) {
						}
						if (disabledUnEntity == null) {
							click(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
						}
						Thread.sleep(1500);
						System.out.println("REached here in line 6420");
						try {
							if (disabledUnEntity.equals("true")) {
								// SEARCH_AGAIN_BUTTON
								waitForElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								assertElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								click(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
								// CANCEL_BUTTON
								waitForElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
								assertElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
								click(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							}
						} catch (NullPointerException e) {
						}
						System.out.println("REached here in line 6431");
						Thread.sleep(2000);
						// below will be a go ahead when the value for unidentified Entity above is
						// selected
						String unEntityRadioSelected = "";
						try {
							unEntityRadioSelected = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
						} catch (NoSuchElementException e) {
						} catch (NullPointerException e) {
						}
						Thread.sleep(1000);
						try {
							if (unEntityRadioSelected == null) {
								click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
							}
						} catch (NullPointerException e) {
						}
						// ENTITY_TEXT_BOX
						waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
						assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
						type(driver,SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
						// DOMESTIC_JURISDICTION_SELECTION
						waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
						assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
						selectByIndex(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
						// REP_JURISDICTION_SELECTION
						waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
						selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
						try {
							// waitForElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
							// assertElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
							driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
							Thread.sleep(1500);
							selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						} catch (NoSuchElementException e) {
						}
						// DOCUMENT_TYPE_DROPDWN
						try {
							// waitForElementPresent(driver,SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
							// assertElementPresent(driver,SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
							driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
							selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
						} catch (NoSuchElementException e) {
						}
						// PLAINTIFF_TEXT_BOX
						waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
						type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
						// DEFENDANT_TEXT_BOX
						waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
						type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

						waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
						assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
						type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					} else if (entitySearchCount != 0) {
						// REP_STATUS_SORT
						waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
						assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
						click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
						// FIRST_ENTITY_IN_SEARCH_RESULT
						waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
						// CONTINUE_BUTTON
						try {
							List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
							if (action.size() > 0) {

								click(driver,SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
							}
						} catch (NoSuchElementException e) {

						}
						if (!caseNum1.equals("")) {
							// CASEID_TEXTBOX
							waitForElementPresent(driver,SOP.CASEID_TEXTBOX, "Case number Search text box");
							assertElementPresent(driver,SOP.CASEID_TEXTBOX, "Case number Search text box");
							if (cdsop.equals("CDSOP")) {
								type(driver,SOP.CASEID_TEXTBOX, "19342919", "Case number Search text box");
							} else if (!cdsop.equals("CDSOP")) {
								type(driver,SOP.CASEID_TEXTBOX, caseNum1, "Case number Search text box");
							}
							// SEARCH_BTN
							waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
							assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
							click(driver,SOP.SEARCH_BTN, "Search button");
							// TOTAL_RECORDS_RELATED_WORKSHEET
							waitForElementPresent(driver,SOP.TOTAL_RECORDS_RELATED_WORKSHEET,
									"Related worksheet search results");
							relatedWorksheet = Integer.parseInt(
									getText(driver,SOP.TOTAL_RECORDS_RELATED_WORKSHEET, "Related worksheet search results"));
							Thread.sleep(1000);
							if (relatedWorksheet == 0) {

								click(driver,SOP.UNRELATED_WORKSHEET_BTN, "Click on Unrealted Worksheer button in CES page");
								Thread.sleep(2000);
								// RADIO_PRESENTATION_BUTTON
								String repChecked = "";
								try {
									repChecked = getAttribute(driver,SOP.RADIO_PRESENTATION_BUTTON, "checked");
								} catch (NoSuchElementException e) {
								}
								if (repChecked == null) {
									// REP_JURISDICTION_SELECTION
									waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
									assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
									selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
								}
								Thread.sleep(2000);
								try {

									driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
									selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law suit type in CES Page");

								} catch (NoSuchElementException e) {
								}
								Thread.sleep(2000);
								try {
									driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
									selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
								} catch (NoSuchElementException e) {
								}
								Thread.sleep(3000);
								waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
								assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "Plaintiff text box in CES Page");
								type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "Plaintiff text box in CES Page");

								waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
								assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "Defendant text box CES Page");
								type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "Defendant text box CES Page");

								waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
								assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
								type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");

							} else if (relatedWorksheet != 0) {
								// FIRST_WORKSHEET_RADIO_BTN
								waitForElementPresent(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
										"First Worksheet id radio button in Related Worksheet Page");
								assertElementPresent(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
										"First Worksheet id radio button in Related Worksheet Page");
								click(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
										"First Worksheet id radio button in Related Worksheet Page");
								// ADD_TO_DOCKET_HISTORY_BUTTON
								waitForElementPresent(driver,SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
								assertElementPresent(driver,SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
								click(driver,SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
								Thread.sleep(2000);
								waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case number text field");
								caseNumber = getAttribute(driver,SOP.CASE_ID_TEXTBOX, "value");
								if (cdsop.equals("CDSOP")) {
									compareStrings(caseNumber, "19342919");
								}

								else if (!cdsop.equals("CDSOP")) {

									compareStrings(caseNumber, caseNum1);
								}
							}
						}
						if (!caseNum2.equals("")) {
							// SELECT_BUTTON_IN_RELATED_LOG
							waitForElementPresent(driver,SOP.SELECT_BUTTON_IN_RELATED_LOG,
									"Select button in Related Log section");
							assertElementPresent(driver,SOP.SELECT_BUTTON_IN_RELATED_LOG,
									"Select button in Related Log section");
							click(driver,SOP.SELECT_BUTTON_IN_RELATED_LOG, "click on Select button in Related Log section");
							// CASEID_TEXTBOX
							waitForElementPresent(driver,SOP.CASEID_TEXTBOX, "Case number Search text box");
							assertElementPresent(driver,SOP.CASEID_TEXTBOX, "Case number Search text box");
							if (cdsop.equals("CDSOP")) {
								type(driver,SOP.CASEID_TEXTBOX, "19342919", "Case number Search text box");
							} else if (!cdsop.equals("CDSOP")) {
								type(driver,SOP.CASEID_TEXTBOX, caseNum2, "Case number Search text box");
							}

							// SEARCH_BTN
							waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
							assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
							click(driver,SOP.SEARCH_BTN, "Search button");
							// FIRST_WORKSHEET_RADIO_BTN
							waitForElementPresent(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
									"First Worksheet id radio button in Related Worksheet Page");
							assertElementPresent(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
									"First Worksheet id radio button in Related Worksheet Page");
							click(driver,SOP.FIRST_WORKSHEET_RADIO_BTN,
									"First Worksheet id radio button in Related Worksheet Page");
							// ADD_TO_DOCKET_HISTORY_BUTTON
							waitForElementPresent(driver,SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							assertElementPresent(driver,SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "Add to Docket history button");
							click(driver,SOP.ADD_TO_DOCKET_HISTORY_BUTTON, "click on Add to Docket history button");
							Thread.sleep(2000);
							waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case number text field");
							caseNumber = getAttribute(driver,SOP.CASE_ID_TEXTBOX, "value");
							if (cdsop.equals("CDSOP")) {
								compareStrings(caseNumber, "19342919");
							} else if (!cdsop.equals("CDSOP")) {

								compareStrings(caseNumber, caseNum2);
							}
						}

						if (caseNum1.equals("")) {
							Thread.sleep(1000);
							driver.switchTo().defaultContent();
							assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
							click(driver,SOP.GLYPHICON_HOME, "glyphicon button");
							Thread.sleep(3000);
							driver.switchTo().frame("frame1");
							// PLAINTIFF_TEXT_BOX
							waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
							assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
							type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
							// DEFENDANT_TEXT_BOX
							waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
							assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
							type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
							try {
								driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
								selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
							} catch (NoSuchElementException e) {
							}
							// DOCUMENT_TYPE_DROPDWN
							try {
								driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
								selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
							} catch (NoSuchElementException e) {
							}
						}
					}
				}
			}
			Thread.sleep(3000);
			assertElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned in CES Page");
			try {
				// ATTORNEY_SENDER_LABEL
				driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

			} catch (NoSuchElementException e) {

				printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
			}
			try {
				// COURT_LABEL
				driver.findElement(SOP.COURT_LABEL);

			} catch (NoSuchElementException e) {
				printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
			}
			try {
				// REJECTION_RULES_LABEL
				driver.findElement(SOP.REJECTION_RULES_LABEL);
			} catch (NoSuchElementException e) {
				printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

			}
			// Below one check can be applied if attorney and court modification needs to be
			// done - 1476
			if (!attorneyName.equals("")) {
				// RADIO_BUTTON_ATTORNEYNONE
				String attorneyNoneAttribute = "";

				try {
					attorneyNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
					waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
							"Radio button for Existing Attorney Sender in CES Page");
					click(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
							"Radio button for Existing Attorney Sender in CES Page");
					// DROP_DOWN_ATTORNEY_SENDER_NAME
					waitForElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
					assertElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
					selectByIndex(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
				} catch (NoSuchElementException e) {
				}
			}

			if (!courtName.equals("")) {
				try {
					String courtNoneAttribute = "";
					courtNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_COURTNONE, "checked");
					waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
							"Radio button for Existing Court in CES Page");
					click(driver,SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
					// DROP_DOWN_COURT_NAME
					waitForElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
					assertElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
					selectByIndex(driver,SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
				} catch (NoSuchElementException e) {
				}
				/*
				 * if(attorneyNoneAttribute == null) { //TEXT_BOX_ATTORNEYNAME
				 * waitForElementPresent(driver,SOP.
				 * TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
				 * assertElementPresent(driver,SOP.
				 * TEXT_BOX_ATTORNEYNAME,"text field for Attorney Sender Name");
				 * type(driver,SOP.TEXT_BOX_ATTORNEYNAME,
				 * attorneyName,"text field for Attorney Sender Name"); } if(courtNoneAttribute
				 * == null) { //TEXT_BOX_COURTNAME
				 * waitForElementPresent(driver,SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
				 * assertElementPresent(driver,SOP.TEXT_BOX_COURTNAME,"text field for Court Name");
				 * type(driver,SOP.TEXT_BOX_COURTNAME,courtName,"text field for Court Name");
				 * 
				 * }
				 */
			}

			// Below one code is to escalate as Possible REjection
			if (!escalationReason.equals("")) {
				// Below one condition needs to be set if the L2 user processing CES from
				// Escalated List
				// then update to possible rejection click can be done from here.
				if ((cesQueue.equals("Escalated List") || cesQueue.equals("OnHold List"))
						&& escalationReason.equals("Update to Possible Rejection")) {
					// UPDATE_TO_POSSIBLE_REJECTION
					waitForElementPresent(driver,SOP.UPDATE_TO_POSSIBLE_REJECTION, "Update to Possible Rejection button");
					assertElementPresent(driver,SOP.UPDATE_TO_POSSIBLE_REJECTION, "Update to Possible Rejection button");
					click(driver,SOP.UPDATE_TO_POSSIBLE_REJECTION, "Update to Possible Rejection button");

				}
				if (cesQueue.equals("Escalated List")
						&& escalationReason.equals("Update to Possible Rejection & GetNext")) {
					// UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT
					waitForElementPresent(driver,SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,
							"Update to Possible Rejection & GetNext button");
					assertElementPresent(driver,SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,
							"Update to Possible Rejection & GetNext button");
					click(driver,SOP.UPDATE_TO_POSSIBLE_REJECTION_AND_GETNEXT,
							"Update to Possible Rejection & GetNext button");
					Thread.sleep(5000);
				}
				if (!escalationReason.equals("Update to Possible Rejection")
						&& !escalationReason.equals("Update to Possible Rejection & GetNext")) {
					// ESCALATION_DETAILS
					waitForElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					assertElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					click(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
					// REASON_DRPDWN
					waitForElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
					assertElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
					selectByVisibleText(driver,SOP.REASON_DRPDWN, escalationReason, "Escalation reason text box");
					// ESCALATION_COMMENTS_TEXTBOX
					waitForElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					assertElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
					type(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Could be a Possible Rejection", "Escalation text box");
					// ESCALATE_BTN
					waitForElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
					assertElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
					click(driver,SOP.ESCALATE_BTN, "Escalate button");
				}
			} else if (rejectionReason.equals("") && reject.equals("Y")) {
				// REJECT_BUTTON_IN_CES
				waitForElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
				// REJECT_REASON_EMPTY_ERROR
				waitForElementPresent(driver,SOP.REJECT_REASON_EMPTY_ERROR, "Error message in CES Page");
				assertElementPresent(driver,SOP.REJECT_REASON_EMPTY_ERROR, "Error message in CES Page");
				String errorMessage = getText(driver,SOP.REJECT_REASON_EMPTY_ERROR, "Error message in CES Page");
				compareStrings(error, errorMessage);

			} else if (!rejectionReason.equals("") && !reject.equals("")) {
				// REJECT_REASON_DROP_DOWN
				waitForElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(driver,SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
				if (!notRejecting.equals("")) {
					// REASON_FOR_NOT_REJECTING
					waitForElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(driver,SOP.REASON_FOR_NOT_REJECTING, notRejecting,
							"Reason for not Rejecting drop down");
					// REJECT_BUTTON_IN_CES
					waitForElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
					// ERROR_REASON_FOR_NOT_REJECTING_SELECTED
					waitForElementPresent(driver,SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED, "Error message in CES Page");
					assertElementPresent(driver,SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED, "Error message in CES Page");
					String errorMessage = getText(driver,SOP.ERROR_REASON_FOR_NOT_REJECTING_SELECTED,
							"Error message in CES Page");
					compareStrings(error, errorMessage);
				} else if (notRejecting.equals("")) {
					if (attorneyName.equals("")) {
						// ATTORNEY_SENDER_NONE_SPECIFIED
						waitForElementPresent(driver,SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						assertElementPresent(driver,SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
						click(driver,SOP.ATTORNEY_SENDER_NONE_SPECIFIED, "None specified radio button");
					}
					Thread.sleep(2000);
					// commenting below as List of WebElemets not required
					// List<WebElement> traceableMail = null;
					WebElement traceableMail = null;
					try {
						traceableMail = driver.findElement(SOP.TRACEABLE_MAIL_FIELD);
						if (traceableMail != null) {
							type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					// HARD_COPY_DELIVERY
					waitForElementPresent(driver,SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					assertElementPresent(driver,SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					String hardCopy = getText(driver,SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
					// REJECT_REASON_DROP_DOWN
					waitForElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(driver,SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
					// REJECT_BUTTON_IN_CES
					waitForElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
					assertElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
					click(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
					Thread.sleep(5000);
					if (hardCopy.equals("No") && error.equals("")) {
						String parentWin = driver.getWindowHandle();
						Thread.sleep(2000);
						handlePopUpWindwow(driver);
						String letterPopup = driver.getCurrentUrl();
						String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId.split("\\: ")[1])
								.get(0);
						assertTextContains(letterPopup, rejectLog);
						driver.close();
						driver.switchTo().window(parentWin);
					}
					// ATTORNEY_SENDER_NOT_SELECTED_ERROR
					if (attorneyName.equals("")) {
						waitForElementPresent(driver,SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR, "Error message in CES Page");
						assertElementPresent(driver,SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR, "Error message in CES Page");
						String errorMessage = getText(driver,SOP.ATTORNEY_SENDER_NOT_SELECTED_ERROR,
								"Error message in CES Page");
						compareStrings(error, errorMessage);
					}
				}
			} else if (escalationReason.equals("") && reject.equals("") && onHold.equals("")) {
				if (!rejectionReason.equals("")) {
					waitForElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					assertElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
					selectByIndex(driver,SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
					// REASON_FOR_NOT_REJECTING
					waitForElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					assertElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
					selectByVisibleText(driver,SOP.REASON_FOR_NOT_REJECTING, notRejecting, "Reject Reason drop down");
					Thread.sleep(2000);
					List<WebElement> traceableMail = null;
					// TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if (traceableMail != null) {
							type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					// SUBMIT_CES
					waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
					click(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
					// SUBMIT_ERROR_REJECT_REASON_SELECTED
					waitForElementPresent(driver,SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED, "Error message in CES Page");
					assertElementPresent(driver,SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED, "Error message in CES Page");
					String errorMessage = getText(driver,SOP.SUBMIT_ERROR_REJECT_REASON_SELECTED, "Error message in CES Page");
					compareStrings(error, errorMessage);
				} else if (rejectionReason.equals("")) {
					List<WebElement> traceableMail = null;
					// TRACEABLE_MAIL_FIELD
					try {
						traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
						if (traceableMail != null) {

							type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					/*
					 * Below Code is addded on 1/21 as part of GCNBO-1740 To handle the onhold
					 * submit scenario when the Escalation Reason for the esop is Possible Rejection
					 */
					if (cesQueue.equals("OnHold List")) {
						// ESCALATION_DETAILS
						waitForElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						assertElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						click(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
						// ESCALATION_REASON
						waitForElementPresent(driver,SOP.ESCALATION_REASON, "Escalation Reason");
						assertElementPresent(driver,SOP.ESCALATION_REASON, "Escalation Reason");
						String escalationReasonInOnHold = getText(driver,SOP.ESCALATION_REASON, "Escalation Reason");

						if (escalationReasonInOnHold.equals("Possible Rejection")) {
							waitForElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							assertElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
							selectByIndex(driver,SOP.REASON_FOR_NOT_REJECTING, 1, "Reject Reason drop down");
							Thread.sleep(2000);

						}
					}
					/* Till here the code change made as on 1/21 */

					// REASON_FOR_NOT_REJECTING
					if (cesQueue.equals("Rejections List")) {
						waitForElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						assertElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
						selectByVisibleText(driver,SOP.REASON_FOR_NOT_REJECTING, notRejecting, "Reject Reason drop down");
						Thread.sleep(2000);
					}
					// SUBMIT_CES
					waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
					assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
					click(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
					Thread.sleep(4000);
				}
			} else if (!onHold.equals("")) {
				// REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
						"Reason for On Hold Text box");
				// ONHOLD_BTN
				waitForElementPresent(driver,SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(driver,SOP.ONHOLD_BTN, "On Hold button");
				click(driver,SOP.ONHOLD_BTN, "On Hold button");
			}

		} catch (Exception e) {
		}
		return esopId.split("\\: ")[1];
	}

	public String rejectESOPWithHardCopyRequiredOrNot(String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);

			if (!cesQueue.equals("New")) {
				moveESOPFromNewQueueToDiffCESQueue(driver,reportSheet, count);
			}

			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], Integer.parseInt(cesQueuCode))
					.get(0);
			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			if (cesQueue.equals("New")) {
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					click(driver,SOP.CLEARBTN, "Clear Button");
					searchForESOP(driver,esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(driver,SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(driver,SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(driver,SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				// SEARCH_BTN
				waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				click(driver,SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							click(driver,SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(driver,SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(driver,SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					click(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {
						attorneyNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						// DROP_DOWN_ATTORNEY_SENDER_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
						assertElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
						selectByIndex(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						String courtNoneAttribute = "";
						courtNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_COURTNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
								"Radio button for Existing Court in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
						// DROP_DOWN_COURT_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
						assertElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
						selectByIndex(driver,SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				// HARD_COPY_DELIVERY
				waitForElementPresent(driver,SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				assertElementPresent(driver,SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value");
				compareStrings(hardCopyDeliveryFlag, getText(driver,SOP.HARD_COPY_DELIVERY, "Hard Copy Delivery Flag Value"));
				// REJECT_REASON_DROP_DOWN
				waitForElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				assertElementPresent(driver,SOP.REJECT_REASON_DROP_DOWN, "Reject Reason drop down");
				selectByIndex(driver,SOP.REJECT_REASON_DROP_DOWN, 1, "Reject Reason drop down");
				// REJECT_BUTTON_IN_CES
				waitForElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
				assertElementPresent(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
				click(driver,SOP.REJECT_BUTTON_IN_CES, "Reject button");
				Thread.sleep(5000);

			}
			if (hardCopyDeliveryFlag.equals("No")) {
				String parentWin = driver.getWindowHandle();
				Thread.sleep(2000);
				handlePopUpWindwow(driver);
				String letterPopup = driver.getCurrentUrl();
				String rejectLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
				assertTextContains(letterPopup, rejectLog);
				driver.close();
				driver.switchTo().window(parentWin);
			}
		} catch (Exception e) {
		}
		return esopId;
	}

	public void moveESOPFromNewQueueToDiffCESQueue(WebDriver driver,String reportSheet, int count) throws Throwable {

		String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
		String moveNewCES = Excelobject.getCellData(reportSheet, "Move New CES To", count);
		String esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], 157001)
				.get(0);
		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
		assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
		click(driver,SOP.CLEARBTN, "Clear Button");
		searchForESOP(driver,esopId);
		try {
			WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
			waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			searchForESOP(driver,esopId);
		} catch (NoSuchElementException e) {
		}
		Thread.sleep(1000);
		waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		if (!moveNewCES.equals("OnHold")) {
			// ESCALATION_DETAILS
			waitForElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			assertElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			click(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
			// REASON_DRPDWN
			waitForElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
			assertElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
			selectByVisibleText(driver,SOP.REASON_DRPDWN, moveNewCES, "Escalation reason text box");
			// ESCALATION_COMMENTS_TEXTBOX
			waitForElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			assertElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
			type(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Moving it to " + moveNewCES, "Escalation text box");
			// ESCALATE_BTN
			waitForElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
			assertElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
			click(driver,SOP.ESCALATE_BTN, "Escalate button");
		}

		else if (moveNewCES.equals("OnHold")) {
			// REASON_FOR_HOLD_TEXTBOX
			waitForElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
			assertElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
			type(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
					"Reason for On Hold Text box");
			// ONHOLD_BTN
			waitForElementPresent(driver,SOP.ONHOLD_BTN, "On Hold button");
			assertElementPresent(driver,SOP.ONHOLD_BTN, "On Hold button");
			click(driver,SOP.ONHOLD_BTN, "On Hold button");
		}
	}

	public void rejectedLogHardCopyRequiredSOPTeamDashboard(String reportSheet, int count, String esopId)
			throws Throwable {

		try {
			teamSOPDashboard(reportSheet, count);
			String branchPlant = SQL_Queries.getTheBranchPlantForTheESOPs(esopId).get(0);
			String rejectedLog = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
			if (branchPlant.equals("92001")) {
				// REJECT_AND_HARDCOPY_LINK
				waitForElementPresent(driver,TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK,
						"Reject and Hard Copy Required For CTCORP");
				assertElementPresent(driver,TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK,
						"Reject and Hard Copy Required For CTCORP");
				click(driver,TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK, "Reject and Hard Copy Required For CTCORP");
			} else if (branchPlant.equals("92003")) {
				// REJECT_AND_HARDCOPY_LINK_NRAI
				waitForElementPresent(driver,TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI,
						"Reject and Hard Copy Required For NRAI");
				assertElementPresent(driver,TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI,
						"Reject and Hard Copy Required For NRAI");
				click(driver,TeamSOPDashboard.REJECT_AND_HARDCOPY_LINK_NRAI, "Reject and Hard Copy Required For NRAI");
			}
			searchForLog(rejectedLog);
			// FIRST_SOP_ID
			waitForElementPresent(driver,TeamSOPDashboard.FIRST_SOP_ID,
					"Reject Log with hard cop required is present in the Team SOP Dashboard");
			assertElementPresent(driver,TeamSOPDashboard.FIRST_SOP_ID,
					"Reject Log with hard cop required is present in the Team SOP Dashboard");

		} catch (NoSuchElementException e) {
		} catch (Exception e) {
		}
	}

	public void searchForLog(String log) throws Throwable {

		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Log #", "Filter drop down");
		waitForElementToBeClickable(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(driver,SOP.FILTERTEXTFIELD, log, "Filter text field");
		assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
		click(driver,SOP.FILTERGOBTN, "Go Button");
	}

	public void compareTheCurrentStatus(String reportSheet, int count, String esopId) throws Throwable {
		String currentStatus = "";
		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		ArrayList<String> statusCode = new ArrayList<String>();
		try {
			Thread.sleep(5000);
			statusCode = SQL_Queries.getTheCurrentStatusCode(esopId);
			currentStatus = statusCode.get(0);
			compareStrings(currentStatus, status);
		} catch (IndexOutOfBoundsException e) {

		}
	}

	public void compareExpeditedWorkflow(String reportSheet, int count, String esopId) throws Throwable {

		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		String expeditedFlag = Excelobject.getCellData(reportSheet, "Expedited Flag", count);
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		ArrayList<String> expeditedLog = new ArrayList<String>();
		try {

			if (expeditedFlag.equals("")) {
				expeditedFlag = null;
			}
			if (workflow.equals("")) {

				workflow = null;
			}
			for(int i =0 ; i < 7 ; i++) {
			expeditedFlag = SQL_Queries.expeditedLogWorkflow(esopId).get(1);
			if(expeditedFlag == null) {
			Thread.sleep(10000);
			}
			else {
				break;
			}
			}
			expeditedLog = SQL_Queries.expeditedLogWorkflow(esopId);
			compareStrings(status, expeditedLog.get(0));
			compareStrings(expeditedFlag, expeditedLog.get(1));
			compareStrings(workflow, expeditedLog.get(2));
		} catch (IndexOutOfBoundsException e) {

		}
	}

	public void compareTheReasonForNotRejection(String reportSheet, int count, String esopId) throws Throwable {
		String currentStatus = "";
		String status = Excelobject.getCellData(reportSheet, "Status Code", count);
		ArrayList<String> statusCode = new ArrayList<String>();
		try {
			Thread.sleep(10000);
			statusCode = SQL_Queries.getTheReasonForNotRejection(esopId);
			currentStatus = statusCode.get(0);
			compareStrings(currentStatus, status);
		} catch (IndexOutOfBoundsException e) {

		}
	}

	public void cesProductivityGrandTotalAndTier3() throws Throwable {

		try {

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			// CES_LEFT_NAV_LINK
			waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
			click(driver,SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");
			// CES_PRODUCTIVITY_TITLE
			waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title");
			assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title");
			compareStrings("CES Productivity", getText(driver,SOP.CES_PRODUCTIVITY_TITLE, "CES Productivity Title"));
			// TIER3_HEADER
			waitForElementPresent(driver,SOP.TIER3_HEADER, "CES Productivity Tier 3");
			assertElementPresent(driver,SOP.TIER3_HEADER, "CES Productivity Tier 3");
			compareStrings("Tier 3", getText(driver,SOP.TIER3_HEADER, "CES Productivity Tier 3"));
			// GRAND_TOTALS_LABEL
			waitForElementPresent(driver,SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals");
			assertElementPresent(driver,SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals");
			compareStrings("Grand Totals", getText(driver,SOP.GRAND_TOTALS_LABEL, "CES Productivity Grand totals"));
			// TOTAL_COUNT_GRAND_TOTALS
			waitForElementPresent(driver,SOP.TOTAL_COUNT_GRAND_TOTALS, "CES Productivity Total count");
			assertElementPresent(driver,SOP.TOTAL_COUNT_GRAND_TOTALS, "CES Productivity Total Count");
			/*
			 * String total_Count = SQL_Queries.getTheTotalCountOfCompletedESOPs().get(0);
			 * compareStrings(total_Count,getText(driver,SOP.TOTAL_COUNT_GRAND_TOTALS,
			 * "Total Count"));
			 */
		} catch (Exception e) {

		}
	}

	// Below one for GCNBO-1283
	public void assignmentHistoryAndAudtitTrail(String esopId, String worksheetId) throws Throwable {

		try {
			String parentWindow = driver.getWindowHandle();
			// WORKSHEET_PROFILE_ASSIGNMENTHISTORY
			waitForElementPresent(driver,WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,
					"Worksheet profile Assignment History link");
			assertElementPresent(driver,WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY,
					"Worksheet profile Assignment History link");
			click(driver,WorksheetCreate.WORKSHEET_PROFILE_ASSIGNMENTHISTORY, "Worksheet profile Assignment History link");
			// below all the scenarios will come which needs to be validated
			handlePopUpWindwow(driver);
			// DOCKET_HISTORY_CES_AUDIT_TRAIL
			waitForElementPresent(driver,WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL, " Docket History in Audit Trail");
			assertElementPresent(driver,WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL, " Docket History in Audit Trail");
			String docketHistoryCES = getText(driver,WorksheetCreate.DOCKET_HISTORY_CES_AUDIT_TRAIL,
					" Docket History in Audit Trail");
			String attorneyWorksheet = getText(driver,WorksheetCreate.ATTORNEY_WORKSHEET_AUDIT_TRAIL,
					" Attorney in Audit Trail");
			String courtWorksheet = getText(driver,WorksheetCreate.COURT_WORKSHEET_AUDIT_TRAIL, " Court in Audit Trail");
			String plaintiffWorksheet = getText(driver,WorksheetCreate.PLAINTIFF_WORKSHEET_AUDIT_TRAIL,
					" Plaintiff in Audit Trail");
			String defendantWorksheet = getText(driver,WorksheetCreate.DEFENDANT_WORKSHEET_AUDIT_TRAIL,
					" Defendant in Audit Trail");
			driver.close();
			driver.switchTo().window(parentWindow);
			if (attorneyWorksheet.equals("")) {
				attorneyWorksheet = null;
			}
			if (courtWorksheet.equals("")) {
				courtWorksheet = null;
			}
			if (plaintiffWorksheet.equals("")) {
				plaintiffWorksheet = null;
			}
			if (defendantWorksheet.equals("")) {
				defendantWorksheet = null;
			}
			if (docketHistoryCES.equals("")) {
				docketHistoryCES = null;
			}
			ArrayList<String> fieldsModifiedInWorksheet = SQL_Queries.fieldsModifiedInWorksheet(worksheetId);
			ArrayList<String> getTheRelatedLogForCompletedESOPs = SQL_Queries.getTheRelatedLogForCompletedESOPs(esopId);
			compareStrings(docketHistoryCES, getTheRelatedLogForCompletedESOPs.get(0));
			compareStrings(attorneyWorksheet, fieldsModifiedInWorksheet.get(0));
			compareStrings(courtWorksheet, fieldsModifiedInWorksheet.get(1));
			compareStrings(defendantWorksheet, fieldsModifiedInWorksheet.get(2));
			compareStrings(plaintiffWorksheet, fieldsModifiedInWorksheet.get(3));
			// Need to comment below
		} catch (Exception e) {

		}
	}

	public void searchForESOP(WebDriver driver,String esopId) throws Throwable {

		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "ESOP Id", "Filter drop down");
		waitForElementToBeClickable(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(driver,SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
		click(driver,SOP.FILTERGOBTN, "Go Button");
	}
	
	public void searchForESOPWithHash(WebDriver driver,String esopId) throws Throwable {

		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "ESOP #", "Filter drop down");
		waitForElementToBeClickable(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "=", "Filter drop down2");
		waitForElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
		selectBySendkeys(driver,SOP.FILTERTEXTFIELD, esopId, "Filter text field");
		assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
		click(driver,SOP.FILTERGOBTN, "Go Button");
	}

	public void partialAndFullCaseSearch(WebDriver driver,String reportSheet, int count) throws Throwable {

		String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
		String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
		String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
		String caseNum = Excelobject.getCellData(reportSheet, "Case Number", count);

		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		if (!cesQueue.equals("New")) {
			moveESOPFromNewQueueToDiffCESQueue(driver,reportSheet, count);
		}
		if (cesQueue.equals("New")) {
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "Standard SOP", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(1000);
		} else if (!cesQueue.equals("New")) {
			// CES_LEFT_NAV_LINK
			waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
			assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
//			click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
			// CES_PRODUCTIVITY_TAB
			waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
			click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

			if (cesQueue.equals("Escalated List")) {
				// ESCALATED_LIST_TAB
				waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
				click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
				// FIRST_CES_SELECT_BUTTON
				waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			}

			else if (cesQueue.equals("OnHold List")) {
				// ON_HOLD_LIST_TAB
				waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// FIRST_ONHOLD_CES_SELECT_BUTTON
				waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
				click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				// create on filter search for New York SOP Team
			}

			else if (cesQueue.equals("Rejections List")) {
				// REJECTION_LIST_TAB
				waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
				click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
				// REJECTIONS_LIST_FIRST_CES_SELECT
				waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
				click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
			}
		}
		Thread.sleep(2000);
		driver.switchTo().frame("frame1");
		System.out.println("Switched to Frame 1");
		Thread.sleep(3000);
		waitForElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
		String arrowEntityCheckedAttribute = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
		if (arrowEntityCheckedAttribute == null) {
			click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
		}
		waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
		if (branchPlant.equals("CTCORP")) {
			// CTCORP_RADIO_BUTTON
			waitForElementPresent(driver,SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
			assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON, "CTCORP Radio Button on search Entity criteria page");
			click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

		} else if (branchPlant.equals("NRAI")) {
			// NRAI_RADIO_BUTTON
			waitForElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
			assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
			click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
		}

		// ENTITY_NAME_TEXTFIELD
		waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
		assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
		click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
		selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
		// SEARCH_BTN
		waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
		assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
		click(driver,SOP.SEARCH_BTN, "Search button");

		// REP_STATUS_SORT
		waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
		assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
		click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
		// FIRST_ENTITY_IN_SEARCH_RESULT
		waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
		assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
		click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
		// CONTINUE_BUTTON
		try {
			List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
			if (action.size() > 0) {

				click(driver,SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
			}
		} catch (NoSuchElementException e) {

		}
		// CASEID_TEXTBOX
		waitForElementPresent(driver,SOP.CASEID_TEXTBOX, "Case number Search text box");
		assertElementPresent(driver,SOP.CASEID_TEXTBOX, "Case number Search text box");
		type(driver,SOP.CASEID_TEXTBOX, caseNum, "Case number Search text box");
		// here we need to type case#
		// SEARCH_BTN
		waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
		assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
		click(driver,SOP.SEARCH_BTN, "Search button");
		Thread.sleep(1000);
		// CASE_NUMBER_RELATED_WORKSHEET
		waitForElementPresent(driver,SOP.CASE_NUMBER_RELATED_WORKSHEET, "Related worksheet search results");
		String caseNumber = getText(driver,SOP.CASE_NUMBER_RELATED_WORKSHEET, "Related worksheet search results");
		assertTextContains(caseNumber, caseNum);

	}

	public void submitTheDSSOPWithNewStatus(String reportSheet, int count) throws Throwable {

		String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
		for (int i = 0; i < count; i++) {
			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		/*	assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button"); */
			waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			click(driver,SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");
			
			/*waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");*/

			//click(driver,SOP.FILTERGOBTN, "Go Button");
			//if (levelOfUser.equals("Level1")) {
				// CES_LEFT_NAV_LINK
	/*		    waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Link in left nav bar");
				click(driver,SOP.CES_LEFT_NAV_LINK, "Click CES Link in left nav bar");
				// CES_PRODUCTIVITY_TAB
				
				 waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				 assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				 click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");*/
				 
					/*waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");*/
/*
				 waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");*/
			
				// REJECTION_LIST_TAB
				/*	waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");*/
				// UNPROCESSED_COUNT
			/*	waitForElementPresent(driver,SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				assertElementPresent(driver,SOP.UNPROCESSED_COUNT, "unprocessed count CES Page");
				click(driver,SOP.UNPROCESSED_COUNT, "click on unprocessed count CES Page");
				Thread.sleep(3000);
				waitForElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				assertElementPresent(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR, "ESOP ID");
				// String esopId = getText(driver,SOP.WORKSHEET_ID_ON_CONTEXT_BAR,"ESOP ID");
				Thread.sleep(500);
				driver.switchTo().frame("frame1");
				Thread.sleep(500);
			}
			Thread.sleep(1000); */
			Thread.sleep(1000);
	/*		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");*/
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Worksheet Type", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "DSSOP", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//a[contains(text(),'Last')]")).click();
			// Thread.sleep(2000);	
	/*		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "Received Juris", "Filter drop down");
			Thread.sleep(500);
			waitForElementToBeClickable(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
			assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "contains", "Filter drop down2");
			Thread.sleep(550);
			waitForElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
			assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
			selectBySendkeys(driver,SOP.FILTERTEXTFIELD, "Alberta", "Filter text field");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");*/
			
			// REJECTIONS_LIST_FIRST_CES_SELECT
/*			waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
			assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
			click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");*/
						
			
			// FIRST_CES_SELECT_BUTTON
	/*		waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");*/
			
			waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			/*waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
			click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
			*/
			Thread.sleep(1000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			String unEntityRadioSelected = "";
			try {
				unEntityRadioSelected = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
			} catch (NoSuchElementException e) {
			} catch (NullPointerException e) {
			}
			Thread.sleep(1000);
			try {
				if (unEntityRadioSelected == null) {
					click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
				}
			} catch (NullPointerException e) {
			}
			// ENTITY_TEXT_BOX
			waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
			type(driver,SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
			// DOMESTIC_JURISDICTION_SELECTION
			waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
			selectByIndex(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
			// REP_JURISDICTION_SELECTION
			waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
			selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
			try {
				// waitForElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				// assertElementPresent(driver,SOP.LAWSUITTYPE_DROPDOWN, "Law Suit Type drop down");
				driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
				Thread.sleep(500);
				selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 1, "Law Suit Type drop down");
			} catch (NoSuchElementException e) {
			}
			// DOCUMENT_TYPE_DROPDWN
			try {
				// waitForElementPresent(driver,SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				// assertElementPresent(driver,SOP.DOCUMENT_TYPE_DROPDWN, "Document Type drop down");
				driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
				selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
			} catch (NoSuchElementException e) {
			}
			// PLAINTIFF_TEXT_BOX
			waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
			type(driver,SOP.PLAINTIFF_TEXT_BOX, "pltf", "plaintiff text box");
			// DEFENDANT_TEXT_BOX
			waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
			type(driver,SOP.DEFENDANT_TEXT_BOX, "dft", "defendant text box");
			Thread.sleep(1000);
			List<WebElement> traceableMail = null;
			try {
				traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
				if (traceableMail != null) {
					type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
				}
			} catch (NoSuchElementException e) {
			}
/*			waitForElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
			assertElementPresent(driver,SOP.REASON_FOR_NOT_REJECTING, "Reason for not Rejecting drop down");
			selectByIndex(driver,SOP.REASON_FOR_NOT_REJECTING, 1, "Reject Reason drop down");*/
			// SUBMIT_CES
			waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
			click(driver,SOP.SUBMIT_CES, "Submit button in CES Page");
		}
	}

	// added on 12/28 to move CES for Performance test data preparation
	public void moveTheCES(String reportSheet, int count) throws Throwable {

		for (int i = 0; i < count; i++) {

			String moveNewCES = Excelobject.getCellData(reportSheet, "Move New CES To", count);

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
			click(driver,SOP.CLEARBTN, "Clear Button");

			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "CES Status", "Filter drop down");
			waitForElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter second drop down");
			selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, "New", "Filter second drop down");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);
			waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "File Name", "Filter drop down");
			Thread.sleep(500);
			waitForElementToBeClickable(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
			assertElementPresent(driver,SOP.FILTERDROPDOWN2, "Filter drop down2");
			selectByVisibleText(driver,SOP.FILTERDROPDOWN2, "contains", "Filter drop down2");
			Thread.sleep(550);
			waitForElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
			assertElementPresent(driver,SOP.FILTERTEXTFIELD, "Filter text field");
			selectBySendkeys(driver,SOP.FILTERTEXTFIELD, "PerfTestHCN", "Filter text field");
			waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
			click(driver,SOP.FILTERGOBTN, "Go Button");
			Thread.sleep(1000);

			Thread.sleep(1000);
			waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			if (!moveNewCES.equals("OnHold")) {
				// ESCALATION_DETAILS
				waitForElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				assertElementPresent(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				click(driver,SOP.ESCALATION_DETAILS, "Escalation details traiangle icon");
				// REASON_DRPDWN
				waitForElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
				assertElementPresent(driver,SOP.REASON_DRPDWN, "Escalation reason text box");
				selectByVisibleText(driver,SOP.REASON_DRPDWN, moveNewCES, "Escalation reason text box");
				// ESCALATION_COMMENTS_TEXTBOX
				waitForElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				assertElementPresent(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Escalation text box");
				type(driver,SOP.ESCALATION_COMMENTS_TEXTBOX, "Moving it to " + moveNewCES, "Escalation text box");
				// ESCALATE_BTN
				waitForElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
				assertElementPresent(driver,SOP.ESCALATE_BTN, "Escalate button");
				click(driver,SOP.ESCALATE_BTN, "Escalate button");
			}

			else if (moveNewCES.equals("OnHold")) {
				// REASON_FOR_HOLD_TEXTBOX
				waitForElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				assertElementPresent(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Reason for On Hold Text box");
				type(driver,SOP.REASON_FOR_HOLD_TEXTBOX, "Putting on On hold for further verification",
						"Reason for On Hold Text box");
				// ONHOLD_BTN
				waitForElementPresent(driver,SOP.ONHOLD_BTN, "On Hold button");
				assertElementPresent(driver,SOP.ONHOLD_BTN, "On Hold button");
				click(driver,SOP.ONHOLD_BTN, "On Hold button");
			}
		}
	}

	public void qualityRandomiserSetup(String reportSheet, int count) throws Throwable {

		String qualityLimit = Excelobject.getCellData(reportSheet, "Quality Limit", count);
		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		// QUALITY_MAINTENANCE
		waitForElementPresent(driver,SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		assertElementPresent(driver,SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		click(driver,SOP.QUALITY_MAINTENANCE, "Quality Maintenance in left nav bar");
		// QUALITY_RANDOMISER_SETUP
		waitForElementPresent(driver,SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		assertElementPresent(driver,SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		click(driver,SOP.QUALITY_RANDOMISER_SETUP, "Quality Randomiser setup in left nav bar");
		// QUALITY_LIMIT_PER_DAY
		waitForElementPresent(driver,SOP.QUALITY_LIMIT_PER_DAY, "Quality limit per day in left nav bar");
		assertElementPresent(driver,SOP.QUALITY_LIMIT_PER_DAY, "Quality limit per day in left nav bar");
		type(driver,SOP.QUALITY_LIMIT_PER_DAY, qualityLimit, "Quality limit per day in left nav bar");
		// SAVE_BTN
		click(driver,SOP.SAVE_BTN, "Quality limit per day in left nav bar");

		if (Integer.valueOf(qualityLimit) >= 0) {

			String qualityLimitCountSet = SQL_Queries.criteriaLimitCount().get(0);
			compareStrings(qualityLimit, qualityLimitCountSet);
		}
		try {
			driver.findElement(SOP.INVALID_LIMIT_ERROR);
			String error = getText(driver,SOP.INVALID_LIMIT_ERROR, "Invalid Limit error message");
			compareStrings("Please provide valid Limit.", error);
		} catch (NoSuchElementException e) {
		}

	}

	public void deleteTheSOPs(String reportSheet, int count) throws Throwable {

		String sopFrom = Excelobject.getCellData(reportSheet, "SOP From", count);

		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");

		if (sopFrom.equals("SOP > 15 days")) {
			// SOP_15DAYS_TAB
			waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");
			click(driver,SOP.SOP_15DAYS_TAB, "SOP greater than 15 days");

		}
		// FIRST_ESOP_ID_SELECTED
		assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
		click(driver,SOP.CLEARBTN, "Clear Button");
		String firstESOPId = getText(driver,SOP.FIRST_ESOP_ID_SELECTED, "First Esop Id selected");
		waitForElementPresent(driver,SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		assertElementPresent(driver,SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		click(driver,SOP.FIRST_SOP_CHECKBOX, "check box to select file");
		// DELETE_SOPS
		assertElementPresent(driver,SOP.DELETE_SOPS, "Delete button is SOP List page");
		click(driver,SOP.DELETE_SOPS, "Delete button in SOP List page");
		handlepopup();
		Thread.sleep(700);
		// Below validate the Data is not present in the tables for the esop
		String esopCountInCESInbox = SQL_Queries.getTheCountInSOPCesInbox(firstESOPId).get(0);
		String esopCountInESOPInbox = SQL_Queries.getTheCountInESOPInbox(firstESOPId).get(0);
		// getTheFieldsForTheESOPs
		compareStrings("0", esopCountInCESInbox);
		compareStrings("0", esopCountInESOPInbox);
	}

	public void metaDataInTheRejectedLog(String esopId) throws Throwable {

		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		// WOKSHEET_SEARCH_LEFT_NAV_LINK
		waitForElementPresent(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "worksheet search link in left nav");
		assertElementPresent(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "assert worksheet search link in left nav");
		click(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK, "click on worksheet search link in left nav");
		// CLASSIC_SEARCH_BTN
		waitForElementPresent(driver,SOP.CLASSIC_SEARCH_BTN, "Classic search button in Worksheet Search Criteria Page");
		assertElementPresent(driver,SOP.CLASSIC_SEARCH_BTN, "assert Classic search button in Worksheet Search Criteria Page");
		click(driver,SOP.CLASSIC_SEARCH_BTN, "click on Classic search button in Worksheet Search Criteria Page");
		String worskheetId = SQL_Queries.getTheRejectedLogForRejectedESOPs(esopId).get(0);
		// WORKSHEET_ID_TEXTBOX
		waitForElementPresent(driver,SOP.WORKSHEET_ID_TEXTBOX, "Id text box in Classic Worksheet Search Criteria Page");
		assertElementPresent(driver,SOP.WORKSHEET_ID_TEXTBOX, "assert Id text box in Classic Worksheet Search Criteria Page");
		type(driver,SOP.WORKSHEET_ID_TEXTBOX, worskheetId, "type Id in text box in Classic Worksheet Search Criteria Page");
		// WORKSHEET_SEARCH_BTN
		waitForElementPresent(driver,SOP.WORKSHEET_SEARCH_BTN, "Search button in Classic Worksheet Search Criteria Page");
		assertElementPresent(driver,SOP.WORKSHEET_SEARCH_BTN,
				"assert Search button in Classic Worksheet Search Criteria Page");
		click(driver,SOP.WORKSHEET_SEARCH_BTN, "click Search button in Classic Worksheet Search Criteria Page");

		// METADATA
		waitForElementPresent(driver,SearchWorksheet.METADATA, "Meta data in Worksheet profile Page");
		assertElementPresent(driver,SearchWorksheet.METADATA, "assert Meta data in Worksheet profile Page");
		String metaData = getText(driver,SearchWorksheet.METADATA, "get the text for Meta data in Worksheet profile Page");
		String damageAmount = metaData.split("\\ Damage Amount : ")[1].split("\\ ,")[0].split("")[0];
		String timeSensitive = metaData.split("\\ Time Sensitive : ")[1].split("\\,")[0].split("")[0];
		String secondReview = metaData.split("\\Second Review : ")[1].split("\\,")[0].split("")[0];
		String shortAnswerDate = metaData.split("\\Short Answer : ")[1].split("\\ ")[0].split("")[0];
		System.out.println(damageAmount);
		System.out.println(timeSensitive);
		System.out.println(secondReview);
		System.out.println(shortAnswerDate);
		if (shortAnswerDate.equals("-")) {
			shortAnswerDate = "N";
		}
		ArrayList<String> metaDataInRejectedLog = SQL_Queries.metaDataInRejectionLog(esopId);
		compareStrings(damageAmount, metaDataInRejectedLog.get(0));
		compareStrings(timeSensitive, metaDataInRejectedLog.get(1));
		compareStrings(secondReview, metaDataInRejectedLog.get(2));
		compareStrings(shortAnswerDate, metaDataInRejectedLog.get(3));
	}

	public String submitESOPWithHardCopyRequiredOrNotSecond(WebDriver driver,String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNoForMultiThreading(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
					.get(1);
			
		/*	if(browserInstance == 2) {
				
				Thread.sleep(5000);
				esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
						.get(0);
				
			}*/
			
			if (!cesQueue.equals("New") && esopId == null) {
				moveESOPFromNewQueueToDiffCESQueue(driver,reportSheet, count);
			}

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			//Below change is Part of Sprint 53 changes
		      waitForElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  assertElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  compareStrings(getText(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
		     //Till here Sprint 53 changes
			if (cesQueue.equals("New")) {
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					//Below change is Part of Sprint 53 changes
				      waitForElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  assertElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  compareStrings(getText(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
				     //Till here Sprint 53 changes
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					click(driver,SOP.CLEARBTN, "Clear Button");
					searchForESOP(driver,esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(driver,SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(driver,SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(driver,SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				
				//INCLUDE_ALL_REP_ASSUMED_BTN
				waitForElementPresent(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				assertElementPresent(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				click(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
								
				// SEARCH_BTN
				waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				click(driver,SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							click(driver,SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(driver,SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					/*
					 * waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					 * assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					 * click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 */
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(driver,SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					click(driver,SOP.GLYPHICON_HOME, "glyphicon button");

					/* Code changed during Accelerated Log Project */
					//Below try and catch block added as part of Sprint 53 scripting
					//from line 8891 to 9024
					String parentWindow = driver.getWindowHandle();
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow(driver);
						driver.close();
						driver.switchTo().window(parentWindow);
						}
					}catch(NoSuchSessionException e ) {
						
					}
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
					click(driver,SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow(driver);
						driver.close();
						driver.switchTo().window(parentWindow);
						Thread.sleep(1000);
						driver.switchTo().frame("frame1");
						}
					}catch(NoSuchSessionException e ) {
						
					}

					try {

						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						if (!lawSuit.equals("")) {
							System.out.println("Reached here with lawsuit value : " + lawSuit);
							selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");

						}

						else {

							selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						}
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {
						attorneyNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						// DROP_DOWN_ATTORNEY_SENDER_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
						assertElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
						selectByIndex(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						String courtNoneAttribute = "";
						courtNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_COURTNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
								"Radio button for Existing Court in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
						// DROP_DOWN_COURT_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
						assertElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
						selectByIndex(driver,SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				/*
				 * //HARD_COPY_DELIVERY waitForElementPresent(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * assertElementPresent(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * compareStrings(hardCopyDeliveryFlag,getText(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value"));
				 */
				List<WebElement> reasonForNotRejection = null;
				// REASON_FOR_NOT_REJECTING
				try {
					reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
					if (reasonForNotRejection != null) {
						Thread.sleep(700);
						selectByIndex(driver,SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
					}
				} catch (NoSuchElementException e) {
				}
				// SUBMIT_CES
				waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
				assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
				click(driver,SOP.SUBMIT_CES, "Submit button in CES");
				Thread.sleep(5000);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return esopId;
	}

	public String actionItemExecution(String esopId) throws Throwable {

		String expeditedLog = "";
		try {
			Thread.sleep(30000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(expeditedLog);

		// ACTION_ITEMS
		waitForElementPresent(driver,SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		assertElementPresent(driver,SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		click(driver,SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		// RETAIN_SOP_STATUS
		waitForElementPresent(driver,SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		assertElementPresent(driver,SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		String retainSOPStatus = getText(driver,SearchWorksheet.RETAIN_SOP_STATUS, "Retain SOP Status");
		compareStrings(retainSOPStatus, "Retained");
		// ISOP_STATUS
		waitForElementPresent(driver,SearchWorksheet.ISOP_STATUS, "ISOP Status");
		assertElementPresent(driver,SearchWorksheet.ISOP_STATUS, "ISOP Status");
		String isopStatus = getText(driver,SearchWorksheet.ISOP_STATUS, "ISOP Status");
		compareStrings(isopStatus, "Executed");
		
		return expeditedLog;
	}

	public void logInActionItemFailure(String esopId) throws Throwable {

		String expeditedLog = "";
		try {
			Thread.sleep(2000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		// ACTION_ITEM_FAILURES
		waitForElementPresent(driver,SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures link in left nav bar");
		assertElementPresent(driver,SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures link in left nav bar");
		click(driver,SearchWorksheet.ACTION_ITEM_FAILURES, "Action Item failures in left nav bar");

		searchForLog(expeditedLog);
		// FIRST_WORKSHEET
		waitForElementPresent(driver,SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		assertElementPresent(driver,SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		click(driver,SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");

		// ACTION_ITEMS
		waitForElementPresent(driver,SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		assertElementPresent(driver,SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");
		click(driver,SearchWorksheet.ACTION_ITEMS, "Action Item button in left nav bar");

		// ACTION_ITEMS_NO_RECORDS
		waitForElementPresent(driver,SearchWorksheet.ACTION_ITEMS_NO_RECORDS, "No Records found in Action Items Page");
		assertElementPresent(driver,SearchWorksheet.ACTION_ITEMS_NO_RECORDS, "No Records found in Action Items Page");
		
		//WORKSHEET_PROFILE_LINK
		waitForElementPresent(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet Profile link");
		assertElementPresent(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK, "workheet Profile link");
		click(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK, "worksheet Profile link");
		
	}

	public void sopWorkflow(String reportSheet, int count, String esopId) throws Throwable {
		String workflow = Excelobject.getCellData(reportSheet, "Workflow", count);
		String logNumber = "";
		try {
			Thread.sleep(2000);
			logNumber = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(logNumber);
		// SOP_WORKFLOW
		waitForElementPresent(driver,SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(driver,SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(driver,SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");

		if (workflow.equals("15001")) {

			compareStrings(workflowInWorksheet, "Full");

		}

		else if (workflow.equals("15002")) {

			compareStrings(workflowInWorksheet, "Accelerated");
		}
	}

	public void actionItemFailuresUI() throws Throwable {
		
		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
        //ACTION_ITEM_FAILURES
		waitForElementPresent(driver,ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		assertElementPresent(driver,ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		click(driver,ActionItemsFailure.ACTION_ITEM_FAILURES, "Action Items Failure link in left nav bar");
		//ACTION_ITEM_FAILURE_PAGE_TITLE
		waitForElementPresent(driver,ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title");
		assertElementPresent(driver,ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title");
		compareStrings("Action Item Failures", getText(driver,ActionItemsFailure.ACTION_ITEM_FAILURE_PAGE_TITLE, "Action Items Failure page title"));
		//SORT_BY
		waitForElementPresent(driver,ActionItemsFailure.SORT_BY, "Sort By label");
		assertElementPresent(driver,ActionItemsFailure.SORT_BY, "Sort By label");
		//RECEIVED_DATE_SORT
		waitForElementPresent(driver,ActionItemsFailure.RECEIVED_DATE_SORT, "Received Date sort link");
		assertElementPresent(driver,ActionItemsFailure.RECEIVED_DATE_SORT, "Received Date sort link");
		//ERROR_REASON_SORT
		waitForElementPresent(driver,ActionItemsFailure.ERROR_REASON_SORT, "Error reason sort link");
		assertElementPresent(driver,ActionItemsFailure.ERROR_REASON_SORT, "Error reason sort link");
		//ASSIGNED_TO_SORT
		waitForElementPresent(driver,ActionItemsFailure.ASSIGNED_TO_SORT, "Assigned to sort link");
		assertElementPresent(driver,ActionItemsFailure.ASSIGNED_TO_SORT, "Assigned to sort link");
		//BRANCH_PLANT_SORT
		waitForElementPresent(driver,ActionItemsFailure.BRANCH_PLANT_SORT, "Branch Plant sort link");
		assertElementPresent(driver,ActionItemsFailure.BRANCH_PLANT_SORT, "Branch Plant sort link");
		//EXPORT_BUTTON
		waitForElementPresent(driver,ActionItemsFailure.EXPORT_BUTTON, "Export button in Action Items failure page");
		assertElementPresent(driver,ActionItemsFailure.EXPORT_BUTTON, "Export button in Action Items failure page");
		//HELP_PAGE_ICON
		waitForElementPresent(driver,ActionItemsFailure.HELP_PAGE_ICON, "Help Page icon in Action Item Failures page");
		assertElementPresent(driver,ActionItemsFailure.HELP_PAGE_ICON, "Help Page icon in Action Item Failures page");
		//CURRENT_FILTER
		waitForElementPresent(driver,ActionItemsFailure.CURRENT_FILTER, "Current filter label in Action Item Failures page");
		assertElementPresent(driver,ActionItemsFailure.HELP_PAGE_ICON, "current filter label  in Action Item Failures page");
		//Below one more check needs to be added for 
		
		
	}

	public void bulkWorksheetInSOPHub(String reportSheet, int count) throws Throwable {
		
		
     String worksheetId = Excelobject.getCellData(reportSheet, "Accelerated Log", count);	
	//SELECT
	waitForElementPresent(driver,SopHub.SELECT, "Select button in Customer Search Page");
	assertElementPresent(driver,SopHub.SELECT, "Select button in Customer Search Page");
	click(driver,SopHub.SELECT, "Select button in Customer Search Page");
	//SOP_HUB_LINK
	waitForElementPresent(driver,SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	assertElementPresent(driver,SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	click(driver,SopHub.SOP_HUB_LINK, "SOP hub link in Select Application Page");
	for(int i = 0; i<10; i++) {
	//LOG_SEARCH_TEXT_FIELD
	waitForElementPresent(driver,SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");
	assertElementPresent(driver,SopHub.LOG_SEARCH_TEXT_FIELD, "Log Search test field in SOP Received Page");		
	type(driver,SopHub.LOG_SEARCH_TEXT_FIELD,worksheetId, "Log Search test field in SOP Received Page");
	//SEARCH_BUTTON
	waitForElementPresent(driver,SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
	assertElementPresent(driver,SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");
	click(driver,SopHub.SEARCH_BUTTON, "Search Button in SOP Received Page");	
	WebElement noSuchWorksheet = null;
	try {
		
		noSuchWorksheet = driver.findElement(By.xpath("//span[contains(text(),'There are no entries in this list.')]"));
		//HOME_BUTTON
		assertElementPresent(driver,SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
		click(driver,SopHub.HOME_BUTTON, "Home Button in SOP Received Page");
		
	}catch(NoSuchElementException e) {
		
	}	
	if(noSuchWorksheet != null) {
	 
		Thread.sleep(12000);
	}
	else {
		break;
	}
   }
	//CT_LOG_NUMBER
	waitForElementPresent(driver,SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
	assertElementPresent(driver,SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub");
	compareStrings(worksheetId,getText(driver,SopHub.CT_LOG_NUMBER, "CT Log number in SOP Hub"));
}
	public void transmittalDataVerification(String reportSheet, int count, String esopId) throws Throwable{
	
		String recipientId = Excelobject.getCellData(reportSheet, "Recipient Id", count);
		String parentWindow = driver.getWindowHandle();
		//FIRST_TRANSMITTAL_BUTTON
		waitForElementPresent(driver,WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		assertElementPresent(driver,WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");
		click(driver,WorksheetCreate.FIRST_TRANSMITTAL_BUTTON, "First Transmittal button in Execute Action items");		
		handlePopUpWindwow(driver);
		String url = driver.getCurrentUrl(); 		
		String pdfData = getPDFContent(url);
	  // below querry the DB to get the below items
		String caseNumber = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(0);
		String plaintiff = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(1);
		String defendant = SQL_Queries.getTheFieldsForTheESOPs(esopId).get(2);
		String courtNameInCES = SQL_Queries.getTheCourtAndAttorneyForCompletedESOPs(esopId).get(1);
		String lawSuitType = SQL_Queries.getTheLawSuitTypeInCESInbox(esopId).get(0);
		String recipientName = SQL_Queries.getTheRecipientName(recipientId).get(0);
		if(courtNameInCES == null) {
			courtNameInCES = "None Specified";
		}
	   String [] worksheetFields = {"TITLE OF ACTION:",			   			        
			        "COURT/AGENCY: "+courtNameInCES,
			        "Case # "+ caseNumber,
			        "NATURE OF ACTION: " + lawSuitType,
                    "ACTION ITEMS: CT has retained the current log, Retain Date: " + getCurrentDate(),
                     };
	   
	    	   
	   for(String str : worksheetFields) {
       if(pdfData.contains(str)){
           flag =  true;                 
           SuccessReport(driver,"Text : " , str + " is present in PDF");
       }
       else {
			failureReport(driver,"Text : " , str + " is not present in PDF");
	 }		
	}
	 
	    String plaintiffInTransmittal = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[0].replaceAll("[^\\x00-\\x7F]", "");
	    String defendantInTransmittal = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[1].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "");	    
	    //System.out.println(pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0]);
	    String recipientInTransmital = pdfData.split("TO: ")[1].split("\n")[0].split("\\R")[0].replace(" ", "");
	    //System.out.println(recipientInTransmital);	   
	    compareStrings(recipientInTransmital.toUpperCase(),recipientName.toUpperCase().replace(" ", ""));	    
	    compareStrings(plaintiff,plaintiffInTransmittal);
	    compareStrings(defendant,defendantInTransmittal);
		driver.close();
		driver.switchTo().window(parentWindow);
  }
	
	public void expeditedTransmissionLog(String esopId) throws Throwable {
		
		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		//EXPEDITED_TRANSMISSIONS
		waitForElementPresent(driver,SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		assertElementPresent(driver,SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		click(driver,SOP.EXPEDITED_TRANSMISSIONS, "Expedited Transmission Link in Left nav bar in SOP Page");
		//CLEARBTN
		assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
		click(driver,SOP.CLEARBTN, "Clear Button");
		searchForESOPWithHash(driver,esopId);
		
		//FIRST_ESOP_IN_EXPEDITED_TRANSMISSION
		waitForElementPresent(driver,SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION, "First ESOP in Expedited Transmission Page");
		assertElementPresent(driver,SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION, "First ESOP in Expedited Transmission Page");
		compareStrings(esopId, getText(driver,SOP.FIRST_ESOP_IN_EXPEDITED_TRANSMISSION,"First ESOP in Expedited Transmission Page"));
		//FIRST_LOG_IN_EXPEDITED_TRANSMISSION
		waitForElementPresent(driver,SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION, "First Log in Expedited Transmission Page");
		assertElementPresent(driver,SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION, "First Log in Expedited Transmission Page");
		compareStrings(expeditedLog, getText(driver,SOP.FIRST_LOG_IN_EXPEDITED_TRANSMISSION,"First Log in Expedited Transmission Page"));
	}

	public void createAndExecuteActionItem(String reportSheet,int count,String esopId) throws Throwable {

		String expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
        String  lawsuitType = Excelobject.getCellData(reportSheet, "Law Suit", count);
		String  hardCopyRequired = Excelobject.getCellData(reportSheet, "Hard Copy DI", count);
		String  entityName = Excelobject.getCellData(reportSheet, "Entity Name", count);
		
		waitForElementPresent(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button");
		assertElementPresent(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button");
		click(driver,SOP.CHOOSE_DI_BTN, "Choose DI Button");
		
		if(hardCopyRequired.equals("No")) {		
	   //VALUE_OF_LAW_SUIT_TYPE_IN_DI
	   int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(driver,SOP.VALUE_OF_LAW_SUIT_TYPE_IN_DI,lawsuitType);
	   System.out.println("the index sent is : " + matchedIndexLawSuit);
	   //USE_BUTTON_IN_LAWSUIT
	   clickOnAParticularIndexOfAnElement(driver,SOP.USE_BUTTON_IN_LAWSUIT,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);	   
	   
	   //SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
	   waitForElementPresent(driver,SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
	   assertElementPresent(driver,SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");
	   click(driver,SOP.SELECT_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Retain button in SOP Papers with Transmittal");		
		
		}
		else if(hardCopyRequired.equals("Yes")) {
		//VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI
		int matchedIndexLawSuit = returnIndexOfMatchedTextvalue(driver,SOP.VALUE_OF_SPECIAL_CIRCUMSTANCES_IN_DI,lawsuitType);
		//USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES
		 clickOnAParticularIndexOfAnElement(driver,SOP.USE_BUTTON_IN_SPECIAL_CIRCUMSTANCES,"Use button in Choose Delivery instrtuction",matchedIndexLawSuit);
		 
		 //EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL
		 waitForElementPresent(driver,SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(driver,SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 click(driver,SOP.EXECUTE_MANUAL_SOP_PAPER_WITH_TRANSMITTAL,"Execute Manual in SOP Papers with Transmittal");
		 //COMMENTS_DRPDWN
		 waitForElementPresent(driver,SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 assertElementPresent(driver,SOP.COMMENTS_DRPDWN,"Execute Manual in SOP Papers with Transmittal");
		 selectByVisibleText(driver,SOP.COMMENTS_DRPDWN,"Hard Copy Required","Execute Manual in SOP Papers with Transmittal");
		 //CONTINUE_BUTTON
		 waitForElementPresent(driver,SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 assertElementPresent(driver,SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 click(driver,SOP.CONTINUE_BUTTON,"Continue button in carrier comments");
		 try {
			 WebElement createPackage = driver.findElement(By.id("btnCreatePackage"));
			 createPackage.click();
		 }catch(NoSuchElementException e) {}
		 //SAVE_BTN
		 assertElementPresent(driver,Entity.SAVE_BTN, "Save button");
		 click(driver,Entity.SAVE_BTN, "Save button");
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementPresent(driver,SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(driver,SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(driver,SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");		 				 
		}

	    //EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL
	   waitForElementPresent(driver,SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   assertElementPresent(driver,SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	   click(driver,SOP.EXECUTE_ISOP_SOP_PAPER_WITH_TRANSMITTAL,"Execute button in SOP Papers with Transmittal");
	
	   for(int i = 0 ; i<10; i++) {
	   ArrayList<String> executedBy = SQL_Queries.executedByInActionItem(expeditedLog);
	   if(!executedBy.get(0).equals("1166") || !executedBy.get(1).equals("1166")) {
		   Thread.sleep(10000);
	    }
	   else {
		   break;
	       }
	   }
	   //WORKSHEET_PROFILE_LINK
	   waitForElementPresent(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   assertElementPresent(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   click(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
	   
	   //POST_STATUS
	   assertElementPresent(driver,SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
	   String postStatus = getText(driver,SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
	   compareStrings(postStatus, "Posted");
	   
	}

	public void unexecuteActionItems(String esopId) throws Throwable{
		
		String expeditedLog = "";
		try {
			Thread.sleep(30000);
			expeditedLog = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchWorksheet(expeditedLog);
		//ACTION_ITEMS_LEFT_NAV_LINK
		waitForElementPresent(driver,SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		assertElementPresent(driver,SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		click(driver,SOP.ACTION_ITEMS_LEFT_NAV_LINK,"Action Item link in left nav bar in worksheet profile");
		
		//UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL
		waitForElementPresent(driver,SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		assertElementPresent(driver,SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		click(driver,SOP.UNEXECUTE_RETAIN_SOP_PAPER_WITH_TRANSMITTAL,"Unexecute Retain SOP");
		//UNEXECUTE_COMMENTS_TEXT_BOX
		waitForElementPresent(driver,SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		assertElementPresent(driver,SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		type(driver,SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Unexecute Retain SOP","Text box for unexecute comments");
		//UNEXECUTE_ACTION_ITEM_BUTTON
		waitForElementPresent(driver,SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		assertElementPresent(driver,SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		click(driver,SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		//UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL
		waitForElementPresent(driver,SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");
		assertElementPresent(driver,SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");
		click(driver,SOP.UNEXECUTE_ISOP_PAPER_WITH_TRANSMITTAL,"Unexecute ISOP");		
		waitForElementPresent(driver,SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		assertElementPresent(driver,SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Text box for unexecute comments");
		type(driver,SOP.UNEXECUTE_COMMENTS_TEXT_BOX,"Unexecute ISOP","Text box for unexecute comments");
		waitForElementPresent(driver,SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		assertElementPresent(driver,SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");
		click(driver,SOP.UNEXECUTE_ACTION_ITEM_BUTTON,"Unexecute Action Item Button");

		   for(int i = 0 ; i<4; i++) {
		   ArrayList<String> executedBy = SQL_Queries.executedByInActionItem(expeditedLog);		   
		   if(executedBy.get(0) != null || executedBy.get(1) != null) {
			   Thread.sleep(10000);
		    }
		   else {
			   break;
		       }
		   }
		   //WORKSHEET_PROFILE_LINK
		   waitForElementPresent(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		   assertElementPresent(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		   click(driver,SearchWorksheet.WORKSHEET_PROFILE_LINK,"worksheet profile link");
		   
		   //POST_STATUS
		   assertElementPresent(driver,SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		   String postStatus = getText(driver,SearchWorksheet.POST_STATUS, "Post Status in Worksheet Profile Page");
		   compareStrings(postStatus, "UnPosted");
		   
		}

	public void createSOPIncidentReportOnTheCreatedWorksheet(String esopId) throws Throwable {
		
		
		String worksheetId = "";
		
		try {
			worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		//CRM_LINK
		waitForElementPresent(driver,HomePage.CRM_LINK,"CRM Link");
		assertElementPresent(driver,HomePage.CRM_LINK,"CRM Link");
		click(driver,HomePage.CRM_LINK,"CRM Link");
		
		assertElementPresent(driver,CRM.REQUEST_SEARCH_PAGE, "Request Search Page");
		assertElementPresent(driver,CRM.CREATE_BUTTON, "Create Button");
		click(driver,CRM.CREATE_BUTTON, "Create Button");
		
		waitForElementPresent(driver,CRM.NEW_REQUEST_PAGE, "New Request Page");
		assertElementPresent(driver,CRM.NEW_REQUEST_PAGE, "New Request Page");
				
		//click(driver,CRM.DROPDOWN_REQUEST_NEW, "Select New from Dropdown");
		waitForElementPresent(driver,CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		assertElementPresent(driver,CRM.SERVICE_TYPE_DROP_DOWN,"Service Type Drop down in New Requests Page");
		selectByVisibleText(driver,CRM.SERVICE_TYPE_DROP_DOWN,"SOP Incident Report", "Select SOP Incident Report from Dropdown");
		
		String parentWindow = driver.getWindowHandle();
		assertElementPresent(driver,CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		click(driver,CRM.WORKSHEET_SEARCH_LINK, "Worksheet Search Link");
		handlePopUpWindwow(driver);
		assertElementPresent(driver,CRM.WORKSHEET_SEARCH_POPUP, "Worksheet Search Popup");
		type(driver,CRM.ENTER_LOGID, worksheetId, "Log ID Entered");
		click(driver,CRM.LOGID_SEARCH_BUTTON, "Log ID Search Button");
		click(driver,Generic.SELECT, "Select Button");
		driver.switchTo().window(parentWindow);
		click(driver,CRM.ERROR_TYPE, "Error Type");
		click(driver,CRM.REQUESTED_VIA, "Requested Via");
		click(driver,CRM.SERVICE_LEVEL, "Service Level");
		click(driver,Generic.SAVE, "Save Button");
		assertElementPresent(driver,CRM.EDIT_REQUEST_PAGE, "Edit Request Page");
		assertElementPresent(driver,CRM.ASSIGNED_STATUS, "Assigned Status");
	}
 
	public void worksheetInMyWorksheetsToReview(String esopId) throws Throwable{
	
		//MY_WORKSHEET
		waitForElementPresent(driver,WorksheetCreate.MY_WORKSHEET,"My Worksheet link");
		assertElementPresent(driver,WorksheetCreate.MY_WORKSHEET,"My Worksheet link");
		click(driver,WorksheetCreate.MY_WORKSHEET,"My worksheet link");
	    //MY_WORKSHEETS_TO_REVIEW_TAB
		waitForElementPresent(driver,CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		assertElementPresent(driver,CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		click(driver,CRM.MY_WORKSHEETS_TO_REVIEW_TAB,"My worksheets to review Tab");
		// CLEARBTN
		waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
		assertElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
		click(driver,SOP.CLEARBTN, "Clear Button of filter");
		String worksheetId = "";
		
		try {
			worksheetId = SQL_Queries.getTheLogNumberInESOPInbox(esopId).get(0);
			System.out.println("The values for WS is " + worksheetId);
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		searchForLog(worksheetId);
		waitForElementPresent(driver,WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA,
				"Log is present in worksheets to review Tab");
		assertElementPresent(driver,WorksheetCreate.FIRST_MY_WORKSHEETS_TO_REVIEW_DATA,
				"Log is present in worksheets to review Tab");
	}

	public void worksheetInMyWorksheetsAndMyTeamWorksheet(String reportSheet , int count) throws Throwable{
		
		String sopWorkFlow = Excelobject.getCellData(reportSheet, "SOP Workflow", count);
		String worksheetIn = Excelobject.getCellData(reportSheet, "Worksheet In", count);
		
		waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
		click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
		//MY_WORKSHEETS_NAV_LINK
		waitForElementPresent(driver,SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");
		assertElementPresent(driver,SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");
		click(driver,SOP.MY_WORKSHEETS_NAV_LINK, "My Worksheet Link in Lefy nav bar");		
		
		if(!worksheetIn.equals("My Worksheet")) {
		 //MY_TEAMS_WORKSHEETS_LINK
		 waitForElementPresent(driver,SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");
		 assertElementPresent(driver,SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");
		 click(driver,SOP.MY_TEAMS_WORKSHEETS_LINK, "My Teams Worksheet Tab");	
			
		}
		
		searchForSOPWorkflow(sopWorkFlow);
		// FIRST_WORKSHEET
		waitForElementPresent(driver,SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		assertElementPresent(driver,SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
		click(driver,SOP.FIRST_WORKSHEET, "First worksheet in the Data Table");
        //SOP_WORKFLOW
		waitForElementPresent(driver,SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		assertElementPresent(driver,SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
		String workflowInWorksheet = getText(driver,SearchWorksheet.SOP_WORKFLOW, "SOP workflow in worksheet profile page");
        compareStrings(sopWorkFlow,workflowInWorksheet);
	}
	
	public void searchForSOPWorkflow(String workflow) throws Throwable {

		waitForElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		assertElementPresent(driver,SOP.FILTERDROPDOWN1, "Filter drop down");
		selectByVisibleText(driver,SOP.FILTERDROPDOWN1, "SOP WorkFlow", "Filter drop down");
		waitForElementToBeClickable(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter drop right");
		assertElementPresent(driver,SOP.DROP_DOWN_LIST_RIGHT, "Filter drop right");
		selectByVisibleText(driver,SOP.DROP_DOWN_LIST_RIGHT, workflow, "Filter drop right");
		waitForElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
		assertElementPresent(driver,SOP.FILTERGOBTN, "Go Button");
		click(driver,SOP.FILTERGOBTN, "Go Button");
	}
	public void searchWorksheet(String worksheetId) throws Throwable {
		try {
			blnEventReport = true;
			//Click On Worksheet Search Link from left nav bar
			click(driver,SOP.WOKSHEET_SEARCH_LEFT_NAV_LINK,"Worksheet Search On Left Nav Link");
			click(driver,SOP.CLASSIC_SEARCH_BTN,"Classic Search Button");
			waitForElementPresent(driver,SOP.SEARCH_BTN, "Search Button");
			
			//Enter an entity Id to be searched and click on search btn
			type(driver,SOP.WORKSHEET_ID_TEXTBOX,worksheetId,"Workhseet Id text Box");
			click(driver,SOP.WORKSHEET_SEARCH_BTN,"Worksheet Search Btn");
						
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void SignIn(WebDriver driver,String strTeam,String strMember) throws Throwable {
		try {
			blnEventReport = true;
			//Validate whether User is navigated to Arrow Login Page
			if(waitForVisibilityOfElementWithoutReport(driver,Login.LOGINBTN, "Login button")) {
				SuccessReport(driver,"Validate whether User is navigated to Arrow Login Page", "User Is succesfully navigated to Arrow Login Page");
				selectByVisibleText(driver,Login.TEAMDROPDOWN, strTeam, "Team Dropdown");
				selectByVisibleText(driver,Login.MEMBERDROPDOWN, strMember, "Member Dropdown");
				click(driver,Login.LOGINBTN, "Log In button");
			}else {
				failureReport(driver,"Validate whether User is navigated to Arrow Login Page", "Failed to Navigate to Arrow Login Page");
			}
			
			waitForElementPresent(driver,HomePage.WELCOMETOARROW, "Entity Link in Top Nav");
			if(isElementPresent(driver,HomePage.WELCOMETOARROW, "Entity Link in Top Nav")) {
				SuccessReport(driver,"Validate whether User is able to login succesffully",
						"User is able to login succesffully");
			}else {
				failureReport(driver,"Validate whether User is able to login succesffully", "Failed to login");
				
			}
			blnEventReport = false;
		} catch (Exception e) {			
			throw e;
		}
	}

	public String submitESOPWithHardCopyRequiredOrNot(WebDriver driver,String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
			
			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNoForMultiThreading(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
					.get(0);
			
			if (!cesQueue.equals("New") && esopId == null) {
				moveESOPFromNewQueueToDiffCESQueue(driver,reportSheet, count);
			}

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			//Below change is Part of Sprint 53 changes
		      waitForElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  assertElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  compareStrings(getText(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
		     //Till here Sprint 53 changes
			if (cesQueue.equals("New")) {
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					//Below change is Part of Sprint 53 changes
				      waitForElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  assertElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  compareStrings(getText(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
				     //Till here Sprint 53 changes
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					click(driver,SOP.CLEARBTN, "Clear Button");
					searchForESOP(driver,esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(driver,SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(driver,SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(driver,SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				
				//INCLUDE_ALL_REP_ASSUMED_BTN
				waitForElementPresent(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				assertElementPresent(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				click(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
								
				// SEARCH_BTN
				waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				click(driver,SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							click(driver,SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(driver,SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					/*
					 * waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					 * assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					 * click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 */
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(driver,SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					click(driver,SOP.GLYPHICON_HOME, "glyphicon button");

					/* Code changed during Accelerated Log Project */
					//Below try and catch block added as part of Sprint 53 scripting
					//from line 8891 to 9024
					String parentWindow = driver.getWindowHandle();
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow(driver);
						driver.close();
						driver.switchTo().window(parentWindow);
						}
					}catch(NoSuchSessionException e ) {
						
					}
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
					click(driver,SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow(driver);
						driver.close();
						driver.switchTo().window(parentWindow);
						Thread.sleep(1000);
						driver.switchTo().frame("frame1");
						}
					}catch(NoSuchSessionException e ) {
						
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					try {

						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						if (!lawSuit.equals("")) {
							System.out.println("Reached here with lawsuit value : " + lawSuit);
							selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");

						}

						else {

							selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						}
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {
						attorneyNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						// DROP_DOWN_ATTORNEY_SENDER_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
						assertElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
						selectByIndex(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						String courtNoneAttribute = "";
						courtNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_COURTNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
								"Radio button for Existing Court in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
						// DROP_DOWN_COURT_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
						assertElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
						selectByIndex(driver,SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				/*
				 * //HARD_COPY_DELIVERY waitForElementPresent(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * assertElementPresent(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * compareStrings(hardCopyDeliveryFlag,getText(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value"));
				 */
				List<WebElement> reasonForNotRejection = null;
				// REASON_FOR_NOT_REJECTING
				try {
					reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
					if (reasonForNotRejection != null) {
						Thread.sleep(700);
						selectByIndex(driver,SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
					}
				} catch (NoSuchElementException e) {
				}
				// SUBMIT_CES
				waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
				assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
				click(driver,SOP.SUBMIT_CES, "Submit button in CES");
				Thread.sleep(5000);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return esopId;
	}

	public String submitESOPWithHardCopyRequiredOrNotThird(int browserInstance,WebDriver driver,String reportSheet, int count) throws Throwable {

		String esopId = "";
		try {

			String cesQueue = Excelobject.getCellData(reportSheet, "CES Queue", count);
			String hardCopyDeliveryFlag = Excelobject.getCellData(reportSheet, "Hard Copy", count);
			String cesQueuCode = Excelobject.getCellData(reportSheet, "CES Queue Status", count);
			String arrowEntity = Excelobject.getCellData(reportSheet, "Arrow Entity", count);
			String branchPlant = Excelobject.getCellData(reportSheet, "Branch Plant", count);
			String levelOfUser = Excelobject.getCellData(reportSheet, "User Level", count);
			String caseNum1 = Excelobject.getCellData(reportSheet, "Case Number", count);
			String plaintiff = Excelobject.getCellData(reportSheet, "Plaintiff", count);
			String defendant = Excelobject.getCellData(reportSheet, "Defendant", count);
			String attorneyName = Excelobject.getCellData(reportSheet, "Attorney", count);
			String courtName = Excelobject.getCellData(reportSheet, "Court", count);
			String lawSuit = Excelobject.getCellData(reportSheet, "Law Suit", count);
			esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNoForMultiThreading(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
					.get(2);
			
	/*		if(browserInstance == 3) {
				
				Thread.sleep(10000);
				esopId = SQL_Queries.getTheTheESOPForHardCopyRequiredOrNo(hardCopyDeliveryFlag.split("")[0], cesQueuCode)
						.get(0);
				
			}*/
			
			
			if (!cesQueue.equals("New") && esopId == null) {
				moveESOPFromNewQueueToDiffCESQueue(driver,reportSheet, count);
			}
			

			waitForElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			assertElementPresent(driver,SOP.SOP_LINK_HEADER, "SOP Link in Header");
			click(driver,SOP.SOP_LINK_HEADER, "SOP link in header");
			//Below change is Part of Sprint 53 changes
		      waitForElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  assertElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
			  compareStrings(getText(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
		     //Till here Sprint 53 changes
			if (cesQueue.equals("New")) {
				waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
				click(driver,SOP.CLEARBTN, "Clear Button");
				searchForESOP(driver,esopId);
				try {
					WebElement noRecords = driver.findElement(SOP.NO_RECORDS_BAR);
					waitForElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					assertElementPresent(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					click(driver,SOP.SOP_15DAYS_TAB, "SOP > 15 Days link");
					//Below change is Part of Sprint 53 changes
				      waitForElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  assertElementPresent(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link");
					  compareStrings(getText(driver,SOP.SOP_WORKFLOW_SORT, "SOP workflow Sort by Link"),"SOP Workflow");
				     //Till here Sprint 53 changes
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button");
					click(driver,SOP.CLEARBTN, "Clear Button");
					searchForESOP(driver,esopId);
				} catch (NoSuchElementException e) {
				}

				Thread.sleep(1000);
				waitForElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				assertElementPresent(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
				click(driver,SOP.CESSELECTBTN, "CES Select Button in SOP List Page");
			} else if (!cesQueue.equals("New")) {

				// CES_LEFT_NAV_LINK
				waitForElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				assertElementPresent(driver,SOP.CES_LEFT_NAV_LINK, "CES Button in left nav bar");
				click(driver,SOP.CES_LEFT_NAV_LINK, "Click on CES Button in left nav bar");
				// CES_PRODUCTIVITY_TAB
				waitForElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				assertElementPresent(driver,SOP.CES_PRODUCTIVITY_TAB, "CES Productivity tab");
				click(driver,SOP.CES_PRODUCTIVITY_TAB, "Click on CES Productivity tab");

				if (cesQueue.equals("Escalated List")) {
					// ESCALATED_LIST_TAB
					waitForElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ESCALATED_LIST_TAB, "Escalated List Tab Button in CES Page");
					click(driver,SOP.ESCALATED_LIST_TAB, "Click on Escalated List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
				}

				else if (cesQueue.equals("OnHold List")) {
					// ON_HOLD_LIST_TAB
					waitForElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.ON_HOLD_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.ON_HOLD_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// FIRST_ONHOLD_CES_SELECT_BUTTON
					waitForElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "First CES Select Button in CES Page");
					click(driver,SOP.FIRST_ONHOLD_CES_SELECT_BUTTON, "Click on First CES Select Button in CES Page");
					// create on filter search for New York SOP Team
				}

				else if (cesQueue.equals("Rejections List")) {
					// REJECTION_LIST_TAB
					waitForElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					assertElementPresent(driver,SOP.REJECTION_LIST_TAB, "OnHold List Tab Button in CES Page");
					click(driver,SOP.REJECTION_LIST_TAB, "Click on OnHold List Tab Button in CES Page");
					searchForESOP(driver,esopId);
					// REJECTIONS_LIST_FIRST_CES_SELECT
					waitForElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					assertElementPresent(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "First CES Select Button in CES Page");
					click(driver,SOP.REJECTIONS_LIST_FIRST_CES_SELECT, "Click on First CES Select Button in CES Page");
				}
			}
			Thread.sleep(2000);
			driver.switchTo().frame("frame1");
			System.out.println("Switched to Frame 1");
			Thread.sleep(3000);
			// TRAINGLE_ICON_ARROW_ENTITY
			// waitForElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section
			// Expaned");
			assertElementPresent(driver,SOP.TRAINGLE_ICON_ARROW_ENTITY, "Entity Section Expaned");
			// INTAKEMETHODVALUE
			waitForElementPresent(driver,SOP.INTAKEMETHODVALUE, "intake method value");
			String cdsop = getText(driver,SOP.INTAKEMETHODVALUE, "intake method value");

			if (!arrowEntity.equals("")) {
				waitForElementPresent(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				String arrowEntityCheckedAttribute = getAttribute(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "checked");
				if (arrowEntityCheckedAttribute == null) {
					click(driver,SOP.ARROW_ENTITY_RADIO_BUTTON, "Radio Button to Select Arrow Entity");
				}
				waitForElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				assertElementPresent(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");
				click(driver,SOP.SELECT_ARROW_ENTITY_BTN, "Select arrow Entity button on ESOP");

				if (!cdsop.equals("CDSOP")) {
					if (branchPlant.equals("CTCORP")) {
						// CTCORP_RADIO_BUTTON
						waitForElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.CTCORP_RADIO_BUTTON,
								"CTCORP Radio Button on search Entity criteria page");
						click(driver,SOP.CTCORP_RADIO_BUTTON, "click on CTCORP Radio Button on search Entity criteria page");

					} else if (branchPlant.equals("NRAI")) {
						// NRAI_RADIO_BUTTON
						waitForElementPresent(driver,SOP.NRAI_RADIO_BUTTON,
								"NRAI Radio Button on search Entity criteria page");
						assertElementPresent(driver,SOP.NRAI_RADIO_BUTTON, "NRAI Radio Button on search Entity criteria page");
						click(driver,SOP.NRAI_RADIO_BUTTON, "click on NRAI Radio Button on search Entity criteria page");
					}
				}
				// ENTITY_NAME_TEXTFIELD
				waitForElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				assertElementPresent(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				click(driver,SOP.ENTITY_NAME_TEXTFIELD, "Entity search text box on ESOP");
				if (cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, "BOM Generic", "Entity search text box on ESOP");
				} else if (!cdsop.equals("CDSOP")) {
					selectBySendkeys(driver,SOP.ENTITY_NAME_TEXTFIELD, arrowEntity, "Entity search text box on ESOP");
				}
				
				//INCLUDE_ALL_REP_ASSUMED_BTN
				waitForElementPresent(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				assertElementPresent(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
				click(driver,SOP.INCLUDE_ALL_REP_ASSUMED_BTN, "Include All rep assumed check box");
								
				// SEARCH_BTN
				waitForElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				assertElementPresent(driver,SOP.SEARCH_BTN, "Search button");
				click(driver,SOP.SEARCH_BTN, "Search button");
				int entitySearchCount = 0;
				// ENTITY_SEARCH_RESULT_COUNT
				waitForElementPresent(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count");
				entitySearchCount = Integer.valueOf(getText(driver,SOP.ENTITY_SEARCH_RESULT_COUNT, "Searched Entity Count"));
				if (entitySearchCount == 0) {
					// Click on unidentified entity
					waitForElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					assertElementPresent(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					String disabledUnEntity = "";
					try {
						disabledUnEntity = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "disabled");
						System.out.println("wdlncjwkcjkwncjwc " + disabledUnEntity);
					} catch (NullPointerException e) {
					}
					if (disabledUnEntity == null) {
						click(driver,SOP.UNIDENTIFIED_ENTITY_BTN, "Searched Entity Count");
					}
					Thread.sleep(1500);
					try {
						if (disabledUnEntity.equals("true")) {
							// SEARCH_AGAIN_BUTTON
							waitForElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							assertElementPresent(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							click(driver,SOP.SEARCH_AGAIN_BUTTON, "Search Again Button");
							// CANCEL_BUTTON
							waitForElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							assertElementPresent(driver,SOP.CANCEL_BUTTON, "Cancel Button");
							click(driver,SOP.CANCEL_BUTTON, "Cancel Button");
						}
					} catch (NullPointerException e) {
					}
					System.out.println("REached here in line 6431");
					Thread.sleep(2000);
					// below will be a go ahead when the value for unidentified Entity above is
					// selected
					String unEntityRadioSelected = "";
					try {
						unEntityRadioSelected = getAttribute(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "checked");
					} catch (NoSuchElementException e) {
					} catch (NullPointerException e) {
					}
					Thread.sleep(1000);
					try {
						if (unEntityRadioSelected == null) {
							click(driver,SOP.UNIDENTIFIED_ENTITY_RADIO_BUTTON, "click on unidentified radio button");
						}
					} catch (NullPointerException e) {
					}
					// ENTITY_TEXT_BOX
					waitForElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					assertElementPresent(driver,SOP.ENTITY_TEXT_BOX, "Entity Name text box");
					type(driver,SOP.ENTITY_TEXT_BOX, "Entity Under Test", "Entity Name text box");
					// DOMESTIC_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					assertElementPresent(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, "Dom Jurisdiction drop down");
					selectByIndex(driver,SOP.DOMESTIC_JURISDICTION_SELECTION, 1, "Dom Jurisdiction drop down");
					// REP_JURISDICTION_SELECTION
					waitForElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					assertElementPresent(driver,SOP.REP_JURISDICTION_SELECTION, "Rep Jurisdiction drop down");
					selectByIndex(driver,SOP.REP_JURISDICTION_SELECTION, 1, "Rep Jurisdiction drop down");
					try {
						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						Thread.sleep(1500);
						selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");

					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
				} else if (entitySearchCount != 0) {
					// REP_STATUS_SORT
					/*
					 * waitForElementPresent(driver,SOP.REP_STATUS_SORT, "REp Status link in CES Page");
					 * assertElementPresent(driver,SOP.REP_STATUS_SORT, "Rep status Link in CES Page");
					 * click(driver,SOP.REP_STATUS_SORT, "click on Rep status link in CES Page");
					 */
					// FIRST_ENTITY_IN_SEARCH_RESULT
					waitForElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					assertElementPresent(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					click(driver,SOP.FIRST_ENTITY_IN_SEARCH_RESULT, "First Entity Search");
					// CONTINUE_BUTTON
					try {
						List<WebElement> action = driver.findElements(SOP.CONTINUE_BUTTON);
						if (action.size() > 0) {

							click(driver,SOP.CONTINUE_BUTTON, "Click on Continue button in CES page");
						}
					} catch (NoSuchElementException e) {
					}
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					assertElementPresent(driver,SOP.GLYPHICON_HOME, "glyphicon button");
					click(driver,SOP.GLYPHICON_HOME, "glyphicon button");

					/* Code changed during Accelerated Log Project */
					//Below try and catch block added as part of Sprint 53 scripting
					//from line 8891 to 9024
					String parentWindow = driver.getWindowHandle();
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow(driver);
						driver.close();
						driver.switchTo().window(parentWindow);
						}
					}catch(NoSuchSessionException e ) {
						
					}
					Thread.sleep(3000);
					driver.switchTo().frame("frame1");
					waitForElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					assertElementPresent(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					click(driver,SOP.ARROW_REPRESENTATION, "Arrow representation button");
					// CLEARBTN
					waitForElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
					assertElementPresent(driver,SOP.CLEARBTN, "Clear Button of filter");
					click(driver,SOP.CLEARBTN, "Clear Button of filter");
					//FIRST_REP_CES_REP_UNITS
					waitForElementPresent(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					assertElementPresent(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");
					click(driver,SOP.FIRST_REP_CES_REP_UNITS,"First Rep in Representations Units Page");					
					try {		
						Set<String> windows = driver.getWindowHandles();
						if(windows.size() > 1) {
						handlePopUpWindwow(driver);
						driver.close();
						driver.switchTo().window(parentWindow);
						Thread.sleep(1000);
						driver.switchTo().frame("frame1");
						}
					}catch(NoSuchSessionException e ) {
						
					}

					// PLAINTIFF_TEXT_BOX
					waitForElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					assertElementPresent(driver,SOP.PLAINTIFF_TEXT_BOX, "plaintiff text box");
					type(driver,SOP.PLAINTIFF_TEXT_BOX, plaintiff, "plaintiff text box");
					// DEFENDANT_TEXT_BOX
					waitForElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					assertElementPresent(driver,SOP.DEFENDANT_TEXT_BOX, "defendant text box");
					type(driver,SOP.DEFENDANT_TEXT_BOX, defendant, "defendant text box");
					waitForElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					assertElementPresent(driver,SOP.CASE_ID_TEXTBOX, "Case Id text box");
					type(driver,SOP.CASE_ID_TEXTBOX, caseNum1, "Case Id text box");
					try {

						driver.findElement(SOP.LAWSUITTYPE_DROPDOWN);
						if (!lawSuit.equals("")) {
							System.out.println("Reached here with lawsuit value : " + lawSuit);
							selectByVisibleText(driver,SOP.LAWSUITTYPE_DROPDOWN, lawSuit, "Law suit type in CES Page");

						}

						else {

							selectByIndex(driver,SOP.LAWSUITTYPE_DROPDOWN, 3, "Law Suit Type drop down");
						}
					} catch (NoSuchElementException e) {
					}
					// DOCUMENT_TYPE_DROPDWN
					try {
						driver.findElement(SOP.NRAI_DOCUMENT_TYPE);
						selectByIndex(driver,SOP.NRAI_DOCUMENT_TYPE, 3, "Document Type drop down");
					} catch (NoSuchElementException e) {
					}
				}
				try {
					// ATTORNEY_SENDER_LABEL
					driver.findElement(SOP.ATTORNEY_SENDER_LABEL);

				} catch (NoSuchElementException e) {

					printMessageInReport("Attorney / Sender label is not present for " + levelOfUser + " user");
				}
				try {
					// COURT_LABEL
					driver.findElement(SOP.COURT_LABEL);

				} catch (NoSuchElementException e) {
					printMessageInReport("Court fields label is not present for " + levelOfUser + " user");
				}
				try {
					// REJECTION_RULES_LABEL
					driver.findElement(SOP.REJECTION_RULES_LABEL);
				} catch (NoSuchElementException e) {
					printMessageInReport("Rejection Rule label not present for " + levelOfUser + " user");

				}
				// Below one check can be applied if attorney and court modification needs to be
				// done - 1476
				if (!attorneyName.equals("")) {
					// RADIO_BUTTON_ATTORNEYNONE
					String attorneyNoneAttribute = "";

					try {
						attorneyNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_ATTORNEYNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_ATTORNEYSENDER,
								"Radio button for Existing Attorney Sender in CES Page");
						// DROP_DOWN_ATTORNEY_SENDER_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "Drop down for Attorney Sender Name");
						assertElementPresent(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, "DROP down for Attorney Sender Name");
						selectByIndex(driver,SOP.DROP_DOWN_ATTORNEY_SENDER_NAME, 1, "DROP down for Attorney Sender Name");
					} catch (NoSuchElementException e) {
					}
				}

				if (!courtName.equals("")) {
					try {
						String courtNoneAttribute = "";
						courtNoneAttribute = getAttribute(driver,SOP.RADIO_BUTTON_COURTNONE, "checked");
						waitForElementPresent(driver,SOP.RADIO_BUTTON_EXISTING_COURT,
								"Radio button for Existing Court in CES Page");
						click(driver,SOP.RADIO_BUTTON_EXISTING_COURT, "Radio button for Existing Court in CES Page");
						// DROP_DOWN_COURT_NAME
						waitForElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "Drop down for Court Name");
						assertElementPresent(driver,SOP.DROP_DOWN_COURT_NAME, "DROP down for Court Name");
						selectByIndex(driver,SOP.DROP_DOWN_COURT_NAME, 1, "DROP down for Court Name");
					} catch (NoSuchElementException e) {
					}
				}
				Thread.sleep(1000);
				List<WebElement> traceableMail = null;
				try {
					traceableMail = driver.findElements(SOP.TRACEABLE_MAIL_FIELD);
					if (traceableMail != null) {
						type(driver,SOP.TRACEABLE_MAIL_FIELD, "123456", "Traceable mail field in CES page");
					}
				} catch (NoSuchElementException e) {
				}
				// Below one check to validate Hard copy Required label and data
				/*
				 * //HARD_COPY_DELIVERY waitForElementPresent(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * assertElementPresent(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value");
				 * compareStrings(hardCopyDeliveryFlag,getText(driver,SOP.HARD_COPY_DELIVERY,
				 * "Hard Copy Delivery Flag Value"));
				 */
				List<WebElement> reasonForNotRejection = null;
				// REASON_FOR_NOT_REJECTING
				try {
					reasonForNotRejection = driver.findElements(SOP.REASON_FOR_NOT_REJECTING);
					if (reasonForNotRejection != null) {
						Thread.sleep(700);
						selectByIndex(driver,SOP.REASON_FOR_NOT_REJECTING, 1, "Reason for not rejection drop down");
					}
				} catch (NoSuchElementException e) {
				}
				// SUBMIT_CES
				waitForElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
				assertElementPresent(driver,SOP.SUBMIT_CES, "Submit button in CES");
				click(driver,SOP.SUBMIT_CES, "Submit button in CES");
				Thread.sleep(5000);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return esopId;
	}

}

	