package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint36 extends BusinessFunctions_NPD {

	//@Test
	public void rejectionRulesMaintenanceApplication() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint36, "GCNBO-1184");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1184", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1184", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1184", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1184", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1184", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rule")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceApplication("GCNBO-1184", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void rejectionRulesUpdateAndValidate() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint36, "GCNBO-1270");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1270", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1270", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1270", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1270", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1270", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rule")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						selectTheJurisdictionAndEdit("GCNBO-1270", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void sopRejectionRulesMaintenanceApplicationAccess() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint36, "GCNBO-1277");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1277", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1277", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1277", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1277", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1277", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rules Maintenance Role")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceRole("GCNBO-1277",iLoop); 
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					} else if (testCaseID.contains("Application access")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceAccess("GCNBO-1277",iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
