package com.arrow.npd.scripts;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint3 extends BusinessFunctions_NPD {
	@Test
	public void cesMLSliderWithData() throws Throwable{
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint3, "CES");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CES";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
				
				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);
					
					//This will mark the beginning of row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Started");
					 
					//This method will log into the Application
					  SignIn(strTeam, strMember);
					
					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
					  verifyCESMLSliderWithData(SheetName, iLoop);
					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	@Test
	public void adminCESMLSlider() throws Throwable{
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint3, "Admin");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "Admin";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
				
				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);
					
					//This will mark the beginning of row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Started");
					 
					//This method will log into the Application
					  SignIn(strTeam, strMember);
					
					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
					  adminCESMLSliderPage(SheetName, iLoop);
					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
	}
}
