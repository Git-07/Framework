package com.arrow.npd.scripts;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint38 extends BusinessFunctions_NPD {
	

	//@Test
	public void newStatusCodeForPossibleRejection() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "GCNBO-1425");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			
				String testCaseID = Excelobject.getCellData("GCNBO-1425", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1425", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1425", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1425", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1425", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1425", iLoop);
						compareTheCurrentStatus("GCNBO-1425", iLoop,esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//with this function sop upload needs to be done with para HCR -> Yes or No	
	@Parameters({"environment"})
	//@Test
	public void rejectReasonAndReasonForNotRejectingFunctionality(String environment) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "GCNBO-1183");			
			//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows(),"Yes",environment);
			//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows(),"No",environment);
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1183", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1183", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1183", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1183", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1183", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);						
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						entitySectionDetailsOnProcessingCES("GCNBO-1183", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//@Test
	public void postCompletCESGrandTotalAndTier3CountsCESProductivity() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "GCNBO-1284");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {			
				String testCaseID = Excelobject.getCellData("GCNBO-1284", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1284", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1284", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1284", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1284", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);	
						entitySectionDetailsOnProcessingCES("GCNBO-1284", iLoop);
						cesProductivityGrandTotalAndTier3();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 	  
	   
	    //@Test
		public void submitTheDSSOP() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "Submit_DSSOP");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("Submit_DSSOP", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("Submit_DSSOP", "Description", iLoop);
					String runStatus = Excelobject.getCellData("Submit_DSSOP", "RunStatus", iLoop);
					String member = Excelobject.getCellData("Submit_DSSOP", "Member", iLoop);
					String team = Excelobject.getCellData("Submit_DSSOP", "Team", iLoop);
					
					if (runStatus.trim().equalsIgnoreCase("Y")) {				
						if (testCaseID.contains("Process")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);	
							submitTheDSSOPWithNewStatus("Submit_DSSOP",iLoop);							
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}					
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	   
	    @Test
		public void submitTheDSSOP2() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "Submit_DSSOP");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("Submit_DSSOP", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("Submit_DSSOP", "Description", iLoop);
					String runStatus = Excelobject.getCellData("Submit_DSSOP", "RunStatus", iLoop);
					String member = Excelobject.getCellData("Submit_DSSOP", "Member", iLoop);
					String team = Excelobject.getCellData("Submit_DSSOP", "Team", iLoop);
					
					if (runStatus.trim().equalsIgnoreCase("Y")) {				
						if (testCaseID.contains("Process")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//entitySectionDetailsOnProcessingCES("Submit_DSSOP",iLoop);
							submitTheDSSOPWithNewStatus("Submit_DSSOP",iLoop);						
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}					
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	   
	  @Test
		public void submitTheDSSOP3() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "Submit_DSSOP");
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					String testCaseID = Excelobject.getCellData("Submit_DSSOP", "TestCase-ID", iLoop);
					String description = Excelobject.getCellData("Submit_DSSOP", "Description", iLoop);
					String runStatus = Excelobject.getCellData("Submit_DSSOP", "RunStatus", iLoop);
					String member = Excelobject.getCellData("Submit_DSSOP", "Member", iLoop);
					String team = Excelobject.getCellData("Submit_DSSOP", "Team", iLoop);
					
					if (runStatus.trim().equalsIgnoreCase("Y")) {				
						if (testCaseID.contains("Process")) {					
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							//entitySectionDetailsOnProcessingCES("Submit_DSSOP",iLoop);
							submitTheDSSOPWithNewStatus("Submit_DSSOP",iLoop);							
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}					
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		  // @Test
			public void moveToCESQueue() throws Throwable {
				try {
					inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint38, "DiffQueue");
					for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
						String testCaseID = Excelobject.getCellData("DiffQueue", "TestCase-ID", iLoop);
						String description = Excelobject.getCellData("DiffQueue", "Description", iLoop);
						String runStatus = Excelobject.getCellData("DiffQueue", "RunStatus", iLoop);
						String member = Excelobject.getCellData("DiffQueue", "Member", iLoop);
						String team = Excelobject.getCellData("DiffQueue", "Team", iLoop);
						
						if (runStatus.trim().equalsIgnoreCase("Y")) {				
							if (testCaseID.contains("Process")) {					
								child = extent.startTest(testCaseID, description);
								iterationReport(iLoop, testCaseID + " Started");
								SignIn(team, member);	
								
								moveESOPFromNewQueueToDiffCESQueue("DiffQueue", iLoop);
								parent.appendChild(child);
								iterationReport(iLoop, testCaseID + " Completed");
								driver.get(URL);
							}					
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
}


