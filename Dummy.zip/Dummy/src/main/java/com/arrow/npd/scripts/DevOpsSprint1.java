package com.arrow.npd.scripts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class DevOpsSprint1 extends BusinessFunctions_NPD{

	
	@Test
	public void accleratedAndFullWorksheet() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint1, "48791And48793");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("48791And48793", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("48791And48793", "Description", iLoop);
			String runStatus = Excelobject.getCellData("48791And48793", "RunStatus", iLoop);
			String member = Excelobject.getCellData("48791And48793", "Member", iLoop);
			String team = Excelobject.getCellData("48791And48793", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Search for the Log")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);				
					worksheetInMyWorksheetsAndMyTeamWorksheet("48791And48793",iLoop);
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {
		e.printStackTrace();
	
	}	
}


}
