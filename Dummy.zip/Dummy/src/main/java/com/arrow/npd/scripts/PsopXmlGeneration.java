package com.arrow.npd.scripts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;


public class PsopXmlGeneration extends BusinessFunctions_NPD {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;
    /*ESOP Id equal:  19344079
	ESOP Id equal:  19344080
	*/
	List<String> fileNames = new ArrayList<String>();
	List<String> esopIds = new ArrayList<String>();
	HashMap<Integer, String> esopMap = new HashMap<Integer,String>();
	HashMap<Integer, String> workSheetMap = new HashMap<Integer,String>();
	int esopKey =1;
	int worksheetKey = 1;
	//@Test
	public void writeToExcel() throws Throwable {

		/*esopMap.put(1, "Test1");
		esopMap.put(8, "Test2");
		esopMap.put(12, "Test3");
		esopMap.put(13, "Test4");
		esopMap.put(14, "Test5");
		esopMap.put(2, "Test6");
		esopMap.put(7, "Test7");*/			
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			_testCaseID = Excelobject.getCellData("PSOP", "TestCase-ID", iLoop);
			_description = Excelobject.getCellData("PSOP", "Description", iLoop);
			_runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop);
			_member = Excelobject.getCellData("PSOP", "Member", iLoop);
			_team = Excelobject.getCellData("PSOP", "Team", iLoop);
			if (_runStatus.trim().equalsIgnoreCase("Y")) {	
			    intialiseTheReport(_testCaseID, _description, iLoop);
				SignIn(_team, _member);
				esopMap.put(esopKey,"Test"+esopKey);
			}
			esopKey++;
			System.out.println("The value of ESOP key : " + esopKey);
		}
		//inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
		//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDPSOPXML,esopKey - 1,"ESOP Id",esopMap);
	}
	
	@Test
	public void enableThePSAndUploadSOP() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
			for (int iLoop = 0; iLoop < inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("PSOP", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("PSOP", "Description", iLoop);
					_runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop);
				_member = Excelobject.getCellData("PSOP", "Member", iLoop);
				_team = Excelobject.getCellData("PSOP", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("For Standalone Entity")) {
						searchForTheEntity("PSOP", iLoop);
						enableThePS();
					} else if (_testCaseID.contains("For Affiliated Entity")) {
						searchForTheAffiliation("PSOP", iLoop);
						enableThePS();
					}
				}
		}
	// fileNames = uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows());
	}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void esopIdGenerationAfterSOPUploaded() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");			
			int file = 0;			
			for (int iLoop = 0; iLoop < inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("PSOP", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("PSOP", "Description", iLoop);
				_runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop);
				_member = Excelobject.getCellData("PSOP", "Member", iLoop);
				_team = Excelobject.getCellData("PSOP", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					searchTheDocumentUploadedRBCOld(fileNames.get(file));
					selectAndAssignTheFileToTeam();
					String esopId = completeTheCESESOP("PSOP",iLoop,fileNames.get(file));
					esopIds.add(esopId);
					esopMap.put(esopKey, esopId);	//This one newly added for making esopMap				
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
					System.out.println("File slected: "+fileNames.get(file));					
					file++;
					Thread.sleep(5000);
				}
				esopKey++;
				System.out.println("The value of ESOP key : " + esopKey);
			}
			//Below functions newly added to write ESOP ids to test data sheet  
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
			//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDPSOPXML,esopKey - 1,"ESOP Id",esopMap);        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Parameters({"environment"})	
	//@Test
	public void esopIdGeneration(String environment) throws Throwable {
		try {
			/*List<String> fileNames = new ArrayList<String>();
			List<String> esopIds = new ArrayList<String>();*/
			//fileNames.add("Te0223.PDF");
			//fileNames.add("ABCDE02221.PDF");
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
			fileNames = uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
			//String fileName = getCurrentDate().split("\\/")[0] + getCurrentDate().split("\\/")[1]+"Test";
			/*String fileName = "Test"+getCurrentDate().split("\\/")[0] + getCurrentDate().split("\\/")[1];
			String currentFileName = null;		
			String desktopPath = System.getProperty("user.home") + "//Desktop";
			copyTheFile(TestFileXMLToUploadScanRBCOld, desktopPath, PowerShellToCopy);
			copyTheFile(TestFilePDFToUploadScanRBCOld, desktopPath, PowerShellToCopy);
			renameTheFiles(desktopPath + "\\TestDataNoHardCopy.XML", fileName + ".XML", PowerShellToRename);
			renameTheFiles(desktopPath + "\\TestDataNoHardCopy.PDF", fileName + ".PDF", PowerShellToRename);
			updateTheXML(desktopPath + "\\" + fileName + ".XML", getCurrentDate(), PowerShellToUpdate);
			int j = 0;
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
				if(j == 1){
					j++;
				}
				if (j == 0) {
					copyTheFile(desktopPath + "\\" + fileName + ".XML", NasScanFirstPath, PowerShellToCopy);
					//Thread.sleep(10000);
					copyTheFile(desktopPath + "\\" + fileName + ".PDF", NasScanFirstPath, PowerShellToCopy);
					Thread.sleep(15000);
					currentFileName = fileName + ".PDF";
					fileNames.add(currentFileName);
					renameTheFiles(desktopPath + "\\" + fileName + ".XML", fileName + ++j + ".XML",
							PowerShellToRename);
					renameTheFiles(desktopPath + "\\" + fileName + ".PDF", fileName + j + ".PDF",
							PowerShellToRename);						
				}
				else if (j > 1) {
					int i = j - 1;
					copyTheFile(desktopPath + "\\" + fileName + i + ".XML", NasScanFirstPath, PowerShellToCopy);					
					Thread.sleep(10000);
					copyTheFile(desktopPath + "\\" + fileName + i + ".PDF", NasScanFirstPath, PowerShellToCopy);
					Thread.sleep(10000);
					currentFileName = fileName + i + ".PDF";
					fileNames.add(currentFileName);
					renameTheFiles(desktopPath + "\\" + fileName + i + ".XML", fileName + j + ".XML",
							PowerShellToRename);
					renameTheFiles(desktopPath + "\\" + fileName + i + ".PDF", fileName + j + ".PDF",
							PowerShellToRename);
					j++;
					
				}
				}
			}
			if(j == 1) {
				deleteTheFile(desktopPath + "\\" + fileName + j + ".PDF",
						PowerShellToDelete);
				deleteTheFile(desktopPath + "\\" + fileName + j + ".XML",
						PowerShellToDelete);
			}
			else {
			deleteTheFile(desktopPath + "\\" + fileName + --j + ".PDF",
					PowerShellToDelete);
			deleteTheFile(desktopPath + "\\" + fileName + j + ".XML",
					PowerShellToDelete);
			}
			Thread.sleep(140000);*/
			int file = 0;			
			for (int iLoop = 0; iLoop < inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("PSOP", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("PSOP", "Description", iLoop);
				_runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop);
				_member = Excelobject.getCellData("PSOP", "Member", iLoop);
				_team = Excelobject.getCellData("PSOP", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {					
/*					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					searchTheDocumentUploadedRBCOld(fileNames.get(file));
					selectAndAssignTheFileToTeam();
					String esopId = completeTheCESESOP("PSOP",iLoop,fileNames.get(file));
					esopIds.add(esopId);
					System.out.println("ESOP Id equal: " +esopId);
					Thread.sleep(25000);
					String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("PSOP",iLoop,esopId);
					System.out.println("WorkSheet Id equal: " +worksheetId);
					searchWorksheet(worksheetId);
					manageActionItemPSOPAndExecuteCentralized("PSOP",iLoop);
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
                    System.out.println("File slected: "+fileNames.get(file));
                    file++;*/					
				    intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("For Standalone Entity")) {
						searchForTheEntity("PSOP", iLoop);
						enableThePS();
					} else if (_testCaseID.contains("For Affiliated Entity")) {
						searchForTheAffiliation("PSOP", iLoop);
						enableThePS();
					}
					searchTheDocumentUploadedRBCOld(fileNames.get(file));
					selectAndAssignTheFileToTeam();
					String esopId = completeTheCESESOP("PSOP",iLoop,fileNames.get(file));
					esopIds.add(esopId);
					esopMap.put(esopKey, esopId);	//This one newly added for making esopMap				
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
					System.out.println("File slected: "+fileNames.get(file));					
					file++;
					Thread.sleep(5000);
				}
				esopKey++;
				System.out.println("The value of ESOP key : " + esopKey);
			}
			//Below functions newly added to write ESOP ids to test data sheet  
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
			//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDPSOPXML,esopKey - 1,"ESOP Id",esopMap);        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//@Test
	public void postEsopIdCreateWorksheetAndManageActionItem() throws Throwable {
		try {
			int esop = 0;			
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("PSOP", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("PSOP", "Description", iLoop);
				_runStatus = Excelobject.getCellData("PSOP", "RunStatus", iLoop);
				_member = Excelobject.getCellData("PSOP", "Member", iLoop);
				_team = Excelobject.getCellData("PSOP", "Team", iLoop);	
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
				    String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("PSOP",iLoop,esopIds.get(esop));
					System.out.println("WorkSheet Id equal: " +worksheetId);
					workSheetMap.put(worksheetKey, worksheetId); // this one newly added
					searchWorksheet(worksheetId);					
					manageActionItemPSOPAndExecuteCentralized("PSOP",iLoop);
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
					esop++;
				}
				worksheetKey++;
				System.out.println("Worksheet Key : "+ worksheetKey);
			}
			//below function is newly added
			//inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, "PSOP");
			//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDPSOPXML,worksheetKey - 1,"WorkSheet Id",workSheetMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}