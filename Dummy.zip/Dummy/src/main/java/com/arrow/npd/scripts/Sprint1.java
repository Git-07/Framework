package com.arrow.npd.scripts;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint1 extends BusinessFunctions_NPD {
	@BeforeClass
	public void excelLoad() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint1, "CES");
	}

	@Test
	public void dsopThroughCES() throws Throwable{
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CES";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
				
				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);
					
					//This will mark the beginning of row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Started");
					 
					//This method will log into the Application
					  SignIn(strTeam, strMember);
					
					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
					  verifyDSOPInCES(SheetName, iLoop);
					  
					//Test case 1: Verify CES select button is not displayed if CES Enabled is set to No
					//  verifyDSOPInCES(SheetName, iLoop);
					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}
}
