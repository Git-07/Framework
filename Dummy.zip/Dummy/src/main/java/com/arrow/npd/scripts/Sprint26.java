package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint26 extends BusinessFunctions_NPD  {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;
	
	@Test
	public void psopInvoiceSearchByFunctionality() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint26, "GCNBO-801");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-801", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-801", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-801", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-801", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-801", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {				
					if (_testCaseID.contains("Functionality of Invoice# Search by")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						psopInvoiceSearch("GCNBO-801", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
					else if (_testCaseID.contains("Functionality of Customer# Search by")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						psopInvoiceSearchByCustomer("GCNBO-801", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void searchByOverrideSearchCriteriaFunctionality() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint26, "GCNBO-801");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-801", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-801", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-801", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-801", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-801", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Search by Invoice# overrides search criteria functionality")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						searchByAndSearchCriteriaFiltersApplied("Invoice","GCNBO-801", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
					else if (_testCaseID.contains("Search by Customer# overrides search criteria functionality")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						searchByAndSearchCriteriaFiltersApplied("Customer","GCNBO-801", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void psopCountSumAndTotalPaperSOP() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint26, "GCNBO-762");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-762", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-762", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-762", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-762", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-762", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("Total Paper SOP Count")) {
						countTotalPaperSOP("GCNBO-762", iLoop);
					}
					endTheReport(_testCaseID, iLoop);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void psopListofInvoice() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint26, "GCNBO-839");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-839", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-839", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-839", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-839", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-839", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Standalone Entity PSOP Invoice List Page")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						searchForTheEntity("GCNBO-839", iLoop);
						psopInvoicesList("GCNBO-839", iLoop, "Standalone Entity");
						searchForOWNumber("GCNBO-839", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
					else if (_testCaseID.contains("Affiliation PSOP Invoice List Page")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						searchForTheAffiliation("GCNBO-839", iLoop);
						psopInvoicesList("GCNBO-839", iLoop, "Affiliation");
						searchForOWNumber("GCNBO-839", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void psopInvoiceProfile() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint26, "GCNBO-839");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-839", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-839", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-839", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-839", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-839", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Invoice Profile from Standalone Entity PSOP Invoice")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						searchForTheEntity("GCNBO-839", iLoop);
						psopInvoicesList("GCNBO-839", iLoop, "Standalone Entity");
						searchForOWNumber("GCNBO-839", iLoop);
						invoiceProfileFromInvoiceList("GCNBO-839", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
					else if (_testCaseID.contains("Invoice Profile from Affiliation PSOP Invoice")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						searchForTheAffiliation("GCNBO-839", iLoop);
						psopInvoicesList("GCNBO-839", iLoop, "Affiliation");
						searchForOWNumber("GCNBO-839", iLoop);
						invoiceProfileFromInvoiceList("GCNBO-839", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void verifyPSOPInvoicesLinkFunctionality() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint26, "GCNBO-851");
			for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) 
			{
				_testCaseID = Excelobject.getCellData("GCNBO-851", "TestCase-ID", iLoop);
			    _description = Excelobject.getCellData("GCNBO-851", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-851", "RunStatus", iLoop);
				_member =Excelobject.getCellData("GCNBO-851", "Member", iLoop);
				_team=Excelobject.getCellData("GCNBO-851","Team", iLoop);
				String entity=Excelobject.getCellData("GCNBO-851", "Entity Id", iLoop);
				System.out.println("entity"+entity);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {					
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					
					if (_testCaseID.contains("For an Affiliated Entity")) {
						verifyPSOPInvoicesLinkFunctionality("GCNBO-851",iLoop,"Entity");
					} 
					else if(_testCaseID.contains("For a Standalone Entity")) 
					{
						verifyPSOPInvoicesLinkFunctionality("GCNBO-851",iLoop,"Entity");
					}
					else if (_testCaseID.contains("For an Affiliation")) {
						verifyPSOPInvoicesLinkFunctionality("GCNBO-851",iLoop,"Affiliation");
					}
					else if (_testCaseID.contains("Revise Button")) {
						verifyReviseButtonFunctionality("GCNBO-851",iLoop);
					}
					
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
			    }
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	
}