package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.npd.scripts.CheckForEnImp.Teams;
import com.arrow.workflows.BusinessFunctions_RenwalInvoice;

public class PendingModules extends BusinessFunctions_RenwalInvoice{

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;
	

	enum Teams{
		
		NewYorkTeam("CT - New York SOP Team"), 
		SOPSupportTeam("SOP Support Team"),
		NewYorkTeamMember("Roopmattee Jairam"),
		SOPSupportTeamMember("Amelia Garner");
		
		String nameAndMemeber;	
		Teams(String teamAndMem){
			this.nameAndMemeber = teamAndMem;
		}
	}
	
	public static void main(String [] ar) throws Throwable {
		String team = "";
		String member = "";
		for(Teams t : Teams.values()) {
			
			switch (t) {
			case NewYorkTeam :
			  team = t.nameAndMemeber;
			  System.out.println(team);
		      break;
		      
			case SOPSupportTeam :
			  team = t.nameAndMemeber;
			  System.out.println(team);
			  break;
			  
			case NewYorkTeamMember:
			member = t.nameAndMemeber;
			System.out.println(member);
			break;
			
			case SOPSupportTeamMember:
			member = t.nameAndMemeber;
			System.out.println(member);
								 
			}				
		}
		
	}
	
	 
	 //@Test
	 //break this into two
	 //Renewal DI related -> EntityLevelDI.Java
	 public void updateTheRenewalDIAutoRenewStatusToActiveEntityLevel() throws Throwable {
			try {
				inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint30, "Pending Modules");	
				for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
					_testCaseID = Excelobject.getCellData("Pending Modules", "TestCase-ID", iLoop);
					_description = Excelobject.getCellData("Pending Modules", "Description", iLoop);
					_runStatus = Excelobject.getCellData("Pending Modules", "RunStatus", iLoop);
					_member = Excelobject.getCellData("Pending Modules", "Member", iLoop);
					_team = Excelobject.getCellData("Pending Modules", "Team", iLoop);					
					if (_runStatus.trim().equalsIgnoreCase("Y")) {					
						if (_testCaseID.contains("Update the Renewal DI at Entity Level")) {
							intialiseTheReport(_testCaseID, _description, iLoop);
							SignIn(_team, _member);
							//searchForTheEntity(getTheActiveStandaloneEntity());
							editTheRenewalDIToPaperLessDeliveryMethod();						
							endTheReport(_testCaseID, iLoop);
							driver.get(URL);
						}
					}
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
	 }
	 
	 //AffiliationLevelDI
	@Test
	public void updateTheRenewalDIAutoRenewStatusToActiveForNewSubgroup() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint30, "Pending Modules");	
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("Pending Modules", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("Pending Modules", "Description", iLoop);
				_runStatus = Excelobject.getCellData("Pending Modules", "RunStatus", iLoop);
				_member = Excelobject.getCellData("Pending Modules", "Member", iLoop);
				_team = Excelobject.getCellData("Pending Modules", "Team", iLoop);					
				if (_runStatus.trim().equalsIgnoreCase("Y")) {	
					 if (_testCaseID.contains("Create A Renewal Subgroup and Update the Renewal DI")) {
							intialiseTheReport(_testCaseID, _description, iLoop);
							SignIn(_team, _member);
							//searchForTheAffiliation(getTheAffiliationHavingMulitpleInvoices());
							createRenewalSubgroupAndRenewalDIPaperLessDeliveryMethod();													
							endTheReport(_testCaseID, iLoop);
							driver.get(URL);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	 
}
