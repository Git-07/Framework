package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint28 extends BusinessFunctions_NPD {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;

	@Test
	public void psopErrorDisplayedInPsopExceptionTab() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint28, "GCNBO-838");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-838", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-838", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-838", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-838", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-838", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("PSOP exception for error")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						String serviceCenter = getTheServiceCenterForTheEntityOrAffiliation("GCNBO-838", iLoop);
						validateThePSOPExceptionsInUI("GCNBO-838", iLoop,serviceCenter);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void creditPSOPInvoicePartialOrFull() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint28, "GCNBO-836");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-836", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-836", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-836", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-836", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-836", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Credited")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);						
						searchForThePSOPInvoiceAndCreditSOP("GCNBO-836", iLoop);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
