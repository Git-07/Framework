package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint35  extends BusinessFunctions_NPD {
	
	@Test
	public void methodOfServiceAndTraceableMailFieldsRetainedInWorksheetPage() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint35, "GCNBO-1180");			
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1180", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1180", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1180", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1180", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1180", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
						if (testCaseID.contains("Escalated ESOP")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							String esopId = esopEscalatedOrOnHold("GCNBO-1180",iLoop);							
							processEscalatedOrOnHoldESOP("GCNBO-1180",iLoop,esopId);
							workSheetContainsPlaintiffAndDefendantValuesAsESOP("GCNBO-1180",iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
						else if (testCaseID.contains("On Hold ESOP")) {
							child = extent.startTest(testCaseID, description);
							iterationReport(iLoop, testCaseID + " Started");
							SignIn(team, member);
							String esopId = esopEscalatedOrOnHold("GCNBO-1180",iLoop);
							processEscalatedOrOnHoldESOP("GCNBO-1180",iLoop,esopId);
							workSheetContainsPlaintiffAndDefendantValuesAsESOP("GCNBO-1180",iLoop,esopId);
							parent.appendChild(child);
							iterationReport(iLoop, testCaseID + " Completed");
							driver.get(URL);
						}
					}
				}			
		} catch (Exception e) {
			e.printStackTrace();
	}
  }
	
    @Test
	public void rejectionListUIValidateForDifferentMember() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint35, "GCNBO-1194");			
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1194", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1194", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1194", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1194", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1194", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Level")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
                        rejectionListForPosssibleRejection("GCNBO-1194",iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}