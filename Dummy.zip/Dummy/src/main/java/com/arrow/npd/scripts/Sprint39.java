package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint39 extends BusinessFunctions_NPD {

	//@Test
	public void attorneyAndCourtInCES() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint39, "GCNBO-1476");	
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1476", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1476", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1476", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1476", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1476", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);												
						//String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1476", iLoop);
						String esopId = "22004576"; 
						viewAndCreateTheWorkSheetUsingESOPId("GCNBO-1476", iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//@Test
	public void updateToPossibleRejectionFromEscalatedList() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint39, "GCNBO-1420");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1420", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1420", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1420", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1420", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1420", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1420", iLoop);
						compareTheCurrentStatus("GCNBO-1420", iLoop, esopId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void fieldsModificationDuringWorksheetCreation() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint39, "GCNBO-1283");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1283", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1283", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1283", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1283", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1283", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Complete")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1283", iLoop);					
						String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("GCNBO-1283", iLoop,esopId);
						assignmentHistoryAndAudtitTrail(esopId,worksheetId);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
