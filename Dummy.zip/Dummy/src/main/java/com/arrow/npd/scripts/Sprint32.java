package com.arrow.npd.scripts;

import java.util.ArrayList;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint32 extends BusinessFunctions_NPD {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;

	
	@Test
	public void changeTheRenewalMonthAndCreditPSOPLines() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint32, "GCNBO-846");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-846", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-846", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-846", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-846", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-846", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Change the Renewal Month on Standalone Entity")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						ArrayList<String> originalInvoiceAndOrderIdEntity = new ArrayList<String>();
						originalInvoiceAndOrderIdEntity = getTheOriginalEntityLevelPSOPInvoice();
						searchForTheEntityAndChangeRenewalMonth(
								getTheEntityIdForThePSOPOrderId(originalInvoiceAndOrderIdEntity.get(1)));
						revisePSOPInvoiceAndCreditSOP("GCNBO-846", iLoop,originalInvoiceAndOrderIdEntity,"");						
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("Change the Renewal Month on Affiliation Level")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);						
						ArrayList<String> originalInvoiceAndOrderIdAffiliation = new ArrayList<String>();
						originalInvoiceAndOrderIdAffiliation = getTheOriginalAffiliationLevelPSOPInvoice();
						searchForTheAffiliationAndChangeRenewalMonth(
								getTheAffiliationIdForThePSOPOrderId(originalInvoiceAndOrderIdAffiliation.get(1)));
						revisePSOPInvoiceAndCreditSOP("GCNBO-846", iLoop,originalInvoiceAndOrderIdAffiliation,"");
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void quitTheAffiliationAndCreditPSOPLines() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint32, "GCNBO-846");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-846", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-846", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-846", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-846", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-846", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {				
					 if (_testCaseID.contains("Quit Entity from Affiliation")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);						
						ArrayList<String> originalInvoiceAndOrderIdAffiliation = new ArrayList<String>();
						originalInvoiceAndOrderIdAffiliation = getTheOriginalAffiliationLevelPSOPInvoice();
						String entityId = getTheEntityIdToQuitFromAffiliationForThePSOPOrderId(originalInvoiceAndOrderIdAffiliation.get(1));
						quitEntityFromAffiliation(entityId);						
						revisePSOPInvoiceAndCreditSOP("GCNBO-846", iLoop,originalInvoiceAndOrderIdAffiliation,entityId);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void joinTheAffiliationAndCreditPSOPLines() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint32, "GCNBO-846");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-846", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-846", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-846", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-846", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-846", "Team", iLoop);
			if (_runStatus.trim().equalsIgnoreCase("Y")) {				
				if (_testCaseID.contains("Add Entity to Affiliation and revise")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						ArrayList<String> originalInvoiceAndOrderIdEntity = new ArrayList<String>();
						originalInvoiceAndOrderIdEntity = getTheOriginalEntityLevelPSOPInvoice();												
						String entityId = getTheEntityIdForThePSOPOrderId(originalInvoiceAndOrderIdEntity.get(1));
						ArrayList<String> originalInvoiceAndOrderIdAffiliation = new ArrayList<String>();
						originalInvoiceAndOrderIdAffiliation = getTheOriginalAffiliationLevelPSOPInvoice();						
						String affiliationId = getTheAffiliationIdForThePSOPOrderId(originalInvoiceAndOrderIdAffiliation.get(1));
						joinEntityToAffiliation(entityId,affiliationId);					
						revisePSOPInvoiceAndCreditSOP("GCNBO-846", iLoop,originalInvoiceAndOrderIdEntity,"");
						revisePSOPInvoiceAndCreditSOP("GCNBO-846", iLoop,originalInvoiceAndOrderIdAffiliation,"");
						quitEntityFromAffiliation(entityId);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
				}
			}
		}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
