package com.arrow.npd.scripts;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint52 extends BusinessFunctions_NPD{
	 
    
	@Test
	public void bulkWorksheetActionItemExecution() throws Throwable {
		
	Map<Integer,String> acceleratedWorksheet = new HashMap<Integer,String>();
	int acceleratedLogKey =1;
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "GCNBO-1666");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1666", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1666", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1666", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1666", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1666", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);											
					String esopId = submitESOPWithHardCopyRequiredOrNot("GCNBO-1666", iLoop);
					//validate the log in expedited transmission page					
					compareExpeditedWorkflow("GCNBO-1666", iLoop,esopId);
					expeditedTransmissionLog(esopId);	
					acceleratedWorksheet.put(acceleratedLogKey, actionItemExecution(esopId));					
					transmittalDataVerification("GCNBO-1666", iLoop,esopId);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");					
					acceleratedLogKey++;
					driver.get(URL);					
				}
			}						
		}
		Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDSprint52,acceleratedLogKey - 1,"Accelerated Log",acceleratedWorksheet);
	}catch(Exception e) {
		e.printStackTrace();
	
	}
	
}
	@Parameters({"sopHubUrl"})
	@Test(dependsOnMethods = {"bulkWorksheetActionItemExecution"})
	public void validateLogInSOPHub(String sopHubUrl) throws Throwable {		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "GCNBO-1666");	
		int rows = inputSheet.getPhysicalNumberOfRows();
		for(int iLoop =0 ; iLoop<= rows; iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1666", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1666", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1666", "RunStatus", iLoop);			
			String sopHubUser = Excelobject.getCellData("GCNBO-1666", "User Name", iLoop);
			String sopHubUserPwd = Excelobject.getCellData("GCNBO-1666", "Password", iLoop);
			String firstName = Excelobject.getCellData("GCNBO-1666", "First Name", iLoop);
			String lastName = Excelobject.getCellData("GCNBO-1666", "Last Name", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");																		
					//below SOP Hub side validations
					driver.get(sopHubUrl);
					loginToSOPHub(sopHubUser,sopHubUserPwd,firstName,lastName);
					bulkWorksheetInSOPHub("GCNBO-1666",iLoop);
					logoutFromSopHub();					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}			
		Excelobject.removeDataFromColumn(TestDataWorkBookNPDSprint52,rows,"Accelerated Log","");
	}catch(Exception e) {
		e.printStackTrace();
	
	}
	
}
	
	//@Test
	public void bulkWorksheetActionItemExecutionFailure() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "GCNBO-1833");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1833", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1833", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1833", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1833", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1833", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);												
					String esopId = submitESOPWithHardCopyRequiredOrNot("GCNBO-1833", iLoop);
					compareExpeditedWorkflow("GCNBO-1833", iLoop,esopId);
					logInActionItemFailure(esopId);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {
		e.printStackTrace();
	
	}	
}
	
	//@Test
	public void sopWorkflowInWorksheet() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "GCNBO-1838");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {			
				String testCaseID = Excelobject.getCellData("GCNBO-1838", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1838", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1838", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1838", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1838", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Reject")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1838", iLoop);
						compareTheCurrentStatus("GCNBO-1838", iLoop,esopId);
						sopWorkflow("GCNBO-1838", iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if(testCaseID.contains("Create")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = submitESOPWithHardCopyRequiredOrNot("GCNBO-1838", iLoop);
						compareTheCurrentStatus("GCNBO-1838", iLoop,esopId);
						viewAndCreateTheWorkSheetUsingESOPId("GCNBO-1838", iLoop,esopId);
						sopWorkflow("GCNBO-1838", iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");						
						driver.get(URL);
					}
					else if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);												
						String esopId = submitESOPWithHardCopyRequiredOrNot("GCNBO-1838", iLoop);
						compareExpeditedWorkflow("GCNBO-1838", iLoop,esopId);
						sopWorkflow("GCNBO-1838", iLoop,esopId);					
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//@Test
	public void actioItemFailureUI() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "GCNBO-1880");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			
				String testCaseID = Excelobject.getCellData("GCNBO-1880", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1880", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1880", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1880", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1880", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Action Items Failure UI")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");						
						SignIn(team, member);						
						actionItemFailuresUI();			
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
