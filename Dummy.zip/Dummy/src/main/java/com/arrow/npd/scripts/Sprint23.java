package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint23 extends BusinessFunctions_NPD{
	
	@Test
	public void updatePaperSurchargeBillingFlag() throws Throwable{
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint23, "GCNBO-765");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "GCNBO-765";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
				
				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);
					
					//This will mark the beginning of row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Started");
					 
					//This method will log into the Application
					  SignIn(strTeam, strMember);
					 
					  if (strTestCaseID.contains("Verfiy Paper Surcharge Billing field value is updated in PSOP database")) {
						  paperSurchargeBillingFlag(SheetName, iLoop);
						} else if (strTestCaseID.contains("Join Entity to an Affiliation")) {
							verifyPSOPFlagOnAffiliationJoin(SheetName, iLoop);
						}
					  driver.get(URL);
					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
}
