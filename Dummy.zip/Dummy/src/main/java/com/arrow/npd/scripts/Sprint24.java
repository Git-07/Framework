package com.arrow.npd.scripts;

import org.testng.annotations.Test;
import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint24 extends BusinessFunctions_NPD {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;

	@Test
	public void invoiceContainsNewlyAddedPSOP() throws Throwable {

		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint24, "GCNBO-761");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-761", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-761", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-761", "RunStatus", iLoop);
				_member =Excelobject.getCellData("GCNBO-761", "Member", iLoop);
				_team=Excelobject.getCellData("GCNBO-761","Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {					
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("PSOP Invoice Search is added")) {

						psopInoviceSearch("GCNBO-761",iLoop,"PSOP Invoice Search");
						
					} else if (_testCaseID.contains("PSOP Invoice Search Criteria UI")) {
						psopInoviceSearch("GCNBO-761",iLoop,"PSOP Invoice Search");
						psopInvoiceSearchCriteriaUI();
					}									
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
				
				
			}

		} catch (Exception e) {

		}
	}

	@Test
	public void renewalXSOPAndPSOPInvoice() throws Throwable {

		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint24, "GCNBO-800");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-800", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-800", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-800", "RunStatus", iLoop);
				_member =Excelobject.getCellData("GCNBO-800", "Member", iLoop);
				_team=Excelobject.getCellData("GCNBO-800","Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member); 
					if (_testCaseID.contains("Paper SOP Surcharge Invoice Search")) {
                      						
						psopInvoiceUnderHomePage("GCNBO-800",iLoop,"Renewal/XSOP/PSOP Invoice Search");

					}
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
				
				
			}
		} catch (Exception e) {

		}

	}

	@Test
	public void paperSurchargeBillingLogic() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint24, "GCNBO-854");
		    for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {			
			_testCaseID = Excelobject.getCellData("GCNBO-854", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-854", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-854", "RunStatus", iLoop);
				_member =Excelobject.getCellData("GCNBO-854", "Member", iLoop);
				_team=Excelobject.getCellData("GCNBO-854","Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_description.contains("For Standalone Entity")) {						
						searchForTheEntity("GCNBO-854", iLoop);
						maintainPaperSurchargeBilling();
						paperSurchargeBillingStatus("GCNBO-854", iLoop,"Entity Profile");

					} else if (_testCaseID.contains("For Affiliated Entity")) {      
						joinAffiliation("GCNBO-854",iLoop);						
						paperSurchargeBillingStatus("GCNBO-854", iLoop,"Affiliation Profile");
						searchForTheEntity("GCNBO-854", iLoop);
						maintainPaperSurchargeBilling();
						quitAffiliation("GCNBO-854",iLoop);
						
					}
					else if(_testCaseID.contains("Maintain Paper Surcharge button is disabled")) {						
						joinAffiliation("GCNBO-854",iLoop);
						searchForTheEntity("GCNBO-854", iLoop);
						maintainPaperSurchargeBilling();
						quitAffiliation("GCNBO-854",iLoop);						
					}
					else if(_testCaseID.contains("Paper Surcharge billing is disabled on quiting affiliation")) {						
						joinAffiliation("GCNBO-854",iLoop);
						paperSurchargeBillingStatus("GCNBO-854", iLoop,"Affiliation Profile");
						searchForTheEntity("GCNBO-854", iLoop);
						maintainPaperSurchargeBilling();
						quitAffiliation("GCNBO-854",iLoop);
						paperSurchageBillingStatusPostQuitAffiliation();																	
					}

					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}

			}
		} catch (Exception e) {

		}
	}
}
