package com.arrow.npd.scripts;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class DevOpsSprint4And5 extends BusinessFunctions_NPD{
	
	
	//@Test	
	public void titleOfActionMaintenance() throws Throwable {	
				
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint5, "TOAMaintenance");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("TOAMaintenance", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("TOAMaintenance", "Description", iLoop);
			String runStatus = Excelobject.getCellData("TOAMaintenance", "RunStatus", iLoop);
			String member = Excelobject.getCellData("TOAMaintenance", "Member", iLoop);
			String team = Excelobject.getCellData("TOAMaintenance", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				
				if (testCaseID.contains("For the Title Of Action")) {	
					try {
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);				
					titleOfActionMaintenanceApp("TOAMaintenance", iLoop);
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {}					
				}
				driver.get(URL);
			}
		}
			
	}
	
	//Below Test methods is just added here to run the NRAI tests, but for merging scripts into regression suite we need
	// to merge only test data will which will take care of these tests
	//@Test	
	public void fullWorksheet() throws Throwable {	
				
		Map<Integer,String> fullWorksheet = new HashMap<Integer,String>();
		int fullLogKey =1;
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint5, "Full Worksheet");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("Full Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Full Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Full Worksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Full Worksheet", "Member", iLoop);
			String team = Excelobject.getCellData("Full Worksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				
				if (testCaseID.contains("Process a CES")) {	
					try {
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);				
					String esopId = submitESOPWithHardCopyRequiredOrNot("Full Worksheet",iLoop);
					String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("Full Worksheet",iLoop,esopId);
					sopWorkflow("Full Worksheet",iLoop,esopId);
					executeActionItem("Full Worksheet",iLoop,esopId);
					//executeActionItem("Full Worksheet",iLoop,"");
					fullWorksheet.put(fullLogKey, worksheetId);
					fullLogKey++;
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {}					
				}
				driver.get(URL);
			}
		}
		
		Excelobject.writeDataToExistingExcel(TestDataNPDDevOpsSprint5,fullLogKey - 1,"Full Log",fullWorksheet);
	}

	@Parameters({"sopHubUrl"})
	//@Test(dependsOnMethods = {"fullWorksheet"})
	public void validatefullWorksheetInSOPHub(String sopHubUrl) throws Throwable {		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint5, "Full Worksheet");	
		int rows = inputSheet.getPhysicalNumberOfRows();		
		System.out.println("Total number of rows = " + rows);
		for(int iLoop =0 ; iLoop<= rows; iLoop++){			
			String testCaseID = Excelobject.getCellData("Full Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Full Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Full Worksheet", "RunStatus", iLoop);			
			String sopHubUser = Excelobject.getCellData("Full Worksheet", "User Name", iLoop);
			String sopHubUserPwd = Excelobject.getCellData("Full Worksheet", "Password", iLoop);
			String firstName = Excelobject.getCellData("Full Worksheet", "First Name", iLoop);
			String lastName = Excelobject.getCellData("Full Worksheet", "Last Name", iLoop);
			String customer = Excelobject.getCellData("Full Worksheet", "Customer", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");																		
					//below SOP Hub side validations
					driver.get(sopHubUrl);
					loginToSOPHubWithCustomer(sopHubUser,sopHubUserPwd,firstName,lastName,customer);
					worksheetInSOPHub("Full Worksheet",iLoop);
					logoutFromSopHub();		
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");					
				}				
			}
			//driver.get(sopHubUrl);
		}			
		Excelobject.removeDataFromColumn(TestDataNPDDevOpsSprint5,rows,"Full Log","");
	}catch(Exception e) {
		e.printStackTrace();}
	
	}
	
	@Test	
	public void optimizedManualWorksheet() throws Throwable {
		Map<Integer,String> optimizedManualWorksheet = new HashMap<Integer,String>();
		int currentTest = 0;
		int optimizedManualLogKey =1;		
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint5, "OptimizedManual Worksheet");
		//Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String [] esops = new String[totalTest];
		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("OptimizedManual Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("OptimizedManual Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("OptimizedManual Worksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("OptimizedManual Worksheet", "Member", iLoop);
			String team = Excelobject.getCellData("OptimizedManual Worksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				
				if (testCaseID.contains("Process a CES")) {	
					try {
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);				
					String esopId = submitESOPWithHardCopyRequiredOrNot("OptimizedManual Worksheet",iLoop);					
					
					//Below two lines of code is added on 7/1/21					
					esops[currentTest] = esopId;
					++currentTest;		
					/*String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("OptimizedManual Worksheet",iLoop,esopId);
					sopWorkflow("OptimizedManual Worksheet",iLoop,esopId);
					executeActionItem("OptimizedManual Worksheet",iLoop,esopId);					
					executeActionItem("OptimizedManual Worksheet",iLoop,"");
					optimizedManualWorksheet.put(optimizedManualLogKey, worksheetId); */
					optimizedManualLogKey++;
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");					
					}catch(Exception e) {e.printStackTrace();}					
				}
				driver.get(URL);				
			}
		}
		
		optimizedManualWorksheet = executeActionItemAfterWorksheetCreation(currentTest - 1,"OptimizedManual Worksheet",esops);
		Excelobject.writeDataToExistingExcel(TestDataNPDDevOpsSprint5,optimizedManualLogKey - 1,"OptimizedManual Log",optimizedManualWorksheet);
		/*for(int i = 0 ;i <totalTest; i++ ) {
		driver.get(URL);
		String member = Excelobject.getCellData("OptimizedManual Worksheet", "Member", i+2);
		String team = Excelobject.getCellData("OptimizedManual Worksheet", "Team", i+2);
		SignIn(team, member);
		String worksheetId = viewAndCreateTheWorkSheetUsingESOPId("OptimizedManual Worksheet",i+2,esops[i]);
		//String worksheetId = "538124038";
		sopWorkflow("OptimizedManual Worksheet",i+2,esops[i]);
		executeActionItem("OptimizedManual Worksheet",i+2,esops[i]);
		driver.manage().deleteAllCookies();
		//executeActionItem("OptimizedManual Worksheet",iLoop,"");
		optimizedManualWorksheet.put(optimizedManualLogKey, worksheetId);
		optimizedManualLogKey++;
		}*/
		
	}
	
    @Test	
	public void optimizedWorksheet() throws Throwable {	

		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint5, "Optimized Worksheet");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("Optimized Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Optimized Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Optimized Worksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Optimized Worksheet", "Member", iLoop);
			String team = Excelobject.getCellData("Optimized Worksheet", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				
				if (testCaseID.contains("Process a CES")) {	
					try {
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);				
					String esopId = submitESOPWithHardCopyRequiredOrNot("Optimized Worksheet",iLoop);
					//Below function needs to uncommented after Release 1.2 development work started
					//sopWorkflow("Optimized Worksheet",iLoop,esopId);					
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {}					
				}
				driver.get(URL);
			}
		}
		
	}
    
    @Parameters({"sopHubUrl"})
	//@Test(dependsOnMethods = {"optimizedManualWorksheet"})
	public void validateOptimizedManualWorksheetInSOPHub(String sopHubUrl) throws Throwable {		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint5, "OptimizedManual Worksheet");	
		int rows = inputSheet.getPhysicalNumberOfRows();
		for(int iLoop =0 ; iLoop<= rows; iLoop++){			
			String testCaseID = Excelobject.getCellData("OptimizedManual Worksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("OptimizedManual Worksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("OptimizedManual Worksheet", "RunStatus", iLoop);			
			String sopHubUser = Excelobject.getCellData("OptimizedManual Worksheet", "User Name", iLoop);
			String sopHubUserPwd = Excelobject.getCellData("OptimizedManual Worksheet", "Password", iLoop);
			String firstName = Excelobject.getCellData("OptimizedManual Worksheet", "First Name", iLoop);
			String lastName = Excelobject.getCellData("OptimizedManual Worksheet", "Last Name", iLoop);
			String customer = Excelobject.getCellData("OptimizedManual Worksheet", "Customer", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");																		
					//below SOP Hub side validations
					driver.get(sopHubUrl);
					loginToSOPHubWithCustomer(sopHubUser,sopHubUserPwd,firstName,lastName,customer);
					worksheetInSOPHub("OptimizedManual Worksheet",iLoop);
					logoutFromSopHub();	
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");					
				}				
			}
			//driver.get(URL);
		}			
		Excelobject.removeDataFromColumn(TestDataNPDDevOpsSprint5,rows,"OptimizedManual Log","");
	}catch(Exception e) {
		e.printStackTrace();}
	
	}


	

}
