package com.arrow.npd.scripts;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint33 extends BusinessFunctions_NPD {

	@Test
	public void retainDataForTheESOP() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint33, "GCNBO-1177");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1177", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1177", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1177", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1177", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1177", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Escalated ESOP")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = esopEscalatedOrOnHold("GCNBO-1177",iLoop);
						processEscalatedOrOnHoldESOP("GCNBO-1177",iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
					else if (testCaseID.contains("On Hold ESOP")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = esopEscalatedOrOnHold("GCNBO-1177",iLoop);
						processEscalatedOrOnHoldESOP("GCNBO-1177",iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void plaintiffAndDefendantMandatoryFieldsToSubmitESOP() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint33, "GCNBO-1178");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1178", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1178", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1178", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1178", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1178", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Plaintiff and Defendant fields")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						validatePlaintiffAndDefendantFieldsAreMandatory("GCNBO-1178",iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}