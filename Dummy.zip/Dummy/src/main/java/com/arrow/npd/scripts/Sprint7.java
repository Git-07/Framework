package com.arrow.npd.scripts;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint7 extends BusinessFunctions_NPD {
//	@Test
//	public void allIntakeMethodsThroughCES() throws Throwable{
//		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint7, "GCNBO174");
//		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
//			try {
//				String SheetName = "GCNBO174";
//				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
//				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
//				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
//				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
//				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
//				
//				if(runStatus.trim().equalsIgnoreCase("Y")) {
//					child = extent.startTest(strTestCaseID, strDesc);
//					
//					//This will mark the beginning of row in data sheet
//					  iterationReport(iLoop-1,strTestCaseID+" Started");
//					 
//					//This method will log into the Application
//					  SignIn(strTeam, strMember);
//					
//					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
//					  verifyAllIntakeMethodThroughCES(SheetName, iLoop);
//					  
//					  parent.appendChild(child);
//					  //This will mark end of the one row in data sheet
//					  iterationReport(iLoop-1,strTestCaseID+" Completed");
//				}
//			}catch (Exception e) {
//				catchBlock(e);
//			}
//		}
//	}
//	
	@Test
	public void customerComments() throws Throwable{
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint7, "GCNBO154");
		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "GCNBO154";
				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
				
				if(runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);
					
					//This will mark the beginning of row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Started");
					 
					//This method will log into the Application
					  SignIn(strTeam, strMember);
					
					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
					  verifyCustomerComments(SheetName, iLoop);
					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,strTestCaseID+" Completed");
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
	}
//	
//	@Test
//	public void genericEntities() throws Throwable{
//		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint7, "GCNBO35");
//		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
//			try {
//				String SheetName = "GCNBO35";
//				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
//				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
//				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
//				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
//				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
//				
//				if(runStatus.trim().equalsIgnoreCase("Y")) {
//					child = extent.startTest(strTestCaseID, strDesc);
//					
//					//This will mark the beginning of row in data sheet
//					  iterationReport(iLoop-1,strTestCaseID+" Started");
//					 
//					//This method will log into the Application
//					  SignIn(strTeam, strMember);
//					
//					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
//					  verifyGenericEntities(SheetName, iLoop);
//					  
//					  parent.appendChild(child);
//					  //This will mark end of the one row in data sheet
//					  iterationReport(iLoop-1,strTestCaseID+" Completed");
//				}
//			}catch (Exception e) {
//				catchBlock(e);
//			}
//		}
//	}
	
//	@Test
//	public void cesEnabledIsRemoved() throws Throwable{
//		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint7, "GCNBO175");
//		for(int iLoop = 2; iLoop<=inputSheet.getPhysicalNumberOfRows(); iLoop++) {
//			try {
//				String SheetName = "GCNBO175";
//				String strTestCaseID=Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
//				String runStatus=Excelobject.getCellData(SheetName, "RunStatus",iLoop);
//				String strTeam=Excelobject.getCellData(SheetName, "Team", iLoop);
//				String strMember=Excelobject.getCellData(SheetName, "Member", iLoop);
//				String strDesc=Excelobject.getCellData(SheetName,"Description", iLoop);
//				
//				if(runStatus.trim().equalsIgnoreCase("Y")) {
//					child = extent.startTest(strTestCaseID, strDesc);
//					
//					//This will mark the beginning of row in data sheet
//					  iterationReport(iLoop-1,strTestCaseID+" Started");
//					 
//					//This method will log into the Application
//					  SignIn(strTeam, strMember);
//					
//					//Test case 1: Verify CES select button is displayed if CES Enabled is set to Yes
//					  verifyCESEnabledRemoved(SheetName, iLoop);
//					  
//					  parent.appendChild(child);
//					  //This will mark end of the one row in data sheet
//					  iterationReport(iLoop-1,strTestCaseID+" Completed");
//				}
//			}catch (Exception e) {
//				catchBlock(e);
//			}
//		}
//	}
}
