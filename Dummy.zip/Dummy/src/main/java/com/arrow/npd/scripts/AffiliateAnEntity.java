package com.arrow.npd.scripts;

import java.util.ArrayList;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.util.DBConnection;
import com.arrow.workflows.BusinessFunctions_NPD;

public class AffiliateAnEntity extends BusinessFunctions_NPD {	
	public static void main(String[] ar) throws Throwable{
		
		System.out.println("Hello world");
			//String sqlQuery = "select ENTITY_ID from ARV_PSOP_BILLING_TARGET where ENTITY_ID = "+"8002257155";
		  // String sqlQuery = "select  from ARV_PSOP_ORDER where ENTITY_ID = "+"9401732814";
		//ARV_FEDEX_CENTRALIZED_MASTER	
		//String sqlQuery = "select * from ARV_FEDEX_CENTRALIZED_MASTER where ENTITY_ID = "+"9401651107";
		//String sqlQuery = "select AFFILIATION_ID from ARV_PSOP_BILLING_TARGET where AFFILIATION_ID = " + "7763";
		String sqlQuery = "select count(*)  from av_tbv_individual i, av_customer c where i.customer_id = c.customer_id" +  
				"and (i.mailing_addr_line_1 like '111 Eighth Avenue%'" +
				"or i.mailing_addr_line_1 like '111 8th Avenue%'   or i.mailing_addr_line_2 like '111 Eighth Avenue%'" +
				"or i.mailing_addr_line_2 like '111 8th Avenue%'   or i.mailing_addr_line_3 like '13th Floor')" +
				"and c.compressed_name in (upper('CTCorporationSystem')," +
				"upper('CTDemoAccount'))   and i.mailing_zip_code like '10011%'  and i.individual_id = 1800648";
					
		String sqlQuery1 = "select  * from ARV_PSOP_Order where rownum = 1";
		String sqlQuery2 = "select E.Entity_ID, Wk.Worksheet_ID from Arrow.ARV_SOP_Worksheet Wk, Arrow. ARV_SOP_Action_Item AI,"
				+ "Arrow.arv_fedex_package fp," 
				+ "Arrow.arv_business_name   bn,"
				+ "Arrow.arv_entity e "
				 + "where" 
			+	" WK.BUS_UNIT_CD =92003"
			+	" and Wk.Worksheet_ID = AI.Worksheet_ID" 
			+   " and fp.PACKAGE_ID = ai.FEDEX_PACKAGE_ID"
			+	" and fp.is_package_centralized ='Y'"
			+	" and wk.BUS_NAME_ID = bn.BUS_NAME_ID"
			//+	" and bn.ENTITY_ID = 9401651107"
			+	" and bn.ENTITY_ID = E.Entity_ID "
			+	" and ai.Created_date >= TO_DATE('01/Jan/2020','dd/mon/yyyy')"
			+	" group by E.Entity_ID, Wk.Worksheet_ID ";

		String sqlQuery3 = "SELECT Invoice_Date FROM CTAV_INVOICE WHERE Invoice_Number IN(19679565)";
		String sqlQuery4 = "SELECT Invoice_Date FROM ARV_PSOP_ORDER WHERE ORDER_ID IN (SELECT FIRST_ORDER_NUMBER FROM CTAV_INVOICE WHERE Invoice_Number IN(19679565))";
		String sqlQuery5 = "SELECT * FROM ARV_PSOP_ORDER WHERE rownum=1";

	String sqlQuerry7 = "SELECT ENTITY_ID FROM ARV_PSOP_ORDER WHERE ORDER_ID IN("+
		    "SELECT FIRST_ORDER_NUMBER from CTAV_INVOICE where FIRST_ORDER_NUMBER IN (" +
		    "SELECT  ORDER_ID from ARV_PSOP_ORDER where  Invoice_Date >= add_months(SYSDATE,- 24)"
		    + " AND ENTITY_ID IS NOT NULL) and FIRST_ORDER_TYPE ='PS' and rownum =1)";
	
	String sqlQuerry = "select AFFL_ID,SUBGROUP_ID,SUBGROUP_NAME from ARV_Subgroup where subgroup_type_cd =10003 and affl_id in(" + 
			"select affiliation_id from ARV_RNWL_ORDER where affiliation_id in (" + 
			"select affl_id from ARV_AFFL_MEMBERSHIP where entity_id in(" + 
			"Select Entity_id from arv_representation where " + 
			"juris_id =8 and service_type_id in (228,223) and is_arms_enabled = 'N' and reason_cd is null and annual_rate is null and current_status_cd =6001))" + 
			"and renewal_year = '2020') and consolidate_invoice ='Y' and Affl_Id not in ('915','389','64129','20','29') where rownum <=2";
	String querry = "select attorney_name,court_name,defendant_name  from ARV_SOP_Worksheet where worksheet_id = 535118393";		
	ArrayList<String> value = DBConnection.getResult(querry);
	System.out.println(value);
	//System.out.println(value.get(0));
	//System.out.println(value.get(2));
	//paperSurchargeBillingValueStored( "9401408451", "Entity Profile", "Enabled");
	
}
	}
	/*
	@Parameters({ "sheetname" })
	@Test
	public void addAnEntityToAnAffiliation(String sheetname) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint23, sheetname);
			System.out.println("physical rows: "+ inputSheet.getPhysicalNumberOfRows());
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testcaseID = Excelobject.getCellData(sheetname, "TestCase-ID", iLoop);
				String group = Excelobject.getCellData(sheetname, "Group", iLoop);
				String description = Excelobject.getCellData(sheetname, "Description", iLoop);
				String runStatus = Excelobject.getCellData(sheetname, "RunStatus", iLoop);
				String team = Excelobject.getCellData(sheetname, "Team", iLoop);
				String member = Excelobject.getCellData(sheetname, "Member", iLoop);	
	  
				if (runStatus.trim().equalsIgnoreCase("Y") && group.contentEquals("Add Entity to an Affiliation")) {
					child = extent.startTest(testcaseID, description);
					iterationReport(iLoop,testcaseID + " Started"); 
					SignIn(team, member);
					 try{
	                      
						//addStandaloneEntityToAffiliation(sheetname, iLoop);
						joinAffiliation(sheetname, iLoop);
					}catch(Exception e){
					
					}					
					  driver.get(URL);					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,testcaseID+" Completed");

				}				
			}
			
		} catch (Exception e) {

		}
	}
	@Parameters({ "sheetname" })
	@Test
	public void quitTheEntityFromAnAffiliation(String sheetname) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint23, sheetname);
			System.out.println("physical rows: "+ inputSheet.getPhysicalNumberOfRows());
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testcaseID = Excelobject.getCellData(sheetname, "TestCase-ID", iLoop);
				String group = Excelobject.getCellData(sheetname, "Group", iLoop);
				String description = Excelobject.getCellData(sheetname, "Description", iLoop);
				String runStatus = Excelobject.getCellData(sheetname, "RunStatus", iLoop);
				String team = Excelobject.getCellData(sheetname, "Team", iLoop);
				String member = Excelobject.getCellData(sheetname, "Member", iLoop);

				if (runStatus.trim().equalsIgnoreCase("Y") && group.equals("Delete Entity from an Affiliation")) {
					child = extent.startTest(testcaseID, description);
					iterationReport(iLoop-1,testcaseID + " Started");
					SignIn(team, member);
					try{
						quitAffiliation(sheetname, iLoop);
					}catch(Exception e){
					
					}					
					  driver.get(URL);					  
					  parent.appendChild(child);
					  //This will mark end of the one row in data sheet
					  iterationReport(iLoop-1,testcaseID+" Completed");

				}				
			}
			
		} catch (Exception e) {

		}
	}*/
