package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint50 extends BusinessFunctions_NPD{
	
	@Test
	public void bulkWorksheetCreation() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint50, "GCNBO-1663");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1663", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1663", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1663", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1663", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1663", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);	
					//Below submitESOPWithHardCopyRequiredOrNot is modified as part of Sprint 53 changes
					//to handle the alert pop up after selecting an arrow entity
					String esopId = submitESOPWithHardCopyRequiredOrNot("GCNBO-1663", iLoop);
					compareExpeditedWorkflow("GCNBO-1663", iLoop,esopId);									
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {}
	}

	@Test
	public void bulkWorksheetCreationWithoutSkip() throws Throwable {
	
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint50, "GCNBO-1663");			
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){	
			String testCaseID = Excelobject.getCellData("GCNBO-1663", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1663", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1663", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1663", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1663", "Team", iLoop);
				
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				
				if (testCaseID.contains("Process")) {
					try {
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");
					SignIn(team, member);	
					//Below submitESOPWithHardCopyRequiredOrNot is modified as part of Sprint 53 changes
					//to handle the alert pop up after selecting an arrow entity					
					String esopId = submitESOPWithHardCopyRequiredOrNot("GCNBO-1663", iLoop);
					compareExpeditedWorkflow("GCNBO-1663", iLoop,esopId);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {
						System.out.println("This is not getting invoked");
					}
					driver.get(URL);
					System.out.println("Not able to reach here");
				}
			}			
			
}
	
}
}
