package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint49 extends BusinessFunctions_NPD{
	
	
	@Test
	public void onHoldQueueReasonForNotRejection() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint49, "GCNBO-1740");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1740", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1740", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1740", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1740", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1740", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);												
					String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1740", iLoop);
					compareTheCurrentStatus("GCNBO-1740", iLoop, esopId);
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");						
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {}	
		
	}
	
	@Test
	public void rejectionLogMetaData() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint49, "GCNBO-1751");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1751", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1751", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1751", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1751", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1751", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Reject")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);												
					String esopId = entitySectionDetailsOnProcessingCES("GCNBO-1751", iLoop);
					metaDataInTheRejectedLog(esopId);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");						
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {}	
		
	}

	// this test method is created to test sp49 changes for rejection rule maintenance app.
	@Test 
	public void rejectionRulesMaintenanceApplication() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint49, "GCNBO-1753");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1753", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1753", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1753", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1753", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1753", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Rejection Rule")) {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						rejectionRulesMaintenanceApplication("GCNBO-1753", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
