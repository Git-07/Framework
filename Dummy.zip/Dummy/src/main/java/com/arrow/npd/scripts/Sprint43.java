package com.arrow.npd.scripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint43 extends BusinessFunctions_NPD{
	
	//@Test
	public void partialAndFullTextCaseSearch() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint43, "GCNBO-1544");	
			//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes");
			//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1544", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1544", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1544", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1544", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1544", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						partialAndFullCaseSearch("GCNBO-1544",iLoop);						
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//below test method is aded on 12/28 to automate
	@Parameters({"environment"})
	@Test
	public void moveCESToDiffQueue(String environment) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint43, "CesMove");	
			uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes",environment);
			uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("CesMove", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("CesMove", "Description", iLoop);
				String runStatus = Excelobject.getCellData("CesMove", "RunStatus", iLoop);
				String member = Excelobject.getCellData("CesMove", "Member", iLoop);
				String team = Excelobject.getCellData("CesMove", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						moveTheCES("CesMove",iLoop);						
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
