package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint40 extends BusinessFunctions_NPD {

	@Test
	public void helpPageFromTheCES() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint40, "GCNBO-1510");	
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1510", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1510", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1510", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1510", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1510", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						helpPageInCESQueue("GCNBO-1510", iLoop);
						driver.manage().deleteAllCookies();						
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
