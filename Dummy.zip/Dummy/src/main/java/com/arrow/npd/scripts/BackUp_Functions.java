package com.arrow.npd.scripts;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.net.URL;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.arrow.objectrepo.SOP;
import com.arrow.sqlqueries.SQL_Queries;
import com.arrow.workflows.BusinessFunctions_NPD;

public class BackUp_Functions extends BusinessFunctions_NPD {
	
	public void abc() throws Throwable{
		//inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint40, "GCNBO-1234");
		//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows());
		//String nullTest = "";		
		//nullTest = null;
String testString = "Text: NOTE: The batch number for this SOP: PerfTestHCNCertifiedMail, Short Answer : Yes , Urgency : Second Review : Yes, Time Sensitive : No, Damage Amount : No , Entity/Affiliation : Apple Inc., Lawsuit Type : Bond Forfeiture";

String test = "2020CA012015I4ATT2016012279CA0l33";
System.out.println(test.length());
System.out.println(getCurrentDate());
/*String date = getCurrentDate();
		//String dr = "Yes";
		//String d =  dr.split("\\: ")[1];
		///String d = date.split("\\:"); 
		//System.out.println(dr.split("")[0]);
		System.out.println(testString.split("\\Short Answer : ")[1].split("\\ ")[0].split("")[0]); 
		System.out.println(testString.split("\\Second Review : ")[1].split("\\,")[0].split("")[0]);
		System.out.println(testString.split("\\ Time Sensitive : ")[1].split("\\,")[0].split("")[0]);
		System.out.println(testString.split("\\ Damage Amount : ")[1].split("\\ ,")[0].split("")[0]);*/
		//System.out.println(date);
	}
	
	//b.writeToExcel(10,"Test","EntityName",map,"D:\\Users\\Mohit.Latwal\\Test_Data_File.xlsx");
	public void writeToExcel(int key ,String sheetName,String colName,HashMap<Integer,String> hm) throws Throwable {

		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDPSOPXML, sheetName);
		Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDPSOPXML,key,colName,hm);
	}
		/*int r = 0;
		XSSFWorkbook wb;
		XSSFSheet sheet;
		XSSFCell cell;
		XSSFRow row;
		int colindex = 1;
		InputStream input = new FileInputStream(TestDataWorkBookNPDPSOPXML);
		wb = new XSSFWorkbook(input);
		sheet = wb.getSheet(sheetName);	
		Iterator<Row> rows = sheet.rowIterator();
		while(rows.hasNext()) {
			row = (XSSFRow) rows.next();			
			if(row.getRowNum() == 0) {				
				Iterator<Cell> cells = row.cellIterator();
				while(cells.hasNext()) {
					cell = (XSSFCell) cells.next();
					if(cell.getStringCellValue().equals(colName)) {						
						colindex = (int) cell.getColumnIndex();
						System.out.println("asnclkscnlnclcq " + colindex);
						break;
					}
				}
			}		
		}
		//row = sheet.getRow(r++);
		for(int j = 1 ; j <=key; j++) {
		row = sheet.getRow(j);
		if(hm.containsKey(j) == true){				
		row.createCell(colindex).setCellValue(hm.get(j));
		//sheet.setColumnWidth(j, 30 * 250);
		}
		else if(hm.containsKey(j) == false) {
			//row = sheet.getRow(j);
			row.createCell(colindex).setCellValue("Not Created");
		}
	}
		FileOutputStream fileOut = new FileOutputStream(TestDataWorkBookNPDPSOPXML);
		wb.write(fileOut);	
		wb.close();
		fileOut.close();
	}*/
		
	public static void main(String[] ar) throws Throwable{
		BackUp_Functions b = new BackUp_Functions();
		
		b.verifyPDFContent("https://arrowstg.azurectwkglobal.com/NPD/SOP/SOP_ViewTransmittal.aspx?ActionItemId=5607014412",
				"TITLE OF ACTION:Bank Of America vs. Philip C");
		//String str = "CTADVANTAGE SERVICE OF  ATTACHMENTS - NEWARK ";
		
		//System.out.println(str.split("-")[0].replace(" ", ""));		
		//b.abc();
		/*HashMap <Integer, String> map = new HashMap<Integer,String>();
		HashMap <Integer, String> map2 = new HashMap<Integer,String>();
		map.put(9,"TestEntity1");
		map.put(10,"TestEntity2");
		map.put(3,"Test1");
		map.put(4,"Test2");
		map.put(5,"TestEntity5");
		map.put(6,"TestEntity10");
		map.put(7,"TestEntity7");
		map.put(8,"TestEntity8");
		map2.put(1,"Affiliation1");
		map2.put(2,"Affiliation2");
		map2.put(3,"Affiliation3");
		map2.put(4,"Affiliation4");
		map2.put(5,"Affiliation5");
		map2.put(6,"Affiliation6");
		map2.put(7,"Affiliation7");
		map2.put(8,"Affiliation8");
		//b.writeToExcel(10,"Test","EntityName",map,"D:\\Users\\Mohit.Latwal\\Test_Data_File.xlsx");
		//b.writeToExcel("Test","AffiliationName",map2,"D:\\Users\\Mohit.Latwal\\Test_Data_File.xlsx");
		b.writeToExcel(8,"PSOP", "ESOP Id", map);
		//b.writeToExcel("Test","AffiliationName",map2);
*/	
		}
	/*if(j == 1){
	j++;
}
if (j == 0) {
	copyTheFile(desktopPath + "\\" + fileName + ".XML", NasScanFirstPath, PowerShellToCopy);
	Thread.sleep(1000);
	copyTheFile(desktopPath + "\\" + fileName + ".PDF", NasScanFirstPath, PowerShellToCopy);
	Thread.sleep(1000);
	currentFileName = fileName + ".PDF";
	renameTheFiles(desktopPath + "\\" + fileName + ".XML", fileName + ++j + ".XML",
			PowerShellToRename);
	renameTheFiles(desktopPath + "\\" + fileName + ".PDF", fileName + j + ".PDF",
			PowerShellToRename);						
}
else if (j > 1) {
	int i = j - 1;
	copyTheFile(desktopPath + "\\" + fileName + i + ".XML", NasScanFirstPath, PowerShellToCopy);
	// copyTheFile(desktopPath+"\\"+fileName+iLoop+".PDF","\\\\nastnri95001.na.wkglobal.com\\SopPassInterim\\PTRP\\TemporaryIsopImages\\AutoUploadSource\\ScanFirst\\ScanFirst",PowerShellToCopy);
	copyTheFile(desktopPath + "\\" + fileName + i + ".PDF", NasScanFirstPath, PowerShellToCopy);
	currentFileName = fileName + i + ".PDF";
	renameTheFiles(desktopPath + "\\" + fileName + i + ".XML", fileName + j + ".XML",
			PowerShellToRename);
	renameTheFiles(desktopPath + "\\" + fileName + i + ".PDF", fileName + j + ".PDF",
			PowerShellToRename);
	j++;
	
}*/

	/*public void paperSurchargeBillingValueStored(String ReportSheet, int count, String profile, String status)
			throws Throwable {
		if (status.equals("Enabled")) {
			if (profile.equals("Entity Profile")) {
				String entity_id = Excelobject.getCellData(ReportSheet, "Entity Id", count);
				ArrayList<String> resultEntity = SQL_Queries.getPSOPBillingFlagForEntity(entity_id);
				System.out.println(resultEntity.size());
				String expectedEntityId = null;
				for (int i = 0; i < resultEntity.size(); i++) {
					System.out.println(resultEntity.get(i));
					if (resultEntity.get(i).equals(entity_id)) {
						expectedEntityId = resultEntity.get(i);
						try {
							printMessageInReport("Entity \"" + expectedEntityId
									+ "\" is inserted in table when PSOP flag is enabled");
						} catch (Throwable e) {
							e.printStackTrace();
						}
						break;
					}
				}
			} else if (profile.equals("Affiliation Profile")) {
				String affl_id = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);
				ArrayList<String> result = SQL_Queries.getPSOPBillingFlagForAffiliation(affl_id);
				String expectedAffiliationId = null;
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).equals(affl_id)) {
						expectedAffiliationId = result.get(i);
						printMessageInReport("Affiliation \"" + expectedAffiliationId
								+ "\" is inserted in table when PSOP flag is enabled");
						break;
					}
				}
			}
		}
		else if(status.equals("Disabled") && profile.equals("Affiliation Profile")){
			String affl_id = Excelobject.getCellData(ReportSheet, "Affiliation Id", count);
			ArrayList<String> result1 = SQL_Queries.getPSOPBillingFlagForAffiliation(affl_id);
			if (result1.size() == 0) {
				printMessageInReport("Affiliation \"" + affl_id
						+ "\" is deleted from table when PSOP flag is disabled");
			}
		}
	}*/
	
	public boolean verifyPDFContent(String strURL, String text) throws Throwable{

        String pdfData = "";
        boolean flag = false;
        try{			
            URL url = new URL(strURL);
            BufferedInputStream file = new BufferedInputStream(url.openStream());
            PDDocument document = null;
            try {
                document = PDDocument.load(file);
                pdfData = new PDFTextStripper().getText(document);
               // System.out.println(pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[0].replaceAll("[^\\x00-\\x7F]", ""));
//System.out.println(pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("vs.")[1].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", ""));           
   //        
                //System.out.println(pdfData.split("TITLE OF ACTION: ")[1].split("(0")[1].split("\n")[0].replaceAll("[^\\x00-\\x7F]", "")); //.split("vs.")[0]
                //String str = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "");
                //System.out.println(pdfData.split("To: ")[1].split("\n")[0].split("\\R")[0].replace(" ", ""));
                //String testStr = "Re: Rockwood Capital Corporation // To: Rockwood Capital Corporation";
                //System.out.println(str.equals(testStr));
                String str = pdfData.split("TITLE OF ACTION: ")[1].split("\n")[0].split("\\R")[0].replaceAll("[^\\x00-\\x7F]", "").split(" \\(")[0];
                System.out.println(str);
                System.out.println(str.split(" \\(0")[0]);
            } finally {
                if (document != null) {
                    document.close();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        if(pdfData.contains(text)){
            flag =  true;    
            System.out.println("Text matached");
            //SuccessReport("Text : " , text + " is present in PDF");
        }
        return flag;
    }
}
