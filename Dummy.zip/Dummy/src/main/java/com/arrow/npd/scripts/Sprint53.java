package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint53 extends BusinessFunctions_NPD{
	
	
	@Test
	public void addAndExecuteDIForActionItemExecutionFailure() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint53, "Sheet1");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("Sheet1", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Sheet1", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Sheet1", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Sheet1", "Member", iLoop);
			String team = Excelobject.getCellData("Sheet1", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);						
					String esopId = submitESOPWithHardCopyRequiredOrNot("Sheet1", iLoop);					
					compareExpeditedWorkflow("Sheet1", iLoop,esopId);
					logInActionItemFailure(esopId);
					createAndExecuteActionItem("Sheet1", iLoop,esopId);
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {
		e.printStackTrace();
	
	}	
}

	//@Test
	public void modifyAndExecuteDIForPostedLog() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint53, "UnExecuteAndExecuteNewDI");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "Description", iLoop);
			String runStatus = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "RunStatus", iLoop);
			String member = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "Member", iLoop);
			String team = Excelobject.getCellData("UnExecuteAndExecuteNewDI", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);
					//String esopId = "22027223";
					String esopId = submitESOPWithHardCopyRequiredOrNot("UnExecuteAndExecuteNewDI", iLoop);
					compareExpeditedWorkflow("UnExecuteAndExecuteNewDI", iLoop,esopId);
					unexecuteActionItems(esopId);
					createAndExecuteActionItem("UnExecuteAndExecuteNewDI", iLoop,esopId);
					rejectedLogHardCopyRequiredSOPTeamDashboard("UnExecuteAndExecuteNewDI", iLoop,esopId);
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {
		e.printStackTrace();
	
	}	
}
	//@Test
	public void createCRMAfterWorksheetCreation() throws Throwable {
		
	String esopId = "";	
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint53, "CreateCRMRequestAfterWorksheet");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "Description", iLoop);
			String runStatus = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "RunStatus", iLoop);
			String member = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "Member", iLoop);
			String team = Excelobject.getCellData("CreateCRMRequestAfterWorksheet", "Team", iLoop);			
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);						
					esopId = submitESOPWithHardCopyRequiredOrNot("CreateCRMRequestAfterWorksheet", iLoop);					
					createSOPIncidentReportOnTheCreatedWorksheet(esopId);
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
				else if (testCaseID.contains("For Bulk not eligible")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);						
					esopId = submitESOPWithHardCopyRequiredOrNot("CreateCRMRequestAfterWorksheet", iLoop);
					viewAndCreateTheWorkSheetUsingESOPId("CreateCRMRequestAfterWorksheet", iLoop,esopId);
					createSOPIncidentReportOnTheCreatedWorksheet(esopId);
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
				else if (testCaseID.contains("My Worksheets to review Tab")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignInFromSOPSupportTeam();						
					worksheetInMyWorksheetsToReview(esopId);
					driver.manage().deleteAllCookies();
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");
					driver.get(URL);
				}
			}
		}
	}catch(Exception e) {
		e.printStackTrace();
	
	}
	}
}
