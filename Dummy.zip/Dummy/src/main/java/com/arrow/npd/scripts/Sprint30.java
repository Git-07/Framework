package com.arrow.npd.scripts;

import java.util.ArrayList;

import org.testng.annotations.Test;

import com.arrow.sqlqueries.SQL_Queries;
import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint30 extends BusinessFunctions_NPD {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;
	private ArrayList<String> entityNumber = new ArrayList<String>();
	private ArrayList<String> subgroupID = new ArrayList<String>();
	
    //@Test
	public void checkDSEffectiveStartDateOriginalInvoiceWithoutDS() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint30, "GCNBO-1068");
			int renewalMonth  = 10;
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-1068", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-1068", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-1068", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-1068", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-1068", "Team", iLoop);
				
				if (_runStatus.trim().equalsIgnoreCase("Y")) {					
					if (_testCaseID.contains("Entity Level Invoice")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						String entity = getTheEntityWithoutDSEnabled();
						bundleDSEffectiveStartDateEntityLevel("GCNBO-1068", iLoop,entity);
						entityNumber.add(entity);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("Subgroup Level Invoice")) {						
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						String subgroupId = getTheSubgroupWithoutDSEnabled(String.valueOf(renewalMonth));
						bundleDSEffectiveStartDateSubgroupLevel("GCNBO-1068", iLoop,"",subgroupId);						
						++renewalMonth;	
						subgroupID.add(subgroupId);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void discontinueRepresentationBackDateDSEffectiveStartDate() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint30, "GCNBO-1068");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-1068", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-1068", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-1068", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-1068", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-1068", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Discontinue DE LLC Rep for Standalone Entity")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);	
						String entity = getEntityHavingMoreThanOneRepIncludingREPLLC();
						discontinueDomesticREPLLCorLP(entity);
				        bundleDSEffectiveStartDateEntityLevel("GCNBO-1068", iLoop, entity);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("Discontinue DE LLC Rep for Entity of a Subgroup")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);						
						String entity = getEntityUnderSubgroupHavingMoreThanOneRepIncludingREPLLC(
								getTheSubgroupWithoutDSEnabled(String.valueOf("5")));					
						discontinueDomesticREPLLCorLP(entity);
						bundleDSEffectiveStartDateSubgroupLevel("GCNBO-1068", iLoop,entity,subgroupForWhichEntityHavingMoreThanOneRepIncludingREPLLC(entity));						
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//@Test
	public void subgroupLevelHaveDSAddStandaloneEntityToIt() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint30, "GCNBO-1068");
			int renewalMonth  = 6;
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-1068", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-1068", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-1068", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-1068", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-1068", "Team", iLoop);
				
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					if (_testCaseID.contains("Standalone Entity have Eligible DE LLC Rep")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						String entity = getTheEntityWithoutDSEnabled();
						addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice("GCNBO-1068",
								iLoop,getTheSubgroupWhichAlreadyHavingDSPresent(String.valueOf(renewalMonth)), entity);
						renewalMonth++;
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("Standalone Entity does not have Eligible DE LLC Rep")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						String entity = getEntityNotHavingDERepLLCORDELP();					
						addTheEntityToTheSubgroupHavingDSPresentAndReviseSubgroupLevelInvoice("GCNBO-1068",
								iLoop,getTheSubgroupWhichAlreadyHavingDSPresent(String.valueOf(renewalMonth)), entity);											
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//@Test
	public void validateTheInvoiceChangesPostrevision() throws Throwable {
		try {
			int s=0,e=0;
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint30, "GCNBO-1068");			
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-1108", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-1108", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-1108", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-1108", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-1108", "Team", iLoop);
	
				
				if (_runStatus.trim().equalsIgnoreCase("Y")) {					
					if (_testCaseID.contains("Entity Level Invoice")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);							
						String orderId = SQL_Queries.getTheOrderIdPostRevisionOfEntityLevelInvoice(entityNumber.get(e)).get(0);
						validateTheInvoiceChangesPostRevision(orderId);
						e++;
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("Subgroup Level Invoice")) {						
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);						
						String orderId = SQL_Queries.getTheOrderIdPostRevisionOfSubgroupLevelInvoice(subgroupID.get(s)).get(0);
						validateTheInvoiceChangesPostRevision(orderId);
						s++;
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
