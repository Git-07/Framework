package com.arrow.npd.scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class ExecutionReportEditing extends BusinessFunctions_NPD{
	
      
	//@Test
	public void editTheReport() {
		
		driver.get("D:/Users/Mohit.Latwal/Desktop/NPD_Automation_Latest/Reports/ExecutionResults.html");
		
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
		    js = (JavascriptExecutor) driver;
		}
		js.executeScript("return document.getElementsByClassName('review-info-star')[0].remove();");

		
		
	}
	
	@Test
	public void bulkWorksheetCreation() throws Throwable {
		
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint50, "GCNBO-1663");		
		for(int iLoop =0 ; iLoop<= 3; iLoop++){			
			String testCaseID = Excelobject.getCellData("GCNBO-1663", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("GCNBO-1663", "Description", iLoop);
			String runStatus = Excelobject.getCellData("GCNBO-1663", "RunStatus", iLoop);
			String member = Excelobject.getCellData("GCNBO-1663", "Member", iLoop);
			String team = Excelobject.getCellData("GCNBO-1663", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(team, member);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					WebElement ele = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[alt='Entity']")));
					ele.click();										
					WebElement ele5 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtEntityNumber")));
					ele5.sendKeys("1234");					
					WebElement ele6 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnSearch")));
					ele6.click();
					WebElement ele2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnCreateEntity")));
					ele2.click();
					WebElement ele4 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ctlJurisSelector_rbJurisType2")));					
                    driver.navigate().refresh();
                    try {
                    	System.out.println("reached here");
                    	Thread.sleep(2000);
                    	//WebElement e = driver.findElement(By.xpath("//Select[@id='ctlJurisSelector_lstJurisdictions']/option[contains(text(),'Alaska')]"));
                    	ele4.click();
                    	Thread.sleep(3000);
                    }catch(StaleElementReferenceException e) {
                    	e.printStackTrace();
                    }
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");						
					driver.get(URL);
				}
			}
		}
	}catch(StaleElementReferenceException e) {
		e.printStackTrace();
	}
	}


}
