package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint27  extends BusinessFunctions_NPD  {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;
	
	@Test
	public void addPSOPPermissionAndInvoiceRevision() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint27, "GCNBO-927");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-927", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-927", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-927", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-927", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-927", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {				
					if (_testCaseID.contains("Admin Tab add the PSOP permission")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						addThePSOPPermissionToRole("GCNBO-927",iLoop);
						Thread.sleep(3000);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
					else if (_testCaseID.contains("For the Role having PSOP permission and Revision using PSOP List")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);		
						selectInvoiceFromTheInvoiceList("GCNBO-927",iLoop);
						psopRevisionPermissionFromInvoiceList("GCNBO-927",iLoop,"Permitted");
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("For the Role having PSOP permission and Revision using Invoice Profile")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);	
						searchForTheInvoiceFromPSOPInvoiceSearch("GCNBO-927",iLoop);
						psopRevisionPermissionFromInvoiceProfile("GCNBO-927",iLoop,"Permitted");
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void removePSOPPermissionAndInvoiceRevision() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint27, "GCNBO-927");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-927", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-927", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-927", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-927", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-927", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {				
					if (_testCaseID.contains("Admin Tab remove the PSOP permission")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						removeThePSOPPermissionFromRole("GCNBO-927",iLoop);	
						Thread.sleep(3000);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}	
					else if (_testCaseID.contains("For the Role not having PSOP permission and Revision using PSOP List")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);		
						selectInvoiceFromTheInvoiceList("GCNBO-927",iLoop);
						psopRevisionPermissionFromInvoiceList("GCNBO-927",iLoop,"Not Permitted");
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("For the Role not having PSOP permission and Revision using Invoice Profile")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);	
						searchForTheInvoiceFromPSOPInvoiceSearch("GCNBO-927",iLoop);
						psopRevisionPermissionFromInvoiceProfile("GCNBO-927",iLoop,"Not Permitted");
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
					else if (_testCaseID.contains("Reset the PSOP permission")) {
						intialiseTheReport(_testCaseID, _description, iLoop);
						SignIn(_team, _member);
						addThePSOPPermissionToRole("GCNBO-927",iLoop);
						Thread.sleep(3000);
						endTheReport(_testCaseID, iLoop);
						driver.get(URL);
					}
				}				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void nraiPSOPInvoiceProfilePage() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint27, "GCNBO-983");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-983", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-983", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-983", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-983", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-983", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("PSOP Invoice Profile")) {
						psopInvoiceSearch("GCNBO-983", iLoop);
					}
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void psopExceptionsUI() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint27, "GCNBO-853");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-853", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-853", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-853", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-853", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-853", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("PSOP Exceptions UI")) {
						psopInvoiceExceptionSearch("GCNBO-853", iLoop);
						psopExceptionTab("GCNBO-853", iLoop);
					}
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
