package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint25 extends BusinessFunctions_NPD {

	private String _testCaseID;
	private String _description;
	private String _runStatus;
	private String _member;
	private String _team;

	@Test
	public void psopInvoicesListPage() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint25, "GCNBO-834");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-834", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-834", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-834", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-834", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-834", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("For Standalone Entity")) {
						searchForTheEntity("GCNBO-834", iLoop);
						psopInvoicesList("GCNBO-834", iLoop, "Standalone Entity");
					} else if (_testCaseID.contains("For Affiliated Entity")) {
						searchForTheAffiliation("GCNBO-834", iLoop);
						psopInvoicesList("GCNBO-834", iLoop, "Affiliation");
					}
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void psopInvoiceProfilePage() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint25, "GCNBO-802");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-802", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-802", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-802", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-802", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-802", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("Search By Invoice ID")) {
						psopInvoiceSearch("GCNBO-802", iLoop);
					}
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void psopInvoiceSearchResultsPage() throws Throwable{
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint25, "GCNBO-833");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-833", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-833", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-833", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-833", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-833", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					if (_testCaseID.contains("PSOP Invoice Status as Open")) {					
						psopInvoiceSearchCriteriaFilter("GCNBO-833", iLoop,"Open");
						psopInvoiceSearchResults("GCNBO-833", iLoop);
					}
					else if (_testCaseID.contains("PSOP Invoice Status as Closed")) {
						psopInvoiceSearchCriteriaFilter("GCNBO-833", iLoop,"Closed");
						psopInvoiceSearchResults("GCNBO-833", iLoop);
					}
					else if (_testCaseID.contains("All PSOP Invoice")) {
						psopInvoiceSearchCriteriaFilter("GCNBO-833", iLoop,"All");
						psopInvoiceSearchResults("GCNBO-833", iLoop);												
					}
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void psopInvoiceRevisionPage() throws Throwable{
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint25, "GCNBO-763");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				_testCaseID = Excelobject.getCellData("GCNBO-763", "TestCase-ID", iLoop);
				_description = Excelobject.getCellData("GCNBO-763", "Description", iLoop);
				_runStatus = Excelobject.getCellData("GCNBO-763", "RunStatus", iLoop);
				_member = Excelobject.getCellData("GCNBO-763", "Member", iLoop);
				_team = Excelobject.getCellData("GCNBO-763", "Team", iLoop);
				if (_runStatus.trim().equalsIgnoreCase("Y")) {
					intialiseTheReport(_testCaseID, _description, iLoop);
					SignIn(_team, _member);
					psopInvoiceRevisionPage("GCNBO-763",iLoop);
					endTheReport(_testCaseID, iLoop);
					driver.get(URL);
				}
		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}