package com.arrow.npd.scripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint42 extends BusinessFunctions_NPD{
	
	//with this function sop upload needs to be done with para HCR -> Yes or No
	@Parameters({"environment"})
	//@Test
	public void rejectionLetterPopUpFromTheCESPage(String environment) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint42, "GCNBO-1543");	
			uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes",environment);
			uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1543", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1543", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1543", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1543", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1543", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Reject")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						rejectESOPWithHardCopyRequiredOrNot("GCNBO-1543", iLoop);						
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//with this function sop upload needs to be done with para HCR -> Yes or No
	@Parameters({"environment"})
	@Test
	public void rejectedHardCopyRequiredSOPTeamDashboard(String environment) throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint42, "GCNBO-1545");
			//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"Yes",environment);
			//uploadTheFilesToScannerRBCPath(inputSheet.getPhysicalNumberOfRows()/2,"No",environment);
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1545", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1545", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1545", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1545", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1545", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Reject")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						String esopId = rejectESOPWithHardCopyRequiredOrNot("GCNBO-1545", iLoop);			
						rejectedLogHardCopyRequiredSOPTeamDashboard("GCNBO-1545", iLoop,esopId);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
