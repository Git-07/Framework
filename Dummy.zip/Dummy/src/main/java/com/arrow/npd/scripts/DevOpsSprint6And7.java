package com.arrow.npd.scripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class DevOpsSprint6And7 extends BusinessFunctions_NPD {

	@Test
	public void bankruptcyDataRetainInWorksheet() throws Throwable {

		int currentTest = 0;
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint7, "Bankruptcy Switch");
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String[] esops = new String[totalTest];
		for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			String testCaseID = Excelobject.getCellData("Bankruptcy Switch", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Bankruptcy Switch", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Bankruptcy Switch", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Bankruptcy Switch", "Member", iLoop);
			String team = Excelobject.getCellData("Bankruptcy Switch", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Process a CES")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = submitESOPWithHardCopyRequiredOrNot("Bankruptcy Switch", iLoop);
						esops[currentTest] = esopId;
						++currentTest;
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
					}
				}
				driver.get(URL);
			}
		}
		//Validate the title of Action after bankruptcy button selected
		validateWorksheetAndExecuteActionItems(currentTest - 1, "Bankruptcy Switch", esops);
	}
	
	@Test
	public void titleOfActionInTransmittal() throws Throwable {

		int currentTest = 0;
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint7, "TOAInTransmittal");

		// Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String[] esops = new String[totalTest];

		for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			String testCaseID = Excelobject.getCellData("TOAInTransmittal", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("TOAInTransmittal", "Description", iLoop);
			String runStatus = Excelobject.getCellData("TOAInTransmittal", "RunStatus", iLoop);
			String member = Excelobject.getCellData("TOAInTransmittal", "Member", iLoop);
			String team = Excelobject.getCellData("TOAInTransmittal", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Process a CES")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = submitESOPWithHardCopyRequiredOrNot("TOAInTransmittal", iLoop);
						esops[currentTest] = esopId;
						++currentTest;
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
					}
				}
				driver.get(URL);
			}
		}
		validateWorksheetAndExecuteActionItems(currentTest - 1, "TOAInTransmittal", esops);
	}
	
	@Test
	public void consolidatedDataRetainInWorksheet() throws Throwable {

		int currentTest = 0;
		inputSheet = Excelobject.getSheetObject(TestDataNPDDevOpsSprint7, "Consolidated Switch");

		// Below parameter is added to fix the execution timing related issue
		int totalTest = inputSheet.getPhysicalNumberOfRows();
		String[] esops = new String[totalTest];
		for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			String testCaseID = Excelobject.getCellData("Consolidated Switch", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("Consolidated Switch", "Description", iLoop);
			String runStatus = Excelobject.getCellData("Consolidated Switch", "RunStatus", iLoop);
			String member = Excelobject.getCellData("Consolidated Switch", "Member", iLoop);
			String team = Excelobject.getCellData("Consolidated Switch", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {

				if (testCaseID.contains("Process a CES")) {
					try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);
						String esopId = submitESOPWithHardCopyRequiredOrNot("Consolidated Switch", iLoop);
						esops[currentTest] = esopId;
						++currentTest;
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					} catch (Exception e) {
					}
				}
				driver.get(URL);
			}
		}
		//Validate the title of Action after consolidated button selected
		validateWorksheetAndExecuteActionItems(currentTest - 1, "Consolidated Switch", esops);
	}
	
// the below test is taken from CES.java file which is part of regression
	
	
	@Parameters({"environment"})
	@Test/*(groups= {"newly"})*/
	public void rejectionLetterPopUpFromTheCESPage(String environment) throws Throwable {
		
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookSOPCES, "RejectionLetterFromCES");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("RejectionLetterFromCES", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("RejectionLetterFromCES", "Description", iLoop);
				String runStatus = Excelobject.getCellData("RejectionLetterFromCES", "RunStatus", iLoop);
				String member = Excelobject.getCellData("RejectionLetterFromCES", "Member", iLoop);
				String team = Excelobject.getCellData("RejectionLetterFromCES", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Reject")) {
						try {
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						rejectESOPWithHardCopyRequiredOrNot("RejectionLetterFromCES", iLoop);																	
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
					}catch(Exception e) {
						e.printStackTrace();		
					}
						driver.get(URL);
					}
				}
			}

	
	}


}
