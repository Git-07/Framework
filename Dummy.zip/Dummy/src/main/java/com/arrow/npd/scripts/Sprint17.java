package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint17 extends BusinessFunctions_NPD{
	
	 @Test
		public void backToInvoiceListButtonOnCreditDSPage() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint17, "GCNBO-604");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "GCNBO-604";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);
						
						backToInvoiceListButtonOnCreditDSPage(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
	 
	 @Test
		public void creditDSOnInvoiceProfilePage() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint17, "GCNBO-608");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "GCNBO-608";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						creditDSButtonOnInvoiceProfilePage(SheetName, iLoop, strTestCaseID);
			
						driver.get(URL);
						
						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}

}
