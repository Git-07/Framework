package com.arrow.npd.scripts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.arrow.npd.scripts.PendingModules.Teams;
import com.arrow.workflows.BusinessFunctions_NPD;

public class HighVolumeAcceleratedLogs extends BusFuncNPD{
	
	//int browserInstance = 0;
	
    enum Teams{
		
		NewYorkTeam("CT - New York SOP Team"), 
		ColumbusSOPTeam("CT - Columbus SOP Team"),
		NewYorkTeamMember("Roopmattee Jairam"),
		ColumbusSOPTeamMember("Troy Spann"),
	    WilmingtonSOPTeam("CT - Wilmington SOP Team"),
	    WilmingtonSOPTeamMember("Cybele Mendes");
		String nameAndMemeber;	
		Teams(String teamAndMem){
			this.nameAndMemeber = teamAndMem;
		}
	}

Map<String, ArrayList<WebDriver>> driversMap = new HashMap<String, ArrayList<WebDriver>>();
//Need browser session invoke function to be implemenmted
@Parameters({"browser","threads","ip"})
@BeforeTest
public /*Map<String , ArrayList<WebDriver>>*/ void createBrowserInstance(String browser, String threads,String ip) throws Throwable{
		
	System.out.println("REached here-----");
	ArrayList<WebDriver>  driver = new ArrayList<WebDriver>();
	for(int i = 0; i < Integer.valueOf(threads); i++) {
		
		driver.add(getTheDriverInstance(ip));
	}
		driversMap.put(browser,driver);

		//return driversMap;
	}
   
    @Parameters({"browser"})
	@Test
	public void bulkWorksheetActionItemExecutionNewYorkTeam(String browser) throws Throwable {
    	//browserInstance = 1;
		String team = "";
		String member = "";
		for(Teams t : Teams.values()) {
			
			switch (t) {
			case NewYorkTeam :
			  team = t.nameAndMemeber;
			  break;
			case NewYorkTeamMember:
				member = t.nameAndMemeber;
				System.out.println(member);		     
			}
		}
		
	//Map<Integer,String> acceleratedWorksheet = new HashMap<Integer,String>();
	//int acceleratedLogKey =1;
	Thread.sleep(10000);
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "MultiThreading");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("MultiThreading", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("MultiThreading", "Description", iLoop);
			String runStatus = Excelobject.getCellData("MultiThreading", "RunStatus", iLoop);
			//String member = Excelobject.getCellData("MultiThreading", "Member", iLoop);
			//String team = Excelobject.getCellData("MultiThreading", "Team", iLoop);
			
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(driversMap.get(browser).get(0),team, member);
					String esopId = submitESOPWithHardCopyRequiredOrNot(driversMap.get(browser).get(0),"MultiThreading", iLoop);
					//validate the log in expedited transmission page					
					//compareExpeditedWorkflow("MultiThreading", iLoop,esopId);
					//expeditedTransmissionLog(esopId);	
					//acceleratedWorksheet.put(acceleratedLogKey, actionItemExecution(esopId));					
					//transmittalDataVerification("MultiThreading", iLoop,esopId);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");					
					//acceleratedLogKey++;
					driversMap.get(browser).get(0).get(URL);
				}
			}						
		}
		//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDSprint52,acceleratedLogKey - 1,"Accelerated Log",acceleratedWorksheet);
	}catch(Exception e) {
		e.printStackTrace();
	
	}
	}
	
	
    @Parameters({"browser"})
	@Test
	public void bulkWorksheetActionItemExecutionColumbusSOPTeam(String browser) throws Throwable {
    	//browserInstance = 2;
		String team = "";
		String member = "";
		for(Teams t : Teams.values()) {
			
			switch (t) {
			case ColumbusSOPTeam :
			  team = t.nameAndMemeber;
			  break;
			case ColumbusSOPTeamMember:
				member = t.nameAndMemeber;
				System.out.println(member);		     
			}
		}
		
	//Map<Integer,String> acceleratedWorksheet = new HashMap<Integer,String>();
	//int acceleratedLogKey =1;
	try {		
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "MultiThreading");		
		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
			String testCaseID = Excelobject.getCellData("MultiThreading", "TestCase-ID", iLoop);
			String description = Excelobject.getCellData("MultiThreading", "Description", iLoop);
			String runStatus = Excelobject.getCellData("MultiThreading", "RunStatus", iLoop);
			//String member = Excelobject.getCellData("MultiThreading", "Member", iLoop);
			//String team = Excelobject.getCellData("MultiThreading", "Team", iLoop);
			if (runStatus.trim().equalsIgnoreCase("Y")) {
				if (testCaseID.contains("Process")) {					
					child = extent.startTest(testCaseID, description);
					iterationReport(iLoop, testCaseID + " Started");						
					SignIn(driversMap.get(browser).get(1),team, member);											
					String esopId = submitESOPWithHardCopyRequiredOrNotSecond(driversMap.get(browser).get(1),"MultiThreading", iLoop);
					//validate the log in expedited transmission page					
					//compareExpeditedWorkflow("MultiThreading", iLoop,esopId);
					//expeditedTransmissionLog(esopId);	
					//acceleratedWorksheet.put(acceleratedLogKey, actionItemExecution(esopId));					
					//transmittalDataVerification("MultiThreading", iLoop,esopId);					
					parent.appendChild(child);
					iterationReport(iLoop, testCaseID + " Completed");					
					//acceleratedLogKey++;
					driversMap.get(browser).get(1).get(URL);					
				}
			}						
		}
		//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDSprint52,acceleratedLogKey - 1,"Accelerated Log",acceleratedWorksheet);
	}catch(Exception e) {
		e.printStackTrace();
	
	}
	}
    
    @Parameters({"browser"})
   	//@Test
   	public void bulkWorksheetActionItemExecutionWilmingtonSOPTeam(String browser) throws Throwable {
    	//browserInstance = 3;
   		String team = "";
   		String member = "";
   		for(Teams t : Teams.values()) {
   			
   			switch (t) {
   			case WilmingtonSOPTeam :
   			  team = t.nameAndMemeber;
   			  break;
   			case WilmingtonSOPTeamMember:
   				member = t.nameAndMemeber;
   				System.out.println(member);		     
   			}
   		}
   	Thread.sleep(40000);	
   	//Map<Integer,String> acceleratedWorksheet = new HashMap<Integer,String>();
   	//int acceleratedLogKey =1;
   	try {		
   		inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint52, "MultiThreading");		
   		for(int iLoop =0 ; iLoop<= inputSheet.getPhysicalNumberOfRows(); iLoop++){			
   			String testCaseID = Excelobject.getCellData("MultiThreading", "TestCase-ID", iLoop);
   			String description = Excelobject.getCellData("MultiThreading", "Description", iLoop);
   			String runStatus = Excelobject.getCellData("MultiThreading", "RunStatus", iLoop);
   			//String member = Excelobject.getCellData("MultiThreading", "Member", iLoop);
   			//String team = Excelobject.getCellData("MultiThreading", "Team", iLoop);
   			if (runStatus.trim().equalsIgnoreCase("Y")) {
   				if (testCaseID.contains("Process")) {					
   					child = extent.startTest(testCaseID, description);
   					iterationReport(iLoop, testCaseID + " Started");						
   					SignIn(driversMap.get(browser).get(2),team, member);											
   					//String esopId = submitESOPWithHardCopyRequiredOrNotThird(browserInstance,driversMap.get(browser).get(2),"MultiThreading", iLoop);
   					//validate the log in expedited transmission page					
   					//compareExpeditedWorkflow("MultiThreading", iLoop,esopId);
   					//expeditedTransmissionLog(esopId);	
   					//acceleratedWorksheet.put(acceleratedLogKey, actionItemExecution(esopId));					
   					//transmittalDataVerification("MultiThreading", iLoop,esopId);					
   					parent.appendChild(child);
   					iterationReport(iLoop, testCaseID + " Completed");					
   					//acceleratedLogKey++;
   					driversMap.get(browser).get(2).get(URL);					
   				}
   			}						
   		}
   		//Excelobject.writeDataToExistingExcel(TestDataWorkBookNPDSprint52,acceleratedLogKey - 1,"Accelerated Log",acceleratedWorksheet);
   	}catch(Exception e) {
   		e.printStackTrace();
   	
   	}
   	}

}
