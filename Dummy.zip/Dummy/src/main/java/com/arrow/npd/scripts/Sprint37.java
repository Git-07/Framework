package com.arrow.npd.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_NPD;

public class Sprint37 extends BusinessFunctions_NPD {

	@Test
	public void entitySectionDefaultExpanded() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint37, "GCNBO-1282");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1282", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1282", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1282", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1282", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1282", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Process")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						entitySectionDetailsOnProcessingCES("GCNBO-1282", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void levelSpecificFieldsInCESPage() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint37, "GCNBO-1182");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1182", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1182", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1182", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1182", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1182", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Log in As Level")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						entitySectionDetailsOnProcessingCES("GCNBO-1182", iLoop);
						driver.manage().deleteAllCookies();
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	@Test    //related logs needs to be created and update the Test data sheet before running scripts
	public void relatedLogSearchfunctionality() throws Throwable {
		try {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookNPDSprint37, "GCNBO-1268");
			for (int iLoop = 0; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				String testCaseID = Excelobject.getCellData("GCNBO-1268", "TestCase-ID", iLoop);
				String description = Excelobject.getCellData("GCNBO-1268", "Description", iLoop);
				String runStatus = Excelobject.getCellData("GCNBO-1268", "RunStatus", iLoop);
				String member = Excelobject.getCellData("GCNBO-1268", "Member", iLoop);
				String team = Excelobject.getCellData("GCNBO-1268", "Team", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					if (testCaseID.contains("Search By Case#")) {					
						child = extent.startTest(testCaseID, description);
						iterationReport(iLoop, testCaseID + " Started");
						SignIn(team, member);						
						entitySectionDetailsOnProcessingCES("GCNBO-1268", iLoop);
						parent.appendChild(child);
						iterationReport(iLoop, testCaseID + " Completed");
						driver.get(URL);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
