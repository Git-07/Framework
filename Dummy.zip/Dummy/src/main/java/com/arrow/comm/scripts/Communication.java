package com.arrow.comm.scripts;

import org.testng.annotations.Test;

import com.arrow.workflows.BusinessFunctions_COMM;

public class Communication extends BusinessFunctions_COMM {

	// User Performs a Successful Search only by Log #
	@Test
	public void searchByLogId() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "SearchByLogOnly");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchByLogOnly";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchByLogId(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Performs a Successful Search by Log
	// Verify the xpath of recieived date of log before changing the logId
	@Test
	public void searchByLogIdAndDate() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "SearchByLogId");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchByLogId";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchByLogIdAndDate(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Performs a Successful Search By Entity
	@Test
	public void searchByEntity() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "SearchByEntity");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SearchByEntity";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					searchByEntity(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Creates a Worksheet
	@Test
	public void createWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "CreateWorksheet");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CreateWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					createWorksheet(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User edits a Communication Worksheet by changing the Received Date Method of
	// Service Comm Juris and Document Juris
	@Test
	public void editWorksheet() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "EditWorksheet");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "EditWorksheet";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					editWorksheet(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}

	// User Views Transmittal
	@Test
	public void viewTransmittal() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "ViewTransmittal");
		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ViewTransmittal";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					viewTransmittal(SheetName, iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");

				}

			} catch (Exception e) {
				catchBlock(e);
			}

		}
	}
	
	// User Views Transmittal History for an Entity when the latest transmittal has not been returned
	@Test
		public void transmittalHistory() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "TransmittalHistory");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "TransmittalHistory";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						transmittalHistory(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		
		
		//'User Views Document Type as "Annual Report" with Document Source as "Department of Commerce" by method of Service as "Bulk Mail"
		@Test
		public void annualReportBulkMail() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "BulkMail");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "BulkMail";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						annualReportBulkMail(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		 
		 
		//'User Views Document Type as "Periodic Report" with Document Source as "Department of Licensing"  by method of Service as "Regular Mail"
		@Test
		public void periodicReportRegularMail() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "RegularMail");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "RegularMail";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						periodicReportRegularMail(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}
		 
		 
		//'User Views Document Type as "Biennial Report" with Document Source as "Arizona Corporation Commission"  by method of Service as "Electronic Delivery"
		@Test
		public void biennialReportElectronicDelivery() throws Throwable {
			inputSheet = Excelobject.getSheetObject(TestDataWorkBookCommunication, "ElectronicDelivery");
			for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
				try {
					String SheetName = "ElectronicDelivery";
					String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
					String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
					String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
					String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
					String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
					if (runStatus.trim().equalsIgnoreCase("Y")) {
						child = extent.startTest(strTestCaseID, strDesc);

						// This will mark the beginning of row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Started");

						// This method will log into the Application
						SignIn(strTeam, strMember);

						biennialReportElectronicDelivery(SheetName, iLoop);

						parent.appendChild(child);
						// This will mark end of the one row in data sheet
						iterationReport(iLoop - 1, strTestCaseID + " Completed");

					}

				} catch (Exception e) {
					catchBlock(e);
				}

			}
		}


}
