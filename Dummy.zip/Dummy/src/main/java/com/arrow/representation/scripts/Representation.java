package com.arrow.representation.scripts;

import org.testng.annotations.Test;
import com.arrow.workflows.BusinessFunctions_Representation;

public class Representation extends BusinessFunctions_Representation {

	@Test
	// Verify Represenation can be created and Discontinued
	public void AffiliatedRepCreateAndDiscontinue() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "AffiliatedRepCreateDiscontinue");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AffiliatedRepCreateDiscontinue";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will create and discontinue rep
					String AffiliatedRepCreateAndDiscontinue = AffiliatedRepCreateAndDiscontinue(SheetName, iLoop);
					System.out.println(AffiliatedRepCreateAndDiscontinue);
					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify Representation can be created and Discontinued for Standalone Entity
	public void StandaloneRepAndDiscontinue() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "StandaloneRepCreateDiscontinue");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "StandaloneRepCreateDiscontinue";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will create and discontinue rep
					String CreateRepAndDiscontinue = StandaloneRepAndDiscontinue(SheetName, iLoop);
					System.out.println(CreateRepAndDiscontinue);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify Representation being Discontinued due to Property Sold
	public void DiscntinueDuetoPropertySold() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "DiscontinueDueToPropertySold");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "DiscontinueDueToPropertySold";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Discontinue due to property sold button
					String DiscntinueDuetoPropertySold = DiscntinueDuetoPropertySold(SheetName, iLoop);
					System.out.println(DiscntinueDuetoPropertySold);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
		@Test
	// Verify Sort By present in Representation 
	public void SortBy() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "SortBy");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "SortBy";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Export button in Representation
					String SortBy = SortBy(SheetName, iLoop);
					System.out.println(SortBy);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify Reinstate and Discontinue Multiple Rep's in Representation 
	public void ReinstateAndDiscontinueMultiple() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "Multiple");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "Multiple";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Export button in Representation
					String ReinstateAndDiscontinueMultiple = ReinstateAndDiscontinueMultiple(SheetName, iLoop);
					System.out.println(ReinstateAndDiscontinueMultiple);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify Print button in Representation 
	public void PrintRepresentation() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "PrintRep");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "PrintRep";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Export button in Representation
					String PrintRep = PrintRep(SheetName, iLoop);
					System.out.println(PrintRep);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify Rep for Independent Director
	public void IndependentDirector() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "IndepedentDirector");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "IndepedentDirector";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Independent Director in Representation
					String IndependentDirector = IndependentDirector(SheetName, iLoop);
					System.out.println(IndependentDirector);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}
	
	@Test
	// Verify State ID for Rep
	public void StateID() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "StateID");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "StateID";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Independent Director in Representation
					String StateID = StateID(SheetName, iLoop);
					System.out.println(StateID);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}	
	
	
	@Test
	// Verify Assumed Name for Rep
	public void AssumedNameRep() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "AssumedName");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "AssumedName";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Independent Director in Representation
					String AssumedNameRep = AssumedNameRep(SheetName, iLoop);
					System.out.println(AssumedNameRep);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}	
	
	@Test
	// Verify Domestic Rep with Corporate Staffing Login
	public void CorporateStaffing() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "CorporateStaffing");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "CorporateStaffing";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					// This will verify Independent Director in Representation
					String CorporateStaffing = CorporateStaffing(SheetName, iLoop);
					System.out.println(CorporateStaffing);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
				}

			} catch (Exception e) {
				catchBlock(e);
			}
		}
	}	
	
	@Test
	// Verify user is able to resignation of the discontinued rep
	public void ResignationOfDiscontinuedRep() throws Throwable {
		inputSheet = Excelobject.getSheetObject(TestDataWorkBookRepresentation, "ResignationOfDiscontinuedRep");

		for (int iLoop = 2; iLoop <= inputSheet.getPhysicalNumberOfRows(); iLoop++) {
			try {
				String SheetName = "ResignationOfDiscontinuedRep";
				String strTestCaseID = Excelobject.getCellData(SheetName, "TestCase-ID", iLoop);
				String runStatus = Excelobject.getCellData(SheetName, "RunStatus", iLoop);
				String strTeam = Excelobject.getCellData(SheetName, "Team", iLoop);
				String strMember = Excelobject.getCellData(SheetName, "Member", iLoop);
				String strDesc = Excelobject.getCellData(SheetName, "Description", iLoop);
				if (runStatus.trim().equalsIgnoreCase("Y")) {
					child = extent.startTest(strTestCaseID, strDesc);

					// This will mark the beginning of row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Started");

					// This method will log into the Application
					SignIn(strTeam, strMember);

					//This method will reinstate the respective discontinued rep
					ResignationOfDiscontinuedRep(SheetName,iLoop);

					parent.appendChild(child);
					// This will mark end of the one row in data sheet
					iterationReport(iLoop - 1, strTestCaseID + " Completed");
					}
			} 
			catch(Exception e){
				catchBlock(e);
			}
		}
	}
}