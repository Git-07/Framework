$sourcePath = $args[0]
Remove-Item -Path $sourcePath