$sourcePath = $args[0]
$destinationPath = $args[1]
Copy-Item -Path $sourcePath -Destination $destinationPath