##File Rename

$sourcePath = $args[0]
$newFileName = $args[1]
Rename-Item -Path $sourcePath -NewName $newFileName